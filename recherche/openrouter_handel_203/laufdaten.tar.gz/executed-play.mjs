import assert from 'node:assert/strict';
import path from 'node:path';
import fs from 'node:fs';

import {observeTurn} from '../natural_ab/observe.mjs';

export async function play({hosts,gate,readRecords,save,root,hash,engine,delay}){
    const turns=[];
    for(let n=1;n<=6;n++)for(const arm of (n%2 ? ['A','B']:['B','A'])){
        const {driver,page,foldChat,inst,card}=hosts[arm];
        const scenario=Math.ceil(n/2);
        const seed=fs.readFileSync(path.join(root,scenario===3?'combat-seed.jsonl':'guild-seed.jsonl'),'utf8');
        const name='natural-trade-'+arm+'-'+n;
        fs.writeFileSync(path.join(inst.user,'chats',card,name+'.jsonl'),seed,{flag:'wx'});
        await page.evaluate(n=>SillyTavern.getContext().openCharacterChat(n),name);
        driver.testChat=await driver.identity();
        const before=await driver.chat(), state=foldChat(before).state;
        const original=seed.trim().split('\n').slice(1).map(JSON.parse);
        assert.deepEqual(state,foldChat(original).state);
        assert.deepEqual(before.map(m=>m.extra?.avereth), original.map(m=>m.extra?.avereth));
        const texts=[
          'Nessa, can you offer me one fine hand-axe for sale right now? What is your firm price for it? I only ask for the offer and keep my purse closed.',
          'Nessa, would you offer me a fine tower shield only on condition that the Guild first seals my permit? I do not have the seal yet. What price would apply once I have it? I am only asking about terms.',
          'Keeping my staff ready, I ask Nessa what firm price she can offer for a fine kite shield right now. May I have a strip of red cloth as a gift? Will you promise to carry a warning to the Guild when we are safe? I keep my coins and stay where I am.'
        ];
        if(state.entities.pc.status==='dead')throw Error(arm+' character dead');
        assert(await driver.verifySaved(before,{complete:true}));assert(!(await driver.probe()).busy);
        const action=texts[scenario-1];
        await page.fill('#send_textarea',action);
        await page.evaluate(observeTurn,{index:before.length+1});
        gate(arm,'trade',n);
        await page.click('#send_but');
        let terminal=false;
        for(let i=0;i<1800;i++){
            const issue=readRecords().find(r=>r.kind==='end'&&!r.ok);
            if(issue)throw Error('physical gate stopped at request '+issue.id);
            const result=await page.evaluate(()=>({ready:!!window.abTurn?.marks.ready,status:document.querySelector('#avereth-action-status')?.textContent}));
            if(result.ready){terminal=true;break;}
            const incomplete=await page.evaluate(i=>SillyTavern.getContext().chat[i]?.extra?.avereth?.extraction?.status==='incomplete',before.length+1);
            if(incomplete) throw Error('ST classified the narrator revision as incomplete');
            if(/Remoteabschluss unbekannt|Speichern fehlgeschlagen/.test(result.status||''))throw Error('host gate: '+result.status);
            await delay(500);
        }
        if(!terminal)throw Error('turn did not reach verified read-back and UI readiness');
        const after=await driver.chat(),reply=after.at(-1);
        const record=reply.extra?.avereth;
        assert(after.length===before.length+2 && !reply.is_user && record?.extraction?.status==='applied');
        assert(await driver.verifySaved(after,{complete:true}));
        const measured=await page.evaluate(()=>{const s=window.abTurn;s.stop();return {marks:s.marks,firstSentence:s.firstSentence,finalRendered:s.finalRendered,world:s.world};});
        assert(measured.marks.ready && measured.marks.confirmedSave);
        gate(null,'closed');
        await page.evaluate(()=>SillyTavern.getContext().reloadCurrentChat());
        const reloaded=await driver.chat(),fold=foldChat(reloaded);
        assert.deepEqual(fold.errors,[]);assert.deepEqual(fold.state,foldChat(after).state);
        assert.equal(hash(reloaded.map(m=>m.extra?.avereth?.events||[])),hash(after.map(m=>m.extra?.avereth?.events||[])));
        assert(await driver.verifySaved(reloaded,{complete:true}));
        const physical=readRecords().filter(r=>r.stage==='trade'&&r.turn===n&&r.arm===arm);
        const end=physical.filter(r=>r.kind==='end');assert.equal(end.length,physical.filter(r=>r.kind==='start').length);
        const durable={world:fold.state,player:after.at(-2),reply,eventsHash:hash(reloaded.map(m=>m.extra?.avereth?.events||[]))};
        save('turn-'+arm+n+'.json',durable);
        fs.copyFileSync(path.join(inst.user,'chats',card,name+'.jsonl'),path.join(root,name+'.jsonl'));
        const item={arm,n,scenario,startWorld:hash(state),startEvents:hash(before.map(m=>m.extra?.avereth?.events||[])),action:after.at(-2).mes,worldHash:hash(fold.state),readback:true,requests:end.map(x=>x.id),measured};
        turns.push(item);save('turns.json',turns);
        console.log('saved',arm,n,scenario,end.length,Math.round(measured.marks.ready-measured.marks.click));
    }
    save('main-complete.json',{turns:turns.length});
}
