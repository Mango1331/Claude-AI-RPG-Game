import { validEncounterLevels } from './v4/domain.js';
import { classDefErrors, classOffer } from './v4/class_growth.js';
// Validation layer.
//  * validateState: invariants the engine guarantees after every fold (used by tests, #audit tooling and the ST
//    extension's integrity check). A violation means a bug or a corrupted log — never something the LLM may "fix".
//  * validateSchema: a small JSON-Schema subset validator (type, enum, const, required, properties,
//    additionalProperties, items, minItems, minimum, maximum, minLength, pattern, anyOf, oneOf, $ref to #/$defs)
//    so the content pack, events and reports are checked against schemas/ without any dependency.
import { deriveCharacter } from './derived.js';
import { FUNCTIONAL } from './knowledge.js';
import { skillOf } from './content.js';
import { promotionPp } from './skills.js';
import { passiveSlots } from './passives.js';

const AWARENESS = new Set(['unaware', 'suspicious', 'aware']);
// V3: offered|active|completed|failed; Runtime V4 adds the listing states of a Guild board and giving up
const QUEST_STATUS = new Set(['offered', 'active', 'completed', 'failed', 'listed', 'taken_by_other', 'withdrawn', 'abandoned', 'expired']);

function isInt(x) {
    return Number.isInteger(x);
}

export function validateState(state, content) {
    const p = [];
    const pc = state.entities.pc;
    if (!state.meta.started) return p;
    if (!pc || !pc.sheet) return ['PC entity or sheet missing'];
    for (const [id, e] of Object.entries(state.entities)) {
        if (e.id !== id) p.push(`entity key ${id} != id ${e.id}`);
        if (!e.sheet) continue;
        const s = e.sheet;
        const where = id === 'pc' ? 'PC' : id;
        if (!isInt(s.level) || s.level < 1) p.push(`${where}: invalid Level ${s.level}`);
        for (const k of content.rules.stats) if (!isInt(s.stats[k]) || s.stats[k] < 1) p.push(`${where}: invalid ${k} ${s.stats[k]}`);
        if (s.evolution) {
            p.push(...classDefErrors(s.evolution, content).map((x) => `${where}: ${x}`));
            if (s.level < content.rules.class_growth.level || !(s.class_history || []).some((h) => h.id === s.evolution.id && h.rank === 'E' && h.quality === s.evolution.quality)) p.push(`${where}: class history/level does not support its active class`);
        }
        if (new Set((s.class_history || []).map((h) => h.rank)).size !== (s.class_history || []).length) p.push(`${where}: duplicate class rank in history`);
        const dv = deriveCharacter(s, content);
        for (const [r, max] of [['hp', dv.maxHp], ['mp', dv.maxMp], ['sta', dv.maxSta]]) {
            if (!isInt(s[r]) || s[r] < 0 || s[r] > max) p.push(`${where}: ${r.toUpperCase()} ${s[r]} outside 0..${max}`);
        }
        if (!isInt(s.xp) || s.xp < 0 || s.xp >= s.level * content.rules.progression.xp_to_next_per_level) p.push(`${where}: XP ${s.xp} invalid for Level ${s.level}`);
        if (!isInt(s.free_points) || s.free_points < 0) p.push(`${where}: free points ${s.free_points}`);
        if (!isInt(s.coin_cp) || s.coin_cp < 0) p.push(`${where}: coin ${s.coin_cp}`);
        for (const [item, q] of Object.entries(s.inventory)) if (!isInt(q) || q <= 0) p.push(`${where}: inventory ${item} ×${q}`);
        for (const [sid, v] of Object.entries(s.skills)) {
            const sk = skillOf(content, sid, state); // Patch 9B-1: the campaign's own Skills too
            if (!sk) p.push(`${where}: unknown skill ${sid}`);
            if (!isInt(v.prof) || v.prof < 1 || v.prof > 5) p.push(`${where}: skill ${sid} proficiency ${v.prof}`);
            // Patch 9B-1: PP below the next promotion, none at P5
            if (sk && v.pp !== undefined && (!isInt(v.pp) || v.pp < 0 || (v.prof >= 5 ? v.pp !== 0 : v.pp >= promotionPp(content, sk, state)))) p.push(`${where}: skill ${sid} PP ${v.pp} at P${v.prof}`);
        }
        // Patch 9B-2: a Passive he has is one of this campaign's, as it was defined
        for (const [pid, had] of Object.entries(s.passives || {})) {
            const def = state.passive_defs?.[pid];
            if (!def) p.push(`${where}: unknown passive ${pid}`);
            else if (JSON.stringify([had.scope, had.condition, had.effects]) !== JSON.stringify([def.scope, def.condition, def.effects])) p.push(`${where}: passive ${pid} differs from its definition`);
            // Patch 9C-2c: one he gave up is not his again
            if ((s.passive_history || []).some((h) => h.id === pid)) p.push(`${where}: passive ${pid} held after it was given up`);
        }
        // Patch 9C-2c: four Passives at most, of every quality together
        if (Object.keys(s.passives || {}).length > passiveSlots(content)) p.push(`${where}: ${Object.keys(s.passives).length} Passives, more than the ${passiveSlots(content)} slots`);
        for (const [slot, ref] of Object.entries(s.equipment)) {
            if (typeof ref === 'string' && !content.items.has(ref)) p.push(`${where}: unknown item ${ref} in ${slot}`);
            if (typeof ref === 'object' && (!ref || !ref.name)) p.push(`${where}: invalid inline item in ${slot}`);
        }
        if (e.status === 'dead' && s.hp !== 0) p.push(`${where}: dead with HP ${s.hp}`);
    }
    // Patch 9C-1: his learning goals (src/v4/growth.js): at most max_active open, Learning Progress whole and up to its
    // need, ready exactly at the need; the Skill of a closed goal is his
    const goals = Object.values(state.growth?.goals || {});
    if (goals.length > (content.rules.growth?.max_active ?? 3)) p.push(`${goals.length} learning goals open`);
    for (const g of goals) {
        if (!isInt(g.lp) || g.lp < 0 || g.lp > g.need) p.push(`learning goal ${g.id}: LP ${g.lp}/${g.need}`);
        if ((g.status === 'ready') !== (g.lp >= g.need)) p.push(`learning goal ${g.id}: ${g.status} at ${g.lp}/${g.need}`);
    }
    // 9C completion: or it evolved into another of his
    for (const d of state.growth?.done || []) if (!d.evidence && !pc.sheet.skills[d.skill] && !(pc.sheet.skill_history || []).some((h) => h.id === d.skill)) p.push(`the Skill ${d.skill} of learning goal ${d.id} is not his`);
    // Patch 9C-2c: every open Passive offer rests on its evidence, offered; an accepted evidence's Passive was his
    // 9C completion: and every open Skill offer, the same way; an accepted Skill evidence's Skill is defined
    for (const d of (state.decisions || []).filter((x) => x.kind === 'passive' || x.kind === 'skill')) {
        const ev = state.growth?.evidence?.[d.evidence];
        if (!ev || ev.status !== 'offered' || ev.decision !== d.id) p.push(`${d.kind} offer ${d.id}: its evidence ${d.evidence} is not offered`);
    }
    const SKILL_KINDS = new Set(['evolution', 'breakthrough', 'combination']);
    for (const ev of Object.values(state.growth?.evidence || {}).filter((x) => x.status === 'accepted')) {
        if (SKILL_KINDS.has(ev.kind) ? !state.skill_defs?.[ev.skill_booked] : !state.passive_defs?.[ev.passive]) p.push(`evidence ${ev.key}: its ${SKILL_KINDS.has(ev.kind) ? `Skill ${ev.skill_booked}` : `Passive ${ev.passive}`} is not defined`);
    }
    // 9C completion: a Skill he evolved from is his no longer, and what it became is a defined Skill
    for (const h of pc?.sheet?.skill_history || []) {
        if (pc.sheet.skills[h.id]) p.push(`skill ${h.id} held after it evolved`);
        if (!state.skill_defs?.[h.evolved_to]) p.push(`skill ${h.id} evolved into an undefined ${h.evolved_to}`);
    }
    const classes = (state.decisions || []).filter((d) => d.kind === 'class');
    if (classes.length > 1 || (classes.length && pc.sheet.evolution)) p.push('invalid open class choice');
    for (const d of classes) {
        if (pc.sheet.level < content.rules.class_growth.level || d.rank !== 'E' || !Array.isArray(d.options) || !d.options.length) p.push('class choice without a supported rank claim');
        const opts = d.options || [];
        if (new Set(opts.map((o) => o.name.toLowerCase())).size !== opts.length) p.push('class choice has repeated names');
        if (new Set(opts.map((o) => o.id)).size !== opts.length) p.push('class choice has repeated option ids');
        for (const o of opts) p.push(...classDefErrors(o, content));
    }
    for (const [k, n] of Object.entries(state.career?.stats || {})) if (!Number.isInteger(n) || n < 0) p.push(`career ${k}: invalid count`);
    const sc = state.scene;
    // Runtime V4 keeps its place nodes in state.places; wilderness outside a settlement lies in its realm (live 30.09.2026)
    if (sc.location && !state.entities[sc.location] && !content.locations.has(sc.location) && !state.places?.[sc.location]) p.push(`unknown scene location ${sc.location}`);
    if (!sc.present.includes('pc')) p.push('PC not present in own scene');
    for (const id of sc.present) if (!state.entities[id]) p.push(`present entity ${id} does not exist`);
    for (const id of Object.keys(sc.positions)) if (!sc.present.includes(id)) p.push(`position for absent ${id}`);
    for (const [id, a] of Object.entries(sc.awareness)) if (!AWARENESS.has(a)) p.push(`awareness ${id}=${a}`);
    for (const id of sc.concealed) if (!state.entities[id]) p.push(`concealed entity ${id} does not exist`);
    // phase marker: exactly one semantic phase (Core #23)
    if ((state.mode === 'combat') !== !!state.encounter) p.push(`mode ${state.mode} inconsistent with encounter ${state.encounter ? 'present' : 'absent'}`);
    const enc = state.encounter;
    if (enc) {
        let pending = 0;
        for (const [id, c] of Object.entries(enc.combatants)) {
            if (!state.entities[id]) p.push(`combatant ${id} has no entity`);
            if (c.current.hp < 0 || c.current.hp > c.fixed.max_hp) p.push(`combatant ${id} HP ${c.current.hp}/${c.fixed.max_hp}`);
            if (c.side === 'hostile' && typeof c.fixed.defeat_xp !== 'number') p.push(`hostile ${id} without locked DefeatXP`);
            // a surrender gives no XP; one killed after it gives its XP once (src/combat.js onDefeat)
            if (enc.defeated.includes(id) && c.side === 'hostile' && (!c.current.surrendered || c.current.xp_counted)) pending += c.fixed.defeat_xp;
        }
        if (pending !== enc.pending_xp) p.push(`Pending XP ${enc.pending_xp} != sum of defeated DefeatXP ${pending}`);
        for (const id of enc.order) if (!enc.combatants[id]) p.push(`turn order contains unknown ${id}`);
        if (enc.current && !enc.order.includes(enc.current)) p.push(`current actor ${enc.current} not in turn order`);
        const pcC = enc.combatants.pc;
        if (pcC && (pcC.current.hp !== pc.sheet.hp || pcC.current.sta !== pc.sheet.sta || pcC.current.mp !== pc.sheet.mp)) p.push('PC sheet resources differ from encounter snapshot');
    }
    // world truth: one current value per functional predicate; a fact about an entity is about one that exists (live run
    // 27.09. 02:30: a fact about mon.cellar_gnawer_pups, a creature the report could not create); a place of the world
    // (state.places, as for the scene above) is one too (4.3.0-c.6.6.53, live 23.10.2026: facts about the entrance of
    // the Mossback Warrens were read as two integrity problems)
    const seen = new Map();
    for (const f of Object.values(state.facts)) {
        if (f.until && f.since && f.until.minute < f.since.minute) p.push(`fact ${f.id} ends before it starts`);
        if (/^(?:npc|mon|loc)\.\w+$/.test(f.s) && !state.entities[f.s] && !content.locations.has(f.s) && !state.places?.[f.s]) p.push(`fact ${f.id} about missing entity ${f.s}`);
        if (f.until || !FUNCTIONAL.has(f.p)) continue;
        const k = `${f.s}|${f.p}`;
        if (seen.has(k)) p.push(`two current values for ${k}: ${seen.get(k)} / ${f.id}`);
        seen.set(k, f.id);
    }
    for (const [who, rows] of Object.entries(state.knowledge)) {
        for (const about of Object.keys(rows)) if (!state.facts[about] && !state.claims[about]) p.push(`${who} knows missing proposition ${about}`);
    }
    for (const r of Object.values(state.relations)) if (r.value < -100 || r.value > 100) p.push(`relation ${r.id} value ${r.value}`);
    for (const q of Object.values(state.quests)) if (!QUEST_STATUS.has(q.status)) p.push(`quest ${q.id} status ${q.status}`);
    // Runtime V4 domains: the scene is a place node; every object has a holder that exists; what Alaric holds is exactly
    // what his sheet's inventory mirrors; a listed contract is on a board
    if (state.meta?.runtime === 'v4') {
        if (!state.places?.[state.scene.at]) p.push(`scene at unknown place ${state.scene.at}`);
        for (const o of Object.values(state.objects || {})) {
            if (o.holder?.entity && !state.entities[o.holder.entity]) p.push(`object ${o.id} held by missing ${o.holder.entity}`);
            if (o.holder?.loc && !state.places[o.holder.loc]) p.push(`object ${o.id} at missing place ${o.holder.loc}`);
            const inv = pc?.sheet?.inventory?.[o.id];
            if (o.holder?.entity === 'pc' && inv !== (o.qty ?? 1)) p.push(`object ${o.id} held by Alaric but inventory shows ${inv}`);
            if (o.holder?.entity !== 'pc' && inv !== undefined) p.push(`object ${o.id} in Alaric's inventory but not held by him`);
        }
        const onBoard = new Set(Object.values(state.guild?.boards || {}).flatMap((b) => b.listings || []));
        for (const q of Object.values(state.quests)) if (q.status === 'listed' && !onBoard.has(q.id)) p.push(`listed ${q.id} is on no board`);
        for (const o of Object.values(state.offers || {})) if (!['open', 'accepted', 'declined', 'expired', 'repriced'].includes(o.status)) p.push(`offer ${o.id} status ${o.status}`);
        // Build .142: the binding terms of a bid, or of each offer line, are one of the known values when present
        const TERMS = ['firm', 'conditional', 'unverified'];
        for (const o of Object.values(state.offers || {})) {
            if (o.terms !== undefined && !TERMS.includes(o.terms)) p.push(`offer ${o.id} terms ${o.terms}`);
            for (const l of o.lines || []) if (l.terms !== undefined && !TERMS.includes(l.terms)) p.push(`offer ${o.id} line ${l.id} terms ${l.terms}`);
            if (o.bid && (o.terms ?? 'firm') === 'firm' && !Number.isInteger(o.price_cp)) p.push(`binding bid ${o.id} without a price`);
        }
        for (const d of state.decisions || []) if (d.kind === 'payment' && d.state === 'needs_confirmation' && !(Number.isInteger(d.amount_cp) && d.amount_cp > 0 && d.seller)) p.push(`payment proposal ${d.id} without payee or amount`);
        for (const place of Object.values(state.places)) if (place.encounter_levels && !validEncounterLevels(content, place.encounter_levels)) p.push(`invalid F area levels at ${place.id}`);
        for (const place of Object.values(state.places)) if (place.population) {
            const pop = place.population;
            if (!content.anchors.has(pop.anchor) || typeof pop.species !== 'string' || !pop.species.trim()
                || !Array.isArray(pop.levels) || pop.levels.length !== 2 || !pop.levels.every(Number.isInteger)
                || pop.levels[0] < 1 || pop.levels[1] > 14 || pop.levels[0] > pop.levels[1]) p.push(`invalid F population at ${place.id}`);
        }
        for (const q of Object.values(state.quests)) if (q.hunt && !state.places[q.hunt.at]?.population) p.push(`quest ${q.id} has no hunting population`);
        for (const q of Object.values(state.quests)) if (q.count_rule != null && (q.kind !== 'guild_contract'
            || !['killed', 'killed_or_fled'].includes(q.count_rule) || q.objectives?.length !== 1
            || q.objectives[0].verb !== 'DEFEAT' || !isInt(q.objectives[0].qty) || q.objectives[0].qty < 1)) p.push(`quest ${q.id} has invalid fixed count rule`);
    }
    if (!isInt(state.rng.n) || state.rng.n < 0) p.push(`rng counter ${state.rng.n}`);
    return p;
}

// ---------------------------------------------------------------------------------------------- JSON Schema subset
function typeOf(v) {
    if (v === null) return 'null';
    if (Array.isArray(v)) return 'array';
    if (Number.isInteger(v)) return 'integer';
    return typeof v;
}

function typeMatches(v, t) {
    const actual = typeOf(v);
    if (t === 'number') return actual === 'number' || actual === 'integer';
    return actual === t;
}

export function validateSchema(value, schema, root = schema, path = '$', errors = []) {
    if (schema === true || schema === undefined) return errors;
    if (schema === false) { errors.push(`${path}: not allowed`); return errors; }
    if (schema.$ref) {
        const name = schema.$ref.replace(/^#\/\$defs\//, '');
        if (!root.$defs || !root.$defs[name]) { errors.push(`${path}: unresolved $ref ${schema.$ref}`); return errors; }
        return validateSchema(value, root.$defs[name], root, path, errors);
    }
    if (schema.type) {
        const types = Array.isArray(schema.type) ? schema.type : [schema.type];
        if (!types.some((t) => typeMatches(value, t))) { errors.push(`${path}: expected ${types.join('|')}, got ${typeOf(value)}`); return errors; }
    }
    if (schema.const !== undefined && value !== schema.const) errors.push(`${path}: must be ${JSON.stringify(schema.const)}`);
    if (schema.enum && !schema.enum.includes(value)) errors.push(`${path}: ${JSON.stringify(value)} not in ${JSON.stringify(schema.enum)}`);
    if (typeof value === 'number') {
        if (schema.minimum !== undefined && value < schema.minimum) errors.push(`${path}: ${value} < ${schema.minimum}`);
        if (schema.maximum !== undefined && value > schema.maximum) errors.push(`${path}: ${value} > ${schema.maximum}`);
    }
    if (typeof value === 'string') {
        if (schema.minLength !== undefined && value.length < schema.minLength) errors.push(`${path}: shorter than ${schema.minLength}`);
        if (schema.pattern && !new RegExp(schema.pattern).test(value)) errors.push(`${path}: "${value}" does not match ${schema.pattern}`);
    }
    if (Array.isArray(value)) {
        if (schema.minItems !== undefined && value.length < schema.minItems) errors.push(`${path}: fewer than ${schema.minItems} items`);
        if (schema.items) value.forEach((v, i) => validateSchema(v, schema.items, root, `${path}[${i}]`, errors));
    }
    if (value && typeof value === 'object' && !Array.isArray(value)) {
        for (const k of schema.required || []) if (!(k in value)) errors.push(`${path}: missing required "${k}"`);
        const props = schema.properties || {};
        for (const [k, v] of Object.entries(value)) {
            if (props[k] !== undefined) validateSchema(v, props[k], root, `${path}.${k}`, errors);
            else if (schema.patternProperties && Object.keys(schema.patternProperties).some((re) => new RegExp(re).test(k))) {
                const re = Object.keys(schema.patternProperties).find((r) => new RegExp(r).test(k));
                validateSchema(v, schema.patternProperties[re], root, `${path}.${k}`, errors);
            } else if (schema.additionalProperties === false) errors.push(`${path}: unexpected property "${k}"`);
            else if (typeof schema.additionalProperties === 'object') validateSchema(v, schema.additionalProperties, root, `${path}.${k}`, errors);
        }
    }
    if (schema.anyOf && !schema.anyOf.some((s) => validateSchema(value, s, root, path, []).length === 0)) errors.push(`${path}: matches none of anyOf`);
    if (schema.oneOf && schema.oneOf.filter((s) => validateSchema(value, s, root, path, []).length === 0).length !== 1) errors.push(`${path}: must match exactly one of oneOf`);
    return errors;
}
