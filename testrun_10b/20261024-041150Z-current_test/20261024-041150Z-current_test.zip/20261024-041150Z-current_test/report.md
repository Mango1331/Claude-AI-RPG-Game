# Avereth Live-Test 20261024-041150Z-current_test

## Kurzfassung

- **Ergebnis:** abgebrochen: unerwarteter UI-Zustand — turn 21: no reply after the message
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_duration (nicht erreicht)
- **Charakter:** mage (mage.arcane_bolt, mage.flame_lance) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world long playtest — a real adventurer's life“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: independent cautious adventurer: explore, talk to people, assess risks, spend rewards on practical needs
- **Züge:** 21 · **Dauer:** 22:15 min · **LLM-Aufrufe der Engine/des Erzählers:** 64
- **Auffälligkeiten:** 19
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.57 |
| Git | 3181c8112ec6 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 72.1 s |
| Browser | chrome 155.0.8059.85 |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261024-041150Z-current_test“, Seed 1747035255 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_duration | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | Mage. | Engine (Menü/Rückfrage) | creation_complete | Choose Mage as base class. | public roadside verge outside Ashbridge | 80/60 | 2.3 s |
| 2 | Arcane Bolt and Flame Lance. | Engine (Menü/Rückfrage) | creation_complete | Pick two offensive Mage skills to finish creation. | public roadside verge outside Ashbridge | 80/72 | 2.1 s |
| 3 | I walk along the road toward Ashbridge's gates, looking for the Adventurers' Guild once inside. | Erzähler | open_run_duration | Enter the city and find the Guild. | Adventurers' Guild hall, Ashbridge | 80/72 | 53.1 s |
| 4 | "Both, if I can. I'd like to register first, then see what work suits a novice mage." | Erzähler | open_run_duration | Register with the Guild and ask about novice-suitable contracts. | Adventurers' Guild hall, Ashbridge | 80/72 | 56.0 s |
| 5 | "Alaric Red." I set two silver on the desk. "Register me as a Novice, please." | Erzähler | open_run_duration | Pay the two-silver fee and register with the Guild under my name. | Adventurers' Guild hall, Ashbridge | 80/72 | 26.6 s |
| 6 | "I'll take the tonic delivery for Healer Ossian. Where do I pick up the crate?" | Erzähler | open_run_duration | Accept the tonic delivery contract and ask where to collect it. | Adventurers' Guild hall, Ashbridge | 80/72 | 78.1 s |
| 7 | I take the crate with both hands. "Thank you. I'll get it to Brenna at the quarry camp." I head out and take the long road past the cedar st… | Erzähler | open_run_duration | Accept the crate from Ossian and set out on the delivery route. | quarry camp | 80/72 | 49.0 s |
| 8 | "Delivered whole, and I'll pass your message to Ossian." I pocket the signed chit. "Anything dangerous on the road back I should know about?… | Erzähler | open_run_duration | Turn in the delivery: get Brenna's news, then return to the Guild with the signed chit for… | Adventurers' Guild hall, Ashbridge | 80/72 | 48.3 s |
| 9 | I set the signed chit on the counter. "Tonic delivered whole to Brenna — she says the willow bark next time, the last batch was short. I'll … | Erzähler | open_run_duration | Turn in the delivery contract and collect the reward. | Adventurers' Guild hall, Ashbridge | 80/72 | 19.2 s |
| 10 | "Understood — I'll run the crate back to the camp." I pick it up and start the walk east along the quarry road again. | Erzähler | open_run_duration | Carry the empty crate back to Brenna so the delivery can count as handed over. | quarry camp | 80/72 | 36.4 s |
| 11 | "That's the crate handed over — that closes the delivery, I take it." I accept a cup of the tea. "Anything else you need run into Ashbridge … | Erzähler | open_run_duration | Confirm the crate handover completes the delivery, then ask Brenna about further work befo… | quarry camp | 80/72 | 25.1 s |
| 12 | I pick the crate back up and thank Brenna for the tea. "Safe road and good luck with the fevers." I head back down the quarry road toward As… | Erzähler | open_run_duration | Carry Ossian's crate back to town so the clerk can close the delivery and pay the 4 silver… | Ashbridge | 80/72 | 26.3 s |
| 13 | I nod to the guard and hurry through the gate toward Ossian's shop, three doors past the fountain. | Erzähler | open_run_duration | Reach Ossian's shop before the gate closes and hand over the crate and chit for payment. | Ossian's shop | 80/72 | 28.6 s |
| 14 | I set the crate on the counter and hold out the signed chit with it. "Brenna's end is done — vials counted, chit signed. She asks for willow… | Erzähler | open_run_duration | Hand over the crate and chit to Ossian's clerk so the delivery closes and I get paid. | Ossian's shop | 80/72 | 113.3 s |
| 15 | "Off to the Guild hall before you bell the close — thank you." I hurry out and make for the Guild hall to turn in the contract. | Erzähler | open_run_duration | Reach the Guild hall before closing and turn in the delivery contract for payment. | Adventurers' Guild hall, Ashbridge | 80/72 | 77.2 s |
| 16 | I take the crate and the chit back to Ossian's shop. "Sorry — I'm to leave the crate on your counter, properly handed over." I set it down o… | Erzähler | open_run_duration | Return the crate to Ossian's assistant and leave it on the counter so the delivery properl… | Ossian's shop | 80/72 | 132.9 s |
| 17 | I hurry back to the Guild hall before the clerk locks up. "The crate's properly handed over at Ossian's now — she took it in both hands. Her… | Erzähler | open_run_duration | Turn in the delivery contract at the Guild hall and collect the 40 coppers. | Adventurers' Guild hall, Ashbridge | 80/72 | 30.7 s |
| 18 | I go straight back to Ossian's. "Your desk wants the goods to stay with you — I can't carry it back again." I put the crate in her hands on … | Erzähler | open_run_duration | Hand the crate over so it stays handed over, then turn in the contract for the 40 coppers. | Adventurers' Guild hall, Ashbridge | 80/72 | 26.6 s |
| 19 | I set the crate down on the Guild hall floor. "You said I could set it down somewhere — it's set down, and my hands are empty. Here's the ch… | Erzähler | open_run_duration | Break the delivery deadlock by leaving the crate at the Guild hall as the clerk suggested,… | Adventurers' Guild hall, Ashbridge | 80/72 | 75.1 s |
| 20 | I curl up on the bench by the night lamp and sleep until the desk opens. At first light, I set the chit on the counter — hands empty, the cr… | Erzähler | open_run_duration | Wait out the night on the Guild hall bench, then turn in the chit at opening with the crat… | Adventurers' Guild hall, Ashbridge | 80/72 | 68.8 s |
| 21 | "Forty coppers, closed at last — thank you for bending the rolls." I pocket the coins. "What else is on the board this morning that suits a … | – | open_run_duration | Collect the pay and ask the clerk for a new novice-suitable contract from the board. | Adventurers' Guild hall, Ashbridge | 80/72 | 78.8 s **no reply after the message** |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zum Start (notiert vor Zug 1): Character creation is a two-step System prompt; class choice first, then two skills.
- zu Zug 1 (notiert vor Zug 2): Skill pool shows concrete damage formulas and MP costs; Blink is tempting but raw offense seems better for a solo F-rank start.
- zu Zug 2 (notiert vor Zug 3): Creation complete: Mage with Arcane Bolt and Flame Lance, 5 silver, full HP/MP. No oddities yet.
- zu Zug 4 (notiert vor Zug 5): Novice board shows five contracts; the tonic delivery (4s) is the safest novice option, the warren clear (1g2s) the most lucrative. Registration costs 2s, leaving 3s.
- zu Zug 5 (notiert vor Zug 6): Registration and F-rank stone both worked cleanly; coin went 50→30 cp, matching the 2s fee. HUD shows 3 silver as expected.
- zu Zug 6 (notiert vor Zug 7): Minor inconsistency: HUD still lists location as 'Adventurers' Guild hall' and 'Present: Clerk' even though I walked to Chandler's Row and Ossian's shop. Also noticed a 'WORLD NOT RECORDED' extractor error line appeared before the reply; state seemed fine otherwise.
- zu Zug 7 (notiert vor Zug 8): Quest panel says READY FOR TURN-IN with the chit signed, but HUD still lists it as active and the crate is still in my inventory — minor lag or handoff issue. Also HUD now says 'Duskreach — quarry camp' though the city was Ashbridge; possibly the region name.
- zu Zug 8 (notiert vor Zug 9): Quest panel still shows reward 40 cp while the board earlier listed 4 silver — watch what the clerk actually pays. Crate still in inventory despite delivery; also HUD said 'Present: nobody' though the clerk is at her ledger.
- zu Zug 9 (notiert vor Zug 10): Turn-in was blocked because the crate (now empty vials) must also be handed over — a stricter delivery rule than the 'READY FOR TURN-IN' panel suggested; also reward quoted as 'four silver bits' vs board's 4s vs quest panel's 40 cp.
- zu Zug 10 (notiert vor Zug 11): Turn-in was blocked twice on the empty crate rule; hopefully handing it to Brenna directly now closes the quest so the clerk can pay the 4 silver.
- zu Zug 11 (notiert vor Zug 12): Quest reward shows 40 cp on the panel while the clerk quoted 4 silver bits — worth watching at pay-out. Two-hour walk means arrival near dusk; crate still in inventory as expected.
- zu Zug 12 (notiert vor Zug 13): Note the reward discrepancy again: HUD quest panel says 40 cp while the clerk earlier quoted 4 silver — watch the actual pay-out.
- zu Zug 13 (notiert vor Zug 14): Reward discrepancy persists on the HUD: quest panel still says 40 cp while the clerk earlier quoted 4 silver — pay-out will settle it.
- zu Zug 14 (notiert vor Zug 15): Clerk confirmed payout is at the Guild hall, not the shop — the reward discrepancy (40 cp on HUD vs 4 silver quoted) will be settled at pay-out. It is 21:04, night; Guild hall may be closing.
- zu Zug 15 (notiert vor Zug 16): The Guild clerk confirmed the pay is 40 coppers, not 4 silver as earlier quoted — the reward discrepancy is resolved; the earlier turn-in failed only because I carried the crate out of the shop.
- zu Zug 16 (notiert vor Zug 17): The quest finally flipped to READY FOR TURN-IN once the crate was handed over with both hands on the counter — the empty-crate rule cost three extra trips but resolved consistently. Still carrying crate and chit in HUD inventory; should clear at payout.
- zu Zug 17 (notiert vor Zug 18): Contradiction: my previous turn had the assistant take the crate in both hands and the quest flipped READY FOR TURN-IN, yet this turn she pressed it back into my hands as if that never happened — the engine appears to have rolled back the handover state.
- zu Zug 18 (notiert vor Zug 19): The delivery is stuck in a genuine engine loop: the assistant refuses the crate while the chit is unclosed, the clerk refuses turn-in while I carry the crate, and my combined walk-out-and-return action was rejected as 'already here'. Third cycle now; if this attempt fails I'll wait for morning as both NPCs advised.
- zu Zug 19 (notiert vor Zug 20): The crate no longer appears under Carried on the HUD after I set it down, though the quest stays active — the loop may finally have broken. The desk simply closed at ninth bell with nobody there, so the last refusal was only the chit having no recipient.
- zu Zug 20 (notiert vor Zug 21): Delivery finally paid out: 30→70 copper, displayed as 7 Silver on the HUD, quest cleared. Oddity: the HUD still lists 'signed delivery chit' under Carried even though the clerk took it and pressed it into her ledger.

## Kämpfe

Kein Kampf.

## Quests

- **Carry Tonic Vials to the Quarry Camp** — active (Zug 6) → completed (Zug 20), READY
  - Aufgabe: Deliver a crate of fever tonic vials to the old quarry camp before the fever there spreads further, as the quarry road is washed out and the crate must go by foot.
  - Endzustand: The crate of fever tonic vials is delivered intact to the quarry camp's healer's tent.

## Auffälligkeiten

- Zug 21 (Runner/UI): no reply after the message
- Zug 6, Nachricht 12 (extraction_failed): the extractor failed: $.deltas[1]: unknown type "place"
- Zug 6, Nachricht 12 (extraction_repaired): the extractor's first answer needed a repair
- Zug 6, Nachricht 12 (finish): extract ended with finish_reason "length"
- Zug 8, Nachricht 15 (planner_repaired): the planner's first answer needed a repair
- Zug 8, Nachricht 15 (finish): plan ended with finish_reason "length"
- Zug 10, Nachricht 19 (planner_repaired): the planner's first answer needed a repair
- Zug 14, Nachricht 28 (extraction_repaired): the extractor's first answer needed a repair
- Zug 14, Nachricht 28 (finish): extract ended with finish_reason "length"
- Zug 15, Nachricht 30 (extraction_repaired): the extractor's first answer needed a repair
- Zug 15, Nachricht 30 (finish): extract ended with finish_reason "length"
- Zug 20, Nachricht 39 (planner_repaired): the planner's first answer needed a repair
- Zug 20, Nachricht 40 (extraction_repaired): the extractor's first answer needed a repair
- Zug 20, Nachricht 40 (finish): extract ended with finish_reason "length"
- Zug 21, Nachricht 41 (planner_failed): the planner failed: report is not valid JSON
- Zug 21, Nachricht 41 (planner_repaired): the planner's first answer needed a repair
- Zug 21, Nachricht 41 (finish): plan ended with finish_reason "length"
- Zug 21, Nachricht 41 (finish): plan_repair ended with finish_reason "length"
- Hinweis (error): Avereth Engine: planner failed (report is not valid JSON). Regenerate or send the message again; no story turn was generated.
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 8× keine gültige JSON-Entscheidung (Züge 5, 10, 11, 12, 13, 14, 15, 16)
- 7 Aufruf(e) mit finish_reason "length" (Nr. 13 extract, Nr. 18 plan, Nr. 40 extract, Nr. 44 extract, Nr. 61 extract, Nr. 63 plan, Nr. 64 plan)

System-Panels: CLARIFY 0, NOT TAKEN 0, REFUSED 2, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: guild_canon 2, engine_booked 1, pc_inventory 4, quest_delivery 2, engine_owned_fact 2.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 23 | 4 | 3.3 s | 22.7 s | 10466 | 9243 | 117 | – | stop 20, length 3 | 3 |
| narrator | 18 | 0 | 12.2 s | 43.0 s | 11288 | 8600 | 552 | – | stop 18 | 0 |
| extract | 22 | 0 | 9.5 s | 51.5 s | 9299 | 7797 | 456 | – | stop 18, length 4 | 4 |
| board | 1 | 0 | 11.2 s | 11.2 s | 1928 | 1711 | 1210 | – | stop 1 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 22:15 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 72.1 s) | 1:31 min |
| 21 Züge, Spiel (Senden bis HUD nach der Extraktion) | 17:35 min — Median 48.3 s, p90 78.8 s, max 132.9 s |
| 21 Züge, Spieler-Entscheidung | 2:51 min — Median 5.0 s, 8 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 2:40 min / 0:11 min / 6:16 min / 7:25 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 58.4 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 38:54 min, 80 Züge ≈ 77:49 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Provider plan | 21 | 63 | 32.2 s | 3.3 s |
| Provider narrator | 16 | 47 | 94.1 s | 12.2 s |
| Provider narrator | 3 | 2 | 43.0 s | 12.2 s |
| Provider extract | 14 | 40 | 87.2 s | 9.5 s |
| Provider extract | 6 | 13 | 52.8 s | 9.5 s |
| Provider extract | 15 | 44 | 51.5 s | 9.5 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
