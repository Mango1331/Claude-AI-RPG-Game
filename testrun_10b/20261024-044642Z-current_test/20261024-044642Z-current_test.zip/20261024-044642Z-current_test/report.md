# Avereth Live-Test 20261024-044642Z-current_test

## Kurzfassung

- **Ergebnis:** abgebrochen: leere Erzählerantwort in einem Story-Zug (kein Swipe, kein Regenerieren) — turn 61: the narrator's reply has no story text (message 122) — the narrator call ended with finish_reason "length" after 8192 completion tokens (max 8192), 35577 characters of reasoning, 0 of text
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_duration (nicht erreicht)
- **Charakter:** mage (mage.arcane_ward, mage.flame_lance) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world long playtest — a real adventurer's life“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: independent cautious adventurer: explore, talk to people, assess risks, spend rewards on practical needs
- **Züge:** 61 · **Dauer:** 80:18 min · **LLM-Aufrufe der Engine/des Erzählers:** 187
- **Auffälligkeiten:** 33
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.57 |
| Git | 3181c8112ec6 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 16.4 s |
| Browser | chrome 155.0.8059.85 |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261024-044642Z-current_test“, Seed 415873872 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_duration | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | I choose Mage. | Engine (Menü/Rückfrage) | creation_complete | Pick the Mage base class. | public roadside verge outside Alderwatch | 80/60 | 2.4 s |
| 2 | I pick Flame Lance and Arcane Ward. | Engine (Menü/Rückfrage) | creation_complete | Complete character creation by selecting the two starter skills Flame Lance and Arcane War… | public roadside verge outside Alderwatch | 80/72 | 2.2 s |
| 3 | I walk along the road toward Alderwatch's gates, keeping an eye out for other travelers. | Erzähler | open_run_duration | Head into Alderwatch and look around. | Alderwatch | 80/72 | 29.0 s |
| 4 | I nod to the gatewarden and walk into the city, heading toward the market and looking for the Adventurers' Guild. | Erzähler | open_run_duration | Enter Alderwatch and find the Adventurers' Guild. | Adventurers' Guild hall, Alderwatch | 80/72 | 27.7 s |
| 5 | I approach the counter and ask about registering with the guild. | Erzähler | open_run_duration | Register with the Adventurers' Guild. | Adventurers' Guild hall, Alderwatch | 80/72 | 57.6 s |
| 6 | I sign the ledger—name Alaric Red, age nineteen, next of kin left blank—and pay the two silver fee. | Erzähler | open_run_duration | Register with the Adventurers' Guild as a Novice. | Adventurers' Guild hall, Alderwatch | 80/72 | 18.3 s |
| 7 | I walk to the big board and read the low rows for Novice contracts. | Erzähler | open_run_duration | Read the Novice-rank contract board to find an achievable first quest. | Adventurers' Guild hall, Alderwatch | 80/72 | 87.9 s |
| 8 | I take the courier slip for the Warden's Sealed Ledger and bring it to the clerk to accept the contract. | Erzähler | open_run_duration | Accept the low-risk courier contract as my first quest. | Adventurers' Guild hall, Alderwatch | 80/72 | 26.1 s |
| 9 | I sign the docket with the charcoal and take the sealed ledger, then head out the south gate to follow the millstream south toward Chapel Ho… | Erzähler | open_run_duration | Sign for the ledger and set out on the courier route to Chapel Hollow. | Adventurers' Guild hall, Alderwatch | 80/72 | 34.3 s |
| 10 | "I'm instructed to put it in the priory's own hands—no one else's. Walk with me if you like, and they can thank you there." | Erzähler | open_run_duration | Decline to hand over the ledger but keep the encounter peaceful. | Adventurers' Guild hall, Alderwatch | 80/72 | 20.4 s |
| 11 | I keep walking toward the village, ledger in hand. "It stays with me. I'll tell the warden you offered a hand." | Erzähler | open_run_duration | Refuse again politely and keep moving toward the priory, staying alert. | Chapel Hollow priory | 80/72 | 21.7 s |
| 12 | I follow the brother inside to the warden and hand over the sealed ledger. | Erzähler | open_run_duration | Deliver the ledger to Warden Ambrose and complete the courier contract. | Warden Ambrose's cell | 80/72 | 98.4 s |
| 13 | I sit and take a sip of the well water. "Quiet enough, thank you—one chatty traveler on the road, nothing more. Is there anything you'd need… | Erzähler | open_run_duration | Complete the delivery conversation and ask about return work before turning in the contrac… | Warden Ambrose's cell | 80/72 | 101.3 s |
| 14 | I take the courtesy note. "East road was quiet, Warden—one traveler with a staff, no carts, no trouble. I'll take that bread, though, and be… | Erzähler | open_run_duration | Accept the note, share road news, and prepare to head back to Alderwatch. | Alderwatch | 80/72 | 120.6 s |
| 15 | I hand the courtesy note to the desk clerk. "The warden's ledger was delivered safe—this confirms it. I'm turning in the courier contract." | Erzähler | open_run_duration | Turn in the completed courier contract at the Guildhall and collect the reward. | Alderwatch | 80/72 | 18.5 s |
| 16 | I knock on the inner door. "Anyone here? I've a courier contract to turn in." | Erzähler | open_run_duration | Get the attention of whoever is inside the Guildhall to turn in the courier contract. | Alderwatch | 80/72 | 138.5 s |
| 17 | "Fair enough—first bell tomorrow, then." I step back out of the Guildhall and look for a cheap inn nearby to take a room and a hot meal. | Erzähler | open_run_duration | Accept the wait until morning and secure food and lodging for the night. | the Halfpenny | 80/72 | 178.7 s |
| 18 | "Room for the night, street side, and the stew. I'll pay now." I set the coins on the bar. | Erzähler | open_run_duration | Pay for supper and a room at the Halfpenny and settle in for the night. | Halfpenny room, street side | 80/72 | 39.2 s |
| 19 | I eat the stew, set my staff on the hook, and turn in for the night. | Erzähler | open_run_duration | Sleep at the Halfpenny and be ready for the Guildhall turn-in at first bell. | Halfpenny room, street side | 80/72 | 39.9 s |
| 20 | I leave the key on the sill and head straight to the Guildhall for first bell. | Erzähler | open_run_duration | Get to Maren's desk at first bell and turn in the courier contract. | Adventurers' Guild hall, Alderwatch | 80/72 | 80.8 s |
| 21 | "Delivered safe and sealed, warden's receipt done. Here's the courtesy note—I'm turning it in." I slide the note across the counter. | Erzähler | open_run_duration | Turn in the courier contract to Maren at first bell and collect the reward. | Adventurers' Guild hall, Alderwatch | 80/72 | 57.3 s |
| 22 | "Catacombs sound above my rank for now—what are the closer errands?" I count the coin into my pouch and eye the board. | Erzähler | open_run_duration | Collect the reward and ask Maren about the nearer errands on the board. | Adventurers' Guild hall, Alderwatch | 80/72 | 116.8 s |
| 23 | "The medicine run to Hollow Bridge—I'll take that one. Fever won't wait." | Erzähler | open_run_duration | Accept the medicine delivery contract to Hollow Bridge. | Adventurers' Guild hall, Alderwatch | 80/72 | 27.1 s |
| 24 | I tuck the parcel level under my arm and set out east from the market square toward Hollow Bridge. | Erzähler | open_run_duration | Deliver the medicine to Hollow Bridge without jarring the flask. | Hollow Bridge tollhouse | 80/72 | 20.0 s |
| 25 | I hand Bertho the parcel. "The fever draught is in the flask—two spoons at dawn and dusk—and the dried herbs make a tisane for the sweating.… | Erzähler | open_run_duration | Deliver the medicine into Bertho's hand with Ansel's instructions. | Hollow Bridge tollhouse | 80/72 | 33.1 s |
| 26 | I step inside and accept the bread and well water. "Glad it came in time. How is Senna doing—has the fever broken yet?" | Erzähler | open_run_duration | Rest briefly with bread and water while asking Bertho about his daughter's condition. | Hollow Bridge tollhouse | 80/72 | 77.8 s |
| 27 | I eat a slice with the honey, thank Bertho, and head back on the road toward Alderwatch to turn the contract in at the Guildhall. | Erzähler | open_run_duration | Finish the visit, walk back to Alderwatch, and turn in the medicine contract at the Guildh… | Adventurers' Guild hall, Alderwatch | 80/72 | 93.4 s |
| 28 | I scan the board for the next contract. "What's left for a Novice, Maren—something I can finish before the light goes?" | Erzähler | open_run_duration | Ask Maren about remaining Novice contracts I can complete today. | Adventurers' Guild hall, Alderwatch | 80/72 | 27.5 s |
| 29 | "The dogs, then." I sign for the feral dog cull at the tannery rows. | Erzähler | open_run_duration | Accept the feral dog cull contract, doable tonight inside the walls. | Adventurers' Guild hall, Alderwatch | 80/72 | 21.3 s |
| 30 | I head to the tannery rows and look for whoever is minding the curing sheds. | Erzähler | open_run_duration | Scout the tannery rows and get local information on the feral dog pack before dusk. | Tannery Rows | 80/72 | 41.2 s |
| 31 | I follow the dog tracks through the gap in the spoil heaps and look for where the pack is denning. | Erzähler | open_run_duration | Track the feral dog pack to its den behind the curing sheds. | den hollow under the spoil heap | 80/72 | 157.6 s |
| 32 | I back off a few paces for room and cast Flame Lance at the barking dog in the den mouth. | Erzähler | open_run_duration | Start the cull with a ranged spell on the lead dog before it closes. | den hollow under the spoil heap | 80/56 | 18.2 s |
| 33 | I cast Flame Lance at the second dog retreating into the hollow. | Erzähler | open_run_duration | Kill the second feral dog with Flame Lance before it flees. | den hollow under the spoil heap | 80/40 | 143.5 s |
| 34 | I reassure the tanner: "Flame Lance burns clean at that den mouth — nothing near your sheds. That big dog, where does it usually run to?" | Erzähler | open_run_duration | Reassure the tanners about fire risk and ask where the third, big dog goes. | den hollow under the spoil heap | 80/40 | 28.4 s |
| 35 | I ask the tanners to point out the old kilns and the drying frames, then find a spot out of sight nearby to wait for dusk. | Erzähler | open_run_duration | Set up an ambush for the big scarred dog along its dusk route past the kilns. | den hollow under the spoil heap | 80/40 | 173.9 s |
| 36 | I hold my position behind the kiln and cast Flame Lance at the big scarred dog at the drying frame. | Erzähler | open_run_duration | Ambush the big scarred dog with Flame Lance while it pulls at the hide. | den hollow under the spoil heap | 80/24 | 38.0 s |
| 37 | I back away from the kilns low and quiet, and once past the spoil heaps I walk back toward town in the dark to find lodging and turn the con… | Erzähler | open_run_duration | Leave the watching fourth dog alone and return to town to rest and turn in the completed c… | Alderwatch | 80/24 | 48.0 s |
| 38 | I take a room and a bowl of stew at the quiet inn with the kettle-and-bed sign, and ask what the bed and meal cost. | Erzähler | open_run_duration | Get lodging and food at the quiet inn for the night. | Alderwatch | 80/24 | 22.2 s |
| 39 | I take the stew and a bunk. "Both, please — stew and the five-copper bed." | Erzähler | open_run_duration | Pay for stew and a bunk to rest overnight before turning in the contract. | Alderwatch | 80/24 | 19.8 s |
| 40 | I sleep through the night, then head to the Guildhall in the morning to turn in the dog cull contract. | Erzähler | open_run_duration | Rest overnight and turn in the completed contract in the morning. | Adventurers' Guild hall, Alderwatch | 80/72 | 28.3 s |
| 41 | #assign INT 2 WIL 2 VIT 1 | System (Befehl) | open_run_duration | Spend the five level-up stat points, then answer Maren and look for a new contract. | Adventurers' Guild hall, Alderwatch | 80/72 | 2.2 s |
| 42 | "The dogs kept mostly to themselves — four of them came at the kilns at dusk, but that was the lot. What novice contracts do you have today?… | Erzähler | open_run_duration | Answer Maren's question and ask for a new Novice-rank contract. | Adventurers' Guild hall, Alderwatch | 80/72 | 22.5 s |
| 43 | "The medicine run to Hollow Bridge sounds right for me today. I'll take that one." | Engine (Menü/Rückfrage) | open_run_duration | Accept the medicine delivery contract to the Hollow Bridge tollhouse. | Adventurers' Guild hall, Alderwatch | 80/72 | 3.9 s |
| 44 | I take the Carry Medicine to the Hollow Bridge Tollhouse contract, the 30-copper remedy parcel run. | Engine (Menü/Rückfrage) | open_run_duration | Re-book the medicine delivery contract after the System's clarify prompt mixed up the boar… | Adventurers' Guild hall, Alderwatch | 80/72 | 5.6 s |
| 45 | I take the 'Carry Medicine to the Hollow Bridge Tollhouse' contract — the remedy parcel slip on Maren's board. | Erzähler | open_run_duration | Retry booking the medicine run using the exact board title, since the System's clarify opt… | Adventurers' Guild hall, Alderwatch | 80/72 | 177.7 s |
| 46 | "So what's the courier slip that's left on the low row — where's it headed, and what's the pay?" | Erzähler | open_run_duration | Ask Maren about the one remaining courier contract on the board before booking anything. | Adventurers' Guild hall, Alderwatch | 80/72 | 17.9 s |
| 47 | "Maren, I never signed for any ledger — I only took the dog cull yesterday. Check your signature line again; that's not my name on it." | Erzähler | open_run_duration | Challenge Maren's claim that I signed for the courier job, since I never took it. | Adventurers' Guild hall, Alderwatch | 80/72 | 144.4 s |
| 48 | "Maren, look in my pack if you like — there's no ledger in it and never was. Whatever you handed over that counter yesterday, it wasn't to m… | Erzähler | open_run_duration | Flatly deny having the ledger and invite Maren to check my pack to prove it. | Adventurers' Guild hall, Alderwatch | 80/72 | 35.5 s |
| 49 | "At the counter it was only you, Maren. But on the Chapel Hollow road a man came up asking after the warden's business — offered to carry th… | Erzähler | open_run_duration | Tell Maren about the stranger on the Chapel Hollow road who angled for the sealed ledger. | Adventurers' Guild hall, Alderwatch | 80/72 | 207.0 s |
| 50 | "Yes — the scar matches my road man, thin and white through the left eyebrow. And here's the whole of it plain: I never took that packet at … | Erzähler | open_run_duration | Give Maren the full plain answer she demanded: the scar matches, and I never carried the l… | Adventurers' Guild hall, Alderwatch | 80/72 | 37.3 s |
| 51 | "Understood, I'll stay in the city. When will the hall master be in, and can I do anything useful meanwhile — like warning the tollhouse mys… | Erzähler | open_run_duration | Cooperate with Maren and offer to help warn the tollhouse while waiting for the hall maste… | Adventurers' Guild hall, Alderwatch | 80/72 | 144.0 s |
| 52 | "I'll do it." I take the day-book and sit by the window, reading through yesterday's entries. "Let's see who passed this counter while he wa… | Erzähler | open_run_duration | Help Maren by examining the day-book and recalling details of yesterday's evening crowd. | Adventurers' Guild hall, Alderwatch | 80/72 | 50.0 s |
| 53 | "Understood, I'll wait for the hall master." I keep a seat by the window and stay where Maren can find me. | Erzähler | open_run_duration | Wait for the hall master as Maren instructed, ready to give my account. | Adventurers' Guild hall, Alderwatch | 80/72 | 107.4 s |
| 54 | I follow Greve into his room and give my full account: the road man with the scar, the signature I never made, and the day-book entry showin… | Erzähler | open_run_duration | Give the hall master my complete account of the impersonation in his private room. | Greve's room | 80/72 | 123.7 s |
| 55 | I think back over the road meeting. "Two small things. He asked about the warden's couriers before I ever said I was one — so he was watchin… | Erzähler | open_run_duration | Answer Greve's question with the small details that could have let the impostor study me. | Greve's room | 80/72 | 36.1 s |
| 56 | "Thank you, Hall master." I finish my tea and head back to the counter. "Maren — Greve said to leave word where I'm lodging with you. And I … | Erzähler | open_run_duration | Close the interview, return the day-book, leave my lodging word with Maren and ask for a c… | Adventurers' Guild hall, Alderwatch | 80/72 | 33.3 s |
| 57 | "Widow Sarra's on Cooper's Lane — put that down for me. Alaric Red, Mage, lodging with Widow Sarra." Once she's noted it, I head out to Coop… | Erzähler | open_run_duration | Leave my lodging word with Maren and secure a cheap room with hot food at Widow Sarra's. | Widow Sarra's rooms | 80/72 | 69.2 s |
| 58 | I climb the stairs, minding the third step, and look over the back room. "If it's as clean as it looks, I'll take it — here's six copper for… | Erzähler | open_run_duration | Inspect the room and pay Sarra six copper for a night's lodging. | back room upstairs | 80/72 | 105.7 s |
| 59 | "Alaric Red, Mage — same as I gave Maren at the hall." | Erzähler | open_run_duration | Give Sarra my name for her lodger book. | back room upstairs | 80/72 | 135.6 s |
| 60 | I put my pouch on the peg and head back to the Guildhall. "Maren — Greve has me off the roads for now. What work is there inside the walls?" | Erzähler | open_run_duration | Ask Maren for a non-road quest since Greve blocked courier work. | back room upstairs | 80/72 | 216.0 s |
| 61 | I tap the tally cellar slip. "This one. Vermin under a grain store is mage work enough — and it pays best." | **leer** | open_run_duration | Accept the Tally Cellar Vermin quest from Maren. | back room upstairs | 80/72 | 200.7 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zum Start (notiert vor Zug 1): Character creation step 1/2 presented; choosing Mage for INT/WIL.
- zu Zug 1 (notiert vor Zug 2): System shows Max HP 80, MP 72, STA 100 and starter gear (Starter Arcane Staff MATK 10, Light Robes DEF 2/MDEF 3) that will auto-equip once Step 2 completes; stat panel updated correctly to INT 6 / WIL 6 after choosing Mage.
- zu Zug 2 (notiert vor Zug 3): Creation complete: Mage with Flame Lance/Arcane Ward, stats confirmed. Milestone 1 done; starting the open run by entering the city.
- zu Zug 3 (notiert vor Zug 4): Character creation completed cleanly; gear auto-equipped and HUD matches the creation panel.
- zu Zug 4 (notiert vor Zug 5): Guild hall found; HUD confirms not yet registered, 5 silver on hand.
- zu Zug 5 (notiert vor Zug 6): Registration details given by the clerk: 2 silver fee, Novice rank, contract slip-book. HUD still shows Guild Rank — and 5 silver, consistent until payment processes.
- zu Zug 6 (notiert vor Zug 7): Registration completed consistently: HUD now shows Guild Rank Novice, Power Rank F, Guild plate carried, coin dropped 5→3 silver (2s fee). One oddity: the purchase panel printed '-20 copper' and 'COIN: 50 → 30 copper' while the HUD counts in silver (5→3); same value, different units.
- zu Zug 7 (notiert vor Zug 8): Contract board works with clear System panel; noted earlier purchase panel oddly showed copper (50→30 cp) while HUD and narration use silver consistently.
- zu Zug 8 (notiert vor Zug 9): HUD Carried does not list the sealed ledger yet—likely because I haven't signed the docket; will confirm it appears after pickup.
- zu Zug 9 (notiert vor Zug 10): HUD now lists the sealed ledger in Carried; HUD shows location as Guild hall while narration clearly has me on the south road—minor location-tracking oddity.
- zu Zug 10 (notiert vor Zug 11): HUD 'Present' still lists the Clerk in the Guild hall while I'm a mile out on the road; location tracking lags the narration.
- zu Zug 11 (notiert vor Zug 12): Quest reward panel shows 40 cp while all economy so far uses silver—likely the same copper/silver inconsistency noted at the shop. Road stranger disengaged; threat note logged in HUD.
- zu Zug 12 (notiert vor Zug 13): Quest flagged READY FOR TURN-IN but reward not yet paid; still showing 40 cp against a silver economy.
- zu Zug 13 (notiert vor Zug 14): Quest still unpaid and flagged active despite delivery; reward remains 40 cp against a silver economy.
- zu Zug 14 (notiert vor Zug 15): Delivered ledger, got bread and courtesy note, returned to Alderwatch; quest still flagged active with 40 cp reward against a silver economy—reward payout still unconfirmed.
- zu Zug 15 (notiert vor Zug 16): Guildhall desk unattended despite narration earlier showing a clerk; turn-in rejected with 'not at a Guild hall' while I stand in the Guildhall—location-tracking bug again.
- zu Zug 16 (notiert vor Zug 17): Turn-in keeps failing with 'not at a Guild hall' while the HUD places me inside the Guildhall; quest reward still 40 cp against a silver economy. Trying a full turn-in again at first bell with Maren.
- zu Zug 17 (notiert vor Zug 18): No change; turn-in still blocked until first bell tomorrow (Maren).
- zu Zug 18 (notiert vor Zug 19): Coin tracking inconsistent: purchase panel showed '30 → 25 copper' but HUD reads 2 Silver 5 Copper; quest reward still listed as 40 cp against a silver-based economy.
- zu Zug 19 (notiert vor Zug 20): Coin display still inconsistent: purchase panel said 30→25 copper but HUD reads 2 Silver 5 Copper; quest still active with 40 cp reward.
- zu Zug 20 (notiert vor Zug 21): Maren is present at the desk this time; HUD oddly lists 'Present: nobody besides Alaric' while she clearly is, and the 'stranger on the road' threat still shows despite being back in Alderwatch.
- zu Zug 21 (notiert vor Zug 22): Turn-in finally succeeded: +40 copper, coin went 25→65 copper on the panel while HUD reads 6 Silver 5 Copper—still inconsistent currency display. 'Present: 1' now correct with Maren shown; the stale 'stranger on the road' threat persists in the HUD despite being back in town.
- zu Zug 22 (notiert vor Zug 23): Board reward text is confusingly double-denominated ('80 cp (8 Silver)') while HUD coin reads silver—currency display still inconsistent. Courier contract closed properly and quest list now empty.
- zu Zug 23 (notiert vor Zug 24): The courtesy note is still in my inventory after turn-in—minor leftover. HUD now shows 6 Silver 5 Copper while the payout panel said 25→65 copper; currency display still inconsistent.
- zu Zug 25 (notiert vor Zug 26): Quest is flagged READY FOR TURN-IN but I still carry the contract slip; the reward panel says 40 cp while HUD coin reads silver—same currency mismatch as before.
- zu Zug 26 (notiert vor Zug 27): Extractor error on last reply ('WORLD NOT RECORDED'), so Bertho's hospitality didn't register in state; quest still shows active though flagged ready for turn-in. I'm heading back to turn it in.
- zu Zug 27 (notiert vor Zug 28): Turn-in succeeded cleanly this time: +40 copper and +23 XP, coin now 1 Gold 5 Copper (still odd denominations vs earlier copper counts). Threat note about the stranger angling for a sealed ledger persists on the HUD.
- zu Zug 28 (notiert vor Zug 29): Board payout denominations still mixed ('80 cp (8 Silver)') though coin is now tracked in gold/silver/copper; the courtesy note to the Guildhall still sits in my inventory after two deliveries.
- zu Zug 29 (notiert vor Zug 30): Threat note about the stranger on the Chapel Hollow road persists even though I'm back inside Alderwatch—possibly stale.
- zu Zug 30 (notiert vor Zug 31): PER search failed to find a shed keeper; fresh tracks lead toward a gap in the spoil heaps at the wall.
- zu Zug 31 (notiert vor Zug 32): Time jumped 14:18→15:18 in HUD while narrator said 10 min; minor tracking inconsistency. Contract needs 3 kills but only 2 dogs present.
- zu Zug 32 (notiert vor Zug 33): Combat ran cleanly with First Strike and loot drops; contract progress shows 1/3 but only two dogs were found at the den, so the third may need tracking.
- zu Zug 33 (notiert vor Zug 34): Contract tracks 2/3 kills; the big dog is still at large. NPC ids show raw placeholder names (Npc.npctanner) in the scene panel.
- zu Zug 34 (notiert vor Zug 35): Tanners confirmed the big dog's route (wall from the north, past the old kilns, strikes at dusk) and mentioned a possible fourth yellowish dog, now flagged in the HUD as a threat.
- zu Zug 35 (notiert vor Zug 36): HUD lists four dogs present but two are dead; the yellowish fourth dog (Feral Dog D) is watching from the pit edge and may join in.
- zu Zug 36 (notiert vor Zug 37): Contract reached 3/3 and is flagged ready for turn-in with loot consistent with prior kills (pelts/fangs stack correctly). The fourth dog (Dog D, MEDIUM) sat still through the fight; leaving it be as the contract is done. HUD location still says 'den hollow' while the scene is the kiln yard — minor label lag.
- zu Zug 37 (notiert vor Zug 38): Contract 3/3 ready for turn-in; MP at 24/72, will need rest before morning turn-in. No new oddities.
- zu Zug 38 (notiert vor Zug 39): Prices confirmed: stew 3 cp, bunk 5 cp — affordable with 1g5c; contract turn-in (50 cp) planned for morning.
- zu Zug 39 (notiert vor Zug 40): Coin display is consistent (105→97 cp, shown as 9s7c). Rest should recover MP before morning turn-in.
- zu Zug 40 (notiert vor Zug 41): Turn-in worked cleanly: 50 copper payout, +23 XP, Level 2 with 5 free points. HUD shows HP 80/85 'lightly wounded' though no recent damage was noted — minor, will watch it. HUD also flags the Chapel Hollow stranger as a lingering threat.
- zu Zug 41 (notiert vor Zug 42): Assign resolved cleanly and raised caps (MP 72→84); HP still 80/85 'lightly wounded' with no damage since the dog fight, likely residual but unconfirmed. Contract turn-in and payout were consistent.
- zu Zug 42 (notiert vor Zug 43): Oddity: Maren claims I 'took the ledger and the medicine both yesterday,' but I only ever took the dog cull. Also the 'Here' line references a stranger on the Chapel Hollow road I've never met — inconsistent with my actual history. I'll pick the safer medicine run and watch for further drift.
- zu Zug 43 (notiert vor Zug 44): System clarify offered three contracts that don't match the narrator's board at all (bog striders, catacomb escort, cart escort) — board/engine mismatch, retrying with the exact name.
- zu Zug 44 (notiert vor Zug 45): Second straight clarify rejection on the medicine run; the System only offers bog striders, catacomb galleries, and a dyer's cart escort, none of which Maren's board lists. Also, the Present line says 'nobody besides Alaric' while Maren is actively talking to me.
- zu Zug 45 (notiert vor Zug 46): Medicine-run contradiction was resolved in-story: Maren says it was taken and closed yesterday and was posted by mistake, so no booking happened. The 'Here' threat line about the Chapel Hollow road stranger still displays even though I'm inside the Guildhall.
- zu Zug 46 (notiert vor Zug 47): Narrator insists I took the sealed-ledger courier job yesterday, but my quest log shows 'Quests: —' and I only ever booked the dog cull — a persistent narrator/HUD contradiction. The 'Here' line also still tracks a stranger angling for the ledger, a plot thread I have never actually touched.
- zu Zug 47 (notiert vor Zug 48): HUD confirms Quests: — and no ledger in Carried, contradicting Maren's ledger entry; also noticed HP cap shown as 90 here versus 85 in turn 42's note.
- zu Zug 48 (notiert vor Zug 49): Maren's search confirmed no ledger in my possession, matching the HUD; the narrator is now running with an impersonation plot that contradicts my actual quest log (Quests: —), though it's at least internally consistent now.
- zu Zug 49 (notiert vor Zug 50): The impersonation plot continues to run smoothly in-story even though my quest log shows no such contract was ever booked; the narrator has fully committed to the doppelganger explanation, so I'll go along with it as in-world truth.
- zu Zug 50 (notiert vor Zug 51): The impostor plot has escalated to a second fraudulent contract (the medicine run) under my name; quest log still shows '—', consistent with my never booking either job.
- zu Zug 52 (notiert vor Zug 53): Small inventory oddity: the HUD still lists the visitor's day-book as Carried after Maren filed it under the counter.
- zu Zug 53 (notiert vor Zug 54): Greve arrived reading Maren's letter copy and checking my face against a description, showing the impersonation plot is now fully in the Guild's hands; the visitor's day-book still shows as Carried in the HUD even though Maren filed it under the counter last turn.
- zu Zug 55 (notiert vor Zug 56): Greve closed the interview with a standing order: no road or courier work for me until the impostor is settled, which effectively blocks my usual quest type for now. The day-book still shows Carried in the HUD despite being handed back — same inventory lag as before.
- zu Zug 56 (notiert vor Zug 57): Small inventory oddity persists: the HUD still lists 'visitor's day-book' as Carried even after Maren filed it on the shelf behind her.
- zu Zug 57 (notiert vor Zug 58): Greve now blocks road and courier work for me, so I'll need non-road quests next; day-book inventory oddity persists.
- zu Zug 58 (notiert vor Zug 59): HUD still lists the visitor's day-book as Carried even after it was filed at the Guildhall; also HP shows lightly wounded with no healing option noted yet, worth watching.
- zu Zug 59 (notiert vor Zug 60): One narrator glitch: 'WORLD NOT RECORDED — extractor gave no valid answer' when I gave Sarra my name, though the story text proceeded fine and nothing changed.
- zu Zug 60 (notiert vor Zug 61): Maren offered three inside-wall quests; the Tally Cellar job (4 silver, kill vermin, confirm cellar clean) suits my blocked-from-roads status.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t32 | 32 | 1 | – | nein | 1 | gewonnen, 12 XP |
| enc.t33 | 33 | 1 | – | nein | 1 | gewonnen, 12 XP |
| enc.t36 | 36 | 1 | – | nein | 1 | gewonnen, 15 XP |

## Quests

- **Cull the Chapel Gnashers at the Millpond Reeds** — expired (Zug 22)
  - Aufgabe: Hunt and cull the gnasher lizards nesting in the reed banks of the Alderwatch millpond so the mill's waterwheel intake runs clear again.
  - Endzustand: Four gnasher lizards are culled at the millpond and the mill's waterwheel intake runs clear.
- **Clear the Old Crown Catacombs, Level 1** — expired (Zug 22), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of the Old Crown Catacombs beneath the ruined chapel west of Alderwatch, putting down the restless skeletons in the burial galleries so the wardens can resume warden patrols.
  - Endzustand: Level 1 of the Old Crown Catacombs is cleared of its restless dead and the temple wardens resume their patrols.
- **Escort the Dyer's Wagon to Fennwick Crossing** — expired (Zug 22)
  - Aufgabe: Escort the dyehouse's wagon of finished cloth and its driver to Fennwick Crossing along the river road, where waylayers have been stopping carts after dusk.
  - Endzustand: The dyehouse wagon and its driver reach Fennwick Crossing safely with the cloth undamaged.
- **Courier the Warden's Sealed Ledger to the Chapel Priory** — active (Zug 8) → completed (Zug 21), READY
  - Aufgabe: Deliver the warden's sealed ledger to the priory at Chapel Hollow before the week's burial rites are read, taking the forest cut where the wagon road is washed out.
  - Endzustand: The warden's sealed ledger is delivered unopened to the priory at Chapel Hollow.
- **Drive the Stone Martens from the Quarry Sheds** — expired (Zug 22)
  - Aufgabe: Clear the stone marten den out of the quarry tool sheds at the Splitrock workings so the cutters can store their tools and lamp oil safely again.
  - Endzustand: The stone marten den is driven off or destroyed and the quarry tool sheds are safe to use again.
- **Carry Medicine to the Hollow Bridge Tollhouse** — active (Zug 23) → completed (Zug 27), READY
  - Aufgabe: Deliver the warden's parcel of fever medicine from the Alderwatch physick hall to the tollhouse at Hollow Bridge before the tollkeeper's daughter worsens.
  - Endzustand: The fever medicine reaches the tollkeeper at Hollow Bridge in usable condition.
- **Cull the Feral Dogs at the Tannery Rows** — active (Zug 29) → completed (Zug 40), READY
  - Aufgabe: Hunt and cull the feral dog pack that has been breaking into the curing sheds behind the tannery rows and destroying hides.
  - Endzustand: The feral dog pack is culled and the curing sheds are safe from further break-ins.

## Auffälligkeiten

- Zug 7, Nachricht 14 (extraction_repaired): the extractor's first answer needed a repair
- Zug 7, Nachricht 14 (finish): extract ended with finish_reason "length"
- Zug 13, Nachricht 26 (extraction_repaired): the extractor's first answer needed a repair
- Zug 13, Nachricht 26 (finish): extract ended with finish_reason "length"
- Zug 14, Nachricht 28 (extraction_repaired): the extractor's first answer needed a repair
- Zug 14, Nachricht 28 (finish): extract ended with finish_reason "length"
- Zug 16, Nachricht 32 (extraction_repaired): the extractor's first answer needed a repair
- Zug 16, Nachricht 32 (finish): extract ended with finish_reason "length"
- Zug 17, Nachricht 33 (planner_repaired): the planner's first answer needed a repair
- Zug 17, Nachricht 33 (finish): plan ended with finish_reason "length"
- Zug 21, Nachricht 41 (planner_repaired): the planner's first answer needed a repair
- Zug 22, Nachricht 43 (finish): board ended with finish_reason "length"
- Zug 25, Nachricht 50 (extraction_repaired): the extractor's first answer needed a repair
- Zug 26, Nachricht 52 (extraction_failed): the extractor failed: $.deltas[0] (person.new): .role: expected string, got null
- Zug 26, Nachricht 52 (extraction_repaired): the extractor's first answer needed a repair
- Zug 26, Nachricht 52 (finish): extract ended with finish_reason "length"
- Zug 31, Nachricht 62 (extraction_repaired): the extractor's first answer needed a repair
- Zug 31, Nachricht 62 (finish): extract ended with finish_reason "length"
- Zug 33, Nachricht 66 (extraction_repaired): the extractor's first answer needed a repair
- Zug 33, Nachricht 66 (finish): extract ended with finish_reason "length"
- Zug 37, Nachricht 74 (extraction_repaired): the extractor's first answer needed a repair
- Zug 51, Nachricht 102 (extraction_repaired): the extractor's first answer needed a repair
- Zug 51, Nachricht 102 (finish): extract ended with finish_reason "length"
- Zug 53, Nachricht 106 (extraction_repaired): the extractor's first answer needed a repair
- Zug 53, Nachricht 106 (finish): extract ended with finish_reason "length"
- Zug 54, Nachricht 108 (extraction_repaired): the extractor's first answer needed a repair
- Zug 54, Nachricht 108 (finish): extract ended with finish_reason "length"
- Zug 59, Nachricht 118 (extraction_failed): the extractor failed: signal is aborted without reason
- Zug 60, Nachricht 120 (extraction_failed): the extractor failed: signal is aborted without reason
- Zug 60, Nachricht 120 (extraction_repaired): the extractor's first answer needed a repair
- Zug 60, Nachricht 120 (finish): extract ended with finish_reason "length"
- Zug 61, Nachricht 122 (empty_reply): the narrator's reply was empty (no extraction; the player saw the notice)
- Hinweis (warning): Avereth Engine: the narrator returned no story text. Swipe or regenerate the reply.
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 33× keine gültige JSON-Entscheidung (Züge 2, 4, 5, 6, 7, 11, 12, 13, 14, 15, 16, 17, 18, 20, 22, 25, 26, 27, 28, 30, 31, 34, 38, 39, 40, 41, 47, 49, 51, 54, 55, 58, 61)
- Server: Generation failed AbortError: The operation was aborted.
- Server: Generation failed AbortError: The operation was aborted.
- 14 Aufruf(e) mit finish_reason "length" (Nr. 16 extract, Nr. 35 extract, Nr. 39 extract, Nr. 46 extract, Nr. 48 plan, Nr. 66 board, Nr. 82 extract, Nr. 98 extract, Nr. 105 extract, Nr. 154 extract, Nr. 161 extract, Nr. 165 extract, Nr. 184 extract, Nr. 187 narrator)

System-Panels: CLARIFY 2, NOT TAKEN 0, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: world_rule 1, guild_canon 1, no_go 3, engine_owned_fact 8, ambient 2, pc_inventory 1, offer 2.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 60 | 2 | 3.7 s | 22.4 s | 10619 | 9261 | 92 | – | stop 59, length 1 | 1 |
| narrator | 56 | 0 | 13.3 s | 93.8 s | 11246 | 8681 | 435 | – | stop 55, length 1 | 1 |
| extract | 68 | 2 | 8.7 s | 68.5 s | 9541 | 7826 | 465 | – | stop 55, length 11 | 11 |
| board | 3 | 1 | 23.1 s | 52.4 s | 1912 | 1708 | 1182 | – | stop 2, length 1 | 1 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 80:18 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 16.4 s) | 0:31 min |
| 61 Züge, Spiel (Senden bis HUD nach der Extraktion) | 70:12 min — Median 39.2 s, p90 157.6 s, max 216.0 s |
| 61 Züge, Spieler-Entscheidung | 8:34 min — Median 6.1 s, 33 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 7:36 min / 1:27 min / 32:15 min / 26:44 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 77.5 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 51:39 min, 80 Züge ≈ 103:18 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spieler | 61 | – | 38.9 s | 6.1 s |
| Spieler | 45 | – | 38.3 s | 6.1 s |
| Spieler | 40 | – | 30.2 s | 6.1 s |
| Spiel | 60 | – | 216.0 s | 39.2 s |
| Spiel | 49 | – | 207.0 s | 39.2 s |
| Spiel | 61 | – | 200.7 s | 39.2 s |
| Provider plan | 31 | 96 | 52.1 s | 3.7 s |
| Provider plan | 57 | 173 | 38.1 s | 3.7 s |
| Provider plan | 17 | 48 | 37.7 s | 3.7 s |
| Provider narrator | 49 | 147 | 196.9 s | 13.3 s |
| Provider narrator | 61 | 187 | 188.5 s | 13.3 s |
| Provider narrator | 45 | 135 | 163.2 s | 13.3 s |
| Provider extract | 16 | 46 | 111.1 s | 8.7 s |
| Provider extract | 51 | 154 | 92.3 s | 8.7 s |
| Provider extract | 14 | 39 | 86.7 s | 8.7 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
