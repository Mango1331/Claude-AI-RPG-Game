# Avereth Live-Test 20261024-104654Z-current_test

## Kurzfassung

- **Ergebnis:** Niederlage — turn 35: he died
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_duration (nicht erreicht)
- **Charakter:** mage (mage.arcane_bolt, mage.flame_lance) · Regelstand 2 (Warrior, Mage, Rogue)
- **Ziel-Dungeon:** Old Crown Catacombs, Ebene 1 (Vertrag quest.clear_the_upper_galleries_of_old_crown_catacombs)
- **Leitfaden:** current_test („Open-world long playtest — a real adventurer's life“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: pragmatic mercenary: value profitable reasonable contracts and gear improvements without reckless fights
- **Züge:** 35 · **Dauer:** 27:12 min · **LLM-Aufrufe der Engine/des Erzählers:** 102
- **Auffälligkeiten:** 2 · **Niederlage** in Zug 35: he died
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.66 |
| Git | 01636f32c46e (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 15.7 s |
| Browser | chrome 155.0.8059.85 |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261024-104654Z-current_test“, Seed 1855507926 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_duration | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | Mage | Engine (Menü/Rückfrage) | creation_complete | Choose the Mage base class, then pick two starter skills. | public roadside verge outside Alderwatch | 80/60 | 2.3 s |
| 2 | Arcane Bolt and Flame Lance. | Engine (Menü/Rückfrage) | creation_complete | Pick two Mage starter skills to finish character creation. | public roadside verge outside Alderwatch | 80/72 | 2.2 s |
| 3 | I walk to the city gates of Alderwatch and look for the Adventurers' Guild. | Erzähler | open_run_duration | Enter Alderwatch and find the Adventurers' Guild to look for novice quests. | Adventurers' Guild hall, Alderwatch | 80/72 | 20.2 s |
| 4 | I enter the guild hall and approach the counter to ask about registering and any novice quests. | Erzähler | open_run_duration | Register at the Adventurers' Guild and ask for novice quests. | Adventurers' Guild hall, Alderwatch | 80/72 | 51.6 s |
| 5 | I pay the two silver, sign the slip, and step onto the measuring stone to have my Power Rank read. | Erzähler | open_run_duration | Register at the guild for 2 silver and get my Power Rank read off the stone. | Adventurers' Guild hall, Alderwatch | 80/72 | 21.2 s |
| 6 | I take the Millbrook hound contract slip to the clerk and ask her to make it active. | Erzähler | open_run_duration | Accept the burrow hound cull contract at the guild counter. | Adventurers' Guild hall, Alderwatch | 80/72 | 26.0 s |
| 7 | I take the slip and head east out of Alderwatch toward Millbrook along the river road. | Erzähler | open_run_duration | Travel to Millbrook to hunt the burrow hounds. | Millbrook | 80/72 | 42.2 s |
| 8 | I walk over to the old man and ask if he can point out where the hounds have been digging and whether anyone's seen how many there are. | Erzähler | open_run_duration | Gather local intel on the hound den before approaching the gully. | Millbrook | 80/72 | 38.0 s |
| 9 | I thank him and circle toward the gully's edge, keeping well clear of its mouth, and look for the den entrance under the darker gorse from a… | Erzähler | open_run_duration | Scout the den entrance without walking into the gully mouth. | scrub gully east of Millbrook | 80/72 | 36.1 s |
| 10 | I cast Flame Lance at the hound at the den entrance. | Engine (Menü/Rückfrage) | open_run_duration | Strike the awake hound at the den mouth with Flame Lance before it can charge. | scrub gully east of Millbrook | 80/72 | 3.9 s |
| 11 | I climb down into the gully and advance along the floor toward the den entrance, staff ready, to draw the hounds out. | Erzähler | open_run_duration | Enter the gully so the hounds become targetable in an active scene. | burrow hound den entrance | 80/72 | 38.8 s |
| 12 | I cast Flame Lance at Burrow Hound A while it's still half in the entrance. | Erzähler | open_run_duration | Open the fight with Flame Lance on the hound emerging from the den. | burrow hound den entrance | 80/56 | 57.9 s |
| 13 | I stay near the den entrance with my staff ready, watching the gully and the den mouth for any movement. | Erzähler | open_run_duration | Wait alertly for the other hounds to show themselves rather than blundering into the den. | burrow hound den entrance | 80/56 | 63.2 s |
| 14 | I hurry up out of the gully and circle along the rim toward where the digging is heading, keeping my distance, staff ready to cast Flame Lan… | Erzähler | open_run_duration | Cut off the hounds escaping through the back tunnel before they slip away. | scrub gully east of Millbrook | 80/56 | 69.5 s |
| 15 | I cast Flame Lance at Burrow Hound B as it breaks through the mound. | Erzähler | open_run_duration | Strike Burrow Hound B the moment it emerges, before it can charge. | scrub gully east of Millbrook | 80/40 | 43.3 s |
| 16 | I cast Flame Lance at Burrow Hound C in the gorse stand. | Erzähler | open_run_duration | Kill the third hound before it flees or charges. | scrub gully east of Millbrook | 80/24 | 20.0 s |
| 17 | I wait and watch the den mouth for any sign of the fourth hound, staying on the rim. | Erzähler | open_run_duration | Wait for the fourth hound to show itself rather than entering the den. | scrub gully east of Millbrook | 80/24 | 19.9 s |
| 18 | I move down into the gully and peer into the den mouth, staff raised, ready to cast if anything stirs — but I won't crawl inside. | Erzähler | open_run_duration | Check the den mouth for the fourth hound without entering the tunnel. | burrow hound den entrance | 80/24 | 65.0 s |
| 19 | I circle around behind the bank and search the scrub for the second opening the airflow pointed to. | Erzähler | open_run_duration | Find the back exit of the den to look for the fourth hound. | behind the den bank | 80/24 | 40.8 s |
| 20 | I follow the trail at a steady pace, tracking the hound toward Millbrook's fields — not rushing, watching ahead for it. | Erzähler | open_run_duration | Track the fleeing fourth hound toward the sheep pens before it does damage. | long pasture by Millbrook's sheep pens | 80/24 | 49.7 s |
| 21 | I cast Flame Lance at the exhausted fourth hound by the trough while it's still lying low. | Erzähler | open_run_duration | Finish the fourth hound at range before it recovers or flees. | long pasture by Millbrook's sheep pens | 80/8 | 21.6 s |
| 22 | I walk back to Millbrook and turn in the completed hound contract at the Guild hall. | Erzähler | open_run_duration | Turn in the finished 4/4 contract and collect the reward. | Millbrook | 80/8 | 34.3 s |
| 23 | I tell the elder the four hounds are dead and the pens are safe, then set off west on the road back to Alderwatch to turn in the contract. | Erzähler | open_run_duration | Report the good news to the elder and walk back to Alderwatch to turn in the contract. | Alderwatch | 80/8 | 68.4 s |
| 24 | I turn in the completed Cull the Burrow Hounds contract at the Guild hall counter. | Erzähler | open_run_duration | Collect the 80 copper reward and close the quest. | Alderwatch | 80/8 | 36.1 s |
| 25 | I ask the clerk where I can get a cheap bed and a hot meal nearby, then head there once she points the way. | Erzähler | open_run_duration | Find cheap food and lodging for the night before turning in the contract at dawn. | Alderwatch | 80/8 | 28.9 s |
| 26 | I take the stew and bread, and pay Marta for the meal and a bed for the night. | Erzähler | open_run_duration | Eat and secure cheap lodging at the Split Barrel to rest and recover MP. | Alderwatch | 80/8 | 41.8 s |
| 27 | I sleep through the night, then go to the Guild hall in the morning and turn in the completed Cull the Burrow Hounds contract. | Erzähler | open_run_duration | Rest overnight, then collect the 80 copper reward at the Guild desk. | Adventurers' Guild hall, Alderwatch | 80/72 | 17.6 s |
| 28 | I walk over to the board and look for a new novice contract with decent pay. | Erzähler | open_run_duration | Browse the Guild board for a new profitable novice contract. | Adventurers' Guild hall, Alderwatch | 80/72 | 43.1 s |
| 29 | I take the Clear the Upper Galleries of Old Crown Catacombs contract slip from the board and accept it at the clerk's desk. | Erzähler | open_run_duration | Accept the highest-paying novice contract, a skeleton-clearing job in the catacombs. | Adventurers' Guild hall, Alderwatch | 80/72 | 18.5 s |
| 30 | I head west out of Alderwatch toward the ruined chapel and find the watchman at the stair. | Erzähler | open_run_duration | Travel to Old Crown Catacombs and locate the entrance to begin the skeleton-clearing contr… | Old Crown Catacombs | 80/72 | 21.2 s |
| 31 | I enter the dungeon. | Erzähler | open_run_duration | Enter Old Crown Catacombs and begin clearing level 1. | Old Crown Catacombs, Level 1 Gallery | 80/72 | 84.6 s |
| 32 | I cast Flame Lance at Restless Skeleton A. | Erzähler | open_run_duration | Open the catacombs fight by burning down the strongest skeleton. | Old Crown Catacombs, Level 1 Gallery | 45/56 | 32.2 s |
| 33 | I cast Flame Lance at Restless Skeleton A to finish it off. | Erzähler | open_run_duration | Kill the wounded skeleton with another Flame Lance before it strikes again. | Old Crown Catacombs, Level 1 Gallery | 25/40 | 18.0 s |
| 34 | I cast Flame Lance at Restless Skeleton B. | Erzähler | open_run_duration | Kill skeleton B before it strikes again, then deal with the last one. | Old Crown Catacombs, Level 1 Gallery | 4/24 | 20.1 s |
| 35 | I finish Restless Skeleton B with a Basic Attack, then cast Flame Lance at Restless Skeleton C. | Erzähler | open_run_duration | Kill the 1 HP skeleton cheaply and burn the last one before it strikes. | Old Crown Catacombs, Level 1 Gallery | 0/24 | 34.6 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zum Start (notiert vor Zug 1): Clean initialization panel; class choice is step 1 of 2, skill selection expected next.
- zu Zug 2 (notiert vor Zug 3): Character creation completed cleanly: Mage with Arcane Bolt and Flame Lance, starter gear equipped, 5 silver on hand.
- zu Zug 4 (notiert vor Zug 5): Guild board shows five novice contracts with clear rewards; the hound cull (8 silver) looks like the best first job for a mage.
- zu Zug 5 (notiert vor Zug 6): Registration cost 2 silver leaving 3 silver; HUD and narration are consistent. Clerk explained Power Rank (F) vs Guild rank clearly.
- zu Zug 6 (notiert vor Zug 7): Contract is active in the HUD with a 0/4 counter, consistent with the clerk's seal; coin matches after registration.
- zu Zug 7 (notiert vor Zug 8): Two inconsistencies: the engine refused 'I take the slip' as quest.accept (already active) even though I was only picking it up, and the HUD now lists the reward as 80 cp while the guild board offered 8 silver. Also a 'Dog A' scene panel appeared before I met any dog.
- zu Zug 8 (notiert vor Zug 9): HUD still shows reward as 80 cp while the board said 8 silver; worth watching whether payout resolves to coin or copper.
- zu Zug 9 (notiert vor Zug 10): Den confirmed with at least two hounds, one awake at the entrance; wind is in my favor since it only sniffed without spotting me.
- zu Zug 10 (notiert vor Zug 11): Flame Lance failed because the hound was scene description, not an active-scene actor; nothing was spent. Need to close distance to trigger combat.
- zu Zug 11 (notiert vor Zug 12): Active scene now lists Burrow Hound A as targetable with HP 23; a third hound is answering the yips, so a 3-vs-1 may develop — I may need to back toward the gully mouth to avoid being surrounded.
- zu Zug 12 (notiert vor Zug 13): Combat resolved cleanly: Flame Lance one-shot Burrow Hound A (41 dmg), +12 XP, loot auto-collected, quest counter 1/4. Third hound answered from up the gully; second may still be in the den.
- zu Zug 13 (notiert vor Zug 14): The hounds are digging out through a back tunnel toward the rim; combat ended cleanly after the one-shot and the HUD still shows the reward discrepancy (80 cp vs 8 silver on the board).
- zu Zug 14 (notiert vor Zug 15): Hound B is emerging ten paces downslope; Hound C is watching the mound and hasn't spotted me yet — wind still in my favor. HUD reward still reads 80 cp vs board's 8 silver.
- zu Zug 15 (notiert vor Zug 16): Third one-shot kill; MP down to 40/72 after two casts, worth watching. Reward discrepancy 80 cp vs board persists in HUD.
- zu Zug 16 (notiert vor Zug 17): Cover gave -25% damage on the gorse hound but it still died in one cast; MP down to 24/72 after three one-shots.
- zu Zug 18 (notiert vor Zug 19): Den is confirmed empty of sound; air movement implies a second opening, so circling the bank is the sensible next step rather than crawling in.
- zu Zug 19 (notiert vor Zug 20): Fourth hound confirmed fled out the back toward Millbrook's fields; contract shows 3/4. Reward discrepancy 80 cp persists.
- zu Zug 20 (notiert vor Zug 21): MP is down to 24/72; this fourth cast will leave me nearly empty, and a village dog is present but only barking from a distance so far.
- zu Zug 21 (notiert vor Zug 22): Fourth hound defeated with a 43-damage first strike; contract flags ready for turn-in. MP nearly drained at 8/72, so I should rest or eat before taking new work.
- zu Zug 22 (notiert vor Zug 23): No Guild hall exists in Millbrook; turn-in requires the half-day walk back to Alderbranch — noted that the earlier attempt was correctly blocked. MP still only 8/72.
- zu Zug 23 (notiert vor Zug 24): Narrator text twice repeated the reward as eighty coppers, matching the HUD's 80 cp; earlier discrepancy note resolved.
- zu Zug 24 (notiert vor Zug 25): Turn-in correctly blocked by desk closing time; must return in the morning. MP still only 8/72, so rest is needed anyway.
- zu Zug 25 (notiert vor Zug 26): No mechanical rest/MP recovery shown yet; will check HUD after sleeping to confirm recovery works.
- zu Zug 26 (notiert vor Zug 27): No mechanical rest effect shown yet; coin was correctly deducted (-5 cp) at the inn. Watching whether sleeping restores MP.
- zu Zug 27 (notiert vor Zug 28): Rest mechanic confirmed working: MP fully restored 8→72 overnight. Reward paid as 8 silver (1 Gold 5 Copper total), slightly inconsistent with the earlier 'eighty copper' phrasing but value matches.
- zu Zug 28 (notiert vor Zug 29): Board offers five varied novice contracts; picking the 120 cp catacombs clear as best pay for a full-MP mage.
- zu Zug 29 (notiert vor Zug 30): Contract accepted cleanly with clear terms; heading out on the first dungeon delve of the run at full HP/MP.
- zu Zug 31 (notiert vor Zug 32): Combat started immediately on entry; enemies closed to SHORT range before my turn, and Flame Lance (35–43) can nearly one-shot the 48 HP skeleton.
- zu Zug 32 (notiert vor Zug 33): Three skeletons all closed to ENGAGED and hit hard in round 2 (35 damage total); at 45/80 HP I need to burn them down fast.
- zu Zug 33 (notiert vor Zug 34): At 25/80 HP with two ENGAGED skeletons, each Flame Lance kill removes one attacker before their initiative turn; MP 40 covers two more casts.
- zu Zug 34 (notiert vor Zug 35): At 4 HP, two skeletons hit ~10 each; killing B first removes one attacker, but C's next hit will likely kill me — this turn decides the fight.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t11 | 12 | 1 | – | nein | 1 | gewonnen, 12 XP |
| enc.t14 | 15 | 1 | – | nein | 1 | gewonnen, 12 XP |
| enc.t15 | 16 | 1 | – | nein | 1 | gewonnen, 12 XP |
| enc.t20 | 21 | 1 | – | nein | 1 | gewonnen, 12 XP |
| enc.t30r | 31 | 3 | – | nein | 2 | **tot** |

## Quests

- **Cull the Burrow Hounds at Millbrook** — active (Zug 6) → completed (Zug 27), READY
  - Aufgabe: Hunt down and cull 4 of the burrow hounds that have been digging into Millbrook's sheep pens and stop the losses.
  - Endzustand: At least 4 burrow hounds are dealt with and the sheep pens of Millbrook are no longer being broken into.
- **Clear the Upper Galleries of the Old Crown Catacombs** — expired (Zug 28), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of the Old Crown Catacombs beneath the ruined chapel west of Alderwatch so the temple wardens can resume sealing the older burials.
  - Endzustand: Level 1 of the Old Crown Catacombs is cleared of its restless dead.
- **Escort the Dyer's Cart to Ford Hallow** — expired (Zug 28)
  - Aufgabe: Escort the dyer's cart carrying two barrels of mordant and finished cloth from Alderwatch to Ford Hallow along the river road, where waylayers have been stopping carts after dusk.
  - Endzustand: The dyer's cart and its driver reach Ford Hallow safely with the mordant barrels and cloth intact.
- **Carry the Warden's Ledger to Greyford Priory** — expired (Zug 28)
  - Aufgabe: Deliver the warden's sealed tithe ledger from Alderwatch to Greyford Priory before the priory's accounting day, riding the cart track through the alder bottoms.
  - Endzustand: The sealed tithe ledger is delivered into the hands of the prior at Greyford Priory before accounting day.
- **Drive Off the Marsh Cat Prowling the Eel-Weirs** — expired (Zug 28)
  - Aufgabe: Hunt down the marsh cat that has been raiding the eel-weirs of the Reed Flats at night and drive it off or kill it so the fishers can work their weirs again.
  - Endzustand: The marsh cat no longer threatens the eel-weirs of the Reed Flats, whether driven off or killed.
- **Clear the Upper Galleries of Old Crown Catacombs** — active (Zug 29), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of the Old Crown Catacombs beneath the ruined chapel west of Alderwatch, driving out or destroying the restless skeletons so the wardens can resume burials in the upper galleries.
  - Endzustand: Level 1 of the Old Crown Catacombs is cleared of restless skeletons and the temple wardens can resume burials in the upper galleries.

## Auffälligkeiten

- Zug 20, Nachricht 40 (extraction_repaired): the extractor's first answer needed a repair
- Zug 22, Nachricht 44 (extraction_repaired): the extractor's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 26× keine gültige JSON-Entscheidung (Züge 2, 4, 5, 6, 7, 9, 10, 13, 14, 15, 17, 18, 19, 20, 21, 22, 23, 25, 26, 27, 28, 30, 31, 32, 33, 34)

System-Panels: CLARIFY 0, NOT TAKEN 1, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: guild_canon 1, ambient 1, engine_owned_fact 4, engine_owned_combat 1, no_go 2, offer 1, group_unclear 2, world_rule 5.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 33 | 0 | 2.5 s | 7.4 s | 10609 | 9360 | 67 | – | stop 33 | 0 |
| narrator | 32 | 0 | 14.0 s | 30.5 s | 11161 | 8515 | 441 | – | stop 32 | 0 |
| extract | 34 | 2 | 7.7 s | 19.7 s | 9444 | 7835 | 359 | – | stop 34 | 0 |
| board | 3 | 1 | 14.7 s | 16.0 s | 1958 | 1754 | 1124 | – | stop 3 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 27:12 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 15.7 s) | 0:32 min |
| 35 Züge, Spiel (Senden bis HUD nach der Extraktion) | 20:33 min — Median 34.6 s, p90 65.0 s, max 84.6 s |
| 35 Züge, Spieler-Entscheidung | 5:34 min — Median 5.1 s, 26 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 2:17 min / 0:40 min / 9:23 min / 7:00 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 44.8 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 29:51 min, 80 Züge ≈ 59:42 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spieler | 14 | – | 69.0 s | 5.1 s |
| Spieler | 6 | – | 34.7 s | 5.1 s |
| Provider narrator | 23 | 63 | 56.2 s | 14.0 s |
| Provider extract | 31 | 90 | 65.5 s | 7.7 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
