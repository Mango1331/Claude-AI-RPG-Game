# Avereth Live-Test 20261024-120700Z-current_test

## Kurzfassung

- **Ergebnis:** abgeschlossen: alle Pflicht-Etappen erreicht
- **Etappen:** 2/2 Pflicht erreicht
- **Charakter:** mage (mage.arcane_bolt, mage.flame_lance) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world long playtest — a real adventurer's life“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: pragmatic mercenary: value profitable reasonable contracts and gear improvements without reckless fights
- **Züge:** 100 · **Dauer:** 77:43 min · **LLM-Aufrufe der Engine/des Erzählers:** 298
- **Auffälligkeiten:** 9
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.67 |
| Git | 7bfb7f25e4d1 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 14.8 s |
| Browser | chrome 155.0.8059.85 |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261024-120700Z-current_test“, Seed 420282641 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_duration | ja | ✔ | 100 | 200 |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | I choose Mage. | Engine (Menü/Rückfrage) | creation_complete | Select the Mage base class. | public roadside verge outside Ashbridge | 80/60 | 2.2 s |
| 2 | I pick Arcane Bolt and Flame Lance. | Engine (Menü/Rückfrage) | creation_complete | Choose two offensive Mage starter skills | public roadside verge outside Ashbridge | 80/72 | 2.1 s |
| 3 | I walk along the road into Ashbridge and look for the Adventurers' Guild. | Erzähler | open_run_duration | Enter the city and find the Guild to look for starter contracts. | Adventurers' Guild hall, Ashbridge | 80/72 | 40.6 s |
| 4 | I wait by the counter for the clerk to finish, then ask about registering with the Guild and any starter contracts available. | Erzähler | open_run_duration | Register at the Guild and ask for novice contracts. | Adventurers' Guild hall, Ashbridge | 80/72 | 16.0 s |
| 5 | "Yes—two silver. I'll register." | Erzähler | open_run_duration | Pay the two silver fee and register with the Guild. | Adventurers' Guild hall, Ashbridge | 80/72 | 22.1 s |
| 6 | I take the Rat Cull slip from the board and bring it to the clerk. "I'll take this one." | Erzähler | open_run_duration | Accept the Rat Cull contract from the Novice board. | Adventurers' Guild hall, Ashbridge | 80/72 | 23.3 s |
| 7 | "I'll take the Millbrook delivery, then." | Erzähler | open_run_duration | Accept the Millbrook delivery contract after the rat cull was taken. | Adventurers' Guild hall, Ashbridge | 80/72 | 49.3 s |
| 8 | I'll take the gate watch, then. | Erzähler | open_run_duration | Accept the East Gate watch hand contract. | Adventurers' Guild hall, Ashbridge | 80/72 | 24.5 s |
| 9 | "Who's been sweeping the board? And what kind of non-Guild work are we talking about?" | Erzähler | open_run_duration | Press the clerk about the slip thief and the non-Guild work options. | Adventurers' Guild hall, Ashbridge | 80/72 | 43.5 s |
| 10 | I head down to the south gate and find the fishmonger who wants someone with a staff to scare off gulls. | Erzähler | open_run_duration | Take the fishmonger's gull-guard work for today's first coin. | Fishmonger's stall by the south gate | 80/72 | 28.6 s |
| 11 | "Deal. I'm in—where do you want me standing?" | Erzähler | open_run_duration | Accept the fishmonger's gull-guard job and start the morning shift. | Fishmonger's stall by the south gate | 80/72 | 47.0 s |
| 12 | I keep the staff sweeping over the boards and keep a particular eye on the big grey-backed gull pretending to leave. | Erzähler | open_run_duration | Work the morning shift and watch Tam's worst thief. | Fishmonger's stall by the south gate | 80/72 | 41.5 s |
| 13 | "Deal—I'll work the afternoon too, and I'll be back tomorrow for the two-and-two." | Erzähler | open_run_duration | Accept the afternoon shift and lock in tomorrow's better rate plus the meal. | Fishmonger's stall by the south gate | 80/72 | 46.7 s |
| 14 | I sit on Marta's stool and keep watching the wall, staff across my knees, until the afternoon trade thins out. | Erzähler | open_run_duration | Finish the afternoon shift on watch for the grey-backed gull's next run. | Fishmonger's stall by the south gate | 80/72 | 67.5 s |
| 15 | I thank Tam and Marta, eat the soup, and ask them where a man can get a cheap bed for the night nearby. | Erzähler | open_run_duration | Finish the day, get a lead on affordable lodging, then sleep to be back for the morning sh… | Fishmonger's stall by the south gate | 80/72 | 22.1 s |
| 16 | I head up Chandler's Row to the Copper Kettle, tell the widow Tam sent me, and pay for a bunk in the common room. | Erzähler | open_run_duration | Get a cheap night's sleep at the Copper Kettle so I'm back for the morning shift. | The Copper Kettle | 80/72 | 45.1 s |
| 17 | I eat the bread and dripping, wash up, and turn in on the fresh-straw bunk, intending to sleep till dawn and be back at Tam's stall before t… | Erzähler | open_run_duration | Rest overnight at the Copper Kettle and return for the morning shift. | The Copper Kettle | 80/72 | 52.6 s |
| 18 | I settle down on the bunk and sleep for the night. | Erzähler | open_run_duration | Sleep through the night at the Copper Kettle and wake in time for the morning shift. | The Copper Kettle | 80/72 | 38.5 s |
| 19 | I walk back to Tam's stall at the south gate and start the morning shift. | Erzähler | open_run_duration | Return to Tam's stall in time for the morning shift at the agreed two-and-two rate. | Fishmonger's stall by the south gate | 80/72 | 38.6 s |
| 20 | I keep the corner covered through midday, then ask Tam how the tally looks and whether the two-and-two comes off today's takings. | Erzähler | open_run_duration | Finish the morning shift and confirm payment terms with Tam. | Fishmonger's stall by the south gate | 80/72 | 56.0 s |
| 21 | I take the coins with a grin and pocket them. "Same again tomorrow, then. I'll be here at first light." | Erzähler | open_run_duration | Accept Tam's doubled pay and lock in the next day's work. | Fishmonger's stall by the south gate | 80/72 | 31.6 s |
| 22 | "What's this about the south gate square needing a man with a staff?" I ask Tam. "Who's paying, and for what?" | Erzähler | open_run_duration | Ask Tam about the afternoon work he mentioned at the south gate square. | Fishmonger's stall by the south gate | 80/72 | 46.6 s |
| 23 | I walk over to the toll house and knock at the open door. "Warden Breek? Tam sent me — I hear you need a staff by the trestle this afternoon… | Erzähler | open_run_duration | Accept the trestle watch job from Warden Breek. | Toll house by the south gate | 80/72 | 26.2 s |
| 24 | "One copper for the afternoon, plus whatever I eat — done. I'll stand the trestle till the fourth bell." I take up a post where I can see th… | Erzähler | open_run_duration | Accept Breek's trestle watch offer and start the afternoon watch. | Toll house by the south gate | 80/72 | 68.1 s |
| 25 | "Nothing gone — that's the job." I stretch my shoulders. "Anything else you need, or should I ask Tam for tomorrow's work? And is there a wo… | Erzähler | open_run_duration | Wrap up the watch, collect recognition from Breek, and ask about follow-on work. | Toll house by the south gate | 80/72 | 42.6 s |
| 26 | I walk back across the square to Tam's barrow. "Trestle stood clean till the clerks came — Breek paid up. Same stall tomorrow, or is there a… | Erzähler | open_run_duration | Return to Tam, report the trestle job done, and ask about tomorrow's work. | Tam's barrow | 80/72 | 25.6 s |
| 27 | I take the fish with a nod. "Thanks, Tam. Guild hall at first light, then. Anywhere cheap and dry to sleep around here before the lamps burn… | Erzähler | open_run_duration | Accept the fish and ask Tam for a cheap place to sleep for the night. | Tam's barrow | 80/72 | 21.8 s |
| 28 | I find the blue door down the alley off the square and knock. "Tam sent me — he offered the smoke shed for the night, if Marta's agreeable." | Erzähler | open_run_duration | Ask Marta for permission to sleep in the smoke shed. | Marta's house on Salt Lane | 80/72 | 31.0 s |
| 29 | I eat the soup and bread, thank Marta, and turn in for the night in the smoke shed. | Erzähler | open_run_duration | Eat, rest, and sleep in the smoke shed until first light. | Tam's smoke shed behind the house on Salt Lane | 80/72 | 28.9 s |
| 30 | I grab the fish and head to the Guild hall on Gate Street to look at the board for work. | Erzähler | open_run_duration | Go to the Guild hall and check the quest board for a suitable contract. | Adventurers' Guild hall, Ashbridge | 80/72 | 52.0 s |
| 31 | I approach the clerk. "I'll take the Chirurgeon's Case delivery to the mill hamlet — the 40 copper job for Chirurgeon Odo." | Erzähler | open_run_duration | Accept the low-risk delivery contract from the Guild board. | Adventurers' Guild hall, Ashbridge | 80/72 | 53.7 s |
| 32 | "Off," I say, and head out to Cordwainer Row to find Chirurgeon Odo's door with the brass ring. | Erzähler | open_run_duration | Take the contract slip to Odo's rooms to collect the case. | Chirurgeon Odo's rooms off Cordwainer Row | 80/72 | 42.7 s |
| 33 | I take the oiled cloth and the case with both hands. "Proper enough to get this there in one piece," I tell the boy, then to Odo: "Where do … | Erzähler | open_run_duration | Accept the case and rain cover and ask Odo to sign the slip so I can set off. | Chirurgeon Odo's rooms off Cordwainer Row | 80/72 | 32.5 s |
| 34 | I set off up the river road, case in both hands, watching the sky. | Erzähler | open_run_duration | Start the half-day delivery walk to the mill hamlet. | Chirurgeon Odo's rooms off Cordwainer Row | 80/72 | 48.6 s |
| 35 | "The slip says I carry it, and Odo signed it so," I say, shifting my grip. "Walk with me if you like, but the case stays in my hands until i… | Erzähler | open_run_duration | Refuse to hand over the case, per contract terms, but let Brac accompany me. | Chirurgeon Odo's rooms off Cordwainer Row | 80/72 | 34.1 s |
| 36 | I keep walking at a steady pace. "Then let's not dawdle — the sooner this is in Garrett's house, the better for the girl." | Erzähler | open_run_duration | Continue the delivery walk to the mill hamlet with Brac accompanying. | Mill hamlet | 80/72 | 58.3 s |
| 37 | I step inside and set the case down within her reach. "It's signed over to Garrett's household — yours now. I'll open it if you've no key; O… | Erzähler | open_run_duration | Hand over the case at Garrett's house and help the mistress get the draughts to Nella. | Millwright's house | 80/72 | 34.1 s |
| 38 | "I'll try," I say, and examine the brass lock, looking for a way to open it without breaking the case or its contents. | Erzähler | open_run_duration | Attempt to open the locked chirurgeon's case carefully so the mistress can get the draught… | Millwright's house | 80/72 | 52.9 s |
| 39 | I stay by the table, ready to help. "I'll wait — tell me if there's anything you need carried or heated." | Erzähler | open_run_duration | Stay and assist while the mistress gives Nella the draught, completing the delivery. | Millwright's house | 80/72 | 30.0 s |
| 40 | I stay at the table. "I'll wait for Garrett — the case is his now, and I'll need his mark on the slip to close the contract." | Erzähler | open_run_duration | Wait for Garrett to settle payment and sign off the delivery contract. | Millwright's house | 80/72 | 40.6 s |
| 41 | I take out the slip and pass it to Garrett with the stub of charcoal. "There — your mark, and the case is yours. Odo's owed whatever the pap… | Erzähler | open_run_duration | Get Garrett's mark on the delivery slip to close the contract. | Millwright's house | 80/72 | 55.5 s |
| 42 | I tuck the signed slip away and accept the bread. "Gladly — I'll walk back before dark. Thank the house for me, and I'll tell Odo to finish … | Erzähler | open_run_duration | Close the delivery and return to Ashbridge to turn the contract in at the Guild hall. | Ashbridge | 80/72 | 30.6 s |
| 43 | I step inside and hand the signed slip to the Guild clerk. "Delivery done — Garrett's mark is on it. I'll take the payment." | Erzähler | open_run_duration | Turn in the completed delivery contract at the Guild hall and collect the reward. | Ashbridge | 80/72 | 22.7 s |
| 44 | "Right — I'll bring the slip back once the mill's word comes in." I check the board for any small contracts I could take in the meantime. | Erzähler | open_run_duration | Accept the clerk's explanation and look for another short contract to fill the time until … | Ashbridge | 80/72 | 44.6 s |
| 45 | I hurry up to Chandler's Row and reach the main hall with the crossed spears before the dark bell. | Erzähler | open_run_duration | Reach the proper Guild hall on Chandler's Row before it closes and look for a short contra… | Adventurers' Guild hall, Ashbridge | 80/72 | 25.9 s |
| 46 | I shoulder in at the left edge of the board and read the open slips for anything small and well-paid near the city. | Erzähler | open_run_duration | Read the contract board for a short, profitable contract to take while waiting for the mil… | Adventurers' Guild hall, Ashbridge | 80/72 | 19.0 s |
| 47 | I take the wolf cull slip off the board and carry it to the clerk. "I'll take this one — the quarry track wolves cull." | Erzähler | open_run_duration | Accept the wolf cull contract at the Guild hall before the dark bell. | Adventurers' Guild hall, Ashbridge | 80/72 | 18.4 s |
| 48 | I ask the clerk, "Where do the wolves den along the track, and is there anywhere cheap to sleep nearby before I head out at first light?" | Erzähler | open_run_duration | Get wolf den details and a cheap lodging recommendation before hunting at dawn. | Adventurers' Guild hall, Ashbridge | 80/72 | 42.7 s |
| 49 | I head for the Wagoner's Rest inside the Southgate and take a room for the night, soup included. | Erzähler | open_run_duration | Sleep cheaply near the Southgate and set out on the wolf cull at first light. | the Wagoner's Rest | 80/72 | 32.0 s |
| 50 | "A cot in the back and the soup, plus the bread." I hand over the two and a half copper. | Erzähler | open_run_duration | Pay for lodging, soup and bread, then sleep and set out on the wolf cull at first light. | the Wagoner's Rest | 80/72 | 25.0 s |
| 51 | I finish the soup and bread, then take a cot in the back room and sleep until first light, ready to head for the quarry track. | Erzähler | open_run_duration | Rest overnight and set out on the wolf cull at dawn. | the Wagoner's Rest | 80/72 | 18.6 s |
| 52 | I thank the innkeeper and head out the Southgate for the quarry track, keeping an eye out for wolves as I go. | Erzähler | open_run_duration | Leave the city at dawn and travel to the quarry track to hunt the wolves. | old quarry track | 80/72 | 59.6 s |
| 53 | I approach the dark shape in the gorse with my staff ready, watching for wolves. | Erzähler | open_run_duration | Investigate the carrion the raven rose from, wary of wolves nearby. | old quarry track | 80/72 | 30.4 s |
| 54 | I raise my staff and cast Flame Lance at the broad-chested wolf, keeping the sheep carcass at my back so neither can circle behind me. | Erzähler | open_run_duration | Open the wolf fight with Flame Lance on Wolf A while keeping my back covered. | old quarry track | 80/56 | 36.6 s |
| 55 | I collect the pelt and fang from the dead wolf, then follow the tracks along the ridgeline where the lean wolf went, looking for the rest of… | Erzähler | open_run_duration | Loot the kill and track the remaining wolves to finish the cull contract. | collapsed adit den | 80/56 | 65.6 s |
| 56 | I stay out of the den's mouth and cast Flame Lance at the nearer of the two resting wolves. | Engine (Menü/Rückfrage) | open_run_duration | Open the den fight with Flame Lance at the resting wolf before it can alert the pack. | collapsed adit den | 80/56 | 8.1 s |
| 57 | I cast Flame Lance at Wolf B. | Erzähler | open_run_duration | Attack the only valid target in the active scene, Wolf B, at the den mouth. | collapsed adit den | 80/40 | 77.1 s |
| 58 | I cast Flame Lance at Wolf C before it can slip away. | Erzähler | open_run_duration | Kill the remaining visible wolf to advance the cull contract. | collapsed adit den | 80/24 | 21.2 s |
| 59 | I collect the pelts and fangs from the two dead wolves, then peer into the adit's dark looking for the fourth wolf, without stepping inside. | Erzähler | open_run_duration | Loot the kills and scout the den mouth for the fourth wolf to finish the cull contract. | collapsed adit den | 80/24 | 20.2 s |
| 60 | I back off from the adit mouth and wait downwind, watching the entrance in case the fourth wolf comes out. | Erzähler | open_run_duration | Ambush the fled fourth wolf if it emerges rather than entering the dark den with low MP. | collapsed adit den | 80/24 | 20.3 s |
| 61 | I carefully enter the adit a few steps, hugging the wall with my staff ready, and look for the fourth wolf just past the bend. | Erzähler | open_run_duration | Enter the den cautiously to find the last wolf and finish the cull contract. | collapsed adit den | 80/24 | 20.1 s |
| 62 | I push a few more paces deeper into the den, feeling along the wall, and search for the fourth wolf. | Erzähler | open_run_duration | Go deeper into the adit to find the last wolf and finish the cull contract. | low-roofed den chamber | 80/24 | 35.5 s |
| 63 | I cast Flame Lance at the wounded she-wolf. | Erzähler | open_run_duration | Kill the last wolf to complete the cull contract, leaving the pups alone. | low-roofed den chamber | 80/8 | 24.2 s |
| 64 | I leave the pups unharmed and head back out of the den toward the guild hall to turn in the cull contract. | Erzähler | open_run_duration | Exit the den and turn in the completed cull contract for the 60 cp reward. | Adventurers' Guild hall, Ashbridge | 80/8 | 34.9 s |
| 65 | #assign INT 3 WIL 2 | System (Befehl) | open_run_duration | Spend my level-up stat points before taking new work. | Adventurers' Guild hall, Ashbridge | 80/8 | 2.5 s |
| 66 | "Anything on the board that pays along the Mill Hamlet road? I'm headed that way with the chirurgeon's case anyway." | Erzähler | open_run_duration | Ask the clerk for paid work along the route to Mill Hamlet before setting out. | Adventurers' Guild hall, Ashbridge | 80/8 | 45.9 s |
| 67 | "The lost lamb pays best — I'll take that one. And the chicken-count too, if it's on my way." | Erzähler | open_run_duration | Accept the Lost Lamb contract and the Reeves chicken-count as paid work along the river ro… | Adventurers' Guild hall, Ashbridge | 80/8 | 51.1 s |
| 68 | I set out upstream on the river road with the chirurgeon's case, keeping an eye out for the Reeves farm and Hollow Brook Pasture as I walk. | Erzähler | open_run_duration | Travel the river road toward Mill Hamlet, watching for the Reeves farm and any sign of the… | Mill hamlet | 80/8 | 38.6 s |
| 69 | I knock at the millwright's door to deliver the chirurgeon's case. | Erzähler | open_run_duration | Hand over the case and collect the 40 cp delivery reward. | Millwright's house | 80/8 | 29.8 s |
| 70 | "I only carried the case — Odo isn't behind me, nobody mentioned coming up. I'm a mage, not a chirurgeon, but I'll help however I can if you… | Erzähler | open_run_duration | Tell Garrett honestly that Odo isn't coming and offer what help I can. | Millwright's house | 80/8 | 70.8 s |
| 71 | I go up the ladder stair to look at the girl, and tell Marta and the family plainly what I see. | Erzähler | open_run_duration | Examine the fevered child honestly so the family can decide whether to send for Odo. | attic sickroom | 80/8 | 32.5 s |
| 72 | "My magic is for fighting, not healing, and I've near none left today. Send your rider now — don't wait on me. I'll help keep her cool and w… | Erzähler | open_run_duration | Be honest that I can't heal and urge them to send for Odo immediately, offering practical … | attic sickroom | 80/8 | 30.1 s |
| 73 | I keep up the cool cloths and sit watch through the afternoon, resting so my mana can recover while we wait for Odo. | Engine (Menü/Rückfrage) | open_run_duration | Stay at the girl's bedside, help with cooling care, and conserve/rest mana until Odo arriv… | attic sickroom | 80/8 | 6.8 s |
| 74 | I rest for two hours, keeping up the cool cloths while I wait for Odo. | Erzähler | open_run_duration | Rest two hours at the bedside to recover mana while waiting for Odo. | attic sickroom | 85/42 | 31.9 s |
| 75 | I tell Marta I'll keep the night watch with the girl if she and her mother need sleep, and keep up the cool cloths. | Erzähler | open_run_duration | Offer to take the night watch at the girl's bedside while waiting for Odo. | attic sickroom | 85/42 | 28.0 s |
| 76 | I keep the morning watch, shortening the cloth rounds as her breathing worsens, and listen for a hoofbeat on the river road. | Erzähler | open_run_duration | Continue the sickroom watch into morning while waiting for Odo to arrive. | attic sickroom | 85/42 | 82.2 s |
| 77 | I fetch Odo's case up the ladder and tell him, "I kept the cloths two days — she worsened overnight, wet at the top of each breath. What els… | Erzähler | open_run_duration | Hand over the case, report the girl's symptoms accurately, and offer further help. | attic sickroom | 85/42 | 41.7 s |
| 78 | "Aye. I'll hold her still and I won't let go. Tell me where to stand and when to take hold." | Erzähler | open_run_duration | Accept the job of holding the girl steady during the incision and ask for positioning. | attic sickroom | 85/42 | 24.3 s |
| 79 | I hold fast, keeping her head forward and still, and don't let go until Odo tells me she's done. | Erzähler | open_run_duration | Hold the girl steady through the rest of the incision. | attic sickroom | 85/42 | 28.1 s |
| 80 | I let the mother wash my forearm, then ask Odo, "Is the case delivered as far as you're concerned? I should see about my fee for the carry." | Erzähler | open_run_duration | Get the delivery quest marked complete and collect the reward. | attic sickroom | 85/42 | 25.6 s |
| 81 | I accept the bread and eat, then ask Odo, "Any word you want carried back to the Guild clerk about the case?" | Erzähler | open_run_duration | Eat the offered meal and get a closing word for the clerk before heading back to turn in t… | attic sickroom | 85/42 | 28.4 s |
| 82 | I eat the eggs, then take my leave and start the walk back downriver to Ashbridge to hand in the contract slip. | Erzähler | open_run_duration | Finish the meal, leave the mill hamlet, and return to Ashbridge to turn in the delivery co… | attic sickroom | 85/42 | 53.5 s |
| 83 | I put my shoulder to the off-side axle and push the cart free of the ditch. | Erzähler | open_run_duration | Free the stuck cart and earn the promised honey. | attic sickroom | 85/42 | 53.8 s |
| 84 | I take the honey pot with thanks and follow the cart down the bend toward Ashbridge. | Erzähler | open_run_duration | Accept the honey and walk on to Ashbridge to turn in the contract. | attic sickroom | 85/42 | 40.2 s |
| 85 | I queue at the southern gate with the cart traffic and pass the guards' inspection into Ashbridge. | Erzähler | open_run_duration | Enter Ashbridge so I can turn in the delivery contract at the Guild hall. | Ashbridge | 85/42 | 45.6 s |
| 86 | I walk up the market row to the Guild hall and hand the contract slip to the clerk, reporting the case delivered to Odo at the mill hamlet. | Erzähler | open_run_duration | Turn in the delivery contract at the Guild hall and collect the reward. | Adventurers' Guild hall, Ashbridge | 85/42 | 44.0 s |
| 87 | "I can get Odo the millwright to stand witness — would a written note from him serve, or do you need him here in person?" | Erzähler | open_run_duration | Ask the clerk what form of witness will close the delivery contract. | Adventurers' Guild hall, Ashbridge | 85/42 | 24.8 s |
| 88 | "Understood — I'll bring Odo's written note with his mark. One thing: the case went into the chirurgeon's hands on the road because a girl a… | Erzähler | open_run_duration | Clarify exactly what Odo's witness note must say before walking back upstream. | Adventurers' Guild hall, Ashbridge | 85/42 | 18.2 s |
| 89 | I take the contract slip back and set out on the river road upstream toward the mill hamlet. | Erzähler | open_run_duration | Walk upstream to get Odo's witness note closing the delivery contract. | Mill hamlet | 85/42 | 54.2 s |
| 90 | "Then I'll take the letter now, if you'll write it — three lines saying the case reached your household whole and was put to use there, with… | Erzähler | open_run_duration | Get Odo's witness letter and carry it back to the Guild to close the contract. | Mill hamlet | 85/42 | 52.5 s |
| 91 | I take the offered letter with thanks and set off back down the river road toward Ashbridge at once. | Erzähler | open_run_duration | Carry the millwright's truthful witness letter back to the Guild desk before the noon coun… | Duskreach | 85/42 | 38.6 s |
| 92 | "Brenna slept without fever-cries through the night — her father's word. Your case was opened on the road short of the mill and used there a… | Erzähler | open_run_duration | Report Brenna's condition to the chirurgeon and pass on the daughter's message. | Duskreach | 85/42 | 23.9 s |
| 93 | I fall in beside Odo's mule and walk with him toward Ashbridge, telling him how the leg looked and that the millwright's household has the c… | Erzähler | open_run_duration | Walk back to Ashbridge with the chirurgeon, sharing what he asks about the leg and payment… | Ashbridge | 85/42 | 22.4 s |
| 94 | I hand Tam the millwright's letter and my contract slip. "The case reached the mill household whole and was put to use there — Odo's doses h… | Erzähler | open_run_duration | Close the delivery contract at the Guild desk and collect the 40 copper reward. | Ashbridge | 85/42 | 24.0 s |
| 95 | I set the millwright's letter and the contract slip on the counter. "It's the case delivery to the mill hamlet — here's the witness letter i… | Erzähler | open_run_duration | Close the delivery contract with Serane and collect the 40 copper reward. | Ashbridge | 85/42 | 30.9 s |
| 96 | I thank Serane and head east out of the square toward the Guild hall with the shield over the door. | Erzähler | open_run_duration | Reach the proper Guild hall by the east market to close the case delivery contract with Ha… | Adventurers' Guild hall, Ashbridge | 85/42 | 29.3 s |
| 97 | I put the contract slip in the brass tray and lay the millwright's letter on the wood. "The case delivery to the mill hamlet — carried whole… | Erzähler | open_run_duration | Close the case delivery contract with Hask and collect the 40 copper reward. | Adventurers' Guild hall, Ashbridge | 85/42 | 18.5 s |
| 98 | "The case is with Odo, the chirurgeon — I met him on the mill road walking it back himself. If the recall is his own word, can he confirm th… | Erzähler | open_run_duration | Ask Hask whether Odo's confirmation can close the delivery or the case must be re-carried. | Adventurers' Guild hall, Ashbridge | 85/42 | 31.8 s |
| 99 | I take my papers back. "Then void the slip — the delivery can't be made as written. And when Odo posts the restock-and-carry job up the mill… | Erzähler | open_run_duration | Abandon the uncompletable delivery contract and line up the fresh restock job instead. | Adventurers' Guild hall, Ashbridge | 85/42 | 27.3 s |
| 100 | I scan the notice board for any fresh contract worth the afternoon — something nearby and payable. | Erzähler | open_run_duration | Look over the board for a new small contract while waiting for Odo's job to be posted. | Adventurers' Guild hall, Ashbridge | 85/42 | 122.3 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zum Start (notiert vor Zug 1): Character creation step 1/2 active; starting stats all 5, 5 silver, outside Ashbridge.
- zu Zug 1 (notiert vor Zug 2): Step 2/2 skill pool shown with formulas; starter gear auto-equips after choice.
- zu Zug 2 (notiert vor Zug 3): Character creation completed cleanly; gear auto-equipped and stats match the Mage bonuses.
- zu Zug 3 (notiert vor Zug 4): Arrival scene at city gate resolved cleanly; Guild hall reached with two unnamed adventurers present.
- zu Zug 4 (notiert vor Zug 5): Registration costs 2 silver, leaving 3; clerk mentions a measuring stone that sets rank and a contract board for Novices.
- zu Zug 5 (notiert vor Zug 6): Registration resolved cleanly: Guild plate issued, rank Novice, coin 3 silver. Three Novice contracts posted; the rat cull pays best (6 silver) and suits a mercenary pragmatist.
- zu Zug 6 (notiert vor Zug 7): Oddity: my quest.accept attempt failed with 'no such contract' even though the slip was just listed on the board — the rat cull had already been taken, so the rejection was fair, but the error came before the in-fiction explanation. Coin shows 3 Silver while the purchase panel said 50→30 copper; the narrator reconciled it as two silver counted out.
- zu Zug 7 (notiert vor Zug 8): Second consecutive quest.accept failure: the Millbrook slip vanished from the board in the same turn I tried to accept it, taken by the two brigandine adventurers. Possible race issue between narrative board state and the quest engine.
- zu Zug 8 (notiert vor Zug 9): Third consecutive quest.accept failure — every Novice slip vanished from the board within the same turn I tried to accept it. The engine consistently rejects spoken acceptances; may need an explicit system command next time a slip is actually available.
- zu Zug 9 (notiert vor Zug 10): Third quest.accept failure: the gate watch slip vanished mid-conversation with no visible actor — the board sweep is engine-driven, not NPC-driven. Non-Guild work offers copper-level pay as fallback.
- zu Zug 10 (notiert vor Zug 11): First non-Guild work offer accepted via plain dialogue instead of quest.accept—worth watching whether it registers as a quest (Quests panel is still empty) or only pays informally.
- zu Zug 11 (notiert vor Zug 12): Engine bug: taking the job was logged as PURCHASE COMPLETE -1 copper — I paid the fishmonger for the privilege of working, instead of earning the copper. Quests panel still empty, so this is informal work only.
- zu Zug 12 (notiert vor Zug 13): Coin inconsistency: narrator log showed 30→29 copper but HUD reports 2 Silver 9 Copper (29c) — actually consistent, fine. Quests panel still empty despite ongoing paid work; wages seem to flow as dialogue rewards, not tracked quests.
- zu Zug 13 (notiert vor Zug 14): Same engine bug again: tomorrow's shifts logged as PURCHASE COMPLETE -4 copper, so the game charges me for future work as earnest money rather than tracking a promised wage. Quests panel still empty for ongoing work.
- zu Zug 14 (notiert vor Zug 15): Coin tracking is now consistent (29c - 4c earnest = 25c on HUD). XP still 0/100 despite a full day of work—non-combat effort grants nothing, worth watching. Soup appeared as a carried item; quest panel still empty.
- zu Zug 16 (notiert vor Zug 17): Lodging worked cleanly: 1 copper deducted, scene state tracked, innkeeper ENGAGED. Still no quest object for the gull job anywhere in the HUD.
- zu Zug 17 (notiert vor Zug 18): Engine rejected "sleep till dawn" with ACTION NOT POSSIBLE — room not booked, despite the narrator having taken my copper and chalked a bunk mark. I'll try a plainer sleep action and see if the room-booking state catches up.
- zu Zug 18 (notiert vor Zug 19): Sleep worked once phrased plainly; RECOVERY said nothing to recover since stats were full, so rest gave no mechanical effect but time advanced cleanly to Day 2, 08:00.
- zu Zug 19 (notiert vor Zug 20): HUD still shows no quest object for the gull job; four gulls listed as ACTIVE SCENE with full HP despite being purely a deterrence job, suggesting combat panels are being used for non-combat threats.
- zu Zug 20 (notiert vor Zug 21): Payment for the gull job went through narratively (2S5c on HUD) but still no quest object ever appeared—informal work seems to bypass the quest system entirely. XP remains 0/100 after two days of labor.
- zu Zug 21 (notiert vor Zug 22): HUD oddity: the coins appear in Carried as a literal item 'the coins Tam holds out' while Coin still reads 2 Silver 5 Copper — the payment wasn't added to the purse.
- zu Zug 22 (notiert vor Zug 23): First formal quest object appeared (Watch the toll trestle, offered, reward 1 cp) — informal gull work never got one. The 'coins' item still sits in Carried alongside Coin reading 2S5c, so Tam's payment remains uncredited.
- zu Zug 23 (notiert vor Zug 24): Quest offer is consistent with Breek's terms (1 cp). Still watching whether the phantom 'coins' item in Carried ever merges into Coin.
- zu Zug 24 (notiert vor Zug 25): Payment engine glitch: taking the job logged as 'PURCHASE COMPLETE -1 copper' (as if I paid Breek) and the quest auto-completed at acceptance, before the watch was done; coin dropped 1 copper despite the narrative saying I'd earn one.
- zu Zug 25 (notiert vor Zug 26): Breek's copper arrived on the HUD correctly (2S5c), but the earlier purchase glitch (-1 copper at acceptance) means the job netted zero; the phantom 'coins' item still sits in Carried. Breek offered recurring market-day work (third and sixth day).
- zu Zug 26 (notiert vor Zug 27): Tam gave a second informal item reward (fish); phantom 'coins' item still in Carried alongside it. Guild board at the hall flagged as the next real work source.
- zu Zug 28 (notiert vor Zug 29): New phantom item 'the coins Tam holds out' appeared in Carried alongside the fish; the quest list is empty again despite the completed trestle watch, suggesting informal jobs never register as persistent quest objects.
- zu Zug 29 (notiert vor Zug 30): Rest worked cleanly (RECOVERY panel noted full resources). Carried still shows phantom items 'the coins Tam holds out' alongside real coin; quest list empty after informal jobs.
- zu Zug 30 (notiert vor Zug 31): Quest board read cleanly with five Novice contracts and clear rewards; no acceptance glitch observed yet. Phantom 'coins Tam holds out' still cluttering Carried.
- zu Zug 31 (notiert vor Zug 32): Contract accepted cleanly this time — slip and quest logged on HUD, no coin glitch. Clerk added a sensible condition: Odo must sign the case over before delivery.
- zu Zug 32 (notiert vor Zug 33): Contract progressing cleanly; phantom 'coins Tam holds out' still cluttering Carried, and a new trestle-theft mystery line appeared in the world notes.
- zu Zug 33 (notiert vor Zug 34): Odo signed the slip cleanly and the case and oiled cloth registered as items; contract still progressing without glitches.
- zu Zug 34 (notiert vor Zug 35): Possible scam or genuine helper — either way the contract requires me to carry it; HUD still shows time/location stale at Odo's rooms despite an hour of travel.
- zu Zug 35 (notiert vor Zug 36): HUD still stale: time/location stuck at Day 3, 08:50 at Odo's rooms despite an hour-plus of travel and a new NPC present.
- zu Zug 36 (notiert vor Zug 37): HUD finally updated: time/location now Day 3, 12:00 at Mill hamlet, and present NPCs corrected to Brac and the mistress.
- zu Zug 37 (notiert vor Zug 38): Note: as a Mage I have no lockpicking tools confirmed in inventory; the small pouch's contents are unverified, so I examine before forcing anything.
- zu Zug 38 (notiert vor Zug 39): Lock opened cleanly with a buckle-pin; case contents and dosing notes confirmed. HUD time/location updating properly now.
- zu Zug 39 (notiert vor Zug 40): Minor HUD oddity: Carried list shows 'the coins Tam holds out' as an item name, which looks like a narrator line leaked into inventory. Also present-NPC field shows a raw internal id (npc.npcmillwright_mistress) instead of a name.
- zu Zug 40 (notiert vor Zug 41): Present-NPC field still leaks an internal id (npc.npcmillwright_mistress) alongside Garrett; carried list still shows the leaked 'the coins Tam holds out' item.
- zu Zug 41 (notiert vor Zug 42): Contract slip now marked; HUD still leaks the internal id for the mistress in Present, and the phantom 'the coins Tam holds out' carried item persists. Reward is listed as 40 cp — modest, worth confirming at the Guild.
- zu Zug 42 (notiert vor Zug 43): No new oddities; the phantom 'coins Tam holds out' item and leaked npc id persist in the HUD. XP still shows 0/100 at L1 after a full day's work.
- zu Zug 43 (notiert vor Zug 44): Engine rejected the turn-in because the mill's confirmation hasn't reached the Guild — a realistic delay mechanic, though the error line 'not at a Guild hall' contradicts the scene (I am at the hall).
- zu Zug 44 (notiert vor Zug 45): The riverside desk was a separate receiving office, not the contract hall — explains the earlier 'not at a Guild hall' rejection; heading to the real hall now.
- zu Zug 45 (notiert vor Zug 46): Reached the main hall before dark bell; board is readable in person. No new HUD oddities.
- zu Zug 46 (notiert vor Zug 47): Board read cleanly in person with four Novice slips; dark bell imminent so picking the near-city wolf cull (60 cp) over the warrens or escort jobs.
- zu Zug 47 (notiert vor Zug 48): Contract accepted cleanly with a magic seal that turns READY on completion — no trophies needed. HUD quest tracker now shows 0/4 defeated.
- zu Zug 48 (notiert vor Zug 49): Clerk gave practical lodging info; contract mechanics consistent. HUD time (15:45) lags the narrator's dusk scene again.
- zu Zug 49 (notiert vor Zug 50): Inn scene engaged cleanly; paying 2.5 cp of 5 cp total, so funds will run low if the wolf cull doesn't pay out soon.
- zu Zug 50 (notiert vor Zug 51): Purchase panel said -3 copper while the quoted price was 2.5 cp, but the coin total (25→22) matches 2.5 cp plus... actually 22 implies 3 cp deducted; minor arithmetic ambiguity. Coin display converted cleanly to 2s 2c.
- zu Zug 51 (notiert vor Zug 52): Coin display is inconsistent: HUD says 2 Silver 2 Copper while purchase panel deducted 3 copper for a 2.5 cp price; recovery panel correctly noted nothing to recover.
- zu Zug 53 (notiert vor Zug 54): Both wolves appeared via ACTIVE SCENE panels with 23 HP each at LONG range; fight start is clean so far.
- zu Zug 54 (notiert vor Zug 55): Flame Lance one-shot Wolf A for 37 damage; combat start/end, XP and loot panels all consistent, quest counter updated to 1/4. Wolf B fled cleanly rather than forcing a repetitive chase.
- zu Zug 55 (notiert vor Zug 56): Narrator counts four wolves at the den while quest needs 4; HUD only shows Wolf B present, so den interior may need entering or separate panels.
- zu Zug 56 (notiert vor Zug 57): System rejected the den-interior wolves as invalid targets; only Wolf B is an active scene entity, so the two resting wolves likely need a new scene trigger or entering the den.
- zu Zug 57 (notiert vor Zug 58): Quest counter updated to 2/4 and Wolf C is now a valid scene entity; the den interior remains unreachable, suggesting pups or another scene trigger inside.
- zu Zug 58 (notiert vor Zug 59): Quest counter at 3/4; a fourth wolf fled into the adit and puppyish cries inside were cut short, suggesting pups or another entity within that the scene has not yet activated.
- zu Zug 59 (notiert vor Zug 60): Loot 'take' was rejected as already held — pouch auto-collects, so looting is redundant. Quest stuck at 3/4 with the last wolf unlocated inside the adit.
- zu Zug 60 (notiert vor Zug 61): Two hours of ambush produced nothing; the fourth wolf will not emerge on its own, so the quest seems to require entering the adit.
- zu Zug 61 (notiert vor Zug 62): Two PER searches failed; no light source among my gear, so den interior exploration is search-check gated.
- zu Zug 62 (notiert vor Zug 63): Den interior finally resolved: the fourth wolf is a wounded she-wolf guarding two pups; scene entities and quest counter (3/4) are consistent.
- zu Zug 63 (notiert vor Zug 64): Quest counter now 4/4 and flagged ready for turn-in; killing the she-wolf in front of her pups is narratively heavy but mechanically clean, +24 XP puts me at 96/100, one kill from Level 2.
- zu Zug 64 (notiert vor Zug 65): Level 2 gained cleanly on turn-in; payout was 6 Silver rather than the listed 60 cp reward — a coin denomination mismatch worth noting. Quest slip auto-filed at the desk.
- zu Zug 65 (notiert vor Zug 66): Coin mismatch confirmed: System said +6 Silver, narrator showed 60 copper counted out; HUD agrees at 8S2C. Stat assign worked cleanly (INT 10, WIL 9).
- zu Zug 66 (notiert vor Zug 67): Ledger inconsistency: narrator says the wolf-cull payout is half-entered and the copper towers not yet handed over, while the HUD already shows 8S2C including the 6S reward. Also MP is nearly drained (8/116) — worth resting or budgeting before any fight.
- zu Zug 67 (notiert vor Zug 68): Both road contracts evaporated: the lamb slip was never really on the board (possible slip-thief tie-in) and the chicken-count was taken by a farm lad with a dog. Also noting my MP is nearly empty at 8/116 with no obvious way to refill it before the walk.
- zu Zug 68 (notiert vor Zug 69): Arrived at the hamlet; HUD shows MP 8/116, oddly low with no cast since last check — worth watching.
- zu Zug 69 (notiert vor Zug 70): MP shows 8/116 with no casts since the last check — possible regen bug or untracked drain; worth watching.
- zu Zug 71 (notiert vor Zug 72): MP still 8/116 with no casts — regen seems broken or drained by something untracked. Also HUD says 'Present: nobody besides Alaric' while Marta is clearly in the room.
- zu Zug 72 (notiert vor Zug 73): HUD still shows MP 8/116 despite no casting and rest — regen still looks broken or drained. 'Present: nobody besides Alaric' again contradicts Marta and the wife being in the house.
- zu Zug 73 (notiert vor Zug 74): System asked for an explicit rest duration; also HUD 'Present: nobody besides Alaric' still contradicts Marta being in the room, and MP remains 8/116.
- zu Zug 74 (notiert vor Zug 75): Explicit rest duration fixed the recovery bug: MP regen worked (8→42) once the System booked two hours. 'Present: nobody besides Alaric' still contradicts Marta being in the room.
- zu Zug 75 (notiert vor Zug 76): HUD 'Present: nobody besides Alaric' still contradicts Marta and the wife being in the house; the 'Marta's choice' threat lead seems stale since the rider was already sent.
- zu Zug 76 (notiert vor Zug 77): Odo has finally arrived; quest should now be completable. HUD 'Present' now correctly lists the Chirurgeon, though the stale 'Marta's choice' threat lead is still displayed despite the rider already having gone.
- zu Zug 77 (notiert vor Zug 78): Odo has arrived and the quest should be completable after the surgery; HUD 'Present' now lists only the Chirurgeon while Marta and the wife are clearly in the room, and the stale 'Marta's choice' threat lead is still active despite the rider having been sent.
- zu Zug 78 (notiert vor Zug 79): Surgery in progress and going well; the stale 'Marta's choice' threat lead is still listed in the HUD even though Odo has arrived and the cut is underway.
- zu Zug 79 (notiert vor Zug 80): Surgery succeeded and the girl breathes clear; HUD 'Present' now lists three people correctly, but the quest still shows only 'active' with no progress note despite the delivery being done.
- zu Zug 80 (notiert vor Zug 81): Quest still shows only 'active' with no progress note despite Odo confirming delivery; the girl's surgery succeeded and the stale 'Marta's choice' lead is gone from the HUD.
- zu Zug 81 (notiert vor Zug 82): No new oddities; the delivery is confirmed complete by Odo, though the quest panel still shows only 'active' with no progress note.
- zu Zug 82 (notiert vor Zug 83): HUD location still reads 'Mill hamlet — attic sickroom' with Odo present even though Alaric is an hour from Ashbridge on the road; the location panel lags the narrative. Quest still shows only 'active' despite confirmed delivery.
- zu Zug 83 (notiert vor Zug 84): HUD location still lags badly: it reads 'Mill hamlet — attic sickroom' with Odo and villagers present while Alaric is on the road with a donkey cart an hour from Ashbridge.
- zu Zug 84 (notiert vor Zug 85): Item engine quirk again: the honey pot was refused as 'someone holds it' but was added to inventory anyway when the woman tucked it under my arm. HUD location still lags, reading the mill hamlet attic while I stand before Ashbridge's gate.
- zu Zug 85 (notiert vor Zug 86): HUD location finally updated to Ashbridge correctly; delivery quest still shows only 'active' with no progress note despite confirmed completion.
- zu Zug 86 (notiert vor Zug 87): Turn-in refused on a technicality: the case went to the chirurgeon on the road, not into the millwright's household as the contract names; the clerk requires a witness from the mill to close it.
- zu Zug 87 (notiert vor Zug 88): Clerk set a clear condition: a letter in Odo's own hand with a recognizable mark saying the case reached the mill household whole closes the contract for 40 copper; HUD location and quest panel now consistent.
- zu Zug 88 (notiert vor Zug 89): Clerk gave clear closure terms: three lines from Odo's own hand with his mark. HUD location now correct; MP still only 42/116 from earlier casting.
- zu Zug 89 (notiert vor Zug 90): HUD location flipped back to 'Mill hamlet' correctly this time, but stale mystery leads (Hollow Brook pasture, Breek's trestle) still linger in the journal feed despite being days old.
- zu Zug 90 (notiert vor Zug 91): Millwright refused to write the exact wording the clerk specified and wrote his own truthful version instead — the clerk's earlier flexibility ('substance, not scripture') will now be tested at turn-in.
- zu Zug 91 (notiert vor Zug 92): No new oddity; the millwright's truthful letter is in hand and the chirurgeon is met on the road as flagged.
- zu Zug 92 (notiert vor Zug 93): Chirurgeon introduced himself as Odo — same name as the millwright; possibly a shared hamlet name or an engine naming slip worth noting.
- zu Zug 93 (notiert vor Zug 94): HUD carried-item text 'the coins Tam holds out' is premature — coins I don't yet have listed before payment; also two chirurgeon/millwright Odo names still ambiguous.
- zu Zug 94 (notiert vor Zug 95): Engine rejected handing two things at once ('nobody to give it to' for the slip); clerk name contradiction: Odo and the prior desk both said Tam keeps the desk, Serane says no Tam exists. HUD still lists 'the coins Tam holds out' as carried though payment never happened.
- zu Zug 95 (notiert vor Zug 96): Engine rejected turn-in here: carried contracts close only where opened, at the Guild hall proper — a two-desk Guild layout now consistent with earlier 'big house by the east market' hints.
- zu Zug 96 (notiert vor Zug 97): HUD still lists premature 'the coins Tam holds out' as carried; carried contracts confirmed to close only at the Guild hall proper.
- zu Zug 97 (notiert vor Zug 98): Turn-in rejected: engine says the case was recalled and never landed in the household, despite the millwright's letter saying it 'reached his household whole and was put to use' — a real contradiction between the witness letter and the contract roll.
- zu Zug 98 (notiert vor Zug 99): Contract confirmed mechanically uncompletable after the recall; engine ties turn-in strictly to case-in-household. Trading a dead quest for the follow-up job is the pragmatic move.
- zu Zug 99 (notiert vor Zug 100): Dead delivery contract cleanly voided; HUD still shows the phantom 'coins Tam holds out' as carried. Turn 100 reached, run continues.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t54 | 54 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t56 | 57 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t57 | 58 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t62 | 63 | 1 | – | nein | 1 | gewonnen, 24 XP |

## Quests

- **Watch the toll trestle** — completed (Zug 24)
- **Clear the Mossback Warrens, Level 1** — expired (Zug 100), Dungeon loc.mossback_warrens Ebene 1
  - Aufgabe: Clear level 1 of the Mossback Warrens, the goblin-dug upper galleries beneath the mossy hill east along the old quarry track, so the Guild can re-open the entry route.
  - Endzustand: Level 1 of the Mossback Warrens is cleared of its goblin occupants and the Guild's entry route is re-opened.
- **Cull the Quarry Track Wolves** — active (Zug 47) → completed (Zug 64), READY
  - Aufgabe: Hunt and cull the wolf pack that has been pulling down quarry mules along the old quarry track, taking at least four of the beasts.
  - Endzustand: At least four wolves of the quarry track pack are killed and the mule trains run without attack.
- **Escort the Dyer's Wagons to Reedford** — expired (Zug 100)
  - Aufgabe: Escort the dyer's two wagons of finished cloth to the Reedford river market, guarding them against the waylayers reported on the south road.
  - Endzustand: The dyer's two wagons and their driver reach the Reedford river market with the cloth undamaged and undelivered to no one but the market.
- **Carry the Chirurgeon's Case to the Mill Hamlet** — active (Zug 31) → abandoned (Zug 99)
  - Aufgabe: Deliver the chirurgeon's locked case of instruments and bandages to the mill hamlet upstream, where a millwright lies with a crushed leg.
  - Endzustand: The chirurgeon's locked case arrives intact at the mill hamlet and is handed to the millwright's household.
- **Drive the Bog Striders from the Eel-Weirs** — expired (Zug 100)
  - Aufgabe: Hunt down the bog striders nesting among the eel-weirs of the Reed Flats and kill at least three so the eel boats can launch safely again.
  - Endzustand: At least three bog striders are killed at the eel-weirs and the eel boats launch safely again.

## Auffälligkeiten

- Zug 11, Nachricht 22 (extraction_repaired): the extractor's first answer needed a repair
- Zug 22, Nachricht 44 (extraction_repaired): the extractor's first answer needed a repair
- Zug 28, Nachricht 56 (extraction_repaired): the extractor's first answer needed a repair
- Zug 32, Nachricht 64 (extraction_repaired): the extractor's first answer needed a repair
- Zug 33, Nachricht 66 (extraction_repaired): the extractor's first answer needed a repair
- Zug 34, Nachricht 68 (extraction_repaired): the extractor's first answer needed a repair
- Zug 82, Nachricht 164 (extraction_repaired): the extractor's first answer needed a repair
- Zug 91, Nachricht 182 (extraction_repaired): the extractor's first answer needed a repair
- Zug 94, Nachricht 188 (extraction_repaired): the extractor's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 54× keine gültige JSON-Entscheidung (Züge 1, 4, 5, 6, 8, 11, 16, 19, 20, 26, 27, 28, 29, 30, 33, 34, 36, 37, 38, 41, 43, 44, 45, 46, 47, 48, 49, 50, 52, 53, 55, 56, 57, 59, 65, 66, 70, 71, 74, 76, 77, 81, 82, 84, 85, 86, 87, 88, 89, 90, 92, 93, 96, 97)

System-Panels: CLARIFY 1, NOT TAKEN 0, REFUSED 1, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: ambient 6, guild_canon 1, engine_owned_fact 11, offer 2, pc_inventory 3, engine_owned_memory 2, quest_delivery 11, world_rule 4, guild_quest_detail 1, group_unclear 2, quest_count 1, guild_completion 1, engine_booked 2, engine_recovery 1, domain_fact 1, no_go 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 97 | 0 | 3.0 s | 8.0 s | 10744 | 9358 | 77 | – | stop 97 | 0 |
| narrator | 95 | 0 | 15.5 s | 31.3 s | 11295 | 8630 | 495 | – | stop 95 | 0 |
| extract | 104 | 9 | 9.8 s | 19.3 s | 9508 | 7859 | 445 | – | stop 104 | 0 |
| board | 2 | 0 | 55.7 s | 93.0 s | 1974 | 0 | 1079 | – | stop 2 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 77:43 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 14.8 s) | 0:57 min |
| 100 Züge, Spiel (Senden bis HUD nach der Extraktion) | 60:52 min — Median 32.3 s, p90 56.0 s, max 122.3 s |
| 100 Züge, Spieler-Entscheidung | 13:41 min — Median 5.7 s, 54 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 6:22 min / 1:51 min / 28:58 min / 19:57 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 44.7 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 29:50 min, 80 Züge ≈ 59:39 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spieler | 60 | – | 57.6 s | 5.7 s |
| Spieler | 56 | – | 51.9 s | 5.7 s |
| Spieler | 65 | – | 34.7 s | 5.7 s |
| Spiel | 100 | – | 122.3 s | 32.3 s |
| Provider narrator | 76 | 221 | 64.4 s | 15.5 s |
| Provider extract | 57 | 170 | 56.8 s | 9.8 s |
| Provider extract | 70 | 206 | 37.9 s | 9.8 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
