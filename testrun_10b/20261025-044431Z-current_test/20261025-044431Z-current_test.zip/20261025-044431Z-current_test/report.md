# Avereth Live-Test 20261025-044431Z-current_test

## Kurzfassung

- **Ergebnis:** abgeschlossen: alle Pflicht-Etappen erreicht
- **Etappen:** 2/2 Pflicht erreicht
- **Charakter:** mage (mage.arcane_bolt, mage.flame_lance) · Regelstand 2 (Warrior, Mage, Rogue)
- **Ziel-Dungeon:** Mossback Warrens, Ebene 1 (ohne Dungeon-Vertrag: der erste betretene)
- **Leitfaden:** current_test („Open-world long playtest — a real adventurer's life“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: curious opportunist: pursue interesting work and discoveries, develop your own ambitions
- **Züge:** 100 · **Dauer:** 57:58 min · **LLM-Aufrufe der Engine/des Erzählers:** 271
- **Auffälligkeiten:** 12
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.78 |
| Git | aa788dd93097 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 62.6 s |
| Browser | chrome 155.0.8059.85 |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261025-044431Z-current_test“, Seed 2136234700 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_duration | ja | ✔ | 100 | 200 |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | Mage | Engine (Menü/Rückfrage) | creation_complete | Choose Mage as base class. | public roadside verge outside Ashbridge | 80/60 | 2.3 s |
| 2 | Arcane Bolt and Flame Lance | Engine (Menü/Rückfrage) | creation_complete | Pick two offensive starter skills. | public roadside verge outside Ashbridge | 80/72 | 2.1 s |
| 3 | I walk along the road into Ashbridge and look for the Adventurers' Guild. | Erzähler | open_run_duration | Enter town and find the Guild for work. | Adventurers' Guild hall, Ashbridge | 80/72 | 21.6 s |
| 4 | I approach the counter. "Good morning. I'd like to register with the Guild and see what contracts are available for a new mage." | Erzähler | open_run_duration | Register with the Guild and ask for novice contracts. | Adventurers' Guild hall, Ashbridge | 80/72 | 20.7 s |
| 5 | I count out two silver and slide them across the counter. "Yes, please register me." | Erzähler | open_run_duration | Pay the two silver fee and complete Guild registration. | Adventurers' Guild hall, Ashbridge | 80/72 | 38.9 s |
| 6 | I take the plate and go to the notice board to read the posted contracts. | Erzähler | open_run_duration | Browse the Guild board for a suitable novice contract. | Adventurers' Guild hall, Ashbridge | 80/72 | 70.4 s |
| 7 | I ask the clerk, "Tell me about the Mossback Warrens — what's in there, and what do goblin parts fetch through the Guild broker?" | Erzähler | open_run_duration | Gather info on the Mossback Warrens and goblin loot prices before deciding whether to go. | Adventurers' Guild hall, Ashbridge | 80/72 | 30.4 s |
| 8 | "Please log me into the Mossback Warrens ledger." Then I ask her where in town I can buy rations, a waterskin and other cheap supplies befor… | Erzähler | open_run_duration | Log into the Warrens ledger and get directions to a supply shop. | Adventurers' Guild hall, Ashbridge | 80/72 | 43.9 s |
| 9 | I head to the market square and go into the general store opposite the smith. | Erzähler | open_run_duration | Buy cheap supplies (rations, waterskin) before the Warrens trip. | General store opposite the smith | 80/72 | 29.5 s |
| 10 | I'll take the waterskin and a length of rope. What does the hardtack cost, and do you have dried rations for a few days? | Erzähler | open_run_duration | Buy waterskin, rope and rations before the Warrens trip. | General store opposite the smith | 80/72 | 29.9 s |
| 11 | I'll take four pieces of hardtack, two bundles of the dried rations, and a flask of lamp oil. | Erzähler | open_run_duration | Buy rations and lamp oil, then head out to the Warrens. | General store opposite the smith | 80/72 | 12.7 s |
| 12 | I sling my pack and head out on the quarry track east toward the Mossback Warrens. | Erzähler | open_run_duration | Leave town for the Warrens with supplies bought. | Duskreach | 80/72 | 17.0 s |
| 13 | I skirt the flooded quarry along the shelf and approach the near tunnel mouth from downwind, watching for movement before closing in. | Erzähler | open_run_duration | Scout the near tunnel entrance carefully before engaging any goblins. | Duskreach | 80/72 | 22.0 s |
| 14 | I wait a few more moments behind the gorse, then move up the bare slope low and quiet, stopping short of the stakes to peer into the tunnel … | Erzähler | open_run_duration | Close with the near tunnel and scout for goblins before engaging. | Duskreach | 80/72 | 20.6 s |
| 15 | I slip between the stakes and ease into the tunnel mouth, staff ready, hugging the wall toward the bend. | Erzähler | open_run_duration | Scout the near tunnel carefully, ready to withdraw if goblins show. | Duskreach | 80/72 | 29.3 s |
| 16 | I hold still at the bend and listen, waiting to see if the thing beyond the turn moves again before I risk a look. | Erzähler | open_run_duration | Listen at the bend before risking a look around it. | Duskreach | 80/72 | 22.2 s |
| 17 | I put my eye carefully around the corner post for a quick look at what lies beyond the bend. | Erzähler | open_run_duration | Peek around the bend to identify the creature before deciding to fight or withdraw. | Duskreach | 80/72 | 20.4 s |
| 18 | I cast Flame Lance at the sleeping brute, aiming for its head. | Erzähler | open_run_duration | Ambush the sleeping brute with an opening spell while it rests. | Duskreach | 80/56 | 15.1 s |
| 19 | I grab the sling-bag and knife from the dead brute, then slip back around the bend and retreat quietly out of the tunnel. | Erzähler | open_run_duration | Loot the killed brute and withdraw before the deeper goblins investigate. | Open slope before the moss-grown hill | 80/56 | 30.5 s |
| 20 | I head down the quarry track toward town, opening the sling-bag as I walk to see what's inside. | Erzähler | open_run_duration | Loot the bag and return to town for the midday contract cart and a buyer. | Ashbridge | 80/56 | 19.0 s |
| 21 | I cut the sling-bag's cord with the brute knife and look through what's inside. | Erzähler | open_run_duration | Open the knotted sling-bag with the looted knife to see its contents. | Ashbridge | 80/56 | 23.0 s |
| 22 | I take the sling-bag and locket inside the Guild hall and ask whether the midday contract cart has arrived and whether anyone here can buy g… | Erzähler | open_run_duration | Check for new contracts and a buyer/appraiser for the loot and mystery locket. | Adventurers' Guild hall, Ashbridge | 80/56 | 26.5 s |
| 23 | I walk over to the far tables and ask the hunters and dice players if any of them know of paid work tonight. | Erzähler | open_run_duration | Find evening paid work through the Guild patrons since the board is empty until morning. | Adventurers' Guild hall, Ashbridge | 80/56 | 20.7 s |
| 24 | I head to the smithy and ask Marta whether she can open the dented locket, and what she'd charge. | Erzähler | open_run_duration | Have the smith open the mystery locket before the day ends. | Marta's smithy | 80/56 | 25.4 s |
| 25 | "I'm sure. Go ahead—ease it open." | Erzähler | open_run_duration | Pay Marta's two copper and have the locket opened. | Marta's smithy | 80/56 | 32.8 s |
| 26 | I ask Marta if she knows anyone in the valley named Trud who went missing near the Warrens, and whether the Watch would pay for news of it. | Erzähler | open_run_duration | Follow the locket lead: ask Marta about Trud and a possible reward. | Marta's smithy | 80/56 | 18.6 s |
| 27 | I thank Marta and head back to the Guild hall to check their ledger for a Trud who entered the Warrens and never came out. | Erzähler | open_run_duration | Follow the locket lead at the Guild's Warrens ledger before the day ends. | Adventurers' Guild hall, Ashbridge | 80/56 | 17.7 s |
| 28 | I ask her to check the ledger for a Trud who entered the Warrens and never signed out. | Erzähler | open_run_duration | Have the clerk search the Guild ledger for a missing Trud before closing time. | Adventurers' Guild hall, Ashbridge | 80/56 | 32.2 s |
| 29 | I show her the opened locket. "This came off a goblin in the Warrens today—Trud's name inside, and a curl of hair. Does the Guild post a con… | Erzähler | open_run_duration | Present the locket evidence and ask whether the Guild will post or pay on a contract for T… | Adventurers' Guild hall, Ashbridge | 80/56 | 31.9 s |
| 30 | "Understood. I'll take the locket to his kin on the quarry track tomorrow. Good night." I pocket the locket and head out to find cheap lodgi… | Erzähler | open_run_duration | Close the Guild visit and get a bed for the night before tomorrow's quarry-track errand an… | The Wether's Head | 80/56 | 64.7 s |
| 31 | I take the pottage and bread and a loft bed, and pay her the two copper. | Erzähler | open_run_duration | Pay for dinner and a loft bed at the Wether's Head for the night. | The Wether's Head loft | 80/56 | 17.4 s |
| 32 | I sleep through the night and head down at dawn for the morning meal. | Erzähler | open_run_duration | Rest overnight, then get breakfast and head out for the quarry track errand. | The Wether's Head | 80/72 | 24.1 s |
| 33 | I take the bread and dripping and pay her the copper, then eat and set out for the south gate. | Erzähler | open_run_duration | Buy breakfast, then leave for the quarry track to find Trud's kin. | the fork under the thorn tree | 80/72 | 23.2 s |
| 34 | I walk to the Brant place and knock, asking for Trud Askel's-son's kin: "I'm carrying news of Trud from the Warrens. Are his folk here?" | Erzähler | open_run_duration | Deliver the locket and news of Trud to his kin at the Brant place. | the Brant place | 80/72 | 22.9 s |
| 35 | I hold out the opened locket. "This came off a goblin in the Warrens yesterday. Trud's name inside, and a lock of hair. I'm sorry—I found no… | Erzähler | open_run_duration | Show the smith the locket and tell him honestly what I found of Trud. | the Brant place | 80/72 | 27.9 s |
| 36 | I wait the hour, keeping out of the way in the yard until the smith comes back out. | Erzähler | open_run_duration | Give the smith his hour, then give the full account of the Warrens as he asked. | the Brant place | 80/72 | 40.1 s |
| 37 | I drink, then give him the whole account: the two dead men at the first chamber, the goblin camp with the brute and its knife, the fire I pu… | Erzähler | open_run_duration | Give the smith the full honest account of the Warrens as he asked. | the Brant place | 80/72 | 25.4 s |
| 38 | "I'll go back in. What coin are you offering, and have you work here at the forge—a blade or a mail shirt I could buy or borrow before I go?… | Erzähler | open_run_duration | Accept the smith's quest and ask for payment and better gear. | the Brant place | 80/72 | 34.0 s |
| 39 | "Yes to the knife—edge it and I'll pay your eight copper. And I'll go at first light, not today—I want full daylight and fresh legs for the … | Erzähler | open_run_duration | Buy the hunting knife for 8 copper and plan to enter the Warrens at first light. | the Brant place | 80/72 | 72.2 s |
| 40 | I take the knife and buckle it on my belt where I can reach it fast, then ask if there's a corner of the yard or barn where I can sleep the … | Erzähler | open_run_duration | Equip the new hunting knife and arrange rest until the first-light departure. | the Brant place | 80/72 | 34.7 s |
| 41 | I thank him, push the horse's nose off if it comes nosing, and settle into the barn corner with the blanket to sleep until first light. | Erzähler | open_run_duration | Sleep the afternoon in the barn to be fresh for the first-light Warrens run. | the Brant place | 80/72 | 40.3 s |
| 42 | I eat the porridge while it's hot, then go over the slate with him and tell him I mean to start down the low passage, right at the fork, as … | Erzähler | open_run_duration | Eat, study the slate, and state my plan to take the low passage first. | the Brant place | 80/72 | 24.1 s |
| 43 | I tell him the truth: I've a flask of lamp oil and that's all—no lantern of my own and no flint. I ask if he'll lend me the horn lantern and… | Erzähler | open_run_duration | Ask to borrow the lantern, flint, and spare oil before setting out. | the Brant place | 80/72 | 22.8 s |
| 44 | I take the lantern, flint and filled flask, thank him, and set off through the yard gate for the hill. | Erzähler | open_run_duration | Collect the borrowed gear and walk to the Warrens while the morning is fresh. | Open slope before the moss-grown hill | 80/72 | 21.5 s |
| 45 | I light the lantern with the strike-a-light, check the flame is steady, and walk in past the cold ashes toward the fork, taking the low pass… | Erzähler | open_run_duration | Light the lantern and enter the hill, heading right at the fork into the low passage. | Open slope before the moss-grown hill | 80/72 | 29.9 s |
| 46 | I stop past the crack, keep the lantern raised, and watch the side crack for movement while readying Arcane Bolt in my free hand. | Erzähler | open_run_duration | Pause at the breathing side crack and prepare for whatever is inside before pushing deeper… | Open slope before the moss-grown hill | 80/72 | 20.0 s |
| 47 | I edge past the crack and creep down the low passage after the prints, lantern low, listening between steps. | Erzähler | open_run_duration | Sneak deeper along the low passage toward the knocking, past the silent crack. | Open slope before the moss-grown hill | 80/72 | 26.1 s |
| 48 | I peer around the bend toward the firelight, staying hidden behind the split pillar, and count whatever is making that light. | Erzähler | open_run_duration | Scout the light's source from cover before committing. | Open slope before the moss-grown hill | 80/72 | 37.3 s |
| 49 | I back away from the bend as quietly as I came, keeping low behind the pillar, and slip back up the low passage toward the fork. | Erzähler | open_run_duration | Withdraw unseen from five goblins and a captive—far beyond my strength—and reassess. | Open slope before the moss-grown hill | 80/72 | 28.7 s |
| 50 | I back away from the bend and retreat up the low passage toward the fork, ready to run if they follow. | Erzähler | open_run_duration | Withdraw from the alerted goblins before they close the twenty strides. | the fork under the thorn tree | 80/72 | 23.7 s |
| 51 | I head back up the wider passage toward the entry cutting and daylight, keeping the lantern low and listening as I go. | Erzähler | open_run_duration | Withdraw from the warrens entirely and return to the smith with the slate, lantern and fli… | Open slope before the moss-grown hill | 80/72 | 38.5 s |
| 52 | I walk down the quarry track to the smith's yard and hand back the slate, lantern and flint, claiming my promised meal and the knife's edge. | Erzähler | open_run_duration | Return to the smith, settle the loaned gear, collect the meal and edged knife. | the smith's yard | 80/72 | 41.9 s |
| 53 | I sit at the bench, eat the meal, and tell him what's down there: five goblins, the chamber with the drag marks, and a boot heel at the back… | Erzähler | open_run_duration | Report the warren findings to the smith and learn who the dragged man is. | the smith's yard | 80/72 | 28.9 s |
| 54 | "The drag marks run deep, not out — and whatever was at the back of that dark was still warm enough for the goblins to keep. If Trud's alive… | Erzähler | open_run_duration | Give the smith my honest read and angle toward a paid rescue job with gear support. | the smith's yard | 80/72 | 24.9 s |
| 55 | "Marta takes the shield and lantern at the front and holds the goblins' charge; I flank from the bend's dark and hit them with Flame Lance. … | Erzähler | open_run_duration | Pitch the rescue plan to the smith and secure the gear offer. | the smith's yard | 80/72 | 24.2 s |
| 56 | "I'd have you at the front with shield and lantern, holding their charge while I flank and burn them. We go for truth, not hope — find Trud … | Erzähler | open_run_duration | Answer Marta directly with the plan and honest terms to secure her as rescue partner. | the smith's yard | 80/72 | 18.7 s |
| 57 | "When." I take up the leaf-bladed shortsword and belt it on, then check my gear before we march. #equipment | Erzähler | open_run_duration | Accept the rescue job, take the offered shortsword, equip it and verify the engine booked … | the smith's yard | 80/72 | 19.8 s |
| 58 | "Dusk tomorrow — understood. If we're not out, don't send anyone." I nod to Marta and head through the gate with her, up the quarry track to… | Erzähler | open_run_duration | Confirm Brant's deadline and set off for the warrens with Marta. | Duskreach | 80/72 | 22.9 s |
| 59 | "Ready. I'll watch our back." I follow Marta in, quiet, staff in hand. | Erzähler | open_run_duration | Enter the warrens behind Marta, keeping quiet and covering the rear. | Mossback Warrens | 80/72 | 33.9 s |
| 60 | I cast Flame Lance at the goblin up on the slab, then keep watching our back for anything coming from the deeper dark. | Engine (Menü/Rückfrage) | open_run_duration | Break up the barricade group fast, starting with the lookout, while covering our rear. | Mossback Warrens | 80/72 | 24.9 s |
| 61 | I cast Flame Lance at the goblin crouched on the tipped slab behind the barricade. | Engine (Menü/Rückfrage) | open_run_duration | Break the barricade group starting with the lookout on the slab. | Mossback Warrens | 80/72 | 4.2 s |
| 62 | I cast Flame Lance at the nearest goblin behind the barricade. | Engine (Menü/Rückfrage) | open_run_duration | Break the barricade defense, starting with the closest goblin, since the System keeps reje… | Mossback Warrens | 80/72 | 4.5 s |
| 63 | I cast Flame Lance at the goblin hammering metal against stone. | Engine (Menü/Rückfrage) | open_run_duration | Break the target-sync problem by attacking the goblin the HUD itself lists as present in t… | Mossback Warrens | 80/72 | 8.4 s |
| 64 | I attack the goblin at the barricade with my staff. | Erzähler | open_run_duration | Try a generic attack wording to see if the System will register the goblin at all. | Mossback Warrens | 80/72 | 25.0 s |
| 65 | I swing my staff at the goblin with the rusted axe climbing the barricade. | Engine (Menü/Rückfrage) | open_run_duration | Engage the axe goblin now that the narrator has him mid-climb, hoping the scene has synced… | Mossback Warrens | 80/72 | 4.1 s |
| 66 | I swing my staff at the axe goblin on the barricade. | Engine (Menü/Rückfrage) | open_run_duration | Engage the axe goblin with the simplest possible attack wording to test scene sync. | Mossback Warrens | 80/72 | 5.0 s |
| 67 | #help | System (Befehl) | open_run_duration | Check the command list for a way to enter combat or register enemies as valid targets. | Mossback Warrens | 80/72 | 2.1 s |
| 68 | #combat | System (Befehl) | open_run_duration | Audit the encounter to see why the goblins are not valid targets. | Mossback Warrens | 80/72 | 2.4 s |
| 69 | #system How do I enter combat with the goblins behind the barricade when they are not listed as scene entities? | Erzähler | open_run_duration | Ask the System directly how to make the barricade goblins valid combat targets. | Mossback Warrens | 80/72 | 7.4 s |
| 70 | I climb over the goblin barricade to get past it. | Erzähler | open_run_duration | Interact with the barricade feature (feat.2) since no goblin actors are booked, hoping the… | Mossback Warrens | 80/72 | 22.4 s |
| 71 | I follow the drag marks down the passage, moving carefully. | Erzähler | open_run_duration | Advance the quest by following the drag marks deeper, past the barricade the goblins aren'… | Bone-strewn ritual chamber | 80/72 | 26.4 s |
| 72 | I examine the wooden whistle on the rope before touching it. | Erzähler | open_run_duration | Inspect the hanging whistle as a possible trap or goblin alarm sign before deciding which … | Bone-strewn ritual chamber | 80/72 | 27.8 s |
| 73 | I step over the trip-line without touching it, then crawl through the low passage slowly, watching for more lines ahead. | Erzähler | open_run_duration | Bypass the alarm trip-line and continue following the drag marks through the crawl. | Low crawl beyond the chamber | 80/72 | 27.4 s |
| 74 | I withdraw silently down the crawl, back toward the bone chamber, and then make my way back to Marta at the barricade. | Erzähler | open_run_duration | Disengage from the six-goblin warren and report what I found instead of dying at Level 1. | Barricade where Marta waits | 80/72 | 23.6 s |
| 75 | I tell Marta what I found: "Three goblins in a fire-lit chamber past the crawl — drag marks end at a covered man-sized shape on a stone shel… | Erzähler | open_run_duration | Report the scouting results and get Marta's input before committing to a fight at Level 1. | Barricade where Marta waits | 80/72 | 25.7 s |
| 76 | "We strike now, then. You take the doorway with the shield, I'll throw fire over your shoulder — starting with the unarmed one before he rea… | Erzähler | open_run_duration | Commit to Marta's plan and attack the three goblins at the fire now, while one is unarmed. | Barricade where Marta waits | 80/72 | 35.3 s |
| 77 | I cast Flame Lance at the unarmed goblin. | Engine (Menü/Rückfrage) | open_run_duration | Open the ambush with fire on the unarmed goblin, triggering Marta's charge. | Barricade where Marta waits | 80/72 | 4.4 s |
| 78 | I cast Flame Lance at the talking goblin standing apart by the fire. | Engine (Menü/Rückfrage) | open_run_duration | Open the ambush with fire on the unarmed talking goblin so Marta charges as planned. | Barricade where Marta waits | 80/72 | 4.8 s |
| 79 | I cast Flame Lance at the nearest goblin. | Engine (Menü/Rückfrage) | open_run_duration | Retry the attack with a simple scene target so the fire goes off and Marta charges. | Barricade where Marta waits | 80/72 | 3.7 s |
| 80 | I step out from behind cover and cast Flame Lance at a goblin warrior. | Engine (Menü/Rückfrage) | open_run_duration | Get the attack to register by naming the enemy type plainly after three rejected target de… | Barricade where Marta waits | 80/72 | 4.4 s |
| 81 | I cast Flame Lance at the goblin. | Engine (Menü/Rückfrage) | open_run_duration | Try the plainest possible target name to get the fire to register. | Barricade where Marta waits | 80/72 | 8.1 s |
| 82 | Marta, the System shows only you in the chamber — where are the three goblins? I can't target them. | Erzähler | open_run_duration | Resolve the scene-sync block by asking Marta directly whether the goblins are actually the… | Barricade where Marta waits | 80/72 | 21.5 s |
| 83 | They went deeper, then — we push in quiet and see where the drag marks lead. Marta, keep low and watch our backs. | Erzähler | open_run_duration | Continue the delve with Marta, tracking the goblins deeper past the barricade. | Bone-strewn ritual chamber | 80/72 | 26.5 s |
| 84 | Before we crawl in — Marta, look behind those sleepers: I thought I saw a boot move in one of the bundles. Then we follow the marks down. | Erzähler | open_run_duration | Check the twitching bundle behind the sleepers before committing to the crack. | Flooded gallery below the low crack | 80/72 | 36.2 s |
| 85 | I hold still and whisper: "Marta — that's a shaman singing to the moss. We're not ready for it. I say we slip back out and come back prepare… | Erzähler | open_run_duration | Decide with Marta whether to withdraw from the shaman or try to sneak past. | Flooded gallery below the low crack | 80/72 | 23.0 s |
| 86 | "Back out, now," I whisper, and start backing up the flooded path toward the crack, slow and quiet, lantern shuttered. | Erzähler | open_run_duration | Withdraw quietly with Marta before the shaman finds us. | Fire-lit goblin chamber | 80/72 | 33.1 s |
| 87 | "Out first," I whisper. "We eat, we think, we come back with fire and oil and a plan — the shaman keeps, but not past tomorrow." | Erzähler | open_run_duration | Withdraw fully to the cleared camp, rest and plan a prepared return against the shaman. | Duskreach | 80/72 | 33.3 s |
| 88 | "Honestly? I want to know what they dragged down there — that shelf's burden and the man it came from. And there's a locket on the bones I m… | Erzähler | open_run_duration | Give Marta a plain answer about our goal and agree on a prepared return plan. | Duskreach | 80/72 | 22.8 s |
| 89 | "The smith first," I say, standing and brushing crumbs off. "He'll want the tale of the drag marks, and he may know whose bones those are — … | Erzähler | open_run_duration | Report to the smith, learn the dead man's identity and kin, and price oil for the return. | the smith's yard | 80/72 | 31.8 s |
| 90 | "Cut in, yes — worked stone, and Marta says there's a lintel over it. You know what sat on that shelf. Tell us whose bones those are, and wh… | Erzähler | open_run_duration | Confirm the shelf's description to the smith and press him for the dead man's identity and… | the smith's yard | 80/72 | 32.0 s |
| 91 | "Both, honestly — the locket for his sister, and what's on the shelf, because I want to know what a dead drover was hiding down a flooded wo… | Erzähler | open_run_duration | Accept the smith's quest offer for the lead bars, front the oil and iron, and confirm Mart… | the smith's yard | 80/72 | 38.9 s |
| 92 | "Agreed — Marta carries the lantern, we go in the morning. I'll call on Brenna tonight and tell her how he lay. We'll be back for the knife … | Erzähler | open_run_duration | Confirm the morning plan with Marta and Halfrid, then head to Brenna's blue-door house wit… | the smith's yard | 80/72 | 21.7 s |
| 93 | I find the house with the blue door past the second bridge and knock, asking for Brenna. | Erzähler | open_run_duration | Call on Trud's sister Brenna tonight to return the locket and tell her how he lay. | Brenna's house, the blue door past the second bridge | 80/72 | 25.6 s |
| 94 | I step inside and take the chair, holding the locket out to her. "Found him decent, Brenna — laid peaceful where the goblins dragged him, ar… | Erzähler | open_run_duration | Return the locket and tell Brenna plainly how Trud lay. | Brenna's house, the blue door past the second bridge | 80/72 | 39.4 s |
| 95 | "Honest answer, Brenna — I saw no boots and no ring where he lay. But we go back down at first light, and I'll look for anything of his and … | Erzähler | open_run_duration | Answer Brenna honestly and promise to search for Trud's belongings on the return trip. | Brenna's house, the blue door past the second bridge | 80/72 | 24.0 s |
| 96 | "Two things, Brenna, and I'll say them plain: someone crossed his arms after the goblins dragged him — goblins don't do that. And in their c… | Erzähler | open_run_duration | Answer Brenna's question honestly about the crossed arms and the bound figure in the gobli… | Brenna's house, the blue door past the second bridge | 80/72 | 47.5 s |
| 97 | "I'll do that — his boot first if it's his, and if it's not, someone will hear who it was. The byre bed suits me fine, and I'll be at the fo… | Erzähler | open_run_duration | Accept Brenna's boot-bundle quest and take the offered bed in the byre for the night. | Brenna's house, the blue door past the second bridge | 80/72 | 26.2 s |
| 98 | I walk in through the open yard gate and call out over the ring of the hammer: "Morning — I'm here for the knife and the lamp oil, and we'll… | Erzähler | open_run_duration | Collect the fronted knife and lamp oil from the smith at first light before heading to the… | the smith's yard | 80/72 | 35.0 s |
| 99 | I take the knife and lantern off the rail, thank the smith, and fall in with Marta. "Lead the way — I'm ready." | Erzähler | open_run_duration | Collect the knife and lantern and set out for the warrens with Marta at first light. | the smith's yard | 80/72 | 167.4 s |
| 100 | "Up the rocks on the left — we look first, and count them proper before we pick a fight." | Erzähler | open_run_duration | Take the hidden approach up the rocks to scout the goblin camp with Marta. | the smith's yard | 80/72 | 31.6 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 1 (notiert vor Zug 2): Skill pool shows real costs and formulas; starter gear will auto-equip on completion.
- zu Zug 2 (notiert vor Zug 3): Character creation completed cleanly; starter gear auto-equipped and stats match the Mage bonuses.
- zu Zug 3 (notiert vor Zug 4): Guild registration is not yet done (Guild Rank shows 'not registered'); asking the clerk about it now.
- zu Zug 4 (notiert vor Zug 5): Registration costs 2 of my 5 silver; clerk is waiting for payment before writing.
- zu Zug 5 (notiert vor Zug 6): Registration completed cleanly: plate issued, Power Rank F recorded, coin deducted properly (50→30 copper shown as 3 Silver in HUD). Note: clerk said 'nothing for a new mage today' despite board slips turning over quickly.
- zu Zug 6 (notiert vor Zug 7): Board had no novice contracts; clerk offered the Mossback Warrens as unsanctioned private work and mentioned midday postings. Engine correctly blocked taking a plate I already held.
- zu Zug 7 (notiert vor Zug 8): Clerk gave concrete broker prices (goblin ears 2c) and warned the shaman throws fire on the second tunnel; solo F-rank dive is risky but the entry ledger is free.
- zu Zug 8 (notiert vor Zug 9): Ledger entry logged cleanly at 09:25; heading to the market to spend part of my 3 silver on supplies.
- zu Zug 9 (notiert vor Zug 10): Shopkeeper gave concrete prices (waterskin 1s, rope 3c, knife 8c); buying supplies within my 3 silver budget.
- zu Zug 10 (notiert vor Zug 11): Purchase engine worked cleanly: -13 copper, HUD coin updated 30→17. Rations and oil priced by the merchant before purchase.
- zu Zug 11 (notiert vor Zug 12): Minor inventory discrepancy: I paid for two dried ration bundles but the HUD lists only one. Also, HUD shows '1 Silver 3 Copper' matching 13 copper — consistent.
- zu Zug 12 (notiert vor Zug 13): Still carrying only one dried ration bundle despite paying for two; I'll watch whether future purchases book correctly. World state and travel time are tracking consistently.
- zu Zug 13 (notiert vor Zug 14): Search roll failed outright (d100 100) yet narration still showed no enemies — watch whether the failed PER check has hidden something from me rather than the screen.
- zu Zug 14 (notiert vor Zug 15): HUD shows Quests: — although I traveled here for a Warrens job; the contract may never have been booked. Also no light source beyond lamp oil, and the tunnel bends dark after fifteen paces.
- zu Zug 15 (notiert vor Zug 16): Quests panel still shows nothing; the Warrens contract appears never to have been booked despite Guild plate in inventory.
- zu Zug 16 (notiert vor Zug 17): Quests panel still empty despite the Warrens job; also the board note says new contracts appear with the midday cart, a hook to check back in town.
- zu Zug 17 (notiert vor Zug 18): Scene panel confirms one MEDIUM brute, HP 54; more goblin voices deeper in. I risk a first strike while it sleeps rather than face it awake plus reinforcements.
- zu Zug 18 (notiert vor Zug 19): Ambush crit one-shot the 54 HP brute for 57 damage; loot and XP booked cleanly in the panel. Quests panel still shows nothing despite traveling here for the Warrens job.
- zu Zug 19 (notiert vor Zug 20): Clean withdrawal; goblins stirred but did not pursue. Loot panel booked knife and 1 cp; sling-bag contents still unknown. Quests panel remains empty despite the Warrens job.
- zu Zug 20 (notiert vor Zug 21): Quests panel still empty despite the Warrens job; board was stripped, new contracts promised with the midday cart.
- zu Zug 21 (notiert vor Zug 22): Loot opened cleanly: 11 coppers + possible silver, brooch, locket, resin. Quests panel still empty despite the Guild plate and the Warrens job; the contract-booking chain has never registered.
- zu Zug 22 (notiert vor Zug 23): Quests panel still empty; clerk confirmed contracts post in the morning and pointed to patrons for tonight's work. Loot is found goods, must be sold in town, not via Guild.
- zu Zug 23 (notiert vor Zug 24): Search for tonight's work failed cleanly (d100 99); no paid work available until morning board, so I pivot to the locket/smithy lead. Coin and HUD consistent.
- zu Zug 25 (notiert vor Zug 26): Locket opened cleanly for 2 copper; coin booked correctly (14→12 copper). Quests panel still empty; morning board remains the next contract source.
- zu Zug 26 (notiert vor Zug 27): Marta pointed to the Guild's crown-charter ledger as the only record of who entered the Warrens; Watch pays nothing for names without a body.
- zu Zug 28 (notiert vor Zug 29): Ledger confirmed Trud Askel's-son entered the Warrens 19 days ago, no exit mark; hunter says goblin teeth pay a copper apiece at the broker. HUD now shows the locket note as a mystery lead; no quest booked yet.
- zu Zug 29 (notiert vor Zug 30): No Guild contract or payout possible for Trud without a client; the clerk points to his kin on the quarry track as the paying party. HUD consistent.
- zu Zug 30 (notiert vor Zug 31): Lodging prices are concrete and cheap (1 copper pottage, 1 copper loft, half-copper straw); coin 1s2c covers it with margin.
- zu Zug 31 (notiert vor Zug 32): Night passed cleanly; coin 10 copper, MP 56/72 not shown as recovering yet—worth checking after rest.
- zu Zug 32 (notiert vor Zug 33): Rest recovered MP fully (56→72); recovery mechanics working. Coin 10 copper, HUD consistent.
- zu Zug 33 (notiert vor Zug 34): Engine refused the breakfast payment because the innkeeper was in the yard—coin stayed at 10 copper, yet HUD now reads 1 Silver with no conversion shown. Possible coin display inconsistency worth watching.
- zu Zug 34 (notiert vor Zug 35): No HUD change since last turn; the coin display still reads 1 Silver with no breakdown, and the unpaid breakfast copper remains an open inconsistency.
- zu Zug 35 (notiert vor Zug 36): HUD still shows 1 Silver with no copper breakdown; the unpaid breakfast copper remains an open bookkeeping inconsistency.
- zu Zug 36 (notiert vor Zug 37): Quest 'take the locket to his kin' still shows on HUD though delivery is essentially done; coin display still 1 Silver with no copper breakdown.
- zu Zug 37 (notiert vor Zug 38): A proper QUEST OFFERED panel appeared for the deeper Warrens job—first time the engine has formalized a private quest offer. Still Level 1 with 32/100 XP; negotiating gear before accepting a second goblin dive seems sensible.
- zu Zug 38 (notiert vor Zug 39): Smith offered concrete prices: 2 silver for the return, +1 silver and hearth-right for Trud's body, hunting knife at 8 copper. Coin 1 Silver should cover it, but the engine's coin bookkeeping (earlier unpaid copper, unexplained 1 Silver) needs watching through this purchase.
- zu Zug 39 (notiert vor Zug 40): Purchase panel shows COIN 10 → 2 copper, but the HUD previously read 1 Silver with no copper breakdown—the engine seems to have treated 1 Silver as 10 copper silently. Knife now bought but likely not yet equipped; I'll verify on the HUD next turn.
- zu Zug 40 (notiert vor Zug 41): Oddity: the HUD 'Equipped' slot still lists the knife by its unfinished rack description, though the smith handed over the edged blade—item text may not have updated with the purchase.
- zu Zug 41 (notiert vor Zug 42): Equipped slot still shows the knife by its unfinished rack description despite the smith handing over the edged blade—item text not updated in HUD.
- zu Zug 42 (notiert vor Zug 43): The smith asked directly about my light and oil; the slate map is now a carried item. Coin stands at 2 Copper with no lantern or flint in the bag.
- zu Zug 43 (notiert vor Zug 44): ITEM panels confirmed the horn lantern and strike-a-light; equipped knife description still stale in the HUD.
- zu Zug 44 (notiert vor Zug 45): Coin shows 2 Copper with no silver breakdown; the equipped knife description in the HUD is still the stale unfinished-rack text despite the smith delivering the edged blade.
- zu Zug 45 (notiert vor Zug 46): The low passage holds fresh goblin-like prints and knocking ahead; the equipped knife description in the HUD is still the stale unfinished-rack text.
- zu Zug 46 (notiert vor Zug 47): Search check vs the crack failed (d100 98) and revealed nothing; knocking has stopped. Stale equipped-knife text persists in HUD.
- zu Zug 47 (notiert vor Zug 48): Fresh goblin-like prints and a drag groove both lead down toward a weak firelight and a live-animal smell; knocking pattern suggests deliberate signaling.
- zu Zug 48 (notiert vor Zug 49): Five MEDIUM goblins (45 HP each) around a fire with what looks like a dragged body; a Level 1 solo fight would be suicidal, so withdrawing is the sensible read. The tapper's knocking seems to be idle noise, and it reacted to something behind, not to me.
- zu Zug 49 (notiert vor Zug 50): Stealth failed on withdrawal (d100 98 again — two 98s in a row feels suspicious); goblins spotted me but held at the fire's edge instead of charging, and a captive's boot twitched. HUD oddly lists location as the open slope while the scene is underground.
- zu Zug 50 (notiert vor Zug 51): Goblins doused their fire and didn't pursue; the tapping rhythm moved elsewhere in the warrens, suggesting more goblins or a signaling network. The captive with the twitching boot remains a lead I'm abandoning for now—too strong for Level 1.
- zu Zug 51 (notiert vor Zug 52): Escaped the warrens cleanly; goblins doused fire and did not pursue. HUD still shows stale equipped-knife text while carried list holds the crude goblin knife.
- zu Zug 52 (notiert vor Zug 53): HUD still lists the knife as 'Equipped' while it actually sits on the rack un-edged; engine text and HUD disagree.
- zu Zug 53 (notiert vor Zug 54): The twitching boot among the sleepers hints a captive may be alive in the camp; the smith is edging toward asking for a rescue I can't solo at Level 1 — gear and payment negotiation coming.
- zu Zug 54 (notiert vor Zug 55): Quest offered for the deeper rescue with Marta and iron gear; HUD equipped line still shows the stale knife text and my coin is only 2 Copper, so the promised gear will matter.
- zu Zug 55 (notiert vor Zug 56): HUD equipped line still stale (knife text) while quest panel correctly shows the deeper rescue as offered; Marta is ENGAGED and demanding a direct answer before gear is handed out.
- zu Zug 56 (notiert vor Zug 57): Quest panel now shows the deeper rescue as offered alongside the active one; HUD equipped line still carries the stale knife text while the finished drover's knife sits on the bench.
- zu Zug 57 (notiert vor Zug 58): Shortsword now correctly shows on the Equipped line — the stale knife text is resolved. The deeper rescue quest still reads 'offered' rather than active despite my acceptance; marching to see if it converts.
- zu Zug 58 (notiert vor Zug 59): Both rescue quests now read active in the HUD; shortsword equipped line confirmed. Note: the HUD 'Leads' still says Marta waits at the gate for my answer, which is stale — she's already marching with me.
- zu Zug 59 (notiert vor Zug 60): Five goblins behind a fresh barricade and one hammering an alarm that carries deeper — the earlier 'goblins ran' read was stale; the HUD 'Leads' still wrongly claims Marta waits at the gate.
- zu Zug 60 (notiert vor Zug 61): The System rejected my last Flame Lance because the target 'goblin up on the slab' wasn't registered as valid in the scene, so nothing was spent; also the HUD dungeon card says inside 0/8 while we are already inside, and the Leads still show stale gate/smith prompts.
- zu Zug 61 (notiert vor Zug 62): Third target rejection: the System only accepts 'ACTIVE SCENE — Marta · SHORT', suggesting the goblins aren't registered as scene entities yet — a scene-sync oddity between narrator and engine.
- zu Zug 62 (notiert vor Zug 63): The System only recognises Marta as a scene entity, so three attack attempts were rejected without spending MP — a scene-sync bug where the barricade goblins aren't registered as valid targets.
- zu Zug 63 (notiert vor Zug 64): Fourth target rejection; only Marta is a valid scene entity. If a generic 'the goblin' also fails, the barricade encounter is unresolvable and I'll fall back to a different approach.
- zu Zug 64 (notiert vor Zug 65): The narrator finally ran the charge narratively despite the System rejections; the axe goblin is now climbing the barricade to meet me, but the HUD still lists only Marta in the scene.
- zu Zug 65 (notiert vor Zug 66): Fifth consecutive target rejection; the System still registers only Marta as a scene entity while the narrator runs the goblins normally.
- zu Zug 66 (notiert vor Zug 67): Six consecutive target rejections: the System only registers Marta as a scene entity while the narrator runs the goblins normally, making the barricade fight unresolvable through normal attack wording.
- zu Zug 67 (notiert vor Zug 68): Six attack rejections so far; #help revealed #combat and #audit commands which may expose the scene-sync problem.
- zu Zug 68 (notiert vor Zug 69): #combat shows Combat INACTIVE and says a dangerous scene stays inactive 'until a hostile commitment' — the rejections may be because no formal combat start was registered, not because the goblins don't exist.
- zu Zug 69 (notiert vor Zug 70): System confirms combat needs engine DUNGEON lines to book foes; the barricade goblins are only narrative, making them untargetable. Trying the obstacle route instead.
- zu Zug 70 (notiert vor Zug 71): Crossing the barricade succeeded via a feature check; the goblins remain narrative-only and unbooked, so the quest can progress by simply walking past them.
- zu Zug 71 (notiert vor Zug 72): The chamber HUD lists 'Present: nobody besides Alaric' while Marta is narratively just behind the barricade; also no goblins are booked anywhere despite the warrens being described as full of them.
- zu Zug 73 (notiert vor Zug 74): HUD books six goblin warriors but the narrative shows only three in the chamber — the same scene-sync mismatch as the barricade. Quest leads now confirm the shelf is likely Trud, so retreating to report is legitimate progress.
- zu Zug 74 (notiert vor Zug 75): HUD now books 3 goblin warriors at the barricade level while the deeper chamber showed 3 more (HUD earlier claimed six) — the scene-sync mismatch persists, but the deeper three were only shown narratively with HP for two. Quest text still shows truncated placeholder wording ('to find wh').
- zu Zug 75 (notiert vor Zug 76): Marta offers a concrete tactical plan and defers to Alaric's call; HUD still books 3 goblins at this level and 3 deeper, consistent with the scouting. Quest text remains truncated ('find wh'), a minor contract-text bug.
- zu Zug 76 (notiert vor Zug 77): HUD still shows 3 goblin warriors at level 1 while the deeper chamber's 3 aren't booked anywhere — scene-sync mismatch persists. MP is 72/72, enough for multiple Flame Lances.
- zu Zug 77 (notiert vor Zug 78): First Flame Lance attempt was rejected as invalid target ('the unarmed goblin') with nothing spent — target naming must match scene entities; retrying with the goblin the narrative actually shows standing apart.
- zu Zug 78 (notiert vor Zug 79): Two Flame Lance attempts rejected as invalid targets though the scene text clearly describes the goblins — target naming is extremely strict; scene still says 'Marta · ENGAGED' with no goblin entities listed.
- zu Zug 79 (notiert vor Zug 80): Third rejected target; the System hint 'which target — Marta?' suggests the scene only registers Marta as present despite the HUD booking 3 goblin warriors alive — the fight may not actually be engaged.
- zu Zug 80 (notiert vor Zug 81): Fourth rejected target attempt; the System only registers Marta in the active scene despite the HUD booking 3 goblin warriors alive — a hard scene-sync block on combat.
- zu Zug 81 (notiert vor Zug 82): Fifth target rejection; the active scene persistently lists only Marta while the HUD books 3 goblin warriors alive at level 1 — a hard contradiction. Asking an NPC in-scene instead of retrying attack syntax.
- zu Zug 82 (notiert vor Zug 83): Narrator confirmed the chamber is empty and the goblins left with the covered shape, yet the HUD still books 3 goblin warriors alive at level 1 — the contradiction persists on the HUD side only. Also noting an unspent lead: Marta still awaits Alaric's direct answer about taking her in.
- zu Zug 83 (notiert vor Zug 84): HUD still books 3 goblin warriors alive while the narrator confirms the chamber is empty and they left through the crack — the scene/HUD contradiction persists. A new lead appeared: a booted foot twitching in a bundle behind the sleepers.
- zu Zug 84 (notiert vor Zug 85): HUD now shows the Moss Shaman (433 HP, MEDIUM threat) in the active scene — a level 1 party of two facing an E-rank boss; the 3 goblin warriors still booked alive though confirmed gone.
- zu Zug 85 (notiert vor Zug 86): The Moss Shaman (433 HP, MEDIUM) is now actively pinging the moss to locate us; sensible withdrawal chosen. HUD still books 3 goblin warriors alive with no trace of them.
- zu Zug 86 (notiert vor Zug 87): Clean withdrawal succeeded; HUD still books 3 goblin warriors alive with no trace in the cleared chamber — the scene/HUD contradiction persists.
- zu Zug 87 (notiert vor Zug 88): HUD now correctly shows us outside at the quarry track and Marta present, but still books the 3 goblin warriors as alive in the active scene while the narrator places them chattering elsewhere — the contradiction persists. Quest text oddly still says 'go deeper past the five goblins'.
- zu Zug 88 (notiert vor Zug 89): Coin is only 2 copper while Marta suggests buying more oil — money is a real constraint. HUD still books the 3 goblin warriors as alive in the active scene even though we're outside at the quarry track and they're elsewhere in the warren.
- zu Zug 89 (notiert vor Zug 90): Coin still only 2 copper while we plan to buy oil — money remains a real constraint pending the smith's answers or a purse from the bones.
- zu Zug 90 (notiert vor Zug 91): A third quest was formally offered (sealed lead bars); accepting should also let the smith front oil and iron against the find — the first real way past our 2-copper constraint. Coin still 2 copper in HUD, so nothing has been booked yet.
- zu Zug 91 (notiert vor Zug 92): Third quest formally accepted and oil/iron fronted as a loan — a real path past our 2-copper problem. HUD now shows flask of lamp oil carried; knife still pending as a promise, correctly not in inventory.
- zu Zug 92 (notiert vor Zug 93): Knife and lantern oil still pending at the smith's for morning; HUD shows flask of lamp oil already carried.
- zu Zug 93 (notiert vor Zug 94): A fourth quest was offered (say it plain) — the locket handover is still pending; HUD shows the locket presumably among the +6 unlisted bag items.
- zu Zug 94 (notiert vor Zug 95): A fourth quest was offered (bring back anything of Trud's). HUD still lists the locket among unlisted bag items despite handing it over narratively — worth watching.
- zu Zug 95 (notiert vor Zug 96): Broth and seed loaf gained as advance payment; HUD bag count went from +6 to +8, consistent with the two items. Fourth quest (Trud's belongings) appears in narrative but not yet in the visible quest list.
- zu Zug 96 (notiert vor Zug 97): A fifth quest was offered (the bundle/boot); HUD quest count and bag items keep tracking narrated gains consistently. Still only 2 copper, but food and lodging are covered by quest gifts.
- zu Zug 97 (notiert vor Zug 98): Time jumped from Day 3 evening to a pre-dawn Day 4 scene in the narration while the HUD still reads Day 3, 18:25 — a narration/HUD time mismatch worth noting.
- zu Zug 98 (notiert vor Zug 99): HUD still reads Day 3, 18:40 evening while narration says pre-dawn — the time mismatch continues. Knife and lantern received as narrated; HUD bag not yet visibly updated.
- zu Zug 99 (notiert vor Zug 100): Engine blocked taking the knife because I supposedly already hold it, and HUD time still reads Day 3, 19:25 despite a full night's sleep — both ongoing inconsistencies. Smoke and movement at the camp suggest roughly 2–3 goblins visible, fewer than the reported five.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t18 | 18 | 1 | – | nein | 1 | gewonnen, 32 XP |

## Quests

- **Go back into the Mossback Warrens past the camp, down the drag marks, to find wh** — active (Zug 38), READY
- **Go deeper past the five goblins with gear and Marta to find what keeps Trud** — active (Zug 58), READY
- **Find what was on the shelf — the smith's sealed lead bars** — active (Zug 91)

## Auffälligkeiten

- Zug 6, Nachricht 11 (board_failed): the board generator failed
- Zug 24, Nachricht 48 (extraction_repaired): the extractor's first answer needed a repair
- Zug 35, Nachricht 69 (planner_repaired): the planner's first answer needed a repair
- Zug 36, Nachricht 72 (extraction_repaired): the extractor's first answer needed a repair
- Zug 52, Nachricht 103 (planner_repaired): the planner's first answer needed a repair
- Zug 59, Nachricht 118 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (goblin): refused, no fight (Patch 8.4.1 guard)
- Zug 64, Nachricht 128 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (goblin): refused, no fight (Patch 8.4.1 guard)
- Zug 71, Nachricht 142 (extraction_repaired): the extractor's first answer needed a repair
- Zug 73, Nachricht 146 (unslotted_dungeon_creature): goblin warrior came into Mossback Warrens without an encounter of the engine (for review)
- Zug 73, Nachricht 146 (unslotted_dungeon_creature): goblin warrior came into Mossback Warrens without an encounter of the engine (for review)
- Zug 73, Nachricht 146 (unslotted_dungeon_creature): goblin warrior came into Mossback Warrens without an encounter of the engine (for review)
- Zug 76, Nachricht 152 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (goblin): refused, no fight (Patch 8.4.1 guard)
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 53× keine gültige JSON-Entscheidung (Züge 1, 3, 4, 5, 6, 7, 8, 9, 10, 13, 16, 17, 19, 21, 23, 25, 26, 27, 28, 29, 30, 31, 32, 35, 36, 37, 42, 43, 44, 45, 46, 47, 48, 52, 53, 55, 59, 61, 62, 63, 66, 67, 68, 71, 72, 73, 78, 85, 92, 93, 94, 98, 99)

System-Panels: CLARIFY 0, NOT TAKEN 1, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: guild_canon 5, engine_owned_fact 3, engine_owned_memory 1, ambient 4, world_rule 7, no_go 4, passage 4, place 1, pc_inventory 6, offer 1, object 1, group_unclear 2, domain_fact 1, dungeon_foe 3, engine_owned_combat 2, time_cap 1, engine_booked 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 97 | 2 | 2.8 s | 6.2 s | 11096 | 9529 | 82 | – | stop 97 | 0 |
| narrator | 85 | 0 | 12.2 s | 18.7 s | 11185 | 8476 | 475 | – | stop 85 | 0 |
| extract | 87 | 3 | 7.3 s | 15.0 s | 9793 | 8086 | 509 | – | stop 87 | 0 |
| board | 2 | 1 | 16.9 s | 19.8 s | 2546 | 1078 | 999 | – | stop 2 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 57:58 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 62.6 s) | 1:20 min |
| 100 Züge, Spiel (Senden bis HUD nach der Extraktion) | 44:22 min — Median 24.9 s, p90 39.4 s, max 167.4 s |
| 100 Züge, Spieler-Entscheidung | 10:19 min — Median 4.4 s, 53 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 6:38 min / 0:34 min / 20:37 min / 12:49 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 32.8 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 21:52 min, 80 Züge ≈ 43:45 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spiel | 99 | – | 167.4 s | 24.9 s |
| Provider narrator | 99 | 267 | 154.6 s | 12.2 s |
| Provider extract | 30 | 87 | 46.8 s | 7.3 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
