# Avereth Live-Test 20261025-081303Z-current_test

## Kurzfassung

- **Ergebnis:** abgeschlossen: alle Pflicht-Etappen erreicht
- **Etappen:** 2/2 Pflicht erreicht
- **Charakter:** mage (mage.arcane_bolt, mage.flame_lance) · Regelstand 2 (Warrior, Mage, Rogue)
- **Ziel-Dungeon:** Glimmerdeep Grotto, Ebene 1 (ohne Dungeon-Vertrag: der erste betretene)
- **Leitfaden:** current_test („Open-world long playtest — a real adventurer's life“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: curious opportunist: pursue interesting work and discoveries, develop your own ambitions
- **Züge:** 100 · **Dauer:** 77:21 min · **LLM-Aufrufe der Engine/des Erzählers:** 288
- **Auffälligkeiten:** 12
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.82 |
| Git | d9476455a745 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 16.3 s |
| Browser | chrome 155.0.8059.85 |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261025-081303Z-current_test“, Seed 1123605938 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_duration | ja | ✔ | 100 | 200 |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | I choose Mage. | Engine (Menü/Rückfrage) | creation_complete | Select Mage as base class. | public roadside verge outside Glassmere | 80/60 | 2.2 s |
| 2 | I pick Arcane Bolt and Flame Lance. | Engine (Menü/Rückfrage) | creation_complete | Finish character creation with two offensive starter skills. | public roadside verge outside Glassmere | 80/72 | 2.1 s |
| 3 | I walk toward the city gates of Glassmere. | Erzähler | open_run_duration | Enter Glassmere and look for the adventurer's guild or contract board. | Glassmere city gates | 80/72 | 48.2 s |
| 4 | I join the queue and, when it's my turn, ask the guard where a new mage can find the adventurer's guild. | Erzähler | open_run_duration | Enter Glassmere and get directions to the adventurer's guild from the guard. | Glassmere | 80/72 | 23.2 s |
| 5 | I follow the guard's directions down Gate Street, past the fountain, left at the fork, and look for the timber-framed building with the swor… | Erzähler | open_run_duration | Reach the adventurer's guild hall and register before midday. | Adventurers' Guild hall, Glassmere | 80/72 | 67.6 s |
| 6 | I step inside, ring the bell, and ask the clerk to register me as a new adventurer. | Erzähler | open_run_duration | Register at the Guild hall before midday. | Adventurers' Guild hall, Glassmere | 80/72 | 17.9 s |
| 7 | I pay the two silver, say "Alaric Red," and touch the measuring stone. | Erzähler | open_run_duration | Register at the Guild by paying the fee and giving my name. | Adventurers' Guild hall, Glassmere | 80/72 | 22.1 s |
| 8 | "Tell me more about Glimmerdeep — what do the crystal and beetle parts fetch, and is there anything dangerous past the outer grottos?" I als… | Erzähler | open_run_duration | Get details on Glimmerdeep and check the board for a first contract. | Adventurers' Guild hall, Glassmere | 80/72 | 78.5 s |
| 9 | "Sorted, thanks." I ask the clerk for directions to Glimmerdeep and whether there's a good shop in town for supplies before I head out. | Erzähler | open_run_duration | Get directions to Glimmerdeep and a tip on where to buy supplies. | Adventurers' Guild hall, Glassmere | 80/72 | 20.5 s |
| 10 | I head to Marren's General Goods on the square and ask what he has in torches, dried food, a waterskin and rope, and at what prices. | Erzähler | open_run_duration | Buy basic supplies for the Glimmerdeep cull before leaving town. | Marren's General Goods | 80/72 | 19.7 s |
| 11 | I'll take five torches, two sausage, a handful of biscuits, and twenty feet of rope — what's the total? | Erzähler | open_run_duration | Buy basic supplies for the Glimmerdeep cull within my 3 silver. | Marren's General Goods | 80/72 | 20.2 s |
| 12 | I agree and pay the one silver and nine copper, then ask Marren: does anyone in town buy beetle parts and crystal shards? | Erzähler | open_run_duration | Buy the supplies and learn where to sell Glimmerdeep loot. | Marren's General Goods | 80/72 | 41.3 s |
| 13 | "That's all, thanks." I bundle the torches and supplies and head out toward Glimmerdeep, following the directions the clerk gave me. | Erzähler | open_run_duration | Leave town for the Glimmerdeep beetle cull with my new supplies. | Glimmerdeep Grotto | 80/72 | 22.3 s |
| 14 | I enter the Glimmerdeep Grotto and pay the ten copper gate fee. | Erzähler | open_run_duration | Enter the dungeon and start the beetle cull. | Glimmerdeep Grotto | 80/72 | 32.7 s |
| 15 | I cast Flame Lance at the nearer beetle. | Engine (Menü/Rückfrage) | open_run_duration | Engage the two beetles, starting with a Flame Lance on the closest one. | Glimmerdeep Grotto | 80/72 | 4.2 s |
| 16 | I cast Flame Lance at the beetle with its head lowered toward me. | Engine (Menü/Rückfrage) | open_run_duration | Retarget Flame Lance at a beetle using scene-anchored wording. | Glimmerdeep Grotto | 80/72 | 7.0 s |
| 17 | I cast Flame Lance at a crystal beetle. | Engine (Menü/Rückfrage) | open_run_duration | Get the combat engine to recognize the beetles with a plain target name. | Glimmerdeep Grotto | 80/72 | 4.1 s |
| 18 | I look around the chamber carefully, staff ready. | Erzähler | open_run_duration | Prompt the narrator to re-describe the scene so the combat engine registers the beetles. | Glimmerdeep Grotto | 80/72 | 55.4 s |
| 19 | I gather the shed crystal plates into my pouch, then follow the tracks through the low crack. | Erzähler | open_run_duration | Collect the free crystal loot and follow the tracks deeper where the clicking went. | Vein chamber | 80/72 | 59.2 s |
| 20 | I cast Flame Lance at the darker beetle. | Erzähler | open_run_duration | Engage the two beetles now that the engine registers them, opening on the darker one. | Vein chamber | 68/56 | 73.0 s |
| 21 | I cast Flame Lance at the beetle in front of me. | Erzähler | open_run_duration | Finish the remaining beetle with Flame Lance before it bites again. | Vein chamber | 57/40 | 37.1 s |
| 22 | I finish it with a Basic Attack, driving my staff into the wounded beetle. | Erzähler | open_run_duration | Kill the 5-HP beetle with a cheap basic attack to save MP. | Vein chamber | 57/40 | 39.2 s |
| 23 | I bandage my thigh with a strip of cloth from my pouch, then gather up the chitin plates and venom gland before deciding whether to press de… | Erzähler | open_run_duration | Recover slightly, secure loot, then weigh pressing on versus withdrawing to town to sell a… | Vein chamber | 57/40 | 24.8 s |
| 24 | I rest for two hours, then head back out through the low crack passage toward the grotto's mouth. | Erzähler | open_run_duration | Rest two hours to recover HP/MP, then withdraw to town with the loot to sell it. | Grotto mouth | 74/65 | 23.6 s |
| 25 | I head down the road to Glassmere and make for the Guild hall to sell the beetle plates, venom gland and shed crystal. | Erzähler | open_run_duration | Return to town and sell my combat loot to a buyer. | Adventurers' Guild hall, Glassmere | 74/65 | 50.2 s |
| 26 | "Done — I'll take the five silver and eight for the lot." I push the goods across the counter to him. | Erzähler | open_run_duration | Accept the clerk's offer and sell all the beetle loot. | Adventurers' Guild hall, Glassmere | 74/65 | 41.9 s |
| 27 | "Thanks — I'll try that soup house." I pocket the coins, then ask, "And where's the cheapest honest bed in town? Somewhere I can sleep and k… | Erzähler | open_run_duration | Get food and a safe cheap lodging recommendation for the night. | Adventurers' Guild hall, Glassmere | 74/65 | 29.3 s |
| 28 | #assign INT 2 WIL 2 VIT 1 | System (Befehl) | open_run_duration | Spend the five free stat points earned at the last level-up. | Adventurers' Guild hall, Glassmere | 74/65 | 2.1 s |
| 29 | I go to the soup house and ask Maret for a bowl and bread. | Erzähler | open_run_duration | Eat a cheap supper at the soup house before finding lodging. | soup house past the cobbler's row | 74/65 | 44.3 s |
| 30 | "Bowl and bread, and an ale, please." I count out three copper. | Erzähler | open_run_duration | Buy supper and an ale at the soup house. | soup house past the cobbler's row | 74/65 | 63.1 s |
| 31 | "Yes, grotto work," I say, then nod toward the servants. "Those two keep glancing at my leg — do they need a mage for something, or is it ju… | Erzähler | open_run_duration | Probe whether the academy servants have paid work to offer. | soup house past the cobbler's row | 74/65 | 25.6 s |
| 32 | "What's the pay, and can I see the stores tonight?" I ask Dace. | Erzähler | open_run_duration | Ask Dace about pay and timing for the cold stores job. | soup house past the cobbler's row | 74/65 | 41.7 s |
| 33 | "I'll take the job at eight silver," I say. "Show me the stores now — I'd rather see the damage in the light before I sit in the dark for it… | Erzähler | open_run_duration | Accept the cold stores job and inspect the damage before nightfall. | college cold stores | 74/65 | 50.3 s |
| 34 | "Keep the lantern low and stay by the stair," I say. I set a torch ready by the cask shelf, then eat a handful of travel biscuits while we w… | Erzähler | open_run_duration | Prepare for the night encounter and recover a little MP before fighting. | college cold stores | 74/65 | 41.1 s |
| 35 | I strike the torch alight and hold it high, then cast Flame Lance toward the green eyes. | Engine (Menü/Rückfrage) | open_run_duration | Light the dark and open the fight with my strongest spell. | college cold stores | 74/65 | 8.3 s |
| 36 | I raise the torch high and advance slowly toward the green eyes, trying to force the creature to show itself. | Erzähler | open_run_duration | Reveal the creature so the System gives me a valid target before I cast. | college cold stores | 74/65 | 62.7 s |
| 37 | "It doesn't want a fight, and neither do I at full strength," I say without turning. "Wren — how did your uncle clear his? Smoke, noise, dig… | Erzähler | open_run_duration | Ask Wren for a nonviolent way to drive the grave-borer off before spending mana I don't ha… | college cold stores | 74/65 | 49.1 s |
| 38 | "Smoke it up and out, then we block the tunnel after," I say. "Dace — wet straw and green wood? Wren, you mentioned a bellows." | Erzähler | open_run_duration | Agree on the smoke-and-tunnel plan and gather materials for it. | college cold stores | 74/65 | 29.1 s |
| 39 | I light the straw and green wood and step back toward the stair with the others, letting the draught carry the smoke to the tunnel. | Erzähler | open_run_duration | Start the smudge fire and drive the borer out through its tunnel. | college cold stores | 74/65 | 38.9 s |
| 40 | "Pack it now, then," I say. I help Dace ram the rubble stones tight into the tunnel mouth and tamp earth behind them until the wall holds so… | Erzähler | open_run_duration | Seal the tunnel to finish the job properly, then collect payment. | college cold stores | 74/65 | 27.8 s |
| 41 | "First light works," I say. "Until then, is there a corner out of the cold where a mage can sleep a few hours? I'll want my wits about me wh… | Erzähler | open_run_duration | Finish the quest handoff and ask the servants for a place to sleep until morning. | college cold stores | 74/65 | 32.2 s |
| 42 | I settle onto the bench by the hearth and sleep until Dace wakes me at first light. | Erzähler | open_run_duration | Rest until morning, then collect the Steward's payment. | college cold stores | 90/108 | 20.9 s |
| 43 | "Ready," I say, and follow Dace up to the Steward's chamber for my eight silver. | Erzähler | open_run_duration | Collect the Steward's payment for the cold-stores job. | Steward's chamber | 90/108 | 36.3 s |
| 44 | I tell him plainly: the crystal came out of the flooded cellar dig, Master Holm examined it, and it's lodged with the Guild now — I can fetc… | Erzähler | open_run_duration | Answer the Steward's crystal question honestly to get the eight silver paid. | Steward's chamber | 90/108 | 33.3 s |
| 45 | I take the eight silver, thank him, and follow Dace down for the warm bread. | Erzähler | open_run_duration | Collect the eight silver and leave with Dace. | college kitchen | 90/108 | 37.8 s |
| 46 | #status | System (Befehl) | open_run_duration | Check whether the eight silver actually reached my purse. | college kitchen | 90/108 | 2.2 s |
| 47 | "Back to the Guild," I say. "A paid mage needs better work than lost goats." I thank Dace for the bread and head for the Guild hall to see w… | Erzähler | open_run_duration | Leave the college and return to the Guild hall for new work. | Adventurers' Guild hall, Glassmere | 90/108 | 69.7 s |
| 48 | "The runner job sounds good — where do I find this merchant with the letter for Millbrook?" | Erzähler | open_run_duration | Take the private letter-courier job and get the merchant's location. | Adventurers' Guild hall, Glassmere | 90/108 | 36.0 s |
| 49 | "Master Ovell? The Guild clerk sent me — I hear you need a runner to Millbrook with a sealed letter." | Erzähler | open_run_duration | Introduce myself to Ovell and take the courier job. | Adventurers' Guild hall, Glassmere | 90/108 | 25.2 s |
| 50 | "That's me — I've just come from Master Ovell's shop on Cooper's Row, where he's at his counter this minute. I'm taking the runner job. What… | Erzähler | open_run_duration | Accept the courier quest formally with the Guild clerk so it registers as taken, not just … | Adventurers' Guild hall, Glassmere | 90/108 | 19.4 s |
| 51 | I go back to Cooper's Row and step into the wool factor's shop again. "Master Ovell — the clerk says the bargain's yours to strike. I'll run… | Erzähler | open_run_duration | Accept the courier job from Ovell in person at his shop. | Ovell's wool factor shop | 90/108 | 36.3 s |
| 52 | "Done." I take the coin and the letter, and pocket it without reading. "Millbrook, into Mistress Harrow's hand — I'm off." | Erzähler | open_run_duration | Accept the courier job in person at Ovell's shop and set out for Millbrook. | Millbrook | 90/108 | 44.5 s |
| 53 | I hold out the sealed letter. "From Master Ovell in Glassmere — he said into your hand and nobody else's. There's another silver waiting whe… | Erzähler | open_run_duration | Deliver the sealed letter to Mistress Harrow and earn the second silver. | Millbrook | 90/108 | 21.6 s |
| 54 | I hand her the sealed letter, unopened. "It's yours to judge, Mistress Bethel — Ovell said the mill house, and you're the mill house. I'll c… | Erzähler | open_run_duration | Deliver the letter to Marda Bethel and report the name mismatch back to Ovell if needed. | Millbrook | 90/108 | 31.2 s |
| 55 | "Word for word, then: Marda Bethel's got it, and she'll send her answer by the wool cart Thursday — and she's none too pleased about the nam… | Erzähler | open_run_duration | Report the delivery done and return to Ovell to collect the second silver. | Caelreth | 90/108 | 111.2 s |
| 56 | I put my shoulder against the cart beside the working carter. "A silver, you said — I'll push, but it's yours to pay when she's free." | Erzähler | open_run_duration | Take the carter's push quest and help free the mired cart for the promised silver. | Caelreth | 90/108 | 49.7 s |
| 57 | "Four now, and the rest at the Woolmark sign come market — I'll hold you to it, Dunn." | Erzähler | open_run_duration | Accept four coppers on the spot and the promised remainder in town, then continue to Glass… | Caelreth | 90/108 | 41.3 s |
| 58 | I find Ovell's shop and knock. "Done — Marda Bethel has it, and her answer comes by the wool cart Thursday. That's my silver, and we'd best … | Erzähler | open_run_duration | Report the delivery to Ovell, collect the promised silver, and get the runner quest proper… | Ovell's wool factor shop | 90/108 | 40.0 s |
| 59 | I wait for the silver and make sure it lands in my hand. "Mark the runner closed, then — and if the Steward's still asking after that crysta… | Erzähler | open_run_duration | Collect the promised silver from Ovell and confirm the quest is closed. | Ovell's wool factor shop | 90/108 | 27.5 s |
| 60 | I check my coin: #status | Erzähler | open_run_duration | Verify whether Ovell's two silver actually landed in my purse. | Ovell's wool factor shop | 90/108 | 16.5 s |
| 61 | I head to the Woolmark for supper and a room for the night. | Erzähler | open_run_duration | Spend the evening at the Woolmark: eat, drink, and get lodging. | the Woolmark | 90/108 | 41.2 s |
| 62 | I take Dunn's silver. "Paid in full, then — good cart, bad axle." Then to the innkeeper: "Stew and a bed, please — nine coppers it is." | Erzähler | open_run_duration | Collect Dunn's promised silver and pay for supper and lodging. | the Woolmark | 90/108 | 51.1 s |
| 63 | I take the room for the night and turn in. In the morning I check my purse: #status | Erzähler | open_run_duration | Sleep at the Woolmark and verify the engine books last night's payments. | the Woolmark | 90/108 | 19.8 s |
| 64 | Over breakfast I lean toward the clerk watching the door. "Trouble with a wagon? I've handled mired carts before — is there work or reward i… | Erzähler | open_run_duration | Pursue the college clerks' missing-wagon situation as a possible paid job. | the Woolmark | 90/108 | 48.8 s |
| 65 | "A silver for a day's walking and plain facts — done. I'll take the mill road and come back to you with what I find." | Erzähler | open_run_duration | Accept Ovell's quest to find the missing stores wagon. | stone pit | 90/108 | 29.9 s |
| 66 | I follow the strange footprints a short way toward the quarry mouth to see where they lead — without going deep — then turn back down the mi… | Erzähler | open_run_duration | Track the prints briefly for facts to report, then return to Ovell for the silver. | Ovell's wool factor shop | 90/108 | 30.2 s |
| 67 | "Found it, plain facts. Wagon's twenty paces off the road by the old quarry — dragged, one wheel still turning when I came up. Grain sacks t… | Erzähler | open_run_duration | Report the plain facts to Ovell and collect the silver reward. | Ovell's wool factor shop | 90/108 | 24.5 s |
| 68 | "I'll go and look — but I fight when I must, not to the death for a wool factor's purse. Name the price, and I'll want to know what the Guil… | Erzähler | open_run_duration | Negotiate a fair price for the Brast rescue scouting job before accepting. | Ovell's wool factor shop | 90/108 | 24.7 s |
| 69 | "Agreed — four silver, one in hand. I'll take the road now and come back with an answer, one way or the other." I pocket the silver and head… | Erzähler | open_run_duration | Accept Ovell's rescue-scouting quest and depart for the quarry. | old quarry mouth | 90/108 | 58.7 s |
| 70 | I light one of my torches, then ease into the quarry mouth along the wall, staff ready, pausing to listen before each few steps. | Erzähler | open_run_duration | Scout the quarry carefully with light, keeping distance from whatever is dragging inside, … | quarry cut bowl | 90/108 | 82.9 s |
| 71 | I take aim from cover and cast Flame Lance at the beast's flank while it's still feeding, hoping to finish it before it turns on Brast or me… | Erzähler | open_run_duration | Ambush the quarry beast with Flame Lance from range to rescue Brast. | quarry cut bowl | 90/92 | 35.2 s |
| 72 | I climb down to Brast, cut his bindings with my knife, and check his wounds. | Erzähler | open_run_duration | Free Brast, assess his condition, and help him out of the quarry. | quarry cut bowl | 90/92 | 27.4 s |
| 73 | I give Brast my waterskin and help him drink, then say, "A second one's loose somewhere — we move now, together, back to the road. Can you w… | Erzähler | open_run_duration | Get Brast out of the quarry before the second beast returns. | quarry cut bowl | 90/92 | 31.6 s |
| 74 | I keep the torch high and take the wall-side path up with Brast, moving steady and quiet, staff ready for the smaller beast. | Erzähler | open_run_duration | Escort Brast out of the quarry along the wall, alert for the second beast. | old quarry mouth | 90/92 | 33.1 s |
| 75 | "We walk together, slow. The wagon can wait — I'll tell Ovell it's there and let him send men for it." I offer Brast my arm and start for th… | Erzähler | open_run_duration | Escort Brast back to the city and report to Ovell, mentioning the wagon of grain for possi… | Glassmere | 90/92 | 41.8 s |
| 76 | I walk with Brast to the mill yard and find Ovell. "Brast is alive — the beasts took the horses, not him. One is dead in the quarry; a secon… | Erzähler | open_run_duration | Turn in both Ovell quests in person, report the dead beast and the loose second one, and m… | the mill yard | 90/92 | 65.5 s |
| 77 | "Two silver for the finding and the bringing both — fair, I'd say, given a second beast is still loose near your wagon." | Erzähler | open_run_duration | Name a fair price to Ovell for both jobs and get paid. | the mill yard | 90/92 | 31.9 s |
| 78 | #status | System (Befehl) | open_run_duration | Verify whether Ovell's two silver and the quest turn-ins actually booked. | the mill yard | 90/92 | 2.3 s |
| 79 | I pocket the two silver and stay to hear Ovell out. "What else did you have in mind?" | Erzähler | open_run_duration | Collect the paid silver and hear Ovell's follow-up offer. | the mill yard | 90/92 | 37.2 s |
| 80 | "I'll take the beast now, while the light's good. Say two silver for the culling and it's done today." | Erzähler | open_run_duration | Accept Ovell's quarry beast culling job and negotiate the pay. | the mill yard | 90/92 | 29.9 s |
| 81 | I wait by the open ledger for Ovell to return from the sheds, then say: "Two silver for the culling, done today — agreed?" | Erzähler | open_run_duration | Wait for Ovell to come back and close the two-silver culling deal in person. | the mill yard | 90/92 | 56.7 s |
| 82 | I set off west along the quarry road at a good pace, watching for the wagon and the drag-path from the road side. | Erzähler | open_run_duration | Travel to the old quarry to hunt the remaining three-toed beast before dusk. | the old quarry | 90/92 | 60.0 s |
| 83 | I climb down the near terraces to the first bench and look over the edge toward the chewing sound, keeping low and out of sight. | Erzähler | open_run_duration | Scout the quarry beast from cover before engaging. | the old quarry | 90/92 | 27.0 s |
| 84 | I inch forward to the bench edge and peer over to see the beast below. | Erzähler | open_run_duration | Get visual on the quarry beast before engaging. | the old quarry | 90/92 | 33.2 s |
| 85 | I climb down the twelve feet quietly while the beast is still eating, staff in hand. | Erzähler | open_run_duration | Get down to the beast's bench quietly and set up an ambush while it eats. | the beast's terrace (third bench) | 90/92 | 57.6 s |
| 86 | I cast Flame Lance at the beast's flank from ten paces while its back is still turned. | Erzähler | open_run_duration | Ambush the quarry beast with Flame Lance before it can react. | the beast's terrace (third bench) | 70/76 | 23.9 s |
| 87 | I cast Arcane Bolt at the beast to finish it off. | Erzähler | open_run_duration | Kill the wounded quarry beast with Arcane Bolt. | the beast's terrace (third bench) | 70/66 | 29.3 s |
| 88 | I walk past the dead beast to the overhang recess and look closely at the pale shape. | Erzähler | open_run_duration | Identify the pale regular shape in the den overhang, possibly the missing wagon. | the overhang recess | 70/66 | 35.6 s |
| 89 | I kneel beside Brast and hold the ale to his lips for him to drink. | Erzähler | open_run_duration | Give the trapped carter a drink before trying to free his leg. | the overhang recess | 70/66 | 44.5 s |
| 90 | "It's dead, Brast. Burned it down myself. Now let's get that stone off your leg — I've got rope, but I'll need your help to lever it." | Erzähler | open_run_duration | Confirm the kill to Brast and start freeing his pinned leg. | the overhang recess | 70/66 | 29.2 s |
| 91 | I fish the pry bar out from under the second sack, loop the rope around the slab's high end, anchor it to the bench stone outside, and wedge… | Erzähler | open_run_duration | Set up the rope-and-lever rig and free Brast's pinned leg. | the overhang recess | 70/66 | 61.8 s |
| 92 | I brace behind the bar and lift on Brast's "when," then jam the chip pile under the low end before the slab can settle back down. | Erzähler | open_run_duration | Lever the slab up and chock it so Brast can pull his leg free. | the overhang recess | 70/66 | 41.3 s |
| 93 | "Brast — there's a mired cart on the road I was meant to help push free. If I can get it moving, could we load you on it? Or I rig a sling a… | Erzähler | open_run_duration | Ask Brast whether the mired cart can carry him out of the quarry. | the overhang recess | 70/66 | 32.8 s |
| 94 | I take some salt pork and a torch from the college sacks, then head up out of the quarry cut toward the road to find Joss Hale's mired cart. | Erzähler | open_run_duration | Grab supplies and go fetch Joss Hale and his cart before dark. | the mired cart on the mill road | 70/66 | 42.0 s |
| 95 | "Neither — I'm the push, though not the college's. Found Brast alive back in the quarry, pinned under a slab. I need your cart rolling and t… | Erzähler | open_run_duration | Tell Joss Hale about Brast and negotiate his help hauling him out. | the mired cart on the mill road | 70/66 | 27.1 s |
| 96 | "Two silver it is, Joss. I'll dig, you drive — show me where you need the push." | Erzähler | open_run_duration | Agree to Joss's price and start getting the cart unstuck. | the mired cart on the mill road | 70/66 | 45.7 s |
| 97 | I climb aboard the cart with the sack and torch, and ride west with Joss back to the quarry cut to load Brast. | Erzähler | open_run_duration | Ride back to the quarry with Joss and load Brast onto the cart. | old quarry mouth | 70/66 | 33.2 s |
| 98 | "Beast's walked off into the pines — we move now, quick and quiet. I'll take the path nearest the wall with my torch, and we load Brast with… | Erzähler | open_run_duration | Load Brast onto the cart fast via the wall-side path before the beast returns. | quarry cut bowl | 70/66 | 86.0 s |
| 99 | "Then we hurry. Joss, take his shoulders — I'll take the legs. Straight up to the cart, no torch glow over the rim." | Erzähler | open_run_duration | Get Brast up the scree and onto the cart fast before the beast returns. | the mired cart on the mill road | 70/66 | 51.6 s |
| 100 | "Joss, torch high — I'm a mage, and Ovell's paying for this one dead." I cast Flame Lance at the breathing in the dark. | Engine (Menü/Rückfrage) | open_run_duration | Fight the quarry beast at the cart instead of fleeing, since Ovell pays for its cull. | the mired cart on the mill road | 70/66 | 5.2 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zum Start (notiert vor Zug 1): Character creation step 1/2 active; Mage offers INT/WIL favored stats.
- zu Zug 2 (notiert vor Zug 3): Creation completed cleanly; starter staff and robes show as equipped, coin 5 silver confirmed in HUD.
- zu Zug 3 (notiert vor Zug 4): Creation complete; HUD matches System panel. Guard scene is SHORT, single NPC, no entry fee mentioned yet.
- zu Zug 4 (notiert vor Zug 5): Directions were consistent with the HUD hint; no entry fee or toll was charged at the gate.
- zu Zug 5 (notiert vor Zug 6): HUD still shows Guild Rank — (not registered), consistent with the scene. No entry toll was charged, matching the guard scene.
- zu Zug 6 (notiert vor Zug 7): Engine rejected a combined action earlier ('step inside' flagged as impossible), but registration proceeded normally. Fee is 2 silver, leaving 3 after registration.
- zu Zug 7 (notiert vor Zug 8): Engine rejected 'step inside' as already there — sensible. Purchase booked correctly (HUD 3 silver), Guild Rank now Novice.
- zu Zug 8 (notiert vor Zug 9): HUD coin switched to silver (3) while the purchase panel showed copper — minor unit inconsistency but totals match. Board had nothing takable; Glimmerdeep culling is the sensible first job.
- zu Zug 9 (notiert vor Zug 10): HUD still shows 3 Silver while the purchase panel earlier said copper — totals match but units are inconsistent. No formal contract accepted yet; Glimmerdeep culling is informal (sell loot, academy slime bounty).
- zu Zug 10 (notiert vor Zug 11): Waterskin costs 4 silver — more than I carry, so I skip it and will use the north gate trough tip differently or revisit later. HUD shows only silver despite copper prices, so I'll watch how small change is booked.
- zu Zug 11 (notiert vor Zug 12): HUD coin shows silver while Marren quotes copper; totals roughly align (3 silver ≈ 100+ copper) if units are treated as same-scale, but the label mismatch persists.
- zu Zug 12 (notiert vor Zug 13): HUD 'Carried' still lists only Pouch and Guild plate and coin reads 3 Silver despite paying 1s9c — the purchased supplies and payment are not reflected in the HUD yet, a booking discrepancy to watch.
- zu Zug 13 (notiert vor Zug 14): HUD coin now reads 1 Silver 1 Copper, matching the panel's 11 copper after the purchase, but the narrated payment of 1s9c from 3 silver would leave 1s1c — consistent if earlier 3 Silver was really 30 copper. Carried list now correctly shows the supplies.
- zu Zug 14 (notiert vor Zug 15): Quests panel still shows '—' despite the clerk's cull talk — no formal contract was ever bookable; proceeding on the gate-warden's bounty/sale info instead. Coin now reads 1 Copper, consistent with panels.
- zu Zug 15 (notiert vor Zug 16): System rejected 'the nearer crystal beetle' as no targetable actor despite the narrator describing two beetles — narrator-scene and combat engine seem desynced; trying scene-anchored phrasing.
- zu Zug 16 (notiert vor Zug 17): Combat engine still reports 'no targetable actor' despite the narrator describing two beetles present; scene and engine remain desynced. HUD 'Present: nobody besides Alaric' also contradicts the narration.
- zu Zug 17 (notiert vor Zug 18): Combat engine has now rejected three plain target phrasings for beetles the narrator described; HUD says 'Present: nobody besides Alaric'. Also note HUD coin shows 1 Copper while earlier panels said 1 Silver 1 Copper.
- zu Zug 18 (notiert vor Zug 19): Combat engine never registered the described beetles; the clicking moved off into the crack. Free shed crystal plates are lootable here — a test of whether loot enters the Carried list, which previously failed to show purchased supplies.
- zu Zug 19 (notiert vor Zug 20): Combat engine now registers both beetles (HP 43/38, MEDIUM) after the re-describe — the earlier desync resolved itself once the narrator named them as present. Loot plates were booked into the pouch. Coin display corrected to 1 Copper.
- zu Zug 20 (notiert vor Zug 21): First Flame Lance one-shot the darker beetle (38 dmg) on First Strike; the lighter one closed and bit for 12. Combat engine now fully functional.
- zu Zug 21 (notiert vor Zug 22): Beetle A at 5 HP; basic attack 18–23 should finish it without burning MP.
- zu Zug 22 (notiert vor Zug 23): Level-up granted 5 stat points; HP/MP maxima rose (85/84) and my earlier #assign went through cleanly. Combat, XP, loot and skill progression all consistent this fight.
- zu Zug 23 (notiert vor Zug 24): Engine asked for an explicit rest duration and rejected re-taking loot already in inventory — loot auto-pickup confirmed. Coin shows 1 Copper despite earlier HUD oddities; will verify at #bag later.
- zu Zug 24 (notiert vor Zug 25): Rest engine recovered HP/MP cleanly with a named duration; loot auto-pickup and duplicate-take rejection both confirmed. Coin still shows only 1 Copper.
- zu Zug 25 (notiert vor Zug 26): First real loot sale offer: 5 silver 8 copper quoted for plates, gland and crystal. HUD carried-coin (1 Copper) has been lagging narrative events; will verify the sale books after acceptance.
- zu Zug 26 (notiert vor Zug 27): Sale booked in engine correctly: +50 copper, itemized sale panel, coin 1→51. HUD coin-lag from earlier turns now resolved. Free stat points (5) still unspent since level-up.
- zu Zug 28 (notiert vor Zug 29): Stat assignment booked cleanly (INT/WIL 9, VIT 6, points to 0). HUD coin now matches narrative: 5 Silver 1 Copper.
- zu Zug 29 (notiert vor Zug 30): Maret priced supper at two copper, ale one; coin 5 Silver 1 Copper, HP/MP not yet fully recovered, no active quests on the board.
- zu Zug 30 (notiert vor Zug 31): Purchase booked cleanly (-3 copper, 51→48). Possible new quest hook via Maret's gossip and the watching servant.
- zu Zug 31 (notiert vor Zug 32): Quest offer panel appeared for the cold stores job; HP still 74/90, MP 65/108 after supper — not fully recovered yet.
- zu Zug 32 (notiert vor Zug 33): Quest offer panel for the cold stores job appeared; pay is 8 silver plus possible bounty, but HP 74/90 and MP 65/108 are not fully recovered before a night fight.
- zu Zug 33 (notiert vor Zug 34): Job accepted cleanly at 8 silver plus bounty; quest now active on HUD. Coin 4S8C consistent with supper purchase. Enemy unidentified and unseen — thumb-wide gnaw marks suggest something bigger than rats.
- zu Zug 34 (notiert vor Zug 35): The heavy creature is unidentified; MP only 65/108, so I'm spending my best spell to open with light and damage together.
- zu Zug 35 (notiert vor Zug 36): System rejected my Flame Lance: the unseen creature is not a valid target — enemies must be revealed/identified before attacks register. Nothing was spent.
- zu Zug 36 (notiert vor Zug 37): Grave-Borer A revealed with its own scene panel (HP 70/70), confirming the earlier targeting rule: enemies must be identified before attacks register. It's a grain-eater, not a man-eater, and may be driven off without a fight — sensible given HP 74/90 and MP 65/108.
- zu Zug 37 (notiert vor Zug 38): Wren offered a nonviolent solution: smoke the borer up through its own tunnel, then block it. The creature's HP panel and threat display confirm combat is optional here — good, since MP is only 65/108.
- zu Zug 38 (notiert vor Zug 39): The borer's tunnel is confirmed behind it; the smoke plan is ready with materials gathered and the creature already retreating toward its exit.
- zu Zug 39 (notiert vor Zug 40): Quest panel already declared 'READY FOR TURN-IN' before the sealing work is done — mild sequencing oddity; also the HUD lists present NPCs with mismatched name/id tags (Dace shown as npc.wren).
- zu Zug 40 (notiert vor Zug 41): Quest completed and marked so in the panel; payment deferred to morning with the Steward. HUD still shows mismatched present-NPC tags (Dace listed as npc.wren) and quests list shows '—' despite the completed quest.
- zu Zug 42 (notiert vor Zug 43): Full rest restored HP/MP to max via a free bench sleep — recovery worked cleanly. HUD still shows the Dace/npc.wren name mismatch.
- zu Zug 43 (notiert vor Zug 44): HUD still shows only 4 Silver 8 Copper before payment; the eight silver has not yet been booked. Present-NPC tag mismatch persists (Dace shown as npc.wren).
- zu Zug 44 (notiert vor Zug 45): Narrator staged the payment on the desk, but the HUD still shows only 4 Silver 8 Copper — the coins are not yet booked; watching whether taking them updates the HUD.
- zu Zug 45 (notiert vor Zug 46): HUD still shows 4 Silver 8 Copper after the narrator staged the payment on the desk — coins not booked yet. HUD also says 'Present: nobody besides Alaric' while Dace is actively talking to me.
- zu Zug 46 (notiert vor Zug 47): System #status now shows the eight silver properly in my purse (12s 8c implied vs HUD's stale 4s 8c) — the coin was booked after all; the HUD panel is just lagging/older. Also an ITEM panel granted me two loaves I already ate, a minor duplication oddity.
- zu Zug 47 (notiert vor Zug 48): HUD coin still shows the stale 4s 8c while #status booked the eight silver — HUD lags confirmed again. HUD 'Present: nobody besides Alaric' contradicts the clerk speaking in the room.
- zu Zug 48 (notiert vor Zug 49): HUD still shows stale 4s 8c and 'Present: nobody besides Alaric' while the clerk and now Ovell are actively talking — same panel lag noted before.
- zu Zug 49 (notiert vor Zug 50): Odd sequencing: the QUEST OFFERED panel appeared while I was still at Ovell's shop, then the narrator reset the scene to the Guild hall as if I'd never left — the engine placed me in two locations at once. Also the HUD 'Present' tag still shows nobody despite the clerk talking.
- zu Zug 50 (notiert vor Zug 51): Engine blocked quest.accept at the Guild hall ('the giver is not here') — location-gated quest acceptance is working, though the QUEST OFFERED panel had fired prematurely at Ovell's shop in the previous scene confusion.
- zu Zug 51 (notiert vor Zug 52): HUD still shows 'Present: nobody besides Alaric' while Ovell stands at the counter, and coin remains 4s 8c despite the promised silver on the counter — same panel lag pattern as before.
- zu Zug 52 (notiert vor Zug 53): HUD again shows 'Present: nobody besides Alaric' while Mistress Harrow is actively talking, and the quest is still listed as 'offered' despite Ovell handing over coin and letter — same HUD lag pattern.
- zu Zug 53 (notiert vor Zug 54): Engine gave 'nobody to give it to' for the hand-off despite Bethel being ENGAGED and present, then the narrator continued as if she were there — give-action targeting bug. Quest still shows 'offered' in HUD after acceptance and half payment.
- zu Zug 54 (notiert vor Zug 55): Quest still listed as 'offered' in the HUD despite full delivery; Bethel confirmed 'Harrow' is Ovell's private byname, so the mystery resolved as flavor, not an error.
- zu Zug 55 (notiert vor Zug 56): Two new quest offers fired on the road with engine panels; the Millbrook runner quest is still 'offered' in the HUD despite complete delivery, so I'll press Ovell for its reward back in Glassmere.
- zu Zug 56 (notiert vor Zug 57): Carter quest paid only partially in fiction so far (four coppers, remainder promised); HUD coin still shows 4s 8c, so I'll verify the engine books the coins and the quest completion.
- zu Zug 57 (notiert vor Zug 58): HUD coin still reads 4s 8c after Dunn counted four coppers into my hand — the payment wasn't booked. The push quest also still shows 'active' with the six coppers outstanding at the Woolmark on market day.
- zu Zug 58 (notiert vor Zug 59): Engine finally booked the runner quest as COMPLETED, but coin still shows 4s 8c before the strongbox opens — payment again lags the fiction; Dunn's four coppers were never added either.
- zu Zug 59 (notiert vor Zug 60): Narrator had Ovell count out two silver, but the HUD coin still reads 4s 8c — payment again not booked by the engine.
- zu Zug 60 (notiert vor Zug 61): Status now shows 4s 8c with the narrator confirming Ovell's two silver landed — the earlier lag seems resolved. The push quest still shows active with six coppers outstanding, payable Thursday at the Woolmark.
- zu Zug 61 (notiert vor Zug 62): Dunn paid the remaining silver in person; the push quest still shows 'active · reward 100 cp' in the HUD, so the engine may not have closed it — will verify coin and quest state after paying.
- zu Zug 62 (notiert vor Zug 63): Coin still reads 4s 8c in the HUD even though I paid nine coppers for supper and bed and received Dunn's silver — net should be about 5s 3c. Payments keep lagging or failing to book; checking #status in the morning.
- zu Zug 63 (notiert vor Zug 64): Engine finally booked the lodging purchase: coin went 48→44 copper, matching the fiction. The Dunn push quest still shows 'active · reward 100 cp' in the HUD despite being paid and closed in the fiction — a persistent HUD/quest inconsistency.
- zu Zug 64 (notiert vor Zug 65): Ovell's wagon quest was booked as QUEST OFFERED (100 cp) while Dunn's push quest still shows 'active' in the HUD despite being paid in full — a second day of the engine lagging behind settled fiction.
- zu Zug 65 (notiert vor Zug 66): Quest panel says 'READY FOR TURN-IN' for the wagon find, but HUD still lists it as active — same lag pattern as Dunn's push quest. Also a debt lead about an eight-silver crystal payment from the Steward is pending.
- zu Zug 66 (notiert vor Zug 67): Quest panel said READY FOR TURN-IN but HUD still lists Ovell's wagon quest as active — same lag pattern as Dunn's push quest, third instance now.
- zu Zug 67 (notiert vor Zug 68): Ovell's wagon quest paid a silver but the HUD still lists it as active — fourth unresolved quest in a row. New offered quest appeared in the HUD before I accepted.
- zu Zug 68 (notiert vor Zug 69): HUD shows 4s 4c but Ovell slid a silver across — coin may not have booked yet, or the earlier total was already off. The new quest booked immediately as active, unlike the previous lagged ones.
- zu Zug 69 (notiert vor Zug 70): New quest booked immediately as active — good. HUD coin still reads 4s 4c which may or may not include Ovell's two silvers; will verify at turn-in.
- zu Zug 70 (notiert vor Zug 71): Beast is MEDIUM at 23 HP, Brast confirmed alive; quest already shows READY FOR TURN-IN before any combat or rescue, which seems premature.
- zu Zug 71 (notiert vor Zug 72): Ambush Flame Lance one-shot the MEDIUM beast (67 crit, +24 XP, pelt and fang loot booked). Quest still shows READY FOR TURN-IN but remains 'active' in HUD — same lag pattern, fifth instance.
- zu Zug 72 (notiert vor Zug 73): Brast confirmed a second, smaller beast went off before dawn — new unbooked threat. Quest still shows active despite READY FOR TURN-IN; coin still reads 4s 4c pending Ovell's two silvers.
- zu Zug 73 (notiert vor Zug 74): Coin still reads 4s 4c and the Brast quest still shows 'active' despite READY FOR TURN-IN; will verify booking at turn-in with Ovell.
- zu Zug 74 (notiert vor Zug 75): Quest flagged READY FOR TURN-IN again but still 'active' in HUD; coin unchanged at 4s 4c. New lead: wagon salvage may pay extra.
- zu Zug 75 (notiert vor Zug 76): Quest flagged READY FOR TURN-IN but still 'active' in HUD for the third consecutive turn — will watch whether turn-in actually books rewards and clears it. Also the Steward still owes eight silver pending the crystal question.
- zu Zug 76 (notiert vor Zug 77): Ovell is offering to pay for both jobs in person; quest HUD still shows both Ovell quests active despite READY FOR TURN-IN flags.
- zu Zug 77 (notiert vor Zug 78): Ovell pushed two silver across and the ledger entry was narrated, but the HUD still reads 4 Silver 4 Copper and all three quests remain 'active' — third turn of quest-flag inconsistency; checking the engine state.
- zu Zug 78 (notiert vor Zug 79): #status confirms coin still 4s 4c despite Ovell narrating two silver paid — fourth turn of unbooked quest rewards. Status otherwise consistent.
- zu Zug 79 (notiert vor Zug 80): Fifth turn of unbooked money: Ovell narrated pushing two silver across, but the HUD still reads 4 Silver 4 Copper. Quest panel also still shows both Ovell jobs active despite completed turn-ins.
- zu Zug 80 (notiert vor Zug 81): Quest acceptance failed with 'the giver is not here' — Ovell walked off mid-offer. Coin still 4s4c despite narrated payment; sixth turn of unbooked money.
- zu Zug 81 (notiert vor Zug 82): Ovell finally agreed the two-silver culling in person and logged it as payable on completion. Coin still reads 4s4c even though he narrated pushing two silver across earlier — seventh turn of unbooked money; the culling pay may also fail to book, worth watching.
- zu Zug 82 (notiert vor Zug 83): Coin still 4s4c on the HUD despite Ovell's narrated payments; culling job finally agreed in person as payable on completion.
- zu Zug 83 (notiert vor Zug 84): Engine resolved only the stealth part of my combined action and dropped the peek — one action per message is being enforced strictly.
- zu Zug 84 (notiert vor Zug 85): Beast is alone, HP 49, hip-high and well camouflaged; a den mouth lies further down, so killing it quickly matters.
- zu Zug 85 (notiert vor Zug 86): Beast confirmed alone, HP 49, back turned, downwind ten paces; a pale regular shape in the den overhang hints at loot or the missing wagon.
- zu Zug 86 (notiert vor Zug 87): First Strike worked: Flame Lance hit for 43, beast at 6 HP, but no ambush bonus and it got two gores in for 20 damage before my turn.
- zu Zug 87 (notiert vor Zug 88): Beast defeated cleanly with Arcane Bolt; loot (hide, 2 tusks) auto-packed, +30 XP. Coin still reads 4s4c — the culling payment remains unbooked until completion, consistent with prior pattern.
- zu Zug 88 (notiert vor Zug 89): Brast found alive — quest flags READY FOR TURN-IN already, before the rescue is finished. I have no water listed, only ale and food.
- zu Zug 89 (notiert vor Zug 90): Quest flagged READY FOR TURN-IN while Brast is still trapped — turn-in seems possible before the rescue is actually finished. Loot auto-packed again; coin still 4s4c with culling payment unbooked.
- zu Zug 90 (notiert vor Zug 91): Brast confirmed alive and cooperative; rescue requires lever work before turn-in despite the quest already showing READY FOR TURN-IN.
- zu Zug 91 (notiert vor Zug 92): Pry bar acquired and rig anchored; rescue not yet resolved despite quest flagging READY FOR TURN-IN earlier.
- zu Zug 92 (notiert vor Zug 93): Rescue resolved: slab chocked successfully, Brast freed but leg badly injured and unable to walk; quest still shows active, not turn-in-ready.
- zu Zug 93 (notiert vor Zug 94): Brast confirmed the cart belongs to Joss Hale and advised getting it rolling first, then loading him at the flat overhang mouth; he offered college stores from the sacks.
- zu Zug 94 (notiert vor Zug 95): Quest still shows active rather than turn-in-ready despite Brast freed; the rescue chain now depends on getting the cart moving and loading him.
- zu Zug 95 (notiert vor Zug 96): Joss named a concrete price of two silver for the haul; HUD confirms 4s4c on hand, so the deal is affordable. Rescue chain still unresolved; quest flags lag behind actual progress.
- zu Zug 96 (notiert vor Zug 97): Engine booked the two-silver payment correctly (44→24 copper, HUD 2s4c). Quest flags still lag the story: 'mired cart' shows active though the cart is now rolling.
- zu Zug 97 (notiert vor Zug 98): Quest 'Learn whether Brast is alive' now flags READY FOR TURN-IN even though Brast is still in the cut and un-lifted — flags again lag the actual state. Fresh three-toed prints show the quarry beast left the cut into the pines; HUD HP is 70/90, lightly wounded.
- zu Zug 98 (notiert vor Zug 99): Brast confirmed the beast checks its cache at night; carrying him and the grain out is flagged as a real threat. Quest turn-in flag again ran ahead of the actual rescue mid-scene.
- zu Zug 99 (notiert vor Zug 100): Turn 100 reached; beast is 30 paces off at torchlight edge. Carrying an F-Rank pelt already, so a kill would add a second — worth real coin.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t17 | 20 | 2 | – | nein | 2 | gewonnen, 216 XP |
| enc.t65 | 71 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t79 | 86 | 1 | – | nein | 1 | gewonnen, 30 XP |

## Quests

- **Something in the college cold stores** — active (Zug 33) → completed (Zug 40), READY
- **Runner to Millbrook with a sealed letter** — completed (Zug 58)
- **A push for the mired cart** — active (Zug 56)
- **Find the missing stores wagon** — active (Zug 65), READY
- **Learn whether Brast is alive behind the quarry mouth** — active (Zug 68), READY

## Auffälligkeiten

- Zug 8, Nachricht 15 (board_failed): the board generator failed
- Zug 14, Nachricht 28 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (crystal beetle): refused, no fight (Patch 8.4.1 guard)
- Zug 18, Nachricht 36 (extraction_repaired): the extractor's first answer needed a repair
- Zug 23, Nachricht 45 (planner_repaired): the planner's first answer needed a repair
- Zug 26, Nachricht 52 (extraction_repaired): the extractor's first answer needed a repair
- Zug 29, Nachricht 58 (extraction_repaired): the extractor's first answer needed a repair
- Zug 36, Nachricht 71 (planner_repaired): the planner's first answer needed a repair
- Zug 44, Nachricht 87 (planner_repaired): the planner's first answer needed a repair
- Zug 47, Nachricht 93 (board_failed): the board generator failed
- Zug 69, Nachricht 137 (planner_repaired): the planner's first answer needed a repair
- Zug 70, Nachricht 140 (extraction_repaired): the extractor's first answer needed a repair
- Zug 97, Nachricht 193 (planner_repaired): the planner's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 48× keine gültige JSON-Entscheidung (Züge 1, 4, 5, 7, 12, 19, 21, 22, 23, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39, 41, 42, 43, 44, 47, 52, 53, 55, 56, 57, 59, 60, 66, 71, 72, 74, 77, 79, 83, 84, 86, 87, 91, 92, 93, 94, 95, 96, 100)

System-Panels: CLARIFY 0, NOT TAKEN 1, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: guild_canon 1, ambient 8, scene_context 36, dungeon_foe 1, world_rule 8, offer 2, no_go 5, private_payment 3, guild_listing 1, engine_owned_fact 2, quest 3, quest_dependency 7, coin 1, pc_inventory 2, entity_fact 2, engine_owned_combat 1, domain_fact 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 100 | 5 | 3.6 s | 9.8 s | 10984 | 9585 | 90 | – | stop 100 | 0 |
| narrator | 90 | 0 | 16.5 s | 28.5 s | 11283 | 8549 | 470 | – | stop 90 | 0 |
| extract | 94 | 4 | 10.3 s | 23.3 s | 10194 | 8388 | 477 | – | stop 94 | 0 |
| board | 4 | 2 | 17.0 s | 18.8 s | 2649 | 2046 | 1097 | – | stop 4 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 77:21 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 16.3 s) | 0:31 min |
| 100 Züge, Spiel (Senden bis HUD nach der Extraktion) | 60:56 min — Median 33.3 s, p90 62.7 s, max 111.2 s |
| 100 Züge, Spieler-Entscheidung | 13:46 min — Median 6.5 s, 48 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 9:00 min / 1:06 min / 28:10 min / 18:57 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 44.8 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 29:53 min, 80 Züge ≈ 59:46 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spieler | 12 | – | 30.5 s | 6.5 s |
| Spiel | 55 | – | 111.2 s | 33.3 s |
| Provider plan | 98 | 282 | 59.6 s | 3.6 s |
| Provider narrator | 55 | 154 | 98.4 s | 16.5 s |
| Provider extract | 76 | 220 | 37.9 s | 10.3 s |
| Provider extract | 19 | 48 | 37.2 s | 10.3 s |
| Provider extract | 30 | 81 | 34.3 s | 10.3 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
