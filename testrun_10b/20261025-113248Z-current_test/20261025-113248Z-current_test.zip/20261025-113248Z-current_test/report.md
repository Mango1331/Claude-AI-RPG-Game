# Avereth Live-Test 20261025-113248Z-current_test

## Kurzfassung

- **Ergebnis:** extractor_failed — turn 22: the World Extractor failed after story message 44; its world changes were not committed ($.deltas[2] (object.new): : unexpected property "ref"; $.deltas[3] (object.move): .object: matches none of anyOf)
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_duration (nicht erreicht)
- **Charakter:** mage (mage.arcane_bolt, mage.flame_lance) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world long playtest — Guild adventurer progression“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: independent cautious Guild adventurer: choose suitable contracts, prepare, recover, sell surplus loot and improve equipment and skills
- **Züge:** 22 · **Dauer:** 11:53 min · **LLM-Aufrufe der Engine/des Erzählers:** 59
- **Auffälligkeiten:** 2
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.85 |
| Git | 6b9ac65f4c2e (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 14.8 s |
| Browser | chrome 155.0.8059.85 |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261025-113248Z-current_test“, Seed 2017657998 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_duration | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | I choose Mage. | Engine (Menü/Rückfrage) | creation_complete | Select Mage as base class. | public roadside verge outside Ashbridge | 80/60 | 2.2 s |
| 2 | I choose Arcane Bolt and Flame Lance. | Engine (Menü/Rückfrage) | creation_complete | Pick two Mage starter skills to finish character creation. | public roadside verge outside Ashbridge | 80/72 | 2.3 s |
| 3 | I head toward the city gates of Ashbridge, looking for the Adventurers' Guild. | Erzähler | creation_complete | Enter Ashbridge and find the Guild to look for a starter contract. | Adventurers' Guild hall, Ashbridge | 80/72 | 30.5 s |
| 4 | I approach the counter clerk. "I'd like to register with the Guild, and see what beginner contracts you have available." | Erzähler | open_run_duration | Register with the Guild and ask for beginner contracts. | Adventurers' Guild hall, Ashbridge | 80/72 | 47.3 s |
| 5 | I pay the two silver and sign the ledger. | Erzähler | open_run_duration | Register with the Guild for two silver. | Adventurers' Guild hall, Ashbridge | 80/72 | 24.0 s |
| 6 | I tell the clerk, "I'll take the turtle cull contract at Miller's Fish Weirs." | Erzähler | open_run_duration | Accept the snapping turtle cull contract as my first Novice hunt. | Adventurers' Guild hall, Ashbridge | 80/72 | 35.6 s |
| 7 | I leave the Guild and head downstream along the Ashbrook toward Miller's Fish Weirs, following the water past the tanneries. | Erzähler | open_run_duration | Travel to the weirs to start the turtle cull contract. | Miller's Fish Weirs | 80/72 | 22.6 s |
| 8 | "Yes — I've come about the turtles. Where have they been doing the worst damage?" | Erzähler | open_run_duration | Ask the fisherman where to hunt the snapping turtles. | Miller's Fish Weirs | 80/72 | 26.5 s |
| 9 | I ask the net mender, "Then I'll wait by the gravel bar now while the sun's still out. Is it safe to watch from this bank?" | Erzähler | open_run_duration | Learn where to safely wait and watch for the sunbathing turtles. | Miller's Fish Weirs | 80/72 | 37.2 s |
| 10 | I stay hidden and keep my eyes on that stretch of slow water, staff ready. When the turtle surfaces again near the trap basket, I cast Flame… | Erzähler | open_run_duration | Ambush the sunbathing turtle with Flame Lance when it next surfaces. | Miller's Fish Weirs | 80/72 | 26.5 s |
| 11 | I cast Flame Lance at the turtle's head as it works at the basket. | Erzähler | open_run_duration | Ambush the surfaced turtle with Flame Lance from the bank. | Miller's Fish Weirs | 69/56 | 15.9 s |
| 12 | I cast Flame Lance at its head again. | Erzähler | open_run_duration | Keep damaging the turtle with my strongest ranged spell before it closes further. | Miller's Fish Weirs | 58/40 | 17.8 s |
| 13 | I cast Flame Lance at its head again to finish it before it can reach the water. | Erzähler | open_run_duration | Kill the crippled turtle with one more Flame Lance. | Miller's Fish Weirs | 58/24 | 30.3 s |
| 14 | I take the flask, sit down on the shingle, and drink while watching the two turtles in the deep channel. | Erzähler | open_run_duration | Accept the offered drink and recover briefly while watching the remaining two turtles. | Miller's Fish Weirs | 58/24 | 23.7 s |
| 15 | I take the flask and drink, then pull the torn cloth back to show him the bite. "Bad enough to bleed. I'll rest a bit before I go at the oth… | Erzähler | open_run_duration | Accept the drink, show the wound, and signal I'll rest before tackling the remaining two t… | Miller's Fish Weirs | 58/24 | 36.4 s |
| 16 | "Half a day. Until my mana comes back and Marda binds this leg." | Erzähler | open_run_duration | Commit to resting until early afternoon so MP and the wound recover before tackling the la… | Miller's Fish Weirs | 80/72 | 32.2 s |
| 17 | I walk down to the third weir's end, ready my staff, and cast Flame Lance at the closer of the two turtles in the channel. | Erzähler | open_run_duration | Resume the cull: attack turtle C with Flame Lance from the bank. | Miller's Fish Weirs | 80/56 | 18.5 s |
| 18 | I cast Flame Lance at Snapping Turtle C to finish it. | Erzähler | open_run_duration | Kill the crippled turtle C with one more Flame Lance before both close in. | Miller's Fish Weirs | 80/40 | 17.4 s |
| 19 | I cast Flame Lance at Snapping Turtle D before it can strike. | Erzähler | open_run_duration | Kill the last turtle with Flame Lance at close range. | Miller's Fish Weirs | 71/24 | 30.4 s |
| 20 | I cast Flame Lance at Snapping Turtle D to finish it. | Erzähler | open_run_duration | Kill the last turtle with one more Flame Lance at arm's reach. | Miller's Fish Weirs | 71/8 | 15.9 s |
| 21 | #assign INT 2 WIL 2 VIT 1 | System (Befehl) | open_run_duration | Spend the 5 level-up stat points on INT, WIL and VIT. | Miller's Fish Weirs | 71/8 | 2.1 s |
| 22 | I gather the scale plates and claws from the dead turtles and head back up the path with the channel man toward Ashbridge, planning to turn … |  | open_run_duration | Leave the weirs with the loot and return to the Guild to turn in the completed cull contra… | Miller's Fish Weirs | 71/8 | 30.7 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zum Start (notiert vor Zug 1): Character creation step 1/2; engine expects plain class choice reply.
- zu Zug 1 (notiert vor Zug 2): Step 2/2 skill selection; engine rejected my previous non-JSON answer.
- zu Zug 2 (notiert vor Zug 3): Creation complete: Mage with Arcane Bolt and Flame Lance, starter staff and robes equipped, 5 silver on hand. Milestone 1 achieved.
- zu Zug 3 (notiert vor Zug 4): Note: my previous valid answer was rejected once for a JSON formatting error; resent.
- zu Zug 4 (notiert vor Zug 5): Test harness again rejected a valid in-character answer for missing JSON; resending. Registration costs 2 of my 5 silver.
- zu Zug 5 (notiert vor Zug 6): Registration booked correctly (coin 50→30 copper, Guild plate in inventory, Novice rank, Power Rank F). Note: HUD shows 3 Silver while earlier text said 5 silver starter — likely coin was always 50 copper (5 silver) and registration left 30; HUD's "3 Silver" label is just formatting.
- zu Zug 6 (notiert vor Zug 7): Test harness intermittently rejects valid JSON answers; resending. Contract accepted and booked in HUD (0/3 defeated).
- zu Zug 7 (notiert vor Zug 8): Test harness again rejected a valid in-character answer for missing JSON; resending.
- zu Zug 8 (notiert vor Zug 9): HUD confirms contract active 0/3, 3 silver, morning time suits turtle sunbathing tactic.
- zu Zug 9 (notiert vor Zug 10): Test harness rejected a valid in-character answer for missing JSON; resending.
- zu Zug 10 (notiert vor Zug 11): Last turn the engine treated my combined hide-and-cast as one action and only rolled Stealth; note HP 84 suggests a tough fight for a Level 1 mage — 3 required kills may be risky.
- zu Zug 11 (notiert vor Zug 12): Combat booked properly: first strike did 29 (cover -25%), turtle bit back for 11. Engine helpfully lists damage ranges; Flame Lance remains best option at 34-42.
- zu Zug 12 (notiert vor Zug 13): Turtle at 17 HP after two Flame Lances; MP 40/72, so one more cast is affordable. Taking 11 damage per round is steady but manageable at 58/80.
- zu Zug 13 (notiert vor Zug 14): Turtle B defeated cleanly: +46 XP, loot (scale plate, claw), Flame Lance gained 18 PP. Two more turtles (70 HP each) still in the channel; contract shows 1/3. MP only 24/72, so I'll need recovery before fighting again.
- zu Zug 14 (notiert vor Zug 15): Resending as JSON after harness rejection. Note: 1/3 defeated in HUD while two turtles remain, so contract needs all three — C and D, not B's replacement.
- zu Zug 15 (notiert vor Zug 16): Engine wanted an explicit rest duration before accepting the action; also note the flask was booked as loot ('swig of plum spirit') even though it's the fisherman's.
- zu Zug 16 (notiert vor Zug 17): Rest booked fully: HP/MP restored to max, half a day elapsed to 17:38. Two turtles remain, 1/3 defeated in HUD.
- zu Zug 17 (notiert vor Zug 18): Both turtles left the water and closed to MEDIUM; dogs arrived at SHORT as visible but not-yet-fighting. Engine again ignored the movement part of my combined action and resolved only the cast.
- zu Zug 18 (notiert vor Zug 19): Turtle C defeated (2/3); turtle D closed to SHORT and is coiled to attack. Dogs and fisherman remain visible-but-not-fighting; MP 40/72 allows two more Lances.
- zu Zug 19 (notiert vor Zug 20): Turtle D bit me for 9 (HP 71/80, MP 24/72); one more Lance (35-43) should defeat it. Dogs and fisherman remain non-combatant.
- zu Zug 20 (notiert vor Zug 21): Combat ended, level 2 reached, Flame Lance gained 18 PP, loot of 4 scale plates and 3 claws booked; HUD HP/MP maxima rose to 85/84. Note: HUD still lists turtle D as a live threat and 'Snapping Turtle B (dead)' while combat panel says C and D defeated — minor narration/HUD inconsistency.
- zu Zug 21 (notiert vor Zug 22): Stat assignment booked (INT/WIL 9, VIT 6). Quest marked ready for turn-in, reward only 40 cp. HUD still stale: shows turtle B not listed as loot source and MP max 84 vs System's 72 base — worth watching.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t11 | 11 | 1 | – | ja | 1 | gewonnen, 46 XP |
| enc.t17 | 17 | 2 | – | ja | 2 | gewonnen, 72 XP |

## Quests

- **Cull the Snapping Turtles at Miller's Fish Weirs** — active (Zug 6), READY
  - Aufgabe: Hunt and cull 3 snapping turtles that have been tearing the fish nets at Odlem Miller's weirs on the Ashbrook shallows.
  - Endzustand: 3 snapping turtles are culled and Miller's weirs fish without torn nets again.

## Auffälligkeiten

- Zug 22, Nachricht 44 (extraction_failed): the extractor failed: $.deltas[2] (object.new): : unexpected property "ref"; $.deltas[3] (object.move): .object: matches none of anyOf
- Zug 22, Nachricht 44 (extraction_repaired): the extractor's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 12× keine gültige JSON-Entscheidung (Züge 1, 2, 4, 5, 7, 8, 9, 10, 13, 14, 15, 21)

System-Panels: CLARIFY 0, NOT TAKEN 2, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: ambient 2, guild_canon 1, world_rule 7, no_go 1, scene_context 6.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 19 | 0 | 2.9 s | 8.4 s | 10640 | 9367 | 54 | – | stop 19 | 0 |
| narrator | 19 | 0 | 13.6 s | 16.6 s | 11467 | 8798 | 442 | – | stop 19 | 0 |
| extract | 20 | 1 | 6.9 s | 10.2 s | 10252 | 8456 | 459 | – | stop 20 | 0 |
| board | 1 | 0 | 18.8 s | 18.8 s | 2131 | 0 | 933 | – | stop 1 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 11:53 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 14.8 s) | 0:29 min |
| 22 Züge, Spiel (Senden bis HUD nach der Extraktion) | 8:46 min — Median 25.2 s, p90 36.4 s, max 47.3 s |
| 22 Züge, Spieler-Entscheidung | 2:20 min — Median 4.3 s, 12 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 1:15 min / 0:19 min / 4:02 min / 2:24 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 30.3 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 20:11 min, 80 Züge ≈ 40:21 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spieler | 15 | – | 34.0 s | 4.3 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
