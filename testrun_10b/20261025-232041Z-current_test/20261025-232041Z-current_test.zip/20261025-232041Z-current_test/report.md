# Avereth Live-Test 20261025-232041Z-current_test

## Kurzfassung

- **Ergebnis:** extractor_failed — turn 58: the World Extractor failed after story message 116; its world changes were not committed ($.deltas[6].scene: explicitly name this earlier scene before the later arrival; do not inherit the reply's final scene)
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_duration (nicht erreicht)
- **Charakter:** mage (mage.arcane_ward, mage.flame_lance) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world long playtest — Guild adventurer progression“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: pragmatic Guild adventurer: value achievable contracts, loot sales and useful gear or skill investments without reckless fights
- **Züge:** 58 · **Dauer:** 27:45 min · **LLM-Aufrufe der Engine/des Erzählers:** 161
- **Auffälligkeiten:** 7
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.91 |
| Git | b55a897af686 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 16.9 s |
| Browser | chrome 155.0.8059.85 |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261025-232041Z-current_test“, Seed 886145967 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_duration | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | I choose Mage. | Engine (Menü/Rückfrage) | creation_complete | Pick Mage as base class. | public roadside verge outside Glassmere | 90/84 | 2.3 s |
| 2 | I pick Flame Lance and Arcane Ward. | Engine (Menü/Rückfrage) | creation_complete | Finish character creation with two Mage starter skills. | public roadside verge outside Glassmere | 90/96 | 2.1 s |
| 3 | I walk toward the city gate of Glassmere, looking for the Adventurers' Guild. | Erzähler | open_run_duration | Enter Glassmere and find the Guild to take a starter contract. | Glassmere gatehouse | 90/96 | 23.0 s |
| 4 | "Adventurer, here to register with the Guild. Is there an entry toll?" | Erzähler | open_run_duration | Answer the guard and enter Glassmere to find the Guild. | Glassmere gatehouse | 90/96 | 15.6 s |
| 5 | I pay the guard two coppers and head for the Guild hall down the third street on the left. | Erzähler | open_run_duration | Pay the toll and enter Glassmere to register with the Adventurers' Guild. | Adventurers' Guild hall, Glassmere | 90/96 | 21.9 s |
| 6 | "Two silver works. I'll register." | Erzähler | open_run_duration | Pay the two silver registration fee and get my Guild mark via the measuring stone. | Adventurers' Guild hall, Glassmere | 90/96 | 19.1 s |
| 7 | I walk to the notice boards and look over the novice listings. | Erzähler | open_run_duration | Browse novice Guild contracts to pick a suitable starter job. | Adventurers' Guild hall, Glassmere | 90/96 | 24.8 s |
| 8 | "I'll take the Reed Flats contract." I bring the bog strider listing to the counter and ask the clerk to make it active. | Erzähler | open_run_duration | Accept the novice bog strider cull contract. | Adventurers' Guild hall, Glassmere | 90/96 | 19.8 s |
| 9 | "Off, thanks." I leave the Guild and take the south road toward the Reed Flats. | Erzähler | open_run_duration | Leave Glassmere and travel south toward the Reed Flats to hunt bog striders. | Eel-weirs of the Reed Flats | 90/96 | 30.6 s |
| 10 | "Where exactly past the third weir do they dig in — banks, water, or both? And what do they do when attacked?" | Erzähler | open_run_duration | Ask the eel fisher for details on strider location and behavior before heading out. | Eel-weirs of the Reed Flats | 90/96 | 18.5 s |
| 11 | "Thanks — that's worth knowing. I'll keep to dry ground and mind the clicking." I head up the channel toward the third weir with the red rag… | Erzähler | open_run_duration | Leave the weirs and scout the strider colony past the third weir. | Third weir with the red rag | 90/96 | 27.0 s |
| 12 | I find a dry, firm spot with the weir timbers at my back, then rap my staff loudly against the planks to draw the striders toward me. | Erzähler | open_run_duration | Bait the striders into attacking me on dry ground where I hold the advantage. | Third weir with the red rag | 90/96 | 26.4 s |
| 13 | I cast Flame Lance at the lead strider before it can spear. | Erzähler | open_run_duration | Strike the coiling lead strider first with Flame Lance. | Third weir with the red rag | 90/80 | 16.5 s |
| 14 | I cast Flame Lance at the strider up the bank on my left before they can spear. | Erzähler | open_run_duration | Kill the second strider with Flame Lance before both strike. | Third weir with the red rag | 85/64 | 15.7 s |
| 15 | I cast Flame Lance at the strider pressed against me before it strikes again. | Erzähler | open_run_duration | Kill the last strider with Flame Lance at point-blank range. | Third weir with the red rag | 85/48 | 16.7 s |
| 16 | I follow the faint clicking south into the reeds to find the fourth strider, keeping to dry ground. | Erzähler | open_run_duration | Hunt the fourth and final strider to complete the cull contract. | Black pool by the leaning dead willow | 85/48 | 24.8 s |
| 17 | I stay on my dry hummock and rap my staff loudly against the ground to bait the strider toward me across the pool. | Erzähler | open_run_duration | Bait the fourth strider into attacking me on dry ground where I hold the advantage. | Black pool by the leaning dead willow | 85/48 | 17.5 s |
| 18 | I cast Flame Lance at the creeping strider while it's still crossing the open mud spit. | Erzähler | open_run_duration | Kill the fourth strider with Flame Lance before it closes to melee. | Black pool by the leaning dead willow | 85/32 | 15.4 s |
| 19 | #assign INT 2 WIL 2 VIT 1 | System (Befehl) | open_run_duration | Spend the five level-up stat points on INT, WIL and VIT for stronger casting and survivabi… | Black pool by the leaning dead willow | 85/32 | 2.2 s |
| 20 | I head back north along the reed channels toward the road and Glassmere to turn in the contract. | Erzähler | open_run_duration | Travel back to Glassmere to turn in the completed cull contract and collect the 90 cp rewa… | Glassmere | 85/32 | 22.2 s |
| 21 | I go to the Guild hall counter and turn in the completed strider cull contract, collecting the 90 copper reward. | Erzähler | open_run_duration | Turn in the cull contract and collect the reward. | Adventurers' Guild hall, Glassmere | 85/32 | 15.4 s |
| 22 | "I have eight strider chitin plates and a venom gland from the cull — does the Guild buy those, or is there a buyer in town? And I'd like to… | Erzähler | open_run_duration | Sell the strider loot and pick a new Guild contract. | Adventurers' Guild hall, Glassmere | 85/32 | 19.6 s |
| 23 | The gland's clean, whole. I'll sell you the eight plates and the gland for twenty copper, and book me the Glasswing Moth Swarm contract. | Erzähler | open_run_duration | Sell the loot at the offered 20 cp and take the moth swarm contract. | Adventurers' Guild hall, Glassmere | 85/32 | 37.6 s |
| 24 | "Yes, pay out the twenty copper and the slip's mine." I take the coins and the contract slip, and ask the clerk where I can rest and eat che… | Erzähler | open_run_duration | Confirm the 20 cp loot sale is booked, then ask about lodging, food and skill training opt… | Adventurers' Guild hall, Glassmere | 85/32 | 72.6 s |
| 25 | I hand her the eight chitin plates and the venom gland for the twenty copper. | Erzähler | open_run_duration | Complete the loot sale that failed to book last turn by physically handing over the goods. | Adventurers' Guild hall, Glassmere | 85/32 | 57.0 s |
| 26 | #bag | System (Befehl) | open_run_duration | Check whether the plates and gland are actually in my inventory before giving up on the sa… | Adventurers' Guild hall, Glassmere | 85/32 | 2.2 s |
| 27 | I take the eight chitin plates and the venom gland out of my pack and lay them on the counter. "Here they are — twenty copper, as agreed." | Erzähler | open_run_duration | Complete the 20 cp loot sale by physically producing the goods the engine says are in my b… | Adventurers' Guild hall, Glassmere | 85/32 | 24.1 s |
| 28 | "Done — twenty copper the lot." I push the plates and gland toward her and take the coins. | Erzähler | open_run_duration | Complete the loot sale with explicit spoken confirmation. | Adventurers' Guild hall, Glassmere | 85/32 | 19.1 s |
| 29 | I give up on the sale for now and head to the Wren for a bed and a meal — what's the price for the night with dinner? | Erzähler | open_run_duration | Drop the bugged sale for now and arrange cheap lodging and food before dark. | Adventurers' Guild hall, Glassmere | 85/32 | 20.6 s |
| 30 | "The four copper bed and supper, please." I take a table by the fire and eat. | Erzähler | open_run_duration | Pay for lodging, dinner and a night's rest to recover MP before tomorrow's moth contract. | Adventurers' Guild hall, Glassmere | 85/32 | 26.2 s |
| 31 | I go up to the loft and sleep till morning. | Erzähler | open_run_duration | Rest overnight to recover MP before tackling the moth contract. | Adventurers' Guild hall, Glassmere | 100/132 | 20.9 s |
| 32 | Back inside the Guild hall, I try the sale once more: "Morning — here are the eight plates and the gland. Twenty copper, as you said." | Erzähler | open_run_duration | Retry the bugged 20 cp loot sale now that I'm rested, before heading out on the moth contr… | Adventurers' Guild hall, Glassmere | 100/132 | 29.4 s |
| 33 | "Fifty-five the lot, then — fetch the broker's coin and I'll take it." | Erzähler | open_run_duration | Sell all eight plates plus the venom gland for the offered 55 copper and get paid. | Adventurers' Guild hall, Glassmere | 100/132 | 28.8 s |
| 34 | I bring the contract slip to the ledger woman. "The strider cull — here's the slip. I'm told the payout's due." | Erzähler | open_run_duration | Turn in the completed strider cull at the front desk and collect the reward. | Adventurers' Guild hall, Glassmere | 100/132 | 29.1 s |
| 35 | I take the slip back and head out the east gate toward the vineyard terraces, watching the kiln row for glasswings as I go. | Erzähler | open_run_duration | Travel east to the vineyard terraces to hunt the six glasswing moths for the 80 cp contrac… | Vineyard terraces and old kiln row east of Glassmere | 100/132 | 35.8 s |
| 36 | I cast Flame Lance at the nearest glasswing on the chimney brick. | Engine (Menü/Rückfrage) | open_run_duration | Start hunting the six glasswing moths for the contract, beginning with the closest one. | Vineyard terraces and old kiln row east of Glassmere | 100/132 | 6.5 s |
| 37 | I cast Flame Lance at the glasswing sunning on the nearest broken chimney. | Engine (Menü/Rückfrage) | open_run_duration | Retarget the Flame Lance with a plainer description so the scene registers the moth as a v… | Vineyard terraces and old kiln row east of Glassmere | 100/132 | 6.6 s |
| 38 | I walk up to the nearest glasswing and strike it with my staff to start the fight. | Erzähler | open_run_duration | Engage a moth at close range so the scene registers a targetable actor, then attack. | Vineyard terraces and old kiln row east of Glassmere | 100/132 | 33.2 s |
| 39 | I cast Flame Lance at Glasswing Moth A. | Erzähler | open_run_duration | Attack the now-registered engaged moth to start whittling down the contract. | Vineyard terraces and old kiln row east of Glassmere | 100/116 | 25.3 s |
| 40 | "Planning on the rest," I call back. "The rest likely flew off when I dropped this one — any trick to getting them back down?" | Erzähler | open_run_duration | Answer the vintner and ask how to lure the scattered moths back within reach. | Vineyard terraces and old kiln row east of Glassmere | 100/116 | 28.2 s |
| 41 | I check the warm flue for the two sheltering moths, and if they're within reach, I cast Flame Lance at the first one. | Erzähler | open_run_duration | Kill the two moths roosting in the warm flue to progress the 6-moth contract. | Vineyard terraces and old kiln row east of Glassmere | 100/116 | 33.6 s |
| 42 | I wait by the kiln row for the scattered moths to settle back, watching for the first one to land within reach. | Erzähler | open_run_duration | Let the lure tactic work: wait for moths to roost at the kilns, then attack. | Vineyard terraces and old kiln row east of Glassmere | 100/116 | 26.6 s |
| 43 | I cast Flame Lance at the moth on the chimney stack. | Erzähler | open_run_duration | Kill the settled moth on the chimney to progress the 6-moth contract. | Vineyard terraces and old kiln row east of Glassmere | 96/100 | 17.3 s |
| 44 | I cast Flame Lance at Glasswing Moth E as it comes in low. | Erzähler | open_run_duration | Kill the second engaged moth to progress the 6-moth contract. | Vineyard terraces and old kiln row east of Glassmere | 96/84 | 13.0 s |
| 45 | "Three down so far," I say to Petros, wiping my knuckle. "They're drifting back to the kilns like you said — keep your nets still and I'll t… | Erzähler | open_run_duration | Report progress to Petros and keep the lure tactic going for the remaining three moths. | Vineyard terraces and old kiln row east of Glassmere | 96/84 | 18.4 s |
| 46 | "Yes — go tell them to hold still," I say. "I'll take the rest as they settle on the warm bricks." | Erzähler | open_run_duration | Send Petros to quiet the netters and keep the lure tactic going for the last three moths. | Vineyard terraces and old kiln row east of Glassmere | 96/84 | 23.3 s |
| 47 | I cast Flame Lance at the moth settled on the flat stones by the flue. | Engine (Menü/Rückfrage) | open_run_duration | Kill the settled moth to progress the 6-moth contract and hopefully level up. | Vineyard terraces and old kiln row east of Glassmere | 96/84 | 5.3 s |
| 48 | I cast Flame Lance at Glasswing Moth F. | Erzähler | open_run_duration | Kill the settled moth F to progress the 6-moth contract and level up. | Vineyard terraces and old kiln row east of Glassmere | 92/68 | 14.6 s |
| 49 | I cast Flame Lance at Glasswing Moth G on the lintel. | Erzähler | open_run_duration | Kill the engaged moth G to progress the 6-moth contract and hopefully level up. | Vineyard terraces and old kiln row east of Glassmere | 92/52 | 17.3 s |
| 50 | #assign INT 2 WIL 2 VIT 1 | System (Befehl) | open_run_duration | Spend the five level-up stat points on INT, WIL and VIT. | Vineyard terraces and old kiln row east of Glassmere | 92/52 | 2.2 s |
| 51 | "Six," I call up, holding the pouch open to show the chitin plates. "That's the lot — tell Marta her kilns are clear."  I check the contract… | Erzähler | open_run_duration | Confirm the 6/6 contract count and wrap up with Petros and Marta. | Vineyard terraces and old kiln row east of Glassmere | 92/52 | 23.3 s |
| 52 | I cast Flame Lance at the glasswing moth circling over the road ahead. | Erzähler | open_run_duration | Kill the roadside moth to book the sixth contract kill and complete the slip. | Vineyard terraces and old kiln row east of Glassmere | 92/36 | 14.6 s |
| 53 | I walk to the Glassmere Guild hall and turn in the contract slip, now READY, to the clerk for the 80-copper reward. | Erzähler | open_run_duration | Turn in the completed moth contract and collect the reward. | Adventurers' Guild hall, Glassmere | 92/36 | 17.6 s |
| 54 | "The board, please — and I've got moth parts to sell. What will you give me for seven feathers, three talons, six chitin plates and two veno… | Erzähler | open_run_duration | Sell the moth loot at the Guild desk and check the contract board for new work. | Adventurers' Guild hall, Glassmere | 92/36 | 30.6 s |
| 55 | "Deal — coin now, please. And I'll take the wyrling kiln contract, if I can sign for it here." | Erzähler | open_run_duration | Sell all moth loot for 35 copper and accept the wyrling contract. | Adventurers' Guild hall, Glassmere | 92/36 | 14.8 s |
| 56 | "Nothing else, thanks." I head out to the cookshop for a hot meal and ask what it costs, then find a quiet spot to rest and recover my mana … | Erzähler | open_run_duration | Recover MP with food/rest before taking on the wyrling contract. | Grass by the millpond wall | 92/36 | 28.1 s |
| 57 | I rest for two hours. | Erzähler | open_run_duration | Recover mana before hunting the wyrlings. | Grass by the millpond wall | 110/86 | 14.2 s |
| 58 | I head east out of the city toward the Claygate clay pits, asking clay-haulers along the way to point me to the old kiln. |  | open_run_duration | Travel to the old kiln and locate the feral wyrlings for the cull contract. | Grass by the millpond wall | 110/86 | 43.9 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 1 (notiert vor Zug 2): Stats already look boosted (STR/VIT/AGI/PER at 7 despite Mage favoring INT/WIL only) — possible engine inconsistency worth watching.
- zu Zug 2 (notiert vor Zug 3): Creation complete at Level 1; stats show all stats at 7 with INT/WIL 8, which is higher than the promised +1 to favored stats only — likely a base-5-plus-bonus quirk, noted.
- zu Zug 3 (notiert vor Zug 4): Guard asks for business at the gate; no toll amount mentioned yet.
- zu Zug 4 (notiert vor Zug 5): Entry toll is two coppers; registration reportedly another copper. Coin still shows 5 Silver in HUD, payment not yet booked.
- zu Zug 5 (notiert vor Zug 6): Toll purchase booked correctly (50→48 copper, HUD shows 4S8C). Registration costs two silver, more than the guard's guess of a copper.
- zu Zug 6 (notiert vor Zug 7): Registration booked correctly (48→28 copper), F rank, Guild plate received; HUD now consistent.
- zu Zug 7 (notiert vor Zug 8): Board offers five novice contracts; veteran NPC recommends Reed Flats as the usual starter. HUD consistent with coin and registration so far.
- zu Zug 10 (notiert vor Zug 11): Tactics briefing is clear: fight from dry ground, they swarm to noise; colony likely larger than the four required.
- zu Zug 11 (notiert vor Zug 12): HUD shows full HP/MP and 0/4 striders; briefing says they swarm to noise, so I'm fighting from the weir with my back covered.
- zu Zug 12 (notiert vor Zug 13): Three MEDIUM striders engaged (24 HP each); they split into a three-line attack as the fisher warned. Full HP/MP going in.
- zu Zug 13 (notiert vor Zug 14): Flame Lance one-shot a MEDIUM strider (41 dmg); combat panel shows clear range/cover mechanics and MP 80/96 after the first cast.
- zu Zug 14 (notiert vor Zug 15): Strider C closed to ENGAGED and hit me for 5; only one enemy left, MP still sufficient.
- zu Zug 15 (notiert vor Zug 16): Combat ran cleanly: three one-shot kills with Flame Lance, +72 XP (72/100, near level-up), +18 PP to the skill, loot auto-looted (5 chitin plates, 1 venom gland). Took 5 damage only when engaged at point-blank.
- zu Zug 16 (notiert vor Zug 17): Fourth strider is hiding across the pool, using the dead willow as cover; contract shows 3/4 defeated. MP 48/96 is still enough for two Flame Lances if needed.
- zu Zug 17 (notiert vor Zug 18): Fourth strider is larger (29 HP, MEDIUM, older one-eyed variant) and creeping cautiously; MP 48/96 allows two more casts.
- zu Zug 18 (notiert vor Zug 19): Level 2 reached with 5 free points; HP/MP maxima rose (95/108); contract shows READY for turn-in with 90 cp reward.
- zu Zug 19 (notiert vor Zug 20): Contract confirmed READY with 4/4 defeated; #assign booked correctly (INT/WIL 11, VIT 8, 0 points left). Note: HUD shown is stale, still lists 5 free points and old maxima.
- zu Zug 20 (notiert vor Zug 21): Minor oddity: the narrator rejected my travel message for naming the turn-in, but the travel itself happened and I'm now at Glassmere. HUD HP/MP maxima differ from earlier panel (100/132 vs 90/96).
- zu Zug 21 (notiert vor Zug 22): Turn-in booked cleanly: +9 silver, +120 XP, quest filed. HUD maxima now 100 HP / 132 MP (shifted again from the 95/108 shown earlier) and MP 32/132 is oddly low after the fight — possibly a stale or slow-updating HUD.
- zu Zug 22 (notiert vor Zug 23): MP still shows 32/132 though I haven't cast since the fight; mana recovery seems slow or the HUD is lagging. Board offers four novice jobs; moth swarm (80 cp) looks safest solo next to the grotto warning.
- zu Zug 23 (notiert vor Zug 24): HUD still lists the 8 plates and gland as carried and coin unchanged, so the sale isn't booked until her payout confirms. MP stuck at 32/132 with no casting since the fight; also HUD claims 'Present: nobody besides Alaric' while the clerk is clearly interacting with me.
- zu Zug 24 (notiert vor Zug 25): The engine rejected the combined message with 'sell: nobody to sell to' even though the clerk had made a firm offer — likely the quoted speech confused the parser. Retrying with a plain physical handover action.
- zu Zug 25 (notiert vor Zug 26): Engine claims the plates and gland are back at camp while the HUD still lists them as carried — a real inventory contradiction. Clerk's offer of 20 cp stands for a future visit.
- zu Zug 26 (notiert vor Zug 27): Narrator claims the goods are at camp while #bag confirms they're carried — a persistent inventory contradiction; trying physical hand-over wording to get the sale booked.
- zu Zug 27 (notiert vor Zug 28): Goods finally came out of the pack and the clerk re-offered 20 cp; sale now hinges on a simple confirmation word. MP still stuck at 32/132 with no casting since the fight.
- zu Zug 28 (notiert vor Zug 29): The sell action keeps failing: the engine parses my spoken confirmation as a sell command with 'nobody to sell to', and #bag still contradicts the narrator about where the plates and gland are. MP also remains stuck at 32/132 with no casting.
- zu Zug 29 (notiert vor Zug 30): MP still stuck at 32/132 despite no casting; inventory contradiction persists (HUD says plates/gland carried, narrator says they're at camp). New lead: hedge-mage Ossory offers paid lessons near market row.
- zu Zug 30 (notiert vor Zug 31): Coin correctly deducted to 8 copper; MP still shown 32/132 after rest, will check again in the morning.
- zu Zug 31 (notiert vor Zug 32): Recovery worked despite the narrator wrongly placing me on the Guild porch instead of the Wren loft I paid for — coin and MP bookkeeping are consistent, scene placement isn't. Inventory contradiction (clerk sees empty pack, #bag lists plates/gland) persists into day 3.
- zu Zug 32 (notiert vor Zug 33): The sale finally moved: a new clerk re-inspected the goods and upped the offer to 55 copper for the lot. Watching whether the engine actually removes the items and books the coin.
- zu Zug 33 (notiert vor Zug 34): Sale finally booked by the engine: items removed, +55 copper, coin 173 (HUD shows 1G7S3C — consistent). Contract slip still shows strider cull as completed and moth quest 0/6; HUD inventory is now clean.
- zu Zug 34 (notiert vor Zug 35): The strider cull was already marked completed/paid, so the glasswing slip was the wrong paper — no double payout available. HUD confirms quest 0/6 and full MP after rest; heading out before noon as the clerk advised.
- zu Zug 35 (notiert vor Zug 36): HUD confirms full MP after rest and the sale correctly booked (coin 173 copper); contract is 0/6 with the hunt site reached.
- zu Zug 36 (notiert vor Zug 37): The System rejected the attack because the moth was only scene description, not a targetable actor — first time combat targeting failed this way; rephrasing more concretely.
- zu Zug 37 (notiert vor Zug 38): Combat targeting keeps failing: the moths are described in scene prose but the System says there is no targetable actor. Trying to physically engage to spawn a proper combat scene.
- zu Zug 38 (notiert vor Zug 39): Physical engagement spawned targetable actors (Moths A–C, HP 18 each) — the earlier targeting failures were resolved by closing to melee range first. Contract still 0/6.
- zu Zug 39 (notiert vor Zug 40): First kill confirmed cleanly: 1/6, loot and XP booked by the engine. Remaining moths scattered after the flame kill, so a lure tactic may be needed.
- zu Zug 40 (notiert vor Zug 41): Vintner gave a useful lure tactic: kill moths at the kiln roost site and the swarm drifts back within a quarter hour; two are sheltering in the warm flue.
- zu Zug 41 (notiert vor Zug 42): Flue search failed (PER check), so the two sheltering moths are out of reach for now; relying on the vintner's lure instead.
- zu Zug 42 (notiert vor Zug 43): Two new targetable moths (D and E, HP 24) are now engaged at the kiln row; the lure tactic worked.
- zu Zug 43 (notiert vor Zug 44): Combat now books targets cleanly once engaged; Flame Lance one-shots the 24 HP moths (53 damage) for 16 MP, and the counter-bite only cost 4 HP.
- zu Zug 44 (notiert vor Zug 45): XP 194/200 — one more moth nearly levels me. Contract counter 3/6 booked correctly with loot and skill PP.
- zu Zug 45 (notiert vor Zug 46): HUD shows XP 194/200; one more moth kills should level me up and grant stat points to assign.
- zu Zug 46 (notiert vor Zug 47): Contract counter and loot continue to book correctly; XP 194/200, so the next kill should trigger a level-up with stat points to assign.
- zu Zug 47 (notiert vor Zug 48): System demanded a target disambiguation between F and G; I answered with the explicit target name. HUD note: it still shows 3/6 and XP 194/200, so the next kill should trigger the level-up.
- zu Zug 48 (notiert vor Zug 49): HUD target panel is confusing: it lists G 24/24 and an H with no HP, while the narrator says the last moth settled on the lintel after biting me. The counter still shows 3/6 per my notes, so kills may not be booking this round.
- zu Zug 49 (notiert vor Zug 50): Leveled to 3 with +5 stat points. HUD inconsistency: it lists a moth H (ENGAGED) and counter 5/6, though the narrator presented the lintel moth as the last one; likely a sixth moth remains. Also the 'Leads' text claims the clerk took my plates and gland, but my inventory still shows them — worth watching.
- zu Zug 50 (notiert vor Zug 51): Stat points assigned (INT 14, WIL 14, VIT 9). HUD is stale: still shows 5/6 and an ENGAGED moth H, though the narrator confirmed F and G defeated and combat ended; also HP/MP totals differ (105/144 vs 100/132). Watching whether the counter updates.
- zu Zug 51 (notiert vor Zug 52): Narrator and slip disagree: six kills were shown in combat logs, but the slip reads 5/6 and the HUD still lists a phantom ENGAGED moth H. A live seventh moth conveniently appeared on the road; I'll treat it as the missing count.
- zu Zug 52 (notiert vor Zug 53): The engine finally booked the sixth kill: slip READY, 6/6, +24 XP. HUD still shows the phantom ENGAGED moth H and dead moths A–G at the kiln row — stale location/entity panel, but the quest ledger is correct.
- zu Zug 53 (notiert vor Zug 54): Contract paid out correctly (8 silver, +120 XP). Note: narrator says clerk took the slip, HUD 'Here' block still references an earlier promise about plates and a twenty-copper price — likely stale text.
- zu Zug 54 (notiert vor Zug 55): Bren offered a concrete 35-copper price for all loot. HUD 'Here' block is stale again, still showing an earlier plates-and-glands promise from a previous scene.
- zu Zug 55 (notiert vor Zug 56): Sale and contract acceptance both booked cleanly in HUD (288 cp, quest active 0/3). The 'Here' block is again stale, reusing an old promise about plates and glands I just sold.
- zu Zug 56 (notiert vor Zug 57): Engine asked for an explicit rest duration — clarifying with 'two hours'. MP critically low (36/168), HP slightly down; the stale 'Here' block again repeats the old plates-and-glands promise.
- zu Zug 57 (notiert vor Zug 58): Rest booked cleanly: HP full, MP 86/168 after two hours. Stale 'Here' block persists, again repeating the old plates-and-glands promise.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t13 | 13 | 3 | – | nein | 3 | gewonnen, 72 XP |
| enc.t18 | 18 | 1 | – | nein | 1 | gewonnen, 30 XP |
| enc.t35 | 39 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t39 | 43 | 2 | – | nein | 2 | gewonnen, 48 XP |
| enc.t43 | 48 | 2 | – | nein | 2 | gewonnen, 48 XP |
| enc.t46 | 52 | 1 | – | nein | 1 | gewonnen, 24 XP |

## Quests

- **Cull the Reed Flats Bog Striders** — active (Zug 8) → completed (Zug 21), READY
  - Aufgabe: Hunt and cull the bog strider colony at the eel-weirs of the Reed Flats so the eel boats can launch safely again.
  - Endzustand: The bog strider colony is culled and the eel boats launch again.
- **Slay the Quarry Hound** — expired (Zug 54)
  - Aufgabe: Track and slay the feral slate hound that has been snatching tools and meat from the Slatepit Quarry camps.
  - Endzustand: The feral slate hound is slain and the quarry camps are untroubled.
- **Thin the Glasswing Moth Swarm** — active (Zug 23) → completed (Zug 53), READY
  - Aufgabe: Hunt down and thin the glasswing moth swarm roosting in the old kiln row before the next terrace vintage is stripped bare.
  - Endzustand: Six glasswing moths are slain and the terrace vines are safe through the vintage.
- **Clear the Glimmerdeep Grotto, Level 1** — expired (Zug 54), Dungeon loc.glimmerdeep_grotto Ebene 1
  - Aufgabe: Clear level 1 of Glimmerdeep Grotto. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Glimmerdeep Grotto is clear.
- **Cull the Millpond Eel Hounds** — expired (Zug 54)
  - Aufgabe: Hunt and cull the eel hounds denning in the millpond sluice before they strip the millpond of every fish.
  - Endzustand: Three eel hounds are culled and the millpond's fish stocks recover.
- **Cull the Feral Wyrlings of the Old Kiln** — active (Zug 55)
  - Aufgabe: Hunt and cull the 3 wyrlings nesting in the abandoned brick kiln by the Claygate clay pits before they burn the drying sheds.
  - Endzustand: The 3 wyrlings nesting in the abandoned brick kiln are culled and the drying sheds are safe from fire.

## Auffälligkeiten

- Zug 11, Nachricht 22 (extraction_repaired): the extractor's first answer needed a repair
- Zug 16, Nachricht 32 (extraction_repaired): the extractor's first answer needed a repair
- Zug 20, Nachricht 40 (extraction_repaired): the extractor's first answer needed a repair
- Zug 27, Nachricht 53 (planner_repaired): the planner's first answer needed a repair
- Zug 56, Nachricht 112 (extraction_repaired): the extractor's first answer needed a repair
- Zug 58, Nachricht 116 (extraction_failed): the extractor failed: $.deltas[6].scene: explicitly name this earlier scene before the later arrival; do not inherit the reply's final scene
- Zug 58, Nachricht 116 (extraction_repaired): the extractor's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 33× keine gültige JSON-Entscheidung (Züge 1, 2, 4, 5, 6, 7, 9, 10, 11, 13, 14, 16, 17, 18, 20, 22, 27, 29, 31, 34, 35, 36, 41, 42, 43, 44, 45, 46, 47, 48, 51, 53, 58)

System-Panels: CLARIFY 1, NOT TAKEN 0, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: guild_canon 1, guild_canon_price 1, ambient 6, world_rule 5, engine_owned_fact 10, group_unclear 3, scene_context 23, offer 5, entity_fact 1, engine_owned_memory 1, no_go 2, engine_booked 1, npc_continuity 2, quest_count 1, pc_inventory 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 54 | 1 | 2.5 s | 5.7 s | 11169 | 9591 | 71 | – | stop 54 | 0 |
| narrator | 50 | 0 | 8.5 s | 16.2 s | 11319 | 8822 | 370 | – | stop 50 | 0 |
| extract | 55 | 5 | 5.8 s | 11.6 s | 10806 | 8805 | 411 | – | stop 55 | 0 |
| board | 2 | 0 | 8.8 s | 9.0 s | 1898 | 1794 | 1099 | – | stop 2 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 27:45 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 16.9 s) | 0:41 min |
| 58 Züge, Spiel (Senden bis HUD nach der Extraktion) | 20:59 min — Median 20.2 s, p90 33.6 s, max 72.6 s |
| 58 Züge, Spieler-Entscheidung | 5:09 min — Median 3.8 s, 33 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 3:08 min / 0:18 min / 8:40 min / 6:49 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 27.0 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 18:01 min, 80 Züge ≈ 36:03 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spiel | 24 | – | 72.6 s | 20.2 s |
| Provider narrator | 25 | 69 | 30.5 s | 8.5 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
