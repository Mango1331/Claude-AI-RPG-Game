# Avereth Live-Test 20261026-012245Z-current_test

## Kurzfassung

- **Ergebnis:** planner_failed — turn 57: the semantic Planner failed before story generation (commands[0] (offer.accept): agreed price 50 cp differs from this offer's 60 cp; clarify instead of substituting an offer)
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_duration (nicht erreicht)
- **Charakter:** mage (mage.arcane_ward, mage.flame_lance) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world long playtest — Guild adventurer progression“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: independent cautious Guild adventurer: choose suitable contracts, prepare, recover, sell surplus loot and improve equipment and skills
- **Züge:** 57 · **Dauer:** 34:57 min · **LLM-Aufrufe der Engine/des Erzählers:** 162
- **Auffälligkeiten:** 12
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.92 |
| Git | 7a00e8febaf0 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 17.9 s |
| Browser | chrome 155.0.8059.85 |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261026-012245Z-current_test“, Seed 402149688 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_duration | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | I choose Mage. My two skills: Flame Lance and Mana Sense. | Engine (Menü/Rückfrage) | creation_complete | Pick the Mage class with Flame Lance and Mana Sense as starter skills. | public roadside verge outside Alderwatch | 90/84 | 2.4 s |
| 2 | Flame Lance and Arcane Ward. | Engine (Menü/Rückfrage) | creation_complete | Complete step 2 by picking two skills from the offered Mage pool. | public roadside verge outside Alderwatch | 90/96 | 2.1 s |
| 3 | I walk toward Alderwatch and look for the Adventurers' Guild to sign up and check available contracts. | Erzähler | open_run_duration | Enter Alderwatch, find the Guild, seek F-rank contracts. | Adventurers' Guild hall, Alderwatch | 90/96 | 29.8 s |
| 4 | Registration, please. I put two silver on the counter, then ask to see the F-rank contracts on the board. | Erzähler | open_run_duration | Register with the Guild and view F-rank contracts. | Adventurers' Guild hall, Alderwatch | 90/96 | 62.2 s |
| 5 | I take the Gnaw-Rats contract slip to the clerk. "This one, please — make it active." | Erzähler | open_run_duration | Accept the gnaw-rat cull contract as a manageable first hunt. | Adventurers' Guild hall, Alderwatch | 90/96 | 17.5 s |
| 6 | I head to Grain Row, find the harbormaster's men, and ask them to show me the marked burrow mouths. | Erzähler | open_run_duration | Travel to Grain Row and get the burrow entrances pointed out to start the rat cull. | Grain Row | 90/96 | 27.1 s |
| 7 | I ask the storeman whether the ajar cellar doors are his warehouse's, and whether he minds me checking them for rat sign. | Erzähler | open_run_duration | Get permission and information to inspect the open cellar doors for gnaw-rat activity. | Grain Row | 90/96 | 31.6 s |
| 8 | I take the storeman up on the lamp, light it, and descend the near cellar stairs carefully with lamp in one hand and staff in the other. | Erzähler | open_run_duration | Start hunting gnaw-rats in the near cellar with a lamp for light. | Grain Row cellar | 90/96 | 28.2 s |
| 9 | I hold the lamp steady and cast Flame Lance down the larger burrow mouth, then ready my staff in case something comes charging out. | Erzähler | open_run_duration | Attack the gnaw-rat in its burrow before it can ambush me. | Grain Row cellar | 90/80 | 23.0 s |
| 10 | I scatter some barley from the torn sack near the burrow mouth as bait, then stand back a few paces with my staff ready, waiting to see if t… | Erzähler | open_run_duration | Bait the gnaw-rats out of their burrow and ambush them from a safe distance. | Grain Row cellar | 90/80 | 29.0 s |
| 11 | I cast Flame Lance at the closest feeding rat. | Erzähler | open_run_duration | Open the ambush by killing the closest gnaw-rat with Flame Lance. | Grain Row cellar | 90/64 | 24.5 s |
| 12 | I cast Flame Lance at the big MEDIUM rat at the larger burrow mouth before it can retreat. | Erzähler | open_run_duration | Kill the large gnaw-rat with Flame Lance before it escapes underground. | Grain Row cellar | 90/48 | 16.1 s |
| 13 | I wait a few more minutes with the lamp and staff ready to see if any rats return; if nothing stirs, I search the cellar for any further bur… | Erzähler | open_run_duration | Wait out the cellar, then sweep for remaining rat activity before leaving. | Grain Row | 90/48 | 36.1 s |
| 14 | I tell the storeman I've killed two rats, but the rest fled deep into the tunnels — I'll come back to finish the cull once I've rested and r… | Erzähler | open_run_duration | Report progress to the storeman and plan to return for the remaining rats after resting. | Grain Row | 90/48 | 27.0 s |
| 15 | #status | System (Befehl) | open_run_duration | Check my stats and resources before deciding how to spend the midday. | Grain Row | 90/48 | 2.2 s |
| 16 | I ask the storeman where I can get a cheap hot meal and an hour's rest nearby before I go back down. | Erzähler | open_run_duration | Find affordable food and a rest spot to recover MP before finishing the cull. | Grain Row | 90/48 | 26.2 s |
| 17 | I head to the Kettle Step, buy a pottage and bread, and sit by the stove for an hour to recover my mana. | Erzähler | open_run_duration | Recover MP with a cheap meal and rest before finishing the rat cull. | Kettle Step | 90/62 | 25.9 s |
| 18 | I thank the innkeeper and head back down to the Grain Row cellars, lamp lit, to finish the rat cull. | Erzähler | open_run_duration | Return to the cellars to kill the remaining four gnaw-rats for the contract. | Grain Row cellar | 90/62 | 17.7 s |
| 19 | I follow the scrabbling past the dividing wall, lamp held high and staff ready, careful to check the floor ahead for burrow mouths or hazard… | Erzähler | open_run_duration | Push into the connected cellar to find and kill the remaining four gnaw-rats. | Second warehouse cellar side | 90/62 | 35.2 s |
| 20 | I back toward the dividing wall arch to funnel them, and cast Flame Lance at the lead rat. | Erzähler | open_run_duration | Fight the four gnaw-rats from a chokepoint at the wall arch. | Second warehouse cellar side | 87/46 | 25.7 s |
| 21 | I cast Flame Lance at Gnaw-Rat G. | Erzähler | open_run_duration | Kill the engaged rat with Flame Lance before the others close in. | Second warehouse cellar side | 81/30 | 20.3 s |
| 22 | I swing my staff in a Basic Attack at Gnaw-Rat E. | Erzähler | open_run_duration | Kill the engaged rats with basic attacks to conserve the last of my mana. | Second warehouse cellar side | 78/30 | 41.6 s |
| 23 | I cast Flame Lance at Gnaw-Rat F before it can bolt into the burrow. | Erzähler | open_run_duration | Kill the last rat with my remaining mana so it can't escape and reset the cull. | Second warehouse cellar side | 78/14 | 22.5 s |
| 24 | #assign INT 2 WIL 2 VIT 1 | System (Befehl) | open_run_duration | Allocate level-up points into INT/WIL for casting power and VIT for survivability. | Second warehouse cellar side | 78/14 | 2.2 s |
| 25 | I gather up my loot and head back out of the cellars toward the Guild hall to turn in the contract. | Erzähler | open_run_duration | Turn in the completed gnaw-rat cull contract at the Guild hall and collect the reward. | Adventurers' Guild hall, Alderwatch | 78/14 | 36.4 s |
| 26 | I walk to the job board and look for a novice-suitable contract. Also, is there anyone at the Guild who buys monster pelts and tails? | Erzähler | open_run_duration | Find a new suitable Guild contract and a buyer for my rat loot. | Adventurers' Guild hall, Alderwatch | 78/14 | 28.8 s |
| 27 | I take my six rat tails and two pelts to the brokerage counter. "How much for six tails and two pelts?" | Erzähler | open_run_duration | Sell my rat loot to the brokerage clerk at quoted prices. | Adventurers' Guild hall, Alderwatch | 78/14 | 20.4 s |
| 28 | "Deal. Thirty-three copper the lot." | Erzähler | open_run_duration | Accept the brokerage quote and sell all six tails and two pelts. | Adventurers' Guild hall, Alderwatch | 78/14 | 20.9 s |
| 29 | I take the Stray Hound Pack slip from the board and hand it to the front clerk. "I'll take this one." | Erzähler | open_run_duration | Accept the stray hound contract as my next hunt. | Adventurers' Guild hall, Alderwatch | 78/14 | 13.8 s |
| 30 | "Before I head out — is there a cheap room or mess here in the hall? I need rest and a meal before I hunt those dogs." | Erzähler | open_run_duration | Recover MP and HP via rest and food before taking on the hound pack. | Adventurers' Guild hall, Alderwatch | 78/14 | 26.5 s |
| 31 | I order a stew and bread at the kitchen hatch and find a seat at the low tables to eat. | Erzähler | open_run_duration | Recover MP and HP with a meal before resting at the Gilded Yoke. | Adventurers' Guild hall, Alderwatch | 78/14 | 24.4 s |
| 32 | I walk to the Gilded Yoke on Cooper's Lane and take a bunk for four copper to sleep off my wounds and restore my mana. | Erzähler | open_run_duration | Rest at the Gilded Yoke to recover HP and MP before hunting the hound pack. | Gilded Yoke | 78/14 | 38.0 s |
| 33 | I lie down on a clean bunk and sleep until evening. | Erzähler | open_run_duration | Rest at the Gilded Yoke to recover HP and MP before the hound hunt. | Gilded Yoke | 100/95 | 22.2 s |
| 34 | I head out to the Brick Kilns by the kiln road to hunt the stray hound pack. | Erzähler | open_run_duration | Travel to the Brick Kilns and hunt the stray hound pack. | Abandoned Brick Kilns | 100/95 | 57.7 s |
| 35 | I cast Flame Lance at the closer hound at the kiln mouth. | Erzähler | open_run_duration | Open the fight against the hound pack with Flame Lance on the nearest dog. | Abandoned Brick Kilns | 89/79 | 32.6 s |
| 36 | I cast Flame Lance at the lunging hound. | Erzähler | open_run_duration | Finish the hound fight with a second Flame Lance before it bites again. | Abandoned Brick Kilns | 89/63 | 27.6 s |
| 37 | I approach the culvert mouth and ready Flame Lance, calling out to draw the third hound out of the drain. | Erzähler | open_run_duration | Flush out the third hound from the culvert to finish the 3-dog contract. | Culvert mouth by the kiln road | 89/63 | 19.4 s |
| 38 | I cast Flame Lance at the hound as it springs at me. | Erzähler | open_run_duration | Kill the third hound mid-leap with Flame Lance to finish the contract. | Culvert mouth by the kiln road | 89/47 | 20.9 s |
| 39 | #assign INT 3 WIL 2 | System (Befehl) | open_run_duration | Allocate the 5 free stat points into INT and WIL before heading back to the Guild. | Culvert mouth by the kiln road | 89/47 | 2.2 s |
| 40 | I walk back along the kiln road to the Adventurers' Guild to turn in the completed hound contract. | Erzähler | open_run_duration | Return to the Guild and turn in the finished hound contract for the reward. | Adventurers' Guild hall, Alderwatch | 89/47 | 29.8 s |
| 41 | I ask the clerk what the healer's bench costs, and whether the Guild buys feral dog pelts and fangs off adventurers. | Erzähler | open_run_duration | Treat the thigh wound and sell the dog loot before taking new work. | Adventurers' Guild hall, Alderwatch | 89/47 | 28.5 s |
| 42 | I take the pelts and fangs over to the brokerage counter and set them out for Tam to weigh and price. | Erzähler | open_run_duration | Sell the dog loot at the brokerage counter before paying for the healer's bench. | Adventurers' Guild hall, Alderwatch | 89/47 | 31.2 s |
| 43 | "Done — fourteen copper it is." I sell him the lot, then head through the far door to Marthe's healer's bench to get my thigh patched up. | Erzähler | open_run_duration | Sell the dog loot for 14 copper and pay the copper for healing at Marthe's bench. | Marthe's healer's bench | 89/47 | 44.1 s |
| 44 | I pay Marthe the copper, thank her, and ask whether she knows of anyone in town who teaches new spells or improves the ones I have. | Erzähler | open_run_duration | Pay for healing and ask Marthe about magic training opportunities. | Marthe's healer's bench | 89/47 | 44.5 s |
| 45 | "Copper it is." I press the coin into Marthe's palm, then head upstairs to the Guild main hall to ask the instructors about skill lessons be… | Erzähler | open_run_duration | Pay for healing and check the Guild instructors about affordable skill training tonight. | Adventurers' Guild hall, Alderwatch | 89/47 | 63.1 s |
| 46 | "Four silver it is." I take the Flame Lance stone and do the hour of drilling with him. | Erzähler | open_run_duration | Buy the Flame Lance skill stone and lesson for 4 silver and verify the skill improves. | Adventurers' Guild hall, Alderwatch | 89/47 | 45.5 s |
| 47 | "Thank you." I head down and find a room or bed for the night to rest and recover. | Erzähler | open_run_duration | Rest overnight after the lesson to recover HP and MP. | Gilded Yoke | 89/47 | 38.0 s |
| 48 | I wake at dawn, and before anything else I check my status to see whether last night's Flame Lance lesson actually took. | Erzähler | open_run_duration | Verify the Flame Lance training booked in the engine, then look for a new Guild contract. | Gilded Yoke | 89/47 | 17.9 s |
| 49 | #status | System (Befehl) | open_run_duration | Verify whether the Flame Lance lesson raised the skill in the engine. | Gilded Yoke | 89/47 | 2.1 s |
| 50 | "Breakfast and a fill of the kettle, whatever it costs — I need my strength back. Then I'll look at the Guild board for a new contract." | Erzähler | open_run_duration | Recover with food, then find a new Guild contract. | Gilded Yoke | 89/47 | 48.1 s |
| 51 | "I'll take the Tallow Lane beetle sweep." I take the slip to the clerk and ask for the details — where the cellars are, when the two nights … | Erzähler | open_run_duration | Accept the Novice contract and get its practical details before starting. | Gilded Yoke | 89/47 | 32.6 s |
| 52 | "The Tallow Lane beetle sweep was on the board a moment ago — has someone taken it, or can I sign for it directly with you?" | Erzähler | open_run_duration | Resolve the contradiction between the posted slip and the empty board and try to accept th… | Gilded Yoke | 89/47 | 17.1 s |
| 53 | I wait at the Guild hall until midday, then check the Novice board for new postings — especially the Tallow Lane beetle sweep. | Erzähler | open_run_duration | Wait for the midday postings and take a Novice contract. | Adventurers' Guild hall, Alderwatch | 89/47 | 41.7 s |
| 54 | "I'll take the boar sow cull." I take that slip to the counter and ask the clerk for the details — where the market alleys are, when the sow… | Erzähler | open_run_duration | Accept the feral boar sow cull contract and get its practical details. | Adventurers' Guild hall, Alderwatch | 89/47 | 34.3 s |
| 55 | "Before I go — my mana's drained and sleep isn't touching it. Is there anything at the Guild or nearby that restores mana, and what would it… | Erzähler | open_run_duration | Ask the clerk about mana recovery options before hunting the sow. | Adventurers' Guild hall, Alderwatch | 89/47 | 52.8 s |
| 56 | I head to the cheaper of the two apothecaries on Tanners' Row and ask for a small mana draught — what they have and at what price. | Erzähler | open_run_duration | Buy an affordable mana draught before hunting the sow. | Cheap apothecary on Tanners' Row | 89/47 | 22.3 s |
| 57 | "I'll take your own brew at five silver." I hand over the coin and drink it there. | – | open_run_duration | Buy and drink the 5s mana draught to restore MP before the sow hunt. | Cheap apothecary on Tanners' Row | 89/47 | 27.8 s **no reply after the message** |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zum Start (notiert vor Zug 1): Character creation step 1/2 offers Warrior, Mage, Rogue; my first plain answer was rejected as non-JSON, so resending as proper command.
- zu Zug 1 (notiert vor Zug 2): My first skill pick was ignored; the System presented its own Mage pool and requires choices from it. Stats after class selection: INT 8, WIL 8, HP 90, MP 96.
- zu Zug 2 (notiert vor Zug 3): Creation complete: Mage with Flame Lance and Arcane Ward; starter staff and robes equipped with stats as listed. Note: Mana Sense was not in the pool, so Arcane Ward was taken instead.
- zu Zug 4 (notiert vor Zug 5): Registration booked correctly (coin 50→30 copper, then HUD shows 3 Silver — minor rounding inconsistency between copper display and silver HUD). Five Novice contracts offered; catacomb one flagged unsafe solo.
- zu Zug 5 (notiert vor Zug 6): Contract activation booked cleanly in the HUD (active, 0/6). Coin displays as 3 Silver consistently now.
- zu Zug 6 (notiert vor Zug 7): Search for the harbormaster's men failed; they may return after midday tide. Cellars are accessible but unmarked.
- zu Zug 7 (notiert vor Zug 8): Storeman confirmed fresh rat sign at the near cellar; contract still 0/6. No combat yet.
- zu Zug 9 (notiert vor Zug 10): Flame Lance down the burrow hit empty tunnels; rats fled deeper and contract still 0/6. MP 80/96 booked correctly.
- zu Zug 10 (notiert vor Zug 11): Three gnaw-rats now active above ground (two SHORT, one MEDIUM watching me); contract still 0/6. Bait worked.
- zu Zug 11 (notiert vor Zug 12): Combat resolved cleanly: Flame Lance one-shot the SHORT rat (49 dmg, +24 XP, tail auto-looted, contract 1/6). Second rat fled; only the MEDIUM watcher remains above ground despite the HUD still listing three active.
- zu Zug 12 (notiert vor Zug 13): Two kills booked cleanly (2/6, 2 tails, MP 48/96). Remaining rats fled deep; contract needs 4 more.
- zu Zug 13 (notiert vor Zug 14): Contract 2/6, MP 48/96, 2 tails looted, no injuries. Remaining rats retreated deep; sensible to recover before pushing further.
- zu Zug 15 (notiert vor Zug 16): Status confirms MP 48/96, XP 48/100, 3 Silver; no free stat points. Contract still 2/6.
- zu Zug 16 (notiert vor Zug 17): Storeman confirmed mana recovers faster when warm and fed; Kettle Step meal is a copper or so, affordable at 3 Silver.
- zu Zug 17 (notiert vor Zug 18): Only partial MP recovery from a full hour: 48→62/96, well short of full. Worth noting for future rest planning.
- zu Zug 18 (notiert vor Zug 19): Several sets of claws plus an unknown dragging sound beyond the wall — possible multiple enemies at once, so I advance cautiously with only 62/96 MP.
- zu Zug 19 (notiert vor Zug 20): All four rats revealed at once, HP 16 each; with 62/96 MP I can only afford about three Flame Lances, so I retreat to the arch to fight them one at a time.
- zu Zug 20 (notiert vor Zug 21): MP 46/96 — this lance drops me to 30, leaving only one more cast; after that I must rely on basic attacks (22–26) which still one-shot 16 HP rats.
- zu Zug 21 (notiert vor Zug 22): Basic attacks (22–26) one-shot 16 HP rats, so I save my last 30 MP instead of casting again; minor bites are adding up (HP 81/90).
- zu Zug 22 (notiert vor Zug 23): Rat F is hesitating at the burrow, possibly fleeing; spending my last 30 MP to finish it now is safer than chasing.
- zu Zug 23 (notiert vor Zug 24): Level 2 reached with 5 free points; contract shows ready for turn-in. HUD HP/MP maxes updated (95/108).
- zu Zug 24 (notiert vor Zug 25): Stat assignment confirmed (INT/WIL 11, VIT 8, 0 free points), but HUD is stale: it still shows old stats and MP 14/96 while System said current values are not refilled — will verify at #status later.
- zu Zug 25 (notiert vor Zug 26): Payout inconsistency: the System already booked +4s5c (to 7s5c) as the Guild payout, then the narrator's clerk paid 45 copper again — HUD still shows 7s5c, so possibly double-counted or just narrated. Also HUD maxes now read HP 100 / MP 132, differing from the earlier post-assign values (95/108).
- zu Zug 26 (notiert vor Zug 27): Coin discrepancy persists: System booked +4s5c to 7s5c, but the clerk also paid 45 copper; HUD shows 7s5c. HUD stats correctly updated after #assign, though MP max changed from 108 to 132 without explanation.
- zu Zug 27 (notiert vor Zug 28): HUD still shows 7s5c despite the System's earlier +4s5c booking; selling loot should clarify the true coin total. Journal/sign entries still reference the cellars I already left.
- zu Zug 28 (notiert vor Zug 29): Coin finally consistent: HUD shows 1 Gold 8 Copper, matching the System's 75→108 copper booking. MP is still low (14/132), so I'll need rest before hunting.
- zu Zug 29 (notiert vor Zug 30): Coin now consistent at 1 Gold 8 Copper after the 33c sale. Journal still shows stale cellar entries; HUD quest counter correctly tracks 0/3 hounds.
- zu Zug 30 (notiert vor Zug 31): Stew 2c, bread 1c, bunk 4c at the Gilded Yoke — affordable recovery options now known.
- zu Zug 31 (notiert vor Zug 32): Meal purchased cleanly (108→105 copper, stew/bread booked); HP and MP unchanged by food so far, so rest is still needed before the hunt.
- zu Zug 32 (notiert vor Zug 33): Bunk purchased cleanly (108→105, then −4 → 1 Gold 1 Copper); the engine initially flagged 'room not booked' but resolved the purchase. HP/MP unchanged until I actually sleep.
- zu Zug 33 (notiert vor Zug 34): Rest worked cleanly: HP 78→100, MP 14→95. Ready for the hound hunt.
- zu Zug 34 (notiert vor Zug 35): Two hounds visible at SHORT range, a third hidden in the culvert — manageable numbers for a L2 mage at full HP/MP.
- zu Zug 35 (notiert vor Zug 36): First Strike Flame Lance one-shot Dog B (48 dmg) but Dogs acted twice before my turn in Round 1-2; initiative order gave them two attacks. 89 HP, comfortable.
- zu Zug 36 (notiert vor Zug 37): Level 3 granted with 5 free stat points; quest shows 2/3 defeated, third hound hidden in culvert. MP 63/144, one Flame Lance left before needing rest.
- zu Zug 37 (notiert vor Zug 38): MP 63 is enough for one more Flame Lance (47-57 dmg vs 23 HP); HUD shows MP 63/144 while earlier combat panel said 132 max — minor tracking inconsistency.
- zu Zug 38 (notiert vor Zug 39): Contract 3/3 complete, ready for turn-in; MP tracking again inconsistent (47/144 in HUD vs 47/132 in combat panel).
- zu Zug 39 (notiert vor Zug 40): Loot dropped: 3 pelts, 4 fangs total. MP max inconsistency persists (144 vs 132). Stat assign booked cleanly.
- zu Zug 40 (notiert vor Zug 41): Contract paid out only 25 copper despite the earlier +2s5c coin line — payout amounts inconsistent. MP max now shows 176, third different value (132/144/176).
- zu Zug 41 (notiert vor Zug 42): MP max now 176 in HUD; earlier panels showed 132 and 144 — third different value. Coin and quest payout booked cleanly.
- zu Zug 42 (notiert vor Zug 43): Tam offered 14 copper for all loot; HUD confirms pelts and fangs still carried until sale books. Coin currently 1g2s6c.
- zu Zug 43 (notiert vor Zug 44): Sale and coin booked cleanly (126→140c); HUD now shows 1g4s but the copper healing fee isn't deducted yet. MP max 176 seems to have stuck this time.
- zu Zug 44 (notiert vor Zug 45): Healing not yet booked in HUD (HP 89/105, coin 1g4s, no copper deducted). Marthe confirmed Guild instructors upstairs teach skills by day — good lead.
- zu Zug 45 (notiert vor Zug 46): Instructor offers Flame Lance stone+lesson for 4 silver; affordable at 1g4s, and I already have Flame Lance P1 so this should raise it — worth verifying the engine books it.
- zu Zug 46 (notiert vor Zug 47): Paid 4s for the Flame Lance stone and lesson, but the HUD still shows Flame Lance P1 — the training is not reflected; I'll verify with #status tomorrow. Also the healing fee still never showed as deducted despite Marthe taking the copper.
- zu Zug 47 (notiert vor Zug 48): Bunk fee of 4 copper not reflected: coin shows 1 Gold but should be 96 copper after the room. Flame Lance still P1 in HUD despite the lesson — checking with #status.
- zu Zug 48 (notiert vor Zug 49): Narrator describes Flame Lance as learned and settled, yet HUD still lists Flame Lance P1; also odd: time shows Day 2, 00:02 night after waking at dawn, and coin shows 1 Gold with the 4c bunk fee unbooked.
- zu Zug 49 (notiert vor Zug 50): Status confirms Flame Lance is still P1 despite the paid lesson — training not booked in the engine. Coin shows 1 Gold with no deductions for the 4c bunk or healing fee, and time reads Day 2 00:02 night despite waking at dawn.
- zu Zug 50 (notiert vor Zug 51): Coin now books correctly (9s8c after 2c breakfast), but MP is still 47/176 after a full night's sleep — rest did not restore mana. Time also still reads Day 2, 00:32 night despite the dawn walk to the Guild.
- zu Zug 51 (notiert vor Zug 52): Engine rejected quest.accept with 'no such contract' even though the slip was just posted; narrator also replayed the breakfast/inn scene and moved me back to the inn despite my Guild action. Coin books correctly now (9s8c), but MP stayed 47/176 after sleep and the clock still reads Day 2 night.
- zu Zug 52 (notiert vor Zug 53): Narrator again replayed the night-inn scene and ignored my line to the clerk; HUD time is stuck around Day 2, 00:52 while the story has moved to morning. The beetle sweep slip exists in prose but quest.accept says 'no such contract' — engine/narrator desync on contracts.
- zu Zug 53 (notiert vor Zug 54): Tallow Lane sweep never reappeared; new Novice board offers several culls. MP still 47/176 at midday after a full night's rest — mana recovery seems broken.
- zu Zug 54 (notiert vor Zug 55): Quest accepted and engine-booked (active, 0/1). MP still 47/176 at midday despite a full night's sleep — recovery problem persists.
- zu Zug 55 (notiert vor Zug 56): Clerk offered mana recovery options: apothecary draughts 4-6s, temple restoration ~1s/dozen, or slow food-and-rest. MP still 47/176.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t11 | 11 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t12 | 12 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t19 | 20 | 4 | – | nein | 4 | gewonnen, 96 XP |
| enc.t33 | 35 | 2 | – | nein | 2 | gewonnen, 48 XP |
| enc.t36 | 38 | 1 | – | nein | 1 | gewonnen, 24 XP |

## Quests

- **Cull the Bog Striders at the Reed Flats Eel-Weirs** — expired (Zug 53)
  - Aufgabe: Hunt and cull 4 bog striders nesting among the eel-weirs of the Reed Flats so the eel boats can launch safely again.
  - Endzustand: 4 bog striders are culled and the eel boats launch from the Reed Flats again.
- **Hunt the Stray Hound Pack by the Brick Kilns** — active (Zug 29) → completed (Zug 40), READY
  - Aufgabe: Hunt down 3 feral dogs that have denned by the abandoned brick kilns and been savaging cart drivers on the kiln road.
  - Endzustand: The 3 feral dogs denned by the abandoned brick kilns are hunted down and the kiln road is safe for cart traffic.
- **Hunt the Pale Heron of the Drowned Orchard** — expired (Zug 53)
  - Aufgabe: Hunt and defeat the single pale heron that has taken up roost in the Drowned Orchard and strips a tree's fruit-buds bare each dawn.
  - Endzustand: The pale heron roosting in the Drowned Orchard is defeated and the orchard's budding trees are left in peace.
- **Cull the Gnaw-Rats in the Grain Row Cellars** — active (Zug 5) → completed (Zug 25), READY
  - Aufgabe: Hunt and cull 6 overgrown gnaw-rats burrowed into the grain warehouses' cellar row before they eat through another season's stores.
  - Endzustand: 6 gnaw-rats are culled from the Grain Row cellars and the warehouse stores are no longer being eaten into.
- **Clear Old Crown Catacombs, Level 1** — expired (Zug 53), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of Old Crown Catacombs. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Old Crown Catacombs is clear.
- **Cull the Feral Boar Sow of the Pig Market Alleys** — active (Zug 54)
  - Aufgabe: Hunt down and kill the 1 feral boar sow that has been breaking into the pig market pens and goring a drover.
  - Endzustand: The feral boar sow is killed and the pig market pens are safe from her break-ins.

## Auffälligkeiten

- Zug 57 (Runner/UI): no reply after the message
- Zug 4, Nachricht 7 (planner_repaired): the planner's first answer needed a repair
- Zug 8, Nachricht 16 (extraction_repaired): the extractor's first answer needed a repair
- Zug 13, Nachricht 26 (extraction_repaired): the extractor's first answer needed a repair
- Zug 34, Nachricht 68 (extraction_repaired): the extractor's first answer needed a repair
- Zug 44, Nachricht 88 (extraction_repaired): the extractor's first answer needed a repair
- Zug 46, Nachricht 91 (planner_repaired): the planner's first answer needed a repair
- Zug 50, Nachricht 100 (extraction_repaired): the extractor's first answer needed a repair
- Zug 53, Nachricht 105 (planner_repaired): the planner's first answer needed a repair
- Zug 57, Nachricht 113 (planner_failed): the planner failed: commands[0] (offer.accept): agreed price 50 cp differs from this offer's 60 cp; clarify instead of substituting an offer
- Zug 57, Nachricht 113 (planner_repaired): the planner's first answer needed a repair
- Hinweis (error): Avereth Engine: planner failed (commands[0] (offer.accept): agreed price 50 cp differs from this offer's 60 cp; clarify instead of substituting an offer). Regenerate or send the message again; no story turn was generated.
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 32× keine gültige JSON-Entscheidung (Züge 1, 4, 6, 7, 8, 9, 10, 11, 14, 15, 16, 17, 19, 20, 21, 22, 23, 25, 30, 31, 32, 34, 36, 37, 38, 39, 41, 42, 49, 54, 55, 56)

System-Panels: CLARIFY 0, NOT TAKEN 0, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: guild_canon 1, engine_owned_combat 1, engine_owned_fact 4, group_unclear 1, world_rule 2, guild_completion 1, offer 1, ambient 1, quest_count 1, attack_commitment 1, recover 1, time_cap 1, no_go 2, scene_context 5, entity_fact 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 55 | 4 | 2.7 s | 9.3 s | 11100 | 9590 | 83 | – | stop 55 | 0 |
| narrator | 50 | 0 | 11.7 s | 19.5 s | 11457 | 8822 | 383 | – | stop 50 | 0 |
| extract | 55 | 5 | 9.5 s | 16.3 s | 10910 | 8885 | 376 | – | stop 55 | 0 |
| board | 2 | 0 | 18.8 s | 26.5 s | 1907 | 847 | 1041 | – | stop 2 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 34:57 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 17.9 s) | 0:34 min |
| 57 Züge, Spiel (Senden bis HUD nach der Extraktion) | 26:29 min — Median 27.1 s, p90 45.5 s, max 63.1 s |
| 57 Züge, Spieler-Entscheidung | 6:57 min — Median 6.3 s, 32 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 3:41 min / 0:38 min / 10:53 min / 8:56 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 35.2 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 23:28 min, 80 Züge ≈ 46:56 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Provider extract | 45 | 126 | 31.6 s | 9.5 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
