# Avereth Live-Test 20261026-031107Z-current_test

## Kurzfassung

- **Ergebnis:** Niederlage — turn 58: he died
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_duration (nicht erreicht)
- **Charakter:** mage (mage.arcane_bolt, mage.flame_lance) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world long playtest — Guild adventurer progression“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: pragmatic Guild adventurer: value achievable contracts, loot sales and useful gear or skill investments without reckless fights
- **Züge:** 58 · **Dauer:** 35:31 min · **LLM-Aufrufe der Engine/des Erzählers:** 168
- **Auffälligkeiten:** 6 · **Niederlage** in Zug 58: he died
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.93 |
| Git | 471d5e8c3509 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 17.4 s |
| Browser | chrome 155.0.8059.85 |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261026-031107Z-current_test“, Seed 90437686 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_duration | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | I choose Mage. | Engine (Menü/Rückfrage) | creation_complete | Pick Mage as base class. | public roadside verge outside Alderwatch | 90/84 | 2.3 s |
| 2 | I choose Arcane Bolt and Flame Lance. | Engine (Menü/Rückfrage) | creation_complete | Finish character creation with two offensive starter skills. | public roadside verge outside Alderwatch | 90/96 | 2.1 s |
| 3 | I walk to Alderwatch's city gate and head for the Adventurers' Guild hall to look at the contract board. | Erzähler | open_run_duration | Enter town and find a suitable F-rank Guild contract. | Adventurers' Guild hall, Alderwatch | 90/96 | 38.2 s |
| 4 | I take the snapjaw lizard notice to the clerk and ask him to make it active. | Erzähler | open_run_duration | Accept the F-rank snapjaw lizard cull contract. | Adventurers' Guild hall, Alderwatch | 90/96 | 15.5 s |
| 5 | I pay the two silver registration fee and put my hand on the measuring stone. | Erzähler | open_run_duration | Register with the Guild so the snapjaw lizard contract can be activated. | Adventurers' Guild hall, Alderwatch | 90/96 | 16.6 s |
| 6 | I head out of the Guild hall and walk to the wharf road to find Ferrin Ott below the Netmenders' Stairs. | Erzähler | open_run_duration | Travel to the client to get the lizard's location and start the hunt. | Netmenders' Stairs drying racks | 90/96 | 23.7 s |
| 7 | I ask Ferrin Ott where the best spot is to wait out of sight, then position myself near the low racks and keep watch for the lizard. | Erzähler | open_run_duration | Set up an ambush by the low racks and wait for the snapjaw lizard. | Netmenders' Stairs drying racks | 90/96 | 28.2 s |
| 8 | I stay hidden behind the cork floats and cast Flame Lance at the lizard while it's still crossing the open mud. | Erzähler | open_run_duration | Ambush the snapjaw lizard with Flame Lance from cover. | Netmenders' Stairs drying racks | 90/96 | 25.6 s |
| 9 | I cast Flame Lance at the lizard before it can bolt for the water. | Erzähler | open_run_duration | Ambush the snapjaw lizard with Flame Lance while it hesitates on the mud. | Netmenders' Stairs drying racks | 90/80 | 21.4 s |
| 10 | I tell Ferrin the lizard's taken care of, and ask him where in town I could sell the skin and fangs. | Erzähler | open_run_duration | Wrap up the contract at the client and learn where to sell the loot. | Netmenders' Stairs drying racks | 90/80 | 42.1 s |
| 11 | I accept the offer and skin the lizard at Ferrin's shed using the hook and beam. | Erzähler | open_run_duration | Skin the lizard properly before the hide spoils, then sell it. | Ferrin's shed | 90/80 | 26.3 s |
| 12 | I thank Ferrin and carry the hide and fangs up to Hobbin's shop, asking what he'll offer for the skin and the two whole fangs. | Erzähler | open_run_duration | Sell the lizard loot to Hobbin the chandler and get a real offer. | Hobbin's chandler shop | 90/80 | 28.0 s |
| 13 | "Eighteen suits me, you weighed the fangs fair. Done at eighteen." | Erzähler | open_run_duration | Sell the hide and fangs to Hobbin for 18 copper. | Hobbin's chandler shop | 90/80 | 15.8 s |
| 14 | I ask Hobbin if he knows where a novice mage could find a decent weapon or a bit of armour worth buying nearby, then head for the Guild hall… | Erzähler | open_run_duration | Get shopping pointers and take a new Guild contract. | Adventurers' Guild hall, Alderwatch | 90/80 | 23.2 s |
| 15 | I take the Stranglewillow Saplings notice to the clerk and ask to accept it. | Erzähler | open_run_duration | Accept the 60-copper sapling cull contract at the Guild counter. | Adventurers' Guild hall, Alderwatch | 90/80 | 18.6 s |
| 16 | I follow the wharf road south past the fish market toward Tanners' Wharf, looking for the yard-warden Doss. | Erzähler | open_run_duration | Travel to Tanners' Wharf and find Doss to locate the saplings. | Tanners' Wharf | 90/80 | 25.1 s |
| 17 | "Flame's risky near the vats — I'll cut them instead. Can your yard hands lend me a sapling-sized axe or billhook?" | Erzähler | open_run_duration | Ask Doss for a cutting tool so I can fell the saplings without cracking the vats. | Tanners' Wharf | 90/80 | 21.4 s |
| 18 | I take the billhook and start on the two dry saplings by the fence, cutting each low and watching the yard hands stay clear. | Erzähler | open_run_duration | Fell the two dry saplings away from the cracked vat. | Tanners' Wharf | 90/80 | 31.9 s |
| 19 | I back away from the reaching roots and cast Flame Lance at the animated sapling. | Erzähler | open_run_duration | Fight the animated stranglewillow with Flame Lance from a safe distance. | Tanners' Wharf | 81/64 | 20.1 s |
| 20 | I cast Flame Lance at the sapling again to burn it down. | Erzähler | open_run_duration | Finish the animated sapling with another Flame Lance. | Tanners' Wharf | 81/48 | 20.8 s |
| 21 | "Cutting it is, then." I approach the sapling in the brickwork carefully and start cutting it low with the billhook, well clear of the crack… | Engine (Menü/Rückfrage) | open_run_duration | Fell the third sapling by cutting to avoid cracking the vat. | Tanners' Wharf | 81/48 | 5.6 s |
| 22 | The System says the sapling isn't a valid target — Doss, is the third sapling actually here in the yard, or is it somewhere else I need to g… | Erzähler | open_run_duration | Resolve the target-validity mismatch by asking Doss where the third sapling actually is. | Tanners' Wharf | 81/48 | 30.3 s |
| 23 | "Then that's the third one. I'll go have a look at the springy plank by the third piling — Doss, anything I should know about the wharf down… | Erzähler | open_run_duration | Head to the third piling to find the real third sapling, asking Doss for local details fir… | Third piling plank | 81/48 | 27.2 s |
| 24 | I stand back from the seam, then hack through the lifted plank with the billhook, ready to leap back if anything reaches up. | Erzähler | open_run_duration | Cut through the springy plank to expose and fell the third stranglewillow sapling. | Third piling plank | 81/48 | 28.5 s |
| 25 | I hook the billhook under the sapling's trunk and heave it up onto the planks, keeping my weight back and away from the reaching tendrils. | Erzähler | open_run_duration | Drag the third sapling up onto the planks so I can burn it in the open. | Third piling plank | 81/48 | 22.6 s |
| 26 | I cast Flame Lance at the sapling on the planks, then step back out of tendril reach. | Erzähler | open_run_duration | Burn the hooked-out sapling dry on the planks to finish the third kill. | Third piling plank | 73/32 | 16.7 s |
| 27 | I cast Flame Lance at the sapling again. | Erzähler | open_run_duration | Finish the third sapling with a second Flame Lance. | Third piling plank | 73/16 | 23.3 s |
| 28 | "Doss, my contract slip still counts two of three — is there another live sapling left here, or can I report this done?" | Erzähler | open_run_duration | Confirm whether the 3/3 contract is actually complete or a sapling remains. | Third piling plank | 73/16 | 18.1 s |
| 29 | I walk down past the vats to the bark-pile ramp and strike the small sapling by the drain with my staff, staying out of tendril reach. | Erzähler | open_run_duration | Kill the third sapling under the bark ramp to complete the contract. | bark-pile ramp | 73/16 | 30.4 s |
| 30 | I strike the small sapling again with my staff, ready to step back if it lashes out. | Erzähler | open_run_duration | Kill the third sapling with staff strikes to complete the contract. | bark-pile ramp | 65/16 | 41.1 s |
| 31 | I strike the sapling again with my staff. | Erzähler | open_run_duration | Finish the third sapling with basic attacks to conserve MP and complete the contract. | bark-pile ramp | 56/16 | 15.3 s |
| 32 | I strike the sapling once more with my staff. | Erzähler | open_run_duration | Finish the third sapling with a basic attack to complete the contract. | bark-pile ramp | 56/16 | 17.3 s |
| 33 | I take the stool and rest a moment, then thank Doss and head back to the Guild hall to turn in the contract. | Erzähler | open_run_duration | Recover briefly, then turn in the completed 3/3 contract at the Guild for the reward. | Adventurers' Guild hall, Alderwatch | 56/16 | 33.2 s |
| 34 | #assign INT 2 WIL 2 VIT 1 | System (Befehl) | open_run_duration | Spend the 5 free stat points, then rest and look for a new Guild contract. | Adventurers' Guild hall, Alderwatch | 56/16 | 2.3 s |
| 35 | I pocket the coin and ask the clerk what contracts are still on the board, and whether he knows a cheap room and a healer nearby. | Erzähler | open_run_duration | Take the reward, browse remaining contracts, and find rest and healing for my wounds. | Adventurers' Guild hall, Alderwatch | 56/16 | 37.5 s |
| 36 | "The snapjaw lizard — what's the posted reward, and any warnings about it?" While he checks, I ask where the temple of Saint Corrin is exact… | Erzähler | open_run_duration | Compare the remaining contracts and get healing directions before picking one. | Adventurers' Guild hall, Alderwatch | 56/16 | 28.0 s |
| 37 | "Thanks. Make the snapjaw lizard contract active for me. I'll get this wound seen to at the temple first, then hunt it." | Erzähler | open_run_duration | Activate the snapjaw contract, then heal at the temple before hunting it. | Temple of Saint Corrin | 56/16 | 24.5 s |
| 38 | "Walk-in. Tore my side open on a stranglewillow sapling out east — it's been soaking drain-water, so I want it cleaned proper. What can you … | Erzähler | open_run_duration | Get the wound treated at the temple, then rest before hunting the snapjaw. | Temple of Saint Corrin | 56/16 | 28.8 s |
| 39 | "Wash, salve, and the mending — seven copper all told. Go ahead." | Erzähler | open_run_duration | Pay for full treatment including the mending-hands to heal the wound before hunting the sn… | Temple of Saint Corrin | 56/16 | 37.5 s |
| 40 | "First time in Alderwatch — the fire rumor's news to me." I finish the willow tea, then ask Brann: "Is there a cheap bed nearby where I can … | Erzähler | open_run_duration | Rest overnight to recover HP and MP before hunting the snapjaw. | Temple of Saint Corrin | 56/16 | 23.2 s |
| 41 | I head to the Drowned Bell and take the corner room for the night. | Erzähler | open_run_duration | Sleep at the Drowned Bell to recover HP and MP before hunting the snapjaw tomorrow. | The Drowned Bell | 56/16 | 25.8 s |
| 42 | I pay the copper for the corner room and two more for the stew, then eat and turn in for the night. | Erzähler | open_run_duration | Pay for room and stew, sleep overnight to recover HP and MP before hunting the snapjaw. | The Drowned Bell | 100/132 | 55.2 s |
| 43 | I head down to the wharf by the Netmenders' Stairs to hunt the snapjaw lizard. | Erzähler | open_run_duration | Go hunt the snapjaw lizard at the wharf. | Netmenders' Stairs drying racks | 100/132 | 37.4 s |
| 44 | I wait on the gallery boards above the mud, out of reach of the wallow mouth, watching for the snapjaw to emerge — and if it does, I hit it … | Erzähler | open_run_duration | Ambush the snapjaw from the gallery boards with Flame Lance when it shows. | Netmenders' Stairs drying racks | 100/132 | 32.6 s |
| 45 | I cast Flame Lance at the snapjaw's head. | Erzähler | open_run_duration | Ambush the snapjaw from the gallery boards with Flame Lance before it notices me. | Netmenders' Stairs drying racks | 100/116 | 23.4 s |
| 46 | I cast Flame Lance at the snapjaw again to finish it. | Erzähler | open_run_duration | Kill the badly wounded snapjaw with a second Flame Lance before it reaches the water. | Netmenders' Stairs drying racks | 100/100 | 27.7 s |
| 47 | I thank the netmender, then head to the Guildhall to turn in the snapjaw contract and ask about selling the carcass and the scale plates and… | Erzähler | open_run_duration | Turn in the snapjaw contract at the Guildhall and arrange selling the loot and carcass. | Adventurers' Guild hall, Alderwatch | 100/100 | 51.4 s |
| 48 | #assign INT 2 WIL 2 VIT 1 | System (Befehl) | open_run_duration | Spend the 5 free stat points from level 3 on INT, WIL and VIT. | Adventurers' Guild hall, Alderwatch | 100/100 | 2.4 s |
| 49 | "I'll sell both plates and both claws — two plates at two silver each, two claws at eight copper." I count them onto the counter, then ask w… | Erzähler | open_run_duration | Sell the snapjaw plates and claws at the standing rate and look for a new contract. | Adventurers' Guild hall, Alderwatch | 100/100 | 41.7 s |
| 50 | "The granary pest cull — make that one active for me." I take the notice to the clerk. | Erzähler | open_run_duration | Accept the granary pest cull contract from the novice board. | Adventurers' Guild hall, Alderwatch | 100/100 | 46.9 s |
| 51 | "Tell me more about the catacombs work from the temple wardens — where's it posted, and what does it pay?" | Erzähler | open_run_duration | Ask the clerk about the catacombs contract's posting location and pay. | Adventurers' Guild hall, Alderwatch | 100/100 | 32.3 s |
| 52 | "Is the temple wardens' catacombs notice up on the board right now? If so, I'll take it." | Erzähler | open_run_duration | Check if the catacombs cull notice is currently posted and accept it if so. | Adventurers' Guild hall, Alderwatch | 100/100 | 23.2 s |
| 53 | I head to Saint Corrin's and find the wardens' office by the healers' hall. "I'm a Guild novice, F-rank — I hear the wardens post catacombs … | Erzähler | open_run_duration | Ask the temple wardens directly about the next catacombs cull contract. | Temple of Saint Corrin | 100/100 | 55.0 s |
| 54 | "I'll take your word on it now — hired direct, twelve silver, first level only. Where do I collect a lamp, and where's the entrance?" | Erzähler | open_run_duration | Accept the wardens' direct catacombs cull hire and get logistics for starting today. | Temple of Saint Corrin | 100/100 | 63.0 s |
| 55 | I take the lamp and chit, then walk the west road to Saint Corrin's Fold and knock at Marta's cottage. "Brother Halden sent me — I'm hired t… | Erzähler | open_run_duration | Travel to the catacombs entrance and meet Marta to start the cull. | Marta's cottage | 100/100 | 53.5 s |
| 56 | I follow Marta to the chapel, help lift the flagstone by the back pew, and prop the door as she showed me. "Lead me down as far as the stair… | Erzähler | open_run_duration | Enter the catacombs with Marta and start clearing the first level. | old chapel of Saint Corrin's Fold | 100/100 | 65.5 s |
| 57 | I start with the nearest branching gallery, lamp high, keeping to the pillars and watching the niches as I advance. | Erzähler | open_run_duration | Begin clearing the first gallery, staying alert for restless dead by the niches. | Old Crown Catacombs | 100/100 | 33.4 s |
| 58 | I cast Flame Lance at the skeleton as it steps toward me. | Erzähler | open_run_duration | Open combat with my strongest fire spell before it closes distance. | Old Crown Catacombs | 0/84 | 35.6 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 1 (notiert vor Zug 2): Stats panel shows all stats raised by +2 (STR/VIT/AGI/PER 7 despite Mage favoring only INT/WIL) — possible engine oddity worth noting.
- zu Zug 2 (notiert vor Zug 3): Creation complete: Mage with Arcane Bolt and Flame Lance, 5 silver, starter gear equipped. Engine stats book the Mage +1 as INT 8/WIL 8; the earlier +2-to-everything oddity is corrected in the final panel.
- zu Zug 3 (notiert vor Zug 4): Contract board offers five novice culls; snapjaw lizard (25 cp, single enemy) looks safest solo starter work.
- zu Zug 4 (notiert vor Zug 5): Contract acceptance was blocked until Guild registration (2 silver); a real membership mechanic, not just narration.
- zu Zug 5 (notiert vor Zug 6): Narrator confirmed the contract active, but the HUD still shows Quests: — — possible booking lag or engine inconsistency. Registration fee booked as -20 copper (coin 50→30), consistent with HUD's 3 Silver.
- zu Zug 6 (notiert vor Zug 7): HUD still shows Quests: — despite the narrator confirming the contract active; coin display now reads 3 Silver, consistent with 30 copper.
- zu Zug 7 (notiert vor Zug 8): Combat panel appeared: Snapjaw Lizard A, HP 20/20, MEDIUM — single enemy, reasonable solo fight.
- zu Zug 8 (notiert vor Zug 9): My Flame Lance action was rejected last turn because Ferrin's shout triggered a stealth check that failed; the engine enforces one main action per turn. The lizard is now alert but not fleeing — still a workable opening.
- zu Zug 9 (notiert vor Zug 10): First strike Flame Lance one-shot the lizard for 43 damage; loot and XP (+24) booked correctly, but HUD Quests still shows '—' despite the active contract.
- zu Zug 11 (notiert vor Zug 12): Skinning done narratively; hide has a burned hole Ferrin says Hobbin will dock for. HUD Quests still shows '—' despite the active contract.
- zu Zug 12 (notiert vor Zug 13): Engine rejected the sell phrasing last turn as 'nobody to sell to' even though Hobbin was present and haggling; retrying with plain dialogue.
- zu Zug 13 (notiert vor Zug 14): Sale finally booked: +18 copper, coin 48 total. HUD Quests still shows '—' even though Ferrin's lizard contract was completed and paid, and no turn-in/reward line appeared for it.
- zu Zug 14 (notiert vor Zug 15): Contract board still lists the completed lizard cull; HUD Quests remains '—' with no turn-in record. Coin reads 4s8c, consistent with the sale.
- zu Zug 15 (notiert vor Zug 16): HUD Quests panel finally shows the active sapling contract with a 0/3 counter, though the board still lists the dead lizard's notice.
- zu Zug 16 (notiert vor Zug 17): Doss warns burning risks the vat beds; the contract counter sits at 0/3. MP is 80/96, so some spellcasting headroom exists if cutting fails.
- zu Zug 17 (notiert vor Zug 18): Billhook lent by Doss and now shown in HUD carried items; contract counter at 0/3.
- zu Zug 18 (notiert vor Zug 19): Second sapling animated into combat (HP 70, ENGAGED); counter still 0/3. Oddity: engine rejected 'I take the billhook' as already held, yet HUD carried list is consistent.
- zu Zug 19 (notiert vor Zug 20): Combat engine works smoothly: first strike bonus applied, MP 64, HP 81 after a 9-damage root lash. Sapling at 28/70, one more hit should end it.
- zu Zug 20 (notiert vor Zug 21): Sapling A defeated for +36 XP and 3 loot plates; Flame Lance gained 18 PP. HUD counter updated to 1/3. Doss advises cutting the third near the cracked vat.
- zu Zug 21 (notiert vor Zug 22): System rejected the third sapling as a target though the narrator describes it standing in the brickwork and Doss discusses cutting it — a narrator/System inconsistency. HUD shows 1/3 defeated.
- zu Zug 22 (notiert vor Zug 23): Narrator retconned the brickwork sapling into an ordinary willow to fix the target-validity mismatch; the third sapling is now under the wharf by the third piling. MP 48/96, HP 81/90.
- zu Zug 23 (notiert vor Zug 24): Signs warn the plank hides the sapling and a lizard may approach (gulls lifting as a tell); water is chest-deep, mud sucking, so I'll avoid going in.
- zu Zug 24 (notiert vor Zug 25): Sapling B engaged at 70/70; Doss suggests hooking it whole onto the planks to burn it dry, which avoids fighting in chest-deep water.
- zu Zug 25 (notiert vor Zug 26): Sapling B is fully exposed on the planks now; one Flame Lance (MP 48) should finish it and complete the 3/3 contract.
- zu Zug 26 (notiert vor Zug 27): Sapling B survived the first Flame Lance (27/70) and counterattacked for 8 damage; MP 32 covers one more cast at 16 MP.
- zu Zug 27 (notiert vor Zug 28): Contract panel still shows 2/3 despite three kills and the narrator earlier saying the brickwork sapling was retconned away; possible counting inconsistency. XP 96/100, so level-up is one small kill away; MP is low at 16.
- zu Zug 28 (notiert vor Zug 29): Doss clarified only two saplings were killed so far; the third is a small one by the bark ramp. HUD loot shows Scale Plate ×4 though the panel awarded ×1 earlier — possible counting oddity.
- zu Zug 29 (notiert vor Zug 30): MP is only 16/96, so conserving it with staff strikes is wise; HUD loot shows Scale Plate ×4 while panels awarded fewer, a counting inconsistency worth watching.
- zu Zug 30 (notiert vor Zug 31): Sapling C engaged and hit back for 8 (HP 65/90); two more basic attacks should finish it. Loot counting inconsistency (Scale Plate ×4 vs panels) still unresolved.
- zu Zug 31 (notiert vor Zug 32): HUD lists Arcane Bolt at 10 MP and Flame Lance at 16 MP while MP is 16; basic attack range shows MEDIUM despite narrator describing staff reach at ENGAGED.
- zu Zug 32 (notiert vor Zug 33): Level 2 granted +5 free stat points; spending 2 INT/2 WIL/1 VIT. HUD shows Scale Plate x5 vs panel awards of x1 per kill — loot counting still inconsistent.
- zu Zug 33 (notiert vor Zug 34): Quest turned in for 60 copper and 120 XP; engine now shows HP 56/95 and MP 16/108 (stats already applied?), loot still shows Scale Plate x5 vs panels awarding x1. Journal signs hint at a spoiled hide nearby and something under planks by a piling.
- zu Zug 34 (notiert vor Zug 35): Stat assignment booked correctly (INT 11, WIL 11, VIT 8). HUD still stale (shows old values and 5 free points); loot counting inconsistency persists (Scale Plate x5 vs x1 awards).
- zu Zug 35 (notiert vor Zug 36): HUD finally synced with assigned stats (INT 11, WIL 11, VIT 8) and MP now 132 max; HP 56/100 with a wound flag. Stale free-points display resolved.
- zu Zug 36 (notiert vor Zug 37): Odd rumor: a Guild man supposedly killed the snapjaw this morning with one fire throw, which I never did — possible world inconsistency. Contract board offers four Novice culls; snapjaw pays 8 silver.
- zu Zug 37 (notiert vor Zug 38): Quest panel shows reward 25 cp while the clerk read 8 silver off the slip — a second reward inconsistency. Odd pre-placed signs about Pell and the plank piling appear in the Here list before I've been there.
- zu Zug 38 (notiert vor Zug 39): Quest panel still shows 25 cp reward versus clerk's 8 silver quote — third reward discrepancy. Signs are pre-pointing me to the snapjaw den (springy plank detail) before I've even left the temple.
- zu Zug 39 (notiert vor Zug 40): Coin inconsistency again: purchase panel deducted 7 copper, but HUD still shows 1 Gold 1 Copper. Wound flag persists despite mending-hands; MP still only 16/132 with no recovery option shown yet.
- zu Zug 40 (notiert vor Zug 41): Coin discrepancy again: purchase panel deducted 7 copper (108→101) while HUD still shows 1 Gold 1 Copper. Wound flag persists despite mending-hands.
- zu Zug 41 (notiert vor Zug 42): Coin discrepancy persists: HUD still shows 1 Gold 1 Copper despite the 7-copper temple deduction; wound flag also persists after mending-hands.
- zu Zug 42 (notiert vor Zug 43): Full recovery confirmed after sleeping at the Drowned Bell: HP 100/100, MP 132/132, wound flag cleared. Coin now consistent at 9 Silver 8 Copper (98 copper), resolving the earlier HUD discrepancy.
- zu Zug 44 (notiert vor Zug 45): Snapjaw B is HP 84/84, larger than the earlier one; it hasn't spotted me yet, so first strike is free.
- zu Zug 45 (notiert vor Zug 46): Ambush crit landed for 74, leaving the snapjaw at 10/84; MP at 116 is enough for one more cast.
- zu Zug 46 (notiert vor Zug 47): Snapjaw B defeated cleanly with two ambush Flame Lances; +46 XP puts me at 198/200, nearly level 3. Carcass noted as sellable hide; contract marked ready for turn-in.
- zu Zug 47 (notiert vor Zug 48): Level 3 reached after turn-in, +2s5c payout, XP 44/300; HUD shows HP 100/105 'lightly wounded' though combat ended full at 100/100 — likely max-HP bump from leveling, worth watching.
- zu Zug 48 (notiert vor Zug 49): Stat assignment booked cleanly (INT 14, WIL 14, VIT 9 per System, though the old HUD still shows 12/12/8 and 'lightly wounded' at full HP). Clerk offers standing loot prices; also note the wharf rumor claims the lizard was killed by 'a Guild man' before I reported it.
- zu Zug 49 (notiert vor Zug 50): Engine blocked the plate/claw sale claiming nobody to sell to, yet the HUD still lists the snapjaw plates and claws as carried — inventory and narration contradict (clerk found pouch empty). Also HUD HP 100/110 still flagged 'lightly wounded' at full HP.
- zu Zug 50 (notiert vor Zug 51): The granary contract vanished from the board before I could take it; engine blocked acceptance with 'no such contract'. HUD still lists the snapjaw plates/claws as carried while the narrator says they're gone — persistent inventory contradiction.
- zu Zug 51 (notiert vor Zug 52): HUD still lists the snapjaw plates and claws as carried even though the narrator says the pouch held nothing—persistent inventory contradiction. MP shown as 100/168 while earlier panels said 116; also HP 'lightly wounded' at full value.
- zu Zug 52 (notiert vor Zug 53): No catacombs notice on the Guild board today; clerk pointed me to the wardens' office at Saint Corrin's. HUD still lists snapjaw plates/claws as carried despite the failed sale, and shows HP 100/110 'lightly wounded' with MP 100/168 after a long rest should have refilled both.
- zu Zug 53 (notiert vor Zug 54): HUD still shows snapjaw plates/claws as carried; 'lightly wounded' at full HP persists. Direct hire offered at same 12s posted rate, starting today.
- zu Zug 54 (notiert vor Zug 55): Halden gave a signed chit, a brass lamp (1 copper deposit), and directions; quest not yet shown in Quests panel — worth watching whether the engine registers the temple hire.
- zu Zug 55 (notiert vor Zug 56): Quests panel still empty despite the direct hire; goals show a paused travel goal that is already complete.
- zu Zug 56 (notiert vor Zug 57): Quests panel still empty despite the direct hire; HP shown 100/110 but MP dropped to 100/168 with no cast noted.
- zu Zug 57 (notiert vor Zug 58): Skeleton has 192 HP — far above anything fought so far; a long fight likely. Quests panel still empty despite the direct hire; dungeon gate card appeared saying entry 'books nothing' though I'm already inside.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t9 | 9 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t19 | 19 | 1 | – | nein | 1 | gewonnen, 36 XP |
| enc.t25 | 26 | 1 | – | nein | 1 | gewonnen, 36 XP |
| enc.t29 | 30 | 1 | – | nein | 1 | gewonnen, 36 XP |
| enc.t43 | 45 | 1 | – | nein | 1 | gewonnen, 46 XP |
| enc.t55 | 58 | 1 | – | nein | 0 | **tot** |

## Quests

- **Cull the Stranglewillow Saplings at Tanners' Wharf** — active (Zug 15) → completed (Zug 33), READY
  - Aufgabe: Cut down and destroy the 3 stranglewillow saplings growing among the tanning vats at Tanners' Wharf before their roots crack the vat beds.
  - Endzustand: The 3 stranglewillow saplings at Tanners' Wharf are destroyed and the tanning vats stand unharmed.
- **Cull the Wharfside Snapjaw Lizard** — active (Zug 37) → completed (Zug 47), READY
  - Aufgabe: Hunt down and kill the 1 snapjaw lizard that has been dragging fish from the drying racks below the Netmenders' Stairs.
  - Endzustand: The 1 snapjaw lizard raiding the drying racks below the Netmenders' Stairs is killed.

## Auffälligkeiten

- Zug 17, Nachricht 34 (extraction_repaired): the extractor's first answer needed a repair
- Zug 32, Nachricht 64 (extraction_repaired): the extractor's first answer needed a repair
- Zug 33, Nachricht 66 (extraction_repaired): the extractor's first answer needed a repair
- Zug 54, Nachricht 108 (extraction_repaired): the extractor's first answer needed a repair
- Zug 56, Nachricht 112 (extraction_repaired): the extractor's first answer needed a repair
- Zug 58, Nachricht 116 (extraction_repaired): the extractor's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 42× keine gültige JSON-Entscheidung (Züge 1, 4, 5, 7, 8, 9, 10, 11, 12, 13, 15, 16, 17, 18, 19, 25, 26, 27, 28, 29, 30, 32, 33, 35, 38, 39, 41, 42, 43, 44, 45, 46, 47, 48, 50, 51, 52, 54, 55, 56, 57, 58)

System-Panels: CLARIFY 0, NOT TAKEN 1, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: guild_canon_price 1, quest 1, world_rule 8, quest_count 1, scene_context 18, guild_canon 2, engine_owned_fact 3, offer 2, ambient 2, passage 2.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 54 | 0 | 2.8 s | 8.0 s | 11187 | 9708 | 86 | – | stop 54 | 0 |
| board | 2 | 1 | 8.3 s | 9.5 s | 2494 | 1013 | 1119 | – | stop 2 | 0 |
| narrator | 53 | 0 | 12.2 s | 21.4 s | 11587 | 8865 | 422 | – | stop 53 | 0 |
| extract | 59 | 6 | 7.4 s | 19.3 s | 11034 | 9002 | 416 | – | stop 59 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 35:31 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 17.4 s) | 0:32 min |
| 58 Züge, Spiel (Senden bis HUD nach der Extraktion) | 27:24 min — Median 26.7 s, p90 51.4 s, max 65.5 s |
| 58 Züge, Spieler-Entscheidung | 6:37 min — Median 4.7 s, 42 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 3:58 min / 0:17 min / 11:55 min / 9:10 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 35.2 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 23:28 min, 80 Züge ≈ 46:56 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spieler | 47 | – | 38.0 s | 4.7 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
