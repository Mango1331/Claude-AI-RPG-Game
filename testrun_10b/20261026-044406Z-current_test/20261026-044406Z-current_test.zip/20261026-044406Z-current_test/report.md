# Avereth Live-Test 20261026-044406Z-current_test

## Kurzfassung

- **Ergebnis:** planner_failed — turn 89: the semantic Planner failed before story generation (commands[0] (offer.accept): agreed price 2 cp differs from this offer's 3 cp; clarify instead of substituting an offer)
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 5. Sicherheitsgrenzen: 1000 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** noch nicht erreicht.
- **Charakter:** mage (mage.arcane_bolt, mage.flame_lance) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: independent cautious Guild adventurer: choose suitable contracts, prepare, recover, sell surplus loot and improve equipment and skills
- **Züge:** 89 · **Dauer:** 50:09 min · **LLM-Aufrufe der Engine/des Erzählers:** 260
- **Auffälligkeiten:** 16
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.94 |
| Git | 21f3822a468c (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 71.1 s |
| Browser | chrome 155.0.8059.85 |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261026-044406Z-current_test“, Seed 1165795224 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | I choose Mage. | Engine (Menü/Rückfrage) | creation_complete | Select Mage as base class. | public roadside verge outside Glassmere | 90/84 | 2.2 s |
| 2 | I choose Arcane Bolt and Flame Lance. | Engine (Menü/Rückfrage) | creation_complete | Pick two starter skills to finish character creation. | public roadside verge outside Glassmere | 90/96 | 2.1 s |
| 3 | I walk to the city gate of Glassmere and enter the city. | Erzähler | open_run_level | Enter Glassmere to find the Guild hall and a suitable first contract. | Glassmere | 90/96 | 33.5 s |
| 4 | I enter the building with the crossed-swords sign and look for the Guild reception. | Erzähler | open_run_level | Find the Guild hall and register, then look for a first contract. | Adventurers' Guild hall, Glassmere | 90/96 | 27.4 s |
| 5 | "Registering. I'd like to sign up as a Guild adventurer, please." | Erzähler | open_run_level | Register with the Guild at Clerk A's counter. | Adventurers' Guild hall, Glassmere | 90/96 | 14.5 s |
| 6 | "Yes, paying." I slide two silver across the counter and give my name as Alaric Red. | Erzähler | open_run_level | Pay the two-silver registration fee and register under my name. | Adventurers' Guild hall, Glassmere | 90/96 | 19.5 s |
| 7 | I walk to the near notice board and read the Novice contracts posted there. | Erzähler | open_run_level | Browse the Novice board for a first suitable contract. | Adventurers' Guild hall, Glassmere | 90/96 | 54.0 s |
| 8 | I take the stub for 'Cull the Quarry Slimes at the Old Sandstone Pit' and bring it to the free clerk with the wax seal to accept the contrac… | Erzähler | open_run_level | Accept the quarry slimes cull contract at the counter. | Adventurers' Guild hall, Glassmere | 90/96 | 20.6 s |
| 9 | I leave the Guild hall and head west along the road past the kilns toward the Old Sandstone Pit. | Erzähler | open_run_level | Travel to the contract site to hunt the quarry slimes. | Old Sandstone Pit | 90/96 | 30.1 s |
| 10 | I climb down the ladder to the second bench and cast Flame Lance at the half-beached slime closest to me. | Erzähler | open_run_level | Engage the nearest slime from the second bench. | Old Sandstone Pit | 65/80 | 17.2 s |
| 11 | I cast Flame Lance at Mineral Slime B. | Erzähler | open_run_level | Kill the engaged slime B with my strongest ranged spell. | Old Sandstone Pit | 45/64 | 38.1 s |
| 12 | I cast Flame Lance at Mineral Slime C. | Erzähler | open_run_level | Continue killing slimes one per round with Flame Lance, accepting chip damage. | Old Sandstone Pit | 30/48 | 20.9 s |
| 13 | I cast Flame Lance at Mineral Slime D. | Erzähler | open_run_level | Continue killing slimes one per round; three more rounds should finish the contract. | Old Sandstone Pit | 20/32 | 11.9 s |
| 14 | I cast Flame Lance at Mineral Slime F. | Erzähler | open_run_level | Kill the fifth slime; one more round should finish the contract. | Old Sandstone Pit | 15/16 | 11.6 s |
| 15 | I cast Flame Lance at Mineral Slime E. | Erzähler | open_run_level | Kill the last slime to complete the contract. | Old Sandstone Pit | 15/0 | 18.2 s |
| 16 | I assign my 5 free stat points: #assign VIT 2 INT 2 WIL 1 | Erzähler | open_run_level | Spend level-up points to boost survivability and magic, then prepare to climb out and rest… | Old Sandstone Pit | 15/0 | 13.2 s |
| 17 | I climb the ladder out of the pit and head back to Caelreth; once in town I turn the contract slip in at the Guild hall and then find lodgin… | Erzähler | open_run_level | Leave the pit, turn in the completed contract at the Guild, then rest to recover HP and MP… | Dripping Antler, small room | 15/0 | 67.4 s |
| 18 | "A night's room, and yes, bring food up. I'll sleep until morning." | Erzähler | open_run_level | Pay for lodging, eat, and sleep through the night to recover HP and MP. | Dripping Antler, small room | 95/108 | 36.7 s |
| 19 | #assign VIT 2 INT 2 WIL 1 | System (Befehl) | open_run_level | Re-issue the stat assignment as a standalone System command since the HUD never recorded i… | Dripping Antler, small room | 95/108 | 2.2 s |
| 20 | I set out from Glassmere and travel east to Asterhall; once there, I turn the READY cull slip in at the Asterhall Guild branch desk. | Erzähler | open_run_level | Travel to the Asterhall branch to turn in the completed slime contract for payout. | Asterhall Guild branch | 95/108 | 51.2 s |
| 21 | I approach Clerk C and hand over the contract slip. "Cull the Quarry Slimes at the Old Sandstone Pit — all six done. Here to turn it in and … | Erzähler | open_run_level | Turn in the completed slime cull contract with Clerk C and collect the reward. | Asterhall Guild branch | 95/108 | 38.5 s |
| 22 | "I'll try the mediation desk — where do I find the senior clerk's back room?" I ask, and head there to have the crossed entry sorted tonight… | Erzähler | open_run_level | Use the mediation desk to fix the crossed contract entry tonight. | Senior clerk's back room | 95/108 | 62.9 s |
| 23 | "Yes, I worked it myself — six slimes in the lower benches, west road. Please correct the entry so the payout can go through." | Erzähler | open_run_level | Confirm the work to Harsk and have him fix the crossed entry tonight. | Senior clerk's back room | 95/108 | 36.5 s |
| 24 | "Alaric Red. Put me down as waiting in Asterhall — I'll be here when the confirmation comes back, so the payout can go the same hour." | Erzähler | open_run_level | Give Harsk my name for the statement and choose to wait in Asterhall for the confirmation. | Senior clerk's back room | 95/108 | 25.1 s |
| 25 | "Nothing else — thanks, Harsk." I pocket the slip and head out to the Guild counter to ask about selling slime gel and cores, and whether an… | Erzähler | open_run_level | Leave the back room, sell surplus loot and pick up a short local contract while waiting fo… | Adventurers' Guild hall, Asterhall | 95/108 | 37.5 s |
| 26 | I head to Denna's materials desk in the alcove. "Corven sent me over — I have nine lots of mineral slime gel and three cores from the sandst… | Erzähler | open_run_level | Get a purchase offer from Denna for my slime gel and cores. | Denna's materials desk | 95/108 | 43.2 s |
| 27 | "I'll sell the gel and take the twelve silver for the cores too — cash for the whole lot, twelve silver four copper." I push the bundles and… | Erzähler | open_run_level | Accept Denna's offer and sell all nine gel lots and three cores for 12s 4c. | Denna's materials desk | 95/108 | 73.8 s |
| 28 | I pocket the three silver six copper and take my cores back. "Understood — I'll keep the cores for now." I return to Corven at the counter. … | Erzähler | open_run_level | Accept the gel-only sale, keep the cores, and ask Corven what F-rank contracts remain on t… | Adventurers' Guild hall, Asterhall | 95/108 | 60.5 s |
| 29 | I hand Corven the pit contract slip. "The sandstone pit job's done — six slimes culled. Here's the slip, pay me out." | Erzähler | open_run_level | Turn in the completed Quarry Slimes contract and collect the 160 cp reward. | Adventurers' Guild hall, Asterhall | 95/108 | 22.2 s |
| 30 | "That's all tonight — goodnight, Corven." I take the easiest copper: "I'll take the Cellar Lurker slip — the barrel-mite at the Tapped Keg."… | Erzähler | open_run_level | Turn in done, take and register the Cellar Lurker contract before the hall closes. | Adventurers' Guild hall, Asterhall | 95/108 | 60.3 s |
| 31 | I head behind the bar to the cellar door, minding the cracked third step, and go down to hunt the barrel-mite. | Erzähler | open_run_level | Enter the Tapped Keg cellar and hunt the barrel-mite. | The Tapped Keg cellar | 95/108 | 33.3 s |
| 32 | I cast Flame Lance at the charging barrel-mite. | Erzähler | open_run_level | Kill the barrel-mite with Flame Lance. | The Tapped Keg cellar | 95/92 | 30.7 s |
| 33 | #assign INT 4 WIL 4 VIT 2 | System (Befehl) | open_run_level | Spend the 5 free stat points from Level 4 on INT, WIL and VIT. | The Tapped Keg cellar | 95/92 | 2.2 s |
| 34 | I pick up the contract slip and head back up the stairs, minding the cracked third step, then go to the barwoman. "Your cellar pest is dead.… | Erzähler | open_run_level | Report the kill upstairs and plan turn-in of the Cellar Lurker contract. | The Tapped Keg | 95/92 | 23.1 s |
| 35 | I take the tankard and drink, then ask the barmaid about lodging for the night. | Erzähler | open_run_level | Accept the free drink and arrange a room to sleep and recover before tomorrow's turn-in. | The Tapped Keg | 95/92 | 21.0 s |
| 36 | "I'll take the room here — four coppers." I pay her and head up to sleep until morning. | Erzähler | open_run_level | Buy the 4-copper room at the Tapped Keg and sleep until morning to recover. | The Tapped Keg | 125/200 | 26.7 s |
| 37 | I grab a quick breakfast at the bar, then head to the Guild hall to turn in the Cull the Cellar Lurker contract. | Erzähler | open_run_level | Eat briefly, then turn in the completed cellar contract at the Guild hall. | Adventurers' Guild hall, Asterhall | 125/200 | 21.7 s |
| 38 | "I'd like to sell some loot — three F-Rank Mineral Slime Cores and a barrel-mite tail. What will the Guild pay?" Then I read the contract bo… | Erzähler | open_run_level | Sell surplus loot at the Guild desk and pick a new contract from the board. | Adventurers' Guild hall, Asterhall | 125/200 | 43.8 s |
| 39 | "I'll take the Cull the Millpond Gnashers contract, Corven." I take the slip and head for the Aldermill millpond. | Erzähler | open_run_level | Accept the millpond gnashers contract and travel to the Aldermill millpond. | Aldermill millpond | 125/200 | 30.5 s |
| 40 | I draw my staff and cast Flame Lance at the snapping turtle under the washing steps. | Erzähler | open_run_level | Attack the turtle at the washing steps to start the gnasher cull. | Aldermill millpond | 118/184 | 20.4 s |
| 41 | I cast Arcane Bolt at the wounded turtle to finish it. | Erzähler | open_run_level | Finish off Snapping Turtle A with Arcane Bolt. | Aldermill millpond | 118/174 | 25.5 s |
| 42 | I ask the woman by the baskets where the other gnashers usually lair, then search the pond's edge and the weir for the next turtle. | Erzähler | open_run_level | Continue the 4-turtle cull by locating the next one. | Aldermill millpond | 118/174 | 27.0 s |
| 43 | I walk to the mill and ask Old Tam where the other three gnashers usually sit — the drowned willow, the weir, or the deep side. | Erzähler | open_run_level | Get the miller's info on turtle lairs to find the next one. | the grain mill at Aldermill | 118/174 | 29.1 s |
| 44 | "Thanks, Tam." I head for the drowned willow and look for the big one sunning on the trunk while the sun is still climbing. | Erzähler | open_run_level | Find and fight the big turtle at the drowned willow before midday. | drowned willow | 118/174 | 29.3 s |
| 45 | I cast Flame Lance at the big turtle's head and neck from the shore. | Erzähler | open_run_level | Open the fight against Snapping Turtle B with Flame Lance from range. | drowned willow | 118/158 | 21.9 s |
| 46 | I head to the weir channel and look for the turtle behind the timbers. | Erzähler | open_run_level | Find and fight the third turtle at the weir. | weir channel | 118/158 | 34.2 s |
| 47 | I cast Flame Lance at the turtle behind the weir timbers before it can slip into the current. | Erzähler | open_run_level | Open the fight against Snapping Turtle C with Flame Lance from the bank. | weir channel | 110/142 | 16.8 s |
| 48 | I cast Arcane Bolt at the turtle at my feet. | Erzähler | open_run_level | Finish the wounded Snapping Turtle C at close range with Arcane Bolt. | weir channel | 110/132 | 17.5 s |
| 49 | I walk the pond edge toward the washing steps and scan the water for the fourth turtle. | Erzähler | open_run_level | Find the fourth and last millpond turtle. | weir channel | 110/132 | 24.3 s |
| 50 | I sit still at the washing steps and watch the shallows for a long while, waiting for the fourth turtle to show itself. | Erzähler | open_run_level | Stake out the washing steps to spot the hidden fourth turtle. | weir channel | 110/132 | 20.3 s |
| 51 | I cast Flame Lance at the basking turtle on the sunken log. | Erzähler | open_run_level | Finish the fourth turtle with Flame Lance at range. | weir channel | 110/116 | 16.9 s |
| 52 | I head back to Aldermill and turn in the completed contract at the Guild hall. | Erzähler | open_run_level | Turn in the finished turtle cull contract at the Guild hall. | Aldermill millpond | 110/116 | 36.6 s |
| 53 | I ask at the mill if any cart or trader is heading toward a larger town with a Guild branch, and which town that would be. | Erzähler | open_run_level | Find the nearest town with a Guild hall to turn in the contract. | the grain mill at Aldermill | 110/116 | 29.9 s |
| 54 | "I'll take that offer, Tam — a hand with the sacks today, a straw loft tonight, and a spot on Tammi's cart at first light for Thornbury." | Erzähler | open_run_level | Arrange lodging, work-for-bed and tomorrow's cart to Thornbury with Tam. | mill loft | 110/116 | 24.1 s |
| 55 | I sleep in the straw loft until morning. | Erzähler | open_run_level | Sleep overnight in the loft to recover before the cart ride. | mill loft | 125/200 | 21.3 s |
| 56 | "Room on the sacks at the back suits me fine, Tammi — let's ride for Thornbury." | Erzähler | open_run_level | Board Tammi's cart to Thornbury. | Thornbury | 125/200 | 47.7 s |
| 57 | I head to the Guild hall in Thornbury and turn in the completed 'Cull the Millpond Gnashers' contract. | Erzähler | open_run_level | Turn in the turtle cull contract at Thornbury's Guild hall. | Thornbury | 125/200 | 43.3 s |
| 58 | "One look at the board before you lock up — what's on it for a Novice mage?" | Erzähler | open_run_level | Check the Guild board for a suitable new contract before the hall closes. | Thornbury | 125/200 | 23.4 s |
| 59 | I find an affordable inn near the Guild hall, get a room, and sleep until dawn. | Erzähler | open_run_level | Lodge overnight near the Guild hall and sleep until dawn to be first at the board. | Bridge and Plough inn | 125/200 | 18.9 s |
| 60 | "The small room at the back, please — six copper. I'll take it and sleep until first light." | Erzähler | open_run_level | Book the six-copper room and sleep until dawn. | Bridge and Plough inn | 125/200 | 38.6 s |
| 61 | I eat the porridge, then head to the Guild hall down the street and turn in the completed 'Cull the Millpond Gnashers' contract slip. | Erzähler | open_run_level | Turn in the gnasher contract and check the Novice board for new dawn postings. | Adventurers' Guild hall, Asterhall | 125/200 | 19.4 s |
| 62 | "What's on the Novice board this morning? I'm after a new contract." | Erzähler | open_run_level | Ask the clerk about current Novice board postings. | Adventurers' Guild hall, Asterhall | 125/200 | 22.6 s |
| 63 | "I'll take the Bog Striders cull at the Reed Flats Eel-Weirs — make it active, please." | Erzähler | open_run_level | Accept the bog strider cull contract, the highest-paying Novice posting. | Adventurers' Guild hall, Asterhall | 125/200 | 15.2 s |
| 64 | "Nothing else. I'll head to the Reed Flats and find Drest Hallow at the eel-weirs." | Erzähler | open_run_level | Leave the Guild and travel to the Reed Flats eel-weirs to meet foreman Drest Hallow about … | Reed Flats eel-weirs | 125/200 | 26.4 s |
| 65 | "That's me. Where are the striders nesting, and where should I avoid wading in?" | Erzähler | open_run_level | Ask Drest Hallow for strider locations and tactics advice. | Reed Flats eel-weirs | 125/200 | 34.3 s |
| 66 | "Walk me down as far as the bend, then. I'll take the big four from the weirs themselves — no wading." | Erzähler | open_run_level | Have Drest guide me to the bend, then fight the four big striders from the weir planking. | the bend at the third weir | 125/200 | 29.1 s |
| 67 | I cast Flame Lance at the closest bog strider, staying on the sound planking. | Erzähler | open_run_level | Open the fight from the weir planking with Flame Lance. | the bend at the third weir | 125/184 | 21.1 s |
| 68 | I cast Flame Lance at the next strider, Bog Strider B, keeping my footing on the sound planking. | Erzähler | open_run_level | Continue the cull, one Flame Lance per strider from the planking. | the bend at the third weir | 119/168 | 22.2 s |
| 69 | I cast Flame Lance at Bog Strider C. | Erzähler | open_run_level | Kill strider C with Flame Lance before the two strike again. | the bend at the third weir | 116/152 | 18.8 s |
| 70 | I cast Flame Lance at Bog Strider D. | Erzähler | open_run_level | Kill the last strider to complete the cull. | the bend at the third weir | 116/136 | 18.7 s |
| 71 | #assign INT 2 WIL 2 VIT 1 | System (Befehl) | open_run_level | Spend the 5 new level-up stat points, then return to Thornbury to turn in the strider cont… | the bend at the third weir | 116/136 | 2.3 s |
| 72 | I head back along the bank path to Thornbury and turn in the strider cull contract at the Guild hall. | Erzähler | open_run_level | Return to Thornbury Guild hall and turn in the completed bog strider cull. | Thornbury | 116/136 | 18.6 s |
| 73 | I ask the boy at the well where the nearest Guild office or clerk in Thornbury is, or whether contract slips can be turned in anywhere here … | Erzähler | open_run_level | Ask the boy whether Thornbury has any way to turn in the completed contract locally. | Thornbury | 116/136 | 20.5 s |
| 74 | I set out for Marrowbridge downriver, taking the road toward Harl's Staithe to catch the ferry if it's running. | Erzähler | open_run_level | Travel toward Marrowbridge to turn in the strider contract at the Guild hall there. | Marrowbridge | 116/136 | 31.1 s |
| 75 | I enter the Marrowbridge Guild hall and turn in the completed bog strider cull contract. | Erzähler | open_run_level | Turn in the 4/4 bog strider cull at the Marrowbridge Guild hall. | Marrowbridge | 116/136 | 30.5 s |
| 76 | I take the ninety copper and read the Novice-rank slips on the left side of the board before the day's listings are struck. | Erzähler | open_run_level | Collect the payout and pick a new suitable Novice contract from the Marrowbridge board. | Marrowbridge | 116/136 | 33.5 s |
| 77 | #bag | System (Befehl) | open_run_level | Verify whether the ninety-copper payout was actually recorded, since the HUD coin still re… | Marrowbridge | 116/136 | 2.3 s |
| 78 | I check the contract slip in my pouch against the clerk's roll and ask her to confirm the strider cull payout was actually recorded, since m… | Erzähler | open_run_level | Resolve the contradiction between narration (paid, closed) and System (slip active, coin u… | Marrowbridge | 116/136 | 36.4 s |
| 79 | #audit | System (Befehl) | open_run_level | Check the audit log to see whether the ninety-copper payout was actually recorded by the e… | Marrowbridge | 116/136 | 2.3 s |
| 80 | I tip the pouch out on the counter and show her the slip is still in my bag on my ledger, then ask her to count out the ninety copper again … | Erzähler | open_run_level | Resolve the payout contradiction by having the clerk pay out again, since the engine still… | Marrowbridge | 116/136 | 22.7 s |
| 81 | I count the coin back into my pouch, thank the clerk, and leave the Guild hall to find cheap lodging for the night. | Erzähler | open_run_level | Drop the thrice-rejected payout dispute (noted as persistent blockage) and recover overnig… | Widow Hale's lodging house | 116/136 | 40.2 s |
| 82 | "Two copper for the bed and a copper for the soup, please. I'll take the room." | Engine (Menü/Rückfrage) | open_run_level | Pay for lodging and soup, then sleep until morning to recover. | Widow Hale's lodging house | 116/136 | 7.5 s |
| 83 | offer.t162.7 — I accept: bed and soup, then I eat and sleep until morning. | Erzähler | open_run_level | Accept the lodging offer and recover overnight. | Widow Hale's lodging house | 135/236 | 15.6 s |
| 84 | I thank Widow Hale and set out for the Adventurers' Guild hall in Asterhall, where my statement is waiting and new postings go up. | Erzähler | open_run_level | Travel to Asterhall Guild hall to follow up the logged statement debt and find new contrac… | Adventurers' Guild hall, Asterhall | 135/236 | 24.8 s |
| 85 | I enter the Guild hall and ask the clerk on duty about the statement logged under Alaric Red, and to see the current Novice postings. | Erzähler | open_run_level | Follow up the logged statement debt and look for new Novice contracts at the Asterhall Gui… | Adventurers' Guild hall, Asterhall | 135/236 | 26.7 s |
| 86 | "I'll take the Millpond Pike contract. Please mark it active for me — and what can you tell me about the millpond's location?" | Erzähler | open_run_level | Accept the Novice pike contract and get details on where to find it. | Adventurers' Guild hall, Asterhall | 135/236 | 17.4 s |
| 87 | "Millpond Pike is marked, then. Is there cheap lodging near the hall for the night? I'll set out for the millpond at dawn." | Erzähler | open_run_level | Find nearby lodging, sleep, then hunt the millpond pike at dawn. | Adventurers' Guild hall, Asterhall | 135/236 | 22.1 s |
| 88 | I walk to the Drowned Lantern and ask for a bed for the night and porridge at first light. | Erzähler | open_run_level | Get lodging and early breakfast at the Drowned Lantern, then sleep until dawn. | The Drowned Lantern | 135/236 | 21.5 s |
| 89 | "Two coppers for the bed, and I'll take porridge with the beer in the morning." I hand over the two coppers for the bed now, then go up to t… | – | open_run_level | Pay for the bed, then sleep until dawn with breakfast arranged. | The Drowned Lantern | 135/236 | 27.9 s **no reply after the message** |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 1 (notiert vor Zug 2): Mage chosen; stats updated (INT 8, WIL 8). Starter gear equips automatically after Step 2.
- zu Zug 2 (notiert vor Zug 3): Character creation completed: Level 1 Mage with Arcane Bolt and Flame Lance, starter gear equipped, 5 silver on hand.
- zu Zug 3 (notiert vor Zug 4): Entered Glassmere; crossed-swords sign likely the Guild. Guild Rank shows 'not registered' in HUD.
- zu Zug 4 (notiert vor Zug 5): Guild hall reached; Clerk A engaged and offering registration. No contradictions so far.
- zu Zug 5 (notiert vor Zug 6): Registration fee is 2 silver; HUD shows 5 silver, affordable. Clerk explained Guild rank vs. power rank distinction.
- zu Zug 6 (notiert vor Zug 7): Registration confirmed: Guild Rank Novice, plate received, coin 3 Silver. Power Rank F via stone. Oddity: purchase panel said 20 copper but HUD shows 3 Silver remaining from 5, consistent with 2 silver paid.
- zu Zug 7 (notiert vor Zug 8): Board shows five Novice contracts; quarry slimes (6 slimes, 1G6S) looks best value for a Level 1. Coin oddity from last turn persists (HUD 3 Silver vs purchase panel copper figures) but is consistent enough to proceed.
- zu Zug 8 (notiert vor Zug 9): Contract confirmed ACTIVE in HUD (0/6). Coin oddity persists: HUD shows 3 Silver while purchase panel showed copper totals.
- zu Zug 9 (notiert vor Zug 10): Arrived at the pit; six slimes confirmed in HUD, contract 0/6. Slimes are slow; one is half-beached and isolated—good first target.
- zu Zug 10 (notiert vor Zug 11): All five slimes engaged immediately after the first kill; each corroding touch dealt 5 damage. One-shot kill with Flame Lance (48 dmg); MP 80/96 is fine but five more casts would nearly drain it.
- zu Zug 11 (notiert vor Zug 12): Four slimes engaged with no clean escape gap; taking 20 damage per round while Flame Lance one-shots each. HP 45/90, MP 64 — pace still works but I'll be near 25 HP by the last kill.
- zu Zug 12 (notiert vor Zug 13): Pace holds: Flame Lance one-shots each slime, but HP is down to 30/90 and will be near 15 by the last kill. Will need rest or a healing item after.
- zu Zug 13 (notiert vor Zug 14): Pace unchanged: Flame Lance one-shots each slime, but HP 20/90 after this round and MP 32 will be nearly spent by the last kill—recovery needed immediately after.
- zu Zug 14 (notiert vor Zug 15): Fifth slime down; HP 15/90 and MP 16/96 — exactly enough for one more Flame Lance. Recovery needed immediately after.
- zu Zug 15 (notiert vor Zug 16): Level 2 confirmed, 6/6 slimes done, contract slip READY; HP 15/95 and MP 0 — must rest before returning to town.
- zu Zug 16 (notiert vor Zug 17): Contradiction: the narrator confirmed my #assign settled, but the HUD still shows Free Stat Points 5 with pre-assign stats (VIT 7, INT 9, WIL 9) — will re-check with #status before relying on it.
- zu Zug 17 (notiert vor Zug 18): HUD still shows Free Stat Points 5 and pre-assign stats despite the narrator confirming the #assign settled—a persistent contradiction to re-check. Also learned Glassmere is only a receiving house: the slip must be turned in at the Asterhall branch, two days east.
- zu Zug 18 (notiert vor Zug 19): Rest at the Dripping Antler worked: HP/MP fully recovered for 4 copper. But the assign contradiction persists — HUD still shows Free Stat Points 5 with pre-assign stats despite the narrator confirming it settled twice. Retrying as a bare command.
- zu Zug 19 (notiert vor Zug 20): The re-issued #assign was recorded: VIT 9, INT 11, WIL 10, 0 free points — the earlier contradiction is resolved. Glassmere's Guild is only a receiving house; payout requires the Asterhall branch, two days east.
- zu Zug 20 (notiert vor Zug 21): Arrived in Asterhall and reached the Guild branch; the earlier refusal was just travel-order — now at a real Guild hall with Clerk C present.
- zu Zug 21 (notiert vor Zug 22): Slime payout blocked by a paperwork mismatch: Glassmere logged it as a house entry, not a branch entry. Mediation desk offered as a free same-night option.
- zu Zug 22 (notiert vor Zug 23): Harsk found the house-entry mismatch in his rolls and is drafting a correction sheet; the slime payout remains unpaid pending his fix.
- zu Zug 23 (notiert vor Zug 24): Harsk logged the correction tonight but the payout waits 4–6 days on Glassmere's confirmation; waiting in Asterhall gets same-hour payment. Note: the engine rejected my dialogue as a quest.turn_in attempt again — dialogue lines keep being misrouted to quest.turn_in.
- zu Zug 24 (notiert vor Zug 25): Correction logged; payout is a 4-6 day debt pending Glassmere's confirmation. Plan: use the wait for loot sales and a short Asterhall contract.
- zu Zug 26 (notiert vor Zug 27): Denna offered 12s 4c for the whole lot; cores carry assay gamble risk, taking the sure cash.
- zu Zug 27 (notiert vor Zug 28): Contradiction: I accepted 12s4c for the whole lot but the engine only processed the gel sale (3s6c) and Denna refused the cores at 4s each — cores still in inventory. Note: I'd earlier asked to sell the cores too, so the partial sale is an engine ruling, not a misunderstanding.
- zu Zug 28 (notiert vor Zug 29): Corven confirmed the pit slip is READY and payable on turn-in; quest panel shows 6/6 defeated but still 'active' — turn-in should complete it.
- zu Zug 29 (notiert vor Zug 30): Payout confirmed: 160cp, coin 222cp. XP 294/300 — nearly level 4. Board is thin; barrel-mite is a short in-town job.
- zu Zug 30 (notiert vor Zug 31): Contract confirmed ACTIVE; location panel still shows Guild hall though the story moved me to the Tapped Keg — minor sync lag.
- zu Zug 31 (notiert vor Zug 32): Cellar scene confirmed, mite engaged at HP 16/16; location panel now matches the Tapped Keg.
- zu Zug 32 (notiert vor Zug 33): Level 4 confirmed (+5 points, HUD shows 10 free — possible carryover), mite one-shot for 24 XP, loot: barrel-mite tail; quest READY for turn-in.
- zu Zug 33 (notiert vor Zug 34): Level 4 stats assigned (INT 17, WIL 16, VIT 11), free points 0; XP 18/400; mite loot is a tail, not a core.
- zu Zug 34 (notiert vor Zug 35): HP max rose to 125 and MP to 200 after stat assignment; barmaid offered a free meal tomorrow. Contract still active, turn-in pending at Guild.
- zu Zug 35 (notiert vor Zug 36): Barmaid offered rooms: 4cp here, 8cp at the Weary Cooper. HP 95/125, MP 92/200 — recovery needed; contract turn-in pending at Guild tomorrow.
- zu Zug 36 (notiert vor Zug 37): Sleep recovered HP/MP fully (125/125, 200/200); room purchase confirmed, coin 218 copper. Ready for turn-in.
- zu Zug 37 (notiert vor Zug 38): Contract turned in and paid: 2 silver, XP 64/400, coin 2G3S8C. No active quests now.
- zu Zug 38 (notiert vor Zug 39): Loot sale refused: materials desk (Denna) absent until midmorning; cores and tail still carried. Board offered five Novice contracts; chose the millpond turtles.
- zu Zug 39 (notiert vor Zug 40): Combat scene opened at millpond: Snapping Turtle A HP 70/70; contract confirmed active 0/4 defeated.
- zu Zug 40 (notiert vor Zug 41): Flame Lance hit hard (59 dmg) but the turtle closed and bit for 7; it's at 11/70, ENGAGED. Combat panels show damage ranges clearly.
- zu Zug 41 (notiert vor Zug 42): Turtle A defeated (36 XP, XP 100/400), loot 2 plates + 1 claw collected; contract 1/4. Something may be moving in the pond.
- zu Zug 42 (notiert vor Zug 43): Search for the second turtle failed (d100 99); villagers point to Old Tam the miller as a better source.
- zu Zug 43 (notiert vor Zug 44): Tam confirms lairs: big turtle at the drowned willow suns midmorning, second at the weir channel, third unseen for half a year.
- zu Zug 45 (notiert vor Zug 46): Snapping Turtle B defeated instantly by an ambush crit (100 dmg); contract 2/4, XP 146/400, loot doubled to 4 plates and 2 claws.
- zu Zug 46 (notiert vor Zug 47): Snapping Turtle C found at the weir, 8 paces off, partial cover; contract 2/4, XP 146/400, loot now 4 plates and 2 claws.
- zu Zug 47 (notiert vor Zug 48): Turtle C closed to ENGAGED and bit for 8 damage; it is at 25/70 HP with partial cover gone.
- zu Zug 48 (notiert vor Zug 49): Turtle C defeated; contract 3/4, XP 182/400, loot 5 plates and 3 claws. A pike-shaped shape was noted in the millpond as a possible sign.
- zu Zug 49 (notiert vor Zug 50): Search roll failed to find the fourth turtle; trying patience at the likely basking spot instead.
- zu Zug 50 (notiert vor Zug 51): Patience worked: Turtle D hauled out to bask, twenty paces off, unaware and unshielded.
- zu Zug 51 (notiert vor Zug 52): All four turtles defeated (two via ambush crits for ~100 damage each); contract now ready for turn-in, XP 218/400, shin wound unhealed.
- zu Zug 52 (notiert vor Zug 53): Aldermill has no Guild branch; the contract turn-in requires travel to a proper town. Location in HUD still says millpond though narration placed me in the village.
- zu Zug 53 (notiert vor Zug 54): Tam confirms nearest Guild branch is Thornbury, a day south; his flour cart leaves at first light tomorrow. Walking the road today was also offered as an alternative.
- zu Zug 54 (notiert vor Zug 55): Arrangement with Tam confirmed: sacks hauled, loft lodging, cart to Thornbury at first light with Tammi.
- zu Zug 55 (notiert vor Zug 56): Full recovery confirmed (HP/MP maxed). Cart to Thornbury departing now; Guild contract turn-in still pending arrival.
- zu Zug 56 (notiert vor Zug 57): Arrived in Thornbury by evening; Guild hall confirmed present in town. Turn-in still pending.
- zu Zug 57 (notiert vor Zug 58): Contract turn-in confirmed: 60 copper paid, slip marked complete; hall closing within minutes so board time is limited.
- zu Zug 58 (notiert vor Zug 59): Contract turn-in confirmed: 60 copper paid, quest still shows active in HUD but slip marked complete. Novice board empty until dawn.
- zu Zug 59 (notiert vor Zug 60): Sleep attempt was refused because no room was booked; innkeeper now offers beds. Also noted: the gnasher payout is logged as a debt waiting on Glassmere's confirmation despite the slip being marked complete — a story/System contradiction to watch.
- zu Zug 60 (notiert vor Zug 61): HUD contradicts narration: it shows location as Asterhall, Bridge and Plough inn, and the gnasher payout as a logged debt in Asterhall, while the story says we are in Thornbury. Also quest still shows 'active' despite marked-complete slip; will try turn-in here.
- zu Zug 61 (notiert vor Zug 62): Gnasher payout confirmed: 6 silver received, quest completed, slip filed. HUD still lists location as Asterhall Guild hall while narration places us in Thornbury — persistent location contradiction.
- zu Zug 62 (notiert vor Zug 63): Board is labelled Asterhall while narration places us in Thornbury — HUD location says Asterhall Guild hall, so I'll follow the System. Payout fully confirmed this time (6 silver), the earlier 'debt' lead is stale.
- zu Zug 63 (notiert vor Zug 64): Contract confirmed active in HUD (0/4 defeated); board labelled Asterhall matches HUD location, so the earlier Thornbury contradiction stands as a narration quirk.
- zu Zug 64 (notiert vor Zug 65): Arrival at Reed Flats confirmed; Drest Hallow present and expecting the Guild hunter.
- zu Zug 65 (notiert vor Zug 66): Four big striders hold the third weir; Drest advises fighting from stakes/screens or boats, never wading.
- zu Zug 67 (notiert vor Zug 68): First Strike Flame Lance one-shot the 22 HP strider for 65 damage; three remain, none advancing yet. Loot auto-gathered (feathers ×5, talon).
- zu Zug 68 (notiert vor Zug 69): Two remaining striders engaged; they deal 3 damage each per round. One Flame Lance per kill is efficient; MP fine at 168.
- zu Zug 69 (notiert vor Zug 70): Combat efficient: one Flame Lance per strider, minor 3-damage hits taken; HP 116/125 fine.
- zu Zug 70 (notiert vor Zug 71): Level 5 confirmed with +5 free stat points; cull quest 4/4 ready for turn-in.
- zu Zug 71 (notiert vor Zug 72): Level 5 confirmed and stats assigned; cull 4/4 ready for turn-in. Minor oddity: the combat-end panel repeated the level-up it already gave last turn, but stats show 0 free points so no duplication in the record.
- zu Zug 72 (notiert vor Zug 73): Thornbury has no Guild hall despite the HUD promising a Guild board here; turn-in may require half a day's travel back to Asterfall.
- zu Zug 73 (notiert vor Zug 74): Confirmed: Thornbury has no Guild hall despite the HUD 'promise' line about a Thornbury board; turn-in requires travel to Marrowbridge.
- zu Zug 74 (notiert vor Zug 75): Arrived in Marrowbridge by ferry; Guild hall confirmed present here, unlike Thornbury.
- zu Zug 75 (notiert vor Zug 76): Payout of 90 copper confirmed in narration, but HUD still shows 2g9s2c and the strider quest still listed active — worth a panel check next turn. Oddity persists: leads still point to a nonexistent Thornbury Guild board.
- zu Zug 76 (notiert vor Zug 77): Turn-in narration confirmed ninety copper counted out, but HUD coin and quest status are unchanged — possible engine recording lag or contradiction. Checking bag before relying on either.
- zu Zug 77 (notiert vor Zug 78): Bag panel confirms coin still 292c and the strider slip still held, despite narration of payment and closure — payout not recorded by the engine. Marrowbridge board refused reading with 'no Guild board here', contradicting the hall's own notice board.
- zu Zug 78 (notiert vor Zug 79): Narration insists the payout was recorded and the slip taken, but the System still shows the slip in my bag, quest active, and coin unchanged at 292c — running #audit to resolve the contradiction.
- zu Zug 79 (notiert vor Zug 80): #audit shows the engine rejected the world report of the payout and slip removal — the engine is authoritative that I still hold the slip and 292c. Third attempt at resolving this; if it fails again I'll note it as a persistent blockage and take other work.
- zu Zug 80 (notiert vor Zug 81): Third payout attempt: engine again shows slip active, coin unchanged at 292c despite narration of payment — recording the 90 cp payout as a persistent optional blockage and moving on. Board struck for the night; will sleep, then sell turtle/slime loot in the morning.
- zu Zug 81 (notiert vor Zug 82): Payout dispute abandoned as a persistent blockage; engine still shows slip active and 292c. Lodging found at Widow Hale's, 2 cp plus 1 cp soup.
- zu Zug 82 (notiert vor Zug 83): System asked for explicit acceptance of the 3 cp lodging+soup offer; nothing spent yet. Payout blockage remains: engine still shows strider slip active and 292c.
- zu Zug 83 (notiert vor Zug 84): Lodging purchase and overnight recovery confirmed by System: -3 cp, HP/MP full. Strider payout remains engine-blocked (slip still active, 4/4 defeated); heading to Asterhall per goals.
- zu Zug 84 (notiert vor Zug 85): Arrived in Asterhall by evening of Day 6; recovery confirmed full. Strider slip still active in bag despite 4/4 defeated — payout blockage persists.
- zu Zug 85 (notiert vor Zug 86): Clerk confirms statement query still pending (expected 4-6 days). Board shows five fresh Novice postings; the Bog Striders listing still appears despite my completed 4/4 slip being unpaid.
- zu Zug 86 (notiert vor Zug 87): Millpond Pike contract confirmed ACTIVE in HUD (0/1). Clerk says pike hunt shallows in evening or dawn; half a morning's walk east. Strider slip still active 4/4 — payout blockage persists.
- zu Zug 87 (notiert vor Zug 88): Millpond Pike confirmed ACTIVE (0/1). Heading to the Drowned Lantern for cheap lodging before the dawn pike hunt.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t10 | 10 | 6 | – | nein | 6 | gewonnen, 144 XP |
| enc.t31 | 32 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t38 | 40 | 1 | – | nein | 1 | gewonnen, 36 XP |
| enc.t43 | 45 | 1 | – | nein | 1 | gewonnen, 46 XP |
| enc.t45 | 47 | 1 | – | nein | 1 | gewonnen, 36 XP |
| enc.t49 | 51 | 1 | – | nein | 1 | gewonnen, 36 XP |
| enc.t65 | 67 | 1 | – | nein | 1 | gewonnen, 28 XP |
| enc.t66 | 68 | 3 | – | nein | 3 | gewonnen, 72 XP |

## Quests

- **Cull the Quarry Slimes at the Old Sandstone Pit** — active (Zug 8) → completed (Zug 29), READY
  - Aufgabe: Destroy 6 mineral slimes pooling in the flooded lower benches of the old sandstone pit so the yard can resume cutting there.
  - Endzustand: The 6 mineral slimes in the flooded lower benches of the old sandstone pit are destroyed and cutting resumes.
- **Cull the Millpond Snapshells** — expired (Zug 38)
  - Aufgabe: Hunt and cull 3 snapshell turtles in the millpond above Aldermill's wheel so the millrace can be cleared of their nests.
  - Endzustand: 3 snapshell turtles are culled and the millpond is safe for the millrace crews to work.
- **Cull the Vineyard Strikers** — expired (Zug 38)
  - Aufgabe: Hunt and cull 5 amber-tongued whipvines strangling the terraced vines at the Sunward Slope vineyard before the harvest crews return.
  - Endzustand: 5 amber-tongued whipvines are culled and the Sunward Slope terraces are safe for the harvest crews.
- **Cull the Quarry Shrieker** — expired (Zug 38)
  - Aufgabe: Hunt down and slay the shrieker roosting in the old Halloway quarry cuts, whose cries have driven the cutters from the lower benches.
  - Endzustand: The shrieker in the old Halloway quarry is slain and the cutters can return to the lower benches.
- **Cull the Ferry Hounds** — expired (Zug 38)
  - Aufgabe: Hunt and cull 4 marsh hounds that have been stalking the ferry livestock pens at the Lantern Crossing at dusk.
  - Endzustand: 4 marsh hounds are culled and the ferry livestock pens are no longer stalked at dusk.
- **Cull the Cellar Lurker** — active (Zug 30) → completed (Zug 37), READY
  - Aufgabe: Hunt down and slay the single barrel-mite that has been gnawing through the ale casks in the Tapped Keg's cellar.
  - Endzustand: The barrel-mite in the Tapped Keg's cellar is slain and the ale casks are safe.
- **Cull the Millpond Gnashers** — active (Zug 39) → completed (Zug 61), READY
  - Aufgabe: Hunt and cull the four snapping turtles gnawing the millrace timbers and biting launderers at the Aldermill millpond.
  - Endzustand: The four snapping turtles at the Aldermill millpond are dealt with and the millrace and washing steps are safe to use again.
- **A Strangled Roost** — expired (Zug 62)
  - Aufgabe: Hunt the vine-lurker that has taken root in the Rooke Street dovecote yard and strangled eleven of the loft's birds.
  - Endzustand: The vine-lurker in the Rooke Street dovecote yard is dealt with and the pigeon loft's birds can fly safely again.
- **One Beast at the Brick Kiln** — expired (Zug 62)
  - Aufgabe: Hunt the lone mud-mawed beast that has been raiding the clay pits at the Harrow & Sons brickworks after dark.
  - Endzustand: The mud-mawed beast raiding the Harrow & Sons clay pits is dealt with and the night kiln crews work without losses.
- **Thin the Willow Fen Adders** — expired (Zug 62)
  - Aufgabe: Hunt and cull the six fen adders denning in the reed beds so the reed-cutters can work the Willow Fen shallows again.
  - Endzustand: The six fen adders denning the Willow Fen reed beds are dealt with and the reed-cutters return to work.
- **The Pale Owl of Bellgrave Orchard** — expired (Zug 62)
  - Aufgabe: Hunt the pale owl that has been striking pickers in the Bellgrave orchard rows at dusk; take care, its screech leaves men dizzy and slow.
  - Endzustand: The pale owl haunting the Bellgrave orchard is dealt with and the pickers bring in the harvest unharmed.
- **Cull the Bog Striders at the Reed Flats Eel-Weirs** — active (Zug 63), READY
  - Aufgabe: Hunt and cull the bog strider colony at the eel-weirs of the Reed Flats so the eel boats can launch safely again.
  - Endzustand: Four bog striders are slain at the eel-weirs and the eel boats launch again.
- **Cull the Stone-Beaked Ape of Thornchapel Orchard** — expired (Zug 85)
  - Aufgabe: Hunt down the single stone-beaked ape that roosts in Thornchapel Orchard's old bell tower before it strips the remaining harvest.
  - Endzustand: The stone-beaked ape is slain and the orchard's remaining harvest is safe.
- **Cull the Ash-Maw Hounds of the Kiln Road** — expired (Zug 85)
  - Aufgabe: Hunt down the pack of ash-maw hounds denning in the old clay pits beside the Kiln Road so carters can haul brick again without losing loads or dogs.
  - Endzustand: Three ash-maw hounds are slain and the Kiln Road carters haul brick without attack.
- **Cull the Rotcap Creepers in the Undertaker's Cellar Garden** — expired (Zug 85)
  - Aufgabe: Hunt down the rotcap creepers that have taken root among the Lanternfield graves and strangle them at the root before they reach the crypt doors.
  - Endzustand: Three rotcap creepers are slain and the Lanternfield graves are free of them.
- **Cull the Pale Heron of the Drowned Millpond** — expired (Zug 85)
  - Aufgabe: Hunt the pale heron haunting the Drowned Millpond, which has snatched two lambs and a goose from the crossing flocks this week.
  - Endzustand: The pale heron is slain and the crossing flocks are safe.
- **Put Down the Millpond Pike** — active (Zug 86)
  - Aufgabe: Kill the oversized pike that has been taking geese and a dog at the old millpond before it takes a child.
  - Endzustand: The oversized pike of the old millpond is dead and the millpond shore is safe again.

## Auffälligkeiten

- Zug 89 (Runner/UI): no reply after the message
- Zug 16, Nachricht 31 (stat_words): the player spent Stat Points in words, not with #assign; nothing was assigned (for review: did the story tell them as done?)
- Zug 16, Nachricht 32 (extraction_repaired): the extractor's first answer needed a repair
- Zug 17, Nachricht 34 (extraction_repaired): the extractor's first answer needed a repair
- Zug 22, Nachricht 44 (extraction_repaired): the extractor's first answer needed a repair
- Zug 27, Nachricht 53 (planner_repaired): the planner's first answer needed a repair
- Zug 30, Nachricht 60 (extraction_repaired): the extractor's first answer needed a repair
- Zug 54, Nachricht 108 (extraction_repaired): the extractor's first answer needed a repair
- Zug 56, Nachricht 112 (extraction_repaired): the extractor's first answer needed a repair
- Zug 65, Nachricht 130 (extraction_repaired): the extractor's first answer needed a repair
- Zug 74, Nachricht 148 (extraction_repaired): the extractor's first answer needed a repair
- Zug 81, Nachricht 162 (extraction_repaired): the extractor's first answer needed a repair
- Zug 82, Nachricht 163 (planner_repaired): the planner's first answer needed a repair
- Zug 89, Nachricht 177 (planner_failed): the planner failed: commands[0] (offer.accept): agreed price 2 cp differs from this offer's 3 cp; clarify instead of substituting an offer
- Zug 89, Nachricht 177 (planner_repaired): the planner's first answer needed a repair
- Hinweis (error): Avereth Engine: planner failed (commands[0] (offer.accept): agreed price 2 cp differs from this offer's 3 cp; clarify instead of substituting an offer). Regenerate or send the message again; no story turn was generated.
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 20× keine gültige JSON-Entscheidung (Züge 1, 21, 31, 32, 33, 36, 38, 39, 40, 45, 50, 54, 59, 65, 66, 67, 71, 74, 75, 79)

System-Panels: CLARIFY 1, NOT TAKEN 1, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: ambient 5, world_rule 16, scene_context 16, guild_canon 1, engine_owned_fact 12, pc_inventory 5, engine_booked 1, npc_continuity 7, offer 3, engine_owned_memory 1, no_go 1, attack_commitment 1, engine_owned_combat 1, place 2, guild_payout 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 85 | 3 | 2.7 s | 6.3 s | 11461 | 9706 | 67 | – | stop 85 | 0 |
| narrator | 80 | 0 | 11.1 s | 21.1 s | 11495 | 8699 | 405 | – | stop 80 | 0 |
| extract | 89 | 9 | 6.9 s | 18.0 s | 11116 | 8990 | 373 | – | stop 89 | 0 |
| board | 6 | 1 | 13.0 s | 22.1 s | 1702 | 1677 | 1162 | – | stop 6 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 50:09 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 71.1 s) | 1:29 min |
| 89 Züge, Spiel (Senden bis HUD nach der Extraktion) | 39:44 min — Median 24.1 s, p90 43.8 s, max 73.8 s |
| 89 Züge, Spieler-Entscheidung | 7:24 min — Median 3.6 s, 20 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 4:57 min / 1:26 min / 16:46 min / 12:58 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 31.8 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 21:11 min, 80 Züge ≈ 42:23 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spiel | 27 | – | 73.8 s | 24.1 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
