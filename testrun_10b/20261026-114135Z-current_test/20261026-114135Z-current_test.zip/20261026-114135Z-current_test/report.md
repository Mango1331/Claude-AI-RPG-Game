# Avereth Live-Test 20261026-114135Z-current_test

## Kurzfassung

- **Ergebnis:** extractor_failed — turn 90: the World Extractor failed after story message 180; its world changes were not committed ($.deltas[3] (fact): .s: expected string, got object; $.deltas[4] (fact): .s: expected string, got object)
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 4. Sicherheitsgrenzen: 1000 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** noch nicht erreicht.
- **Charakter:** mage (mage.arcane_bolt, mage.blink) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: curious Guild adventurer: freely explore and choose interesting contracts while developing levels, gear and techniques; incidental help remains welcome
- **Züge:** 90 · **Dauer:** 42:25 min · **LLM-Aufrufe der Engine/des Erzählers:** 264
- **Auffälligkeiten:** 14
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.97 |
| Git | b51a6f1d4441 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 62.2 s |
| Browser | chrome 155.0.8059.85 |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261026-114135Z-current_test“, Seed 167685493 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | I choose Mage. | Engine (Menü/Rückfrage) | creation_complete | Pick Mage as base class. | public roadside verge outside Glassmere | 90/84 | 2.1 s |
| 2 | I pick Arcane Bolt and Blink. | Engine (Menü/Rückfrage) | creation_complete | Select two starter skills to finish character creation. | public roadside verge outside Glassmere | 90/96 | 2.1 s |
| 3 | I walk to Glassmere and head for the Adventurers' Guild hall to register as a Guild adventurer. | Erzähler | open_run_level | Enter Glassmere and register at the Guild to start taking contracts. | Adventurers' Guild hall, Glassmere | 90/96 | 17.1 s |
| 4 | "Alaric Red." I hand the clerk two silver to register. | Erzähler | open_run_level | Pay the two silver registration fee and register at the Guild. | Adventurers' Guild hall, Glassmere | 90/96 | 14.8 s |
| 5 | I take the Guild plate and walk to the contract board to look at the notices available to Novice rank. | Erzähler | open_run_level | Registered as Novice; now browse the Guild board for a suitable first contract. | Adventurers' Guild hall, Glassmere | 90/96 | 37.0 s |
| 6 | "Any work posted elsewhere today? I heard the men mention Glimmerdeep paying for crystal beetles — is that a Guild contract I could take?" | Erzähler | open_run_level | Ask the clerk about the Glimmerdeep beetle work as a possible first contract since the boa… | Adventurers' Guild hall, Glassmere | 90/96 | 29.6 s |
| 7 | "I'll take the Eel-Weir Bog Striders contract — the level 1 one for the Reed Flats eel-fishers." | Erzähler | open_run_level | Accept the bog strider culling contract at the Guild counter. | Adventurers' Guild hall, Glassmere | 90/96 | 20.6 s |
| 8 | I set out south along the river road toward the Reed Flats to find the eel-weirs and the cooperative's foreman. | Erzähler | open_run_level | Travel to the Reed Flats and locate the foreman for the bog strider contract. | the eel-weirs of the Reed Flats | 90/96 | 34.3 s |
| 9 | I approach Tam and show my Guild plate. "I'm Alaric Red, from the Guild — I've taken the contract to cull the bog striders. Where should I s… | Erzähler | open_run_level | Report to the foreman Tam and locate the bog striders. | the eel-weirs of the Reed Flats | 90/96 | 24.6 s |
| 10 | "A lift would be welcome — drop me at the third weir rack-end." | Erzähler | open_run_level | Accept Tam's free pole-ride to the third weir to start hunting the striders. | the eel-weirs of the Reed Flats | 90/96 | 17.9 s |
| 11 | I move carefully along the muddy shelf toward the scratched rack, scanning the reed walls and shallow water for bog striders. | Erzähler | open_run_level | Search the third weir area for the bog striders and engage the first one spotted. | the eel-weirs of the Reed Flats | 90/96 | 17.4 s |
| 12 | I follow the trampled seam into the reed bed, staff ready, listening for the knocking and watching for any strider. | Erzähler | open_run_level | Track the bog strider through the reed bed via the trampled seam and engage it. | strider feeding clearing in the reed bed | 90/96 | 22.0 s |
| 13 | I cast Arcane Bolt at the bog strider. | Erzähler | open_run_level | Engage the strider with Arcane Bolt before its answerer arrives. | strider feeding clearing in the reed bed | 90/86 | 14.5 s |
| 14 | I check the contract slip to see how many bog striders the cull requires, then continue tracking along the water margin for another one. | Erzähler | open_run_level | Verify the contract's kill requirement and hunt a second strider. | the eel-weirs of the Reed Flats | 90/86 | 29.8 s |
| 15 | I circle along the water margin to get a clear line on Bog Strider B around the weir rack, then cast Arcane Bolt at it. | Erzähler | open_run_level | Engage Bog Strider B with Arcane Bolt despite its cover. | the eel-weirs of the Reed Flats | 90/76 | 21.2 s |
| 16 | I head back along the water margin toward Tam's pole landing, then travel to the Glassmere Guild hall to turn in the completed contract. | Erzähler | open_run_level | Return and turn in the culled striders contract at the Guild hall. | Adventurers' Guild hall, Glassmere | 90/76 | 31.9 s |
| 17 | #assign INT 2 WIL 2 PER 1 | System (Befehl) | open_run_level | Spend the 5 free stat points from the level-up. | Adventurers' Guild hall, Glassmere | 90/76 | 2.1 s |
| 18 | "What's on the board today? I'm after something suitable for a novice mage." | Erzähler | open_run_level | Browse the Guild board for a new suitable contract. | Adventurers' Guild hall, Glassmere | 90/76 | 18.5 s |
| 19 | "I'll take the Mill Road Wolves contract, please." | Erzähler | open_run_level | Accept the wolf cull contract from the clerk. | Adventurers' Guild hall, Glassmere | 90/76 | 11.2 s |
| 20 | I'll take the Primer of Bolt for 120 copper, please — then set out south for Barrowford. | Erzähler | open_run_level | Buy the Bolt primer and travel to Barrowford for the wolf contract. | Adventurers' Guild hall, Glassmere | 90/76 | 17.2 s |
| 21 | Then I'm off — I set out south on the road to Barrowford. | Erzähler | open_run_level | Skip the unaffordable primer and travel to Barrowford for the wolf contract. | Barrowford | 90/76 | 32.5 s |
| 22 | I latch the gate and come into the yard. "Guild's finest novice, at your service — your wife said you know where the wolves have been workin… | Erzähler | open_run_level | Speak with the farmer to get wolf locations and start the hunt. | Barrowford | 90/76 | 25.6 s |
| 23 | "Four wolves at the third hedge by dusk — understood. I'll take them before they take another lamb. If the work runs past dark, I'll trouble… | Erzähler | open_run_level | Confirm the plan with Marta and head for the third hedge east to hunt the wolves at dusk. | Barrowford | 90/76 | 27.7 s |
| 24 | I wait with my back to the fence, staff ready, and cast Arcane Bolt at the first wolf that steps clear of the treeline. | Engine (Menü/Rückfrage) | open_run_level | Ambush the wolves at dusk from behind the fence, opening with Arcane Bolt. | Barrowford | 90/76 | 4.8 s |
| 25 | I hold position behind the fence, staff ready, watching the treeline until one of the wolves actually steps into the open. | Erzähler | open_run_level | Wait for a wolf to become a valid target before attacking. | Barrowford | 90/76 | 18.5 s |
| 26 | I cast Arcane Bolt at the wolf standing in the open by the hedge gap. | Erzähler | open_run_level | Open the fight on the exposed wolf now that it's a valid target. | Barrowford | 90/66 | 20.7 s |
| 27 | I stay behind the fence by the fallen wolf, quiet and watchful, in case the pack comes back for their dead or for me. | Erzähler | open_run_level | Hold position at the kill site and wait for the remaining wolves to return. | Barrowford | 90/66 | 18.9 s |
| 28 | I leave the carcass where it lies and head up to the house to knock on Marta's door. "They've gone north for now. Might I trouble you for th… | Erzähler | open_run_level | Ask Marta for barn lodging and sleep until dawn before hunting the remaining wolves. | Hedderow farmhouse | 90/66 | 23.5 s |
| 29 | "A cup warm would be kind, thank you." I take the offered kettle drink, then bed down in the barn stall and sleep until dawn. | Erzähler | open_run_level | Accept Marta's kettle, then sleep in the barn until morning to recover before tracking the… | Hedderow farmhouse | 95/132 | 20.2 s |
| 30 | I cross the stream and follow the wolves' tracks north from the third hedge, tracking the remaining three into the treeline. | Erzähler | open_run_level | Track and hunt the three remaining wolves north of the stream at dawn. | the Mill Road treeline east of Barrowford | 95/132 | 21.2 s |
| 31 | I approach the den split slowly and quietly, staff raised, ready to cast Arcane Bolt at whatever comes out. | Erzähler | open_run_level | Engage the wolf at the den as a valid target. | wolf den split | 95/132 | 26.7 s |
| 32 | I cast Arcane Bolt at the ragged-eared wolf at the den mouth. | Erzähler | open_run_level | Open the fight on the exposed wolf B at the den mouth. | wolf den split | 95/122 | 35.7 s |
| 33 | I check the den mouth for signs of how many wolves still shelter inside, then peer into the split cautiously, staff ready. | Erzähler | open_run_level | Scout the den interior for the remaining two wolves before pressing in. | wolf den split | 95/122 | 20.7 s |
| 34 | I cast Blink to slip through the split quickly, then cast Arcane Bolt at Wolf A if it's still inside. | Erzähler | open_run_level | Enter the den past full cover and finish Wolf A. | wolf den split | 95/122 | 23.8 s |
| 35 | I hold my ground at the chamber's edge and cast Arcane Bolt into the deeper black where I last heard Wolf A moving. | Erzähler | open_run_level | Fire Arcane Bolt at Wolf A's position in the dark to draw it out or hit it. | wolf den split | 95/122 | 17.0 s |
| 36 | I cast Blink back out through the split to the treeline, then wait near the den mouth with my staff ready, watching whether Wolf A follows m… | Erzähler | open_run_level | Lure the cover-hugging wolf out by giving up the enclosed position and waiting at the mout… | wolf den split | 95/122 | 13.1 s |
| 37 | I leave the den and walk the Mill Road treeline to look for the other wolves, keeping the den for last. | Erzähler | open_run_level | Give up on the cover-hugging wolf for now and hunt the remaining road wolves instead. | the Mill Road treeline east of Barrowford | 95/122 | 27.1 s |
| 38 | I cast Arcane Bolt at the feeding wolf from cover, then stay hidden behind the trees to see whether it charges or flees. | Erzähler | open_run_level | Ambush Wolf C at range from concealment. | the Mill Road treeline east of Barrowford | 95/112 | 18.1 s |
| 39 | I follow the fresh two-wolf tracks east down the slope toward the water, keeping low and quiet. | Erzähler | open_run_level | Hunt the two wolves that went east toward the water. | streambank below the slope | 95/112 | 26.2 s |
| 40 | I cast Arcane Bolt at the lying wolf on the gravel spit, then hold behind the pines to see how they react. | Erzähler | open_run_level | Ambush Wolf D at range while the pair is still undecided. | streambank below the slope | 95/102 | 19.3 s |
| 41 | I cast Arcane Bolt at Gray Wolf E in the shallows before it decides to flee. | Erzähler | open_run_level | Kill the last visible wolf while it is still hesitating. | streambank below the slope | 95/92 | 14.5 s |
| 42 | I cast Blink to appear inside the den behind Wolf A, then cast Arcane Bolt at it. | Erzähler | open_run_level | Blink past Wolf A's cover to flank it inside the den. | streambank below the slope | 95/92 | 16.5 s |
| 43 | I check the quest panel for Thin the Mill Road Wolves to see whether the four wolf kills have been recorded. | Erzähler | open_run_level | Inspect the quest panel to verify the kill counter before turning the contract in. | streambank below the slope | 95/92 | 13.8 s |
| 44 | I head east toward Barrowford and the Mill Road treeline to find the wolves the contract actually targets. | Erzähler | open_run_level | Travel to the Mill Road treeline where the contract wolves actually are. | the Mill Road treeline east of Barrowford | 95/92 | 46.9 s |
| 45 | I approach the shepherd boy and ask what he can tell me about the wolves working this fence — how many, and when they were last seen. | Erzähler | open_run_level | Gather information from the shepherd about the contract wolves before hunting them. | the Mill Road treeline east of Barrowford | 95/92 | 19.8 s |
| 46 | I thank the boy and slip through the fence toward the half-eaten carcass under the pines, moving slowly and watching the dark trunks for the… | Erzähler | open_run_level | Approach the carcass at the treeline to find the four contract wolves. | the half-eaten ewe under the pines | 95/92 | 25.3 s |
| 47 | I retreat to the fence and pick a concealed spot with a clear view of the carcass, then wait quietly with staff ready for the wolves to come… | Erzähler | open_run_level | Set up an ambush at the carcass and wait for the wolves to return. | the half-eaten ewe under the pines | 95/92 | 22.9 s |
| 48 | I hold still in the shadow and cast Arcane Bolt at the yearling at the carcass. | Erzähler | open_run_level | Ambush the yearling with Arcane Bolt before it can flee or alert the pack. | the half-eaten ewe under the pines | 95/82 | 23.7 s |
| 49 | #assign INT 2 WIL 2 VIT 1 | System (Befehl) | open_run_level | Spend the five level-up stat points. | the half-eaten ewe under the pines | 95/82 | 2.5 s |
| 50 | "One down — three to run. Which way does that ridge lead, and do you know where the pack dens? I'd rather take the old gray first, like you … | Erzähler | open_run_level | Get the boy's guidance on where the remaining three wolves, especially the leader, have go… | the half-eaten ewe under the pines | 95/82 | 22.8 s |
| 51 | "Yes, run and tell him one's down — I'll take the track east of here up the High Back after the rest." | Erzähler | open_run_level | Send the boy to tell his father, then pursue the remaining wolves via the shepherd track. | the shepherd track up the High Back | 95/82 | 20.3 s |
| 52 | I start up the shepherd track, moving carefully and watching the mud and heather for fresh wolf sign as I climb toward the quarry. | Erzähler | open_run_level | Climb the High Back track to track the remaining three wolves toward the quarry and crags. | Caelreth | 95/82 | 25.7 s |
| 53 | I ease behind a boulder at the quarry's rim and hold still, listening to pinpoint where the breathing is coming from before I move. | Erzähler | open_run_level | Locate the unseen creature in the quarry bramble before engaging. | Caelreth | 95/82 | 24.1 s |
| 54 | I keep behind the boulder and cast Arcane Bolt at the pinned old wolf, staying out of reach of its lunge. | Erzähler | open_run_level | Kill the crippled leader wolf from range with Arcane Bolt. | Caelreth | 95/72 | 15.7 s |
| 55 | I follow the fresh tracks across the quarry floor toward the dark seam between the crags, watching ahead for the remaining wolves. | Erzähler | open_run_level | Track the remaining two wolves toward their den in the crag seam. | the dark seam between the crags | 95/72 | 47.5 s |
| 56 | I keep my distance at the seam's mouth and cast Arcane Bolt at the yearling holding the den's mouth. | Erzähler | open_run_level | Open the fight against the two yearling wolves with Arcane Bolt from range. | the dark seam between the crags | 95/62 | 15.7 s |
| 57 | I let the last yearling flee if it chooses, stepping aside from the run's mouth, and once it's gone or dead I check the contract slip to see… | Erzähler | open_run_level | Avoid an unnecessary kill and verify the contract counter. | the dark seam between the crags | 95/62 | 18.1 s |
| 58 | I head back down the quarry track and east toward the Mill Road treeline, watching for fresh wolf sign along the road. | Erzähler | open_run_level | Go to the Mill Road treeline where the contract actually counts wolves. | the Mill Road treeline east of Barrowford | 95/62 | 26.8 s |
| 59 | I walk up to the shepherd boy on the wall and tell him I've cleared the den wolves back at the quarry, and ask what he knows about the pack … | Erzähler | open_run_level | Question the shepherd boy about the Mill Road pack's numbers and den. | the Mill Road treeline east of Barrowford | 95/62 | 21.3 s |
| 60 | I point to the alder dip and ask the boy whether the pack comes out there at first light, and whether there's a farm nearby where I can slee… | Erzähler | open_run_level | Learn the pack's morning pattern and find lodging for the night before a dawn ambush. | the Mill Road treeline east of Barrowford | 95/62 | 20.1 s |
| 61 | I head west down the road to the Hedderow farmhouse and tell Marta that Col sent me — I'm the one doing for the wolves — and ask for a bed i… | Erzähler | open_run_level | Get lodging and a hot meal at the Hedderow farm before a dawn ambush at the alder dip. | Hedderow farmhouse | 95/62 | 24.0 s |
| 62 | I go in by the fire, eat the soup and bread, and let Marta look at my hands while I rest. | Engine (Menü/Rückfrage) | open_run_level | Take Marta's offered meal and care, then sleep in the byre before dawn. | Hedderow farmhouse | 95/62 | 5.0 s |
| 63 | I eat the soup and bread by the fire and let Marta look at my hands, then rest in the byre until dawn. | Erzähler | open_run_level | Name the rest duration the System asked for: until dawn, covering meal, care and sleep. | Hedderow farmhouse | 105/168 | 18.0 s |
| 64 | I set out east along the wall toward the alder dip, moving quietly through the mist and keeping downwind, and take up a hidden position befo… | Erzähler | open_run_level | Reach the alder dip before dawn to ambush the Mill Road pack. | the alder dip | 105/168 | 27.8 s |
| 65 | I burst from cover and cast Arcane Bolt at the big gray-muzzled leader before the pack can scatter. | Erzähler | open_run_level | Open the ambush on the leader per the boy's promise, hitting him first while the pack is d… | the alder dip | 105/158 | 20.6 s |
| 66 | I track the fleeing pack up the fold into the trees, following their trail while it's fresh. | Erzähler | open_run_level | Pursue the six fleeing wolves into the timber while their trail is fresh. | the den hollow under the outcrop | 105/158 | 26.5 s |
| 67 | I approach the den mouth with my staff ready and cast Arcane Bolt at the first wolf that shows itself. | Erzähler | open_run_level | Attack the wolves at the den, starting with whichever comes into view. | the den hollow under the outcrop | 105/158 | 20.6 s |
| 68 | I release the bolt at the gray wolf holding the den mouth, aiming for its chest. | Erzähler | open_run_level | Fire Arcane Bolt at the blocking wolf to start the den fight. | the den hollow under the outcrop | 105/148 | 15.6 s |
| 69 | I squeeze into the den mouth far enough to see the back of the tunnel, staff raised, checking whether any wolves remain inside or if there's… | Erzähler | open_run_level | Inspect the den interior for remaining wolves or a back exit before pursuing the rest of t… | the den hollow under the outcrop | 105/148 | 21.1 s |
| 70 | I take aim through the crack and cast Arcane Bolt at the yearling waiting at the bracken edge. | Erzähler | open_run_level | Snipe the lingering yearling from the den's rear crack with Arcane Bolt. | the den hollow under the outcrop | 105/148 | 17.5 s |
| 71 | I slip out through the den's back crack and move down the slope toward the yearling to get within Medium range, then cast Arcane Bolt at it. | Erzähler | open_run_level | Close to spell range and snipe the lingering yearling. | the den hollow under the outcrop | 105/138 | 19.7 s |
| 72 | I head down the bracken slope toward the treeline by the Mill Road, tracking the remaining wolves' trail. | Erzähler | open_run_level | Pursue the remaining four wolves toward their ground below the ridgeline. | the Mill Road treeline east of Barrowford | 105/138 | 22.3 s |
| 73 | I approach the shepherd boy at the gate and ask him about the wolves: "Seen which way the pack went this morning? I'm here from the Guild to… | Erzähler | open_run_level | Question the shepherd boy about the remaining wolves' location. | the Mill Road treeline east of Barrowford | 105/138 | 23.7 s |
| 74 | I follow the fresh tracks up the shepherd track toward the high pasture, heading for the quarry cut over the ridge. | Erzähler | open_run_level | Track the remaining four wolves toward their quarry den above the high pasture. | the crags above the old quarry | 105/138 | 24.3 s |
| 75 | I circle the quarry rim looking for a safer descent on the near side, keeping clear of the bramble-hidden lip, then pick a route down to wit… | Erzähler | open_run_level | Descend into the quarry bowl carefully and approach the den within spell range. | the den hollow under the outcrop | 105/138 | 26.6 s |
| 76 | I stand ready at my distance and cast Arcane Bolt into the dark of the den split, aiming at whatever rumbled inside. | Engine (Menü/Rückfrage) | open_run_level | Attack the wolf in the den split with Arcane Bolt from Medium range. | the den hollow under the outcrop | 105/138 | 6.5 s |
| 77 | I pick up a loose stone and throw it into the den split to flush out whatever's inside, standing ready at Medium range. | Erzähler | open_run_level | Provoke the hidden wolf into coming out where it can be targeted. | the den hollow under the outcrop | 105/138 | 18.4 s |
| 78 | I cast Arcane Bolt at the charging gray-muzzled wolf. | Erzähler | open_run_level | Attack the gray-muzzled leader wolf with Arcane Bolt before it lunges. | the den hollow under the outcrop | 105/128 | 51.0 s |
| 79 | #assign INT 3 WIL 2 | System (Befehl) | open_run_level | Spend the 5 level-up stat points on INT and WIL. | the den hollow under the outcrop | 105/128 | 2.5 s |
| 80 | I throw another stone into the den split to flush out whatever's still inside, standing ready at Medium range. | Erzähler | open_run_level | Flush the remaining wolves out of the den split so they become targetable. | the den hollow under the outcrop | 105/128 | 51.8 s |
| 81 | I lower my staff and back away from the den, leaving the female and her pups alive, then head back up the shepherd track to find the boy. | Erzähler | open_run_level | Spare the den mother and pups, withdraw, and report to the shepherd's boy. | the shepherd track up the High Back | 105/128 | 40.7 s |
| 82 | I tell the boy the gray-muzzled leader is dead, along with several others from the pack, and that I left the den mother and her pups alive. … | Erzähler | open_run_level | Report the wolf cull to the shepherd's boy and settle the quest lead. | the shepherd track up the High Back | 105/128 | 29.3 s |
| 83 | "That's me. The road wolves are next — where along the Mill Road have they been hitting the flocks, and when?" | Erzähler | open_run_level | Get the boy's information on where the four Mill Road wolves hunt so I can pursue the actu… | the shepherd track up the High Back | 105/128 | 31.2 s |
| 84 | "A dip by the beck and the broken wall at dusk — I'll be there before evening. You can tell your father the gray one is dead and the road wo… | Erzähler | open_run_level | Get directions settled and head toward the Mill Road dip to wait for the four road wolves … | the shepherd track up the High Back | 105/128 | 30.0 s |
| 85 | I head down the shepherd track toward the mill and the beck dip, planning to reach the broken wall well before evening. | Erzähler | open_run_level | Travel to the beck dip by the broken wall to wait for the four road wolves at dusk. | the dip where the beck crosses under the Mill Road | 105/128 | 43.1 s |
| 86 | I find a shaded spot near the broken wall with a clear view of the dip and the hazels, settle in to wait, and meditate to recover MP until d… | Erzähler | open_run_level | Wait at the dip for the four road wolves while recovering MP before the dusk fight. | the dip where the beck crosses under the Mill Road | 105/128 | 34.8 s |
| 87 | I keep watch from my spot by the broken wall through the night, staff ready, watching the dip and the hazels for the road wolves. | Erzähler | open_run_level | Hold an overnight vigil at the dip in case the wolves come in the dark. | the dip where the beck crosses under the Mill Road | 105/128 | 20.1 s |
| 88 | Two nights and no wolves have shown at the dip — I head back to Barrowford, to the shepherd's house, third past the mill with the blue door,… | Erzähler | open_run_level | Consult the shepherd's father after the wolves failed to appear at the dip. | the shepherd's house | 105/128 | 27.9 s |
| 89 | "Thank you. North end of the treeline, by the low wall, at evening or first light — I'll be there tonight and see your flocks safe." | Erzähler | open_run_level | Confirm the corrected hunting ground with the shepherd, then plan to stake out the north t… | the shepherd's house | 105/128 | 24.6 s |
| 90 | I spend the day preparing, then head to the north end of the treeline by the low wall in the afternoon to find a good hidden spot before the… |  | open_run_level | Stake out the corrected wolf hunting ground at the north treeline before dusk. | the shepherd's house | 105/128 | 34.4 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 2 (notiert vor Zug 3): Character creation completed cleanly: Mage with Arcane Bolt and Blink, starter staff and robes equipped, 5 silver on hand.
- zu Zug 3 (notiert vor Zug 4): Registration fee quoted as two silver; shop panel shows a fee item, so I'll pay and verify registration is recorded.
- zu Zug 4 (notiert vor Zug 5): Registration confirmed: Guild plate received, Novice rank, coin now 3 Silver (fee charged as 20 cp, HUD shows 50→30 cp conversion oddity but consistent).
- zu Zug 5 (notiert vor Zug 6): Board picked clean this morning; contracts turn over at dawn. Rumor: Glimmerdeep pays for culling crystal beetles. Primers cost 120 cp each, unaffordable at 3 Silver plus needing supplies.
- zu Zug 6 (notiert vor Zug 7): Board refreshed with five Novice contracts, including Glimmerdeep Grotto level 1 (recommended 1, dungeon, risky solo). I chose the safer bog strider cull, recommended level 1, 25 cp reward.
- zu Zug 7 (notiert vor Zug 8): Contract confirmed ACTIVE in the HUD. Glimmerdeep Grotto level 1 noted as a future solo-capable option once stronger.
- zu Zug 8 (notiert vor Zug 9): Arrived at the eel-weirs; Tam identified by red kerchief; knocking sign from the reed bed suggests striders nearby.
- zu Zug 10 (notiert vor Zug 11): Dropped at the third weir rack-end; fresh claw scratches on the rack and knocking sounds in the reeds suggest striders are close.
- zu Zug 11 (notiert vor Zug 12): Search for striders failed (PER check); only trace is the trampled seam entering the reed bed.
- zu Zug 12 (notiert vor Zug 13): A second strider answered the knock from the channel; possible two-enemy fight ahead.
- zu Zug 13 (notiert vor Zug 14): Oddity: the strider was defeated with loot and XP granted, but the HUD quest still reads 0/1 defeated — worth watching whether the counter updates.
- zu Zug 14 (notiert vor Zug 15): Contract slip shows no kill count; HUD still reads 0/1 defeated after one kill — counter may only update at turn-in or is lagging. A second, deeper-knock strider answered B's call.
- zu Zug 15 (notiert vor Zug 16): Quest now reads 1/1 defeated and QUEST READY FOR TURN-IN — the earlier 0/1 was just a lagging counter. Two kills gave 72/100 XP; loot: 4 chitin plates, 1 venom gland.
- zu Zug 16 (notiert vor Zug 17): Turn-in succeeded: 25 copper payout, level 2 with 5 free points, and the Guild now sells skill primers (120 cp each).
- zu Zug 17 (notiert vor Zug 18): Stat points assigned cleanly (INT 11, WIL 11, PER 8). Guild shop sells F-rank skill primers at 120 cp; I hold 5s5c.
- zu Zug 18 (notiert vor Zug 19): Board offers four novice contracts; wolves (rec. level 4, 80 cp) look the best fit for a level-2 mage. HP slightly down from the strider fight; MP 76/132.
- zu Zug 20 (notiert vor Zug 21): Primer purchase failed for lack of coin (120 cp vs 5s5c); noted to revisit after earning the 80 cp wolf reward.
- zu Zug 21 (notiert vor Zug 22): Arrived in Barrowford; contract is 0/4 wolves, not 1. A farmer's wife pointed me to her husband and the third hedge east.
- zu Zug 22 (notiert vor Zug 23): Marta corrected my assumption: she is the widow, not the farmer's wife; wolves work the third hedge east at dusk. Contract is 0/4; dusk is imminent.
- zu Zug 23 (notiert vor Zug 24): Two pairs of eyes visible in the treeline; wolves are cautious and silent. MP 76/132 before the fight.
- zu Zug 24 (notiert vor Zug 25): Arcane Bolt refused: no wolf is a valid target yet — they are still hidden in the treeline. Also noted the HUD is stale (shows Marta as present) while the active scene is the ambush.
- zu Zug 25 (notiert vor Zug 26): Three wolves now active in the scene (Wolf C in the open, A and B at treeline); a fourth silent mover still inside the trees. Contract 0/4.
- zu Zug 26 (notiert vor Zug 27): Wolf C defeated in one hit (+24 XP), but the quest panel still reads 0/4 despite the kill — possible counter lag or contradiction to watch. The other three wolves fled north rather than attacking.
- zu Zug 27 (notiert vor Zug 28): Long watch confirmed: the three remaining wolves kept their distance all night and did not return. Quest still reads 0/4 despite Wolf C's confirmed kill and loot — counter contradiction persists. It is deep night, Day 1 21:42+; recovery via sleep needed.
- zu Zug 28 (notiert vor Zug 29): Quest panel still reads 0/4 despite Wolf C's confirmed defeat and loot — counter lag or bug to keep watching. Level 2 confirmed, MP 66/132.
- zu Zug 29 (notiert vor Zug 30): Recovery confirmed: HP/MP/STA full after sleeping in the barn. Quest counter still reads 0/4 despite Wolf C's confirmed kill and loot — persistent contradiction.
- zu Zug 30 (notiert vor Zug 31): Found the wolf den; one animal audible inside. Quest counter still reads 0/4 despite the confirmed Wolf C kill.
- zu Zug 31 (notiert vor Zug 32): Two wolves ENGAGED (A and B); B at the den mouth with partial cover, A still inside. Quest counter still reads 0/4 despite Wolf C's confirmed kill.
- zu Zug 32 (notiert vor Zug 33): Wolf B one-shot again (+24 XP, loot); Wolf A retreated deep into the den with full cover. Quest counter still reads 0/4 despite two confirmed kills — persistent bug.
- zu Zug 33 (notiert vor Zug 34): Wolf A has full cover deep in the den; Wolf B defeated one-shot again. Quest counter still reads 0/4 despite two confirmed kills — persistent bug.
- zu Zug 34 (notiert vor Zug 35): Blink succeeded; I'm inside the den with Wolf A somewhere in full-cover dark beyond the light. Quest counter still reads 0/4 despite two confirmed kills.
- zu Zug 35 (notiert vor Zug 36): Wolf A holds full cover in the dark; Arcane Bolt refused for no line of sight. Trying a lure instead of a third blind attempt.
- zu Zug 36 (notiert vor Zug 37): Lure failed: Wolf A stays in full cover, no pursuit. Quest counter still 0/4 despite two confirmed kills — persistent bug.
- zu Zug 37 (notiert vor Zug 38): Wolf C found feeding, unaware, 50 paces off; its trail leads north toward old-kill smell. Quest counter still 0/4 despite two confirmed kills.
- zu Zug 38 (notiert vor Zug 39): Wolf C defeated with an ambush crit (53 damage, +30 XP); loot collected. Quest counter still reads 0/4 despite three confirmed kills — persistent bug.
- zu Zug 39 (notiert vor Zug 40): Two young wolves found at the stream, twenty paces off; wind is carrying my scent and one is already alert. Quest counter still 0/4 despite three confirmed kills.
- zu Zug 40 (notiert vor Zug 41): Wolf D defeated instantly (+48 XP, level 2, 144/200 XP). Wolf E stands hesitating in the shallows. Quest counter still reads 0/4 despite four confirmed kills — persistent bug.
- zu Zug 41 (notiert vor Zug 42): All four road wolves defeated by ambush first-strikes; quest counter still reads 0/4 despite four confirmed kills — persistent bug. Wolf A remains in the den.
- zu Zug 42 (notiert vor Zug 43): Wolf A apparently never existed in the den — the den was empty; all four road wolves are dead. Counter still 0/4 despite four confirmed kills; checking the panel before returning to the Guild.
- zu Zug 43 (notiert vor Zug 44): The four stream wolves were not the contract targets; the slip still counts 0/4 at the Mill Road treeline east of Barrowford. Not a bug — wrong wolves.
- zu Zug 44 (notiert vor Zug 45): Arrived at the Mill Road treeline; four fresh wolf track sets and a half-eaten carcass confirm the real contract targets are here. A shepherd boy watches from the wall.
- zu Zug 45 (notiert vor Zug 46): Confirmed four contract wolves including a big gray-muzzled leader, last seen at first light moving into the trees; contract still 0/4.
- zu Zug 46 (notiert vor Zug 47): Contract wolves (four, including a big gray-muzzled leader) confirmed nearby and moving in; MP 92/132, XP 192/200, nearly level 3.
- zu Zug 47 (notiert vor Zug 48): Two contract wolves (Wolf E, Wolf D) now visible at the carcass; leader still unseen upslope. Ambush position holds but the yearling has scented toward my hiding spot.
- zu Zug 48 (notiert vor Zug 49): Level 3 confirmed with +5 free points. Oddity: Wolf E defeated but the contract counter still reads 0/4 — same recording lag as the stream wolves; will re-check after more kills.
- zu Zug 49 (notiert vor Zug 50): Level 3 confirmed and stats assigned; contract slip still shows 0/4 despite Wolf E's confirmed defeat — recording lag again, will re-check after the next kill.
- zu Zug 50 (notiert vor Zug 51): Contract slip still reads 0/4 despite Wolf E defeated and loot recorded — same lag as before. HP dropped to 95/105 without any hit shown; noting it.
- zu Zug 51 (notiert vor Zug 52): MP shown as 82/168 in HUD versus 92/132 earlier — max MP rose with the level-up, noted. Contract still 0/4 despite confirmed Wolf E kill; fresh wolf tracks on the lower track.
- zu Zug 52 (notiert vor Zug 53): Fresh wolf tracks converge on the quarry; something unseen breathes under a collapsed shed, and the silence suggests the remaining pack may be denning here.
- zu Zug 53 (notiert vor Zug 54): The 'leader' is the old gray wolf, crippled under a collapsed shed — pinned, unable to rise but still able to bite within a few body-lengths. Contract counter still reads 0/4.
- zu Zug 54 (notiert vor Zug 55): Gray Wolf G (the old leader) defeated at range for 46 damage and 30 XP; contract counter still reads 0/4 despite two confirmed kills — recording lag persists. Two wolves remain, tracks lead to the den seam in the crags.
- zu Zug 55 (notiert vor Zug 56): Both yearlings present in the den (HP 28 and 23); contract slip still reads 0/4 despite two confirmed kills — counter lag persists.
- zu Zug 56 (notiert vor Zug 57): Yearling A defeated for 48 XP; last yearling is whining and leaning toward fleeing. Contract slip still reads 0/4 after three confirmed kills.
- zu Zug 57 (notiert vor Zug 58): Contract slip still 0/4 after four confirmed kills; the quarry wolves apparently don't count — the contract targets the Mill Road treeline pack. Noted persistent counter lag.
- zu Zug 58 (notiert vor Zug 59): Reached Mill Road treeline; fresh prints show the remaining pack still patrols the pastures. Contract counter still 0/4 despite four confirmed quarry kills — quarry wolves don't count toward the Mill Road contract.
- zu Zug 59 (notiert vor Zug 60): Boy confirms the Mill Road pack numbers seven to eight grays seen mornings at the alder dip; den unknown. Contract counter still 0/4; quarry kills didn't count.
- zu Zug 60 (notiert vor Zug 61): Boy confirms the pack (7–8 grays) drinks at the alder dip at first light and sleeps in the timber at night; lodging lead is Hedderow farm, quarter mile west, ask for Marta.
- zu Zug 61 (notiert vor Zug 62): Contract still reads 0/4; also two unresolved promises from the boy (telling his father, taking the gray-muzzled leader first) worth addressing.
- zu Zug 62 (notiert vor Zug 63): System asked for a named duration before booking rest; retrying with 'until dawn' as the boy advised being in position before first light.
- zu Zug 63 (notiert vor Zug 64): Rest worked: HP/MP fully restored to 105/168. Pack of 7–8 expected at the alder dip at first light; contract still 0/4.
- zu Zug 64 (notiert vor Zug 65): Eight wolves confirmed at the dip, including the leader (Gray Wolf H). Wind is in my favour downwind; contract still 0/4.
- zu Zug 65 (notiert vor Zug 66): Leader one-shot with Arcane Bolt first strike (49 dmg) for +30 XP; the other seven wolves scattered rather than fighting. Contract counter still reads 0/4 despite the confirmed kill — contradiction to watch.
- zu Zug 66 (notiert vor Zug 67): Pack fled to a den under an outcrop; wind now carries my scent toward them — a single alert bark, then stillness. Contract counter still 0/4 despite the leader kill.
- zu Zug 67 (notiert vor Zug 68): Wolf N (34 HP) holds the den mouth while more eyes wait inside; I'm downwind, so the scent advantage is lost.
- zu Zug 68 (notiert vor Zug 69): Second wolf one-shot with First Strike Arcane Bolt (41 dmg, +58 XP); the rest of the pack fled deeper or out the far side. Contract counter still reads 0/4 despite two confirmed kills — persistent bookkeeping oddity worth noting.
- zu Zug 69 (notiert vor Zug 70): Two wolves defeated but quest counter still reads 0/4 — possible tracking bug worth noting. Pack of five escaped out the back crack; a yearling lingers in view at LONG range.
- zu Zug 70 (notiert vor Zug 71): First LONG-range cast refused by the engine — Arcane Bolt maxes at MEDIUM; nothing spent. Contract counter still 0/4 after two confirmed kills, likely a tracking bug.
- zu Zug 71 (notiert vor Zug 72): Third one-shot First Strike kill (+72 XP, XP 278/300). Quest counter still reads 0/4 despite three confirmed wolf kills — tracking bug persists.
- zu Zug 72 (notiert vor Zug 73): Quest counter still 0/4 despite three confirmed wolf kills; leads mention the boy asking me to take the gray-muzzled leader first.
- zu Zug 73 (notiert vor Zug 74): Col confirms four wolves remain and asks that the gray-muzzled leader be taken first; quest counter still reads 0/4 despite four confirmed kills.
- zu Zug 74 (notiert vor Zug 75): Wind is blowing up-slope toward me, so the wolves likely already have my scent; den split visible across the bowl, no wolves in sight yet.
- zu Zug 75 (notiert vor Zug 76): Reached the den split safely after marking the hidden rock lip; something inside is awake and aware of me, gave one rumble then went silent.
- zu Zug 76 (notiert vor Zug 77): System refused the blind cast: no targetable actor in the den split yet — nothing spent. Must flush the animal into the open first.
- zu Zug 77 (notiert vor Zug 78): The stone flushed out the big gray-muzzled leader; it is now charging me at short range. This is likely the wolf the boy asked me to take first.
- zu Zug 78 (notiert vor Zug 79): Leader wolf defeated in one first-strike Arcane Bolt (50 dmg); Level 4 gained, +5 stat points. Quest counter still reads 0/4 despite five confirmed wolf kills — persistent contradiction.
- zu Zug 79 (notiert vor Zug 80): Leader defeated on first strike again; quest counter still 0/4 despite six kills — persistent counter bug. Stat points assigned (INT 18, WIL 17 per System).
- zu Zug 80 (notiert vor Zug 81): Den holds a nursing female and pups; I'm choosing to spare them. Quest counter still 0/4 despite multiple confirmed wolf kills — persistent counter bug worth noting at turn-in.
- zu Zug 81 (notiert vor Zug 82): Quest counter still reads 0/4 despite many confirmed wolf kills — persistent counter bug; also a wolf howl sounded from the ridge behind me as I left.
- zu Zug 82 (notiert vor Zug 83): The quarry pack was a side matter; the real contract targets are four 'road wolves' on the Mill Road side, which matches the active 0/4 quest. Quest counter bug persists (0/4 despite many confirmed quarry kills).
- zu Zug 83 (notiert vor Zug 84): Col confirmed the road wolves hunt the edges of the day near the beck dip and broken wall; father's house is third past the mill, blue door. Quest counter still 0/4.
- zu Zug 84 (notiert vor Zug 85): MP only 128/212; consider recovering before the dusk fight. Quest counter still 0/4.
- zu Zug 85 (notiert vor Zug 86): Arrived at the dip by midday; wolves expected at dusk. MP at 128/212, so waiting to recover is sensible. Quest counter still 0/4.
- zu Zug 86 (notiert vor Zug 87): First dusk vigil passed with no wolves appearing; MP stayed 128/212 and a passive INT training ticked to 40/200 during the wait.
- zu Zug 87 (notiert vor Zug 88): Second full night at the dip produced no wolves; counter still 0/4. The leads list still shows only the quarry promises, so I'll ask the father directly.
- zu Zug 88 (notiert vor Zug 89): Father corrected Col's lead: wolves range the north treeline where the wood meets the grass by the low wall, not the beck dip — explains two empty vigils. Counter still 0/4.
- zu Zug 89 (notiert vor Zug 90): Father corrected the lead: wolves range the north treeline by the low wall, coming an hour or two after dark. MP still only 128/212 — worth recovering while waiting.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t13 | 13 | 1 | – | nein | 1 | gewonnen, 48 XP |
| enc.t15 | 15 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t24 | 26 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t30 | 32 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t36 | 38 | 1 | – | nein | 1 | gewonnen, 30 XP |
| enc.t38 | 40 | 1 | – | nein | 1 | gewonnen, 48 XP |
| enc.t39 | 41 | 1 | – | nein | 1 | gewonnen, 48 XP |
| enc.t46 | 48 | 1 | – | nein | 1 | gewonnen, 48 XP |
| enc.t51 | 54 | 1 | – | nein | 1 | gewonnen, 30 XP |
| enc.t53 | 56 | 1 | – | nein | 1 | gewonnen, 48 XP |
| enc.t61 | 65 | 1 | – | nein | 1 | gewonnen, 30 XP |
| enc.t64 | 68 | 1 | – | nein | 1 | gewonnen, 58 XP |
| enc.t67 | 71 | 1 | – | nein | 1 | gewonnen, 72 XP |
| enc.t73 | 78 | 1 | – | nein | 1 | gewonnen, 58 XP |

## Quests

- **Cull the Eel-Weir Bog Striders** — active (Zug 7) → completed (Zug 16), READY
  - Aufgabe: Hunt and cull the bog strider colony at the eel-weirs of the Reed Flats so the eel boats can launch safely again.
  - Endzustand: The bog strider colony is culled and the eel boats launch again.
- **Thin the Mill Road Wolves** — active (Zug 19)
  - Aufgabe: Hunt down and cull 4 of the wolves that have been pulling down sheep along the Mill Road east of Barrowford.
  - Endzustand: 4 of the Mill Road wolves are dealt with and the flocks can graze the east pastures again.

## Auffälligkeiten

- Zug 5, Nachricht 9 (board_failed): the board generator failed
- Zug 8, Nachricht 16 (extraction_repaired): the extractor's first answer needed a repair
- Zug 14, Nachricht 28 (extraction_repaired): the extractor's first answer needed a repair
- Zug 16, Nachricht 32 (extraction_repaired): the extractor's first answer needed a repair
- Zug 23, Nachricht 46 (extraction_repaired): the extractor's first answer needed a repair
- Zug 28, Nachricht 56 (extraction_repaired): the extractor's first answer needed a repair
- Zug 51, Nachricht 102 (extraction_repaired): the extractor's first answer needed a repair
- Zug 58, Nachricht 115 (planner_repaired): the planner's first answer needed a repair
- Zug 81, Nachricht 162 (extraction_repaired): the extractor's first answer needed a repair
- Zug 83, Nachricht 166 (extraction_repaired): the extractor's first answer needed a repair
- Zug 85, Nachricht 170 (extraction_repaired): the extractor's first answer needed a repair
- Zug 86, Nachricht 171 (planner_repaired): the planner's first answer needed a repair
- Zug 90, Nachricht 180 (extraction_failed): the extractor failed: $.deltas[3] (fact): .s: expected string, got object; $.deltas[4] (fact): .s: expected string, got object
- Zug 90, Nachricht 180 (extraction_repaired): the extractor's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 24× keine gültige JSON-Entscheidung (Züge 2, 7, 9, 11, 12, 13, 20, 24, 28, 30, 42, 45, 46, 47, 48, 53, 56, 60, 66, 67, 74, 75, 87, 89)

System-Panels: CLARIFY 1, NOT TAKEN 5, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: guild_canon 2, engine_owned_fact 7, engine_owned_memory 1, no_go 3, scene_context 13, quest_count 1, guild_payout 1, group_unclear 3, engine_owned_combat 1, engine_recovery 1, world_rule 1, attack_commitment 2.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 87 | 2 | 2.5 s | 4.8 s | 11766 | 9798 | 77 | – | stop 87 | 0 |
| narrator | 82 | 0 | 9.4 s | 13.6 s | 11279 | 8673 | 434 | – | stop 82 | 0 |
| extract | 92 | 10 | 6.8 s | 10.9 s | 11224 | 8982 | 466 | – | stop 92 | 0 |
| board | 3 | 1 | 9.8 s | 11.5 s | 2286 | 2286 | 1549 | – | stop 3 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 42:25 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 62.2 s) | 1:19 min |
| 90 Züge, Spiel (Senden bis HUD nach der Extraktion) | 33:51 min — Median 21.2 s, p90 34.8 s, max 51.8 s |
| 90 Züge, Spieler-Entscheidung | 5:41 min — Median 3.4 s, 24 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 4:16 min / 0:31 min / 14:16 min / 11:28 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 26.4 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 17:34 min, 80 Züge ≈ 35:09 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Provider narrator | 44 | 128 | 35.3 s | 9.4 s |
| Provider narrator | 78 | 225 | 30.1 s | 9.4 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
