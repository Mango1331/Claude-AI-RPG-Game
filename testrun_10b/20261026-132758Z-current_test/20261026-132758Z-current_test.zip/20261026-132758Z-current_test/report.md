# Avereth Live-Test 20261026-132758Z-current_test

## Kurzfassung

- **Ergebnis:** extractor_failed — turn 73: the World Extractor failed after story message 146; its world changes were not committed ($.deltas[3].scene: explicitly name this earlier scene before the later arrival; do not inherit the reply's final scene; $.deltas[4].scene: explicitly name this )
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 5. Sicherheitsgrenzen: 1000 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** noch nicht erreicht.
- **Charakter:** mage (mage.arcane_bolt, mage.flame_lance) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: pragmatic Guild adventurer: value achievable contracts, loot sales and useful gear or skill investments without reckless fights
- **Züge:** 73 · **Dauer:** 32:16 min · **LLM-Aufrufe der Engine/des Erzählers:** 203
- **Auffälligkeiten:** 18
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.98 |
| Git | c1ed54b596bb (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 15.8 s |
| Browser | chrome 155.0.8059.85 |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261026-132758Z-current_test“, Seed 2091006301 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | I choose Mage. | Engine (Menü/Rückfrage) | creation_complete | Pick Mage as base class. | public roadside verge outside Alderwatch | 90/84 | 2.2 s |
| 2 | I select Arcane Bolt and Flame Lance as my two skills. | Engine (Menü/Rückfrage) | creation_complete | Pick two starter skills and finish creation. | public roadside verge outside Alderwatch | 90/96 | 2.1 s |
| 3 | I walk to the Alderwatch city gate and enter the city, heading for the Adventurers' Guild hall. | Erzähler | open_run_level | Enter Alderwatch and reach the Guild to find a starter contract. | Adventurers' Guild hall, Alderwatch | 90/96 | 19.8 s |
| 4 | "I'm new here and looking to register with the Guild. What do I need to do?" | Erzähler | open_run_level | Register with the Guild and ask about starter contracts. | Adventurers' Guild hall, Alderwatch | 90/96 | 12.2 s |
| 5 | "Yes. Here's two silver — register me." | Erzähler | open_run_level | Pay the 2 silver fee and register with the Guild as Novice. | Adventurers' Guild hall, Alderwatch | 90/96 | 14.3 s |
| 6 | I walk over to the cork board and read the Novice contracts on the lower half. | Erzähler | open_run_level | Read the Novice contract board to pick a starter contract. | Adventurers' Guild hall, Alderwatch | 90/96 | 43.6 s |
| 7 | "Any work before midday — even small paid tasks around the hall — or should I wait for the new postings?" | Erzähler | open_run_level | Ask the clerk about interim work or wait for midday postings. | Adventurers' Guild hall, Alderwatch | 90/96 | 50.5 s |
| 8 | "I'll take the Adder contract at the Millrace Stone." I show my Guild plate to the clerk. | Erzähler | open_run_level | Accept the level-1 adder cull contract and verify it's ACTIVE. | Adventurers' Guild hall, Alderwatch | 90/96 | 15.6 s |
| 9 | I head out through the south gate and follow the river a mile down to Cokewell Mill. | Erzähler | open_run_level | Travel to Cokewell Mill to hunt the adder under the millrace stone. | millrace stone, Cokewell Mill | 90/96 | 22.4 s |
| 10 | "Mind if I wait near the stone until the sun's high? I'll take it when it comes out to warm itself." | Erzähler | open_run_level | Wait near the millrace stone for midday when the adder emerges, then attack it in the open… | millrace stone, Cokewell Mill | 90/96 | 18.8 s |
| 11 | I ask the miller, "Any way to flush it out — a hook, a spade, anything to check under the stone or the bank holes? I'd rather not sit here a… | Erzähler | open_run_level | Ask the miller for tools or advice to flush out or locate the adder. | millrace stone, Cokewell Mill | 90/96 | 18.5 s |
| 12 | "The sluice sounds cleaner. Shut it — I'll stand at the race and take it when the water drops." | Erzähler | open_run_level | Have the miller close the sluice and wait for the adder in the drained channel. | millrace stone, Cokewell Mill | 90/96 | 20.4 s |
| 13 | I cast Flame Lance at the adder while it's still half in its hole, aiming to strike before it can reach the water. | Erzähler | open_run_level | Open combat with Flame Lance on the adder before it escapes. | millrace stone, Cokewell Mill | 90/80 | 20.6 s |
| 14 | "I'll take the skin and fangs back to the Guild. Thanks for the sluice — it made it easy." I collect the carcass parts and head back up the … | Erzähler | open_run_level | Collect the loot and travel back to the Guild hall to turn in the adder contract. | Adventurers' Guild hall, Alderwatch | 90/80 | 20.1 s |
| 15 | I take the fifteen copper and ask the clerk, "Is the parts broker here today? I've an adder skin and two fangs to sell." | Erzähler | open_run_level | Turn in payout done; sell adder loot to the Guild broker. | Adventurers' Guild hall, Alderwatch | 90/80 | 21.1 s |
| 16 | "Five copper the lot works. Done, Hetta." | Erzähler | open_run_level | Accept Hetta's offer and sell the adder skin and fangs for five copper. | Adventurers' Guild hall, Alderwatch | 90/80 | 13.2 s |
| 17 | I thank Hetta and go to the notice board out front to look at the fresh contract listings. | Erzähler | open_run_level | Check the Guild board for a new suitable contract. | Adventurers' Guild hall, Alderwatch | 90/80 | 14.5 s |
| 18 | I take the Bog Striders slip to the clerk. "I'll accept this contract — culling three bog striders at the Reed Flats eel-weirs. Please mark … | Erzähler | open_run_level | Accept the bog strider cull contract (rec. level 6, 90 cp) and get it confirmed ACTIVE. | Adventurers' Guild hall, Alderwatch | 90/80 | 16.2 s |
| 19 | I ask around the Guild hall for an eel boat heading downstream to the Reed Flats landing, and travel there by boat if one is going. | Erzähler | open_run_level | Travel to the Reed Flats eel-weirs to hunt the bog striders. | Reed Flats landing | 90/80 | 40.5 s |
| 20 | I ask the fisher where the striders surface most, then walk carefully out along the walkway toward the weirs with my staff ready. | Erzähler | open_run_level | Hunt the bog striders along the weir walkway while daylight keeps them quiet. | Reed Flats landing | 90/80 | 21.9 s |
| 21 | I stop at the patched planks and cast Flame Lance down through the gap at the water below, targeting the strider hiding under the boards. | Engine (Menü/Rückfrage) | open_run_level | Flame Lance the strider lurking under the patched planks. | Reed Flats landing | 90/80 | 4.3 s |
| 22 | I stay on the walkway by the patched planks and cast Flame Lance down through the boards at the water beneath them. | Engine (Menü/Rückfrage) | open_run_level | Flame Lance the strider lurking under the patched planks. | Reed Flats landing | 90/80 | 4.5 s |
| 23 | I stamp hard on the patched planks a few times to provoke whatever is hiding beneath them into surfacing. | Erzähler | open_run_level | Provoke the hidden strider to appear so it becomes a valid combat target. | Reed Flats landing | 90/80 | 21.7 s |
| 24 | I step back off the patched planks onto the landing side of the walkway and cast Flame Lance at Bog Strider A's head as it forces through th… | Erzähler | open_run_level | Flame Lance the now-surfaced Bog Strider A as a valid combat target. | Reed Flats landing | 90/64 | 21.7 s |
| 25 | I tell the fisher I'll take the middle rows next, and walk on along the walkway toward the weirs, watching the water and planking for signs … | Erzähler | open_run_level | Continue the cull by hunting the second strider along the weir walkway. | Reed Flats landing | 90/64 | 21.1 s |
| 26 | I stop by the rocking trap at the middle rows and stamp on the planks beside it to provoke the strider beneath into surfacing. | Erzähler | open_run_level | Provoke the second strider near the middle rows into becoming a valid target. | Reed Flats landing | 90/64 | 21.7 s |
| 27 | I cast Flame Lance at Bog Strider B's head as it climbs onto the walkway. | Erzähler | open_run_level | Kill Bog Strider B with a first-strike Flame Lance before the third strider arrives. | Reed Flats landing | 90/48 | 21.4 s |
| 28 | #assign INT 2 WIL 2 VIT 1 | System (Befehl) | open_run_level | Spend the level-up stat points on INT, WIL and VIT. | Reed Flats landing | 90/48 | 2.2 s |
| 29 | I walk back along the walkway to the landing and tell the fisher I've killed the second strider, but the third got away toward the bend — I'… | Erzähler | open_run_level | Report the second kill and defer the third strider until rested. | Reed Flats landing | 90/48 | 23.9 s |
| 30 | I accept Tam's offer: I'll take the bunk in the drying shed and the stew, sleep until morning, then finish the cull at first light. | Erzähler | open_run_level | Take the offered lodging and sleep overnight to recover mana before hunting the third stri… | Reed Flats landing | 100/132 | 29.4 s |
| 31 | I come down from the shed and tell Marn he can launch with me — we'll take his boat toward the bend and finish the cull. I cast Flame Lance … | Erzähler | open_run_level | Hunt the third strider with Marn's boat support, first-strike Flame Lance. | the bend at the eel-weirs | 100/132 | 35.9 s |
| 32 | I cast Flame Lance at Bog Strider C's head as it rises from the water. | Erzähler | open_run_level | Kill the third strider with a first-strike Flame Lance. | the bend at the eel-weirs | 100/116 | 18.0 s |
| 33 | I ride back to the landing with Marn, then head to Alderwatch's Guild hall and turn in the contract slip to collect the ninety-coin payout f… | Erzähler | open_run_level | Travel to Alderwatch Guild hall and turn in the completed strider cull contract for the re… | Adventurers' Guild hall, Alderwatch | 100/116 | 25.2 s |
| 34 | #quests | System (Befehl) | open_run_level | Check whether the strider cull contract is actually closed and paid, since narration and H… | Adventurers' Guild hall, Alderwatch | 100/116 | 2.2 s |
| 35 | #audit | System (Befehl) | open_run_level | Inspect the audit log to resolve why the completed strider cull still shows active and 0/3… | Adventurers' Guild hall, Alderwatch | 100/116 | 2.2 s |
| 36 | #quest Cull the Bog Striders at the Eel-Weirs of the Reed Flats | System (Befehl) | open_run_level | Inspect the strider cull quest detail to see why it still shows active and 0/3 despite the… | Adventurers' Guild hall, Alderwatch | 100/116 | 2.2 s |
| 37 | The contract still counts only one strider dead, so two remain. I go back out with Marn to the bend past the third weir and watch the water … | Erzähler | open_run_level | Hunt the remaining striders at the bend with Marn, first-strike Flame Lance on surfacing. | eel-weirs, Reed Flats | 100/116 | 30.6 s |
| 38 | Marn's eyes say three dead, the ledger says one — so I'll trust the counter, not the water. Marn, pole us back along the middle rows of the … | Erzähler | open_run_level | Sweep the middle weir rows for the remaining striders, with a fallback to resolving the co… | eel-weirs, Reed Flats | 100/116 | 38.7 s |
| 39 | I cast Flame Lance at the closest strider, the SHORT one standing in the shallows. | Erzähler | open_run_level | First-strike the nearer strider while it stands still in the shallows. | eel-weirs, Reed Flats | 100/100 | 30.2 s |
| 40 | I hold my action, staff ready, watching the deep pool for the MEDIUM strider to surface before casting Flame Lance at it. | Erzähler | open_run_level | Ambush the remaining MEDIUM strider when it surfaces. | eel-weirs, Reed Flats | 100/100 | 19.5 s |
| 41 | Marn, pole us toward that channel under the frames — I'll watch the reed-bed end of it for the strider that slipped away. | Erzähler | open_run_level | Track the remaining strider through the under-weir channel toward the reed-beds. | channel under the trap-frames | 100/100 | 28.5 s |
| 42 | I cast Flame Lance at the strider's broadside while it watches the boats. | Erzähler | open_run_level | First-strike the last strider broadside in the channel. | channel under the trap-frames | 100/84 | 24.8 s |
| 43 | Marn, take us back to Tam's boats — I'll claim the cull at the Guild counter after. And while we row, I spend my level's growth: #assign INT… | Erzähler | open_run_level | Assign level-up stats and head back to Tam, then to the Guild to resolve the quest counter… | channel under the trap-frames | 100/84 | 49.1 s |
| 44 | #assign INT 3 VIT 2 | System (Befehl) | open_run_level | Spend the five level-up stat points on INT and VIT via the system command. | channel under the trap-frames | 100/84 | 2.4 s |
| 45 | Marn, drop me at the landing — I'm for the Guild hall. (At the counter:) My contract slip reads 2/3 defeated, but I've killed the big one on… | Erzähler | open_run_level | Resolve the 2/3 quest counter discrepancy at the Guild counter before turning in. | channel under the trap-frames | 100/84 | 25.0 s |
| 46 | I let Marn pole me to the landing boards and go speak with Tam before leaving. | Erzähler | open_run_level | Talk to Tam at the landing as he asked, then plan the trip to Alderwatch Guild hall. | Reed Flats landing | 100/84 | 25.2 s |
| 47 | I take the smoked eel and tell Tam I'll deal with the third strider now before it takes another trap. I walk out along the north line toward… | Erzähler | open_run_level | Hunt the remaining bog strider near the middle rows to complete the 3/3 cull before turnin… | the bend at the eel-weirs | 100/84 | 39.7 s |
| 48 | I step back off the sagging elbow onto solid boards, then cast Flame Lance at the water beside the gnawed posts to force the strider hiding … | Erzähler | open_run_level | Bait out and fight the third bog strider at the chewed walkway bend. | the bend at the eel-weirs | 94/68 | 19.9 s |
| 49 | I cast Flame Lance at the strider on the sagging elbow before it can lunge. | Erzähler | open_run_level | Kill the third bog strider with Flame Lance on my initiative turn. | the bend at the eel-weirs | 94/52 | 14.7 s |
| 50 | I take the chitin plates and venom gland and head back along the north line to the landing, then travel to the Alderwatch Guild hall. (At th… | Erzähler | open_run_level | Travel back and turn in the completed strider cull at the Guild hall, flagging the counter… | Adventurers' Guild hall, Alderwatch | 94/52 | 34.9 s |
| 51 | #quests | System (Befehl) | open_run_level | Verify whether the cull contract actually closed despite the refusal line and the clerk's … | Adventurers' Guild hall, Alderwatch | 94/52 | 2.3 s |
| 52 | I set the contract slip on the counter again: the seal read READY and the count is right — mark the cull completed and close it in the roll. | Erzähler | open_run_level | Get the System to actually close the bog strider cull contract and confirm it in the quest… | Adventurers' Guild hall, Alderwatch | 94/52 | 21.1 s |
| 53 | I tell the clerk that the fisher Marn watched the third strider die and vouched for it at the landing — can he take a witnessed statement to… | Erzähler | open_run_level | Resolve the 2/3 count discrepancy via a witness statement or the Reed Flats desk. | Adventurers' Guild hall, Alderwatch | 94/52 | 40.4 s |
| 54 | I ask the clerk to attach the note to the contract, then take lodging for the night so I can reach the Reed Flats desk in the morning. | Erzähler | open_run_level | Have the dispute note added and get a night's lodging before going to Reed Flats at dawn. | Adventurers' Guild hall, Alderwatch | 94/52 | 26.8 s |
| 55 | I take the corner room and pay six coppers for the bed and supper, then eat and sleep until morning. | Erzähler | open_run_level | Get lodging and a full night's recovery before going to the Reed Flats desk at dawn. | Adventurers' Guild hall, Alderwatch | 94/52 | 28.5 s |
| 56 | I book the corner room with supper, paying the six coppers, then go up, eat and sleep until morning. | Erzähler | open_run_level | Book the room properly so sleep is registered, then recover overnight. | Adventurers' Guild hall, Alderwatch | 94/52 | 21.9 s |
| 57 | I book the corner room with supper at the ledger desk, paying the six coppers — then, once it's booked, I go up and sleep until morning. | Erzähler | open_run_level | Book lodging explicitly so sleep registers, then recover overnight. | Adventurers' Guild hall, Alderwatch | 94/52 | 24.1 s |
| 58 | I climb to the corner room, take the bed, and sleep until morning. | Erzähler | open_run_level | Sleep in the now-booked corner room to recover overnight. | Adventurers' Guild hall, Alderwatch | 94/52 | 17.0 s |
| 59 | I ask the innkeeper to write my name in the ledger for the corner room and confirm the booking is complete — then I go up and sleep. | Erzähler | open_run_level | Get the ledger booking explicitly confirmed so sleep registers, then sleep overnight. | Adventurers' Guild hall, Alderwatch | 94/52 | 15.1 s |
| 60 | I take the key, unlock the corner room, and go to bed there, resting until dawn. | Erzähler | open_run_level | Rephrase the overnight rest to dodge the false 'room not booked' refusal and actually reco… | Adventurers' Guild hall, Alderwatch | 115/168 | 18.7 s |
| 61 | I return the key to the innkeeper and head to the Reed Flats to reconcile the third-strider count at the desk there. | Erzähler | open_run_level | Recover done; travel to Reed Flats to resolve the 2/3 count discrepancy. | eel-weirs, Reed Flats | 115/168 | 27.3 s |
| 62 | I follow the fresh prints toward the lower weir, staff ready, staying alert for the strider. | Erzähler | open_run_level | Track and deal with the remaining bog strider at the lower weir. | lower weir | 115/168 | 23.9 s |
| 63 | I cast Flame Lance at the strider across the weir's outflow. | Erzähler | open_run_level | Attack the confirmed third strider to complete the 3/3 cull contract. | lower weir | 115/152 | 18.7 s |
| 64 | I assign all five free stat points to INT, then walk back to the first weir landing to report the third strider's death to the crew. | Erzähler | open_run_level | Spend level-up points on INT and report the completed cull at the landing. | Reed Flats landing | 115/152 | 23.5 s |
| 65 | "It's done — the big one dropped at the lower weir, and that makes all three culled. Your traps should sit quiet now." | Erzähler | open_run_level | Report the third strider's death to Tam to settle the count, then head back to turn in the… | Reed Flats landing | 115/152 | 26.1 s |
| 66 | #assign INT 5 | System (Befehl) | open_run_level | Verify the stat assignment is recorded, since HUD still shows 5 free points and INT 16. | Reed Flats landing | 115/152 | 2.2 s |
| 67 | I thank Tam and the fishers for the smoked eel, then set out on foot for Alderwatch to reconcile the count at the Reed Flats desk and turn i… | Erzähler | open_run_level | Travel back to Alderwatch to settle the 3/3 cull contract. | Reed Flats landing | 115/152 | 19.6 s |
| 68 | I give the carter a hand at the frame to shift the stuck wheel, then continue toward Alderwatch. | Erzähler | open_run_level | Help the stranded carter briefly, then keep travelling to Alderwatch to turn in the contra… | Alderwatch | 115/152 | 24.4 s |
| 69 | I head to the Guild hall and find the Reed Flats desk to reconcile the third-strider count, then turn in the completed cull contract. | Erzähler | open_run_level | Reach the Guild hall's Reed Flats desk, reconcile the count and turn in the 3/3 contract. | Adventurers' Guild hall, Alderwatch | 115/152 | 19.5 s |
| 70 | #assign INT 3 WIL 2 | System (Befehl) | open_run_level | Spend the five new level-up points on INT and WIL. | Adventurers' Guild hall, Alderwatch | 115/152 | 2.4 s |
| 71 | "Before I go — do you buy strider chitin and venom glands here, and what would you offer for twelve plates and six glands? And I'd take the … | Erzähler | open_run_level | Sell surplus strider loot at the Guild counter and buy the Mend primer. | Adventurers' Guild hall, Alderwatch | 115/152 | 29.6 s |
| 72 | "Then I'll be back when Hetta's at her desk. Meanwhile — is there a Guild board contract I could take for the morning that starts and ends n… | Erzähler | open_run_level | Ask the clerk for a morning contract while waiting for the materials desk to open. | Adventurers' Guild hall, Alderwatch | 115/152 | 19.4 s |
| 73 | "I'll wait for Hetta then. Is there somewhere nearby I could compare staff and robe prices in the meantime?" |  | open_run_level | Fill the morning browsing gear prices in the market while waiting for Hetta's afternoon de… | Adventurers' Guild hall, Alderwatch | 115/152 | 43.3 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zum Start (notiert vor Zug 1): Character creation started; choosing Mage for INT/WIL.
- zu Zug 1 (notiert vor Zug 2): Stats after Mage selection: INT 8, WIL 8, Max MP 96; starter staff and robes auto-equip on completion.
- zu Zug 2 (notiert vor Zug 3): Creation complete: Mage with Arcane Bolt and Flame Lance, MATK 10, 5 silver. Heading to the Guild for a first contract.
- zu Zug 3 (notiert vor Zug 4): Reached the Guild hall; not yet registered (Guild Rank —). Clerk is engaged and waiting.
- zu Zug 4 (notiert vor Zug 5): Registration costs 2 silver (I have 5); after registering I should check the contract board for a Novice contract.
- zu Zug 5 (notiert vor Zug 6): Registration confirmed: Novice rank, Power Rank F, coin 3 Silver. Coin dropped 50→30 copper in the panel while HUD shows 3 Silver — same value, minor unit inconsistency.
- zu Zug 6 (notiert vor Zug 7): Novice board is empty; new postings expected around midday. Guild sells skill primers (120 cp each) for skills I already know except Guard/Ward/Mend — noted as future learning options.
- zu Zug 7 (notiert vor Zug 8): Midday postings arrived early; five Novice contracts posted. The adder cull (rec. level 1, 15 cp) is the sensible starter; catacombs/boar/wolves are above my level.
- zu Zug 8 (notiert vor Zug 9): Adder contract confirmed ACTIVE in HUD. Full HP/MP; travel to the mill is next.
- zu Zug 9 (notiert vor Zug 10): At the mill; adder hides under the stone except near midday, and the bank has escape holes — waiting for midday sun is the sensible tactic.
- zu Zug 10 (notiert vor Zug 11): The adder never emerged at midday despite warm sun; miller suggests high water or it moved into bank holes. Waiting alone didn't work, so trying to flush it next.
- zu Zug 11 (notiert vor Zug 12): Miller offered two flush methods; chose the sluice option as safer than prying the stone with a spade.
- zu Zug 12 (notiert vor Zug 13): Adder engaged: HP 20, larger than expected. Combat has begun.
- zu Zug 13 (notiert vor Zug 14): Adder one-shot with Flame Lance first strike (45 dmg); +24 XP, loot confirmed, contract ready for turn-in.
- zu Zug 14 (notiert vor Zug 15): Contract turned in: +15 copper payout plus 46 quest XP (70/100 total). Clerk mentions a side-door broker for monster parts on Guild days.
- zu Zug 15 (notiert vor Zug 16): Broker offered 5 copper for skin plus fangs; HUD still shows the parts carried, so sale not yet confirmed.
- zu Zug 16 (notiert vor Zug 17): Sale confirmed: +5 copper, HUD now 5 Silver, adder parts cleared. Hetta points to fresh board listings including wolves and bog striders.
- zu Zug 17 (notiert vor Zug 18): Board shows four Novice contracts; bog striders (rec. lvl 6, 9 Silver) look the best fit while I'm L1 near level-up. Shop panel oddly offers skill primers at 120 cp each, beyond my 5 Silver minus… actually affordable only one, but I'll consider after next payout.
- zu Zug 18 (notiert vor Zug 19): Contract confirmed ACTIVE (0/3). MP 80/96; could top up before the fight, but Flame Lance one-shot the adder so proceeding.
- zu Zug 19 (notiert vor Zug 20): Arrived at Reed Flats landing by eel boat; fisher warns three striders come up under the planking and go quiet in sunlight. Time 17:52, so daylight may be fading.
- zu Zug 20 (notiert vor Zug 21): Walkway signs (droppings, patched boards) mark a strider under the middle rows; sun still up for about two hours, which keeps them quiet.
- zu Zug 21 (notiert vor Zug 22): System rejected my first cast because the strider was not a valid target in the active scene; nothing was spent. Retrying the attack against the spot itself.
- zu Zug 22 (notiert vor Zug 23): Two Flame Lance attempts rejected: the strider under the boards is not a valid target yet, suggesting it must be drawn out into the scene before combat can start.
- zu Zug 23 (notiert vor Zug 24): Stamping worked: Bog Strider A is now ENGAGED with HP 24/24, so combat targeting is possible. Two earlier Flame Lance attempts were correctly rejected before it surfaced—no MP lost.
- zu Zug 24 (notiert vor Zug 25): Bog Strider A defeated with one Flame Lance first strike (24 XP, XP 94/100); loot collected. Quest panel still shows 0/3 defeated despite the kill being confirmed in combat log — possible HUD lag worth watching.
- zu Zug 25 (notiert vor Zug 26): Quest panel still shows 0/3 defeated despite the engine confirming Bog Strider A defeated with XP and loot — a persistent counter contradiction. MP 64/96 leaves two more Flame Lances before low reserves.
- zu Zug 26 (notiert vor Zug 27): Bog Strider B is now a valid target (SHORT, HP 29/29); a third strider is sliding toward the broken span, so a second fight may follow immediately.
- zu Zug 27 (notiert vor Zug 28): Level 2 confirmed with +5 stat points; quest counter still shows 0/3 despite two engine-confirmed kills. Third strider withdrawn toward the bend; fisher says return before dark.
- zu Zug 28 (notiert vor Zug 29): Stats assigned: INT 11, WIL 11, VIT 8, no points left. Quest counter still shows 0/3 despite two engine-confirmed kills — persistent contradiction.
- zu Zug 29 (notiert vor Zug 30): Two kills confirmed with XP and loot but quest panel still shows 0/3 — persistent counter contradiction. HUD shows MP max 132 after assignment; taking the shed bunk to sleep and recover before the third strider.
- zu Zug 30 (notiert vor Zug 31): Overnight recovery confirmed: HP 100/100, MP 132/132. Quest counter still 0/3 despite two engine-confirmed kills — persistent contradiction.
- zu Zug 31 (notiert vor Zug 32): Strider C is now a valid target at HP 24/24; the previous Flame Lance was left forming, not resolved.
- zu Zug 32 (notiert vor Zug 33): Third strider defeated first-strike, +24 XP (48/200), loot gained; quest counter still shows 0/3 despite three engine-confirmed kills — persistent contradiction noted.
- zu Zug 33 (notiert vor Zug 34): Narration shows the clerk confirming and paying 90 cp, but the HUD still lists the quest active, 0/3 defeated, and 5 Silver — turn-in result unconfirmed, checking the quest panel.
- zu Zug 34 (notiert vor Zug 35): Narrator confirmed the turn-in was paid (90 cp counted out), but the quest panel still lists the strider cull as active 0/3 — engine-recorded state contradicts both narration and the three confirmed kills.
- zu Zug 35 (notiert vor Zug 36): Audit shows the engine rejected the turn-in: contract completion stays engine-owned and the kill progress was never accepted, so the quest remains genuinely active. The clerk's payment narration was unconfirmed story, not engine state.
- zu Zug 36 (notiert vor Zug 37): Quest detail reveals the engine only accepted one kill (1/3 implied), despite narration confirming three kills — my earlier turn-in was rightly rejected; must kill two more striders for real.
- zu Zug 37 (notiert vor Zug 38): Narrator and Marn insist three striders died and two carcasses are visible, yet the HUD still shows 0/3 — a hard engine/story contradiction; the hunt continues per the authoritative counter.
- zu Zug 38 (notiert vor Zug 39): The burned striders are molts, not kills — nothing was actually dead; two live striders (one SHORT, one MEDIUM) now surfaced. Explains the 0/3 counter.
- zu Zug 39 (notiert vor Zug 40): One real strider killed (engine-confirmed 1/3); earlier kills were molts. MEDIUM strider E still holds in the deep pool.
- zu Zug 40 (notiert vor Zug 41): One real strider defeated (engine 1/3); the last MEDIUM strider likely fled under the weirs toward the reed-beds.
- zu Zug 41 (notiert vor Zug 42): Strider E surfaced broadside at half distance; still only 1/3 engine-confirmed kills.
- zu Zug 42 (notiert vor Zug 43): Third strider defeated and Level 3 confirmed, yet the quest panel still reads 2/3 — the molt/kill confusion persists; the counter must be checked at turn-in.
- zu Zug 43 (notiert vor Zug 44): Tam says the two burnt husks drifted up days dead — so the third live strider may still be out on the north line, matching the quest counter's 2/3. The previous #assign was embedded in a mixed message and never applied (Free Stat Points still 5).
- zu Zug 44 (notiert vor Zug 45): Stats assigned (INT 15, VIT 10). Tam says the two burnt husks were days dead, so only two live striders were killed this week and a third may still raid the north line — yet the engine awarded Level 3 and loot for strider E, so the counter may be stale.
- zu Zug 45 (notiert vor Zug 46): Travel and turn-in were refused as separate steps; Guild hall is in Alderwatch, half an afternoon away. Tam wants a word first.
- zu Zug 46 (notiert vor Zug 47): HUD sign places the third strider near the middle rows/ben; quest still 2/3. Tam gave a smoked eel and hospitality offer.
- zu Zug 47 (notiert vor Zug 48): Fresh gnawed posts at the middle-rows bend indicate the third strider is lurking under the listing walkway; quest still reads 2/3.
- zu Zug 48 (notiert vor Zug 49): Third strider engaged from behind; it took the first-strike bite (HP 94). Flame Lance 55–68 damage should one-shot its 29 HP.
- zu Zug 49 (notiert vor Zug 50): Third strider defeated (67 dmg Flame Lance, +48 XP, loot gained), but the quest panel still reads 2/3 defeated despite all three live striders being killed — persistent counter discrepancy to resolve at turn-in.
- zu Zug 50 (notiert vor Zug 51): Contradiction: the System refused the turn-in and the HUD still shows the quest active at 2/3, while the narrator confirmed the clerk closed the cull and paid 90 cp. I have 5 Silver and still hold 10 chitin plates and 6 venom glands as surplus.
- zu Zug 51 (notiert vor Zug 52): Persistent contradiction: narrator confirmed the clerk closed the cull and paid 90 cp, but the System refused the turn-in and #quests still shows it active at 2/3. Retrying the turn-in now that the seal is brightened.
- zu Zug 52 (notiert vor Zug 53): Turn-in refused again: the roll records only 2/3 striders; the clerk says only the Reed Flats desk can fix a records fault. Persistent System/narrator contradiction on this contract.
- zu Zug 53 (notiert vor Zug 54): Clerk confirms only the Reed Flats desk can reconcile the 2/3 count; he offers to attach a note. Contract remains active despite narrator-side closure claims earlier.
- zu Zug 54 (notiert vor Zug 55): Note attached to the contract slip as instructed; lodging now offered at the Tallowed Wick. Persistent contradiction stands: quest panel still shows 2/3 despite the third strider's confirmed kill.
- zu Zug 55 (notiert vor Zug 56): System refused 'sleep until morning' as room not booked even though the narrator had me pay and take the key — booking must be explicit before sleep.
- zu Zug 56 (notiert vor Zug 57): Scene snapped back to the Guild hall lodging ledger after the payment; double-charged 6 cp twice for the same room and supper (now 3s8c). Sleep still refused until booking is explicit, so re-booking at the ledger.
- zu Zug 57 (notiert vor Zug 58): Third payment taken and the ledger actually written this time, yet the room is still flagged unbooked for sleep — a persistent booking/sleep contradiction worth noting if it refuses again.
- zu Zug 58 (notiert vor Zug 59): Fourth payment of 6 cp taken, coin now 3s8c, yet the room still flags unbooked for sleep — a persistent booking/sleep contradiction across four attempts; trying explicit ledger confirmation next.
- zu Zug 59 (notiert vor Zug 60): Fifth payment of 6 cp taken and the ledger written with my name, yet sleep is still refused as 'room not booked' — likely the engine rejects the phrase 'sleep until morning' itself; trying different wording.
- zu Zug 60 (notiert vor Zug 61): Sleep finally registered after rephrasing to 'resting until dawn' — full HP/MP recovery. Persistent lodging contradiction resolved by wording, not booking.
- zu Zug 61 (notiert vor Zug 62): Crew reports fresh big strider prints at the lower weir despite the 2/3 count; the disputed third strider may still be alive, which would reconcile the count.
- zu Zug 62 (notiert vor Zug 63): Third strider confirmed alive at the lower weir (Bog Strider G, HP 53/53, MEDIUM); killing it reconciles the 2/3 count.
- zu Zug 63 (notiert vor Zug 64): One-shot Flame Lance killed the third strider (62 dmg vs 53 HP); contract now 3/3, ready for turn-in. Level 4, +5 stat points pending.
- zu Zug 64 (notiert vor Zug 65): Narrator says the five points settled but HUD still shows Free Stat Points 5 and INT 13 — assignment not yet recorded; will verify with #assign.
- zu Zug 65 (notiert vor Zug 66): HUD contradiction: narrator says five points settled, but HUD shows Free Stat Points 5 and INT 16 (13+5 would be 18). Re-issuing #assign to confirm.
- zu Zug 66 (notiert vor Zug 67): #assign INT 5 finally recorded: INT 21, 0 free points — earlier assignments were narration-only. Contract 3/3, heading to turn in.
- zu Zug 67 (notiert vor Zug 68): Location shows Reed Flats landing while narrator describes the levee road — the System confirms the walk is in progress. Contract 3/3 ready for turn-in; earlier narrator's count-reconciliation must happen at the Reed Flats desk, not Alderwatch's paying desk.
- zu Zug 68 (notiert vor Zug 69): Arrived in Alderwatch; clerk confirms the count must be reconciled at the Reed Flats desk, not the paying desk.
- zu Zug 69 (notiert vor Zug 70): Contract turned in: +90 copper, +360 XP, Level 5 confirmed with 5 free points. Guild now sells skill primers (strike, bolt, guard, ward, mend) at 120 cp each.
- zu Zug 70 (notiert vor Zug 71): Contract turned in cleanly (+9 silver, +360 XP, Level 5); #assign now records reliably (INT 25, WIL 16, 0 free). Guild sells skill primers at 120 cp each.
- zu Zug 71 (notiert vor Zug 72): Materials clerk Hetta and the primers are only available in the afternoon; morning contract browsing is the sensible filler.
- zu Zug 72 (notiert vor Zug 73): Morning board is thin: only Proven-rank catacomb notices; Novice rat job already taken. Hetta (materials sales and primers) opens in the afternoon.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t13 | 13 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t22 | 24 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t25 | 27 | 1 | – | nein | 1 | gewonnen, 30 XP |
| enc.t29 | 32 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t33 | 39 | 1 | – | nein | 1 | gewonnen, 144 XP |
| enc.t36 | 42 | 1 | – | nein | 1 | gewonnen, 144 XP |
| enc.t41r | 48 | 1 | – | nein | 1 | gewonnen, 48 XP |
| enc.t55 | 63 | 1 | – | nein | 1 | gewonnen, 168 XP |

## Quests

- **Cull the Adder at the Millrace Stone** — active (Zug 8) → completed (Zug 14), READY
  - Aufgabe: Hunt down and cull 1 large adder denning under the millrace stone, which has struck at the miller's boy fetching water.
  - Endzustand: The adder at the millrace stone is culled and the mill household draws water safely again.
- **Cull the Bog Striders at the Eel-Weirs of the Reed Flats** — active (Zug 18) → completed (Zug 69), READY
  - Aufgabe: Hunt and cull 3 bog striders that have claimed the eel-weirs of the Reed Flats and snatched two fishers off their walkways.
  - Endzustand: The 3 bog striders at the eel-weirs of the Reed Flats are culled and the eel boats launch safely again.

## Auffälligkeiten

- Zug 6, Nachricht 11 (board_failed): the board generator failed
- Zug 15, Nachricht 30 (extraction_repaired): the extractor's first answer needed a repair
- Zug 18, Nachricht 35 (cull_count): Cull the Bog Striders at the Eel-Weirs of the Reed Flats: its objective counts 3, its texts say 3, 2 (for review)
- Zug 19, Nachricht 38 (extraction_repaired): the extractor's first answer needed a repair
- Zug 30, Nachricht 60 (extraction_repaired): the extractor's first answer needed a repair
- Zug 31, Nachricht 62 (extraction_repaired): the extractor's first answer needed a repair
- Zug 33, Nachricht 66 (extraction_repaired): the extractor's first answer needed a repair
- Zug 37, Nachricht 73 (planner_repaired): the planner's first answer needed a repair
- Zug 42, Nachricht 84 (extraction_repaired): the extractor's first answer needed a repair
- Zug 50, Nachricht 100 (extraction_repaired): the extractor's first answer needed a repair
- Zug 54, Nachricht 108 (extraction_repaired): the extractor's first answer needed a repair
- Zug 55, Nachricht 110 (extraction_repaired): the extractor's first answer needed a repair
- Zug 57, Nachricht 114 (extraction_repaired): the extractor's first answer needed a repair
- Zug 64, Nachricht 127 (stat_words): the player spent Stat Points in words, not with #assign; nothing was assigned (for review: did the story tell them as done?)
- Zug 68, Nachricht 136 (extraction_repaired): the extractor's first answer needed a repair
- Zug 71, Nachricht 142 (extraction_repaired): the extractor's first answer needed a repair
- Zug 73, Nachricht 146 (extraction_failed): the extractor failed: $.deltas[3].scene: explicitly name this earlier scene before the later arrival; do not inherit the reply's final scene; $.deltas[4].scene: explicitly name this earlier scene before the later arrival; 
- Zug 73, Nachricht 146 (extraction_repaired): the extractor's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 12× keine gültige JSON-Entscheidung (Züge 11, 20, 21, 22, 35, 36, 40, 41, 42, 44, 48, 53)

System-Panels: CLARIFY 0, NOT TAKEN 0, REFUSED 2, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: ambient 6, engine_owned_memory 2, engine_owned_fact 12, engine_owned 2, attack_commitment 2, engine_owned_combat 1, no_go 7, scene_context 30, guild_canon 1, quest_count 3, quest_dependency 2, group_unclear 1, group_fact 1, world_rule 1, npc_continuity 9, object 1, engine_booked 1, engine_recovery 1, guild_payout 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 64 | 1 | 2.8 s | 4.5 s | 11528 | 9793 | 98 | – | stop 64 | 0 |
| narrator | 61 | 0 | 8.9 s | 12.9 s | 11510 | 8747 | 417 | – | stop 61 | 0 |
| extract | 74 | 13 | 5.8 s | 10.2 s | 11198 | 8992 | 431 | – | stop 74 | 0 |
| board | 4 | 2 | 15.6 s | 19.2 s | 2908 | 2367 | 1244 | – | stop 4 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 32:16 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 15.8 s) | 0:31 min |
| 73 Züge, Spiel (Senden bis HUD nach der Extraktion) | 25:45 min — Median 21.1 s, p90 38.7 s, max 50.5 s |
| 73 Züge, Spieler-Entscheidung | 4:49 min — Median 3.2 s, 12 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 3:44 min / 0:59 min / 10:30 min / 7:56 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 25.1 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 16:45 min, 80 Züge ≈ 33:30 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spieler | 64 | – | 31.0 s | 3.2 s |
| Provider narrator | 53 | 142 | 31.9 s | 8.9 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
