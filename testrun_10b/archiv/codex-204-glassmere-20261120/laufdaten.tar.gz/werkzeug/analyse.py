import json,collections,datetime,decimal,statistics,tarfile,gzip,re,hashlib,io,sys,os
from pathlib import Path
D=Path('/tmp/rpg204/live')
def rows(f):return [json.loads(l) for l in (D/f).read_text().splitlines() if l] if (D/f).exists() else []
ledger=rows('physical.jsonl');starts={x['id']:x for x in ledger if x['kind']=='start'};ends={x['id']:x for x in ledger if x['kind']=='end'};turns={x['n']:x for x in rows('turns.jsonl')}
actions=rows('actions.jsonl')
activity=[]
for x in actions:
 n=x['n'];req=[s for s in starts.values() if s['turn']==n]; rr=[ends.get(s['id'],{}) for s in req]
 obs=turns.get(n,{}).get('timing',{});marks=obs.get('marks',{});w=obs.get('world',{}) or {}
 dur=lambda k:round((marks[k]-marks['click'])/1000,3) if marks.get(k)!=None and marks.get('click')!=None else None
 activity.append(dict(n=n,player=x.get('text'),hud=x.get('hud',False),mode=x.get('mode'),requested=[s['role'] for s in req],ids=[s['id'] for s in req],failed=[r.get('id') for r in rr if not r.get('ok')],firstProse=dur('firstProse'),ready=dur('ready'),applied=w.get('extraction_status'),persisted=w.get('persisted'),verifiedReload=n in turns,cost=str(sum((decimal.Decimal(str((r.get('usage') or {}).get('cost',0))) for r in rr),decimal.Decimal(0)))))
events=[(x['at'],1,x['id']) for x in starts.values()]+[(x['at'],-1,x['id']) for x in ends.values()]
overlap=any(ends.get(i,{}).get('at',float('inf'))>s['at'] for i,s in zip(starts,list(starts.values())[1:]))
usage=[r['usage'] for r in ends.values() if r.get('usage')];su=lambda k:sum(u.get(k,0) for u in usage)
cost=sum(decimal.Decimal(str(u['cost'])) for u in usage)
summary=dict(complete=len(turns),inputs=len(actions),physical=len(starts),endRecords=len(ends),serial=not overlap,roles=dict(collections.Counter(s['role'] for s in starts.values())),input=su('prompt_tokens'),output=su('completion_tokens'),reasoning=sum((u.get('completion_tokens_details')or {}).get('reasoning_tokens',0) for u in usage),cache=sum((u.get('prompt_tokens_details')or {}).get('cached_tokens',0) for u in usage),confirmedCostUSD=str(cost),chargedOrReservedUSD=str(sum(decimal.Decimal(r['chargedOrReservedUSD']) for r in ends.values())),turns=activity)
(D/'metrics.json').write_text(json.dumps(summary,indent=2))
print({k:v for k,v in summary.items() if k!='turns'})
