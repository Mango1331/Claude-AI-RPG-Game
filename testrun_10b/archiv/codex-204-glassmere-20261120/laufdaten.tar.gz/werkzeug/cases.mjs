import fs from 'node:fs'; import assert from 'node:assert/strict';
import {engineAt,foldCheck,normalizeEvent} from '/workspace/avereth-204/avereth-engine/tools/replay/replay.mjs';
const dir=process.argv[2]||'/tmp/rpg204/live', rows=f=>fs.readFileSync(dir+'/'+f,'utf8').trim().split('\n').map(JSON.parse);
const E=await engineAt();const chat=rows('chat.jsonl').slice(1), ledger=rows('physical.jsonl');
const result={fold:foldCheck(E,{chat}),cases:[]};
for(const [turn,side] of [[5,'player'],[5,'reply'],[6,'player'],[16,'reply'],[20,'reply'],[23,'reply']]){
 const i=chat.map((m,j)=>m.is_user?j:null).filter(j=>j!==null)[turn-1]+Number(side==='reply');
 const slice=structuredClone(chat.slice(0,i+1)),m=slice.at(-1),orig=m.extra.avereth;delete m.extra.avereth;
 const inputs=ledger.filter(r=>r.kind==='end'&&r.turn===turn&&r.role===(side==='player'?'planner':'extractor'));let idx=0;const llm=async()=>{assert(idx<inputs.length);return inputs[idx++].text;};
 if(side==='player'){if(m.is_system)m.is_system=false;await E.runtime.prepareGenerationAsync(slice,E.content,{type:'normal',settings:{},llm});}
 else{let first=E.runtime.processReplyAny(slice,i,E.content,{});assert(first.extract);await E.runtime.runExtraction(slice,i,E.content,llm);}
 const events=m.extra?.avereth?.events||[];const old=orig.events||[];const match=JSON.stringify(events.map(normalizeEvent))===JSON.stringify(old.map(normalizeEvent));
 result.cases.push({turn,side,modelInputs:idx,originalEvents:old.length,replayedEvents:events.length,identical:match,rejected:events.filter(e=>e.t==='delta.rejected').map(e=>[e.d.rule,e.d.reason])});
}
console.log(JSON.stringify(result,null,2));
