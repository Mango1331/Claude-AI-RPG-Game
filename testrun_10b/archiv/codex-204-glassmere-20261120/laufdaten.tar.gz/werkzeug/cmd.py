from pathlib import Path
import json,sys,time
d=Path('/tmp/rpg204/live');cmd=json.loads(sys.argv[1]);cmd['seq']=time.time_ns()//1000000
t=d/'command.tmp';t.write_text(json.dumps(cmd));t.replace(d/'command.json')
while True:
 r=json.loads((d/'response.json').read_text())
 if r.get('seq')==cmd['seq']:break
 time.sleep(.3)
print(r)
v=json.loads((d/'visible.json').read_text());print(v['last']['text']);print((v['last'].get('engine') or '')[:1900]);print((v['hud'] or '')[:2400]);print(v['controls'])
