import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {Driver,loadPlaywright} from '/workspace/avereth-204/avereth-engine/tools/st_live/live/driver.mjs';
import {startServer} from '/workspace/avereth-204/avereth-engine/tools/st_live/live/server.mjs';
import {createInstance,writeConfig,seedProfile,chatFiles} from '/workspace/avereth-204/avereth-engine/tools/st_live/live/profile.mjs';
import {PRESET_TO_SETTINGS} from '/workspace/avereth-204/avereth-engine/tools/st_live/live/import_profile.mjs';
import {observeTurn} from '/workspace/avereth-ortrade/avereth-engine/tools/st_live/natural_ab/observe.mjs';
import {foldChat} from '/workspace/avereth-204/avereth-engine/src/host.js';
const root='/tmp/rpg204/live', stDir='/workspace/avereth-setup/st-sandbox/SillyTavern', eng='/workspace/avereth-204/avereth-engine';
const file=k=>path.join(root,k), save=(k,v)=>{fs.writeFileSync(file(k+'.tmp'),JSON.stringify(v,null,2));fs.renameSync(file(k+'.tmp'),file(k));};
const journal=(k,obj)=>fs.appendFileSync(file(k),JSON.stringify(obj)+'\n'), wait=ms=>new Promise(r=>setTimeout(r,ms));
const records=()=>fs.existsSync(file('physical.jsonl'))?fs.readFileSync(file('physical.jsonl'),'utf8').trim().split('\n').filter(Boolean).map(JSON.parse):[];
assert(!process.env.OPENROUTER_API_KEY&&!process.env.FEATHERLESS_API_KEY);save('gate.json',{arm:null});
const inst=createInstance({runId:'204',base:root,runDir:root});
const port=18541;writeConfig(inst,port);
const start=tag=>startServer({stDir,inst,port,logFile:file(tag+'.log'),timedFile:file(tag+'-timed.log')});
const boot=await start('boot');await boot.stop();
const preset='Avereth Narrator V4',raw=fs.readFileSync(eng+'/presets/'+preset+'.json','utf8');
const generation=Object.fromEntries(Object.entries(JSON.parse(raw)).map(([k,v])=>[PRESET_TO_SETTINGS[k]||k,v]));
const card='Avereth V4'; const seeded=seedProfile(inst,{username:'Alaric',card:{name:card},preset:{name:preset,text:raw},generation,connection:{chat_completion_source:'custom',custom_url:'http://127.0.0.1:18551/v1',custom_model:'z-ai/glm-5.3-flash',custom_include_body:'reasoning:\n  effort: low',custom_include_headers:'',custom_exclude_body:'',custom_prompt_post_processing:''},source:'custom'});
const sf=path.join(inst.user,'settings.json');let settings=JSON.parse(fs.readFileSync(sf));settings.oai_settings.stream_openai=true;settings.power_user.smooth_streaming=false;fs.writeFileSync(sf,JSON.stringify(settings));
const server=await start('st');const browser=await loadPlaywright().chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--disable-dev-shm-usage']});
let counter=0, blocked=false;
try{
const dr=await Driver.create(browser,{turnTimeoutMs:900000});const p=dr.page;assert((await dr.open(server.url)).connected);await dr.openCard(card);
const cfg=await p.evaluate(()=>{let c=SillyTavern.getContext(),o=c.chatCompletionSettings;return {description:c.characters[c.characterId].description,model:o.custom_model,stream:o.stream_openai,smooth:c.powerUserSettings.smooth_streaming,compact:c.extensionSettings.avereth?.compactOutput===true,preset:o.preset_settings_openai,context:o.openai_max_context,max:o.openai_max_tokens,temp:o.temp_openai,topP:o.top_p_openai};});
assert.equal(cfg.description.trim(),fs.readFileSync(eng+'/content/narrator/Avereth_Narrator_Contract_v4.txt','utf8').trim());assert(cfg.stream&&!cfg.smooth&&!cfg.compact&&cfg.preset===preset&&cfg.max===4096);save('profile.json',{...cfg,core:seeded,chat:await dr.identity()});
const digest=x=>createHash('sha256').update(JSON.stringify(x)).digest('hex');
async function verify(n){
 const ch=await dr.chat();assert(await dr.verifySaved(ch,{complete:true}));const before=foldChat(ch);assert.deepEqual(before.errors,[]);
 const ev=ch.map(m=>m.extra?.avereth?.events||[]);await p.evaluate(async()=>{await SillyTavern.getContext().reloadCurrentChat()});
 await p.waitForFunction(len=>SillyTavern.getContext().chat.length===len,ch.length);
 const fresh=await dr.chat();assert(await dr.verifySaved(fresh,{complete:true}));const f=foldChat(fresh);assert.deepEqual(f.errors,[]);assert.deepEqual(before.state,f.state);assert.deepEqual(ev,fresh.map(m=>m.extra?.avereth?.events||[]));
 const files=chatFiles(inst,card);const actual=files.find(f=>path.basename(f,'.jsonl')===dr.testChat.chatId);assert(actual);fs.copyFileSync(actual,file('chat.jsonl'));
 save('world-'+n+'.json',f.state);return {state:digest(f.state),events:digest(ev),messages:fresh.length};
}
async function visible(){
 const v=await dr.view({back:0});const controls=await p.evaluate(()=>[...document.querySelectorAll('#chat .mes:last-child button,#avereth-action-choices button,#avereth-action-targets button,#avereth-action-send,#avereth-action-choices summary,#avereth-action-mode')].filter(e=>e.checkVisibility()&&!e.disabled).map(e=>({label:e.innerText||e.title,id:e.id||undefined,data:{...e.dataset}})));
 const live={last:v.messages.at(-1),hud:v.hud,controls,toast:v.toasts};save('visible.json',live);return live;
}
await verify(0);await visible();save('response.json',{n:0,ready:true});
let seen=0;
for(;;){
 if(!fs.existsSync(file('command.json'))){await wait(180);continue;}
 const cmd=JSON.parse(fs.readFileSync(file('command.json')));if(cmd.seq<=seen){await wait(180);continue;}seen=cmd.seq;
 try{
 if(cmd.op==='end'){save('response.json',{seq:seen,closed:true});break;}
 if(cmd.note)journal('feedback.jsonl',{turn:counter,at:new Date().toISOString(),feedback:cmd.note});
 if(cmd.op==='view'){await visible();save('response.json',{seq:seen,ready:!blocked});continue;}
 if(blocked)throw Error('Campaign input locked');
 for(const sel of cmd.click||[])await p.locator(sel).filter({visible:true}).last().click({timeout:4000});
 if(cmd.mode)await p.selectOption('#avereth-action-mode',cmd.mode);
 if(cmd.op==='pick'){await visible();save('response.json',{seq:seen,picked:true});continue;}
 assert(cmd.op==='play'&&counter<50);
 assert(!(await dr.probe()).busy);const prev=await dr.chat();assert(await dr.verifySaved(prev,{complete:true}));
 await p.fill('#send_textarea',cmd.text||'');const button=p.locator(cmd.hud?'#avereth-action-send':'#send_but');assert(await button.isVisible());await p.evaluate(observeTurn,{index:prev.length+1});
 counter++;journal('actions.jsonl',{n:counter,...cmd,at:new Date().toISOString()});save('gate.json',{arm:'A',stage:'campaign',turn:counter});
 let ok=false;const t0=Date.now();await button.click({timeout:5000});
 for(let i=0;i<3500;i++){
  const ends=records().filter(x=>x.kind==='end'&&x.turn===counter);if(ends.some(x=>!x.ok))throw Error('Upstream stopped: '+JSON.stringify(ends.filter(x=>!x.ok).map(x=>[x.id,x.status,x.reason])));
  const x=await p.evaluate(len=>{const c=SillyTavern.getContext(),m=c.chat.at(-1);return {len:c.chat.length,answered:c.chat.length>=len+2&&!m?.is_user,ext:m?.extra?.avereth?.extraction?.status,status:document.querySelector('#avereth-action-status')?.textContent,world:window.abTurn?.world,system:m?.is_system||m?.extra?.avereth_panel,busy:!!document.querySelector('#mes_stop')?.checkVisibility(),panel:m?.extra?.avereth?.panel,viewReady:window.abTurn?.marks?.ready!=null};},prev.length);
  if(x.ext==='failed'||(!x.busy&&x.panel?.includes('Erzählung unvollständig'))||/Remoteabschluss unbekannt|Speichern fehlgeschlagen/.test(x.status||''))throw Error('Host stopped: '+JSON.stringify(x));
  if(x.answered&&!x.busy&&(x.world?.persisted&&x.ext==='applied'&&x.status==='Gespeichert'||!ends.some(e=>e.role==='narrator')&&(x.system||!x.ext)&&Date.now()-t0>1200)){
   if(await dr.verifySaved(await dr.chat(),{complete:true})&&!dr.pendingSaves.size){ok=true;break;}
  }
  await wait(250);
 }
 if(!ok)throw Error('Turn completion timeout');
 save('gate.json',{arm:null});const timing=await p.evaluate(()=>{let s=window.abTurn;s.stop();return {marks:s.marks,world:s.world,firstSentence:s.firstSentence};});
 const checked=await verify(counter);await visible();journal('turns.jsonl',{n:counter,timing,checked,elapsed:Date.now()-t0});save('response.json',{seq:seen,n:counter,complete:true});
 }catch(e){save('gate.json',{arm:null});blocked=fs.existsSync(file('actions.jsonl'))&&JSON.parse(fs.readFileSync(file('actions.jsonl'),'utf8').trim().split('\n').at(-1)).seq===seen;await visible().catch(()=>{});save('response.json',{seq:seen,error:e.message,blocked});}
}
}finally{save('gate.json',{arm:null});while(records().filter(r=>r.kind==='start').length>records().filter(r=>r.kind==='end').length)await wait(200);await browser.close();await server.stop();}
