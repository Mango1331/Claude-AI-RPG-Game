import assert from 'node:assert/strict';
import fs from 'node:fs';import {createHash} from 'node:crypto';
import {foldChat} from '/workspace/avereth-204/avereth-engine/src/host.js';
const root=(process.argv[2]||'/tmp/rpg204/live')+'/',lines=f=>fs.readFileSync(root+f,'utf8').trim().split('\n').map(JSON.parse);
const chat=lines('chat.jsonl').slice(1), turns=lines('turns.jsonl');
const hash=x=>createHash('sha256').update(JSON.stringify(x)).digest('hex');
assert.equal(turns.length,41);assert.equal(chat.filter(m=>m.is_user).length,41);
for(const {n,checked} of turns){
 const slice=chat.slice(0,checked.messages);const f=foldChat(slice);
 assert.deepEqual(f.errors,[]);assert.deepEqual(f.state,JSON.parse(fs.readFileSync(root+'world-'+n+'.json')));assert.equal(hash(f.state),checked.state);assert.equal(hash(slice.map(m=>m.extra?.avereth?.events||[])),checked.events);
}
const pending=lines('direct-before.jsonl').slice(1);const events=xs=>xs.map(m=>m.extra?.avereth?.events||[]);
assert.deepEqual(events(chat.slice(0,pending.length)),events(pending));assert.deepEqual(chat[pending.length-1].extra.avereth_action_input,pending.at(-1).extra.avereth_action_input);
console.log('41 historical prefix states and event sequence hashes match separate ST reloads. Quest input revision and events unchanged through recovery.');
