# Avereth Live-Test 20261027-030034Z-current_test

## Kurzfassung

- **Laufprofil:** guild-warrior; Startklasse Warrior, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** extractor_failed — turn 32: the World Extractor failed after story message 64; its world changes were not committed ($: unexpected property "thread")
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 2. Sicherheitsgrenzen: 150 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** noch nicht erreicht.
- **Charakter:** warrior (warrior.heavy_slash, warrior.guard) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: cautious adventurer: prepare and recover, weigh threats and withdraw when sensible
- **Züge:** 32 · **Dauer:** 26:53 min · **LLM-Aufrufe der Engine/des Erzählers:** 93
- **Auffälligkeiten:** 14
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.100 |
| Git | cadd5315862a (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 9.1 s |
| Browser | chrome 156.0.8078.48 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261027-030034Z-current_test“, Seed 1348926322 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | Warrior | Engine (Menü/Rückfrage) | creation_complete | Choose Warrior as base class. | public roadside verge outside Ashbridge | 90/84 | 2.1 s |
| 2 | I choose Heavy Slash and Guard. | Engine (Menü/Rückfrage) | creation_complete | Complete character creation with two starter skills. | public roadside verge outside Ashbridge | 95/84 | 2.1 s |
| 3 | I walk into Ashbridge and head for the Adventurers' Guild hall to register and look at the contract board. | Erzähler | open_run_level | Enter Ashbridge and reach the Guild hall to register and find a first contract. | Adventurers' Guild hall, Ashbridge | 95/84 | 75.6 s |
| 4 | I pay the clerk two silver to register with the Guild. | Erzähler | open_run_level | Register at the Guild for 2 silver to access contracts. | Adventurers' Guild hall, Ashbridge | 95/84 | 35.7 s |
| 5 | I take the Marsh Cat contract from the board and bring it to the clerk. "I'll take the tannery job. Please make it active." | Erzähler | open_run_level | Accept the Marsh Cat contract and have the clerk activate it. | Adventurers' Guild hall, Ashbridge | 95/84 | 73.0 s |
| 6 | I head to soak-row and look for Hessa Vull's tannery to ask about the marsh cat. | Erzähler | open_run_level | Visit the client at the tannery for information before hunting the cat. | the tannery yards and ditch banks of soak-row | 95/84 | 33.0 s |
| 7 | "I'm after it now. Anything I should know—where it's been slipping in, or what it left behind?" | Erzähler | open_run_level | Ask Hessa Vull for details on the marsh cat before hunting it in the reed beds. | the tannery yards and ditch banks of soak-row | 95/84 | 51.5 s |
| 8 | I head east along the ditches into the reed beds and search carefully for the cat's lair, watching for worn trails, prints, or cheek-marked … | Erzähler | open_run_level | Track the marsh cat to its lair in the reed beds. | reed beds east along the soak-row ditches | 95/84 | 20.6 s |
| 9 | I draw my sword and follow the worn trail into the reeds slowly, Guard ready, keeping my weight on the firmer ground at the trail's edges. | Erzähler | open_run_level | Stalk the marsh cat along its worn trail with sword drawn and Guard ready. | reed beds east along the soak-row ditches | 95/84 | 17.8 s |
| 10 | I follow the worn trail into the reeds, staying on the firmer ground at its edges. | Erzähler | open_run_level | Track the marsh cat along its worn trail into the reed beds. | the marsh cat's lay-up hummock | 95/84 | 46.2 s |
| 11 | I face the marsh cat and attack it with Heavy Slash as soon as it comes into reach. | Erzähler | open_run_level | Engage the marsh cat with Heavy Slash. | the marsh cat's lay-up hummock | 95/84 | 24.1 s |
| 12 | I close the distance to the marsh cat, advancing to engage it at melee range with my sword ready. | Erzähler | open_run_level | Close from SHORT to ENGAGED so I can attack the marsh cat next turn. | the marsh cat's lay-up hummock | 95/84 | 15.7 s |
| 13 | I meet the leaping cat with Heavy Slash, swinging at its body as it comes in under my blade. | Erzähler | open_run_level | Attack the ENGAGED marsh cat with Heavy Slash as it leaps. | the marsh cat's lay-up hummock | 83/84 | 28.8 s |
| 14 | I strike at the wounded marsh cat with a Basic Attack before it can lunge again. | Erzähler | open_run_level | Kill the 9-HP marsh cat with a cheaper Basic Attack instead of Heavy Slash. | the marsh cat's lay-up hummock | 83/84 | 39.2 s |
| 15 | I check the contract slip to confirm whether this cat counts toward the cull, then head back toward the tannery soak-rows. | Erzähler | open_run_level | Verify kill counts toward contract and return to the tannery area for the next cat. | the tannery yards and ditch banks of soak-row | 83/84 | 29.4 s |
| 16 | I greet Hessa Vull and ask her where the remaining marsh cats have been prowling, mentioning I've just killed one out in the reeds. | Erzähler | open_run_level | Ask Hessa for the location of more cats to continue the cull contract. | the tannery yards and ditch banks of soak-row | 83/84 | 37.8 s |
| 17 | #quest Cull the Marsh Cats Prowling the Tannery Yards | System (Befehl) | open_run_level | Inspect the quest panel to learn why my confirmed kill still shows 0/1 on the cull contrac… | the tannery yards and ditch banks of soak-row | 83/84 | 2.2 s |
| 18 | I walk down the soak-row showing the marsh-cat pelt and claw to the workers as Hessa suggested, letting them see the scarred beast is dead. | Erzähler | open_run_level | Show proof of the kill down the row to build goodwill and possibly resolve the contract's … | the tannery yards and ditch banks of soak-row | 83/84 | 203.4 s |
| 19 | "It fought hard — I killed a marsh cat out in the reeds and this hide is torn from it. If the scarred one still lives, I'll go back and fini… | Erzähler | open_run_level | Answer Genn honestly and commit to hunting the scarred cat if it survives. | the tannery yards and ditch banks of soak-row | 83/84 | 23.4 s |
| 20 | I drink the hot mug Tam offered, then guide Genn along the stile path to the hollow and show her the full marsh cat carcass so she can judge… | Erzähler | open_run_level | Recover with the offered drink, then let Genn inspect the carcass to verify whether my kil… | the hollow off the stile path | 83/84 | 28.1 s |
| 21 | I ask Genn to skin and take the young cat's pelt as proof of the kill, then follow her directions toward the third stile to track the scarre… | Erzähler | open_run_level | Harvest proof from the cub kill, then hunt the actual scarred target past the third stile. | the third stile | 83/84 | 37.8 s |
| 22 | I draw my longsword and hold ready at the stile, watching the run for the cat to come out rather than going in after it. | Erzähler | open_run_level | Fight the scarred marsh cat defensively as it emerges from the reeds. | the third stile | 83/84 | 18.2 s |
| 23 | I brace behind my sword with Guard as the scarred cat charges, letting it come onto my blade at the stile. | Erzähler | open_run_level | Defend against the charge rather than meeting it in the open. | the third stile | 83/84 | 19.9 s |
| 24 | I drive the longsword up into the cat's chest as it lands on my blade, then shove it off and step back along the stile. | Erzähler | open_run_level | Meet the charge with a braced counter-thrust and keep my footing. | the third stile | 65/84 | 21.5 s |
| 25 | I use Guard to blunt its next lunge, then answer with a Heavy Slash the moment my turn comes. | Erzähler | open_run_level | Defend against the wounded cat's next attack, then counter with Heavy Slash. | the third stile | 63/84 | 23.0 s |
| 26 | I finish it with a Heavy Slash at the dying cat. | Erzähler | open_run_level | Kill the scarred marsh cat with Heavy Slash. | the third stile | 63/84 | 17.2 s |
| 27 | #assign STR 2 VIT 2 WIL 1 | System (Befehl) | open_run_level | Spend the 5 level-up stat points, then return to the tannery with the kill. | the third stile | 63/84 | 2.2 s |
| 28 | I take the pelt, claws and fangs from the dead cat and head back to the tannery yards to report the scarred marsh cat's kill. | Erzähler | open_run_level | Loot confirmed and return to the tannery for the contract turn-in. | the tannery yards and ditch banks of soak-row | 63/84 | 146.2 s |
| 29 | "It's dead. Here's the pelt, claws and fangs as proof." | Erzähler | open_run_level | Report the scarred marsh cat's kill to Hessa Vull with the trophies as proof. | the tannery yards and ditch banks of soak-row | 63/84 | 42.8 s |
| 30 | "Twenty-five, yes. But the kill's mine either way — I'll take you up on that kettle, and a word from you to the Guild clerk would help, sinc… | Erzähler | open_run_level | Accept Hessa's offer to treat the wound and secure her testimony for the Guild turn-in. | the tannery yards and ditch banks of soak-row | 63/84 | 18.6 s |
| 31 | "Nothing else, thank you. I'll head back to the Guild hall now to report the kill." | Erzähler | open_run_level | Leave the tannery and return to the Guild hall to turn in the marsh cat contract with Hess… | Adventurers' Guild hall, Ashbridge | 63/84 | 89.4 s |
| 32 | "I killed the scarred old marsh cat at the third stile — here's the pelt, claws and fangs, and Hessa Vull at the tannery yards will vouch fo… |  | open_run_level | Report the confirmed kill to the clerk with trophies and Hessa's testimony to complete the… | Adventurers' Guild hall, Ashbridge | 63/84 | 82.5 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zum Start (notiert vor Zug 1): Character creation step 1/2 shown; five silver and traveler's clothes confirmed.
- zu Zug 1 (notiert vor Zug 2): Stats confirmed after Warrior pick: STR 8, VIT 8, starter gear promised on completion.
- zu Zug 2 (notiert vor Zug 3): Creation complete: Level 1 Warrior with Heavy Slash and Guard, starter sword and armor equipped, 5 silver on hand.
- zu Zug 3 (notiert vor Zug 4): Registration fee is 2 silver (shop panel lists 20 cp — contradiction to check after paying). Novice board has a likely first job: Marsh Cat at the tannery, 25 cp.
- zu Zug 4 (notiert vor Zug 5): Registration completed for 20 cp (HUD shows 3 Silver); Guild plate and slip book received, F-rank confirmed. Marsh Cat contract pays 25 cp — suitable first solo job.
- zu Zug 5 (notiert vor Zug 6): Contract confirmed active in HUD; clerk says the cat lairs in reed beds by day, yards at dusk.
- zu Zug 6 (notiert vor Zug 7): Contract confirmed active, 0/1 defeated; clerk says the cat lairs in reed beds by day and hunts the yards at dusk.
- zu Zug 7 (notiert vor Zug 8): Hessa confirmed entry route over the ditch bank and pointed to the reed beds east; warned about knee-deep mud.
- zu Zug 8 (notiert vor Zug 9): Arrival pending resolved: at the reed beds, fresh trail and cheek-marked post found; wind is in my face and a moorhen went silent nearby, so the cat may be close.
- zu Zug 9 (notiert vor Zug 10): Engine resolves one action per message; drawing the sword was taken but following the trail was refused, so I repeat the follow alone with sword already drawn.
- zu Zug 10 (notiert vor Zug 11): Marsh Cat A is in active scene, HP 42/42, SHORT with partial cover; it is cutting off my retreat toward the ditch bank.
- zu Zug 11 (notiert vor Zug 12): Heavy Slash was refused: the cat stands at SHORT, beyond the skill's ENGAGED reach, so I must declare movement to close first. The cat is blocking my retreat toward the ditch bank.
- zu Zug 12 (notiert vor Zug 13): Movement succeeded: cat now ENGAGED and mid-leap at my sword-side forearm; first real attack chance.
- zu Zug 13 (notiert vor Zug 14): First Strike Heavy Slash did 33 damage; cat at 9/42 but still bit my forearm and raked my hip for 12 total. Basic Attack (22-26) suffices to finish it and saves STA.
- zu Zug 14 (notiert vor Zug 15): Marsh Cat A defeated for 72 XP; quest panel still shows 0/1 defeated, so I check the slip to confirm counting. HP 83/95, STA 88/100 — manageable.
- zu Zug 15 (notiert vor Zug 16): Cat killed and looted, but quest panel still reads 0/1 defeated despite COMBAT END crediting the kill; possible counting delay or bug. HP 83/95, lightly wounded, armor strap scored.
- zu Zug 16 (notiert vor Zug 17): Hessa confirms the cat I killed is the scarred one that raided the tannery, yet the quest counter still reads 0/1 — either a counting bug or the kill needs verification. She offers a walk down the row to show proof for worker goodwill.
- zu Zug 17 (notiert vor Zug 18): Quest panel now logs the den find as done but kill counter still 0/1; Hessa points to Guild slip as the payment channel and suggests showing the row the kill.
- zu Zug 18 (notiert vor Zug 19): Genn says the torn, clean-furred hide strip proves no beast dead — the scarred cat may still live despite the confirmed 72-XP kill; quest counter still 0/1. Possible mismatch between combat result and quest tracking.
- zu Zug 19 (notiert vor Zug 20): Genn's hide reading (torn, clean-furred, no scars) matches the System's 0/1 counter: my confirmed 72-XP kill was likely a different cat and the scarred target probably lives. Dogs are quiet and workers are betting coppers on the outcome.
- zu Zug 20 (notiert vor Zug 21): Confirmed: my 72-XP kill was a first-year cub, not the scarred contract target, which likely dens past the third stile. XP 72/100, HP 83/95 — nearing level but still lightly wounded.
- zu Zug 21 (notiert vor Zug 22): Breathing beast confirmed in the reed den past the third stile; Genn warned it attacks sideways from cover. HP 83/95, near level-up at 72/100 XP.
- zu Zug 22 (notiert vor Zug 23): Scarred marsh cat confirmed alive and hostile at 50 HP, matching the 0/1 counter; it is gathering to charge.
- zu Zug 24 (notiert vor Zug 25): Combat is systematic now: cat at 25/50, me at 65 HP, Heavy Slash 28-34 should finish it. Guard first since the cat acts before me in turn order.
- zu Zug 25 (notiert vor Zug 26): Guard blunted the last lunge to 2 damage; cat at 25 HP, Heavy Slash 28-34 should end it.
- zu Zug 26 (notiert vor Zug 27): Scarred cat defeated (+88 XP, Level 2, loot gained), but quest counter still shows 0/1 — may need proof or a proper turn-in at the tannery/Guild. HUD now shows HP 63/105.
- zu Zug 27 (notiert vor Zug 28): Level 2 confirmed, stats assigned; loot (pelt, claws, fangs) gained. Quest counter still shows 0/1, so the kill likely needs reporting at the tannery or Guild.
- zu Zug 28 (notiert vor Zug 29): Quest counter still shows 0/1 despite the confirmed kill; turn-in or proof presentation may be needed to update it.
- zu Zug 29 (notiert vor Zug 30): Hessa confirmed the kill but gave the trophies back to sell; quest counter still shows 0/1, so the turn-in must happen at the Guild hall. She offers wound treatment and formal testimony.
- zu Zug 30 (notiert vor Zug 31): Wound treated at the tannery (HP 63/115, told two days easy). Hessa gave plain testimony for the Guild clerk; quest counter still shows 0/1, so the official turn-in must happen at the Guild hall.
- zu Zug 31 (notiert vor Zug 32): Turn-in was refused once because the outcome isn't established in the world; hoping testimony plus trophies satisfies the clerk now.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t13 | 13 | 1 | – | nein | 1 | gewonnen, 72 XP |
| enc.t23 | 24 | 1 | – | nein | 1 | gewonnen, 88 XP |

## Quests

- **Cull the Marsh Cats Prowling the Tannery Yards** — active (Zug 5)
  - Aufgabe: Hunt down the single marsh cat that has been slipping into the tannery yards at night and killing the curing dogs.
  - Endzustand: The marsh cat that raided the tannery yards is dealt with and the curing dogs are safe.

## Auffälligkeiten

- Zug 4, Nachricht 7 (planner_repaired): the planner's first answer needed a repair
- Zug 16, Nachricht 32 (extraction_repaired): the extractor's first answer needed a repair
- Zug 18, Nachricht 36 (extraction_repaired): the extractor's first answer needed a repair
- Zug 18, Nachricht 36 (finish): extract ended with finish_reason "length"
- Zug 21, Nachricht 42 (extraction_repaired): the extractor's first answer needed a repair
- Zug 28, Nachricht 56 (extraction_repaired): the extractor's first answer needed a repair
- Zug 28, Nachricht 56 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 28, Nachricht 56 (finish): extract ended with finish_reason "length"
- Zug 28, Nachricht 56 (finish): extract_repair ended with finish_reason "length"
- Zug 31, Nachricht 62 (extraction_repaired): the extractor's first answer needed a repair
- Zug 31, Nachricht 62 (finish): extract ended with finish_reason "length"
- Zug 32, Nachricht 64 (extraction_failed): the extractor failed: $: unexpected property "thread"
- Zug 32, Nachricht 64 (extraction_repaired): the extractor's first answer needed a repair
- Zug 32, Nachricht 64 (finish): extract ended with finish_reason "length"
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 6× keine gültige JSON-Entscheidung (Züge 7, 8, 18, 22, 24, 32)
- 5 Aufruf(e) mit finish_reason "length" (Nr. 48 extract, Nr. 77 extract, Nr. 78 extract, Nr. 88 extract, Nr. 92 extract)

System-Panels: CLARIFY 0, NOT TAKEN 2, REFUSED 1, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: guild_canon 3, engine_booked 2, ambient 2, attack_commitment 3, world_rule 3, quest_dependency 2, quest_count 4, engine_owned_combat 1, engine_owned_fact 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 1, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 29 | 1 | 2.9 s | 6.7 s | 11636 | 9751 | 81 | – | stop 29 | 0 |
| board | 1 | 0 | 40.8 s | 40.8 s | 2356 | 0 | 1436 | – | stop 1 | 0 |
| narrator | 28 | 0 | 11.8 s | 23.5 s | 11379 | 8724 | 464 | – | stop 28 | 0 |
| extract | 35 | 2 | 7.2 s | 51.3 s | 11347 | 8968 | 405 | – | stop 30, length 5 | 5 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 26:53 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 9.1 s) | 0:22 min |
| 32 Züge, Spiel (Senden bis HUD nach der Extraktion) | 21:49 min — Median 28.4 s, p90 82.5 s, max 203.4 s |
| 32 Züge, Spieler-Entscheidung | 4:17 min — Median 4.2 s, 6 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 1:53 min / 0:41 min / 8:54 min / 9:14 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 48.9 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 32:37 min, 80 Züge ≈ 65:15 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spieler | 14 | – | 40.1 s | 4.2 s |
| Spieler | 17 | – | 31.8 s | 4.2 s |
| Spiel | 18 | – | 203.4 s | 28.4 s |
| Spiel | 28 | – | 146.2 s | 28.4 s |
| Spiel | 31 | – | 89.4 s | 28.4 s |
| Provider narrator | 18 | 47 | 139.8 s | 11.8 s |
| Provider narrator | 5 | 10 | 57.3 s | 11.8 s |
| Provider extract | 28 | 78 | 61.7 s | 7.2 s |
| Provider extract | 31 | 88 | 60.7 s | 7.2 s |
| Provider extract | 28 | 77 | 56.3 s | 7.2 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
