# Avereth Live-Test 20261027-032730Z-current_test

## Kurzfassung

- **Laufprofil:** guild-mage; Startklasse Mage, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** abgebrochen: leere Erzählerantwort in einem Story-Zug (kein Swipe, kein Regenerieren) — turn 96: the narrator's reply has no story text (message 192) — the narrator call ended with finish_reason "length" after 8192 completion tokens (max 8192), 35293 characters of reasoning, 0 of text
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 5. Sicherheitsgrenzen: 150 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** noch nicht erreicht.
- **Charakter:** mage (mage.arcane_bolt, mage.arcane_ward) · Regelstand 2 (Warrior, Mage, Rogue)
- **Ziel-Dungeon:** Old Crown Catacombs, Ebene 1 (Vertrag quest.clear_old_crown_catacombs_level_1)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: pragmatic adventurer: sell surplus loot and invest in useful equipment and techniques
- **Züge:** 96 · **Dauer:** 62:38 min · **LLM-Aufrufe der Engine/des Erzählers:** 265
- **Auffälligkeiten:** 24
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.100 |
| Git | cadd5315862a (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 14.3 s |
| Browser | chrome 156.0.8078.48 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261027-032730Z-current_test“, Seed 1348926323 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | Mage | Engine (Menü/Rückfrage) | creation_complete | Choose Mage as base class. | public roadside verge outside Alderwatch | 90/84 | 2.3 s |
| 2 | I choose Arcane Bolt and Arcane Ward. | Engine (Menü/Rückfrage) | creation_complete | Pick two starter skills and finish Mage creation. | public roadside verge outside Alderwatch | 90/96 | 2.2 s |
| 3 | I walk into Alderwatch and head for the Adventurers' Guild hall to look at the contract board. | Erzähler | open_run_level | Enter the city and find Guild contracts suitable for a Level-1 Mage. | Adventurers' Guild hall, Alderwatch | 90/96 | 51.1 s |
| 4 | "I'd like to register with the Guild, please. I'm a new mage looking for novice contracts." | Erzähler | open_run_level | Register at the Guild, then take a suitable novice contract. | Adventurers' Guild hall, Alderwatch | 90/96 | 35.4 s |
| 5 | "Two silver, here." I hand over the coins, give my name as Alaric, and press my hand to the measuring stone. Once registered, I take the Orc… | Erzähler | open_run_level | Pay the two-silver fee, register with the Guild, and accept the novice wolf cull contract. | Adventurers' Guild hall, Alderwatch | 90/96 | 22.2 s |
| 6 | I leave the Guild hall, head out through the south gate, and ask a carter to point me toward Bram Tull's orchard. | Erzähler | open_run_level | Travel to the orchard to hunt the yearling wolf. | Tull orchard rows | 90/96 | 167.7 s |
| 7 | I call out to the farmer: "Morning! I'm Alaric from the Guild — I've taken the contract to cull the yearling wolf troubling your orchard. Wh… | Erzähler | open_run_level | Talk to the farmer about the wolf contract instead of fighting his dogs. | Tull orchard rows | 90/96 | 13.5 s |
| 8 | I hold up the contract slip so he can read the seal. "Here — seal and my Guild plate, if you want to see both." | Erzähler | open_run_level | Show the farmer the sealed contract slip and Guild plate to prove I'm from the Guild. | Tull orchard rows | 90/96 | 19.0 s |
| 9 | "Smarter than sitting still, aye. I'll try bait — scatter a pile of windfall apples in the open rows near the creek, downwind of where I'll … | Erzähler | open_run_level | Propose a bait-and-ambush plan and ask the farmer where the wolf feeds heaviest. | Tull orchard rows | 90/96 | 27.7 s |
| 10 | I gather the soft brown windfall apples into a pile in the open grass where the wolf feeds, then settle into hiding up the slope toward the … | Erzähler | open_run_level | Set the bait pile and hide downwind to ambush the wolf at dusk. | Tull orchard rows | 90/96 | 29.9 s |
| 11 | "Aye, call them off, please. Then I'll set the bait pile and come back to hide once they're quiet." | Erzähler | open_run_level | Get the farmer to call off the dogs so the ambush isn't spoiled. | Tull orchard rows | 90/96 | 33.4 s |
| 12 | I stay hidden behind the hedge and keep watching the bait pile and the scrub until the wolf comes out or dusk falls. | Erzähler | open_run_level | Wait in ambush for the wolf at the bait pile. | Tull orchard rows | 90/96 | 18.3 s |
| 13 | I stay hidden behind the hedge and keep watching the bait pile and the creek scrub for the wolf. | Erzähler | open_run_level | Continue the ambush until dusk, when the farmer said the wolf feeds. | Tull orchard rows | 90/96 | 32.2 s |
| 14 | I cast Arcane Bolt at the wolf. | Erzähler | open_run_level | Open the ambush attack on the wolf with Arcane Bolt. | Tull orchard rows | 90/96 | 20.1 s |
| 15 | I sneak down the slope toward the wolf to close into Arcane Bolt range, then cast Arcane Bolt at it. | Erzähler | open_run_level | Close to MEDIUM range and open the attack on the wolf. | Tull orchard rows | 90/96 | 21.2 s |
| 16 | I move down the open slope toward the wolf until it is at MEDIUM range, using the creek's noise to cover my steps. | Erzähler | open_run_level | Close the distance to MEDIUM range so Arcane Bolt can reach the wolf. | Tull orchard rows | 90/96 | 27.3 s |
| 17 | I cast Arcane Bolt at the wolf. | Erzähler | open_run_level | Open the attack on the yearling wolf now that it is at MEDIUM range. | Tull orchard rows | 90/86 | 16.7 s |
| 18 | I take the wolf pelt and fangs, then walk back to Alderwatch and head to the Guild hall to turn in the Cull the Orchard Row Wolf contract. | Erzähler | open_run_level | Return to Alderwatch and turn in the completed wolf contract at the Guild hall. | Adventurers' Guild hall, Alderwatch | 90/86 | 24.9 s |
| 19 | "What else is on the board tonight? I'm looking for another novice contract, ideally something I can finish before it gets too late." | Erzähler | open_run_level | Ask the clerk for another achievable Novice contract from the Guild board. | Adventurers' Guild hall, Alderwatch | 90/86 | 29.9 s |
| 20 | "I'll take the Reed Flat Striders contract." | Erzähler | open_run_level | Accept the Reed Flat Striders contract from the clerk. | Adventurers' Guild hall, Alderwatch | 90/86 | 16.1 s |
| 21 | "I'm off to the flats. Thanks." | Erzähler | open_run_level | Leave the Guild and head south to the Reed Flats to hunt striders. | eel-weirs of the Reed Flats | 90/86 | 30.4 s |
| 22 | "I'm from the Alderwatch Guild — I've taken the strider cull contract for the cooperative. Which way to the weirs where they've been spookin… | Erzähler | open_run_level | Identify myself to the fishermen and ask where the striders are. | eel-weirs of the Reed Flats | 90/86 | 34.3 s |
| 23 | I head out along the middle weir walkway toward the deep pool, staff ready, listening for the clicking. | Erzähler | open_run_level | Move onto the middle weir to hunt the striders feeding at the pool. | eel-weirs of the Reed Flats | 90/86 | 80.1 s |
| 24 | I cast Arcane Bolt at the nearer strider standing on the weir crest. | Erzähler | open_run_level | Engage the bog striders on the middle weir to advance the cull contract. | eel-weirs of the Reed Flats | 90/86 | 17.2 s |
| 25 | I give ground back along the plank walkway to draw the strider onto the narrow planks, then cast Arcane Bolt at it once it comes within reac… | Erzähler | open_run_level | Fall back to narrow footing so the strider enters Arcane Bolt's MEDIUM range, then attack … | eel-weirs of the Reed Flats | 90/76 | 25.2 s |
| 26 | I cast Arcane Bolt at Bog Strider A to finish it. | Erzähler | open_run_level | Kill the wounded strider A with Arcane Bolt. | eel-weirs of the Reed Flats | 90/66 | 22.8 s |
| 27 | I cast Arcane Bolt at Bog Strider B. | Erzähler | open_run_level | Kill strider B at short range with Arcane Bolt. | eel-weirs of the Reed Flats | 74/56 | 17.2 s |
| 28 | I cast Arcane Bolt at Bog Strider B point-blank to finish it. | Erzähler | open_run_level | Kill the wounded strider B at ENGAGED range before it bites again. | eel-weirs of the Reed Flats | 74/46 | 75.9 s |
| 29 | "Both of 'em done," I call back, then #assign INT 3 WIL 2 VIT 2 PER 3 | Erzähler | open_run_level | Confirm the kills to Dorna and spend the 10 free stat points. | eel-weirs of the Reed Flats | 74/46 | 24.3 s |
| 30 | #assign INT 3 WIL 2 VIT 2 PER 3 | System (Befehl) | open_run_level | Spend the 10 free stat points, since the HUD still shows them unspent. | eel-weirs of the Reed Flats | 74/46 | 2.2 s |
| 31 | "Two more to finish, and I'd rather not let 'em settle in," I say, and push on along the walkway toward the right-bank reeds, keeping to the… | Erzähler | open_run_level | Continue the strider cull contract toward the remaining two kills despite the fisherman's … | eel-weirs of the Reed Flats | 74/46 | 28.0 s |
| 32 | I pick up a loose stone from the crest and hurl it at the long shape under the reeds, ready to step back out of reach. | Engine (Menü/Rückfrage) | open_run_level | Provoke a reaction from the motionless shape at range without closing or spending MP. | eel-weirs of the Reed Flats | 74/46 | 11.4 s |
| 33 | I advance slowly toward the fresh drag mark, staff ready, watching the motionless shape under the reeds for any movement. | Erzähler | open_run_level | Close with the reed-bed shape to provoke or identify it as the third strider. | drag mark by the reed hummock | 74/46 | 27.9 s |
| 34 | I cast Arcane Bolt at Bog Strider C. | Erzähler | open_run_level | Strike the bracing strider from SHORT range before it can close or charge. | drag mark by the reed hummock | 74/36 | 31.0 s |
| 35 | I push on past the hummock, following the waterline toward where the clicking came from, staff up and watching the reeds. | Erzähler | open_run_level | Hunt the fourth strider to finish the cull contract. | drag mark by the reed hummock | 74/36 | 23.4 s |
| 36 | I cast Arcane Bolt at Bog Strider D while it stands at the flat's far edge. | Erzähler | open_run_level | Take the fourth strider with a ranged First-Strike bolt before it can charge across the op… | drag mark by the reed hummock | 74/26 | 17.3 s |
| 37 | I start the walk back along the waterline toward the first weir and the fisherman's lantern, keeping to firm silt and watching the reeds. | Erzähler | open_run_level | Return off the flats toward the first weir to report the cull complete, then rest and turn… | eel-weirs of the Reed Flats | 74/26 | 55.0 s |
| 38 | I tell Dorna the four striders are dead — two past the second weir, one at the drag mark, one on the big flat — and that the boats can launc… | Erzähler | open_run_level | Report the cull complete to the bookkeeper and arrange overnight lodging before the Guild … | eel-weirs of the Reed Flats | 74/26 | 36.5 s |
| 39 | I take the blanket, settle onto the straw pallet in the net shed, and sleep until morning. | Erzähler | open_run_level | Recover overnight at the offered lodging before the Guild turn-in. | eel-weirs of the Reed Flats | 110/152 | 39.6 s |
| 40 | I thank Ben for the tea and set out on the road to Alderwatch, walking to the Guild hall to turn in the strider contract. | Erzähler | open_run_level | Travel to Alderwatch and turn in the completed cull contract at the Guild hall. | Adventurers' Guild hall, Alderwatch | 110/152 | 24.7 s |
| 41 | I hand the clerk the contract slip, the six chitin plates and the venom gland as proof, and tell him all four striders are dead — ask him to… | Erzähler | open_run_level | Establish the contract outcome as achieved at the Guild counter with physical proof, then … | Adventurers' Guild hall, Alderwatch | 110/152 | 121.2 s |
| 42 | I sell nothing at the counter, tuck the plates and gland away, and head back out the south road to Reed Flat to hunt the two striders the se… | Erzähler | open_run_level | Return to the flats and finish the remaining two strider kills so the contract seal turns … | eel-weirs of the Reed Flats | 110/152 | 19.1 s |
| 43 | I ask Dorna exactly where the boat crew saw the churned mud and the strider — the middle weir and out past the pot lines. | Erzähler | open_run_level | Get the precise location of the remaining striders from Dorna before hunting them. | eel-weirs of the Reed Flats | 110/152 | 24.1 s |
| 44 | I set out past the middle weir into the deep channel, following the churned mud and paired prints to hunt the two remaining striders. | Erzähler | open_run_level | Hunt the two remaining striders in the deep channel past the middle weir. | deep channel past the middle weir | 110/152 | 46.3 s |
| 45 | I wade quietly closer using the pot stakes as cover, then cast Arcane Bolt at the still strider. | Erzähler | open_run_level | Ambush the paired striders from cover, opening on the stationary one. | deep channel past the middle weir | 110/152 | 23.4 s |
| 46 | I creep further along the stake line until the still strider is within Arcane Bolt's range, then cast Arcane Bolt at Bog Strider F. | Erzähler | open_run_level | Close to MEDIUM range under cover, then open combat on the still strider. | deep channel past the middle weir | 110/142 | 26.7 s |
| 47 | I cast Arcane Bolt at the approaching Bog Strider E. | Erzähler | open_run_level | Kill the last strider while it approaches at SHORT range to complete the 4/4 contract. | deep channel past the middle weir | 110/132 | 65.1 s |
| 48 | I collect the loose chitin plates and venom gland from the two dead striders, then wade back to the middle weir and check the contract slip'… | Erzähler | open_run_level | Collect loot and return to check whether the strider contract seal now reads achieved at 4… | middle weir platform | 110/132 | 53.8 s |
| 49 | #quest Cull the Reed Flat Striders | System (Befehl) | open_run_level | Inspect the quest panel to see whether the strider kills were recorded against the 2/4 cou… | middle weir platform | 110/132 | 2.2 s |
| 50 | #audit | System (Befehl) | open_run_level | Check the audit log to see why the two latest strider kills were not recorded against the … | middle weir platform | 110/132 | 2.2 s |
| 51 | I scan the reeds and channels from the middle weir platform, then follow the churned mud along the pot lines toward the third weir, keeping … | Erzähler | open_run_level | Continue the cull: the audit shows the quest counter is authoritative at 2/4, so two more … | middle weir platform | 110/132 | 76.4 s |
| 52 | I cast Arcane Bolt at the feeding Bog Strider G, aiming for an ambush strike while it's distracted. | Erzähler | open_run_level | Ambush the feeding strider at SHORT range with Arcane Bolt. | middle weir platform | 110/122 | 23.7 s |
| 53 | #assign INT 2 WIL 2 PER 1 | System (Befehl) | open_run_level | Spend the five level-up stat points. | middle weir platform | 110/122 | 2.2 s |
| 54 | I search the flats around the third weir for the last strider, staying low along the channels and watching the churned mud for fresh tracks. | Erzähler | open_run_level | Hunt the fourth and final strider to complete the cull contract. | middle weir platform | 110/122 | 19.6 s |
| 55 | I follow the fresh tracks toward the stand of dead snags, keeping low in the reeds and watching for the last strider. | Erzähler | open_run_level | Track and ambush the fourth strider to finish the cull contract. | stand of dead snags | 110/122 | 46.2 s |
| 56 | I cast Arcane Bolt at Bog Strider H before it can flee. | Erzähler | open_run_level | Kill the fourth strider with a quick strike to complete the cull contract. | stand of dead snags | 110/112 | 28.2 s |
| 57 | #quest Cull the Reed Flat Striders | System (Befehl) | open_run_level | Verify the cull contract counter registered the fourth kill. | stand of dead snags | 110/112 | 2.2 s |
| 58 | #audit | System (Befehl) | open_run_level | Check the audit log to see whether the fourth strider kill was recorded toward the cull co… | stand of dead snags | 110/112 | 2.2 s |
| 59 | I scan the channels around the middle weir for another bog strider, following the churned mud along the pot lines. | Erzähler | open_run_level | Find and kill a strider that the engine will actually count as the fourth. | stand of dead snags | 110/112 | 26.8 s |
| 60 | I head back to Dorna's barrel at the eel-weirs and ask where the remaining bog striders were last seen. | Erzähler | open_run_level | Get fresh strider locations from Dorna since tracking by mud failed. | eel-weirs of the Reed Flats | 110/112 | 36.0 s |
| 61 | I take the tea and head out past the third weir line toward the deep channels, looking for the big strider Ben saw. | Erzähler | open_run_level | Hunt the fourth strider in the deep channels past the third weir before dark. | deep channels past the third weir line | 110/112 | 30.4 s |
| 62 | I cast Arcane Bolt at Bog Strider I while it's still unaware. | Erzähler | open_run_level | Strike the big strider first before it reacts, to register the fourth and final kill. | deep channels past the third weir line | 110/112 | 14.6 s |
| 63 | I move along the reed corridor's bank to close inside Medium range of Bog Strider I, keeping low and quiet. | Erzähler | open_run_level | Close to Medium range so Arcane Bolt can reach the strider. | deep channels past the third weir line | 110/112 | 32.2 s |
| 64 | I cast Arcane Bolt at Bog Strider I. | Erzähler | open_run_level | Strike the fourth and final strider now that it's in Medium range. | deep channels past the third weir line | 110/102 | 16.2 s |
| 65 | #quest Cull the Reed Flat Striders | System (Befehl) | open_run_level | Verify whether the fourth strider kill registered on the quest counter. | deep channels past the third weir line | 110/102 | 2.2 s |
| 66 | I head back along the reed corridor to dry ground and travel to the Guild hall, where I turn in the completed strider cull contract. | Erzähler | open_run_level | Return from the deep channels and turn in the four-strider cull at the Guild hall. | Adventurers' Guild hall, Alderwatch | 110/102 | 60.2 s |
| 67 | "The fourth was the big one out past the third weir — killed it at dusk, first bolt took it. Please check the seal again and mark the contra… | Erzähler | open_run_level | Re-attempt the strider cull turn-in, citing the fourth kill, since the System refused it w… | Adventurers' Guild hall, Alderwatch | 110/102 | 41.7 s |
| 68 | I sit by the hearth, buy a mug of hot tea from the clerk, and wait an hour for the seal to turn. | Erzähler | open_run_level | Wait at the Guild hearth as suggested so the contract seal can turn, then retry the turn-i… | Adventurers' Guild hall, Alderwatch | 110/102 | 32.7 s |
| 69 | I buy the novice bunk for a copper and sleep until first light, then check the contract's status. | Erzähler | open_run_level | Sleep at the Guild and re-check the quest counter in the morning. | Adventurers' Guild hall, Alderwatch | 115/188 | 36.0 s |
| 70 | I take the contract slip and head back out to the Reed Flats at first light to hunt the strider that's still walking — checking the reed cha… | Erzähler | open_run_level | Hunt the uncounted fourth strider on the Flats so the seal can turn. | eel-weirs of the Reed Flats | 115/188 | 49.5 s |
| 71 | "Morning. Dorna, is it? I'm on the Guild cull contract for the striders — a fourth one may still be walking these channels. Have you or your… | Erzähler | open_run_level | Ask Dorna and the fisherman where the last strider is so I can finish the cull. | eel-weirs of the Reed Flats | 115/188 | 20.7 s |
| 72 | I thank Dorna and follow the causeway line out past the last weir toward the deep channels, keeping watch for the strider. | Erzähler | open_run_level | Hunt the uncounted fourth strider in the deep channels past the last weir. | eel-weirs of the Reed Flats | 115/188 | 37.1 s |
| 73 | I follow the fresh webbed track out along the causeway toward the deep channels, staff ready, keeping low and watching the water for the str… | Erzähler | open_run_level | Hunt the uncounted fourth strider following its fresh track into the deep channels. | deep channels past the third weir line | 115/188 | 30.3 s |
| 74 | I cast Arcane Bolt at the strider as it crosses the open mud toward the causeway. | Erzähler | open_run_level | Engage the fourth strider at range to complete the cull count. | deep channels past the third weir line | 115/178 | 33.1 s |
| 75 | I check #quest Cull the Reed Flat Striders to confirm the kill count, then head back along the causeway toward the Guild hall. | Erzähler | open_run_level | Verify the cull count updated, then return to the Guild for the turn-in. | Adventurers' Guild hall, Alderwatch | 115/178 | 95.7 s |
| 76 | "Clerk, I've killed the fourth strider out past the last weir — the kill went through my Guild enchantments and I've its chitin plate here. … | Erzähler | open_run_level | Turn in the cull contract, citing the confirmed fourth kill and loot. | Adventurers' Guild hall, Alderwatch | 115/178 | 61.0 s |
| 77 | "I'll wait it out." I take a bench with my tea, and after about an hour I return to the counter. "Clerk, check the roll again now — the four… | Erzähler | open_run_level | Wait out the tally lag, then re-attempt the turn-in. | Adventurers' Guild hall, Alderwatch | 115/178 | 17.4 s |
| 78 | #audit | System (Befehl) | open_run_level | Inspect the audit log to see why the fourth strider kill did not register. | Adventurers' Guild hall, Alderwatch | 115/178 | 2.2 s |
| 79 | I head back out along the causeway into the deep channels and search for the wounded fourth strider — if it crawled off to die, I'll finish … | Erzähler | open_run_level | Hunt down the wounded fourth strider so the kill registers with the Guild and the cull con… | far weir | 115/178 | 21.9 s |
| 80 | I wade out into the shallow channel past the last weir, searching the reed islands and mud banks for the wounded strider. | Erzähler | open_run_level | Find and finish the wounded fourth strider inside the Guild's logging range. | far weir | 115/178 | 17.9 s |
| 81 | I keep to the channel's edge out of reach of its front legs and cast Arcane Bolt at the wounded strider's head. | Erzähler | open_run_level | Kill the wounded fourth strider at range so the Guild's roll registers the fourth cull kil… | far weir | 96/168 | 15.0 s |
| 82 | I cast Arcane Bolt at the strider's head to finish it. | Erzähler | open_run_level | Kill Bog Strider K with Arcane Bolt so the fourth cull kill registers. | far weir | 96/158 | 14.2 s |
| 83 | #assign INT 2 WIL 3 | System (Befehl) | open_run_level | Spend the five level-up points on INT and WIL. | far weir | 96/158 | 2.3 s |
| 84 | I head back along the causeway to the Guild hall in Valedorn Crown and turn in the completed strider cull contract to collect my 80 coppers. | Erzähler | open_run_level | Turn in the now-complete cull contract at the Guild hall. | Adventurers' Guild hall, Alderwatch | 96/158 | 28.4 s |
| 85 | I read the contract board for a new job suited to a Level 5 mage, and ask the clerk whether anyone here buys Bog Strider chitin plates in bu… | Erzähler | open_run_level | Pick the next Guild contract and sell surplus strider chitin. | Adventurers' Guild hall, Alderwatch | 96/158 | 28.6 s |
| 86 | I check the broker's list by the door for current chitin and venom gland prices, then ask the clerk to register me for the Clear Old Crown C… | Erzähler | open_run_level | Sell chitin later and take the catacombs clearing contract. | Adventurers' Guild hall, Alderwatch | 96/158 | 38.0 s |
| 87 | I take my 17 sound chitin plates to Ossler the armorer on Cordwain Street and sell them at 4 cp each, then carry the 3 venom glands to Marro… | Erzähler | open_run_level | Sell surplus chitin and glands at broker's-list prices before heading to the catacombs. | Ossler's armory | 96/158 | 25.4 s |
| 88 | "Yes — all seventeen at four copper each, as you count them." I accept Ossler's offer and take the payment. | Erzähler | open_run_level | Sell the 17 chitin plates to Ossler at his offered 4 cp each. | Ossler's armory | 96/158 | 23.0 s |
| 89 | I walk to Marrow & Sons on Tanner's Row, and once there I offer the three intact venom glands for sale at fifteen copper each, as their list… | Erzähler | open_run_level | Sell the three venom glands to Marrow & Sons at the broker's-list price before heading to … | Marrow & Sons, Physickers | 96/158 | 23.3 s |
| 90 | "Sold — all three, forty-five copper the lot." I accept the physicker's offer and take the payment. | Erzähler | open_run_level | Accept the confirmed offer of 45 copper for the three venom glands. | Marrow & Sons, Physickers | 96/158 | 53.6 s |
| 91 | I head for the Old Crown Catacombs to clear them per my active contract. | Erzähler | open_run_level | Travel to the contracted catacombs and begin the clear. | Old Crown Catacombs, level 1 | 96/158 | 31.2 s |
| 92 | I take the left fork toward the standing water, staff ready, moving quietly and listening for the source of that dragging sound. | Erzähler | open_run_level | Investigate the dragging sound down the left fork and start clearing level 1. | Old Crown Catacombs, level 1 | 96/158 | 20.0 s |
| 93 | I cast Arcane Bolt at the approaching undead as it closes. | Engine (Menü/Rückfrage) | open_run_level | Open the fight with Arcane Bolt against the ghoul-like undead. | Old Crown Catacombs, level 1 | 96/158 | 3.9 s |
| 94 | I cast Arcane Bolt at the ghoul-like undead. | Engine (Menü/Rückfrage) | open_run_level | Attack the undead using a concrete target designation. | Old Crown Catacombs, level 1 | 96/158 | 3.9 s |
| 95 | I cast Arcane Bolt at the figure standing half in the water at the far end of the burial hall. | Engine (Menü/Rückfrage) | open_run_level | Open the fight using the scene's own description of the undead as the target. | Old Crown Catacombs, level 1 | 96/158 | 3.8 s |
| 96 | I move down the left fork toward the standing water, staff ready, to find the source of the dragging sound. | **leer** | open_run_level | Reach the flooded left fork and actually encounter the undead so it becomes a targetable a… | Old Crown Catacombs, level 1 | 96/158 | 104.2 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zum Start (notiert vor Zug 1): Character creation started; five silver and simple clothes confirmed.
- zu Zug 2 (notiert vor Zug 3): Creation complete: Level 1 Mage with Arcane Bolt and Arcane Ward, starter staff and robes equipped, 5 silver. Stats confirmed by HUD.
- zu Zug 3 (notiert vor Zug 4): HUD shows Guild Rank not registered, so registration is needed before accepting contracts. Board offers five novice notices; the wolf cull (30 cp) looks easiest for a solo L1 mage.
- zu Zug 4 (notiert vor Zug 5): Registration offered for 2 silver; wolf cull (30 cp) is my chosen first contract. Must verify contract is ACTIVE before travelling.
- zu Zug 5 (notiert vor Zug 6): Registration and contract both confirmed: quest shows ACTIVE, coin 3 silver. Oddity: purchase log said -20 copper but narration said two silver; HUD's 3 silver is authoritative.
- zu Zug 6 (notiert vor Zug 7): Arrived at Tull orchard; two guard dogs (23 HP each) and the farmer present. Contract confirmed active in HUD.
- zu Zug 8 (notiert vor Zug 9): Farmer confirmed the wolf dens in scrub by the creek, active at dusk and an hour before dawn, wary of man-smell. Time is 10:30, so I have hours before the dusk window.
- zu Zug 9 (notiert vor Zug 10): Wolf confirmed food-mad, prefers rotten apples, dens in creek scrub; farmer advised hiding barn-side since afternoon wind comes off the creek.
- zu Zug 10 (notiert vor Zug 11): Engine resolves one action per message — my combined bait-and-hide was partly NOT TAKEN, and the stealth check failed, dogs barked and alerted the scrub. Will split actions one at a time from now on.
- zu Zug 11 (notiert vor Zug 12): Bait pile set and hiding spot confirmed; wolf count 0/1, midday now, wolf expected at dusk.
- zu Zug 12 (notiert vor Zug 13): Time discrepancy: HUD reads 14:25 (afternoon) while the narration describes dusk approaching and the sign claims the scrub stayed silent 'into dusk' with no wolf. Waiting does advance the clock (~4 hours per message), so I'll keep holding the ambush.
- zu Zug 13 (notiert vor Zug 14): Wolf emerged at dusk per the bait plan; HUD still says 16:25 'afternoon' while narration calls it dusk — same time discrepancy as before. Wolf HP 23, LONG encounter.
- zu Zug 14 (notiert vor Zug 15): Cast was refused for range: wolf at LONG, Arcane Bolt reaches MEDIUM; must move closer first. HUD time still 16:25 while narration says dusk.
- zu Zug 15 (notiert vor Zug 16): Engine refused combined move-and-cast twice, saying no declared movement brings the wolf into range; trying a movement-only declaration this time. HUD time still 16:25 despite dusk narration.
- zu Zug 16 (notiert vor Zug 17): Movement-only declaration worked: engine moved the wolf LONG → MEDIUM, confirming combined move-and-cast is what it refuses. Wolf is now in Arcane Bolt range, still unaware, nosing toward its back trail.
- zu Zug 17 (notiert vor Zug 18): One-shot ambush crit killed the wolf instantly (54 dmg vs 23 HP); quest ready for turn-in, 24/100 XP, loot in pouch. Time discrepancy persists: HUD says 16:25 afternoon while narration describes full dark.
- zu Zug 18 (notiert vor Zug 19): Contract paid out 3 Silver +46 XP; XP now 70/100, coin 6 Silver. Time discrepancy persists: HUD says 17:25 afternoon while narration describes full dark.
- zu Zug 19 (notiert vor Zug 20): Board offers four Novice contracts; striders (rec. level 4, dusk hunters, close-ish) is the achievable one tonight. Guild also sells skill primers at 120 cp each, but I hold only 6 Silver and want coin first.
- zu Zug 20 (notiert vor Zug 21): Contract confirmed ACTIVE in HUD (0/4). Time discrepancy persists: HUD 17:25 afternoon while narration describes full dark.
- zu Zug 21 (notiert vor Zug 22): Arrived at the eel-weirs; two fishermen present and wary. Contract confirmed 0/4 in HUD.
- zu Zug 22 (notiert vor Zug 23): Dorna confirmed the slip and pointed to the middle and third weirs; striders feed at dusk, signaled by clicking sounds.
- zu Zug 23 (notiert vor Zug 24): Two bog striders visible (HP 43 and 53); contract confirmed 0/4 in HUD. Time discrepancy persists: HUD 18:30 evening while narration says full dark.
- zu Zug 24 (notiert vor Zug 25): Arcane Bolt failed for range: strider at LONG, spell reaches MEDIUM; nothing spent. Strider A is now closing on my position.
- zu Zug 25 (notiert vor Zug 26): Both striders at MEDIUM; A at 12 HP. Arcane Bolt (31-37) should kill it; B (53 HP) still fresh.
- zu Zug 26 (notiert vor Zug 27): Strider A defeated (contract likely 1/4 once confirmed); strider B closed to SHORT. Clicking in the right-bank reeds hints at more striders nearby.
- zu Zug 27 (notiert vor Zug 28): Strider B closed and bit me for 16 (HP 74). At 18 HP, one Arcane Bolt should kill it; clicking in the reeds suggests a third strider nearby.
- zu Zug 28 (notiert vor Zug 29): Double level-up to 3 confirmed (+288 XP); loot: 2 chitin plates, 1 venom gland. Contract at 2/4; clicking in the reeds stopped.
- zu Zug 29 (notiert vor Zug 30): The previous #assign bundled with dialogue was not applied: HUD still shows 10 free stat points. Re-issuing it as a standalone command.
- zu Zug 30 (notiert vor Zug 31): Stat points confirmed spent (INT 13, WIL 12, VIT 9, PER 10). Contract at 2/4; fisherman warns of slick stones past the second weir and at least two more striders in the right-bank reeds.
- zu Zug 31 (notiert vor Zug 32): Travel past the second weir processed despite the 'arrival pending' flag; the HUD confirms I stand twenty paces short of the reeds. A fresh body-width drag leads to a motionless long shape; MP is low at 46/152, so I conserve it.
- zu Zug 32 (notiert vor Zug 33): The thrown stone was refused: the shape under the reeds is not a valid target in the active scene, which still lists only the fishermen and two dead striders — the third strider may not exist or may need proximity to spawn.
- zu Zug 33 (notiert vor Zug 34): The reed-bed shape only became a valid target (Bog Strider C, HP 34/34, SHORT) after I closed to ten paces — distant shapes are not targetable. It is alive and bracing, and the narration hints at old blood, so it may already be wounded.
- zu Zug 34 (notiert vor Zug 35): Strider C defeated in one First-Strike bolt (+72 XP, chitin plate), but the HUD quest counter still reads 2/4 despite three kills recorded — possible counter lag to watch. MP low at 36/152.
- zu Zug 35 (notiert vor Zug 36): Bog Strider D (HP 29/29, MEDIUM, 25 paces) now faces me across open mud; it is larger than the last one. Quest counter still reads 2/4 despite three confirmed kills — checking the panel again after this fight.
- zu Zug 36 (notiert vor Zug 37): Fourth strider defeated with one bolt; quest counter still reads 2/4 despite four confirmed kills and 4/4 narratively — likely a counter lag to verify at turn-in. MP low (26/152), wounded; need recovery before next job.
- zu Zug 37 (notiert vor Zug 38): Narrator says all four striders are dead and loot is confirmed (6 plates, venom gland), but the HUD quest counter still reads 2/4 — will verify at turn-in whether the engine credits the kills.
- zu Zug 38 (notiert vor Zug 39): Dorna offered a dry corner in the net shed with a blanket; quest counter still reads 2/4 despite four confirmed kills — will verify at the Guild turn-in.
- zu Zug 39 (notiert vor Zug 40): Overnight recovery fully restored HP/MP; quest counter still reads 2/4 despite four confirmed kills — will raise it at the Guild turn-in.
- zu Zug 40 (notiert vor Zug 41): Turn-in refused because the contract outcome was not yet established in the world despite four confirmed kills; presenting loot proof to the clerk to fix the 2/4 counter discrepancy.
- zu Zug 41 (notiert vor Zug 42): Turn-in still refused: the contract seal reads open at 2/4 despite four narrator-confirmed kills — the engine requires two more real kills. Loot handed over and returned untouched; clerk noted plates can be sold at the brokerage separately.
- zu Zug 42 (notiert vor Zug 43): Contract seal still reads 2/4 despite four narrator-confirmed kills; the engine demands two more real kills out past the middle weir.
- zu Zug 43 (notiert vor Zug 44): Dorna confirmed two striders working together past the middle weir; engine still counts 2/4, so two more real kills are required.
- zu Zug 44 (notiert vor Zug 45): Both remaining striders present at LONG range and unaware; downwind, so a stealthy approach is plausible.
- zu Zug 45 (notiert vor Zug 46): Arcane Bolt was refused at LONG range; combat only triggers once a target is in MEDIUM range, so I must close the gap before casting.
- zu Zug 46 (notiert vor Zug 47): Ambush crit one-shot Bog Strider F at MEDIUM range; loot drifted loose, and Bog Strider E is now at SHORT and closing.
- zu Zug 47 (notiert vor Zug 48): Engine counted both kills but HUD quest line still reads 2/4 — possible display lag; will verify the seal after returning.
- zu Zug 48 (notiert vor Zug 49): Both striders defeated and loot confirmed by the engine, yet the HUD quest line and the physical seal still read 2/4 — checking the quest panel for the authoritative count.
- zu Zug 49 (notiert vor Zug 50): Combat engine confirmed both kills and loot, yet the quest panel still reads 2/4 with 'defeated: open' — a contradiction worth auditing.
- zu Zug 50 (notiert vor Zug 51): Audit clarifies the contradiction: the two latest kills were rejected from the engine-owned quest state, so the contract genuinely stands at 2/4 and two more striders must still be found and killed.
- zu Zug 51 (notiert vor Zug 52): Found Bog Strider G feeding, unaware, at SHORT range; counter confirms 2/4 so two more kills needed.
- zu Zug 52 (notiert vor Zug 53): Ambush crit one-shot Bog Strider G; quest counter now correctly reads 3/4 after the audit, so one more strider remains. Level 4 gained, +5 free points.
- zu Zug 53 (notiert vor Zug 54): Ambush crit one-shot the larder-raider; counter now 3/4, one kill remains. Stats assigned to INT/WIL/PER.
- zu Zug 54 (notiert vor Zug 55): Tracks found near third weir, less than an hour old, heading into snag stand; contract at 3/4, one kill remains.
- zu Zug 55 (notiert vor Zug 56): Bog Strider H is a smaller juvenile at 24 HP, alerted by a stick tap but not yet fleeing; contract at 3/4.
- zu Zug 56 (notiert vor Zug 57): Bog Strider H defeated with a first-strike Arcane Bolt (46 dmg, one-shot); narrator claims contract READY but HUD still reads 3/4, so checking the quest panel.
- zu Zug 57 (notiert vor Zug 58): Quest panel still reads 3/4 despite the System confirming Bog Strider H defeated; counter may be stale, so checking the audit log once.
- zu Zug 58 (notiert vor Zug 59): Audit shows the engine rejected the fourth kill: counter still 3/4, so the juvenile apparently didn't register. Need to find and defeat another strider.
- zu Zug 59 (notiert vor Zug 60): Search failed; mud trail was days old. Quest panel hints at two striders clicking off the right-bank reeds; asking Dorna for a current sighting.
- zu Zug 60 (notiert vor Zug 61): Dorna confirms a large strider standing in the channel past the third weir line two evenings back; light is fading.
- zu Zug 61 (notiert vor Zug 62): Found Bog Strider I (35 HP) past the third weir at dusk; it has not marked me yet, so striking first.
- zu Zug 62 (notiert vor Zug 63): Arcane Bolt failed at LONG range; must close to Medium before striking.
- zu Zug 63 (notiert vor Zug 64): Closed to Medium successfully; strider's head turning toward me but not yet confirmed to have marked me.
- zu Zug 64 (notiert vor Zug 65): Bog Strider I defeated with a first-strike Arcane Bolt (54 damage); combat panel and loot confirm, but the HUD quest line still shows 3/4, so checking the quest panel.
- zu Zug 65 (notiert vor Zug 66): Combat panel confirmed Bog Strider I defeated (54 dmg first strike, +58 XP, 2 chitin plates), but the quest panel still lists 'defeated: open' with no numeric counter. Testing the true kill count by attempting the turn-in.
- zu Zug 66 (notiert vor Zug 67): Contradiction: narrator had the clerk pay 80 cp, but the System panel refused the turn-in ('outcome not established') and the HUD still shows 3/4 defeated with the quest active. Trusting the System refusal and addressing the stated cause.
- zu Zug 67 (notiert vor Zug 68): Clerk now says the seal is cold/unturned and to return after supper; previous turn the seal was READY — direct narration contradiction. Third attempt pending after the suggested wait.
- zu Zug 68 (notiert vor Zug 69): HUD shows 3/4 defeated — the fourth kill never registered despite the combat panel. Clerk implies one strider may still live; plan to hunt the Flats again at dawn if the seal stays cold.
- zu Zug 69 (notiert vor Zug 70): Seal still cold after overnight sleep and full recovery (HP/MP restored); clerk B confirms midday is the final deadline, implying the 4th kill never registered despite the combat panel. Heading back to the Flats to find the remaining strider.
- zu Zug 70 (notiert vor Zug 71): Third turn-in attempt still blocked; seal cold overnight and clerk B says the count isn't met if it stays cold past midday — so I'm hunting the uncounted strider. Refusal flagged my combined action as 'arrival pending', so I'll interact locally first.
- zu Zug 71 (notiert vor Zug 72): Dorna confirms sign of a fourth strider in the deep channels past the last weir; HUD still shows 3/4 defeated.
- zu Zug 72 (notiert vor Zug 73): Fresh dinner-plate-sized webbed prints and knocking from the deep water confirm a live strider past the last weir; HUD still shows 3/4 defeated.
- zu Zug 73 (notiert vor Zug 74): Found the live fourth strider at the drying rack in the deep channels; it is now approaching. Combat panel shows it at full 24 HP.
- zu Zug 74 (notiert vor Zug 75): Combat panel confirmed Bog Strider J defeated and looted a chitin plate, but the HUD quest line still reads 3/4 defeated — possible registration lag or a counter bug worth watching at turn-in.
- zu Zug 75 (notiert vor Zug 76): Combat panel confirmed Bog Strider J defeated with chitin plate loot, but HUD quest line still reads 3/4 defeated — possible engine lag or a counter bug; testing turn-in now.
- zu Zug 76 (notiert vor Zug 77): Clerk confirms the roll can lag up to half a day for distant kills; turn-in refused until the fourth kill posts. Two rangers eavesdropped on the exchange.
- zu Zug 77 (notiert vor Zug 78): Roll has fully caught up and still reads 3/4; clerk says the fourth kill either posted beyond logging range or the strider crawled off to die. This is the second failed turn-in attempt.
- zu Zug 78 (notiert vor Zug 79): Roll fully caught up and still reads 3/4; clerk suggests the fourth strider died or is dying beyond the enchantment's logging range. Second blocked turn-in attempt — next failure means trying a different branch.
- zu Zug 80 (notiert vor Zug 81): Found the missing fourth strider alive: Bog Strider K, MEDIUM, HP 64/64, cornered on a reed island past the far weir with one ruined rear leg. Kill site is closer in than yesterday's fight, but still past the last weir — registration within Guild logging range remains unconfirmed.
- zu Zug 81 (notiert vor Zug 82): Bog Strider K closed fast despite its ruined leg and bit me for 19; it's at 16 HP, engaged, one Arcane Bolt should finish it.
- zu Zug 82 (notiert vor Zug 83): Fourth strider finally killed inside logging range; quest now READY FOR TURN-IN, Level 5 with 5 free stat points.
- zu Zug 83 (notiert vor Zug 84): Fourth strider finally registered inside logging range; quest is READY FOR TURN-IN. Assigned the 5 level-up points (INT 19, WIL 19) despite being lightly wounded at 96/115 HP.
- zu Zug 84 (notiert vor Zug 85): Turn-in succeeded: +8 silver, +240 XP, quest completed; now Level 5, XP 252/500, 17 chitin plates stockpiled and no active quest.
- zu Zug 85 (notiert vor Zug 86): Guild board offers a new Reed Flats strider cull (9 silver) plus a catacombs clear (level 2 rec, 1g1s). Clerk pointed to lamplighters' yard and Ossler the armorer as chitin buyers but gave no prices yet.
- zu Zug 86 (notiert vor Zug 87): Catacombs contract now ACTIVE (110 cp reward). Broker's list prices: 4 cp/plate at Ossler, 15 cp/gland at Marrow & Sons; 17 plates + 3 glands should net ~113 cp.
- zu Zug 87 (notiert vor Zug 88): Ossler offered 4 cp per plate for all seventeen; sale not yet recorded, awaiting his confirmation.
- zu Zug 88 (notiert vor Zug 89): Chitin sale confirmed: +68 copper, coin now 2g6c, quest slip active. Ossler offered repeat business on strider plates if I'm back in the flats.
- zu Zug 89 (notiert vor Zug 90): Physicker confirmed house price 15 cp per gland, 45 total, and is waiting on acceptance; glands still in inventory per HUD, so sale not yet recorded.
- zu Zug 90 (notiert vor Zug 91): Gland sale confirmed: +45 copper, coin 2g5s1c. All surplus loot sold; heading out for the active catacombs contract.
- zu Zug 91 (notiert vor Zug 92): Entered the catacombs; level 1 forks into a flooded left passage (dragging sound) and rubble-choked right fork. HP 96/120, MP 158/228 before any fight.
- zu Zug 92 (notiert vor Zug 93): Left fork was briefly flagged sealed but the move went through anyway — oddity. Now facing a ghoul-like undead in the flooded burial hall; it noticed me and is charging.
- zu Zug 93 (notiert vor Zug 94): System refused 'the approaching undead' as a target; the scene currently shows no targetable actor, though the ghoul is described as advancing. Oddity: earlier the left fork was flagged 'sealed' yet I entered anyway.
- zu Zug 94 (notiert vor Zug 95): System twice refused targets ('approaching undead', 'ghoul-like undead') claiming no targetable actor, while narration shows one advancing — trying the exact scene wording 'the figure'.
- zu Zug 95 (notiert vor Zug 96): HUD confirms 'Present: nobody besides Alaric' — the ghoul was narration only; three attack attempts were refused for lack of a targetable actor.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t17 | 17 | 1 | – | ja | 1 | gewonnen, 24 XP |
| enc.t25 | 25 | 2 | – | nein | 2 | gewonnen, 288 XP |
| enc.t32 | 34 | 1 | – | nein | 1 | gewonnen, 72 XP |
| enc.t34 | 36 | 1 | – | nein | 1 | gewonnen, 30 XP |
| enc.t44 | 46 | 1 | – | nein | 1 | gewonnen, 48 XP |
| enc.t45 | 47 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t48 | 52 | 1 | – | nein | 1 | gewonnen, 168 XP |
| enc.t51 | 56 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t57 | 64 | 1 | – | nein | 1 | gewonnen, 58 XP |
| enc.t66 | 74 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t72 | 81 | 1 | – | nein | 1 | gewonnen, 206 XP |

## Quests

- **Cull the Reed Flat Striders** — active (Zug 20) → completed (Zug 84), READY
  - Aufgabe: Hunt and cull 4 bog striders at the eel-weirs of the Reed Flats so the eel boats can launch safely again.
  - Endzustand: 4 bog striders at the Reed Flat eel-weirs are culled and the eel boats launch again.
- **Cull the Orchard Row Wolf** — active (Zug 5) → completed (Zug 18), READY
  - Aufgabe: Hunt and kill the single gaunt yearling wolf that has been slipping under the hedge gaps to take lambs in the Tull orchard rows.
  - Endzustand: The gaunt yearling wolf raiding the Tull orchard rows is killed and the lambs are safe.
- **Thin the Barrowfield Ghouls** — expired (Zug 85)
  - Aufgabe: Hunt and cull 6 ghouls prowling the old barrowfield pastures before the autumn herds are moved through.
  - Endzustand: 6 ghouls prowling the Barrowfield pastures are culled and the herds can be moved through.
- **Thin the Highpass Wyrms** — expired (Zug 85)
  - Aufgabe: Hunt and cull 3 rock wyrms denning in the Highpass scree slopes so the Crown Road freight wagons can cross without losing draft teams.
  - Endzustand: 3 rock wyrms denning in the Highpass scree slopes are culled and the freight wagons cross safely.
- **Clear the Old Crown Catacombs, Level 1** — expired (Zug 85), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of Old Crown Catacombs. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Old Crown Catacombs is clear.
- **Clear Old Crown Catacombs, Level 1** — active (Zug 86), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of Old Crown Catacombs. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Old Crown Catacombs is clear.

## Auffälligkeiten

- Zug 6, Nachricht 12 (extraction_repaired): the extractor's first answer needed a repair
- Zug 6, Nachricht 12 (finish): extract ended with finish_reason "length"
- Zug 12, Nachricht 23 (planner_repaired): the planner's first answer needed a repair
- Zug 23, Nachricht 46 (extraction_repaired): the extractor's first answer needed a repair
- Zug 23, Nachricht 46 (finish): extract ended with finish_reason "length"
- Zug 38, Nachricht 76 (extraction_repaired): the extractor's first answer needed a repair
- Zug 47, Nachricht 94 (extraction_repaired): the extractor's first answer needed a repair
- Zug 47, Nachricht 94 (finish): extract ended with finish_reason "length"
- Zug 51, Nachricht 102 (extraction_repaired): the extractor's first answer needed a repair
- Zug 51, Nachricht 102 (finish): extract ended with finish_reason "length"
- Zug 56, Nachricht 112 (extraction_repaired): the extractor's first answer needed a repair
- Zug 66, Nachricht 132 (extraction_repaired): the extractor's first answer needed a repair
- Zug 68, Nachricht 135 (planner_repaired): the planner's first answer needed a repair
- Zug 76, Nachricht 152 (extraction_repaired): the extractor's first answer needed a repair
- Zug 76, Nachricht 152 (finish): extract ended with finish_reason "length"
- Zug 79, Nachricht 157 (planner_repaired): the planner's first answer needed a repair
- Zug 84, Nachricht 168 (extraction_repaired): the extractor's first answer needed a repair
- Zug 87, Nachricht 173 (planner_repaired): the planner's first answer needed a repair
- Zug 89, Nachricht 177 (planner_repaired): the planner's first answer needed a repair
- Zug 90, Nachricht 180 (extraction_repaired): the extractor's first answer needed a repair
- Zug 90, Nachricht 180 (finish): extract ended with finish_reason "length"
- Zug 91, Nachricht 182 (extraction_repaired): the extractor's first answer needed a repair
- Zug 96, Nachricht 192 (empty_reply): the narrator's reply was empty (no extraction; the player saw the notice)
- Hinweis (warning): Avereth Engine: the narrator returned no story text. Swipe or regenerate the reply.
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 26× keine gültige JSON-Entscheidung (Züge 2, 8, 10, 15, 17, 20, 23, 24, 25, 40, 41, 43, 44, 45, 46, 47, 55, 61, 62, 63, 64, 72, 73, 78, 79, 80)
- 7 Aufruf(e) mit finish_reason "length" (Nr. 14 extract, Nr. 67 extract, Nr. 136 extract, Nr. 143 extract, Nr. 210 extract, Nr. 252 extract, Nr. 265 narrator)

System-Panels: CLARIFY 0, NOT TAKEN 2, REFUSED 2, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: ambient 3, no_go 3, scene_context 16, time_cap 2, engine_owned_combat 1, pc_inventory 1, guild_payout 1, guild_completion 1, engine_owned_fact 11, attack_commitment 1, world_rule 5, quest_count 9, engine_recovery 1, guild_canon 1, engine_owned_memory 1, domain_fact 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 90 | 5 | 2.6 s | 8.9 s | 11545 | 9796 | 69 | – | stop 90 | 0 |
| board | 3 | 1 | 12.2 s | 13.8 s | 2415 | 2103 | 1119 | – | stop 3 | 0 |
| narrator | 81 | 0 | 11.1 s | 22.7 s | 11393 | 8739 | 440 | – | stop 80, length 1 | 1 |
| extract | 91 | 5 | 6.5 s | 22.7 s | 11181 | 8952 | 380 | – | stop 85, length 6 | 6 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 62:38 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 14.3 s) | 0:28 min |
| 96 Züge, Spiel (Senden bis HUD nach der Extraktion) | 49:14 min — Median 25.3 s, p90 60.2 s, max 167.7 s |
| 96 Züge, Spieler-Entscheidung | 11:24 min — Median 4.2 s, 26 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 6:25 min / 0:35 min / 21:45 min / 16:59 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 37.9 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 25:16 min, 80 Züge ≈ 50:32 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spieler | 42 | – | 38.0 s | 4.2 s |
| Spieler | 34 | – | 34.4 s | 4.2 s |
| Spieler | 79 | – | 30.4 s | 4.2 s |
| Spiel | 6 | – | 167.7 s | 25.3 s |
| Spiel | 41 | – | 121.2 s | 25.3 s |
| Spiel | 96 | – | 104.2 s | 25.3 s |
| Provider narrator | 41 | 117 | 99.6 s | 11.1 s |
| Provider narrator | 96 | 265 | 94.9 s | 11.1 s |
| Provider narrator | 75 | 206 | 86.4 s | 11.1 s |
| Provider extract | 6 | 14 | 104.5 s | 6.5 s |
| Provider extract | 23 | 67 | 51.4 s | 6.5 s |
| Provider extract | 51 | 143 | 50.1 s | 6.5 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
