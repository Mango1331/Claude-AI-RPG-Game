# Avereth Live-Test 20261027-043011Z-current_test

## Kurzfassung

- **Laufprofil:** guild-rogue; Startklasse Rogue, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** extractor_failed — turn 5: the World Extractor failed after story message 10; its world changes were not committed ($.deltas[2] (person.new): .at: matches none of anyOf)
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 1. Sicherheitsgrenzen: 150 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** noch nicht erreicht.
- **Charakter:** rogue (rogue.razor_cut, rogue.evasive_step) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: pragmatic adventurer: sell surplus loot and invest in useful equipment and techniques
- **Züge:** 5 · **Dauer:** 2:54 min · **LLM-Aufrufe der Engine/des Erzählers:** 11
- **Auffälligkeiten:** 3
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.100 |
| Git | cadd5315862a (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 14.8 s |
| Browser | chrome 156.0.8078.48 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261027-043011Z-current_test“, Seed 1348926324 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | Rogue | Engine (Menü/Rückfrage) | creation_complete | Choose Rogue as base class. | public roadside verge outside Ashbridge | 90/84 | 2.3 s |
| 2 | I choose Razor Cut and Evasive Step. | Engine (Menü/Rückfrage) | creation_complete | Finish character creation with two chosen starter skills. | public roadside verge outside Ashbridge | 90/84 | 2.1 s |
| 3 | I walk into Ashbridge and head to the Adventurers' Guild hall to look at the contract board. | Erzähler | open_run_level | Reach the Guild and check available contracts. | Adventurers' Guild hall, Ashbridge | 90/84 | 35.4 s |
| 4 | I go to the clerk and ask to register with the Guild. | Erzähler | open_run_level | Register as a Guild member so I can take contracts. | Adventurers' Guild hall, Ashbridge | 90/84 | 14.1 s |
| 5 | "Alaric Red." I pay the two silver fee. |  | open_run_level | Register with the Guild by giving my name and paying the two silver fee. | Adventurers' Guild hall, Ashbridge | 90/84 | 65.0 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zum Start (notiert vor Zug 1): Character creation step 1/2 shown; Rogue available with AGI/PER favored stats.
- zu Zug 1 (notiert vor Zug 2): Rogue chosen; stats AGI 8 PER 8, HP 90, starter dagger and light armor promised on completion.
- zu Zug 2 (notiert vor Zug 3): Creation complete: Level 1 Rogue with Razor Cut and Evasive Step, starter dagger and light armor equipped, 5 silver on hand.
- zu Zug 3 (notiert vor Zug 4): Novice board shows five cull contracts; Guild Rank shows 'not registered', so registration likely needed before accepting.
- zu Zug 4 (notiert vor Zug 5): Registration requires name plus 2 silver one-time fee; I have 5 silver, affordable.

## Kämpfe

Kein Kampf.

## Quests

Keine angenommen.


## Auffälligkeiten

- Zug 5, Nachricht 10 (extraction_failed): the extractor failed: $.deltas[2] (person.new): .at: matches none of anyOf
- Zug 5, Nachricht 10 (extraction_repaired): the extractor's first answer needed a repair
- Zug 5, Nachricht 10 (finish): extract ended with finish_reason "length"
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- 1 Aufruf(e) mit finish_reason "length" (Nr. 10 extract)

System-Panels: CLARIFY 0, NOT TAKEN 0, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: ambient 1, guild_canon 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 3 | 0 | 2.5 s | 4.0 s | 11689 | 9707 | 101 | – | stop 3 | 0 |
| board | 1 | 0 | 13.3 s | 13.3 s | 2356 | 2105 | 1350 | – | stop 1 | 0 |
| narrator | 3 | 0 | 8.7 s | 11.8 s | 11664 | 0 | 354 | – | stop 3 | 0 |
| extract | 4 | 0 | 9.8 s | 35.9 s | 11171 | 8908 | 903 | – | stop 3, length 1 | 1 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 2:54 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 14.8 s) | 0:28 min |
| 5 Züge, Spiel (Senden bis HUD nach der Extraktion) | 1:59 min — Median 14.1 s, p90 65.0 s, max 65.0 s |
| 5 Züge, Spieler-Entscheidung | 0:23 min — Median 3.3 s, 1 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 0:09 min / 0:13 min / 0:27 min / 0:59 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 28.4 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 18:56 min, 80 Züge ≈ 37:52 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spiel | 5 | – | 65.0 s | 14.1 s |
| Provider extract | 5 | 10 | 35.9 s | 9.8 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
