# Avereth Live-Test 20261027-050329Z-current_test

## Kurzfassung

- **Laufprofil:** explore-mage; Startklasse Mage, Schwerpunkt explore. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** extractor_failed — turn 20: the World Extractor failed after story message 40; its world changes were not committed (report is not valid JSON)
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 1. Sicherheitsgrenzen: 150 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** noch nicht erreicht.
- **Charakter:** mage (mage.arcane_bolt, mage.flame_lance) · Regelstand 2 (Warrior, Mage, Rogue)
- **Ziel-Dungeon:** Mossback Warrens, Ebene 1 (Vertrag quest.clear_mossback_warrens_level_1)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: pragmatic adventurer: sell surplus loot and invest in useful equipment and techniques
- **Züge:** 20 · **Dauer:** 18:38 min · **LLM-Aufrufe der Engine/des Erzählers:** 59
- **Auffälligkeiten:** 7
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.100 |
| Git | cadd5315862a (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 62.6 s |
| Browser | chrome 156.0.8078.48 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261027-050329Z-current_test“, Seed 1348926326 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | I choose Mage. | Engine (Menü/Rückfrage) | creation_complete | Select the Mage base class. | public roadside verge outside Ashbridge | 90/84 | 2.3 s |
| 2 | I choose Arcane Bolt and Flame Lance. | Engine (Menü/Rückfrage) | creation_complete | Select the two starter skills Arcane Bolt and Flame Lance. | public roadside verge outside Ashbridge | 90/96 | 2.1 s |
| 3 | I walk along the road toward the city of Ashbridge. | Erzähler | open_run_level | Enter Ashbridge to explore and find opportunities. | Ashbridge west gate | 90/96 | 36.8 s |
| 4 | "Exploration, mostly — I'm a journeyman mage looking for work and sights. Any word on what the Guild needs these days?" | Erzähler | open_run_level | Answer the guard and ask about the Guild and opportunities. | Ashbridge west gate | 90/96 | 20.8 s |
| 5 | I walk to the Guild board and read the posted notices. | Erzähler | open_run_level | Check the Guild board for contracts and registration options. | Adventurers' Guild hall, Ashbridge | 90/96 | 21.2 s |
| 6 | I step inside to the clerk's counter and ask whether I can register with the Guild, and what contracts are on the board. | Erzähler | open_run_level | Register at the Guild and view the contract board inside. | Adventurers' Guild hall, Ashbridge | 90/96 | 36.4 s |
| 7 | I pay the two silver fee and ask the clerk to register me as a Novice member. | Erzähler | open_run_level | Register with the Guild for 2 silver to unlock Novice contracts. | Adventurers' Guild hall, Ashbridge | 90/96 | 17.7 s |
| 8 | I ask the clerk to accept the Weir Viper contract for me. | Erzähler | open_run_level | Take the easiest Novice contract and verify it's ACTIVE. | Adventurers' Guild hall, Ashbridge | 90/96 | 37.3 s |
| 9 | I head out through the south gate and walk to the Millpond weirs to find the frog-catchers. | Erzähler | open_run_level | Travel to the Millpond weirs and locate the frog-catchers who know the viper's stones. | Millpond weirs | 90/96 | 28.3 s |
| 10 | I keep to the near side and edge along the third weir toward the big flat stone at the bend; if the viper is sunning there, I cast Flame Lan… | Erzähler | open_run_level | Approach the viper's stone carefully and attack it with Flame Lance from range. | flat stone at the bend of the third weir | 90/96 | 23.0 s |
| 11 | I cast Flame Lance at the viper before it can strike. | Erzähler | open_run_level | Attack the sunning viper with Flame Lance. | flat stone at the bend of the third weir | 90/80 | 16.4 s |
| 12 | I walk back through the south gate to the Guild hall and turn in the Cull the Weir Viper contract at the clerk's counter. | Erzähler | open_run_level | Return to Duskreach's Guild hall and turn in the completed viper contract. | Adventurers' Guild hall, Ashbridge | 90/80 | 41.8 s |
| 13 | I ask the drover what he knows about the sheep-killer east of Ashbridge — where it strikes, when, and what tracks it leaves. | Erzähler | open_run_level | Follow the sheep-killer rumor as a next lead before the Guild posts it. | Adventurers' Guild hall, Ashbridge | 90/80 | 367.7 s |
| 14 | I ask the clerk whether the Guild buys F-Rank materials like my grey viper skin and fangs, and what she would offer for them. | Erzähler | open_run_level | Sell the surplus viper loot for coin before heading out. | Adventurers' Guild hall, Ashbridge | 90/80 | 81.7 s |
| 15 | I accept the offer and sell the viper skin and both fangs to the clerk's brokerage for eleven copper. | Engine (Menü/Rückfrage) | open_run_level | Sell viper loot through the Guild broker as offered. | Adventurers' Guild hall, Ashbridge | 90/80 | 6.5 s |
| 16 | I accept the bid at 12 copper and sell the skin and both fangs to the clerk's brokerage. | Erzähler | open_run_level | Accept the corrected 12-copper bid and complete the sale. | Adventurers' Guild hall, Ashbridge | 90/80 | 15.7 s |
| 17 | I take the coin and head to the board to look over the postings, especially the Barrow-Ridge direwolf notice and the Mossback warrens. | Erzähler | open_run_level | Check the Guild board for a suitable next contract or lead. | Adventurers' Guild hall, Ashbridge | 90/80 | 32.5 s |
| 18 | I ask the clerk to register me for the Clear Mossback Warrens Level 1 contract, and check that it shows as active before I set out. | Erzähler | open_run_level | Take the level-appropriate Mossback Warrens contract and verify it is active. | Adventurers' Guild hall, Ashbridge | 90/80 | 16.0 s |
| 19 | I set out east along the old quarry track toward the Mossback Warrens, and on reaching the hill I sign the entry ledger before going down in… | Erzähler | open_run_level | Travel to the Mossback Warrens, sign in, and begin clearing level one. | Mossback Warrens mouth gallery | 90/80 | 48.1 s |
| 20 | I move quietly to the bend and peek around it to see the goblins before they spot me. |  | open_run_level | Scout the goblins around the bend before engaging. | Mossback Warrens mouth gallery | 90/80 | 66.4 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zum Start (notiert vor Zug 1): Character creation started at step 1/2; class choice pending confirmation.
- zu Zug 1 (notiert vor Zug 2): Mage class confirmed: INT 8, WIL 8, Max MP 96, starter staff and robes equipped on completion.
- zu Zug 2 (notiert vor Zug 3): Creation complete: Level 1 Mage, Arcane Bolt + Flame Lance, starter staff and robes equipped, 5 silver.
- zu Zug 3 (notiert vor Zug 4): Foot travelers enter free; gate routine is friendly.
- zu Zug 4 (notiert vor Zug 5): Reached Ashbridge; guard mentioned sheep killings east of the river farms as a possible contract hook.
- zu Zug 5 (notiert vor Zug 6): The outside board holds only public notices; the real contract board is inside the hall. Guild rank still unregistered per HUD.
- zu Zug 6 (notiert vor Zug 7): Guild registration costs 2 silver (one-time, grants Novice rank); Power Rank is measured separately by a stone. Novice board has contracts from 20 cp viper culling up to a 220 cp direwolf hunt at recommended level 13.
- zu Zug 7 (notiert vor Zug 8): Registered as Novice, Power Rank F confirmed, coin 3 silver. Novice board offers contracts from 20 cp to 220 cp; drover just entered, likely the sheep-killer rumor source.
- zu Zug 8 (notiert vor Zug 9): Weir Viper contract confirmed ACTIVE (0/1) on quest panel; coin 3 silver after paying registration.
- zu Zug 9 (notiert vor Zug 10): Net-mender confirmed the viper's spot: third weir past the alder, flat stone at the bend, suns there in the morning; warned the weir's top course is slick. Contract slip serves as proof — no trophy needed.
- zu Zug 10 (notiert vor Zug 11): Viper confirmed present at the flat stone, HP 20/20, head lifting — it noticed me. Casting first.
- zu Zug 11 (notiert vor Zug 12): First-strike Flame Lance killed the viper outright (44 dmg vs 20 HP, 16 MP); loot gained: F-Rank skin and 2 fangs. Quest panel confirms 1/1 and ready for turn-in; the sheep-killer lead east of Ashbridge is still unposted.
- zu Zug 12 (notiert vor Zug 13): Viper contract turned in: +2 silver (5 total), +46 XP (70/100). Drover at the counter has a fresh sheep-killer lead near the river farms; Barrow Ridge direwolf posting also mentioned.
- zu Zug 13 (notiert vor Zug 14): Drover confirmed east sheep-killer (Millhollow, dusk strikes, plate-sized three-toed prints) has no Guild posting yet; his own trouble is a direwolf at Barrow Ridge. Guild sells skill primers at 120 cp each; I hold 5 silver.
- zu Zug 14 (notiert vor Zug 15): Clerk offered 11 copper net (12 less 1 fee) for burnt skin and fangs; Guild doesn't buy outright, only brokers.
- zu Zug 15 (notiert vor Zug 16): System clarified the bid as 12 cp gross (11 net after the 1-cp fee); my 'eleven copper' wording was read as a counter-offer. Nothing spent or rolled yet.
- zu Zug 16 (notiert vor Zug 17): Sale confirmed: +12 copper, now 6s2cp. Coin discrepancy: narrator said one silver two copper but HUD says 62 copper total — HUD authoritative. Drover's direwolf lead at Barrow Ridge cairns looks like the strongest next fight.
- zu Zug 17 (notiert vor Zug 18): Sale completed: +12 copper, now 6s2cp per HUD. Guild board offers serpents (rec. 5), millpond raptor (rec. 9), Barrow-Ridge direwolves (rec. 13), and Mossback Warrens L1 (rec. 1) — the warrens fits my level; the drover offers a reward split and local knowledge for the direwolf job as a later option.
- zu Zug 18 (notiert vor Zug 19): Contract confirmed ACTIVE under my name with a sealed slip I must return; MP is 80/96, slightly below full, and the warrens entry requires signing the hill ledger under crown charter.
- zu Zug 19 (notiert vor Zug 20): Half-day travel put me at the warrens at dusk (18:30); signed ledger, contract active. Two-plus goblins audible around the first bend, dragging something.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t11 | 11 | 1 | – | nein | 1 | gewonnen, 24 XP |

## Quests

- **Cull the Weir Viper** — active (Zug 8) → completed (Zug 12), READY
  - Aufgabe: Kill the small grey viper that has been striking at the frog-catchers' hands among the Millpond weirs.
  - Endzustand: The grey viper at the Millpond weirs is dead.
- **Clear Mossback Warrens Level 1** — active (Zug 18), Dungeon loc.mossback_warrens Ebene 1
  - Aufgabe: Clear level 1 of Mossback Warrens. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Mossback Warrens is clear.

## Auffälligkeiten

- Zug 4, Nachricht 8 (extraction_repaired): the extractor's first answer needed a repair
- Zug 15, Nachricht 29 (planner_repaired): the planner's first answer needed a repair
- Zug 17, Nachricht 34 (extraction_repaired): the extractor's first answer needed a repair
- Zug 19, Nachricht 38 (extraction_repaired): the extractor's first answer needed a repair
- Zug 20, Nachricht 40 (extraction_failed): the extractor failed: report is not valid JSON
- Zug 20, Nachricht 40 (extraction_repaired): the extractor's first answer needed a repair
- Zug 20, Nachricht 40 (finish): extract_repair ended with finish_reason "length"
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 3× keine gültige JSON-Entscheidung (Züge 2, 5, 6)
- 1 Aufruf(e) mit finish_reason "length" (Nr. 59 extract)

System-Panels: CLARIFY 1, NOT TAKEN 0, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: no_go 1, ambient 3, engine_owned_fact 2, guild_canon 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 19 | 1 | 2.4 s | 12.6 s | 11739 | 9720 | 68 | – | stop 19 | 0 |
| narrator | 17 | 0 | 9.3 s | 29.1 s | 12019 | 0 | 460 | – | stop 17 | 0 |
| extract | 21 | 4 | 7.0 s | 28.9 s | 11393 | 8927 | 495 | – | stop 20, length 1 | 1 |
| board | 2 | 1 | 9.8 s | 10.7 s | 3034 | 2470 | 1359 | – | stop 2 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 18:38 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 62.6 s) | 1:19 min |
| 20 Züge, Spiel (Senden bis HUD nach der Extraktion) | 15:19 min — Median 25.6 s, p90 81.7 s, max 367.7 s |
| 20 Züge, Spieler-Entscheidung | 1:46 min — Median 3.2 s, 3 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 1:13 min / 0:20 min / 9:03 min / 4:01 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 51.2 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 34:08 min, 80 Züge ≈ 68:17 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spiel | 13 | – | 367.7 s | 25.6 s |
| Spiel | 14 | – | 81.7 s | 25.6 s |
| Provider narrator | 13 | 35 | 323.8 s | 9.3 s |
| Provider extract | 20 | 59 | 41.4 s | 7.0 s |
| Provider extract | 14 | 39 | 32.3 s | 7.0 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
