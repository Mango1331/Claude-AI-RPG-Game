# Avereth – neun natürliche Testkampagnen

Status: **interrupted**. Serie abgeschlossen bedeutet, dass die Läufe beendet sind; es bedeutet nicht neun bestandene Level-15-Abnahmen.

| Nr. | Profil | Seed | Eingaben | Level | Ende | Originalbericht |
|---|---|---:|---:|---:|---|---|
| 1 | guild-warrior | 1348926322 | 32 | 2 | extractor_failed | [report.md](001-guild-warrior/20261027-030034Z-current_test/report.md) |
| 2 | guild-mage | 1348926323 | 96 | 5 | narrator_empty | [report.md](002-guild-mage/20261027-032730Z-current_test/report.md) |
| 3 | guild-rogue | 1348926324 | 5 | 1 | extractor_failed | [report.md](003-guild-rogue/20261027-043011Z-current_test/report.md) |
| 4 | explore-warrior | 1348926325 | 47 | 1 | narrator_empty | [report.md](004-explore-warrior/20261027-043306Z-current_test/report.md) |
| 5 | explore-mage | 1348926326 | 20 | 1 | extractor_failed | [report.md](005-explore-mage/20261027-050329Z-current_test/report.md) |
| 6 | explore-rogue | 1348926327 | 32 | 2 | process_error | [report.md](006-explore-rogue/20261027-052209Z-current_test/report.md) |
| 7 | dungeon-warrior | 1348926328 | – | – | pending | – |
| 8 | dungeon-mage | 1348926329 | – | – | pending | – |
| 9 | dungeon-rogue | 1348926330 | – | – | pending | – |

