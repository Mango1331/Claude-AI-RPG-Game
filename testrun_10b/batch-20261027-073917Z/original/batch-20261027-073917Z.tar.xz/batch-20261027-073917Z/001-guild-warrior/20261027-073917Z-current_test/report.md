# Avereth Live-Test 20261027-073917Z-current_test

## Kurzfassung

- **Laufprofil:** guild-warrior; Startklasse Warrior, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** abgebrochen: Limit erreicht — 150 turns
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 7. Sicherheitsgrenzen: 150 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** Level 4, 176 XP seit Levelaufstieg, 262 cp, HP 75, MP 88; Ort realm.caelreth.the_tannery_ponds_south_of_glassmere. Ausrüstung und Skills stehen in evaluation.json → progression.checkpoint.
- **Charakter:** warrior (warrior.heavy_slash, warrior.guard) · Regelstand 2 (Warrior, Mage, Rogue)
- **Ziel-Dungeon:** Glimmerdeep Grotto, Ebene 1 (ohne Dungeon-Vertrag: der erste betretene)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: curious adventurer: follow interesting opportunities without forcing dangerous encounters
- **Züge:** 150 · **Dauer:** 82:37 min · **LLM-Aufrufe der Engine/des Erzählers:** 429
- **Auffälligkeiten:** 46
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.101 |
| Git | c9e3fa58bb57 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 13.8 s |
| Browser | chrome 156.0.8078.48 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261027-073917Z-current_test“, Seed 1613311441 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | I choose Warrior. | Engine (Menü/Rückfrage) | creation_complete | Select the Warrior base class. | public roadside verge outside Glassmere | 90/84 | 2.2 s |
| 2 | I pick Heavy Slash and Guard. | Engine (Menü/Rückfrage) | creation_complete | Select Heavy Slash and Guard as starter skills to finish Warrior creation. | public roadside verge outside Glassmere | 95/84 | 2.1 s |
| 3 | I walk into Glassmere and look for the Adventurers' Guild hall. | Erzähler | open_run_level | Reach the city and find the Guild to take contracts. | Adventurers' Guild hall, Glassmere | 95/84 | 18.7 s |
| 4 | I approach the clerk at the counter and ask: "I'd like to register with the Guild as a new adventurer, please. What do I need to do?" | Erzähler | open_run_level | Register with the Guild so I can take contracts. | Adventurers' Guild hall, Glassmere | 95/84 | 32.2 s |
| 5 | I sign the ledger as Alaric, mark Warrior as my trade, and hand the clerk two silver. Then I place my hand on the measuring stone. | Erzähler | open_run_level | Register with the Guild and get measured for Rank. | Adventurers' Guild hall, Glassmere | 95/84 | 19.6 s |
| 6 | I pin my new Guild plate inside my pouch, then ask the clerk: "Where does the academy post its beetle culling contracts, and is there any ot… | Erzähler | open_run_level | Find available work since the board is empty. | Adventurers' Guild hall, Glassmere | 95/84 | 76.8 s |
| 7 | I leave the Guild hall and walk to Mantle Lane to find the stabling master and ask about the night watch work. | Erzähler | open_run_level | Take the sheep-watch job at Mantle Lane since the board is empty. | Mantle Lane stables | 95/84 | 22.1 s |
| 8 | "I'll take tonight's watch," I tell her. "I'll look over the ground now if I may, then be back before dusk." | Erzähler | open_run_level | Accept the night watch job and inspect the pen by daylight. | Mantle Lane stables | 95/84 | 26.4 s |
| 9 | I spend the morning on small preparations, then return to the stable gate before dusk and ask Bette Hallow for a lantern, a flint, and to be… | Erzähler | open_run_level | Prepare during the day and begin the night watch at the stables. | Mantle Lane stables | 95/84 | 26.0 s |
| 10 | I take the lantern and set myself by the shed, light it with the flint and striker, and settle onto the stool to keep the fire lit and watch… | Erzähler | open_run_level | Start the night watch with the lantern lit to deter the predator. | Mantle Lane stables | 95/84 | 60.2 s |
| 11 | "Quiet one — nothing came near the wall all night," I say, and help her count the sheep and goats at the gate. | Erzähler | open_run_level | Complete the watch, get the sheep counted and the pay | Mantle Lane stables | 95/84 | 39.6 s |
| 12 | I pocket the twenty-two coppers and tell Bette: "I'll take tonight's watch too. Meanwhile I'll check the Guild board — Thursday's grain guar… | Erzähler | open_run_level | Collect pay, accept another watch, and look for Guild work at the hall. | Mantle Lane stables | 95/84 | 32.0 s |
| 13 | I go to the board and take the rat culling contract slip, then ask the clerk to register it as active for me. | Erzähler | open_run_level | Accept the rat culling contract from the Novice board and get it activated. | Mantle Lane stables | 95/84 | 22.8 s |
| 14 | I walk from the stables to the Guild hall, take the rat culling slip from the Novice board, and ask the clerk to register it as active for m… | Erzähler | open_run_level | Reach the Guild hall and activate the rat culling contract. | Adventurers' Guild hall, Glassmere | 95/84 | 58.2 s |
| 15 | I ask the clerk to set aside any Novice contract that suits a sword when the midday slips are sorted, then walk to the market square and off… | Erzähler | open_run_level | Reserve a midday Novice slip and earn coin crate-loading until then. | Market square | 95/84 | 26.3 s |
| 16 | "Deal — half a copper the crate, counted at the door," I say, and start hauling crates up the ramp, stacking them square inside the warehous… | Engine (Menü/Rückfrage) | open_run_level | Accept the crate-loading work and earn coin until the midday Guild slips. | Market square | 95/84 | 40.7 s |
| 17 | I take the foreman's offer: all remaining crates carried and stacked square at half a copper each, pay counted at the door when the work is … | Engine (Menü/Rückfrage) | open_run_level | Confirm the crate-loading work at the agreed half-copper per crate. | Market square | 95/84 | 12.2 s |
| 18 | I work only at half a copper per crate, as the foreman quoted. | Engine (Menü/Rückfrage) | open_run_level | Accept the crate work at the agreed half-copper rate. | Market square | 95/84 | 6.4 s |
| 19 | I accept the crate-loading offer. | Erzähler | open_run_level | Confirm the crate-loading job at the foreman's quoted rate and start working. | Market square | 95/84 | 38.9 s |
| 20 | I walk to the Guild hall and ask the clerk for the sword-suitable Novice slip she held for me. | Erzähler | open_run_level | Claim the held Novice contract at the Guild hall and get it registered active. | Adventurers' Guild hall, Glassmere | 95/84 | 88.1 s |
| 21 | "I'll wait for the midday sort," I tell the clerk, and take a seat on a bench where he can see me. | Erzähler | open_run_level | Wait at the Guild hall for the midday contract sort to finish. | Adventurers' Guild hall, Glassmere | 95/84 | 20.6 s |
| 22 | "I'll check the board again later," I tell the clerk, and ask him where Glimmerdeep and the academy's beetle grottos are, and what the culli… | Erzähler | open_run_level | Get details on the Glimmerdeep beetle culling as an alternative source of work and XP. | Adventurers' Guild hall, Glassmere | 95/84 | 19.6 s |
| 23 | I thank the clerk, buy a waterskin and some food from a market stall on my way out, and set off north along the stream road toward Glimmerde… | Erzähler | open_run_level | Head for Glimmerdeep with water and supplies for the beetle culling. | Adventurers' Guild hall, Glassmere | 95/84 | 17.5 s |
| 24 | I buy the waterskin, a loaf of bread, and a wedge of cheese for nine copper, then set off north along the stream road toward Glimmerdeep. | Erzähler | open_run_level | Buy road supplies and travel toward Glimmerdeep for the beetle culling. | Glimmerdeep Grotto | 95/84 | 31.1 s |
| 25 | I show Ostrey my Guild plate and pay the ten copper entry fee, then head into the outer grottos to cull beetles. | Erzähler | open_run_level | Show the plate, pay the gate fee, and enter Glimmerdeep's outer grottos for the culling. | Glimmerdeep Grotto | 95/84 | 25.9 s |
| 26 | I draw my longsword and charge the beetle that lifted its head, aiming a Heavy Slash at it. | Engine (Menü/Rückfrage) | open_run_level | Engage the three glass beetles, starting with the alert one. | Glimmerdeep Grotto | 95/84 | 4.5 s |
| 27 | I step through the passage into the first grotto and attack the nearest glass beetle with Heavy Slash. | Erzähler | open_run_level | Confirm entering the grotto and target a beetle by name so the attack resolves. | first grotto | 95/84 | 18.3 s |
| 28 | I press the attack, using Heavy Slash again on Glass Beetle A before the other two can close in. | Erzähler | open_run_level | Continue the attack on Glass Beetle A with Heavy Slash. | first grotto | 95/84 | 17.1 s |
| 29 | I close to ENGAGED with Glass Beetle A and use Heavy Slash on it. | Erzähler | open_run_level | Declare movement to ENGAGED range so Heavy Slash can resolve on Beetle A. | first grotto | 95/84 | 34.9 s |
| 30 | I use Heavy Slash on Glass Beetle B. | Erzähler | open_run_level | Defeat Beetle B with Heavy Slash while it is in range. | first grotto | 95/84 | 10.9 s |
| 31 | I step to ENGAGED with Glass Beetle B and use Heavy Slash on it. | Erzähler | open_run_level | Close into reach and finish Beetle B with Heavy Slash. | first grotto | 95/84 | 26.6 s |
| 32 | I use Heavy Slash on Glass Beetle C. | Erzähler | open_run_level | Defeat Beetle C, now at SHORT... wait, it needs ENGAGED — actually attack it. | first grotto | 95/84 | 10.8 s |
| 33 | I step to ENGAGED with Glass Beetle C and use Heavy Slash on it. | Erzähler | open_run_level | Close into reach and finish Beetle C with Heavy Slash. | first grotto | 90/84 | 14.9 s |
| 34 | I finish it with Heavy Slash on Glass Beetle C. | Erzähler | open_run_level | Defeat the wounded Beetle C with Heavy Slash. | first grotto | 90/84 | 44.1 s |
| 35 | #assign STR 3 VIT 2 | System (Befehl) | open_run_level | Spend the 5 free stat points on STR and VIT. | first grotto | 90/84 | 2.2 s |
| 36 | I check the quest panel to see if the beetle culling contract has an active objective. | Erzähler | open_run_level | Verify whether the beetle cull is tied to an active Guild contract before heading out to s… | first grotto | 90/84 | 18.1 s |
| 37 | I press on deeper into the first grotto, staying alert for the mineral slimes. | Erzähler | open_run_level | Continue clearing the grotto's remaining threats while I still have daylight and decent HP… | round chamber | 90/84 | 136.4 s |
| 38 | I examine the abandoned satchel near the fork for traps or hazards before opening it. | Erzähler | open_run_level | Inspect and loot the old satchel before choosing a passage. | round chamber | 90/84 | 22.2 s |
| 39 | I take the rusted pick head and the parchment sketch, leave the cracked flask, and follow the slime track into the level passage with my swo… | Erzähler | open_run_level | Loot the safe satchel items and hunt the mineral slimes in the level passage. | low gallery | 90/84 | 27.8 s |
| 40 | I take the initiative and cast no spell — I charge Mineral Slime A and strike with Heavy Slash. | Erzähler | open_run_level | Engage Slime A with Heavy Slash before both can move. | low gallery | 90/84 | 20.8 s |
| 41 | I close the remaining distance to Mineral Slime A and strike with Heavy Slash. | Erzähler | open_run_level | Enter engagement range and attack Slime A. | low gallery | 90/84 | 22.6 s |
| 42 | I move into ENGAGED range with Mineral Slime A. If I reach it, I strike with Heavy Slash. | Erzähler | open_run_level | Declare movement into ENGAGED with Slime A, then attack conditionally. | low gallery | 90/84 | 16.4 s |
| 43 | I advance into ENGAGED range with Mineral Slime A. | Erzähler | open_run_level | Declare movement into ENGAGED range as a standalone action so the engine registers it befo… | low gallery | 90/84 | 13.2 s |
| 44 | I strike Mineral Slime A with Heavy Slash. | Erzähler | open_run_level | Attack Slime A now that it is ENGAGED. | low gallery | 81/84 | 15.5 s |
| 45 | I finish Mineral Slime A with Heavy Slash. | Erzähler | open_run_level | Kill the wounded Slime A before it and B wear me down. | low gallery | 77/84 | 15.2 s |
| 46 | I strike Mineral Slime B with Heavy Slash. | Erzähler | open_run_level | Kill the last slime with Heavy Slash. | low gallery | 73/84 | 11.1 s |
| 47 | I finish Mineral Slime B with Heavy Slash. | Erzähler | open_run_level | Kill the last slime. | low gallery | 73/84 | 18.6 s |
| 48 | #assign STR 3 VIT 2 | System (Befehl) | open_run_level | Spend the 5 level-up points on STR and VIT. | low gallery | 73/84 | 2.1 s |
| 49 | I continue along the level passage, following the dried glassy track toward the Glimmer Queen's deep. | Erzähler | open_run_level | Press on through the level passage toward the remaining threat, the Glimmer Queen. | level passage | 73/84 | 14.3 s |
| 50 | I follow the glassy track around the bend toward the crystal-bloomed deep, sword ready. | Erzähler | open_run_level | Approach the Glimmer Queen's chamber and engage her. | crystal-bloomed deep | 73/84 | 35.5 s |
| 51 | I open the fight with First Strike: Heavy Slash at the Glimmer Queen. | Erzähler | open_run_level | Engage the Queen with a Heavy Slash before she closes. | crystal-bloomed deep | 73/84 | 34.2 s |
| 52 | I advance across the open floor toward the Glimmer Queen, closing to ENGAGED range, and attack her with Heavy Slash as soon as I reach her. | Erzähler | open_run_level | Close the LONG gap and engage the Queen with Heavy Slash. | crystal-bloomed deep | 73/84 | 21.7 s |
| 53 | I run straight across the open floor along the glassy track, closing to ENGAGED range with the Glimmer Queen, sword raised. | Erzähler | open_run_level | Close to ENGAGED range with the Queen and attack. | crystal-bloomed deep | 73/84 | 17.7 s |
| 54 | I strike the Glimmer Queen with Heavy Slash. | Erzähler | open_run_level | Attack the Queen now that she's at ENGAGED range. | crystal-bloomed deep | 50/84 | 17.0 s |
| 55 | I strike the Glimmer Queen again with Heavy Slash. | Erzähler | open_run_level | Keep attacking the Queen with Heavy Slash while STA lasts. | crystal-bloomed deep | 39/84 | 53.0 s |
| 56 | I finish her with one more Heavy Slash. | Erzähler | open_run_level | Kill the Queen with a final Heavy Slash while STA lasts. | crystal-bloomed deep | 39/84 | 15.5 s |
| 57 | #assign VIT 2 STR 2 WIL 1 | System (Befehl) | open_run_level | Spend the 5 level-up points on VIT, STR and WIL. | crystal-bloomed deep | 39/84 | 2.2 s |
| 58 | I follow the level passage back out of the dungeon, heading for the exit and then the road back toward town. | Erzähler | open_run_level | Leave the cleared dungeon and return to town to sell loot and recover. | Glimmerdeep Grotto | 39/84 | 66.9 s |
| 59 | "Back to Glassmere — I've just cleared the Glimmer Queen and I'm hurt bad. If your cart's going my way, I'd gladly ride along." | Erzähler | open_run_level | Accept a ride toward town and recover there. | Glassmere | 39/84 | 101.5 s |
| 60 | "Thanks, Hobb — you saved me a long, bad walk." I climb down, thank the watchmen on my way through the gate, and head into town to find an i… | Erzähler | open_run_level | Enter Glassmere and obtain lodging so I can sleep and recover from 39/155 HP. | Lamp and Lantern inn | 39/84 | 29.1 s |
| 61 | "I can pay. I'll take the bed and the supper — twelve copper." I hand over the coins, eat what I can, and go up to sleep until morning. | Engine (Menü/Rückfrage) | open_run_level | Buy lodging and supper, then sleep overnight to recover HP and STA. | Lamp and Lantern inn | 39/84 | 11.6 s |
| 62 | #accept offer.t120.5 | System (Befehl) | open_run_level | Confirm the 12 cp purchase of bed and supper. | Lamp and Lantern inn | 39/84 | 2.1 s |
| 63 | #buy offer.t120.5 | System (Befehl) | open_run_level | Confirm the 12 cp bed and supper purchase with the correct command. | Lamp and Lantern inn | 39/84 | 2.2 s |
| 64 | Yes — book both, bed and supper, for 12 copper. | Engine (Menü/Rückfrage) | open_run_level | Confirm the 12 cp inn offer verbally as the System requested. | Lamp and Lantern inn | 39/84 | 7.0 s |
| 65 | I buy the bed and the supper, twelve copper, as offered. | Engine (Menü/Rückfrage) | open_run_level | Verbally confirm the inn purchase with explicit positions and price. | Lamp and Lantern inn | 39/84 | 7.3 s |
| 66 | I buy two positions from offer.t120.5: one bed for 8 copper and one supper for 4 copper, 12 copper total. | Erzähler | open_run_level | Complete the inn purchase by restating each offer position and price explicitly. | Lamp and Lantern inn | 39/84 | 17.9 s |
| 67 | I finish supper, go up to the second door, and sleep until morning. | Erzähler | open_run_level | Sleep overnight to recover HP and STA. | inn room, second door upstairs | 39/84 | 23.5 s |
| 68 | I lie back down on the straw mattress and sleep for a few more hours to recover. | Engine (Menü/Rückfrage) | open_run_level | Get an engine-confirmed rest to recover HP and STA. | inn room, second door upstairs | 39/84 | 4.1 s |
| 69 | I sleep until morning. | Erzähler | open_run_level | Get an engine-confirmed overnight rest to recover HP and STA. | inn room, second door upstairs | 52/88 | 17.0 s |
| 70 | I strap on my armor and gear, then head downstairs to the Guild hall to sell my beetle loot and check the contract board. | Erzähler | open_run_level | Gear up and return to the Guild for loot sales and a new contract. | Adventurers' Guild hall, Glassmere | 52/88 | 60.8 s |
| 71 | I sell everything to the clerk for the offered 205 copper. | Erzähler | open_run_level | Sell all beetle loot at the clerk's stated price. | Adventurers' Guild hall, Glassmere | 52/88 | 25.9 s |
| 72 | I take the Weir Adder contract slip from the board and ask the clerk to chalk me down as taken for it. | Erzähler | open_run_level | Accept the low-risk weir adder contract at the Guild. | Adventurers' Guild hall, Glassmere | 52/88 | 28.0 s |
| 73 | I head out of the Guild down Outflow Lane toward the south gate, then follow the river to Millward's fish traps and look for Millward among … | Erzähler | open_run_level | Travel to the fish traps and find Millward to point me at the adder. | the fish weirs at the Glassmere outflow | 52/88 | 69.8 s |
| 74 | I walk up to the shed on the bank and call out to the figure on the stakes, asking if he's Millward and where the grey adder is sunning. | Erzähler | open_run_level | Find Millward at the weirs and get pointed to the adder. | Millward's shed on the bank | 52/88 | 127.9 s |
| 75 | I stay on the bank, keep out of the mud and shallows, and throw a stone to draw the adder off the mud spit into open water where I can strik… | Erzähler | open_run_level | Lure the adder into the open and fight from the bank while badly wounded. | Millward's shed on the bank | 52/88 | 36.2 s |
| 76 | I wait on the bank behind the shed's corner, sword ready, and throw another stone at the water near the adder to goad her into striking towa… | Erzähler | open_run_level | Lure the adder toward the bank so I can strike without wading in badly wounded. | Millward's shed on the bank | 52/88 | 29.1 s |
| 77 | I meet her charge with a Heavy Slash as she comes up the mud slope. | Erzähler | open_run_level | Strike the adder as it reaches dry ground. | Millward's shed on the bank | 52/88 | 16.8 s |
| 78 | I hold my ground and strike with a Heavy Slash as she comes within reach. | Erzähler | open_run_level | Land the Heavy Slash once the adder closes into ENGAGED range. | Millward's shed on the bank | 52/88 | 15.3 s |
| 79 | I strike with a Heavy Slash as she strikes at me. | Erzähler | open_run_level | Land the Heavy Slash now that the adder is ENGAGED. | Millward's shed on the bank | 52/88 | 17.1 s |
| 80 | I thank Millward and travel back to the Guild hall in Caelreth to turn in the adder contract. | Erzähler | open_run_level | Return to the Guild hall and turn in the completed adder contract. | Adventurers' Guild hall, Glassmere | 52/88 | 28.9 s |
| 81 | "Where can I get these ribs seen to — is there a healer or a bathhouse in town? And a bed for the night, once I'm patched up." | Erzähler | open_run_level | Ask the clerk about healing and lodging in Glassmere. | Adventurers' Guild hall, Glassmere | 52/88 | 16.3 s |
| 82 | "Nothing else at the desk, thank you. I'll see Mother Hesse first, then a contract after I'm mended." | Erzähler | open_run_level | Finish at the desk and head to Mother Hesse to have the ribs treated. | Adventurers' Guild hall, Glassmere | 52/88 | 22.0 s |
| 83 | I knock on the blue door and ask Mother Hesse to look at my torn ribs — the Guild sent me. | Erzähler | open_run_level | Have Mother Hesse treat the torn ribs. | Adventurers' Guild hall, Glassmere | 52/88 | 22.5 s |
| 84 | "Six coppers for the binding and brew — done. I'll take the soup too, that's two more." | Erzähler | open_run_level | Pay Mother Hesse eight coppers for treatment and a meal. | Adventurers' Guild hall, Glassmere | 52/88 | 23.6 s |
| 85 | I eat the soup and drink the willow-bark brew, then rest at the Sleeping Dog until morning. | Erzähler | open_run_level | Recover: finish the meal and get a night's lodging and sleep. | Adventurers' Guild hall, Glassmere | 155/88 | 112.4 s |
| 86 | I walk to the Guild hall's contract board and look over the available contracts. | Erzähler | open_run_level | Check the board for a new achievable contract now that I'm fully healed. | Adventurers' Guild hall, Glassmere | 155/88 | 28.0 s |
| 87 | I take the Grey Weir Adder slip to the clerk and ask to accept the contract. | Erzähler | open_run_level | Accept the adder cull contract at the Guild desk. | Adventurers' Guild hall, Glassmere | 155/88 | 13.8 s |
| 88 | I head out the east water-gate and follow the outflow channel to the fish weirs, then ask the weir-keepers where the adder has been seen. | Erzähler | open_run_level | Travel to the weirs and get pointed to the adder's spot. | the fish weirs at the Glassmere outflow | 155/88 | 62.2 s |
| 89 | I head down the towpath to the middle weir and search the reeds on the east bank for the adder. | Erzähler | open_run_level | Find the grey weir adder near the middle weir's east-bank reeds. | the middle weir | 155/88 | 21.9 s |
| 90 | I follow the trampled slot into the reeds slowly, sword drawn, keeping my eyes on the flattened mud ahead of me. | Erzähler | open_run_level | Search the trampled slot in the east-bank reeds for the adder. | the reed hollow at the middle weir | 155/88 | 22.8 s |
| 91 | I strike first, swinging a Heavy Slash at the adder's raised head before it can lunge. | Erzähler | open_run_level | Attack the adder with Heavy Slash to start the fight. | the reed hollow at the middle weir | 155/88 | 13.8 s |
| 92 | I step into ENGAGED range and swing a Heavy Slash at the adder's head. | Erzähler | open_run_level | Close to ENGAGED and attack the adder with Heavy Slash. | the reed hollow at the middle weir | 155/88 | 17.2 s |
| 93 | I head back through the water-gate to the Guild hall and turn in the adder skin and fangs for the cull contract's reward. | Erzähler | open_run_level | Turn in the completed adder cull at the Guild hall. | Adventurers' Guild hall, Glassmere | 155/88 | 16.7 s |
| 94 | I gather the coins and look over the contract board for another Novice job I can take. | Erzähler | open_run_level | Collect reward and pick a new Guild contract. | Adventurers' Guild hall, Glassmere | 155/88 | 15.1 s |
| 95 | "The stranglewillow creeper at the Tannery Ponds, please." I take the contract slip once she registers it. | Erzähler | open_run_level | Accept the creeper cull contract at the Guild desk. | Adventurers' Guild hall, Glassmere | 155/88 | 13.4 s |
| 96 | I head out through the south gate and follow the tanner's track to the Tannery Ponds to hunt the stranglewillow creeper. | Erzähler | open_run_level | Travel south to the Tannery Ponds for the active creeper cull contract. | the Tannery Ponds south of Glassmere | 155/88 | 23.2 s |
| 97 | I approach the second pool and attack the stranglewillow creeper lurking under the leaning willow, opening with a Heavy Slash once I'm in EN… | Engine (Menü/Rückfrage) | open_run_level | Engage and attack the creeper at the willow. | the Tannery Ponds south of Glassmere | 155/88 | 7.3 s |
| 98 | I walk toward the leaning willow at the second pool and search the churned mud beneath it to draw the creeper out. | Erzähler | open_run_level | Find and engage the creeper so it becomes a valid target. | the Tannery Ponds south of Glassmere | 155/88 | 26.7 s |
| 99 | I attack the stranglewillow creeper with a Heavy Slash. | Erzähler | open_run_level | Engage the now-present creeper as a valid target and open combat with Heavy Slash. | the Tannery Ponds south of Glassmere | 102/88 | 15.2 s |
| 100 | I finish it with a Basic Attack on the stranglewillow creeper. | Erzähler | open_run_level | Kill the wounded creeper to complete the cull contract. | the Tannery Ponds south of Glassmere | 75/88 | 14.7 s |
| 101 | I strike the stranglewillow creeper again with a Basic Attack to finish it. | Erzähler | open_run_level | Kill the creeper (4 HP left) with a Basic Attack. | the Tannery Ponds south of Glassmere | 75/88 | 19.3 s |
| 102 | I head back north to Glassmere and, once I reach the Guild hall, report the completed creeper cull to the clerk to collect the 90 copper rew… | Erzähler | open_run_level | Return to the Guild hall and turn in the finished creeper contract for the reward. | Adventurers' Guild hall, Glassmere | 75/88 | 21.1 s |
| 103 | #assign STR 3 VIT 2 | System (Befehl) | open_run_level | Spend the 5 level-up stat points on STR and VIT. | Adventurers' Guild hall, Glassmere | 75/88 | 2.3 s |
| 104 | I walk to Mother Hesse's house on Chandler's Lane, the one with the blue door, and knock to have my ribs mended. | Erzähler | open_run_level | Recover from the wounded state at Mother Hesse's. | Mother Hesse's house | 75/88 | 85.7 s |
| 105 | I pay the four silver and let her set the ribs and rinse the gall-burn. | Erzähler | open_run_level | Pay Mother Hesse's 4 silver fee to heal the wounded state. | Mother Hesse's house | 75/88 | 17.8 s |
| 106 | I thank her and head to the nearest cheap inn, take a room, and sleep until morning to recover. | Erzähler | open_run_level | Rest at an inn to restore HP after healing. | the Sleeping Dog | 75/88 | 31.0 s |
| 107 | I buy the room for the night from the innkeeper, then sleep until morning. | Erzähler | open_run_level | Actually purchase lodging and sleep, since the HUD still shows wounded and HP 75/175 despi… | the Sleeping Dog | 175/88 | 18.0 s |
| 108 | I eat the breakfast, then head to the Guild hall and look over the contract board for a new job I can take. | Erzähler | open_run_level | Recover done; pick a new Guild contract. | the Sleeping Dog | 175/88 | 22.9 s |
| 109 | I climb the steps and enter the Guild hall, then read the contract board for a job I can take. | Erzähler | open_run_level | Read the Guild contract board and pick a new contract. | Adventurers' Guild hall, Glassmere | 175/88 | 78.7 s |
| 110 | I go to the front desk and ask the clerk to register me for the stranglewillow creeper contract — three creepers at the Tannery Ponds for 90… | Erzähler | open_run_level | Take the creeper cull contract at the desk. | Adventurers' Guild hall, Glassmere | 175/88 | 27.9 s |
| 111 | I take the slip and head south out of the city to the Tannery Ponds to hunt the stranglewillow creepers. | Erzähler | open_run_level | Travel to the Tannery Ponds and start the creeper cull. | the Tannery Ponds south of Glassmere | 175/88 | 69.0 s |
| 112 | I move along the near bank toward the stripped willow, watching the reeds and water for movement, and probe the reeds with my sword to flush… | Erzähler | open_run_level | Find and attack a stranglewillow creeper at the near bank. | the Tannery Ponds south of Glassmere | 175/88 | 28.2 s |
| 113 | I grip my sword and strike at the drifting creeper leaf mat at the willow roots, ready for the creeper to strike. | Engine (Menü/Rückfrage) | open_run_level | Provoke and attack the creeper hiding at the willow roots. | the Tannery Ponds south of Glassmere | 175/88 | 6.3 s |
| 114 | I wait at the edge of the flattened reeds and prod the drifting leaf mat at the roots with the tip of my sword, trying to draw the creeper o… | Erzähler | open_run_level | Provoke the hidden creeper into revealing itself as a targetable actor. | the Tannery Ponds south of Glassmere | 175/88 | 29.9 s |
| 115 | I strike at the rearing creeper with Heavy Slash. | Erzähler | open_run_level | Attack the now-engaged creeper with my known skill. | the Tannery Ponds south of Glassmere | 101/88 | 17.7 s |
| 116 | I finish it with another Heavy Slash at the wounded stem. | Erzähler | open_run_level | Kill Creeper B with Heavy Slash for contract kill 1/3. | the Tannery Ponds south of Glassmere | 64/88 | 22.6 s |
| 117 | I finish it with a Basic Attack at the nearly severed stem. | Erzähler | open_run_level | Kill Creeper B for contract kill 1/3. | the Tannery Ponds south of Glassmere | 64/88 | 18.0 s |
| 118 | #assign STR 2 VIT 3 | System (Befehl) | open_run_level | Spend the five level-up stat points on Strength and Vitality to hit harder and survive the… | the Tannery Ponds south of Glassmere | 64/88 | 2.4 s |
| 119 | I call across the pond to the tanner, telling him I've just cut down one of the creepers and asking if he's seen more of them near the secon… | Erzähler | open_run_level | Talk to the tanner and locate the remaining two creepers for the contract. | the Tannery Ponds south of Glassmere | 64/88 | 20.8 s |
| 120 | I accept the tanner's offer to sit in the shed and drink some water, resting until my wounds stop pounding. | Engine (Menü/Rückfrage) | open_run_level | Recover a little in the shed before hunting the north pond creepers. | the Tannery Ponds south of Glassmere | 64/88 | 8.6 s |
| 121 | I rest in the shed for two hours, drinking water. | Erzähler | open_run_level | Rest two hours in the shed to recover HP before hunting the north pond creepers. | the Tannery Ponds south of Glassmere | 104/88 | 14.7 s |
| 122 | I head to the north pond and search the reeds and water for the smaller creepers. | Erzähler | open_run_level | Find the next creeper at the north pond for contract kill 2/3. | the north pond of the Tannery Ponds | 104/88 | 21.0 s |
| 123 | I wade toward the bent glossy reed a dozen paces in and strike it down with Heavy Slash. | Erzähler | open_run_level | Attack the creeper hiding in the north pond reed bed for contract kill 2/3. | the north pond of the Tannery Ponds | 104/88 | 22.9 s |
| 124 | I hold my swing on the bent reed and turn to face the disturbance on my right, sword raised, waiting for the creature to show itself before … | Erzähler | open_run_level | Face the incoming creeper instead of overcommitting to the bent reed. | the north pond of the Tannery Ponds | 104/88 | 60.8 s |
| 125 | I meet the charging creeper with Heavy Slash as it strikes. | Erzähler | open_run_level | Strike the engaged creeper with Heavy Slash for contract kill 2/3. | the north pond of the Tannery Ponds | 70/88 | 19.3 s |
| 126 | I finish Creeper C with a Heavy Slash. | Erzähler | open_run_level | Kill the 7 HP creeper for contract kill 2/3. | the north pond of the Tannery Ponds | 70/88 | 79.5 s |
| 127 | I wade to the bent reed where the second creeper was waking and strike it with Heavy Slash. | Engine (Menü/Rückfrage) | open_run_level | Hunt the third creeper at the bent reed for contract kill 3/3. | the north pond of the Tannery Ponds | 70/88 | 4.8 s |
| 128 | I search the reed bed around the bent reed for the third creeper, sword ready. | Erzähler | open_run_level | Find the third creeper's actual location since it is no longer targetable at the bent reed… | the north pond of the Tannery Ponds | 70/88 | 21.1 s |
| 129 | I strike Creeper D's glossy body with Heavy Slash before it can uncoil. | Erzähler | open_run_level | Attack the newly engaged Creeper D for the third contract kill. | the north pond of the Tannery Ponds | 13/88 | 43.3 s |
| 130 | I finish Creeper D with a Basic Attack. | Erzähler | open_run_level | Kill the 27 HP creeper for the third contract kill. | the north pond of the Tannery Ponds | 13/88 | 18.6 s |
| 131 | I wade back to dry ground and head for the Guild hall to turn in the creeper contract. | Erzähler | open_run_level | Return to the Guild hall and turn in the completed creeper contract. | Adventurers' Guild hall, Glassmere | 13/88 | 54.0 s |
| 132 | #assign STR 2 VIT 3 | System (Befehl) | open_run_level | Spend the 5 level-up stat points on STR and VIT, then seek recovery. | Adventurers' Guild hall, Glassmere | 13/88 | 2.5 s |
| 133 | I ask the clerk about lodging or a healer in town, since I'm badly hurt and need rest before taking another contract. | Erzähler | open_run_level | Find recovery at Level 7 with 13/210 HP before choosing the next contract. | Adventurers' Guild hall, Glassmere | 13/88 | 33.0 s |
| 134 | I head to Cooper's Row and find Maida Cotton's blue door with the dried herbs, and ask her to treat my injuries. | Erzähler | open_run_level | Get healed by Maida before resting, as the clerk advised. | Maida Cotton's healer house | 13/88 | 95.8 s |
| 135 | I pay Maida the ten silver for the full treatment — poultice, binding, draught, and the cot — and let her treat me. | Erzähler | open_run_level | Pay for and receive Maida's healing and rest. | Maida Cotton's healer house | 13/88 | 16.8 s |
| 136 | I sleep on Maida's cot through the worst of the day, as she instructed, and wake only when she clears me. | Engine (Menü/Rückfrage) | open_run_level | Sleep under Maida's supervision to recover HP. | Maida Cotton's healer house | 13/88 | 5.1 s |
| 137 | I sleep until she clears me — say, until evening. | Erzähler | open_run_level | Name a sleep duration so the cot rest can resolve and HP recover. | Maida Cotton's healer house | 59/88 | 32.9 s |
| 138 | I thank Maida and head to the Drowned Ox for a bed and stew, then sleep until morning. | Erzähler | open_run_level | Get lodging and overnight rest to continue recovering HP. | the Drowned Ox | 59/88 | 24.6 s |
| 139 | I pay the innkeeper for the stew and the room, eat, and sleep until morning. | Erzähler | open_run_level | Buy lodging and food, then recover overnight. | the Drowned Ox | 225/88 | 38.6 s |
| 140 | I head to the Glassmere Guild hall and look over the contract board for a job I can take. | Erzähler | open_run_level | Pick a new Guild contract now that HP is fully recovered. | Adventurers' Guild hall, Glassmere | 225/88 | 27.3 s |
| 141 | I take the Stranglewillow Creeper notice to the ink-fingered clerk and ask him to register the contract for me. | Erzähler | open_run_level | Register the creeper cull contract (120 cp reward) at the Guild counter. | Adventurers' Guild hall, Glassmere | 225/88 | 15.9 s |
| 142 | I leave through the south gate and follow the tanners' track toward the Tannery Ponds to hunt the stranglewillow creeper. | Erzähler | open_run_level | Travel to Tannery Ponds to fulfill the active creeper contract. | the Tannery Ponds south of Glassmere | 225/88 | 23.3 s |
| 143 | I thank the tanner and head to the left-hand pond where the reeds grow tall, watching the willow whips, and attack the stranglewillow creepe… | Erzähler | open_run_level | Engage the stranglewillow creeper to complete the active contract. | the left-hand pond of the Tannery Ponds | 225/88 | 20.3 s |
| 144 | I keep clear of the whip reach and strike at the rooted bole where the whips meet it. | Erzähler | open_run_level | Fight the stranglewillow creeper, aiming at its rooted bole. | the left-hand pond of the Tannery Ponds | 225/88 | 33.6 s |
| 145 | I step in across the reed line to close into sword reach and strike the bole with Heavy Slash. | Erzähler | open_run_level | Close to ENGAGED range and attack the creeper's bole. | the left-hand pond of the Tannery Ponds | 170/88 | 25.4 s |
| 146 | I finish it with a Basic Attack at the bole. | Erzähler | open_run_level | Kill the wounded creeper with a Basic Attack. | the left-hand pond of the Tannery Ponds | 170/88 | 20.9 s |
| 147 | "It does — the Guild pays on the slip once it's registered as done. I'll head back and turn it in now." | Erzähler | open_run_level | Answer the tanner and return to the Guild hall to turn in the completed creeper contract. | Adventurers' Guild hall, Glassmere | 170/88 | 39.0 s |
| 148 | "Cleared at the Tannery Ponds, both ponds. What's on the board for a Novice today?" | Erzähler | open_run_level | Confirm the payout and ask for the next Guild contract from the board. | Adventurers' Guild hall, Glassmere | 170/88 | 41.3 s |
| 149 | "I'll take the weir adder contract, and one of those Primer of Guard manuals too." I accept the adder slip and buy the primer, then read it … | Erzähler | open_run_level | Take the grey weir adder contract and buy the Guard primer to learn a new skill. | Adventurers' Guild hall, Glassmere | 170/88 | 21.0 s |
| 150 | "I already know Guard — keep the primer. I'll take the adder job now." I head to the fish weirs at the Glassmere outflow and search the mill… | Erzähler | open_run_level | Skip the redundant Guard primer and hunt the weir adder for the active contract. | the fish weirs at the Glassmere outflow | 170/88 | 20.1 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 2 (notiert vor Zug 3): Creation complete: Level 1 Warrior with Heavy Slash and Guard, starter gear equipped, 5 silver.
- zu Zug 3 (notiert vor Zug 4): Arrived in Glassmere and reached the Guild hall; not yet registered (Guild Rank — on HUD).
- zu Zug 4 (notiert vor Zug 5): Registration requires 2 silver fee and signing the ledger; a measuring stone sets Guild Rank for free.
- zu Zug 5 (notiert vor Zug 6): Registration confirmed: Guild Rank Novice, plate received, 3 silver left. Board empty this morning; clerk mentioned academy crystal beetle culling at Glimmerdeep grottos as recurring work.
- zu Zug 6 (notiert vor Zug 7): Primer shop offered at Guild (120 cp each) — not affordable now. Board empty; only lead is the private sheep watch on Mantle Lane.
- zu Zug 7 (notiert vor Zug 8): Private watch job accepted offer: copper per sheep at sunrise, paid after, no Guild paper. It comes only when a lone watcher sits; two people or fire deter it.
- zu Zug 8 (notiert vor Zug 9): Daylight search for tracks failed (PER check); no sign of the predator. Watch runs dusk to sunrise, paid a copper per surviving sheep; fire or two people deters it, a lone watcher draws it.
- zu Zug 9 (notiert vor Zug 10): Lantern and flint received; watch has begun at 18:15. Note: the job pays only if the fire-or-two-people deterrent is met, so keeping the lantern lit matters.
- zu Zug 10 (notiert vor Zug 11): Watch completed uneventfully; lantern stayed lit, all sheep alive at dawn. No XP or pay shown yet — payment is a copper per surviving sheep, so I need the count confirmed.
- zu Zug 11 (notiert vor Zug 12): Pay received: 22 coppers for the watch, though the HUD still shows only 3 Silver and no XP — coin may not be tracked below silver. Bette offered a second night; rumor points to Thursday grain-guard work at the Guild.
- zu Zug 12 (notiert vor Zug 13): Second watch promised for tonight at dusk. Board was thin: lamp oil delivery, rat culling, crate loading; no grain work posted yet, though a courier just arrived with fresh slips.
- zu Zug 13 (notiert vor Zug 14): Previous attempt failed because I was still at the stables; the board is at the Guild hall, so I now name the destination explicitly.
- zu Zug 14 (notiert vor Zug 15): Rat culling was signed by two wharf boys within the half-hour; the whole Novice board was cleared, new slips promised by midday. Clerk offered private crate-loading at the market square — pays by the crate, no Guild credit.
- zu Zug 15 (notiert vor Zug 16): Foreman offered 1 cp per crate with about sixty left; clerk will hold a sword-suitable Novice slip until midday.
- zu Zug 16 (notiert vor Zug 17): The System treated the handshake as a shop transaction needing explicit acceptance; no pay or work was recorded yet.
- zu Zug 17 (notiert vor Zug 18): System flagged a price mismatch: narrator's foreman says half a copper, posted shop offer lists 1 cp. I chose the cheaper quoted rate; watching whether the work and pay now register.
- zu Zug 18 (notiert vor Zug 19): System looped through three clarify prompts before locking the acceptance wording; still no confirmation that pay or work is recorded yet.
- zu Zug 19 (notiert vor Zug 20): Crate work completed: 63 crates, paid 32 copper (HUD shows 2 Silver 9 Copper). The System logged the labor as a purchase of -1 copper — an oddity, but the pay is recorded.
- zu Zug 20 (notiert vor Zug 21): Crate pay confirmed: HUD shows 2 Silver 9 Copper after 63 crates. Board still empty of Novice work; the clerk says the midday sort isn't done yet.
- zu Zug 21 (notiert vor Zug 22): Midday sort confirmed: no Novice contracts on the board; clerk offered Glimmerdeep beetle culling as a non-contract alternative where kills and crystal loot are mine to keep.
- zu Zug 22 (notiert vor Zug 23): No Novice contracts after the midday sort; clerk confirmed Glimmerdeep culling as non-contract work with sellable crystal. Leaving for Glimmerdeep now, arriving mid-afternoon.
- zu Zug 23 (notiert vor Zug 24): No Novice contracts available; proceeding with the non-contract Glimmerdeep culling as the clerk described.
- zu Zug 24 (notiert vor Zug 25): Arrived at Glimmerdeep by mid-afternoon as the clerk said; dungeon gate panel confirms Rank F, 10 copper fee, and culling access for registered Guild members.
- zu Zug 25 (notiert vor Zug 26): Entered Glimmerdeep, paid 10 copper (19 cp left). Three glass beetles grazing in the first grotto; rules: outer grottos only, out by dark.
- zu Zug 26 (notiert vor Zug 27): Attack was refused: no valid target — the active scene still shows Ostrey at the gate, so the dungeon entry likely needs to be explicitly confirmed.
- zu Zug 27 (notiert vor Zug 28): Scene panel now shows three named beetles (A/B/C) with HP bars, so targets are addressable; my Heavy Slash on Beetle A is mid-swing but no damage result confirmed yet.
- zu Zug 28 (notiert vor Zug 29): Heavy Slash was refused because the beetle was at SHORT range; range bands matter. Beetle B is now MEDIUM, C still LONG.
- zu Zug 29 (notiert vor Zug 30): Combat resolved: Beetle A defeated in one Heavy Slash (31 dmg, first strike). Beetle B now at SHORT, C at MEDIUM; STA 93/100.
- zu Zug 30 (notiert vor Zug 31): Range bands gate every attack: SHORT targets need a declared move to ENGAGED first, even in my own turn.
- zu Zug 31 (notiert vor Zug 32): Beetle C moved to SHORT; HUD lists attacks only at ENGAGED, so a declared move to ENGAGED may be needed first.
- zu Zug 32 (notiert vor Zug 33): Range rule confirmed again: SHORT targets require a declared move to ENGAGED in the same turn; two beetles already defeated.
- zu Zug 33 (notiert vor Zug 34): Beetle C at 11 HP, ENGAGED, so Heavy Slash should finish it; took 5 damage from its bite.
- zu Zug 34 (notiert vor Zug 35): Level 2 confirmed, +168 XP, loot: 6 chitin plates and 1 venom gland. Free 5 stat points available.
- zu Zug 35 (notiert vor Zug 36): Level 2 confirmed with STR/VIT assigned; HP 90/105 lightly wounded, STA 72. Beetles drop loot but no active contract is listed in the HUD.
- zu Zug 36 (notiert vor Zug 37): HP shows 90/115 after the VIT assignment; 3 slimes and the Glimmer Queen remain for the level clear.
- zu Zug 37 (notiert vor Zug 38): Found an old satchel at a fork: level passage (wet mineral smell, likely slimes) or corkscrew down toward the stream. HP 90/115, STA 72.
- zu Zug 38 (notiert vor Zug 39): Satchel searched successfully: pick head, cracked flask, and a sketch warning of 'them' in the level passage; a slime track confirms slimes that way. HP 90/115, STA 72 going in.
- zu Zug 39 (notiert vor Zug 40): Two Medium slimes (58/50 HP) engaged in the low gallery; ground is slick, so footwork may matter. Level clear still requires slimes plus the Glimmer Queen.
- zu Zug 40 (notiert vor Zug 41): The attack was refused for range; must declare movement into ENGAGED before swinging.
- zu Zug 41 (notiert vor Zug 42): Two refusals for range; combat requires explicit declared movement into ENGAGED before any swing.
- zu Zug 42 (notiert vor Zug 43): Third range refusal even though I declared moving into ENGAGED; the conditional 'if I reach it, strike' phrasing may have voided the movement, so this turn is a pure movement declaration with no attack attached.
- zu Zug 43 (notiert vor Zug 44): Movement succeeded this time: Slime A moved MEDIUM→ENGAGED (HUD shows ENGAGED, narration says SHORT). One pace away, so a plain attack should now register.
- zu Zug 44 (notiert vor Zug 45): First Strike worked: Heavy Slash dealt 35, Slime A at 23 HP; both slimes now ENGAGED and chipping 4–5 corrosion per round.
- zu Zug 45 (notiert vor Zug 46): Slime A defeated; Slime B at full 50 HP, ENGAGED. STA 58, so ~8 more Heavy Slashes possible; corrosion chipping ~4-5 per round.
- zu Zug 46 (notiert vor Zug 47): Slime B at 17 HP; one more Heavy Slash (30–36) should defeat it. STA fine at 51, HP 73.
- zu Zug 47 (notiert vor Zug 48): Level 3 confirmed after slimes defeated, +168 XP; HP max shows 125 in HUD versus 115 in the combat line (minor contradiction, HUD authoritative).
- zu Zug 48 (notiert vor Zug 49): Stats assigned: STR 16, VIT 14, points spent. All five threats on level 1 dealt with except the Glimmer Queen; HP still wounded at 73/125.
- zu Zug 49 (notiert vor Zug 50): HP max now reads 135 in HUD versus 115 in the last combat line; wounded at 73 HP with STA 44 going into the Queen fight.
- zu Zug 50 (notiert vor Zug 51): Queen revealed at 108 HP, LONG fight; HP 73/135, STA 44 — enough for maybe 6 Heavy Slashes, will need Guard turns to recover.
- zu Zug 51 (notiert vor Zug 52): First Strike failed correctly: Queen at LONG, Heavy Slash only reaches ENGAGED. She didn't charge; must cross ~20 open strides, likely taking a charge attack while wounded at 73/135 HP.
- zu Zug 52 (notiert vor Zug 53): Two refusals for attacks at LONG range; now declaring pure movement across the open floor first, expecting her braced charge.
- zu Zug 53 (notiert vor Zug 54): Movement worked: Queen now ENGAGED, stroke is mine to begin; STA 44 limits Heavy Slashes, may need Guard turns to recover.
- zu Zug 54 (notiert vor Zug 55): Round 1 resolved: my Heavy Slash hit for 35 (73/108), her two bites took me to 50 HP. STA 37 allows about four more Heavy Slashes; Guard recovery may be needed after.
- zu Zug 55 (notiert vor Zug 56): Queen at 35 HP, one Heavy Slash (35-43) should end it; my HP 39/135, STA 30 — cutting it close but viable.
- zu Zug 56 (notiert vor Zug 57): Queen defeated: +300 XP, Level 4, loot includes a Return Stone and 3 Queen chitin plates plus a venom gland. Level 1 of the dungeon is CLEARED; HP 39/145, badly wounded.
- zu Zug 57 (notiert vor Zug 58): Level 4 assigned (VIT 17, STR 19, WIL 8). Dungeon level 1 fully CLEARED this cycle; HP still 39/145, so recovery is the priority before any further dungeon work.
- zu Zug 58 (notiert vor Zug 59): HUD updated HP to 39/155 and MP 88 after level-up. Narrator placed me still at the grotto exit at 19:08 despite my travel order; an old carter now offers company on the road west.
- zu Zug 59 (notiert vor Zug 60): Hobb's cart got me to Glassmere by 20:08. HP still 39/155 (badly wounded), STA 23/100 — lodging and overnight sleep are the priority; loot sales can follow in the morning.
- zu Zug 60 (notiert vor Zug 61): Shop offer confirmed: bed 8 cp, supper 4 cp; I have 1s 9c, enough for both plus overnight recovery next.
- zu Zug 61 (notiert vor Zug 62): System asked for explicit confirmation of the 12 cp inn purchase; nothing was spent yet.
- zu Zug 62 (notiert vor Zug 63): #accept was rejected as unknown; retrying the pending inn offer with #buy.
- zu Zug 63 (notiert vor Zug 64): #accept and #buy are both unknown commands; the System wants a plain verbal confirmation of offer.t120.5.
- zu Zug 64 (notiert vor Zug 65): System asked me to restate the offer positions and price; nothing spent yet.
- zu Zug 65 (notiert vor Zug 66): The System rejected both #buy and #accept and twice demanded an itemized verbal restatement; trying explicit positions and prices now.
- zu Zug 66 (notiert vor Zug 67): Purchase finally confirmed after itemized restatement (-12 cp); now at 7 copper, HP 39/155, badly wounded.
- zu Zug 67 (notiert vor Zug 68): Narration showed a full night's sleep, but the System refused the action ('arrival pending') and the HUD confirms no recovery: HP 39/155, STA 23/100 on Day 3, 07:08. Retrying an explicit rest.
- zu Zug 68 (notiert vor Zug 69): System rejected 'sleep until morning' asking for an explicit duration/end; retrying with the named end point. Narration already showed a full night's sleep but HUD still shows HP 39/155, STA 23/100.
- zu Zug 69 (notiert vor Zug 70): Recovery finally engine-confirmed after naming an explicit end point ('until morning'): HP 52/155, STA 44/100. Still badly wounded; partial rest works but full recovery may need more rest or healing.
- zu Zug 70 (notiert vor Zug 71): Clerk made a concrete offer: 205 copper for the whole pouch (plates, glands, gel, core). Still badly wounded (HP 52/155); will pick a low-risk contract next.
- zu Zug 71 (notiert vor Zug 72): Loot sale confirmed: +205 copper, now 212. Still badly wounded (HP 52/155); picking the cheap, close adder contract over the grotto.
- zu Zug 72 (notiert vor Zug 73): Contract confirmed active in HUD (0/1). Still badly wounded (HP 52/155), so I'll fight from the bank, not the shallows.
- zu Zug 73 (notiert vor Zug 74): Arrival at the weirs is confirmed by the HUD; the previous 'arrival pending' refusal just needed the interaction split from travel.
- zu Zug 74 (notiert vor Zug 75): Adder confirmed as a target (HP 20/20, MEDIUM); Millward warned the mud bogs to the knee and the snake is quick in water, so I'll fight from the bank rather than wade in.
- zu Zug 75 (notiert vor Zug 76): Adder was flushed into the open shallows by the first stone; Millward warns the run has a soft knee-deep bottom, so I'll keep drawing her toward dry ground.
- zu Zug 76 (notiert vor Zug 77): Adder lured onto the mud slope and closing; fight starts on dry bank as planned.
- zu Zug 77 (notiert vor Zug 78): Heavy Slash failed on range: adder was still SHORT. She's nearly closed now; strike once she's ENGAGED.
- zu Zug 78 (notiert vor Zug 79): HUD now shows the adder as ENGAGED; the two earlier swings failed only on range.
- zu Zug 79 (notiert vor Zug 80): Adder defeated with one Heavy Slash on the first strike turn (50 damage); +24 XP, loot: adder skin and two fangs. Quest shows 1/1 defeated, ready to turn in. HP 52/155, badly wounded.
- zu Zug 80 (notiert vor Zug 81): Contract paid out: +2s5c and +46 XP, quest completed and slip filed. HP 52/155, badly wounded; healing and rest are the priority before taking another contract.
- zu Zug 81 (notiert vor Zug 82): Turn-in already completed last turn; clerk gave directions to healer (Mother Hesse, Chandler's Lane) and lodging (Sleeping Dog, 2c).
- zu Zug 83 (notiert vor Zug 84): HP 52/155, badly wounded; healer offers binding plus willow-bark brew for 6c and soup for 2c more — affordable at 2g3s7c.
- zu Zug 84 (notiert vor Zug 85): Treatment and meal paid (8c); HP still 52/155 per HUD, so recovery must come from rest. HUD oddly still lists the Guild hall as location while I'm at Mother Hesse's.
- zu Zug 85 (notiert vor Zug 86): Recovery confirmed: HP/STA fully restored after meal and night's sleep. HUD oddly places me at the Guild hall though I slept at the Sleeping Dog.
- zu Zug 86 (notiert vor Zug 87): Fully healed overnight; board offers adder (lvl1), creeper (lvl5), boar (lvl9), lynx (lvl13), grotto (lvl1). Taking the achievable adder repeat.
- zu Zug 87 (notiert vor Zug 88): Adder contract confirmed ACTIVE (0/1). Also noting the Guild sells skill primers (Strike, Bolt, Guard, Ward, Mend) at 120 cp each — Guard already known.
- zu Zug 89 (notiert vor Zug 90): Arrival at the middle weir confirmed; fresh belly-drag and tail mark mark the adder's path into dense reeds.
- zu Zug 90 (notiert vor Zug 91): Adder found coiled and fed in the reed hollow, HP 20/20; it is posturing to strike.
- zu Zug 91 (notiert vor Zug 92): First attack failed on range: adder was at SHORT, Heavy Slash only reaches ENGAGED; it closed distance and is now ENGAGED but a step beyond clean reach.
- zu Zug 92 (notiert vor Zug 93): Adder defeated in one Heavy Slash (44 damage, +24 XP); loot auto-collected, quest ready for turn-in.
- zu Zug 93 (notiert vor Zug 94): Adder cull turned in for 25 copper and 46 XP; now Level 4 at 176/400 XP, no active quests.
- zu Zug 94 (notiert vor Zug 95): Board offers creeper (lvl 5), boar sow (lvl 9), lynx (lvl 13), grotto (lvl 1). Creeper is the nearest-fit next step; verify it shows ACTIVE before travelling.
- zu Zug 95 (notiert vor Zug 96): Creeper contract confirmed ACTIVE in HUD (0/1 defeated); clerk says no trophy needed, the READY seal is proof enough. STA at 93/100, otherwise in good shape.
- zu Zug 96 (notiert vor Zug 97): HUD confirms creeper contract active 0/1; the willow by the second pool shows clear creeper sign.
- zu Zug 97 (notiert vor Zug 98): Attack refused: creeper not yet a valid target in scene; only the tanner is present at LONG. Need to provoke or locate it first.
- zu Zug 98 (notiert vor Zug 99): The creeper drew itself out and is now ENGAGED (HP 80/80); my earlier attack was refused only because it wasn't in scene yet.
- zu Zug 99 (notiert vor Zug 100): Heavy Slash landed for 43; creeper at 37/80, my HP 102/155. Basic Attack (33–40) should suffice.
- zu Zug 100 (notiert vor Zug 101): Creeper at 4/80 after two rounds; its discharges deal ~27 each and my HP is down to 75/155. One more Basic Attack should end it.
- zu Zug 101 (notiert vor Zug 102): Creeper defeated (1/1), +186 XP to 362/400, Heavy Slash nearly at P2 (72/75). HP down to 75/155 and still flagged wounded; will need recovery after turn-in.
- zu Zug 102 (notiert vor Zug 103): Turn-in confirmed: +9 silver and +300 XP, Level 5 with 5 free points. HP max rose to 165 but I'm still flagged wounded at 75/155→75/165; Mother Hesse visit pending.
- zu Zug 103 (notiert vor Zug 104): Turn-in and level-up confirmed; STR/VIT assigned, 0 free points left. Still flagged wounded at 75/165; heading to Mother Hesse.
- zu Zug 104 (notiert vor Zug 105): Price shown is 4 silver, not the 40 copper in the shop line; I can afford it either way. HP max rose to 175 after VIT assign.
- zu Zug 105 (notiert vor Zug 106): Wounded flag cleared after Mother Hesse's mending (Effects empty), but HP still 75/175 — overnight rest needed. Paid 40 copper as the shop line said, not the 4 silver she quoted.
- zu Zug 106 (notiert vor Zug 107): Contradiction: narration described a full night's sleep, but HUD still shows Day 4 16:04, wounded, HP 75/175 — the rest was not recorded. Retrying with an explicit purchase then sleep.
- zu Zug 107 (notiert vor Zug 108): Rest finally recorded: HP 175/175, STA 100/100, Day 5 08:00, wounded flag cleared. XP shows 262/500 after level-up reset.
- zu Zug 108 (notiert vor Zug 109): Rest fully recorded: HP 175/175, STA 100/100, Day 5 morning. The engine required actually arriving at the Guild hall before reading the board; I'm now entering it.
- zu Zug 109 (notiert vor Zug 110): Board read successfully at the Guild hall; creeper contract (90 cp, 3 kills) fits my level and known terrain.
- zu Zug 110 (notiert vor Zug 111): Creeper contract confirmed ACTIVE in HUD (0/3). Heading out to the ponds.
- zu Zug 111 (notiert vor Zug 112): At the ponds; creeper feeding scars lead toward the second pond. Contract active 0/3.
- zu Zug 112 (notiert vor Zug 113): Arrival confirmed; fresh creeper sign at the split willow roots suggests one is sheltering there.
- zu Zug 113 (notiert vor Zug 114): System refused the attack: the creeper is not yet a targetable actor in the scene — it must be flushed out first.
- zu Zug 114 (notiert vor Zug 115): Prodding the leaf mat flushed Creeper B into an ENGAGED, targetable state (HP 106/106); a tanner across the pond has noticed.
- zu Zug 115 (notiert vor Zug 116): Heavy Slash first strike dealt 50; creeper retaliates with ranged magical discharge (~37/hit). HP 101/175 — sustainable but worth watching over three kills.
- zu Zug 116 (notiert vor Zug 117): Creeper B at 9 HP after two Heavy Slashes; its magical discharge (~37/hit) has dropped me to 64/175 — worth considering recovery between kills.
- zu Zug 117 (notiert vor Zug 118): Creeper B defeated: contract 1/3, +270 XP, Heavy Slash promoted to P2, Level 6 with 5 free points. HP 64/185 badly wounded with two kills still owed — need recovery or supplies before engaging the next creeper; a tanner is calling from across the pond.
- zu Zug 118 (notiert vor Zug 119): Assign confirmed: STR 26, VIT 24, no free points left. HP still 64/185 badly wounded with two creeper kills owed; a tanner is calling across the pond, unsure whether to approach.
- zu Zug 119 (notiert vor Zug 120): Tanner B confirms smaller creepers in the north pond and runoff channel; contract is 1/3, HP 64/200 badly wounded, so a short rest before the next kill.
- zu Zug 120 (notiert vor Zug 121): System asked for an explicit rest duration; naming two hours to book the recovery properly.
- zu Zug 121 (notiert vor Zug 122): Two-hour rest booked properly: HP 64→104/200, STA full. Contract still 1/3; tanner pointed to the north pond, runoff channel, and reeds.
- zu Zug 122 (notiert vor Zug 123): Arrival at the north pond is confirmed by the HUD; the reed bed shows glossy false reeds, one bent like a fishing line a dozen paces in — a clear creeper target.
- zu Zug 123 (notiert vor Zug 124): A second creeper is sliding in through the reeds toward the bent reed just as I was four paces from my strike — potential two-target engagement in knee-deep mud.
- zu Zug 124 (notiert vor Zug 125): Creeper C engaged at full 64 HP; a second creeper is waking behind me near the bent reed — possible two-front fight while I stand at 104/200 in knee-deep mud.
- zu Zug 125 (notiert vor Zug 126): Creeper C at 7/64 after a 57-damage Heavy Slash; magical discharges cost 34 HP total. Second creeper still waking behind me.
- zu Zug 126 (notiert vor Zug 127): Creeper C defeated; contract 2/3, XP 156/600, HP 70/200. The creaking behind me has stopped — the third creeper may have gone still or submerged.
- zu Zug 127 (notiert vor Zug 128): Third creeper not targetable — no valid actor in scene; may have submerged or moved. Contract at 2/3, HP 70/200.
- zu Zug 128 (notiert vor Zug 129): The third creeper was found as Creeper D, now ENGAGED at 88/88 — its reed bed was a lure built on a cart-wheel root-mass. Contract still 2/3, HP 70/200.
- zu Zug 129 (notiert vor Zug 130): Creeper D at 27/88 after first-strike Heavy Slash; its two discharges dropped me to 13/200 HP — this kill is critical, then I must recover urgently.
- zu Zug 130 (notiert vor Zug 131): Contract 3/3 and READY FOR TURN-IN confirmed; HP 13/200 near death — recovery needed after turn-in.
- zu Zug 131 (notiert vor Zug 132): Turned in creeper contract: +9 silver, +300 XP, Level 7 with 5 free points. HP 13/210 — recovery urgent before next contract.
- zu Zug 132 (notiert vor Zug 133): Level 7 confirmed, stats assigned (STR 29, VIT 28), creeper contract paid out 9 silver. HP still 13/210 — recovery is the immediate priority.
- zu Zug 133 (notiert vor Zug 134): Clerk gave concrete directions: healer Maida Cotton on Cooper's Row, then lodging at the Drowned Ox. HP 13/225 is critical; Primer of Strike (120 cp) also available at the Guild for later.
- zu Zug 134 (notiert vor Zug 135): Maida offers full treatment plus supervised cot rest for 10 silver; I have 4 Gold so it's affordable. HP 13/225 is near death, so healing before any new contract.
- zu Zug 135 (notiert vor Zug 136): Purchase confirmed (-100 cp, coin 300). Treatment received but HP still 13/225 in HUD — recovery not yet recorded; must confirm after the cot rest.
- zu Zug 136 (notiert vor Zug 137): System refused the open-ended sleep and asked for a named duration; nothing was booked yet.
- zu Zug 137 (notiert vor Zug 138): Recovery resolved: HP 13→59/225, STA full. Maida says no fighting until day after tomorrow; two-day binding follow-up is free.
- zu Zug 138 (notiert vor Zug 139): HUD coin shows 3 Gold, so 51 cp for stew and room is affordable; purchase still needs confirmation before relying on the rest.
- zu Zug 139 (notiert vor Zug 140): Recovery fully confirmed: HP 59→225/225 after paid night at the Drowned Ox. Maida's two-day binding follow-up is still pending; no fighting until day after tomorrow per her instruction.
- zu Zug 140 (notiert vor Zug 141): HP fully recovered to 225/225 after paid night at the Drowned Ox. Novice board offers five contracts; creeper at 120 cp is a good solo fit. Maida's binding follow-up still pending, no fighting restriction mentioned past day after tomorrow.
- zu Zug 141 (notiert vor Zug 142): Contract confirmed ACTIVE in HUD (0/1 defeated); HP fully recovered to 225/225.
- zu Zug 142 (notiert vor Zug 143): Creeper located by tanner's directions at the left-hand pond; combat not yet started.
- zu Zug 143 (notiert vor Zug 144): Combat scene opened: creeper is Elite, HP 80/80, SHORT range; my first stroke is committed but outcome not yet resolved.
- zu Zug 144 (notiert vor Zug 145): Basic Attack failed on range: creeper sits at SHORT over soft mud; I must declare movement to close before striking.
- zu Zug 145 (notiert vor Zug 146): Heavy Slash crit for 61; creeper at 19/80 ENGAGED, retaliating with magical pulses for ~27 each. HP 170/225, fine.
- zu Zug 146 (notiert vor Zug 147): Creeper defeated; contract 1/1 ready for turn-in, +186 XP, creeper essence looted. Oddity: HUD 'Here' still lists dark water churning as a sign despite the creeper being dead.
- zu Zug 147 (notiert vor Zug 148): Turn-in completed: +186 XP combat, +300 XP payout, 1g2s coin, XP 560/700 at L7. Oddity: narration described counting 'twelve shillings' worth' while the System recorded 1 Gold 2 Silver — the System figure stands.
- zu Zug 148 (notiert vor Zug 149): Board offers four Novice jobs; weir adder is the quick solo one. Guard primer costs 120 cp, affordable at 3g6s9c. XP 560/700, close to L8.
- zu Zug 149 (notiert vor Zug 150): Refusal was just wording ('read once learned' needs step 2). HUD confirms Guard P1 already known, so buying its primer is pointless; adder contract is ACTIVE at 0/1.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t25 | 29 | 3 | – | nein | 3 | gewonnen, 168 XP |
| enc.t39 | 44 | 2 | – | nein | 2 | gewonnen, 168 XP |
| enc.t48 | 54 | 1 | – | nein | 1 | gewonnen, 300 XP |
| enc.t66 | 79 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t79 | 92 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t85 | 99 | 1 | – | nein | 1 | gewonnen, 186 XP |
| enc.t99 | 115 | 1 | – | nein | 1 | gewonnen, 270 XP |
| enc.t107 | 125 | 1 | – | nein | 1 | gewonnen, 124 XP |
| enc.t110 | 129 | 1 | – | nein | 1 | gewonnen, 218 XP |
| enc.t124 | 145 | 1 | – | nein | 1 | gewonnen, 186 XP |

## Quests

- **Kill the Weir Adder at Millward's Fish Traps** — active (Zug 72) → completed (Zug 80)
  - Aufgabe: Kill 1 grey weir adder at the fish weirs at the Glassmere outflow. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 grey weir adder killed at the fish weirs at the Glassmere outflow.
- **Thin the Stranglewillow Creepers at the Tannery Ponds** — expired (Zug 86)
  - Aufgabe: Kill 4 stranglewillow creepers at the Tannery Ponds south of Glassmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 stranglewillow creepers killed at the Tannery Ponds south of Glassmere.
- **Hunt the Ridge Boar Sow of the Clayfield Orchards** — expired (Zug 86)
  - Aufgabe: Kill 1 the scarred boar sow at the Clayfield orchards east of Glassmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the scarred boar sow killed at the Clayfield orchards east of Glassmere.
- **Cull the Pale Lynx Prides of the Cleft Slopes** — expired (Zug 86)
  - Aufgabe: Kill 6 pale lynxes at the rocky slopes above the cleft stream north of Glassmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 6 pale lynxes killed at the rocky slopes above the cleft stream north of Glassmere.
- **Clear Glimmerdeep Grotto, Level 1** — expired (Zug 86), Dungeon loc.glimmerdeep_grotto Ebene 1
  - Aufgabe: Clear level 1 of Glimmerdeep Grotto. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Glimmerdeep Grotto is clear.
- **Cull the Grey Weir Adder at the Fish Weirs** — active (Zug 87) → completed (Zug 93), READY
  - Aufgabe: Kill 1 grey weir adder at the fish weirs at the Glassmere outflow. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 grey weir adder killed at the fish weirs at the Glassmere outflow.
- **Cut Down the Stranglewillow Creeper of the Tannery Ponds** — active (Zug 95) → completed (Zug 102)
  - Aufgabe: Kill 1 stranglewillow creeper at the Tannery Ponds south of Glassmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 stranglewillow creeper killed at the Tannery Ponds south of Glassmere.
- **Slay the Scarred Boar Sow of the Clayfield Orchards** — expired (Zug 109)
  - Aufgabe: Kill 1 scarred boar sow at the Clayfield orchards east of Glassmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 scarred boar sow killed at the Clayfield orchards east of Glassmere.
- **Take the Pale Lynx Above the Cleft Stream** — expired (Zug 109)
  - Aufgabe: Kill 1 pale lynx at the rocky slopes above the cleft stream north of Glassmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 pale lynx killed at the rocky slopes above the cleft stream north of Glassmere.
- **Clear Glimmerdeep Grotto Level 1** — expired (Zug 109), Dungeon loc.glimmerdeep_grotto Ebene 1
  - Aufgabe: Clear level 1 of Glimmerdeep Grotto. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Glimmerdeep Grotto is clear.
- **Cull the Grey Weir Adder at the Outflow** — expired (Zug 140)
  - Aufgabe: Kill 1 grey weir adder at the fish weirs at the Glassmere outflow. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 grey weir adder killed at the fish weirs at the Glassmere outflow.
- **Cut Down the Stranglewillow Creepers of the Tannery Ponds** — active (Zug 110) → completed (Zug 131), READY
  - Aufgabe: Kill 3 stranglewillow creeper at the Tannery Ponds south of Glassmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 stranglewillow creeper killed at the Tannery Ponds south of Glassmere.
- **Slay the Scarred Boar Sow of the Clayfield Orchards** — expired (Zug 140)
  - Aufgabe: Kill 1 scarred boar sow at the Clayfield orchards east of Glassmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 scarred boar sow killed at the Clayfield orchards east of Glassmere.
- **Take the Pale Lynx Above the Cleft Stream** — expired (Zug 140)
  - Aufgabe: Kill 1 pale lynx at the rocky slopes above the cleft stream north of Glassmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 pale lynx killed at the rocky slopes above the cleft stream north of Glassmere.
- **Clear Glimmerdeep Grotto Level 1** — expired (Zug 140), Dungeon loc.glimmerdeep_grotto Ebene 1
  - Aufgabe: Clear level 1 of Glimmerdeep Grotto. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Glimmerdeep Grotto is clear.
- **Cull the Grey Weir Adder** — active (Zug 149)
  - Aufgabe: Kill 1 grey weir adder at the fish weirs at the Glassmere outflow. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 grey weir adder killed at the fish weirs at the Glassmere outflow.
- **Clear the Stranglewillow Creeper** — active (Zug 141) → completed (Zug 147), READY
  - Aufgabe: Kill 1 stranglewillow creeper at the Tannery Ponds south of Glassmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 stranglewillow creeper killed at the Tannery Ponds south of Glassmere.

## Auffälligkeiten

- Zug 5, Nachricht 9 (planner_repaired): the planner's first answer needed a repair
- Zug 6, Nachricht 11 (board_failed): the board generator failed
- Zug 6, Nachricht 11 (finish): board ended with finish_reason "length"
- Zug 12, Nachricht 24 (extraction_repaired): the extractor's first answer needed a repair
- Zug 14, Nachricht 27 (board_failed): the board generator failed
- Zug 15, Nachricht 30 (extraction_repaired): the extractor's first answer needed a repair
- Zug 16, Nachricht 31 (planner_repaired): the planner's first answer needed a repair
- Zug 16, Nachricht 31 (finish): plan ended with finish_reason "length"
- Zug 17, Nachricht 33 (planner_repaired): the planner's first answer needed a repair
- Zug 18, Nachricht 35 (planner_repaired): the planner's first answer needed a repair
- Zug 24, Nachricht 48 (extraction_repaired): the extractor's first answer needed a repair
- Zug 25, Nachricht 50 (extraction_repaired): the extractor's first answer needed a repair
- Zug 37, Nachricht 74 (extraction_repaired): the extractor's first answer needed a repair
- Zug 37, Nachricht 74 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 37, Nachricht 74 (finish): extract ended with finish_reason "length"
- Zug 58, Nachricht 116 (extraction_repaired): the extractor's first answer needed a repair
- Zug 58, Nachricht 116 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 58, Nachricht 116 (finish): extract ended with finish_reason "length"
- Zug 59, Nachricht 118 (extraction_repaired): the extractor's first answer needed a repair
- Zug 59, Nachricht 118 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 59, Nachricht 118 (finish): extract ended with finish_reason "length"
- Zug 61, Nachricht 121 (planner_repaired): the planner's first answer needed a repair
- Zug 64, Nachricht 127 (planner_repaired): the planner's first answer needed a repair
- Zug 65, Nachricht 129 (planner_repaired): the planner's first answer needed a repair
- Zug 67, Nachricht 134 (extraction_repaired): the extractor's first answer needed a repair
- Zug 73, Nachricht 146 (extraction_repaired): the extractor's first answer needed a repair
- Zug 73, Nachricht 146 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 73, Nachricht 146 (finish): extract ended with finish_reason "length"
- Zug 85, Nachricht 170 (extraction_repaired): the extractor's first answer needed a repair
- Zug 85, Nachricht 170 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 85, Nachricht 170 (finish): extract ended with finish_reason "length"
- Zug 88, Nachricht 176 (extraction_repaired): the extractor's first answer needed a repair
- Zug 88, Nachricht 176 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 88, Nachricht 176 (finish): extract ended with finish_reason "length"
- Zug 97, Nachricht 193 (planner_repaired): the planner's first answer needed a repair
- Zug 109, Nachricht 218 (extraction_repaired): the extractor's first answer needed a repair
- Zug 109, Nachricht 218 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 109, Nachricht 218 (finish): extract ended with finish_reason "length"
- Zug 111, Nachricht 222 (extraction_repaired): the extractor's first answer needed a repair
- Zug 111, Nachricht 222 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 111, Nachricht 222 (finish): extract ended with finish_reason "length"
- Zug 112, Nachricht 224 (extraction_repaired): the extractor's first answer needed a repair
- Zug 114, Nachricht 228 (extraction_repaired): the extractor's first answer needed a repair
- Zug 122, Nachricht 244 (extraction_repaired): the extractor's first answer needed a repair
- Zug 133, Nachricht 266 (extraction_repaired): the extractor's first answer needed a repair
- Zug 138, Nachricht 276 (extraction_repaired): the extractor's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 15× keine gültige JSON-Entscheidung (Züge 2, 16, 24, 33, 50, 53, 74, 81, 83, 87, 89, 122, 123, 141, 143)
- 10 Aufruf(e) mit finish_reason "length" (Nr. 12 board, Nr. 47 plan, Nr. 106 extract, Nr. 164 extract, Nr. 168 extract, Nr. 203 extract, Nr. 240 extract, Nr. 251 extract, Nr. 312 extract, Nr. 319 extract)

System-Panels: CLARIFY 9, NOT TAKEN 0, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: guild_canon 4, ambient 12, pc_inventory 1, coin_evidence 2, no_go 6, scene_context 29, engine_owned_fact 14, entity_fact 4, time_cap 3, arrival_evidence 1, group_unclear 3, world_rule 15, offer 2, attack_commitment 8, quest_dependency 1, engine_owned_memory 1, engine_recovery 2, quest_count 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 8, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 148 | 8 | 2.4 s | 5.7 s | 11382 | 9807 | 83 | – | stop 147, length 1 | 1 |
| narrator | 127 | 0 | 8.9 s | 24.9 s | 11389 | 8721 | 406 | – | stop 127 | 0 |
| extract | 145 | 10 | 5.4 s | 17.7 s | 12068 | 9242 | 368 | – | stop 137, length 8 | 8 |
| board | 9 | 3 | 10.8 s | 42.1 s | 2452 | 2148 | 1172 | – | length 1, stop 8 | 1 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 82:37 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 13.8 s) | 0:28 min |
| 150 Züge, Spiel (Senden bis HUD nach der Extraktion) | 70:02 min — Median 21.1 s, p90 60.8 s, max 136.4 s |
| 150 Züge, Spieler-Entscheidung | 9:22 min — Median 2.8 s, 15 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 8:44 min / 2:19 min / 30:05 min / 23:10 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 31.8 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 21:10 min, 80 Züge ≈ 42:21 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spiel | 37 | – | 136.4 s | 21.1 s |
| Spiel | 74 | – | 127.9 s | 21.1 s |
| Spiel | 85 | – | 112.4 s | 21.1 s |
| Provider plan | 16 | 47 | 37.1 s | 2.4 s |
| Provider narrator | 74 | 206 | 103.0 s | 8.9 s |
| Provider narrator | 134 | 380 | 82.5 s | 8.9 s |
| Provider narrator | 20 | 57 | 78.6 s | 8.9 s |
| Provider extract | 59 | 168 | 60.8 s | 5.4 s |
| Provider extract | 37 | 107 | 59.6 s | 5.4 s |
| Provider extract | 37 | 106 | 57.8 s | 5.4 s |
| Provider board | 6 | 12 | 42.1 s | 10.8 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
