# Avereth Live-Test 20261027-090159Z-current_test

## Kurzfassung

- **Laufprofil:** guild-mage; Startklasse Mage, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** Niederlage — turn 99: he died
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 3. Sicherheitsgrenzen: 150 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** noch nicht erreicht.
- **Charakter:** mage (mage.arcane_bolt, mage.arcane_ward) · Regelstand 2 (Warrior, Mage, Rogue)
- **Ziel-Dungeon:** Glimmerdeep Grotto, Ebene 1 (Vertrag quest.clear_glimmerdeep_grotto_level_1)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: cautious adventurer: prepare and recover, weigh threats and withdraw when sensible
- **Züge:** 99 · **Dauer:** 38:48 min · **LLM-Aufrufe der Engine/des Erzählers:** 223
- **Auffälligkeiten:** 32 · **Niederlage** in Zug 99: he died
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.101 |
| Git | c9e3fa58bb57 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 9.2 s |
| Browser | chrome 156.0.8078.48 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 182 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261027-090159Z-current_test“, Seed 1613311442 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | I choose Mage. | Engine (Menü/Rückfrage) | creation_complete | Select Mage as base class. | public roadside verge outside Glassmere | 90/84 | 2.3 s |
| 2 | I pick Arcane Bolt and Arcane Ward. | Engine (Menü/Rückfrage) | creation_complete | Finish character creation by selecting the two starter skills. | public roadside verge outside Glassmere | 90/96 | 2.1 s |
| 3 | I walk to Glassmere and head to the Adventurers' Guild hall to look at the contract board. | Erzähler | open_run_level | Enter city and check Guild contracts. | Adventurers' Guild hall, Glassmere | 90/96 | 49.1 s |
| 4 | "Yes, I'm new. I'd like to register with the Guild, please." | Erzähler | open_run_level | Register with the Guild for 2 silver so I can take contracts. | Adventurers' Guild hall, Glassmere | 90/96 | 15.1 s |
| 5 | "Alaric." I pay the two silver, write my name in the ledger, and press my hand to the measuring stone. | Erzähler | open_run_level | Complete Guild registration: pay, sign, and measure Power Rank. | Adventurers' Guild hall, Glassmere | 90/96 | 20.1 s |
| 6 | "What usually comes up on the Novice section? I'd like to know what to expect before dawn." | Erzähler | open_run_level | Ask the clerk about typical Novice contracts so I can prepare for dawn postings. | Adventurers' Guild hall, Glassmere | 90/96 | 16.1 s |
| 7 | "Thanks, that helps. I'll come back at first light for the board. Is there anywhere nearby to eat cheaply and rest until then?" | Erzähler | open_run_level | Ask the clerk for cheap food and lodging while waiting for dawn postings. | Adventurers' Guild hall, Glassmere | 90/96 | 21.1 s |
| 8 | I walk to the Weary Cart, order pottage and bread for a copper, and ask for a bench by the hearth until the small hours. | Erzähler | open_run_level | Eat cheaply and rest at the Weary Cart until dawn postings. | The Weary Cart | 90/96 | 63.3 s |
| 9 | "The bench till the small hours, please — here's three coppers." | Erzähler | open_run_level | Buy the 3-copper hearth bench to rest until dawn postings. | The Weary Cart | 90/96 | 14.8 s |
| 10 | I head back to the Guild hall and check the Novice contract board. | Erzähler | open_run_level | Return to the Guild and look for an achievable Novice contract on the board. | Adventurers' Guild hall, Glassmere | 90/96 | 37.3 s |
| 11 | I take the Weir-Lurking Bog Strider slip to the counter and ask the clerk to book it. | Erzähler | open_run_level | Accept the bog strider kill contract at the counter. | Adventurers' Guild hall, Glassmere | 90/96 | 25.6 s |
| 12 | I set out for the Reed Flats, following the eel-boat track past the tanner's stairs toward the eel-weirs. | Erzähler | open_run_level | Travel to the Reed Flats weirs to hunt the bog strider. | Adventurers' Guild hall, Glassmere | 90/96 | 20.1 s |
| 13 | I walk carefully along the causeway toward the third weir basket, watching the water for movement, and stop at a safe distance on the bank t… | Erzähler | open_run_level | Approach the third weir on the bank and scout the bog strider without wading. | the eel-weirs of the Reed Flats | 90/96 | 24.0 s |
| 14 | I cast Arcane Bolt at the bog strider under the third basket. | Erzähler | open_run_level | Open the fight with ranged magic from the causeway. | the eel-weirs of the Reed Flats | 90/86 | 17.0 s |
| 15 | I collect the three chitin plates from the gravel bar if I haven't already, then head back along the causeway to the Guild hall to turn in t… | Erzähler | open_run_level | Retrieve loot and return to the Guild for the turn-in. | Adventurers' Guild hall, Glassmere | 90/86 | 20.1 s |
| 16 | I check the Novice contract board for fresh postings. | Erzähler | open_run_level | Look for the next achievable Guild contract on the board. | Adventurers' Guild hall, Glassmere | 90/86 | 16.1 s |
| 17 | I ask the clerk to book the Glimmerdeep Grotto Level 1 clearance contract. | Erzähler | open_run_level | Accept the achievable recommended-level-1 grotto clearance contract. | Adventurers' Guild hall, Glassmere | 90/86 | 15.7 s |
| 18 | I head out the west gate, follow the river track and take the old quarry road up toward the warden's hut below the kiln terraces at Glimmerd… | Erzähler | open_run_level | Travel to the Glimmerdeep Grotto entrance to start the clearance contract. | Warden's hut below the kiln terraces | 90/86 | 28.5 s |
| 19 | I ask Dalrei whether there's a safe spot nearby to camp or rest before entering, or whether she'd advise going in now given the light. | Erzähler | open_run_level | Weigh timing and recovery options before entering the grotto. | Warden's hut below the kiln terraces | 90/86 | 27.0 s |
| 20 | I fill a water skin at the hut, then head into the grotto entrance now, taking the lamp and following the chalk line into the first gallery. | Erzähler | open_run_level | Enter the grotto while light remains and start clearing level one. | Warden's hut below the kiln terraces | 90/86 | 23.3 s |
| 21 | I cast Arcane Bolt at the nearest beetle, keeping the chalk line between us. | Engine (Menü/Rückfrage) | open_run_level | Engage the crystal beetles at range to clear the first gallery. | Warden's hut below the kiln terraces | 90/86 | 3.8 s |
| 22 | I step fully into the first gallery scene, lamp raised, and cast Arcane Bolt at the nearest crystal beetle among the rubble heaps. | Engine (Menü/Rückfrage) | open_run_level | Enter the gallery as an active scene and attack the nearest beetle. | Warden's hut below the kiln terraces | 90/86 | 3.7 s |
| 23 | I bid Dalrei farewell and leave the warden's hut scene, walking the chalk line alone into the first gallery; once I am there among the rubbl… | Erzähler | open_run_level | Explicitly depart the hut scene so the active scene becomes the first gallery, then attack… | Warden's hut below the kiln terraces | 90/86 | 63.6 s |
| 24 | Standing among the rubble heaps in the first gallery, I release the built Arcane Bolt at the nearest crystal beetle. | Engine (Menü/Rückfrage) | open_run_level | Release the mid-cast Arcane Bolt at the nearest beetle now that the narrator has placed me… | Warden's hut below the kiln terraces | 90/86 | 6.7 s |
| 25 | I walk on alone into the first gallery of Glimmerdeep Grotto and stop there among the rubble heaps, facing the three beetles. | Erzähler | open_run_level | Force the active scene to update to the grotto gallery before attacking. | Warden's hut below the kiln terraces | 90/86 | 18.6 s |
| 26 | I am now alone in the first gallery of Glimmerdeep Grotto — Dalrei, Hobb and the mule are no longer present. I cast Arcane Bolt at the close… | Engine (Menü/Rückfrage) | open_run_level | Update the lagging active scene and attack the beetle. | Warden's hut below the kiln terraces | 90/86 | 4.0 s |
| 27 | #help | System (Befehl) | open_run_level | Check the command list for a scene or movement command that can fix the stale active scene… | Warden's hut below the kiln terraces | 90/86 | 2.1 s |
| 28 | #combat | System (Befehl) | open_run_level | Check the combat/encounter audit to see how the active scene is being tracked and why it s… | Warden's hut below the kiln terraces | 90/86 | 2.2 s |
| 29 | #system How does the engine update the active scene when Alaric travels from the warden's hut to the first gallery of Glimmerdeep Grotto? At… | Erzähler | open_run_level | Ask the System how to change the active scene so the beetles become valid targets. | Warden's hut below the kiln terraces | 90/86 | 10.9 s |
| 30 | I cast Arcane Bolt at the nearest crystal beetle. | Engine (Menü/Rückfrage) | open_run_level | Attack a beetle now that the active scene is confirmed as the first gallery. | Warden's hut below the kiln terraces | 90/86 | 4.3 s |
| 31 | I walk into the first gallery of Glimmerdeep Grotto and cast Arcane Bolt at the nearest crystal beetle. | Erzähler | open_run_level | Combine travel and attack in one message so the scene loads the beetles as legal targets. | Warden's hut below the kiln terraces | 90/86 | 20.0 s |
| 32 | I release the built Arcane Bolt at the nearest crystal beetle. | Engine (Menü/Rückfrage) | open_run_level | Fire the already-building bolt at the beetle now that the scene shows me among the heaps. | Warden's hut below the kiln terraces | 90/86 | 4.0 s |
| 33 | #system The active scene still lists Dalrei, Master Hobb and Mule A even though Alaric has walked thirty paces into Glimmerdeep Grotto's fir… | Erzähler | open_run_level | Ask the System directly how to force the scene update so the beetles become attackable. | Warden's hut below the kiln terraces | 90/86 | 9.6 s |
| 34 | I cast Arcane Bolt at crystal_beetle_A, the nearest beetle on the rubble heap. | Engine (Menü/Rückfrage) | open_run_level | Attack the now-valid nearest beetle now that the System confirms the scene holds three bee… | Warden's hut below the kiln terraces | 90/86 | 4.6 s |
| 35 | I walk from the warden's hut into the first gallery of Glimmerdeep Grotto and cast Arcane Bolt at crystal_beetle_A. | Erzähler | open_run_level | Resolve travel and attack in one declared message per the System's stated fix. | Warden's hut below the kiln terraces | 90/86 | 33.4 s |
| 36 | I release the building Arcane Bolt at the nearest crystal beetle. | Engine (Menü/Rückfrage) | open_run_level | Fire the already-building bolt at the nearest beetle now that the narrator confirms I am a… | Warden's hut below the kiln terraces | 90/86 | 4.8 s |
| 37 | I walk into the first gallery of Glimmerdeep Grotto, following the blue chalk line, and stop near the nearest rubble heap. | Erzähler | open_run_level | Declare travel alone so the scene track updates to the gallery before attacking. | Warden's hut below the kiln terraces | 90/86 | 18.9 s |
| 38 | I cast Arcane Bolt at mon.crystal_beetle_A. | Engine (Menü/Rückfrage) | open_run_level | Attack the beetle using the exact System-formatted actor ID the System itself listed, hopi… | Warden's hut below the kiln terraces | 90/86 | 5.1 s |
| 39 | #help | System (Befehl) | open_run_level | Check the command list for a scene, travel or movement command that can update the active … | Warden's hut below the kiln terraces | 90/86 | 2.2 s |
| 40 | #combat | System (Befehl) | open_run_level | Audit the encounter to see why the beetle target is not registered in the active scene. | Warden's hut below the kiln terraces | 90/86 | 2.2 s |
| 41 | I enter the first gallery of Glimmerdeep Grotto and commit to attacking the crystal beetles there, casting Arcane Bolt at the nearest one. | Erzähler | open_run_level | Make a hostile commitment to start combat per #combat's diagnosis, then attack a beetle. | Warden's hut below the kiln terraces | 90/86 | 44.9 s |
| 42 | I cast Arcane Bolt at the nearest crystal beetle. | Engine (Menü/Rückfrage) | open_run_level | Attack a beetle now that hostile commitment was declared, to trigger combat activation. | Warden's hut below the kiln terraces | 90/86 | 4.0 s |
| 43 | I cast Arcane Bolt at mon.crystal_beetle_A. | Engine (Menü/Rückfrage) | open_run_level | Attack the beetle via the exact actor ID to activate combat. | Warden's hut below the kiln terraces | 90/86 | 5.8 s |
| 44 | I travel to Glimmerdeep Grotto Level 1 and, on arrival, cast Arcane Bolt at the nearest crystal beetle. | Erzähler | open_run_level | Reach the actual beetle scene and attack there, since the active scene is still the warden… | Glimmerdeep Grotto | 90/86 | 18.5 s |
| 45 | I cast Arcane Bolt at mon.crystal_beetle_A. | Engine (Menü/Rückfrage) | open_run_level | Attack a beetle now that the active scene is actually the grotto gallery. | Glimmerdeep Grotto | 90/86 | 5.5 s |
| 46 | #combat | System (Befehl) | open_run_level | Check the combat scene registry, since the narrator shows beetles but the System sees no t… | Glimmerdeep Grotto | 90/86 | 2.2 s |
| 47 | I declare hostile intent against the crystal beetles in this gallery and commit to attacking them, starting with the nearest one. | Erzähler | open_run_level | Make an explicit hostile commitment to activate combat, then attack. | Glimmerdeep Grotto | 90/86 | 17.8 s |
| 48 | I release the held bolt at the beetle advancing toward me. | Engine (Menü/Rückfrage) | open_run_level | Release the charged Arcane Bolt at the approaching beetle now that hostile commitment seem… | Glimmerdeep Grotto | 90/86 | 7.0 s |
| 49 | I cast Arcane Bolt at mon.crystal_beetle_A. | Engine (Menü/Rückfrage) | open_run_level | Fire the held bolt at the exact registry actor ID now that the active scene is finally the… | Glimmerdeep Grotto | 90/86 | 6.0 s |
| 50 | I attack the nearest crystal beetle with my staff. | Engine (Menü/Rückfrage) | open_run_level | Trigger combat with a plain Basic Attack after targeted casts keep failing the registry. | Glimmerdeep Grotto | 90/86 | 9.5 s |
| 51 | #help | System (Befehl) | open_run_level | Look up how to list or target actors in the active scene. | Glimmerdeep Grotto | 90/86 | 2.1 s |
| 52 | #system How do I make an actor targetable in the active scene? The narrator shows crystal beetles but combat says there is no targetable act… | Erzähler | open_run_level | Ask the System directly how to register the beetles as valid targets. | Glimmerdeep Grotto | 90/86 | 9.9 s |
| 53 | I strike at the lead crystal beetle with my staff. | Erzähler | open_run_level | Declare a direct hostile attack in plain wording so the engine registers the beetles and a… | Glimmerdeep Grotto | 90/86 | 21.1 s |
| 54 | #combat | System (Befehl) | open_run_level | Check whether the encounter is now ACTIVE with registered beetle targets. | Glimmerdeep Grotto | 90/86 | 2.1 s |
| 55 | I attack the lead crystal beetle and keep attacking until it is dead. | Engine (Menü/Rückfrage) | open_run_level | Commit a plain hostile declaration naming the described foe so the engine registers the en… | Glimmerdeep Grotto | 90/86 | 20.8 s |
| 56 | I cast Arcane Bolt at the crystal beetle standing ten paces in front of me. | Engine (Menü/Rückfrage) | open_run_level | Try a named spell cast as the hostile commitment to force target registration. | Glimmerdeep Grotto | 90/86 | 5.8 s |
| 57 | I cast Arcane Bolt at the crystal beetle I already struck. | Engine (Menü/Rückfrage) | open_run_level | Answer the System's clarification by picking the beetle I struck, hoping a concrete disamb… | Glimmerdeep Grotto | 90/86 | 4.0 s |
| 58 | the one you struck | Engine (Menü/Rückfrage) | open_run_level | Answer the System's clarification menu with the exact option wording to register the beetl… | Glimmerdeep Grotto | 90/86 | 6.0 s |
| 59 | I cast Arcane Bolt at the big one on the heap. | Engine (Menü/Rückfrage) | open_run_level | Pick the exact menu option for the big beetle to register a valid target. | Glimmerdeep Grotto | 90/86 | 3.9 s |
| 60 | I step back out of the beetle cavern toward the grotto entrance, keeping my eyes on the beetles. | Erzähler | open_run_level | Withdraw from the unresolvable encounter and try a different part of the grotto. | Glimmerdeep Grotto | 90/86 | 70.5 s |
| 61 | #combat | System (Befehl) | open_run_level | Inspect the engine's combat/scene state to find why no target registers. | Glimmerdeep Grotto | 90/86 | 2.1 s |
| 62 | I use Basic Attack on the lead beetle blocking the passage. | Engine (Menü/Rückfrage) | open_run_level | Try Basic Attack as the hostile commitment to trigger combat registration. | Glimmerdeep Grotto | 90/86 | 4.3 s |
| 63 | #help | System (Befehl) | open_run_level | List available System commands to find how to register a target or scene. | Glimmerdeep Grotto | 90/86 | 2.2 s |
| 64 | #system The scene shows six crystal beetles around me, but combat says INACTIVE with no targetable actor. How do I enter combat or register … | Erzähler | open_run_level | Ask the System directly how to activate combat against the beetles. | Glimmerdeep Grotto | 90/86 | 11.5 s |
| 65 | I attack one of the crystal beetles blocking the passage, striking it with my staff. | Engine (Menü/Rückfrage) | open_run_level | Declare a hostile attack to fix the engine encounter and register targetable beetles. | Glimmerdeep Grotto | 90/86 | 4.0 s |
| 66 | I attack the crystal beetle. | Engine (Menü/Rückfrage) | open_run_level | Declare an attack against the registered foe by its exact level-definition name to fix the… | Glimmerdeep Grotto | 90/86 | 5.3 s |
| 67 | I give up on the phantom beetles and leave the cavern, heading back out of Glimmerdeep Grotto toward the entrance. | Erzähler | open_run_level | Withdraw from the unregistered encounter and exit the dungeon. | wet crystal gallery | 90/86 | 19.0 s |
| 68 | I cast Arcane Bolt at Crystal Beetle A. | Erzähler | open_run_level | Attack the now-registered beetle by its exact panel name to start combat. | wet crystal gallery | 65/76 | 16.8 s |
| 69 | I cast Arcane Bolt at Crystal Beetle A to finish it off. | Erzähler | open_run_level | Kill the nearly-dead beetle A before it bites again. | wet crystal gallery | 49/66 | 15.8 s |
| 70 | I cast Arcane Bolt at Crystal Beetle B. | Erzähler | open_run_level | Kill beetle B quickly to reduce incoming damage. | wet crystal gallery | 33/56 | 24.6 s |
| 71 | I finish Crystal Beetle B with a Basic Attack, then keep my staff raised toward Crystal Beetle C, ready for its next move. | Erzähler | open_run_level | Kill beetle B cheaply with a basic attack and save MP for Arcane Ward or Bolt on C. | wet crystal gallery | 27/56 | 14.6 s |
| 72 | I cast Arcane Ward, then attack Crystal Beetle C with a Basic Attack. | Erzähler | open_run_level | Raise a barrier to blunt C's hits, then chip it down with a basic attack. | wet crystal gallery | 27/46 | 15.2 s |
| 73 | I cast Arcane Bolt at Crystal Beetle C. | Erzähler | open_run_level | Kill the fresh beetle quickly with a high-damage bolt before it grinds me down. | wet crystal gallery | 27/36 | 17.3 s |
| 74 | #assign VIT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up points to boost survivability before pushing on. | wet crystal gallery | 27/36 | 2.1 s |
| 75 | I withdraw back the way I came, staff raised and watching for whatever has been following me. | Erzähler | open_run_level | Retreat wounded from the gallery while a threat trails behind, staying alert. | Glimmerdeep Grotto | 27/36 | 18.9 s |
| 76 | I head down the slope to the bog road and walk back toward town, staying alert on the dark trail. | Erzähler | open_run_level | Travel back to town wounded to recover and later turn in loot. | Glimmerdeep Grotto | 27/36 | 21.1 s |
| 77 | I walk through the town gate at Glassmere and head straight for the nearest inn to get a room for the night. | Erzähler | open_run_level | Reach Glassmere and obtain lodging to recover overnight. | the Drowned Lantern | 27/36 | 51.4 s |
| 78 | "I'll take the room with breakfast, and the stew as well if it's cheap." | Erzähler | open_run_level | Buy lodging with breakfast and stew to recover overnight. | the Drowned Lantern | 27/36 | 52.1 s |
| 79 | "I'll have a bowl of the stew and bread too, then." | Erzähler | open_run_level | Buy the 2 cp stew and bread, then sleep upstairs. | the Drowned Lantern | 27/36 | 13.1 s |
| 80 | I finish the stew, then go up to my room and sleep until morning. | Erzähler | open_run_level | Sleep overnight to recover HP and MP. | the Drowned Lantern | 110/116 | 17.4 s |
| 81 | I eat the breakfast that comes with the room, then head for the Guild hall to look at the contract board. | Erzähler | open_run_level | Recover with breakfast, then check the Guild board for achievable contracts. | Adventurers' Guild hall, Glassmere | 110/116 | 35.8 s |
| 82 | "I'll take the boar cull along Hollow Row — four tusked orchard boars. Can you mark it active for me?" | Erzähler | open_run_level | Accept the achievable Orchard Boars contract at the Guild board. | Adventurers' Guild hall, Glassmere | 110/116 | 16.0 s |
| 83 | I leave the Guild hall and take the south road toward Hollow Row, following the row markers past the stone bridge. | Erzähler | open_run_level | Travel to Hollow Row and hunt the boars for the active contract. | the cider orchards along Hollow Row | 110/116 | 22.4 s |
| 84 | I thank the basket-man and walk to the far end of the orchard by the broken fence, then find a spot with a tree at my back to wait for the b… | Erzähler | open_run_level | Take position at the far rows near the downed fence to ambush the boars. | the cider orchards along Hollow Row | 110/116 | 23.8 s |
| 85 | I cast Arcane Bolt at the boar while it's still deciding at the fence. | Erzähler | open_run_level | Open the boar fight from ambush range before it closes. | the cider orchards along Hollow Row | 82/106 | 18.8 s |
| 86 | I cast Arcane Bolt at the boar. | Erzähler | open_run_level | Continue the boar fight with the stronger ranged attack. | the cider orchards along Hollow Row | 57/96 | 16.6 s |
| 87 | I cast Arcane Bolt at the boar. | Erzähler | open_run_level | Finish the wounded boar with another Arcane Bolt before it gores me again. | the cider orchards along Hollow Row | 31/86 | 41.7 s |
| 88 | I finish it with a Basic Attack at the swaying boar. | Erzähler | open_run_level | Kill the nearly dead boar with a cheaper basic attack. | the cider orchards along Hollow Row | 31/86 | 18.3 s |
| 89 | #assign VIT 3 WIL 2 | System (Befehl) | open_run_level | Spend the five level-up stat points on survivability and casting. | the cider orchards along Hollow Row | 31/86 | 2.2 s |
| 90 | "Yes, I can walk. Lead me to the house — I'll take water and let your wife bind these wounds, then I'll deal with the rest of the sounder." | Erzähler | open_run_level | Accept the farmer's help to recover at the house before facing the remaining boars. | Bram Helt's farmhouse | 31/86 | 26.5 s |
| 91 | "Thank you — I'll take the bed in the barn and your wife's stew, and sleep until morning before I go at the rest of the sounder." | Erzähler | open_run_level | Rest overnight at the farm to recover HP before hunting the remaining three boars. | Bram Helt's farmhouse | 130/136 | 15.4 s |
| 92 | I thank Bram and Maren, then head down into the east orchard rows to hunt the remaining three boars, following the fresh rooting sign. | Erzähler | open_run_level | Hunt the remaining three boars in the east rows at full HP/MP. | the cider orchards along Hollow Row | 130/136 | 65.3 s |
| 93 | I put the fence and the pear tree at my back and cast Arcane Bolt at the smaller boar with the broken tusk. | Engine (Menü/Rückfrage) | open_run_level | Open the fight against the three remaining boars at range, targeting the weaker one. | the cider orchards along Hollow Row | 130/136 | 6.2 s |
| 94 | The smaller boar with the broken tusk is Boar C — I cast Arcane Bolt at Tusked Orchard Boar C. | Erzähler | open_run_level | Open the 3-on-1 fight at range against the weaker boar. | the cider orchards along Hollow Row | 130/136 | 13.8 s |
| 95 | I move to MEDIUM range behind the fence gap and cast Arcane Bolt at Tusked Orchard Boar C. | Erzähler | open_run_level | Close into spell range and attack Boar C. | the cider orchards along Hollow Row | 130/126 | 16.2 s |
| 96 | I cast Arcane Bolt at the wounded Boar C at SHORT range to finish it before it gores me. | Erzähler | open_run_level | Kill the wounded Boar C with a second Arcane Bolt before it attacks. | the cider orchards along Hollow Row | 109/116 | 16.1 s |
| 97 | I cast Arcane Bolt at Tusked Orchard Boar C to finish it off. | Erzähler | open_run_level | Kill the 6-HP Boar C engaged with me before the other two boars reach melee. | the cider orchards along Hollow Row | 59/106 | 15.1 s |
| 98 | I cast Arcane Ward to shield myself, then on my next turn finish the weaker Boar D with Arcane Bolt. | Erzähler | open_run_level | Survive the double gore with a barrier before counterattacking. | the cider orchards along Hollow Row | 37/96 | 12.7 s |
| 99 | I cast Arcane Bolt at Tusked Orchard Boar D. | Erzähler | open_run_level | Kill the wounded Boar D before the next gore lands. | the cider orchards along Hollow Row | 0/86 | 28.9 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 2 (notiert vor Zug 3): Creation complete: Level 1 Mage, INT 8/WIL 8, MATK 10, 5 silver. Skills Arcane Bolt and Arcane Ward.
- zu Zug 3 (notiert vor Zug 4): Novice board is empty this morning; new postings at dawn. Registration costs 2 silver, leaving 3.
- zu Zug 4 (notiert vor Zug 5): Registration requires name, payment, and stone touch; performing all three now to confirm Guild Rank on the HUD.
- zu Zug 5 (notiert vor Zug 6): Registration confirmed: Guild Rank Novice, Power Rank F, Guild plate in inventory, 3 silver left. Coin discrepancy: narrator said 50→30 copper but HUD shows 3 silver; HUD is authoritative.
- zu Zug 6 (notiert vor Zug 7): Registration fully confirmed: Novice rank, F Power Rank, plate in inventory, 3 silver. Glimmerdeep culling suggested as optional F-rank income source.
- zu Zug 8 (notiert vor Zug 9): HUD shows 3 Silver with no copper breakdown; narrator charges 3 cp for the bench. Meal already eaten for a copper.
- zu Zug 9 (notiert vor Zug 10): HUD contradiction: narration played out the whole night on the hearth bench, but HUD time still reads Day 1, 12:25 midday. Coin confirmed 2s 7c after the 3cp bench purchase.
- zu Zug 10 (notiert vor Zug 11): Novice board shows five contracts; bog strider (25 cp) is the most achievable solo F-rank job. HUD time now Day 1 12:55, rest confirmed.
- zu Zug 11 (notiert vor Zug 12): Contract confirmed ACTIVE on HUD (0/1 defeated). Rest confirmed by HUD time now Day 1 13:00; previous night-time narration was cosmetic.
- zu Zug 13 (notiert vor Zug 14): Strider confirmed at third weir, HP 24, partial cover; reeds rustled with unseen movement earlier — possible second threat.
- zu Zug 14 (notiert vor Zug 15): One-shot kill: Arcane Bolt first strike did 26 damage, defeating the 24 HP strider instantly. Loot (3 chitin plates) and quest 1/1 already confirmed in HUD; unseen reed movement never materialized as a threat.
- zu Zug 15 (notiert vor Zug 16): Turn-in confirmed: +46 XP, payout 2s 5c, quest filed. XP now 70/100 at L1; chitin plates still carried as loot to sell.
- zu Zug 16 (notiert vor Zug 17): Board shows boar/stag/bear contracts well above my level; Glimmerdeep L1 (rec. level 1, 40 cp) is the sensible pick despite the solo-risk warning.
- zu Zug 17 (notiert vor Zug 18): Contract confirmed ACTIVE on HUD. MP only 86/96 from the earlier fight; will consider recovery or supplies before entering the grotto.
- zu Zug 18 (notiert vor Zug 19): Arrived at warden's hut; grotto entrance confirmed with lamp and chalk line, beetles in outer galleries. MP 86/96, late afternoon — Dalrei warns light dies fast after sunset.
- zu Zug 19 (notiert vor Zug 20): MP nearly full, HP full; Dalrei says first galleries low-risk and lamp/chalk line provided at the mouth. Going in now per her advice.
- zu Zug 20 (notiert vor Zug 21): Entered grotto with lamp and chalk line; three beetles feeding among rubble in the first gallery, nearest about fifteen paces off and not yet alerted.
- zu Zug 21 (notiert vor Zug 22): System refused my Arcane Bolt: active scene was still the warden's hut, so the beetles weren't valid targets. I'm re-entering by moving into the gallery scene first, then attacking.
- zu Zug 22 (notiert vor Zug 23): Second Arcane Bolt refusal: active scene still lists Dalrei/Hobb/Mule even though narration placed me in the gallery — scene tracking lags my declared movement. Nothing spent or rolled either time.
- zu Zug 23 (notiert vor Zug 24): Narration finally processed my departure from the hut and moved me into the first gallery, with the bolt already building at my staff tip; HUD still lists warden's hut as location, so scene-tracking lag persists. Time is 17:45 and Dalrei warned the light dies fast.
- zu Zug 24 (notiert vor Zug 25): Third target refusal: scene tracking still lists the hut occupants despite narration confirming I am in the gallery. Trying a movement-only turn so the scene updates before I cast.
- zu Zug 25 (notiert vor Zug 26): Fourth turn on scene lag: HUD still shows warden's hut despite narration twice confirming I'm in the gallery. Beetles remain unalerted; MP 86/96, HP full.
- zu Zug 26 (notiert vor Zug 27): Narrator finally processed my departure from the hut (Dalrei watched me take up my things) and placed me in the gallery, yet the newest attack refusal still lists ACTIVE SCENE as Dalrei/Hobb/Mule — System scene state is desynced from narration after five attempts. Beetles remain unalerted; MP 86/96, HP full.
- zu Zug 27 (notiert vor Zug 28): #help lists no scene command; #combat and #audit may reveal how the engine records scene state. Fifth attempt pending.
- zu Zug 28 (notiert vor Zug 29): #combat says Combat INACTIVE until hostile commitment; scene tracking is stuck on the warden's hut despite narration moving me to the gallery.
- zu Zug 29 (notiert vor Zug 30): System confirms scene is now the first gallery with three beetles as legal targets; combined travel+attack in one message is the correct pattern.
- zu Zug 30 (notiert vor Zug 31): The scene regressed to the warden's hut again despite the prior System confirmation that it was the gallery; the System's own correction says travel+attack must be combined in one message.
- zu Zug 31 (notiert vor Zug 32): Narration confirms I'm in the gallery with the bolt building; HUD still stale on the warden's hut, but the narrator block is the newest scene state.
- zu Zug 32 (notiert vor Zug 33): Same refusal a sixth time: active scene remains the warden's hut occupants despite narrator confirming I am in the gallery with a bolt building. The scene tracker is not following travel narration.
- zu Zug 33 (notiert vor Zug 34): The System finally diagnosed the refusals: scene updates ride on the travel declaration itself, and it now lists mon.crystal_beetle_A/B/C as scene actors with Dalrei, Hobb and Mule A removed. No bolt outcome (MP cost, roll, damage) was actually shown, so I re-declare the attack rather than assume it resolved.
- zu Zug 34 (notiert vor Zug 35): Seventh refusal: despite the System's own diagnosis, the active scene still lists the hut occupants and the beetle remains an invalid target.
- zu Zug 35 (notiert vor Zug 36): Narrator confirms arrival in the first gallery with the bolt building, but the HUD still lists the warden's hut occupants as the active scene — same scene-track lag as before. Trying to fire the in-progress bolt without re-declaring travel this time.
- zu Zug 36 (notiert vor Zug 37): Eighth refusal: scene track remains locked on the warden's hut occupants even though narration twice confirms arrival in the gallery with a bolt building. Trying travel-only without an attached attack.
- zu Zug 37 (notiert vor Zug 38): Solo travel narration moves the story but never the HUD scene, which stays locked on the hut occupants; the System even listed mon.crystal_beetle_A/B/C as actors yet keeps refusing targets. Trying the exact actor ID once; if refused again I will inspect #help/#audit or switch to different contract work.
- zu Zug 38 (notiert vor Zug 39): Eighth consecutive target refusal: the active scene stays locked on Dalrei/Hobb/Mule A no matter the travel declaration, exact actor ID, or the System's own earlier fix. Checking the documented command list before abandoning the beetle contract for other work.
- zu Zug 39 (notiert vor Zug 40): Ninth refusal pattern persists; #help shows no scene/travel command exists, so I am checking #combat for the encounter registry.
- zu Zug 40 (notiert vor Zug 41): #combat reveals the core issue: combat is INACTIVE and 'a dangerous scene stays INACTIVE until a hostile commitment' — previous attacks may have failed because commitment was never registered, not just scene tracking.
- zu Zug 41 (notiert vor Zug 42): Narrator again confirms arrival at the beetles, but the HUD still shows warden's hut; #combat says combat stays INACTIVE until hostile commitment, so testing whether a concrete attack now registers.
- zu Zug 42 (notiert vor Zug 43): Narrator again confirms arrival at the beetles, but the scene registry still shows the warden's hut occupants; hostile commitment did not activate combat.
- zu Zug 43 (notiert vor Zug 44): System confirms the active scene is the warden's hut (Dalrei, Hobb, mule) — the beetles were never present; earlier attacks failed on location, not commitment.
- zu Zug 44 (notiert vor Zug 45): HUD now confirms location Glimmerdeep Grotto with beetles present; the scene lock finally updated after the explicit travel declaration at the dungeon gate.
- zu Zug 45 (notiert vor Zug 46): System says ACTIVE SCENE has no targetable actor despite the narrator placing three beetles in the gallery; scene registry and narration are desynced again.
- zu Zug 46 (notiert vor Zug 47): Scene registry finally matches the grotto, but combat still reports INACTIVE pending a hostile commitment despite my prior cast attempt.
- zu Zug 47 (notiert vor Zug 48): Narrator now shows the bolt held at staff tip waiting on release after the hostile declaration; combat may now be activatable by actually firing.
- zu Zug 48 (notiert vor Zug 49): System again reports no targetable actor even after the hostile commitment and narrator's reacting beetles; the descriptive target was rejected, so I retry the exact actor ID under the corrected scene.
- zu Zug 49 (notiert vor Zug 50): Third failed attack attempt: System says no targetable actor despite the hostile declaration and narrator's reacting beetles. Retrying with a basic melee attack before falling back to other grotto work.
- zu Zug 50 (notiert vor Zug 51): Fourth consecutive 'no targetable actor' refusal despite hostile commitment and narrator-placed beetles; scene registry seems empty, so I check command help for a way to list actors.
- zu Zug 51 (notiert vor Zug 52): Fifth attack refusal in a row; scene registry remains empty despite narrator beetles. Consulting the System directly as an alternative to repeated attempts.
- zu Zug 52 (notiert vor Zug 53): System clarified the exact gating: a hostile action in a player message must be read by the engine to register foes; my earlier declarations may have been too meta. Retrying with a plain natural attack.
- zu Zug 53 (notiert vor Zug 54): My staff strike on the lead beetle finally resolved in narration — the engine may have registered the encounter this time; verifying via #combat before casting.
- zu Zug 54 (notiert vor Zug 55): Narrator resolved my staff strike (hit, shell held, all three beetles aggro) yet #combat still reports INACTIVE — narration and engine state contradict. This is another registration attempt; if refused again I will withdraw and try different work.
- zu Zug 55 (notiert vor Zug 56): Sixth target refusal: narrator shows an active three-beetle fight, #combat stays INACTIVE and the registry stays empty — a persistent narration/engine contradiction. If this cast also fails I will withdraw from the gallery.
- zu Zug 56 (notiert vor Zug 57): The System finally offered a disambiguation menu for the beetles — a path to registering a valid target; the earlier 'no targetable actor' refusals may have stemmed from ambiguous references.
- zu Zug 57 (notiert vor Zug 58): The System's own menu wording must be echoed verbatim; paraphrasing like 'the one I already struck' was rejected as invalid target.
- zu Zug 58 (notiert vor Zug 59): Echoing the menu option verbatim ('the one you struck') was still rejected as no targetable actor — second refusal on the same menu; trying a different listed option before this counts as the third.
- zu Zug 59 (notiert vor Zug 60): Third consecutive 'no targetable actor' refusal against visibly present beetles — the encounter cannot be registered by any wording. Withdrawing to find other targets; noting this as a persistent narration/engine contradiction.
- zu Zug 60 (notiert vor Zug 61): Withdrawing failed: three more beetles block the exit passage while the first three close in behind — six beetles, and the engine still lists 'no targetable actor'. Checking the combat panel once before choosing a response.
- zu Zug 61 (notiert vor Zug 62): Six beetles now surround the passage; #combat still INACTIVE with 'no targetable actor' despite visible enemies — trying the most basic skill to force combat state.
- zu Zug 62 (notiert vor Zug 63): Combat remains INACTIVE with 'no targetable actor' even with six beetles surrounding me — Basic Attack also refused. Seeking a command to inspect or enter the scene properly.
- zu Zug 63 (notiert vor Zug 64): Six beetles surround me yet combat stays INACTIVE and no wording registers a target; using the #system mechanics question as the last diagnostic before withdrawing.
- zu Zug 64 (notiert vor Zug 65): System clarified: narrated beetles were never engine-registered; a declared attack should fix the encounter and register combat actors.
- zu Zug 65 (notiert vor Zug 66): Fourth target refusal despite the System's instruction to attack a declared beetle; the prose beetles and the three registered 'not met' beetles still never connect.
- zu Zug 66 (notiert vor Zug 67): Fourth target refusal; the prose beetles remain unregistered despite following the System's exact instructions. Abandoning this encounter as a persistent blockage after three-plus failures.
- zu Zug 67 (notiert vor Zug 68): After withdrawal the engine finally registered three beetles (A/B/C) as present targets; the dungeon level shows 0 of ? threats dealt with, so killing them likely counts toward the active clear contract.
- zu Zug 68 (notiert vor Zug 69): Combat finally registered and running; A at 5 HP, my Basic Attack outdamages Arcane Bolt per panel but Bolt is safer to guarantee the kill.
- zu Zug 69 (notiert vor Zug 70): Combat runs cleanly now; A defeated, B and C each hit for ~6-10 per round. HP 49/90 and dropping ~16/round — may need Arcane Ward or a potion after this fight.
- zu Zug 70 (notiert vor Zug 71): HP down to 33/90 with C untouched (29 HP); after B falls I will likely need Arcane Ward plus a potion to survive C.
- zu Zug 71 (notiert vor Zug 72): HP down to 27/90 with C fresh at 29 HP; I take ~6-10/round, so Arcane Ward plus finishing C with basics is the cautious route.
- zu Zug 72 (notiert vor Zug 73): Arcane Ward worked, absorbing C's 6 damage fully; but the chained Basic Attack was refused — one main action per turn. C at 29 HP, Bolt's 32-39 should finish it.
- zu Zug 73 (notiert vor Zug 74): Level 2 confirmed, +216 XP, loot: 4 chitin plates and 1 venom gland. HP 27/95 badly wounded; a threat still follows behind. Max HP/MP rose to 95/108.
- zu Zug 74 (notiert vor Zug 75): Level 2 confirmed, stats assigned; HP 27/95 still badly wounded and a threat follows behind the way I came.
- zu Zug 75 (notiert vor Zug 76): Note: contract not cleared — only 3 beetles of ? threats dealt with, so no turn-in yet. HP 27/110, evening rain, long walk back.
- zu Zug 76 (notiert vor Zug 77): Narrator placed me still on the bog road while the HUD already says Glimmerdeep Grotto; per conventions I follow the System and head for Glassmere. Contract not cleared — only beetle threats dead, so no turn-in yet.
- zu Zug 77 (notiert vor Zug 78): Innkeeper offers room for 8 cp with breakfast or 6 cp without; I have 5s 2cp and am badly wounded at 27/110 HP.
- zu Zug 78 (notiert vor Zug 79): Lodging with breakfast purchased and recorded (-8 cp, key in hand). Stew offered at 2 cp; HUD shows 4 Silver 4 Copper while purchase note said 44 cp — consistent.
- zu Zug 79 (notiert vor Zug 80): Stew bought and eaten; room key in hand. Note: HUD shows a carried 'bowl of stew (portion)' even though I ate it — minor inventory oddity.
- zu Zug 80 (notiert vor Zug 81): Full overnight recovery confirmed: HP 110/110, MP 116/116. Grotto contract still not cleared — only 7 chitin plates and a venom gland looted so far; may need to finish clearing or return to the Guild for guidance.
- zu Zug 81 (notiert vor Zug 82): Board shows five Novice jobs; the Grotto contract remains active and uncleared. XP 186/200, nearly Level 3.
- zu Zug 82 (notiert vor Zug 83): Boar cull confirmed ACTIVE in HUD (0/4). Guild sells skill primers at 120 cp; I hold 4s 2cp — affordable after boar reward.
- zu Zug 83 (notiert vor Zug 84): Boar contract active 0/4; farmer points to the broken fence at the far end as the entry point. Nearly Level 3 at 186/200 XP.
- zu Zug 84 (notiert vor Zug 85): Boar A (HP 108/108, MEDIUM) has entered at the broken fence and is testing the air; contract shows 0/4.
- zu Zug 85 (notiert vor Zug 86): Boar A closed and gored me for 28 (HP 82/110); Arcane Bolt hit for 32 on first strike. Farmer is watching from SHORT range.
- zu Zug 86 (notiert vor Zug 87): Boar at 44/108, my HP down to 57 after two gores to the same leg; two more bolts should finish it but a third hit is dangerous — farmer approaching.
- zu Zug 87 (notiert vor Zug 88): Boar A at 6 HP after three bolts; I'm down to 31 HP from repeated gores — this fight is far more dangerous than expected for a MEDIUM target.
- zu Zug 88 (notiert vor Zug 89): Level 3 confirmed with 5 free points; boar A defeated (1/4), 224 XP, hide and 2 tusks looted. HP critically low at 31/115.
- zu Zug 89 (notiert vor Zug 90): Level 3 confirmed, points assigned; HP still critical at 31/115 and 3 boars remain on the contract. Taking the offered rest and bandaging is the cautious play.
- zu Zug 90 (notiert vor Zug 91): Oddity: System posted 'QUEST FAILED — Clear Glimmerdeep Grotto Level 1 (Novice)' — I never accepted that contract, only carried its slip; noting the contradiction. HP 31/130, 3 boars remain.
- zu Zug 91 (notiert vor Zug 92): Overnight recovery fully restored HP 130/130 and MP 136/136; still noting the unexplained QUEST FAILED notice for a Grotto contract I never accepted.
- zu Zug 92 (notiert vor Zug 93): All three remaining boars present and at full HP; I'm fully recovered. Fight is 3-on-1, so caution and cover matter.
- zu Zug 93 (notiert vor Zug 94): System required a target disambiguation before spending anything; no roll occurred yet.
- zu Zug 94 (notiert vor Zug 95): Arcane Bolt refused at LONG range; need MEDIUM. Boars still unaware at full HP.
- zu Zug 95 (notiert vor Zug 96): Ambush crit landed for 52; Boar C at 46 HP and charging to SHORT, other two at MEDIUM. Killing C first reduces the 3-on-1.
- zu Zug 96 (notiert vor Zug 97): Boar C's dying charge still gored me for 21 (HP 109/130); B and D are now at SHORT. My staff is out of reach but casting works without it.
- zu Zug 97 (notiert vor Zug 98): Two boars now ENGAGED; taking 21-28 per round while at 59 HP. Arcane Ward (10 MP) is the only defensive option listed.
- zu Zug 98 (notiert vor Zug 99): Ward absorbed 27 damage but I'm at 37 HP with both boars engaged; killing D quickly is critical.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t14 | 14 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t32 | 68 | 3 | – | nein | 3 | gewonnen, 216 XP |
| enc.t48 | 85 | 1 | – | nein | 1 | gewonnen, 224 XP |
| enc.t56 | 95 | 3 | – | nein | 1 | **tot** |

## Quests

- **Slay the Weir-Lurking Bog Strider** — active (Zug 11) → completed (Zug 15), READY
  - Aufgabe: Kill 1 the bog strider at the eel-weirs of the Reed Flats at the eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the bog strider at the eel-weirs of the Reed Flats killed at the eel-weirs of the Reed Flats.
- **Thin the Orchard Boar Sounder** — expired (Zug 81)
  - Aufgabe: Kill 5 orchard boars of the Hollow Row cider orchards at the cider orchards along Hollow Row. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 5 orchard boars of the Hollow Row cider orchards killed at the cider orchards along Hollow Row.
- **Slay the Pale Stag of the Mistfen** — expired (Zug 81)
  - Aufgabe: Kill 1 the mana-drunk pale stag of the Mistfen at the Mistfen reedlands north of Glassmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the mana-drunk pale stag of the Mistfen killed at the Mistfen reedlands north of Glassmere.
- **Kill the Ashen Ridge Cave Bear** — expired (Zug 81)
  - Aufgabe: Kill 1 the great scarred cave bear of the Ashen Ridge at the kiln camps under the Ashen Ridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the great scarred cave bear of the Ashen Ridge killed at the kiln camps under the Ashen Ridge.
- **Clear Glimmerdeep Grotto Level 1** — active (Zug 17) → failed (Zug 90), Dungeon loc.glimmerdeep_grotto Ebene 1
  - Aufgabe: Clear level 1 of Glimmerdeep Grotto. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Glimmerdeep Grotto is clear.
- **Cull the Tusked Orchard Boars along Hollow Row** — active (Zug 82)
  - Aufgabe: Kill 4 tusked orchard boars at the cider orchards along Hollow Row. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 tusked orchard boars killed at the cider orchards along Hollow Row.
- **Clear Level 1 of Glimmerdeep Grotto** — taken_by_other (Zug 90), Dungeon loc.glimmerdeep_grotto Ebene 1
  - Aufgabe: Clear level 1 of Glimmerdeep Grotto. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Glimmerdeep Grotto is clear.

## Auffälligkeiten

- Zug 3, Nachricht 5 (board_failed): the board generator failed
- Zug 5, Nachricht 10 (extraction_repaired): the extractor's first answer needed a repair
- Zug 7, Nachricht 14 (extraction_repaired): the extractor's first answer needed a repair
- Zug 8, Nachricht 16 (extraction_repaired): the extractor's first answer needed a repair
- Zug 8, Nachricht 16 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 8, Nachricht 16 (finish): extract ended with finish_reason "length"
- Zug 13, Nachricht 26 (extraction_repaired): the extractor's first answer needed a repair
- Zug 19, Nachricht 38 (extraction_repaired): the extractor's first answer needed a repair
- Zug 23, Nachricht 46 (extraction_repaired): the extractor's first answer needed a repair
- Zug 23, Nachricht 46 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 23, Nachricht 46 (finish): extract ended with finish_reason "length"
- Zug 35, Nachricht 69 (planner_repaired): the planner's first answer needed a repair
- Zug 35, Nachricht 69 (finish): plan ended with finish_reason "length"
- Zug 41, Nachricht 81 (planner_repaired): the planner's first answer needed a repair
- Zug 41, Nachricht 81 (finish): plan ended with finish_reason "length"
- Zug 41, Nachricht 82 (extraction_repaired): the extractor's first answer needed a repair
- Zug 44, Nachricht 88 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (crystal beetle): refused, no fight (Patch 8.4.1 guard)
- Zug 45, Nachricht 89 (planner_repaired): the planner's first answer needed a repair
- Zug 47, Nachricht 94 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (crystal beetle): refused, no fight (Patch 8.4.1 guard)
- Zug 49, Nachricht 97 (planner_repaired): the planner's first answer needed a repair
- Zug 53, Nachricht 106 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (crystal beetle): refused, no fight (Patch 8.4.1 guard)
- Zug 53, Nachricht 106 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (crystal beetle): refused, no fight (Patch 8.4.1 guard)
- Zug 53, Nachricht 106 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (crystal beetle): refused, no fight (Patch 8.4.1 guard)
- Zug 60, Nachricht 119 (planner_repaired): the planner's first answer needed a repair
- Zug 60, Nachricht 119 (finish): plan ended with finish_reason "length"
- Zug 60, Nachricht 120 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (crystal beetle): refused, no fight (Patch 8.4.1 guard)
- Zug 60, Nachricht 120 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (crystal beetle): refused, no fight (Patch 8.4.1 guard)
- Zug 84, Nachricht 168 (extraction_repaired): the extractor's first answer needed a repair
- Zug 92, Nachricht 184 (extraction_repaired): the extractor's first answer needed a repair
- Zug 92, Nachricht 184 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 92, Nachricht 184 (finish): extract ended with finish_reason "length"
- Zug 90, Nachricht 180 (floor_cleared_by_others): level 1 of loc.glimmerdeep_grotto was cleared, not by him (credit: others)
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 12× keine gültige JSON-Entscheidung (Züge 2, 8, 11, 13, 21, 29, 75, 76, 78, 85, 92, 95)
- 6 Aufruf(e) mit finish_reason "length" (Nr. 22 extract, Nr. 68 extract, Nr. 83 plan, Nr. 92 plan, Nr. 120 plan, Nr. 202 extract)

System-Panels: CLARIFY 2, NOT TAKEN 2, REFUSED 0, BLOCKED 0, FAILED 1. Zurückgewiesene Deltas: guild_canon 1, no_go 1, scene_context 19, time_cap 1, engine_booked 1, guild_payout 1, engine_owned_fact 4, ambient 3, passage 7, dungeon_foe 7, world_rule 20, dungeon_foe_thread 1, group_unclear 2, offer 1, engine_recovery 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 3, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 87 | 5 | 2.4 s | 4.9 s | 11613 | 9780 | 71 | – | stop 84, length 3 | 3 |
| board | 6 | 3 | 8.8 s | 12.1 s | 2958 | 2459 | 1143 | – | stop 6 | 0 |
| narrator | 62 | 0 | 7.7 s | 10.7 s | 11350 | 8704 | 377 | – | stop 62 | 0 |
| extract | 68 | 7 | 5.3 s | 15.2 s | 11879 | 9205 | 361 | – | stop 65, length 3 | 3 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 38:48 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 9.2 s) | 0:26 min |
| 99 Züge, Spiel (Senden bis HUD nach der Extraktion) | 28:12 min — Median 15.7 s, p90 37.3 s, max 70.5 s |
| 99 Züge, Spieler-Entscheidung | 8:43 min — Median 2.8 s, 13 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 5:18 min / 0:57 min / 8:44 min / 9:06 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 22.4 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 14:55 min, 80 Züge ≈ 29:50 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spieler | 44 | – | 61.5 s | 2.8 s |
| Spieler | 27 | – | 36.3 s | 2.8 s |
| Spieler | 34 | – | 32.5 s | 2.8 s |
| Spiel | 60 | – | 70.5 s | 15.7 s |
| Spiel | 92 | – | 65.3 s | 15.7 s |
| Spiel | 23 | – | 63.6 s | 15.7 s |
| Provider narrator | 78 | 159 | 39.9 s | 7.7 s |
| Provider extract | 8 | 22 | 45.3 s | 5.3 s |
| Provider extract | 23 | 68 | 44.4 s | 5.3 s |
| Provider extract | 92 | 202 | 39.9 s | 5.3 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
