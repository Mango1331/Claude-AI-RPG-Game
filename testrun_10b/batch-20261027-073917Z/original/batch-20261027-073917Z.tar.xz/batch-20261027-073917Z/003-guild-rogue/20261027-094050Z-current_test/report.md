# Avereth Live-Test 20261027-094050Z-current_test

## Kurzfassung

- **Laufprofil:** guild-rogue; Startklasse Rogue, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** abgebrochen: Limit erreicht — 150 turns
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 8. Sicherheitsgrenzen: 150 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** Level 6, 216 XP seit Levelaufstieg, 662 cp, HP 108, MP 100; Ort loc.vintners_press_house. Ausrüstung und Skills stehen in evaluation.json → progression.checkpoint.
- **Charakter:** rogue (rogue.razor_cut, rogue.evasive_step) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: pragmatic adventurer: sell surplus loot and invest in useful equipment and techniques
- **Züge:** 150 · **Dauer:** 78:27 min · **LLM-Aufrufe der Engine/des Erzählers:** 427
- **Auffälligkeiten:** 62
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.101 |
| Git | c9e3fa58bb57 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 14.2 s |
| Browser | chrome 156.0.8078.48 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261027-094050Z-current_test“, Seed 1613311443 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | Rogue | Engine (Menü/Rückfrage) | creation_complete | Choose Rogue as base class. | public roadside verge outside Alderwatch | 90/84 | 2.3 s |
| 2 | I choose Razor Cut and Evasive Step as my two starter skills. | Engine (Menü/Rückfrage) | creation_complete | Select the two starter Rogue skills to finish character creation. | public roadside verge outside Alderwatch | 90/84 | 2.1 s |
| 3 | I walk to Alderwatch and head for the Adventurers' Guild hall to look at the contract board. | Erzähler | open_run_level | Enter the city and find the Guild board for a first contract. | Adventurers' Guild hall, Alderwatch | 90/84 | 49.6 s |
| 4 | "I'd like to take the Cull the Millpond Rat Pack contract, please — log it for me." | Erzähler | open_run_level | Register the rat cull contract at the desk so it becomes active. | Adventurers' Guild hall, Alderwatch | 90/84 | 15.3 s |
| 5 | "Yes, I'll register. Here's two silver — and my name is Alaric." | Erzähler | open_run_level | Pay the two-silver fee and register with the Guild as a Novice. | Adventurers' Guild hall, Alderwatch | 90/84 | 18.2 s |
| 6 | "Still yes." I place two silver on the desk and put my hand flat on the measuring stone. | Erzähler | open_run_level | Pay the registration fee and complete the Power Rank reading to become a registered Novice… | Adventurers' Guild hall, Alderwatch | 90/84 | 22.2 s |
| 7 | "Yes — log the Cull the Millpond Rat Pack contract under my name, please." | Erzähler | open_run_level | Register as Novice (done) and accept the rat cull contract. | Adventurers' Guild hall, Alderwatch | 90/84 | 19.5 s |
| 8 | "Nothing else — I'm off to the mill." I leave the Guild hall and walk south along the river road to Cobblemill, then find the old millpond s… | Erzähler | open_run_level | Travel to Cobblemill's millpond shed to hunt the contract rats. | the millpond shed at Cobblemill | 90/84 | 59.4 s |
| 9 | I draw my starter dagger, push the crooked door open, and step in to attack the oversized rat inside. | Erzähler | open_run_level | Enter the shed and kill the contract rat. | the millpond shed at Cobblemill | 90/84 | 18.7 s |
| 10 | I strike at the rat with Razor Cut as it lunges at me. | Erzähler | open_run_level | Attack the engaged oversized rat with my dagger skill. | the millpond shed at Cobblemill | 90/84 | 42.5 s |
| 11 | I head back north along the river road to the Alderwatch Guild hall and turn in the Cull the Millpond Rat Pack contract at the desk. | Erzähler | open_run_level | Return to the Guild hall and turn in the completed rat cull contract. | Adventurers' Guild hall, Alderwatch | 90/84 | 16.6 s |
| 12 | "What else is on the Novice board? I'm looking for another contract." | Erzähler | open_run_level | Ask the clerk for the next achievable Novice contract from the board. | Adventurers' Guild hall, Alderwatch | 90/84 | 17.9 s |
| 13 | "Log the boar sow job under my name, please — Thin the Fox-Size Boar Sow at the Vine Rows." | Erzähler | open_run_level | Accept the single-kill boar sow contract, the most achievable posting on the Novice board … | Adventurers' Guild hall, Alderwatch | 90/84 | 12.5 s |
| 14 | "Nothing else — I'm off to the vine rows." I leave the Guild hall, head south out of the city, and walk up onto the Alderwatch Slopes to fin… | Erzähler | open_run_level | Travel to the vine rows on the Alderwatch Slopes to hunt the contract boar sow. | the vine rows on the Alderwatch Slopes | 90/84 | 22.3 s |
| 15 | "I'm the tracking sort." I examine the mud by the upper wall and follow the sow's trail down toward the wood. | Erzähler | open_run_level | Track the boar sow from the vine rows into the wood. | the wooded fold below the vine rows | 90/84 | 29.3 s |
| 16 | I stay downwind and sneak closer through the fern brake, then strike her flank with Razor Cut. | Erzähler | open_run_level | Ambush the boar sow from stealth with Razor Cut. | the wooded fold below the vine rows | 90/84 | 41.1 s |
| 17 | I creep down through the fern brake to the streambed, cross it quietly, and close on her flank — once in range, I strike with Razor Cut. | Erzähler | open_run_level | Close to melee range across the streambed, then ambush the sow with Razor Cut. | the wooded fold below the vine rows | 90/84 | 16.6 s |
| 18 | I draw my dagger and charge the twenty paces to close with her, then strike with Razor Cut. | Erzähler | open_run_level | Close to ENGAGED range openly and attack with Razor Cut. | the wooded fold below the vine rows | 82/84 | 86.3 s |
| 19 | I strike again with Razor Cut before she can recover. | Erzähler | open_run_level | Finish the wounded sow with Razor Cut. | the wooded fold below the vine rows | 82/84 | 14.3 s |
| 20 | I take the hide and tusk as proof and head back up to the vine rows, then return to the Guild hall to turn in the boar sow contract. | Erzähler | open_run_level | Return to the Guild hall and turn in the completed boar sow contract with the loot as proo… | Adventurers' Guild hall, Alderwatch | 82/84 | 44.5 s |
| 21 | #quests | System (Befehl) | open_run_level | Inspect the quest panel to see why the boar sow kill was not counted. | Adventurers' Guild hall, Alderwatch | 82/84 | 2.1 s |
| 22 | #audit | System (Befehl) | open_run_level | Check the audit log for why the boar sow kill wasn't recorded on the contract. | Adventurers' Guild hall, Alderwatch | 82/84 | 2.1 s |
| 23 | #quest Thin the Fox-Size Boar Sow at the Vine Rows | System (Befehl) | open_run_level | Inspect quest detail/progress to find why the sow kill is not counted. | Adventurers' Guild hall, Alderwatch | 82/84 | 2.1 s |
| 24 | I hand the clerk the contract slip, the sow hide and the tusk, and ask to turn in the boar sow contract. | Erzähler | open_run_level | Attempt the turn-in in person with proof of the kill. | Adventurers' Guild hall, Alderwatch | 82/84 | 26.3 s |
| 25 | I take back the slip and head back up to the vine rows to confirm the sow's carcass and settle the count. | Erzähler | open_run_level | Return to the vine rows to confirm the contract sow is dead so the count updates and payme… | the vine rows on the Alderwatch Slopes | 82/84 | 23.3 s |
| 26 | I head down to the streambed in the wooded fold to find and confirm the sow's carcass. | Erzähler | open_run_level | Locate and confirm the contract sow's carcass so the kill count settles and payment can be… | the wooded fold below the vine rows | 82/84 | 17.4 s |
| 27 | I follow the drag marks and fresh boar tracks down to the streambed to find the sow's carcass. | Erzähler | open_run_level | Locate and confirm the contract sow's carcass at the streambed so the kill count settles a… | the streambed in the wooded fold | 82/84 | 21.6 s |
| 28 | I strike the distracted sow from behind with Razor Cut, aiming for its throat. | Erzähler | open_run_level | Ambush the feeding second sow with Razor Cut to score the contract kill and the level-up. | the streambed in the wooded fold | 82/84 | 16.9 s |
| 29 | I close the three strides to ENGAGED and strike her throat with Razor Cut. | Erzähler | open_run_level | Move into ENGAGED range and ambush the second sow with Razor Cut. | the streambed in the wooded fold | 74/84 | 38.7 s |
| 30 | I finish her with another Razor Cut at her throat. | Erzähler | open_run_level | Kill the wounded sow B with Razor Cut to complete the contract kill. | the streambed in the wooded fold | 74/84 | 33.6 s |
| 31 | #assign AGI 2 PER 2 VIT 1 | System (Befehl) | open_run_level | Spend the 5 level-up stat points on AGI, PER and VIT. | the streambed in the wooded fold | 74/84 | 2.1 s |
| 32 | #quest Thin the Fox-Size Boar Sow at the Vine Rows | System (Befehl) | open_run_level | Inspect the quest panel to see whether the kill registered after defeating the second sow. | the streambed in the wooded fold | 74/84 | 2.2 s |
| 33 | I drag the second sow's carcass up to the vine rows by the upper wall so the kill is confirmed at the contract site, then take the slip back… | Erzähler | open_run_level | Move the contract sow's carcass to the vine rows and return to the Guild to turn in the qu… | Adventurers' Guild hall, Alderwatch | 74/84 | 92.1 s |
| 34 | I return to the vine rows and wait by the upper wall for dusk, ready to kill the sow there at the rows where the contract counts. | Erzähler | open_run_level | Kill a tusked sow at the vine rows site itself so the engine records the contract kill. | the vine rows on the Alderwatch Slopes | 74/84 | 27.4 s |
| 35 | I wait at the upper wall until dusk falls, dagger ready, watching the tree line below. | Erzähler | open_run_level | Wait through to dusk at the vine rows so the contract sow arrives and can be killed on sit… | the vine rows on the Alderwatch Slopes | 74/84 | 21.6 s |
| 36 | I stand watch through the night at the upper wall, dagger ready, waiting for the remaining tusked sow to come up from the stream cut to feed… | Erzähler | open_run_level | Ambush the remaining sow at the vine rows at night so the kill registers on site for the c… | the vine rows on the Alderwatch Slopes | 74/84 | 18.5 s |
| 37 | #quest Thin the Fox-Size Boar Sow at the Vine Rows | System (Befehl) | open_run_level | Inspect the contract's exact terms to see why the sow kill is not counting. | the vine rows on the Alderwatch Slopes | 74/84 | 2.2 s |
| 38 | I wait at the upper wall through the day until dusk, dagger ready for the sow that comes up from the stream cut to root the rows. | Erzähler | open_run_level | Ambush the dusk sow at the vine rows so the kill registers on site for the contract. | the vine rows on the Alderwatch Slopes | 74/84 | 21.5 s |
| 39 | I wait until she crosses onto the vine rows, then ambush her from behind the wall's end, striking her flank with Razor Cut. | Erzähler | open_run_level | Kill the dusk sow on the vine rows site so the engine records the contract kill. | the vine rows on the Alderwatch Slopes | 74/84 | 41.9 s |
| 40 | I close the dozen strides down the slope to engage her, then strike her flank with Razor Cut. | Erzähler | open_run_level | Move into ENGAGED range and attack the sow so the kill registers. | the vine rows on the Alderwatch Slopes | 74/84 | 17.0 s |
| 41 | I leave the wall's end and walk straight down the slope toward the sow, closing to engage her. | Erzähler | open_run_level | Close the distance to ENGAGED range so an attack becomes possible next turn. | the vine rows on the Alderwatch Slopes | 74/84 | 52.6 s |
| 42 | I step the last few strides to her and strike her flank with Razor Cut. | Erzähler | open_run_level | Attack the sow at SHORT range so the kill registers for the contract. | the vine rows on the Alderwatch Slopes | 54/84 | 14.9 s |
| 43 | I strike her flank again with Razor Cut. | Erzähler | open_run_level | Keep attacking the sow at ENGAGED range to finish her for the contract. | the vine rows on the Alderwatch Slopes | 34/84 | 14.3 s |
| 44 | I strike her flank with Razor Cut one more time to finish her. | Erzähler | open_run_level | Kill the sow this round before she gores me again. | the vine rows on the Alderwatch Slopes | 34/84 | 16.6 s |
| 45 | I shoulder my gear and head back up the slope to Alderwatch, then straight to the Guild hall to turn in the boar sow contract. | Erzähler | open_run_level | Return to the Guild hall and turn in the completed boar sow contract for the 90 copper rew… | Adventurers' Guild hall, Alderwatch | 34/84 | 16.5 s |
| 46 | #assign VIT 2 WIL 2 INT 1 | System (Befehl) | open_run_level | Spend the 5 free stat points from the level-up. | Adventurers' Guild hall, Alderwatch | 34/84 | 2.2 s |
| 47 | I sell the surplus boar sow hide and tusk to the clerk, then ask what lodging nearby costs for the night. | Erzähler | open_run_level | Sell surplus loot and get lodging to recover HP overnight. | Adventurers' Guild hall, Alderwatch | 34/84 | 27.1 s |
| 48 | I accept her offer of twenty copper for the hide and tusk, then take the Grey Hen's ten-copper option for the night. | Erzähler | open_run_level | Sell surplus loot and buy lodging with wound care to recover HP overnight. | Adventurers' Guild hall, Alderwatch | 34/84 | 36.7 s |
| 49 | I tell Marren to look at the leg now, then eat and sleep until morning. | Erzähler | open_run_level | Get wound treatment, a meal and a full night's sleep to recover HP. | Adventurers' Guild hall, Alderwatch | 115/100 | 25.8 s |
| 50 | I sell the remaining sow hide and the pair of tusks to the clerk, then ask to see the Guild contract board for a new F-rank job. | Erzähler | open_run_level | Sell surplus loot and pick a new Guild contract. | Adventurers' Guild hall, Alderwatch | 115/100 | 97.1 s |
| 51 | I take the Rat in the Millpond Shed slip to the clerk and ask her to register the contract for me. | Erzähler | open_run_level | Accept the novice rat contract from the Guild board. | Adventurers' Guild hall, Alderwatch | 115/100 | 23.0 s |
| 52 | I ready my dagger, ease the shed door open, and approach the dark corner past the post, attacking the rat when it shows itself. | Erzähler | open_run_level | Fight the oversized rat in the millpond shed to complete the active contract. | Adventurers' Guild hall, Alderwatch | 115/100 | 20.8 s |
| 53 | I sidestep its lunge and slash at the rat with Razor Cut. | Engine (Menü/Rückfrage) | open_run_level | Fight the oversized rat in the millpond shed with Razor Cut to complete the active contrac… | Adventurers' Guild hall, Alderwatch | 115/100 | 3.8 s |
| 54 | I return to the millpond shed and attack the oversized rat in the dark corner past the post. | Erzähler | open_run_level | Re-enter the shed scene so the rat becomes a valid combat target. | the millpond shed at Cobblemill | 115/100 | 21.2 s |
| 55 | I use Razor Cut on Oversized Rat B. | Erzähler | open_run_level | Attack the now-valid engaged rat target with Razor Cut. | the millpond shed at Cobblemill | 115/100 | 16.0 s |
| 56 | I head back to the Guild hall and turn in the completed Rat in the Millpond Shed contract to the clerk. | Erzähler | open_run_level | Turn in the completed rat contract and collect the reward. | Adventurers' Guild hall, Alderwatch | 115/100 | 17.0 s |
| 57 | #assign AGI 2 PER 2 VIT 1 | System (Befehl) | open_run_level | Spend the 5 free stat points from Level 4. | Adventurers' Guild hall, Alderwatch | 115/100 | 2.2 s |
| 58 | "What contracts are on the board for a Novice Rogue? I'm looking for the next job." | Erzähler | open_run_level | Ask the clerk for the next available Guild contract. | Adventurers' Guild hall, Alderwatch | 115/100 | 13.0 s |
| 59 | I take the Boar in the Vine Rows slip from the board and ask the clerk to accept the contract. | Erzähler | open_run_level | Accept the boar sow contract at the Guild. | Adventurers' Guild hall, Alderwatch | 115/100 | 11.7 s |
| 60 | I travel south to the vine rows on the Alderwatch Slopes and look for the tusked boar sow tearing up the rows. | Erzähler | open_run_level | Travel to the vine rows and engage the boar sow for the active contract. | the vine rows on the Alderwatch Slopes | 115/100 | 22.4 s |
| 61 | I follow the fresh cloven prints through the hedge gap toward the treeline, keeping low and my dagger ready. | Erzähler | open_run_level | Track the boar sow toward the silent woodland and engage her for the active contract. | the mud hollow by the big beech | 115/100 | 66.9 s |
| 62 | I use Evasive Step to slip aside from her charge and strike her flank with Razor Cut as she passes. | Erzähler | open_run_level | Dodge the sow's charge and counter with Razor Cut. | the mud hollow by the big beech | 115/100 | 15.2 s |
| 63 | I throw myself aside behind the big beech as she charges. | Erzähler | open_run_level | Dodge the sow's charge as a single action this turn. | the mud hollow by the big beech | 115/100 | 16.7 s |
| 64 | I dash in and slash her flank with Razor Cut while she's still shaking off the beech impact. | Erzähler | open_run_level | Land the first hit on the dazed sow before she can charge again. | the mud hollow by the big beech | 115/100 | 13.7 s |
| 65 | I dart in and use Razor Cut on her flank at close range. | Erzähler | open_run_level | Attack the sow, whose HUD range reads SHORT despite the narrator's MEDIUM. | the mud hollow by the big beech | 115/100 | 51.1 s |
| 66 | I close the eight paces of mud and move to ENGAGED with the sow. | Erzähler | open_run_level | Move into ENGAGED range so Razor Cut becomes possible. | the mud hollow by the big beech | 115/100 | 12.0 s |
| 67 | I strike her flank with Razor Cut at ENGAGED range. | Erzähler | open_run_level | Land Razor Cut now that I'm in ENGAGED range. | the mud hollow by the big beech | 105/100 | 60.3 s |
| 68 | I finish her with Razor Cut. | Erzähler | open_run_level | Kill the wounded sow with Razor Cut while she's at 15 HP. | the mud hollow by the big beech | 105/100 | 11.6 s |
| 69 | I gather the hide and tusks and travel back to the Guild hall, where I show the clerk the contract slip and report that I defeated the tuske… | Erzähler | open_run_level | Turn in the boar contract at the Guild hall and resolve the 0/1 discrepancy. | Adventurers' Guild hall, Alderwatch | 105/100 | 24.9 s |
| 70 | "I took her in a muddy hollow off the slopes, not at the vine rows — the tracks led there. Can the kill still be registered, or should I tak… | Erzähler | open_run_level | Explain the kill location to the clerk and ask whether the contract can still be resolved. | Adventurers' Guild hall, Alderwatch | 105/100 | 18.8 s |
| 71 | I go to the brokerage counter and ask what they'll pay for my two sow hides and the tusk. | Erzähler | open_run_level | Sell surplus boar loot at the Guild brokerage. | Adventurers' Guild hall, Alderwatch | 105/100 | 24.2 s |
| 72 | I accept the 1 Gold 3 Silver for the lot, then go to the healer two doors down and ask them to treat my wounded leg. | Engine (Menü/Rückfrage) | open_run_level | Sell the boar loot at the offered price and get the leg healed. | Adventurers' Guild hall, Alderwatch | 105/100 | 7.3 s |
| 73 | I accept the 26 coppers for the lot, then go to the healer two doors down and ask them to treat my wounded leg. | Erzähler | open_run_level | Accept the broker's actual 26 cp offer and then get the leg healed. | the healer's shop | 105/100 | 23.0 s |
| 74 | "I'll take the full treatment — wash, stitches, salve, wrapping." | Erzähler | open_run_level | Buy the full 20 cp healing treatment from the healer. | the healer's shop | 105/100 | 15.4 s |
| 75 | I travel to the Guild hall and ask the clerk whether I can cancel the boar contract since the sow died off the vine rows — and if so, show m… | Erzähler | open_run_level | Cancel the blocked boar contract and pick a different achievable Guild contract. | Adventurers' Guild hall, Alderwatch | 105/100 | 24.2 s |
| 76 | "Close it as failed and void, please." I wait for that to be done, then take the Adder at the Weir Crossing slip from the board and ask the … | Erzähler | open_run_level | Void the blocked boar contract and take the adder kill contract instead. | Adventurers' Guild hall, Alderwatch | 105/100 | 16.3 s |
| 77 | I sell the oversized rat pelt and two tails at the brokerage if they're still buying, then set out east on the river road for the Weir Cross… | Erzähler | open_run_level | Sell surplus rat loot and travel for the adder contract. | the reedbanks at the Weir Crossing | 105/100 | 28.9 s |
| 78 | I knock at the ferry house and ask about the adder — where it's been seen and whether a bed for the night is available before I hunt it in t… | Erzähler | open_run_level | Get local info on the adder and lodging for the night before hunting. | the reedbanks at the Weir Crossing | 105/100 | 21.9 s |
| 79 | "I'll take bed, supper, and porridge — twelve coppers." I pay and stay the night, then hunt the adder at the old fish racks come morning. | Erzähler | open_run_level | Buy lodging and supper for 12 cp, sleep, then hunt the adder in daylight. | the reedbanks at the Weir Crossing | 105/100 | 43.5 s |
| 80 | I take the offered room upstairs and sleep until morning. | Erzähler | open_run_level | Book the room, sleep until morning, then hunt the adder. | the reedbanks at the Weir Crossing | 105/100 | 35.4 s |
| 81 | "The room, then — four coppers." I pay for the room and sleep until morning. | Erzähler | open_run_level | Book the room explicitly for four coppers, then sleep until morning. | the reedbanks at the Weir Crossing | 105/100 | 23.3 s |
| 82 | I take the room the keeper booked for me, bank the candle, and sleep. | Erzähler | open_run_level | Sleep in the paid-for room, phrasing it as using the booked room. | the reedbanks at the Weir Crossing | 125/100 | 71.7 s |
| 83 | I eat the porridge, then head downstream to the old fish racks and look for the adder sunning on the flat stones. | Erzähler | open_run_level | Eat breakfast and hunt the adder at the fish racks in daylight. | the old fish racks | 125/100 | 23.6 s |
| 84 | I follow the fresh drag-groove in the mud and search the thick reeds along the shelf for the large marsh adder. | Erzähler | open_run_level | Track the adder from the drag-groove into the reeds. | the hummock in the reeds | 125/100 | 23.6 s |
| 85 | It's cold and sluggish — I strike first with Razor Cut at the adder's head. | Erzähler | open_run_level | Initiate combat with Razor Cut while the adder is still dull with cold. | the hummock in the reeds | 125/100 | 16.4 s |
| 86 | I hold my ground and let the adder close to ENGAGED range, then strike with Razor Cut at its head. | Erzähler | open_run_level | Wait for the adder to come into range, then attack with Razor Cut. | the hummock in the reeds | 125/100 | 18.0 s |
| 87 | I step forward through the shallow mud into ENGAGED range and strike with Razor Cut at the adder's head. | Erzähler | open_run_level | Close to ENGAGED range and attack with Razor Cut. | the hummock in the reeds | 108/100 | 24.3 s |
| 88 | I finish it with Razor Cut at the adder's wounded head. | Erzähler | open_run_level | Kill the badly wounded adder with Razor Cut. | the hummock in the reeds | 108/100 | 66.9 s |
| 89 | I harvest nothing more and head back along the riverbank toward the Weir Crossing ferry house, then on to the Guild hall in town to turn in … | Erzähler | open_run_level | Return and turn in the completed adder contract at the Guild hall. | Adventurers' Guild hall, Alderwatch | 108/100 | 24.1 s |
| 90 | #assign AGI 5 PER 5 | System (Befehl) | open_run_level | Spend the 10 free stat points on AGI and PER. | Adventurers' Guild hall, Alderwatch | 108/100 | 2.2 s |
| 91 | "What have you got on the board for a Novice rogue? And do you buy monster parts here — I've got adder skin, fang, venom sac and boar hide t… | Erzähler | open_run_level | Ask the clerk for a new Guild contract and sell surplus loot. | Adventurers' Guild hall, Alderwatch | 108/100 | 51.0 s |
| 92 | "I'll take the Vine-Row Boar Sow contract." And to Marta: "I have adder skin, fang and venom sac, boar hide and rat pelts and tails to sell … | Erzähler | open_run_level | Accept the boar sow contract and ask merchant Marta for a loot offer. | Adventurers' Guild hall, Alderwatch | 108/100 | 29.2 s |
| 93 | "Done — I accept your offer of thirty-two silver ten for the lot." I hand over the adder skin, fang, venom sac, boar hide and the rat pelt a… | Engine (Menü/Rückfrage) | open_run_level | Sell all surplus loot to Marta for her offered 32s 10c. | Adventurers' Guild hall, Alderwatch | 108/100 | 10.7 s |
| 94 | I sell the adder skin, fang, venom sac, boar hide, rat pelt and two rat tails to Marta for thirty-two silver ten copper. | Engine (Menü/Rückfrage) | open_run_level | Complete the loot sale to Marta for her offered 32s 10c. | Adventurers' Guild hall, Alderwatch | 108/100 | 12.2 s |
| 95 | Marta, I'll buy out your whole offer — the adder skin, fang, venom sac, boar hide, rat pelt and both rat tails — for the thirty-two silver t… | Engine (Menü/Rückfrage) | open_run_level | Complete the loot sale to Marta as an explicit purchase of all her offer positions for 32s… | Adventurers' Guild hall, Alderwatch | 108/100 | 9.6 s |
| 96 | I buy all offer positions in Marta's current offer — adder skin, adder fang, venom sac, boar hide, rat pelt and two rat tails — for the list… | Erzähler | open_run_level | Complete the loot sale using explicit offer-position purchase wording. | Adventurers' Guild hall, Alderwatch | 108/100 | 19.7 s |
| 97 | #quests | System (Befehl) | open_run_level | Verify whether the Vine-Row Boar Sow contract is actually active before travelling. | Adventurers' Guild hall, Alderwatch | 108/100 | 2.3 s |
| 98 | Clerk, the Vine-Row Boar Sow is dead — I killed her at the vine rows. I turn in the contract and claim the payout. | Erzähler | open_run_level | Turn in the completed boar sow contract at the Guild counter. | Adventurers' Guild hall, Alderwatch | 108/100 | 25.8 s |
| 99 | I take my slip and head for the vintners' press-house on the Slopes to find the steward and get his sign-off on the dead sow. | Erzähler | open_run_level | Get the vintners' steward to mark the contract slip so the boar sow payout can be claimed. | vintners' press-house | 108/100 | 54.3 s |
| 100 | "I'm here about the boar sow you hired culled for — the big one rooting below your vine rows. She's dead; I killed her there yesterday eveni… | Erzähler | open_run_level | Ask the steward to verify the kill and sign off the contract slip. | vintners' press-house | 108/100 | 18.1 s |
| 101 | "Lead the way — I'll walk down and show you the carcass myself." | Erzähler | open_run_level | Accompany the steward to the sow's carcass for verification and sign-off. | the ditch below the last terrace | 108/100 | 78.4 s |
| 102 | I accept the steward's marked slip and the silver gratuity with my thanks, then head back to the Guild hall to claim the payout. | Erzähler | open_run_level | Take sign-off and gratuity, return to the Guild hall for the boar sow turn-in. | Adventurers' Guild hall, Alderwatch | 108/100 | 33.1 s |
| 103 | I hand the clerk the steward's marked slip. "That's her — verified by the vintners' steward himself. Settle it, please." | Erzähler | open_run_level | Turn in the marked slip and claim the boar sow payout. | Adventurers' Guild hall, Alderwatch | 108/100 | 20.0 s |
| 104 | I take the Vine-Row Boar Sow contract from the board and bring it to the clerk to take it under my name. | Erzähler | open_run_level | Take the still-posted contract from the board so it can be turned in with the marked slip. | Adventurers' Guild hall, Alderwatch | 108/100 | 25.4 s |
| 105 | I bring both slips — the Guild contract and the steward's marked slip — back to the clerk at the counter and hand them over for the turn-in. | Erzähler | open_run_level | Turn in the now-active Vine-Row Boar Sow contract with the steward's proof and claim the p… | Adventurers' Guild hall, Alderwatch | 108/100 | 16.5 s |
| 106 | I head back to the vintners' vine rows below the wall to check whether the sow the record needs is still there — the steward mentioned talk … | Erzähler | open_run_level | Return to the vine rows to find and defeat the sow the engine requires (0/1). | the vine rows on the Alderwatch Slopes | 108/100 | 23.9 s |
| 107 | "Point out Hesse's rows, then — and I'll take it from there." | Erzähler | open_run_level | Have Tam point out Hesse's middle-terrace rows, then hunt the second sow upslope. | the vine rows on the Alderwatch Slopes | 108/100 | 59.2 s |
| 108 | I follow the fresh trail upslope past the stone fence into the scrub, tracking quietly toward the treeline where the sow was seen. | Erzähler | open_run_level | Track the second sow past the stone fence and hunt it for the engine-registered kill. | the scrub treeline above the stone fence | 108/100 | 24.0 s |
| 109 | I circle quietly to her flank and strike with Razor Cut while her head is still down, aiming for her hind leg before she can turn. | Erzähler | open_run_level | Ambush the unaware second sow with Razor Cut to open the fight for the engine-registered k… | the scrub treeline above the stone fence | 108/100 | 16.6 s |
| 110 | I close the distance quietly through the scrub until Razor Cut can reach her, then strike her hind leg while her head is still down. | Erzähler | open_run_level | Move into ENGAGED range and ambush the sow with Razor Cut for the engine-registered kill. | the scrub treeline above the stone fence | 108/100 | 35.2 s |
| 111 | I strike her hind leg with Razor Cut while her head is still down. | Erzähler | open_run_level | Ambush the engaged sow with Razor Cut for the engine-registered kill. | the scrub treeline above the stone fence | 108/100 | 14.0 s |
| 112 | I finish her with a Basic Attack to the head before she can lunge again. | Erzähler | open_run_level | Kill the crippled sow with a Basic Attack for the engine-registered kill. | the scrub treeline above the stone fence | 108/100 | 57.0 s |
| 113 | I collect the kill confirmation on the contract slip and head back down the slope toward the road and Hesse's rows. | Erzähler | open_run_level | Return from the completed sow cull to report and claim the payout. | Hesse's rows | 108/100 | 23.1 s |
| 114 | "Both sows are dead, Hesse — the second was rooting upslope past the stone fence. The slip's marked ready; I'll take the payout, and if you … | Erzähler | open_run_level | Report the completed cull to Hesse and claim the reward before returning to the Guild. | Hesse's rows | 108/100 | 88.1 s |
| 115 | "Alaric Red. And the meat's yours if you want it — I've no claim on it. I'll head back to the Guild before the light goes." | Erzähler | open_run_level | Give Hesse my name, leave the meat to him, and return to the Guild to turn in the complete… | Adventurers' Guild hall, Alderwatch | 108/100 | 26.9 s |
| 116 | I hand the clerk the amber-marked slip and ask for the payout on the Vine-Row boar cull. | Erzähler | open_run_level | Turn in the completed sow cull contract at the Guild counter for the 90 cp reward. | Adventurers' Guild hall, Alderwatch | 108/100 | 40.4 s |
| 117 | I sell the boar hide and tusk at the brokerage counter, then look over the board for a fresh contract I can take on. | Erzähler | open_run_level | Sell surplus loot and pick a new Guild contract. | Adventurers' Guild hall, Alderwatch | 108/100 | 41.8 s |
| 118 | #assign AGI 3 PER 2 | System (Befehl) | open_run_level | Spend the 5 free stat points on AGI and PER. | Adventurers' Guild hall, Alderwatch | 108/100 | 2.4 s |
| 119 | I buy the Primer of Strike for 120 copper and, if the purchase is recorded, study it right away to learn the strike skill. | Erzähler | open_run_level | Buy the Guild's Primer of Strike and learn the strike skill before lodging for the night. | Adventurers' Guild hall, Alderwatch | 108/100 | 38.9 s |
| 120 | #bag | System (Befehl) | open_run_level | Check whether the Primer of Strike was actually recorded in my inventory. | Adventurers' Guild hall, Alderwatch | 108/100 | 2.4 s |
| 121 | The primer isn't in my bag and my coin is unchanged, so the purchase didn't take. I try again: I buy the Primer of Strike from the merchant … | Erzähler | open_run_level | Retry the primer purchase, since the bag and coin show it was never recorded. | Adventurers' Guild hall, Alderwatch | 108/100 | 22.1 s |
| 122 | I set 120 copper on the counter and say, "That's the coin — I'll take one of the Strike primers." | Erzähler | open_run_level | Complete the primer purchase with coin explicitly placed on the counter. | Adventurers' Guild hall, Alderwatch | 108/100 | 14.0 s |
| 123 | I sit under the lamp and study the Primer of Strike carefully, working through every page and practicing the motions until I've learned the … | Engine (Menü/Rückfrage) | open_run_level | Learn the strike skill from the purchased primer. | Adventurers' Guild hall, Alderwatch | 108/100 | 5.3 s |
| 124 | I study the Primer of Strike for 2 hours, practicing until I've learned the strike skill. | Erzähler | open_run_level | Study the primer for a stated duration to learn strike. | Adventurers' Guild hall, Alderwatch | 108/100 | 38.5 s |
| 125 | The hall is closing, so I head to an inn in Alderwatch, take a room for the night, and sleep until morning. | Erzähler | open_run_level | Get lodging and sleep overnight to recover HP and stamina, continuing the primer study tom… | the Green Barrel inn | 108/100 | 20.2 s |
| 126 | "The ten-copper room, and supper from the pot while it's hot." | Engine (Menü/Rückfrage) | open_run_level | Buy supper and the ten-copper room from the innkeeper, then sleep until morning. | the Green Barrel inn | 108/100 | 13.3 s |
| 127 | Both together — the room and supper, 14 copper. | Engine (Menü/Rückfrage) | open_run_level | Buy the room and supper together, then sleep until morning. | the Green Barrel inn | 108/100 | 7.7 s |
| 128 | Yes — supper plus the plain room, 14 copper. | Erzähler | open_run_level | Confirm the combined purchase of supper and the plain room, then sleep. | the Green Barrel inn | 108/100 | 16.9 s |
| 129 | I sit at a table and study the Primer of Strike for 3 hours, practicing the motions until the strike skill takes hold. | Erzähler | open_run_level | Continue gradual learning of strike with a stated study duration. | the Green Barrel inn | 108/100 | 19.6 s |
| 130 | I keep studying the Primer of Strike for another 4 hours, drilling until the strike skill is fully learned. | Erzähler | open_run_level | Continue gradual learning of strike with a stated study duration. | the Green Barrel inn | 108/100 | 17.0 s |
| 131 | I buy the porridge for 3 copper, then head to the Adventurers' Guild hall in Alderwalk and look over the contract board for an achievable so… | Erzähler | open_run_level | Recover with breakfast and pick a new Guild contract from the actual board. | Adventurers' Guild hall, Alderwatch | 108/100 | 29.5 s |
| 132 | #quests | System (Befehl) | open_run_level | Check quest panel status, since the boar sow slip and parts are in my bag but the quest li… | Adventurers' Guild hall, Alderwatch | 108/100 | 2.2 s |
| 133 | I take the Drive Off the Vine-Row Boar Sow slip from the board and hand the clerk the contract slip plus the sow hide and tusk as proof, ask… | Erzähler | open_run_level | Turn in the completed Vine-Row Boar Sow contract with proof at the Guild counter. | Adventurers' Guild hall, Alderwatch | 108/100 | 22.9 s |
| 134 | I ask the clerk to log the Drive Off the Vine-Row Boar Sow contract as active under my name, and to pay out my completed millpond rat and ma… | Erzähler | open_run_level | Register the fresh sow contract properly and turn in the completed contracts the quest pan… | Adventurers' Guild hall, Alderwatch | 108/100 | 59.0 s |
| 135 | I head to the Vine Rows with my active sow contract slip and hunt for the vine-row boar sow; if I find her, I attack with Razor Cut. | Erzähler | open_run_level | Travel to the Vine Rows and work the active sow contract. | the vine rows on the Alderwatch Slopes | 108/100 | 44.4 s |
| 136 | I ask Garr to point me toward the woodscrub past the top wall, then head up there, track the sow, and attack her with Razor Cut when I find … | Erzähler | open_run_level | Travel into the woodscrub and hunt the vine-row sow for the active contract. | the scrub treeline above the stone fence | 108/100 | 23.7 s |
| 137 | I follow the fresh sow tracks up into the gorse and leaning pines; if I find the sow, I attack her with Razor Cut. | Erzähler | open_run_level | Track the sow through the scrub from the confirmed treeline and engage her for the active … | the shelf between the rock outcrops | 108/100 | 19.2 s |
| 138 | I attack the sow with Razor Cut, aiming for her flank as she gathers to charge. | Erzähler | open_run_level | Engage the sow for the active contract. | the shelf between the rock outcrops | 108/100 | 18.1 s |
| 139 | I sprint the twenty paces toward the sow, using Evasive Step to stay evasive as I close, then strike her flank with Razor Cut. | Erzähler | open_run_level | Close to ENGAGED range and attack the sow for the active contract. | the shelf between the rock outcrops | 108/100 | 14.5 s |
| 140 | I strike her open flank with Razor Cut. | Erzähler | open_run_level | Attack the sow now that we're ENGAGED. | the shelf between the rock outcrops | 86/100 | 15.7 s |
| 141 | I strike her again with Razor Cut before she can recover. | Erzähler | open_run_level | Finish the wounded sow with Razor Cut. | the shelf between the rock outcrops | 86/100 | 66.9 s |
| 142 | I collect myself, then head back down through the vine rows to the steward to report the sow defeated and turn in the contract. | Erzähler | open_run_level | Turn in the completed sow contract at the steward's. | vintners' press-house | 86/100 | 19.4 s |
| 143 | I ask Dagget to confirm the sow is dealt with, then set out for the Guild hall in Alderwatch to turn in the contract. | Erzähler | open_run_level | Travel to Alderwatch Guild hall to turn in the completed sow contract. | Adventurers' Guild hall, Alderwatch | 86/100 | 23.4 s |
| 144 | I ask the clerk about the marsh adder notice for Weir Crossing and take that contract if it's open to my rank. | Erzähler | open_run_level | Take the marsh adder contract from the Guild board as the next solo job. | Adventurers' Guild hall, Alderwatch | 86/100 | 41.9 s |
| 145 | I travel east along the river road to Weir Crossing, then look for the reedbanks where the adder was seen. | Erzähler | open_run_level | Travel to Weir Crossing to hunt the marsh adder for the active contract. | the reedbanks at the Weir Crossing | 86/100 | 39.4 s |
| 146 | I thank the ferry keeper and head into the reedbank along the cut channel past the second trap line, watching the shallows for the adder. | Erzähler | open_run_level | Hunt the marsh adder in its reported channel. | the shallows past the second trap line | 86/100 | 56.7 s |
| 147 | I dodge aside with Evasive Step and strike the adder with Razor Cut as it lunges. | Erzähler | open_run_level | Dodge the adder's lunge and counter with Razor Cut. | the shallows past the second trap line | 86/100 | 23.6 s |
| 148 | I strike the adder with Razor Cut as it rears. | Erzähler | open_run_level | Attack the rearing adder with Razor Cut. | the shallows past the second trap line | 86/100 | 16.0 s |
| 149 | I step forward to close to ENGAGED range, then strike the adder with Razor Cut. | Erzähler | open_run_level | Close to ENGAGED and land Razor Cut on the adder. | the shallows past the second trap line | 86/100 | 23.2 s |
| 150 | #assign AGI 3 WIL 2 | System (Befehl) | open_run_level | Spend the five level-up stat points on Agility and Will. | the shallows past the second trap line | 86/100 | 2.6 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zum Start (notiert vor Zug 1): Character creation started; class choice pending.
- zu Zug 1 (notiert vor Zug 2): My previous plain-text reply was rejected; answers must be JSON objects.
- zu Zug 2 (notiert vor Zug 3): Character creation complete: Level 1 Rogue with Razor Cut and Evasive Step, starter gear equipped, 5 silver on hand.
- zu Zug 3 (notiert vor Zug 4): Guild registration may be required; HUD shows Guild Rank — (not registered), clerk said contracts activate only when logged at the desk.
- zu Zug 4 (notiert vor Zug 5): Registration costs 2 silver at the desk; affordable with 5 silver on hand.
- zu Zug 5 (notiert vor Zug 6): Registration procedure confirmed: 2 silver fee plus hand on the measuring stone; not yet completed, HUD still shows Guild Rank — (not registered).
- zu Zug 6 (notiert vor Zug 7): Registration completed: Guild Rank Novice confirmed in HUD, 2 silver paid, Power Rank F, Guild plate received. Contract still not active.
- zu Zug 7 (notiert vor Zug 8): Contract Cull the Millpond Rat Pack is now ACTIVE (0/1 defeated); needs one confirmed oversized-rat kill at the shed, 25 copper on turn-in.
- zu Zug 8 (notiert vor Zug 9): Arrived at the millpond shed; gnawing confirms something inside, and an abandoned maul lies by the door as an improvised option.
- zu Zug 9 (notiert vor Zug 10): Combat engaged: Oversized Rat A, HP 16/16, it charged first. HUD shows no damage taken yet.
- zu Zug 10 (notiert vor Zug 11): One-strike kill via Razor Cut first strike (31 damage); +24 XP, pelt and tail looted, quest marked ready for turn-in.
- zu Zug 11 (notiert vor Zug 12): Turn-in confirmed: +46 XP (70/100), 2s5c payout, quest filed. No active quests now; surplus pelt and tail still carried, worth selling at a shop later.
- zu Zug 12 (notiert vor Zug 13): Narrator re-ran a turn-in refusal, but the System panel and HUD confirm the rat contract was paid and filed — treating System as authoritative. Board options: boar sow (rec. lvl 5, 1 kill), adders (lvl 8, 6 kills), dire wolves (lvl 13), catacombs (lvl 3, group risk).
- zu Zug 13 (notiert vor Zug 14): Boar sow contract confirmed ACTIVE in HUD (0/1 defeated). Recommended level 5 for a Level 1 rogue — noting the risk; will fight carefully or retreat if it goes badly.
- zu Zug 14 (notiert vor Zug 15): Vintner confirms the sow raids at dusk from the wood below; tracking now instead of waiting for dark.
- zu Zug 15 (notiert vor Zug 16): Sow located broadside, unaware, ~30 paces off across the streambed; HP 41, MEDIUM — riskier than the rat, will retreat if she takes little damage.
- zu Zug 16 (notiert vor Zug 17): Razor Cut refused last turn: sow at LONG range, skill only reaches ENGAGED; must declare movement to close first.
- zu Zug 17 (notiert vor Zug 18): Stealth failed on a snapped branch; sow now alerted and squared up, twenty paces off across open mud. Charging openly is the remaining option.
- zu Zug 18 (notiert vor Zug 19): First Strike landed for 28; sow at 13/41, I took 8 gore damage (HP 82/90). One more Razor Cut should finish her.
- zu Zug 19 (notiert vor Zug 20): Sow defeated and looted, but the HUD quest counter still reads 0/1 defeated — will verify it updates at turn-in.
- zu Zug 20 (notiert vor Zug 21): Turn-in refused: quest counter still 0/1 despite COMBAT END confirming the sow defeated and loot taken. Possible engine tracking bug — checking the quest panel.
- zu Zug 21 (notiert vor Zug 22): Quest panel confirms 0/1 despite COMBAT END logging the sow defeated and loot taken — likely a kill-registration tracking issue; checking #audit for the recorded change.
- zu Zug 22 (notiert vor Zug 23): Audit shows the engine rejected a world report on contract completion; it points to quest.detail/quest.progress for progress tracking.
- zu Zug 23 (notiert vor Zug 24): Quest detail says only engine-recorded kills count; the kill was engine-confirmed in COMBAT END, so trying the turn-in with the physical proof.
- zu Zug 24 (notiert vor Zug 25): Turn-in still refused at 0/1; clerk offers on-the-spot pay if I return and confirm the carcass, versus a 1–2 day delayed payout. XP 94/100 — one kill from leveling.
- zu Zug 25 (notiert vor Zug 26): Clerk still refuses turn-in at 0/1 despite the seal reading READY; vintner points to the streambed in the wooded fold where the sow squealed and went quiet.
- zu Zug 26 (notiert vor Zug 27): Carcass was dragged toward the streambed by something heavy with fresh boar-sized tracks alongside — possibly a second tusked beast; the count still shows 0/1.
- zu Zug 27 (notiert vor Zug 28): The live second sow (B, 41 HP, SHORT) stands beside the first sow's carcass in the streambed — this is likely the beast the contract actually needs; killing it should settle the 0/1 count. I am one XP from level 2 (94/100).
- zu Zug 28 (notiert vor Zug 29): Razor Cut failed for range only: sow B is at SHORT and no movement was declared; nothing spent, no roll. She is still distracted feeding at the bank.
- zu Zug 29 (notiert vor Zug 30): First Strike landed for 28 (sow at 13/41); her counter-gore cost 8 HP (74/90). Razor Cut's 23-29 damage should finish her this turn.
- zu Zug 30 (notiert vor Zug 31): Sow B defeated with Razor Cut: +24 XP, loot (hide, 2 tusks), Razor Cut P1 36/75, LEVEL UP to Level 2 with 5 free points. Quest count still shows 0/1 despite both sows dead.
- zu Zug 31 (notiert vor Zug 32): Level 2 assigned (AGI 11, PER 11, VIT 8). Quest counter still reads 0/1 despite two tusked sows defeated — checking the quest panel before returning to the Guild.
- zu Zug 32 (notiert vor Zug 33): Quest panel still shows 0/1 and the clerk cannot pay until the kill is confirmed as the contract sow; the vintner's note says the carcass was left untouched by the stream. Dragging the carcass to the vine rows to settle the count.
- zu Zug 33 (notiert vor Zug 34): Turn-in refused twice: engine counts 0/1 kills; dragging the carcass to the rows did not register. The kill likely must occur at the vine rows location, so I will ambush the sow there at dusk.
- zu Zug 34 (notiert vor Zug 35): Waiting was refused as 'arrival pending' despite already being at the vine rows; trying an explicit wait-until-dusk action instead.
- zu Zug 35 (notiert vor Zug 36): Time is 18:00 and it is already full dark; the sow has not appeared yet. Two turn-ins were refused with 0/1 kills — the engine seems to require the kill at the rows themselves.
- zu Zug 36 (notiert vor Zug 37): Night ambush produced no second sow; contract still 0/1 despite holding a sow hide and tusks. The kill may need to happen at the rows itself or the contract may be bugged — checking its terms before abandoning it.
- zu Zug 37 (notiert vor Zug 38): Quest panel confirms only engine-recorded kills at the vine rows count; the night watch produced no sow. Trying a dusk ambush on site since she is said to come up at dusk.
- zu Zug 38 (notiert vor Zug 39): A live Tusked Boar Sow C (HP 82/82) has finally spawned at dusk and is approaching the rows; the kill must land on the rows themselves to count.
- zu Zug 39 (notiert vor Zug 40): The sow rooted a dozen strides below the rows and never crossed onto them; the previous ambush was refused for range. Now closing deliberately to engage.
- zu Zug 40 (notiert vor Zug 41): The engine refused combined movement+attack twice; trying movement alone this turn, attack next.
- zu Zug 41 (notiert vor Zug 42): Movement succeeded alone; sow is now at SHORT and facing me, tusks forward. Attack should be possible this turn.
- zu Zug 42 (notiert vor Zug 43): Combat finally engaged; Razor Cut landed 27, sow at 55 HP, she gored me for 20 (HP 54/100).
- zu Zug 43 (notiert vor Zug 44): Razor Cut landed 30 again; sow at 25 HP, me at 34 HP after a second 20-damage gore to the same leg. One more hit should end it.
- zu Zug 44 (notiert vor Zug 45): Sow defeated on the rows, contract now READY FOR TURN-IN; +152 XP puts me at 170/200, one level away. HP 34/100 — badly wounded, should recover after turn-in.
- zu Zug 45 (notiert vor Zug 46): Turn-in succeeded: +90 copper, +300 XP, Level 3 with 5 free points. HP still 34/105; I badly need lodging and recovery after spending points.
- zu Zug 46 (notiert vor Zug 47): Turn-in and level-up confirmed; stats assigned. HUD stale re: sellable loot and HP; need recovery from 34/105.
- zu Zug 47 (notiert vor Zug 48): HUD shows a second sow hide and tusk still carried; clerk offered 20c for the pair and the Grey Hen at 10c includes wound treatment — best value at HP 34/115.
- zu Zug 48 (notiert vor Zug 49): Sale of the second hide went through (20c), but HUD still lists both hides and tusks plus rat loot carried — inventory may be stale. Lodging at the Grey Hen paid; need confirmation of HP recovery by morning.
- zu Zug 49 (notiert vor Zug 50): Full recovery confirmed: HP 115/115, MP/STA full. HUD still lists a hide and two tusks carried despite earlier sale — treating HUD as authoritative and selling them again.
- zu Zug 50 (notiert vor Zug 51): HUD still lists a sow hide and tusk carried despite the confirmed sale of both — inventory panel appears stale again. Also noted: the journal hints the second sow kill was never engine-counted, so I'll avoid repeat sow contracts.
- zu Zug 51 (notiert vor Zug 52): Contract Rat in the Millpond Shed is registered and active (0/1 defeated); I've arrived at the shed and the rat's den corner was pointed out. HUD again lists a sow hide and tusk already sold.
- zu Zug 52 (notiert vor Zug 53): HUD still shows stale carried loot (extra hide/tusk) and a confusing 'debt' note about the sow contract; rat in the shed just charged me.
- zu Zug 53 (notiert vor Zug 54): System says the active scene is still 'Clerk' despite narration placing me in the shed — the rat fight never registered. Retrying by explicitly returning to the shed.
- zu Zug 54 (notiert vor Zug 55): Scene switch worked: HUD now shows Oversized Rat B engaged in the shed, so the fight is finally live.
- zu Zug 55 (notiert vor Zug 56): Rat defeated with one first-strike Razor Cut (31 dmg); contract now 1/1. HUD again shows duplicated carried items (two tails, two sow hides) — stale inventory persists.
- zu Zug 56 (notiert vor Zug 57): Level 4 confirmed (+5 stat points); rat contract paid out 1s5c and 46 XP. HUD again shows duplicated carried items (tail x2, three sow hides) — stale inventory persists.
- zu Zug 57 (notiert vor Zug 58): Stat points assigned cleanly (AGI 15, PER 15, VIT 11). The recurring 'debt' note about an uncounted sow kill persists in the HUD but the rat payout went through normally.
- zu Zug 58 (notiert vor Zug 59): Board offers four Novice jobs; boar (rec. lvl 5) is the sensible next target. The 'debt' note about the uncounted sow kill persists — I'll keep an eye on whether a new boar kill registers properly.
- zu Zug 59 (notiert vor Zug 60): Contract accepted and confirmed active (0/1). The recurring 'debt' note about the uncounted sow kill persists — I'll watch whether a fresh engine-recorded kill registers this time.
- zu Zug 60 (notiert vor Zug 61): HUD shows a stale duplicated sow hide and a recurring 'debt' note about an uncounted sow kill; the contract still reads 0/1, so I need a fresh engine-recorded kill.
- zu Zug 61 (notiert vor Zug 62): Sow engaged at 49/49 HP; my HP 115/125. HUD still shows the duplicated hide and the recurring 'debt' note about the uncounted sow kill.
- zu Zug 62 (notiert vor Zug 63): Last turn's combined dodge+attack was rejected as two actions; only the dodge counts. HP still 115/125, sow unharmed at 49/49.
- zu Zug 63 (notiert vor Zug 64): Solo dodge was accepted (MOVED, distance opened to MEDIUM); her beech collision left her briefly dazed but she recovered — the tree may be a repeatable shield tactic. Attack alone has not yet been attempted this fight.
- zu Zug 64 (notiert vor Zug 65): Contradiction: narrator says MEDIUM range but the HUD lists the sow as SHORT. I'll trust the HUD and attack; if refused again I'll move first.
- zu Zug 65 (notiert vor Zug 66): Range contradiction resolved: engine says SHORT is not enough for Razor Cut (needs ENGAGED); earlier refusals were range, not misunderstanding. Moving as a single action.
- zu Zug 66 (notiert vor Zug 67): Movement to ENGAGED was accepted as a single action; now in blade's length of the sow, who is still gathering for another charge.
- zu Zug 67 (notiert vor Zug 68): First Strike Razor Cut landed for 34 (sow at 15/49); her gore cost 10 HP, now 105/125. One more hit should end it.
- zu Zug 68 (notiert vor Zug 69): Sow defeated (+50 XP, Razor Cut 72/75), but quest panel still reads 0/1 defeated — possible turn-in requirement. Fresh boar-sized drag tracks near the stream suggest a second animal; clerk earlier refused payment against a 'grey seal'.
- zu Zug 69 (notiert vor Zug 70): Turn-in refused: the contract requires the sow to be killed at the vine rows specifically; my sow died in a hollow off-slope. HUD shows two Sow Hides carried, only one expected.
- zu Zug 70 (notiert vor Zug 71): Turn-in refused again: seal requires the kill at the vine rows specifically; contract stays active. Clerk suggests healer two doors down for the leg.
- zu Zug 71 (notiert vor Zug 72): Broker offered 1 Gold 3 Silver for two hides and three tusks; contract stays active pending a sow killed at the vine rows themselves.
- zu Zug 72 (notiert vor Zug 73): System clarified the broker's offer is 26 cp, not 1g3s as my previous message assumed; accepting the correct bid now.
- zu Zug 73 (notiert vor Zug 74): Loot sold for 26 cp as clarified; coin now 192 copper. Healer offers full treatment for 20 cp vs basic for 10 cp.
- zu Zug 74 (notiert vor Zug 75): Full 20 cp treatment bought and applied; HP still 105/125, leg healing takes days. Boar contract remains 0/1 due to kill-location seal; two failed turn-ins so far — switching to a different contract is the sensible branch.
- zu Zug 75 (notiert vor Zug 76): Clerk offered to void the boar contract with no penalty; Novice board shows adder (160 cp), dire wolves (200 cp), and catacombs (120 cp, group risk). Adder suits a wounded leg best — no slopes, no climbing.
- zu Zug 76 (notiert vor Zug 77): Boar contract voided cleanly; adder contract now ACTIVE (0/1). Coin 172 cp after 20 cp treatment; leg stitched, heal advice: keep dry two days.
- zu Zug 77 (notiert vor Zug 78): Reached Weir Crossing after dark; brokerage was closed so rat loot still unsold. HP 105/125, leg stitched.
- zu Zug 78 (notiert vor Zug 79): Keeper confirms adder location: old fish racks downstream of the weir, suns on flat stones. Taking bed+supper+porridge for 12 cp before hunting, as leg needs rest and night marsh hunting is risky.
- zu Zug 79 (notiert vor Zug 80): Supper and porridge agreed at 12 cp; room must be booked explicitly before sleeping.
- zu Zug 80 (notiert vor Zug 81): Supper and porridge (12 cp) already paid; the engine wants the room booked as a separate explicit purchase before sleep is possible.
- zu Zug 81 (notiert vor Zug 82): Paid 4 cp for the room yet the engine still reports 'room not booked' — possible tracking oddity; trying wording that references the keeper's booking.
- zu Zug 82 (notiert vor Zug 83): Sleep finally resolved after rephrasing as using the keeper's booked room; HP/STA fully restored. Adder contract still 0/1.
- zu Zug 83 (notiert vor Zug 84): Arrival at the racks now confirmed; a fresh drag-groove in the mud is the only sign of the adder so far.
- zu Zug 84 (notiert vor Zug 85): Combat scene now ACTIVE: Large Marsh Adder A, HP 52/52, SHORT range. It hasn't struck yet; attacking first while it's cold.
- zu Zug 85 (notiert vor Zug 86): Razor Cut failed: adder at SHORT, skill reaches ENGAGED at most; must wait for it to close.
- zu Zug 86 (notiert vor Zug 87): The adder stopped a stride short and waits; range remains SHORT until I move in myself.
- zu Zug 87 (notiert vor Zug 88): First strike landed for 40 damage; adder at 12 HP but envenomed my thigh for 17 — watch HP and venom after the fight.
- zu Zug 88 (notiert vor Zug 89): Adder defeated, quest ready for turn-in; Razor Cut advanced to P2. Venom caused only local 17 damage, no lingering effect listed.
- zu Zug 89 (notiert vor Zug 90): Two level-ups at once confirmed (L6, 10 free points); quest paid out 1g6s plus 810 XP.
- zu Zug 90 (notiert vor Zug 91): Level 6 confirmed, stat points spent (AGI 22, PER 22). Guild shop offers F-rank skill primers at ~120 cp; adder loot still in pouch, worth selling.
- zu Zug 91 (notiert vor Zug 92): Board offers five Novice contracts; boar sow (rec. level 5) is the best fit for L6. Marta is present and ENGAGED as merchant, so loot sale can proceed here.
- zu Zug 92 (notiert vor Zug 93): Contract slip received and stated active; Marta's offer covers all carried loot. Note HUD shows Quests: — despite the slip — will verify it's ACTIVE before travelling.
- zu Zug 93 (notiert vor Zug 94): System asked to clarify the sale as a purchase of offer positions; restating the transaction explicitly.
- zu Zug 94 (notiert vor Zug 95): System repeatedly demanded a 'purchase of offer positions' phrasing; the sale has not yet been recorded. Boar sow contract slip stated active by clerk, but HUD Quests still shows '—'.
- zu Zug 95 (notiert vor Zug 96): System still refuses to record the sale despite three phrasings; also HUD Quests shows '—' so the boar sow contract's active status needs verification once the sale is resolved.
- zu Zug 96 (notiert vor Zug 97): Loot sale finally recorded: +330 copper (662 total), Marta actually paid 33s even. HUD still shows Quests: — despite carrying the contract slip, so verifying its status.
- zu Zug 97 (notiert vor Zug 98): Quest panel confirms the boar sow contract is completed; loot sale recorded at 33s even (662 copper total). Three duplicate contracts remain only 'listed', so the active-slip issue resolved itself as completion.
- zu Zug 98 (notiert vor Zug 99): Turn-in refused: slip needs the vintners' steward's sign-off or a trophy. I sold the hide to Marta already, so sign-off is the route.
- zu Zug 99 (notiert vor Zug 100): Reached the press-house; steward present and receptive. Note the odd 'Here' lore lines mentioning a second-sow mystery — may complicate sign-off.
- zu Zug 100 (notiert vor Zug 101): Steward took the slip and wants to see the carcass in person before marking it; he hints at a council gratuity. Odd lore note about a possible second sow lingers.
- zu Zug 101 (notiert vor Zug 102): Steward verified the carcass, chalked and thumb-marked the slip, and offered a one-silver council gratuity on top of the hall's pay.
- zu Zug 102 (notiert vor Zug 103): Turn-in refused once with quest.turn_in already_completed, but the clerk is now actively asking for the marked slip — the payout seems payable via the slip rather than the quest flag. Gratuity silver accepted from steward.
- zu Zug 103 (notiert vor Zug 104): Clerk confirmed the payout chain: contract must be taken at the counter before turn-in, even retroactively for work already done.
- zu Zug 104 (notiert vor Zug 105): Contract confirmed ACTIVE under my name; the clerk invited immediate turn-in with both slips.
- zu Zug 105 (notiert vor Zug 106): Turn-in refused: engine counts 0/1 tusked boar sow despite the steward's verified mark — the kill happened before the contract was taken, so it never registered. Lore hints at a possible second sow; returning to the vine rows to test whether the record needs a fresh kill.
- zu Zug 106 (notiert vor Zug 107): Contract is active (0/1); the clerk confirmed the payout needs a fresh engine-registered kill. Tam offers a free guide to Hesse's rows.
- zu Zug 107 (notiert vor Zug 108): Trail of the second sow confirmed fresh and heading toward the treeline; she is reportedly larger than the first sow.
- zu Zug 108 (notiert vor Zug 109): Engine panel confirms the target as Tusked Boar Sow E (MEDIUM, HP 82/82), still unaware and broadside — a stealth opener is available before she reacts.
- zu Zug 109 (notiert vor Zug 110): Razor Cut was refused: the sow is at LONG range and needs a declared movement into ENGAGED range first; she remains unaware.
- zu Zug 110 (notiert vor Zug 111): Stealth check succeeded; sow is now ENGAGED and unaware at her flank, one main action per turn so the strike was not taken last turn.
- zu Zug 111 (notiert vor Zug 112): Ambush crit took 73 of 82 HP; sow is crippled at ENGAGED with 9 HP left on my turn.
- zu Zug 112 (notiert vor Zug 113): Second sow defeated via ambush crit plus Basic Attack; contract now 1/1 with hide and tusk in pouch. HP 108/135, STA 81/100 — light wounds, may want recovery before the next job.
- zu Zug 113 (notiert vor Zug 114): Contract slip confirmed READY with 1/1 defeated; heading back down to Hesse with hide and tusk in pouch, HP and STA only lightly spent.
- zu Zug 114 (notiert vor Zug 115): Contract confirmed 1/1 defeated with hide and tusk as loot; Hesse confirms the payout comes from the Guild, so I'll turn the slip in there.
- zu Zug 115 (notiert vor Zug 116): Back at the Guild hall before 17:00 with the slip confirmed READY; XP 368/600, so the payout plus another small job should push Level 7.
- zu Zug 116 (notiert vor Zug 117): Payout confirmed: +90 cp, XP only 68/700 (a level-up may have consumed the rest — HUD shows L7 with fresh XP bar). Free stat points 5 still unassigned.
- zu Zug 117 (notiert vor Zug 118): Brokerage closed for the day; hide and tusk still in pouch for morning sale. Board offers rat cull (25cp, lvl 1), marsh adder (150cp, lvl 9), dire wolves and catacombs both chalked as dangerous solo.
- zu Zug 118 (notiert vor Zug 119): Assign confirmed: AGI 26, PER 25, 0 free points left. Board has chalk warnings against dire wolves and catacombs solo; the marsh adder (rec. level 9, 150 cp) looks like the best next job after recovery and gear.
- zu Zug 119 (notiert vor Zug 120): HUD after purchase shows no Primer of Strike in inventory and no strike skill learned, though the narrator described the purchase; checking the bag before relying on it.
- zu Zug 120 (notiert vor Zug 121): Bag and coin confirm the primer purchase never recorded despite the narrator describing payment and reading; first retry of a possible engine hiccup.
- zu Zug 121 (notiert vor Zug 122): Second purchase attempt also failed to record (bag and coin unchanged); now retrying with explicit coin-on-counter per the merchant's wording — third and final try before abandoning.
- zu Zug 122 (notiert vor Zug 123): Third purchase attempt finally recorded: -120 cp, Primer of Strike in pouch. Skills not yet updated, so studying now.
- zu Zug 123 (notiert vor Zug 124): System asked for an explicit study duration before booking anything; purchase is now confirmed (-120 cp, primer in pouch).
- zu Zug 124 (notiert vor Zug 125): The System booked the study as gradual learning: strike at 20/100 LP after 2 hours, not an instant skill — HUD skill list still lacks strike. The hall closed at dusk bell, so studying more tonight isn't possible.
- zu Zug 125 (notiert vor Zug 126): Still Level 7 with 68/700 XP; strike learning is gradual (20/100 LP), so more study sessions will be needed. Guild board warnings suggest dire wolf and catacombs jobs are unsafe solo.
- zu Zug 126 (notiert vor Zug 127): System asked to clarify the combined purchase; nothing spent yet.
- zu Zug 127 (notiert vor Zug 128): System keeps asking for purchase clarification; third confirmation now given.
- zu Zug 128 (notiert vor Zug 129): Purchase finally confirmed after three clarifications (-14 cp). Slept, but HP only 108/140 — morning recovery incomplete; time is oddly 22:25 at night despite the 'morning' narration.
- zu Zug 129 (notiert vor Zug 130): Study is slow: strike only 34/100 LP after ~5 hours total. It is now past midnight (01:25); studying through the night will cost recovery time.
- zu Zug 130 (notiert vor Zug 131): Overnight study shows heavy diminishing returns: 3 hours gave +14 LP, the next 4 hours only +6 (strike 40/100). It is 05:25 Day 5; HP still 108/140 after sleeping.
- zu Zug 131 (notiert vor Zug 132): HUD shows a Vine-Row Boar Sow contract slip and boar hide/tusk carried, yet the quest panel reads '—' — possibly a completed-but-unturned-in contract; verifying.
- zu Zug 132 (notiert vor Zug 133): Quest panel confirms three completed contracts ready for turn-in (millpond rat, adder, boar sow) — turn them in before taking new work. Boar sow slip explicitly hints I may take it from the board and turn it straight back in with proof in hand.
- zu Zug 133 (notiert vor Zug 134): Quest panel shows completed rat and adder contracts ready for payout; the sow contract must be signed out fresh before proof counts.
- zu Zug 134 (notiert vor Zug 135): Sow contract now properly active (0/1). Completed rat/adder entries can't be paid out — the engine treats them as board listings, not signed-out jobs; the completed duplicates seem unclaimable.
- zu Zug 135 (notiert vor Zug 136): Sow contract properly active (0/1); Tam warns she may have young with her. Arrival in the vine rows is confirmed, so hunting should now be possible.
- zu Zug 136 (notiert vor Zug 137): Previous 'arrival pending' refusal is resolved: the HUD now confirms I stand at the scrub treeline with fresh tracks leading up, so tracking should now be actionable. Watch for the possible young boars Tam warned about.
- zu Zug 137 (notiert vor Zug 138): Combat initiated: Tusked Boar Sow, 89 HP, MEDIUM, with 20 paces open ground and wind in my favor. She has detected something but hasn't spotted me yet.
- zu Zug 138 (notiert vor Zug 139): Razor Cut refused at MEDIUM range: needs declared movement to ENGAGED first. Piglets audible in downhill gorse; sow is guarding and aware of me.
- zu Zug 139 (notiert vor Zug 140): Sprint with Evasive Step succeeded; sow is now ENGAGED and charging, flank open.
- zu Zug 140 (notiert vor Zug 141): First strike landed for 55; sow at 34 HP but gored me for 22 (HP 86/140). She's holding ground over piglets, not fleeing.
- zu Zug 141 (notiert vor Zug 142): Sow defeated with second Razor Cut (48 dmg); loot hide and tusk stored; 154 XP gained, Razor Cut now P2 33/75; contract shows 1/1. Slight oddity: loot 'sat in his pouch already' before I looted.
- zu Zug 142 (notiert vor Zug 143): Turn-in refused at the press-house: contracts must be turned in at a Guild hall; steward is away in Alderwatch. Contract shows 1/1 defeated.
- zu Zug 143 (notiert vor Zug 144): Sow contract paid out at the desk: +9 silver, +300 XP (522/700), slip filed — though the HUD still lists the filed slip under Carried. Board warnings mark the dire wolf and catacombs jobs as unsafe solo; the marsh adder at Weir Crossing looks like the achievable next job.
- zu Zug 144 (notiert vor Zug 145): Marsh adder contract confirmed ACTIVE (0/1). Wound is slowing me but holding; adders reportedly strike without warning.
- zu Zug 145 (notiert vor Zug 146): Ferry keeper gave a concrete location and timing: past the second trap line, morning sun on the shallows. Reward shown as 160 cp in HUD vs 16 silver quoted by the clerk — worth watching at turn-in.
- zu Zug 146 (notiert vor Zug 147): Adder engaged at the channel mouth, 48 HP; contract still 0/1. Reward discrepancy persists (160 cp in HUD vs 16 silver quoted).
- zu Zug 147 (notiert vor Zug 148): Engine refused the combined dodge+strike last turn; Evasive Step resolved but Razor Cut was not taken. Adder is at 48/48 HP, contract still 0/1.
- zu Zug 148 (notiert vor Zug 149): Engine refused Razor Cut last turn: adder at SHORT, out of dagger range; it did not press the attack.
- zu Zug 149 (notiert vor Zug 150): Adder defeated first strike (55 dmg), +192 XP, Level 8 with 5 free points; contract 1/1 ready for turn-in. Loot auto-stowed despite narrator saying pouch.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t10 | 10 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t18 | 18 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t26 | 29 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t36 | 42 | 1 | – | nein | 1 | gewonnen, 152 XP |
| enc.t47 | 55 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t58 | 67 | 1 | – | nein | 1 | gewonnen, 50 XP |
| enc.t77 | 87 | 1 | – | nein | 1 | gewonnen, 216 XP |
| enc.t96 | 111 | 1 | – | ja | 1 | gewonnen, 152 XP |
| enc.t119 | 140 | 1 | – | nein | 1 | gewonnen, 154 XP |
| enc.t128 | 149 | 1 | – | nein | 1 | gewonnen, 192 XP |

## Quests

- **Cull the Millpond Rat Pack** — active (Zug 7) → completed (Zug 11), READY
  - Aufgabe: Kill 1 oversized rat at the millpond shed at Cobblemill. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 oversized rat killed at the millpond shed at Cobblemill.
- **Thin the Fox-Size Boar Sow at the Vine Rows** — active (Zug 13) → completed (Zug 45), READY
  - Aufgabe: Kill 1 tusked boar sow at the vine rows on the Alderwatch Slopes. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 tusked boar sow killed at the vine rows on the Alderwatch Slopes.
- **Cull the Reedbank Adders** — expired (Zug 50)
  - Aufgabe: Kill 6 large marsh adders at the reedbanks at the Weir Crossing. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 6 large marsh adders killed at the reedbanks at the Weir Crossing.
- **Drive Down the Barrow-Ridge Dire Wolves** — expired (Zug 50)
  - Aufgabe: Kill 8 dire wolves at the dens under Barrow Ridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 8 dire wolves killed at the dens under Barrow Ridge.
- **Clear Old Crown Catacombs Level 1** — expired (Zug 50), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of Old Crown Catacombs. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Old Crown Catacombs is clear.
- **Rat in the Millpond Shed** — active (Zug 51) → completed (Zug 56)
  - Aufgabe: Kill 1 oversized rat at the millpond shed at Cobblemill. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 oversized rat killed at the millpond shed at Cobblemill.
- **Boar in the Vine Rows** — active (Zug 59) → abandoned (Zug 76)
  - Aufgabe: Kill 1 tusked boar sow at the vine rows on the Alderwatch Slopes. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 tusked boar sow killed at the vine rows on the Alderwatch Slopes.
- **Adder at the Weir Crossing** — active (Zug 76) → completed (Zug 89), READY
  - Aufgabe: Kill 1 large marsh adder at the reedbanks at the Weir Crossing. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 large marsh adder killed at the reedbanks at the Weir Crossing.
- **Dire Wolves under Barrow Ridge** — expired (Zug 91)
  - Aufgabe: Kill 4 dire wolves at the dens under Barrow Ridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 dire wolves killed at the dens under Barrow Ridge.
- **Secure the Old Crown Catacombs, Level 1** — expired (Zug 91), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of Old Crown Catacombs. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Old Crown Catacombs is clear.
- **Cull the Millpond Shed Rat** — expired (Zug 131)
  - Aufgabe: Kill 1 oversized rat at the millpond shed at Cobblemill. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 oversized rat killed at the millpond shed at Cobblemill.
- **Cull the Vine-Row Boar Sow** — active (Zug 104) → completed (Zug 116)
  - Aufgabe: Kill 1 tusked boar sow at the vine rows on the Alderwatch Slopes. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 tusked boar sow killed at the vine rows on the Alderwatch Slopes.
- **Kill the Weir Crossing Marsh Adder** — expired (Zug 131)
  - Aufgabe: Kill 1 large marsh adder at the reedbanks at the Weir Crossing. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 large marsh adder killed at the reedbanks at the Weir Crossing.
- **Cull the Barrow Ridge Dire Wolves** — expired (Zug 131)
  - Aufgabe: Kill 4 dire wolves at the dens under Barrow Ridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 dire wolves killed at the dens under Barrow Ridge.
- **Clear Old Crown Catacombs, Level 1** — expired (Zug 131), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of Old Crown Catacombs. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Old Crown Catacombs is clear.
- **Drive Off the Vine-Row Boar Sow** — active (Zug 134) → completed (Zug 143)
  - Aufgabe: Kill 1 tusked boar sow at the vine rows on the Alderwatch Slopes. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 tusked boar sow killed at the vine rows on the Alderwatch Slopes.
- **Kill the Weir Crossing Marsh Adder** — active (Zug 144), READY
  - Aufgabe: Kill 1 large marsh adder at the reedbanks at the Weir Crossing. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 large marsh adder killed at the reedbanks at the Weir Crossing.

## Auffälligkeiten

- Zug 8, Nachricht 16 (extraction_repaired): the extractor's first answer needed a repair
- Zug 15, Nachricht 30 (extraction_repaired): the extractor's first answer needed a repair
- Zug 18, Nachricht 36 (extraction_repaired): the extractor's first answer needed a repair
- Zug 18, Nachricht 36 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 18, Nachricht 36 (finish): extract ended with finish_reason "length"
- Zug 20, Nachricht 39 (planner_repaired): the planner's first answer needed a repair
- Zug 20, Nachricht 39 (finish): plan ended with finish_reason "length"
- Zug 20, Nachricht 40 (extraction_repaired): the extractor's first answer needed a repair
- Zug 29, Nachricht 57 (planner_repaired): the planner's first answer needed a repair
- Zug 33, Nachricht 66 (extraction_repaired): the extractor's first answer needed a repair
- Zug 38, Nachricht 75 (planner_repaired): the planner's first answer needed a repair
- Zug 41, Nachricht 82 (extraction_repaired): the extractor's first answer needed a repair
- Zug 41, Nachricht 82 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 41, Nachricht 82 (finish): extract ended with finish_reason "length"
- Zug 47, Nachricht 93 (planner_repaired): the planner's first answer needed a repair
- Zug 48, Nachricht 96 (extraction_repaired): the extractor's first answer needed a repair
- Zug 54, Nachricht 107 (planner_repaired): the planner's first answer needed a repair
- Zug 65, Nachricht 130 (extraction_repaired): the extractor's first answer needed a repair
- Zug 65, Nachricht 130 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 65, Nachricht 130 (finish): extract ended with finish_reason "length"
- Zug 67, Nachricht 134 (extraction_repaired): the extractor's first answer needed a repair
- Zug 67, Nachricht 134 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 67, Nachricht 134 (extractor_recovery_zero_deltas): recovery was applied with 0 deltas; review narrated world changes against the saved state (not necessarily an error)
- Zug 67, Nachricht 134 (finish): extract ended with finish_reason "length"
- Zug 71, Nachricht 142 (extraction_repaired): the extractor's first answer needed a repair
- Zug 73, Nachricht 146 (extraction_repaired): the extractor's first answer needed a repair
- Zug 79, Nachricht 157 (planner_repaired): the planner's first answer needed a repair
- Zug 79, Nachricht 157 (finish): plan ended with finish_reason "length"
- Zug 82, Nachricht 164 (extraction_repaired): the extractor's first answer needed a repair
- Zug 82, Nachricht 164 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 82, Nachricht 164 (extractor_recovery_zero_deltas): recovery was applied with 0 deltas; review narrated world changes against the saved state (not necessarily an error)
- Zug 82, Nachricht 164 (finish): extract ended with finish_reason "length"
- Zug 93, Nachricht 185 (planner_repaired): the planner's first answer needed a repair
- Zug 94, Nachricht 187 (planner_repaired): the planner's first answer needed a repair
- Zug 95, Nachricht 189 (planner_repaired): the planner's first answer needed a repair
- Zug 96, Nachricht 191 (planner_repaired): the planner's first answer needed a repair
- Zug 98, Nachricht 196 (extraction_repaired): the extractor's first answer needed a repair
- Zug 99, Nachricht 198 (extraction_repaired): the extractor's first answer needed a repair
- Zug 101, Nachricht 202 (extraction_repaired): the extractor's first answer needed a repair
- Zug 101, Nachricht 202 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 101, Nachricht 202 (finish): extract ended with finish_reason "length"
- Zug 102, Nachricht 204 (extraction_repaired): the extractor's first answer needed a repair
- Zug 112, Nachricht 224 (extraction_repaired): the extractor's first answer needed a repair
- Zug 112, Nachricht 224 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 112, Nachricht 224 (extractor_recovery_zero_deltas): recovery was applied with 0 deltas; review narrated world changes against the saved state (not necessarily an error)
- Zug 112, Nachricht 224 (finish): extract ended with finish_reason "length"
- Zug 115, Nachricht 230 (extraction_repaired): the extractor's first answer needed a repair
- Zug 119, Nachricht 237 (planner_repaired): the planner's first answer needed a repair
- Zug 119, Nachricht 237 (finish): plan ended with finish_reason "length"
- Zug 126, Nachricht 251 (planner_repaired): the planner's first answer needed a repair
- Zug 127, Nachricht 253 (planner_repaired): the planner's first answer needed a repair
- Zug 134, Nachricht 268 (extraction_repaired): the extractor's first answer needed a repair
- Zug 134, Nachricht 268 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 134, Nachricht 268 (finish): extract ended with finish_reason "length"
- Zug 136, Nachricht 272 (extraction_repaired): the extractor's first answer needed a repair
- Zug 141, Nachricht 282 (extraction_repaired): the extractor's first answer needed a repair
- Zug 141, Nachricht 282 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 141, Nachricht 282 (finish): extract ended with finish_reason "length"
- Zug 144, Nachricht 288 (extraction_repaired): the extractor's first answer needed a repair
- Zug 145, Nachricht 289 (planner_repaired): the planner's first answer needed a repair
- Zug 145, Nachricht 289 (finish): plan ended with finish_reason "length"
- Zug 149, Nachricht 298 (extraction_repaired): the extractor's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 38× keine gültige JSON-Entscheidung (Züge 2, 9, 15, 16, 17, 26, 27, 29, 36, 38, 39, 42, 52, 53, 61, 62, 70, 72, 80, 81, 84, 86, 95, 98, 99, 102, 108, 110, 111, 120, 130, 132, 134, 136, 139, 147, 148, 149)
- 13 Aufruf(e) mit finish_reason "length" (Nr. 51 extract, Nr. 56 plan, Nr. 108 extract, Nr. 177 extract, Nr. 184 extract, Nr. 219 plan, Nr. 231 extract, Nr. 284 extract, Nr. 319 extract, Nr. 337 plan, Nr. 376 extract, Nr. 399 extract, Nr. 411 plan)

System-Panels: CLARIFY 7, NOT TAKEN 6, REFUSED 3, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: guild_canon_price 1, guild_canon 4, engine_owned_memory 2, attack_commitment 10, engine_owned_fact 22, guild_payout 4, world_rule 8, quest_count 3, engine_owned_combat 1, offer 2, no_go 8, scene_context 31, sale_evidence 1, guild_completion 1, engine_booked 1, guild_quest_detail 1, ambient 4, pc_inventory 3, npc_continuity 1, coin_evidence 1, quest 1, time_cap 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 9, Transport 0, davon angewendet mit 0 Deltas 3. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 148 | 14 | 2.6 s | 7.0 s | 11904 | 9781 | 90 | – | stop 144, length 4 | 4 |
| board | 4 | 0 | 10.3 s | 26.5 s | 2448 | 2142 | 1079 | – | stop 4 | 0 |
| narrator | 126 | 0 | 8.6 s | 13.2 s | 11434 | 8786 | 391 | – | stop 126 | 0 |
| extract | 149 | 14 | 5.6 s | 20.7 s | 12013 | 9184 | 370 | – | stop 140, length 9 | 9 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 78:27 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 14.2 s) | 0:28 min |
| 150 Züge, Spiel (Senden bis HUD nach der Extraktion) | 64:59 min — Median 21.6 s, p90 56.7 s, max 97.1 s |
| 150 Züge, Spieler-Entscheidung | 10:26 min — Median 3.2 s, 39 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 9:59 min / 0:56 min / 24:45 min / 23:41 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 30.2 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 20:07 min, 80 Züge ≈ 40:13 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spieler | 37 | – | 38.8 s | 3.2 s |
| Spiel | 50 | – | 97.1 s | 21.6 s |
| Spiel | 33 | – | 92.1 s | 21.6 s |
| Spiel | 114 | – | 88.1 s | 21.6 s |
| Provider narrator | 33 | 84 | 76.3 s | 8.6 s |
| Provider narrator | 114 | 325 | 69.9 s | 8.6 s |
| Provider narrator | 50 | 135 | 59.2 s | 8.6 s |
| Provider extract | 18 | 51 | 65.9 s | 5.6 s |
| Provider extract | 82 | 231 | 54.2 s | 5.6 s |
| Provider extract | 101 | 284 | 50.8 s | 5.6 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
