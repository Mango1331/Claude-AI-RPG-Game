# Avereth Live-Test 20261027-105925Z-current_test

## Kurzfassung

- **Laufprofil:** explore-warrior; Startklasse Warrior, Schwerpunkt explore. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** abgebrochen: unerwarteter UI-Zustand — turn 87: no reply after the message
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 2. Sicherheitsgrenzen: 150 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** noch nicht erreicht.
- **Charakter:** warrior (warrior.heavy_slash, warrior.guard) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: pragmatic adventurer: sell surplus loot and invest in useful equipment and techniques
- **Züge:** 87 · **Dauer:** 54:43 min · **LLM-Aufrufe der Engine/des Erzählers:** 285
- **Auffälligkeiten:** 47
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.101 |
| Git | c9e3fa58bb57 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 61.7 s |
| Browser | chrome 156.0.8078.48 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261027-105925Z-current_test“, Seed 1613311444 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | I choose Warrior. | Engine (Menü/Rückfrage) | creation_complete | Select Warrior as base class. | public roadside verge outside Alderwatch | 90/84 | 2.3 s |
| 2 | I choose Heavy Slash and Guard. | Engine (Menü/Rückfrage) | creation_complete | Select the two starter skills to finish creation. | public roadside verge outside Alderwatch | 95/84 | 2.1 s |
| 3 | I walk along the road to Alderwatch's gate and enter the city. | Erzähler | open_run_level | Enter Alderwatch to prepare and gather direction for travel. | Alderwatch | 95/84 | 17.2 s |
| 4 | I head down to the market square and look for a merchant buying monster parts or a smith selling used gear. | Erzähler | open_run_level | Scout the market for trade opportunities and gear prices before leaving town. | Market Square | 95/84 | 20.3 s |
| 5 | I walk over to the armorer's open front and ask what he has in used gear for around 5 silver — a shield or a sturdier blade — and at what pr… | Erzähler | open_run_level | Ask the present armorer for concrete used-gear offers and prices within my 5-silver budget… | Market Square | 95/84 | 23.4 s |
| 6 | I'll take the round shield at two and a half silver, and I'll strap it on before I leave. | Erzähler | open_run_level | Buy the used shield for 2.5 silver and equip it. | Market Square | 95/84 | 25.0 s |
| 7 | I'll take the strap extension for the copper — do the work, then I strap the shield on properly. | Erzähler | open_run_level | Buy the 1-copper strap extension so the shield can be equipped, then equip it. | Market Square | 95/84 | 18.3 s |
| 8 | I buy some travel provisions for the road — ask Merchant A for hard bread, dried meat and a full waterskin, and what that costs. | Erzähler | open_run_level | Buy travel food and water for leaving town. | Market Square | 95/84 | 18.5 s |
| 9 | I'll take two coppers' worth of the dried meat, then walk to the baker's stall and buy a hardtack brick for a copper. | Erzähler | open_run_level | Buy dried meat from Merchant A and hardtack from the baker for the road. | Baker's stall | 95/84 | 25.2 s |
| 10 | I'll take one hardtack brick for a copper, then refill my waterskin at the well before heading for the town's east gate. | Erzähler | open_run_level | Buy hardtack, refill waterskin, and leave Alderwatch eastward. | East Gate | 95/84 | 30.9 s |
| 11 | I ask the guard where the east road leads — the nearest village or landmark worth visiting, and whether there's any trouble along it these d… | Erzähler | open_run_level | Ask the gate guard about the road ahead, nearby destinations, and any rumors of trouble. | East Gate | 95/84 | 23.1 s |
| 12 | I set out east on the road to Milbrook. | Erzähler | open_run_level | Leave Alderwatch eastward and travel the road toward Milbrook. | Tilted cart on the north track | 95/84 | 59.5 s |
| 13 | I help straighten the cart and gather the spilled turnips, then see to the man's injured arm. | Erzähler | open_run_level | Help the farmers recover the cart and tend the hurt man, earning goodwill and possibly pai… | Tilted cart on the north track | 95/84 | 31.3 s |
| 14 | I walk with the cart the rest of the way to the village and take Silla's offer of a seat at the taproom — the stew and bread, if I can pay f… | Erzähler | open_run_level | Accept the farmers' meal offer at the Milbrook taproom and follow up on the mill house lea… | Taproom by the bridge | 95/84 | 48.5 s |
| 15 | I pay two coppers for my bowl and an ale, eat with Silla and Bones, and ask what they know of the north woods trouble before I see Brenna th… | Erzähler | open_run_level | Pay for the meal and gather details on the north woods lead from the farmers. | Taproom by the bridge | 95/84 | 22.9 s |
| 16 | I finish my ale, thank Silla and Bones, and cross the bridge to the mill house to find Brenna, telling her the farmers sent me and asking wh… | Erzähler | open_run_level | Meet headman Brenna at the mill house and get the paid north woods job. | Mill house | 95/84 | 57.9 s |
| 17 | I accept Brenna's offer: I'll go into the north woods in daylight tomorrow, look properly at what's taking the stock, and come back with a t… | Erzähler | open_run_level | Accept the paid north woods job from Brenna. | Mill house | 95/84 | 63.5 s |
| 18 | "Alaric Red. I'll take the corner room at the taproom, and I'll ask Hedric to walk me to the gate at first light." | Erzähler | open_run_level | Give Brenna my name, arrange lodging and Hedric's guide at dawn. | Mill house | 95/84 | 75.2 s |
| 19 | I follow the woodcutter's track past the pasture gate, moving slow toward the bend where the ewes were found, watching for tracks or anythin… | Erzähler | open_run_level | Enter the north woods in daylight and investigate the site of the disappearances. | the bend where the ewes were found | 95/84 | 21.6 s |
| 20 | I step off the track into the hollow and examine the ground closely for tracks or signs of what took the ewes. | Erzähler | open_run_level | Investigate the ewe-death hollow for evidence. | the bend where the ewes were found | 95/84 | 14.6 s |
| 21 | I climb up the track toward the old birch stand, watching the trees ahead as I go. | Erzähler | open_run_level | Follow the only remaining lead toward the birch stand where the woodcutters turn back. | old birch stand | 95/84 | 33.9 s |
| 22 | I approach the low, wide shape in the deep shade slowly with my sword ready, and examine it from a few paces without touching it. | Erzähler | open_run_level | Investigate the still shape among the birch roots before it can be a threat or a clue. | woven bark dome | 95/84 | 31.7 s |
| 23 | I back away quietly without turning my back on the entrance, then watch the opening from cover to see what comes out. | Erzähler | open_run_level | Observe the breathing den from safety before deciding to fight or retreat. | woven bark dome | 95/84 | 15.6 s |
| 24 | Since nothing emerges and the breathing has settled into deep sleep, I withdraw to the pasture and report to Brenna what I found: a woven ba… | Erzähler | open_run_level | Withdraw safely and deliver the true report to Brenna to earn the promised silver. | Hedric's pasture | 95/84 | 34.7 s |
| 25 | "Report's given true and whole, Brenna, as we struck. I'll take the three silver you promised — and if that sleeper under the birch turns ou… | Erzähler | open_run_level | Claim the promised three silver for the true report and open follow-up work with Brenna. | Hedric's pasture | 95/84 | 78.9 s |
| 26 | "Struck, then — ten silver for a true report at dusk. I'll take that bed and hot meal now, then head back up at dusk." | Erzähler | open_run_level | Accept Brenna's dusk offer, rest at the mill house, then investigate at dusk. | Hedric's pasture | 95/84 | 40.7 s |
| 27 | I pay Brenna two coppers for the private corner past the curtain in the loft, and if the bed is booked, I sleep there until dusk. | Erzähler | open_run_level | Book the loft bed first, then sleep until dusk to recover before the investigation. | Hedric's pasture | 95/84 | 116.8 s |
| 28 | I go down to the mill floor and find Brenna, then put the two coppers in her palm for the private corner past the curtain in the loft. | Erzähler | open_run_level | Book the loft corner directly from Brenna on the mill floor. | mill floor | 95/84 | 23.9 s |
| 29 | I climb the ladder to the loft corner past the curtain and sleep there until dusk. | Erzähler | open_run_level | Sleep in the booked loft corner until dusk to recover before the dusk investigation. | mill loft corner | 95/84 | 20.6 s |
| 30 | I wake at dusk, take up my sword, and head quietly up the north woods track toward the birches, going silent past the bend as Brenna warned. | Erzähler | open_run_level | Head out at dusk to investigate the den under the birches. | mill loft corner | 95/84 | 42.0 s |
| 31 | I slip out of the mill house and head quietly up the north woods track, going silent past the bend at the ewes. | Erzähler | open_run_level | Travel up the north woods track at dusk toward the birch den, moving quietly past the bend… | north woods track past the bend | 95/84 | 29.2 s |
| 32 | I creep down the slope among the birches, quiet and low, to get a clear look at the thing feeding on the ground before it spots me. | Erzähler | open_run_level | Sneak closer to identify the creature before deciding to fight or withdraw. | north woods track past the bend | 95/84 | 22.9 s |
| 33 | I draw my sword and charge the beast from behind, striking with Heavy Slash before it can turn fully. | Erzähler | open_run_level | Ambush the Bristle-Spined Hollow Beast with Heavy Slash for a full kill reward. | north woods track past the bend | 95/84 | 30.9 s |
| 34 | I charge down the slope and engage the beast, swinging Heavy Slash the moment I reach it. | Erzähler | open_run_level | Close the distance to ENGAGED and attack with Heavy Slash. | north woods track past the bend | 95/84 | 15.9 s |
| 35 | I sprint after the retreating beast and close to ENGAGED, then swing Heavy Slash at it. | Erzähler | open_run_level | Close distance to ENGAGED and attack with Heavy Slash in one declared move-then-strike. | north woods track past the bend | 95/84 | 20.5 s |
| 36 | I withdraw from the root hollow, climb back up to the track, and make my way back to Brenna's mill to report what I found. | Erzähler | open_run_level | Withdraw from the unreachable den beast and return to Brenna with a true report. | mill floor | 95/84 | 21.1 s |
| 37 | "It's still alive — a big bristled beast, denned under the birch roots in the north hollow. It took a ewe tonight and it's too deep under th… | Erzähler | open_run_level | Give Brenna a true report on the den beast and collect the promised three silver. | mill floor | 95/84 | 30.5 s |
| 38 | "I'm listening. What terms did you have in mind for daylight?" | Erzähler | open_run_level | Hear Brenna's offer for a daylight hunt of the den beast. | mill floor | 95/84 | 22.8 s |
| 39 | I take the three silver from the table. "Agreed — eight on proof, the carcass mine, Hedric to the gate at first light." Then I climb into th… | Erzähler | open_run_level | Accept Brenna's terms, take the three silver, and sleep in the loft until first light. | mill floor | 95/84 | 40.6 s |
| 40 | I eat a quick breakfast, then tell Hedric I'm ready to walk to the pasture gate. | Erzähler | open_run_level | Finish breakfast and set out with Hedric toward the pasture gate. | mill floor | 95/84 | 58.7 s |
| 41 | I walk with Hedric through the pasture gate and follow the track toward the birch stand, watching for the churned mud where the ewe was drag… | Erzähler | open_run_level | Travel past the gate with Hedric's guidance toward the den beast in the birch stand. | north woods track past the bend | 95/84 | 26.2 s |
| 42 | I follow the drag-groove toward the water side of the birch hollow, sword drawn, watching for the den. | Erzähler | open_run_level | Track the den beast to its hollow and hunt the bristleback. | old birch stand | 95/84 | 23.9 s |
| 43 | I meet its charge and swing Heavy Slash at the brissleback's head as it closes. | Erzähler | open_run_level | Fight the charging brissleback with Heavy Slash. | old birch stand | 95/84 | 13.6 s |
| 44 | I meet its charge at ENGAGED range and swing Heavy Slash at the brissleback's head as it reaches me. | Erzähler | open_run_level | Fight the charging brissleback with Heavy Slash once it is in ENGAGED range. | old birch stand | 92/84 | 18.6 s |
| 45 | I swing Heavy Slash again to finish the wounded brissleback. | Erzähler | open_run_level | Finish the brissleback with Heavy Slash. | old birch stand | 92/84 | 16.2 s |
| 46 | I take the brissleback carcass proof and watch the breathing darkness under the roots from a careful distance, deciding whether to accept Br… | Erzähler | open_run_level | Secure the kill and decide on the dusk investigation offer. | old birch stand | 92/84 | 22.4 s |
| 47 | I shoulder my pack and walk back down to Hedric's pasture gate, then on to the mill house to report the kill to Brenna and collect the bount… | Erzähler | open_run_level | Return to the mill with the hide and tusk, report true, and collect Brenna's bounty before… | mill floor | 92/84 | 24.4 s |
| 48 | "Fair. And I'll take that porridge while I wait for dusk — then I'll go back and see what breathes under the dome." | Erzähler | open_run_level | Accept Brenna's dusk offer, eat and recover at the mill until dusk, then investigate the d… | dark hollow beneath the birch roots | 92/84 | 81.7 s |
| 49 | I find a shaded spot by the stream within sight of the den and wait there until dusk, then walk to the woven bark dome and look inside it. | Erzähler | open_run_level | Wait out the hours until dusk, then investigate the dome and den for Brenna's ten-silver o… | woven bark dome | 92/84 | 35.5 s |
| 50 | I draw my longsword and carefully peer past the woven bark dome into the den mouth. | Erzähler | open_run_level | Investigate the den at dusk for Brenna's ten-silver offer. | woven bark dome | 92/84 | 23.4 s |
| 51 | I back slowly out of the den mouth without turning my back on the amber eyes, then walk down the track to the mill house to report to Brenna… | Erzähler | open_run_level | Withdraw from an unknown larger predator and collect the ten-silver dusk report from Brenn… | mill floor | 92/84 | 51.6 s |
| 52 | "I'll take the loft for the night, Brenna. In the morning I'm for Corvane — something that size wants a hired spear, not mine." | Erzähler | open_run_level | Sleep at the mill to recover, then travel onward to the city next day. | mill floor | 95/84 | 62.6 s |
| 53 | I take the bread and cheese for the road, thank Brenna, and set out east along the river road toward Corvane. | Erzähler | open_run_level | Leave the mill and travel toward Corvane, staying alert for opportunities on the road. | Corvane | 95/84 | 20.8 s |
| 54 | I stop a market trader packing up and ask where I can sell a brissleback hide and tusk, and where a decent lodgings might be for the night. | Erzähler | open_run_level | Sell surplus loot and find lodging in Corvane before dark. | Corvane | 95/84 | 22.9 s |
| 55 | I knock on the blue door and offer Hask the brissleback hide and tusk, asking what he'll pay for the pair. | Erzähler | open_run_level | Sell the brissleback loot to Hask the furrier. | Corvane | 95/84 | 25.2 s |
| 56 | "Two silver's a low open, Hask, and we both know it. Four silver, the pair, and the tusk's thrown in clean." | Erzähler | open_run_level | Counter Hask's low bid to four silver for the hide and tusk. | Corvane | 95/84 | 13.6 s |
| 57 | "Three silver it is, Hask. Done." | Erzähler | open_run_level | Accept Hask's three-silver offer and complete the sale. | Corvane | 95/84 | 32.1 s |
| 58 | I pull the F-Rank Brissleback Hide and Tusk from my pouch and lay them on the counter. "They're here, Hask — three silver, as agreed." | Erzähler | open_run_level | Complete the sale using the items the HUD confirms I carry. | Corvane | 95/84 | 21.6 s |
| 59 | I leave Hask's shop with an apology and head to the Iron Boar inn to ask for a room for the night. | Erzähler | open_run_level | Drop the blocked sale after repeated engine refusals and get lodging before dark. | the Iron Boar inn | 95/84 | 19.4 s |
| 60 | "Evening. What's a room for the night run me? I'll take one." | Erzähler | open_run_level | Get a room at the Iron Boar and sleep until morning. | the Iron Boar inn | 95/84 | 13.7 s |
| 61 | "Room and the stew, please — coin up front for all of it." | Erzähler | open_run_level | Pay for the room and supper at the Iron Boar. | the Iron Boar inn | 95/84 | 15.1 s |
| 62 | I eat the stew by the fire, then take my key up to the back room, second door, and sleep until morning. | Erzähler | open_run_level | Eat supper and sleep at the Iron Boar until morning. | back room of the Iron Boar | 95/84 | 18.5 s |
| 63 | I wake, gear up, eat some dried meat, and set out from Corvane toward the north woods to investigate what's been taking Brenna's stock. | Erzähler | open_run_level | Leave the inn at dawn and travel to the north woods to investigate the stock disappearance… | hollow before the woven bark dome | 95/84 | 39.1 s |
| 64 | I stay back in the tree cover and quietly watch the den's entrance for signs of what dwells inside. | Erzähler | open_run_level | Scout the den from cover before committing to a fight. | hollow before the woven bark dome | 95/84 | 14.9 s |
| 65 | I approach the den's entrance carefully, staying off the pressed path, and peer inside to see what dwells there. | Erzähler | open_run_level | Close-inspect the den entrance from a careful approach to identify the dweller or its lair… | den entrance under the woven bark dome | 95/84 | 30.5 s |
| 66 | I search the den's nest and leavings for anything useful — bones, tusk, wool, or signs of tracks leading out — then follow the freshest trac… | Erzähler | open_run_level | Loot the empty den and track the absent dweller. | rise above the brackern dell | 95/84 | 77.1 s |
| 67 | I charge down the slope and strike with Heavy Slash at the beast while it's still worrying its kill. | Erzähler | open_run_level | Ambush the boar-beast with Heavy Slash to start the fight on my terms. | rise above the brackern dell | 95/84 | 20.2 s |
| 68 | I charge down the slope to close the distance, then strike with Heavy Slash as soon as I'm in range. | Erzähler | open_run_level | Close to ENGAGED range down the slope, then attack with Heavy Slash. | rise above the brackern dell | 95/84 | 57.6 s |
| 69 | I close the distance to ENGAGED range with the beast, drawing my sword as I charge down the slope. | Erzähler | open_run_level | Declare movement alone to close from LONG to ENGAGED, then attack next turn. | rise above the brackern dell | 95/84 | 18.7 s |
| 70 | I close the remaining distance to ENGAGED range and strike with Heavy Slash at the beast. | Erzähler | open_run_level | Close from MEDIUM to ENGAGED and land the Heavy Slash. | rise above the brackern dell | 95/84 | 58.9 s |
| 71 | I hold my ground and let the beast come to me, striking with Heavy Slash the moment it reaches ENGAGED range. | Erzähler | open_run_level | Wait for the charging beast to close into ENGAGED range, then land the Heavy Slash. | rise above the brackern dell | 95/84 | 16.8 s |
| 72 | I strike with Heavy Slash at the beast's head as it reaches me. | Erzähler | open_run_level | Land the Heavy Slash now that the beast has closed to SHORT range. | rise above the brackern dell | 95/84 | 16.1 s |
| 73 | I strike with Heavy Slash at the beast's head as it charges into me. | Erzähler | open_run_level | Land the Heavy Slash now that the HUD confirms the beast is at ENGAGED range. | rise above the brackern dell | 83/84 | 17.2 s |
| 74 | I strike with Heavy Slash at the beast's wounded head before it can charge again. | Erzähler | open_run_level | Land another Heavy Slash while the beast is at ENGAGED range. | rise above the brackern dell | 72/84 | 32.3 s |
| 75 | I finish it with another Heavy Slash to the beast's head. | Erzähler | open_run_level | Land a third Heavy Slash to kill the beast at 12 HP. | rise above the brackern dell | 72/84 | 18.2 s |
| 76 | #assign STR 3 VIT 2 | System (Befehl) | open_run_level | Spend the five level-up points on STR and VIT. | rise above the brackern dell | 72/84 | 2.2 s |
| 77 | I skin and butcher what I can usefully take from the boar-beast carcass, then head north through the trees toward where Brenna's stock has b… | Erzähler | open_run_level | Harvest the kill, then continue north investigating the stock disappearances. | the bend where the ewes were found | 72/84 | 45.0 s |
| 78 | I examine the ewe-death hollow for tracks or signs, then follow the track up toward the old birch stand. | Erzähler | open_run_level | Investigate the kill site, then push on to the birch stand where the taker was heard. | hollow before the woven bark dome | 72/84 | 28.0 s |
| 79 | I circle the mound at a careful distance, watching for fresh tracks and any sign the dweller is inside before deciding to strike or withdraw… | Erzähler | open_run_level | Reconnoiter the den before committing to a fight while wounded. | hollow before the woven bark dome | 72/84 | 20.1 s |
| 80 | I withdraw carefully back down the drag-line path and head south through the north woods to Brenna's farm to report what I found. | Erzähler | open_run_level | Withdraw wounded from the unconfirmed den and report the true finding to Brenna for the pr… | Brenna's farm | 72/84 | 30.2 s |
| 81 | I come inside, sit down, and say: "I'll hear it, Brenna. What's been chewing at you, and what do you think I'm owed?" | Erzähler | open_run_level | Hear Brenna's offer and the matter weighing on her over bread. | Brenna's farm | 72/84 | 35.9 s |
| 82 | "My road's for Corvane anyway, so I'll hear the terms. What's the pay, and what exactly do you want this spear to do?" | Erzähler | open_run_level | Hear Brenna's wages and terms before accepting the errand. | Brenna's farm | 72/84 | 23.0 s |
| 83 | "We've struck it. Half now, and I'll carry your token to Corvane and bring back a name." | Erzähler | open_run_level | Accept Brenna's finding-fee bargain and take the first silver and her token. | Brenna's farm | 72/84 | 33.1 s |
| 84 | "I'll set out now, while the light holds. Your writ speaks for me, I take it? Then I'm for Corvane — I'll ask at the Guild hall by the east … | Erzähler | open_run_level | Confirm the writ suffices and set out for Corvane to find a hired spear. | Corvane | 72/84 | 36.8 s |
| 85 | I walk to the Guild hall with the spear and crossed axe over its doors and ask at the counter about hiring a spear for a beast-kill job in t… | Erzähler | open_run_level | Reach the Guild hall before dusk and inquire about hiring a mercenary for Brenna's beast j… | Adventurers' Guild hall, Corvane | 72/84 | 31.1 s |
| 86 | I take the notice: one copper, cash — and write out the terms plain: Brenna of the mill village pays wages on the deed for the beast of the … | Erzähler | open_run_level | Post the one-copper Guild notice with Brenna's writ and terms before the board is read. | Adventurers' Guild hall, Corvane | 72/84 | 21.1 s |
| 87 | I tell the clerk my lodging — "I'll be at a tavern by the carter's yard tonight, they'll know which" — then walk over to Hask the furrier's … | – | open_run_level | Leave word with the clerk where to find me, then sell the brissleback loot to Hask before … | Adventurers' Guild hall, Corvane | 72/84 | 33.6 s **no reply after the message** |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 2 (notiert vor Zug 3): Creation complete: Level 1 Warrior, Heavy Slash + Guard, starter gear equipped, 5 silver.
- zu Zug 3 (notiert vor Zug 4): Entered Alderwatch without toll or registration; guard mentioned Guild hall and Bridge Street pickpockets.
- zu Zug 4 (notiert vor Zug 5): Engine refused my combined travel+ask with 'arrival pending'; now arrival is confirmed and HUD lists Merchant A and Merchant B present at the square. No loot to sell yet, so scouting gear prices first.
- zu Zug 5 (notiert vor Zug 6): Shop panel shows the used longsword (ATK 6) is worse than my starter (ATK 10), so I skip blades; shield offered at 3s, firm at 2.5s.
- zu Zug 6 (notiert vor Zug 7): Shield bought at 2.5s but not equippable: strap too short for starter armor; smith offers a 1-cp strap fix (SHOP panel lists it).
- zu Zug 7 (notiert vor Zug 8): Shield now properly equipped after the 1-copper strap fix; coin 4s 9c. Engine required purchase and equip as separate steps, both confirmed.
- zu Zug 8 (notiert vor Zug 9): Merchant A sells meat at 1 cp/quarter-pound but no bread or skins; baker two stalls down sells hardtack 1 cp/brick; waterskin refill is 1 cp at the well.
- zu Zug 9 (notiert vor Zug 10): Provisions nearly done; shield equipped, ATK still 10. Note: HUD 'Equipped' list doesn't show the shield, though narration confirmed it strapped — worth checking before relying on it in combat.
- zu Zug 10 (notiert vor Zug 11): HUD coin still 4s7c though narration showed 1c paid for the brick and 1c for the well; brick also absent from Carried and shield still missing from Equipped despite confirmed narration. Provisions done, so I'm leaving town and gathering direction from the guard.
- zu Zug 11 (notiert vor Zug 12): HUD still shows coin 4s7c and brick/shield absent from Carried/Equipped despite confirmed purchases; I'll rely on narration and re-check panels later.
- zu Zug 12 (notiert vor Zug 13): Arrived near Milbrook in a quarter day (faster than the guard's half-day estimate); encounter at a tilted cart with an injured farmer on the north track toward the rumored north woods.
- zu Zug 13 (notiert vor Zug 14): HUD coin still 4s7c and shield still missing from Equipped despite earlier confirmed purchases; brick and waterskin absent from Carried. Silla offered a meal and pointed to headman Brenna at the mill house re north woods trouble.
- zu Zug 14 (notiert vor Zug 15): HUD coin still 4s7c despite confirmed spending earlier; shield still missing from Equipped. Shop panel offered stew/bread at 1 cp; Silla said I've earned half price.
- zu Zug 15 (notiert vor Zug 16): Coin corrected to 45 copper after purchase; shield still absent from Equipped despite earlier confirmation. Time is 14:30, so Brenna may not be available until dusk.
- zu Zug 16 (notiert vor Zug 17): Brenna's offer confirmed: 3s for a true report, 4s plus meat claim if something is killed. Quest panel still empty — will verify the job is ACTIVE before travelling.
- zu Zug 17 (notiert vor Zug 18): Job accepted in narration but Quests panel still shows '—'; the goal line records it only as a promise. Will verify ACTIVE before travelling.
- zu Zug 18 (notiert vor Zug 19): Time jumped overnight to first light of Day 2 at the pasture gate; narration confirms lodging and Hedric's escort. Quests panel still shows '—' but the goal line records the job as a promise; proceeding on the narration.
- zu Zug 19 (notiert vor Zug 20): HUD time contradicts narration: panel says Day 1, 19:30 evening while the story has first light of Day 2 at the gate. Quests panel still shows '—' despite the struck job.
- zu Zug 20 (notiert vor Zug 21): HUD still shows Day 1, 20:10 evening while narration has first light of Day 2 — persistent time contradiction. Search of hollow failed (PER check); no tracks, clean site. Quests panel still '—'.
- zu Zug 21 (notiert vor Zug 22): Reached the old birch stand; HUD time now says Day 1, 20:35 evening while narration still reads morning — persistent time contradiction. A low, wide unmoving shape in deep shade is the only new lead.
- zu Zug 22 (notiert vor Zug 23): Found a woven bark dome over a breathing den beneath the birch roots — something alive, no kill remains or tracks anywhere. HUD time still contradicts narration (Day 1 evening vs. story morning).
- zu Zug 23 (notiert vor Zug 24): The den dweller never emerged; breathing settled into deep sleep. A Level-1 solo fight in its own burrow seems beyond my abilities, so completing the paid report is the sensible play.
- zu Zug 24 (notiert vor Zug 25): HUD still contradicts narration: Present says 'nobody besides Alaric' and time reads Day 1, 23:05 night while Brenna speaks to me at midday. No silver change yet — the offer is still only a promise, so I'm explicitly asking for payment.
- zu Zug 25 (notiert vor Zug 26): Silver rose from 3 to 4 Silver 5 Copper with the three-silver payment, though HUD still shows Day 1, 23:05 night while narration is midday — persistent time contradiction. New offer: ten silver for a dusk investigation, plus bed and meal at the mill house.
- zu Zug 26 (notiert vor Zug 27): The engine refused my combined action because the room was not booked first — lodging must be an explicit purchase before sleeping. Brenna's price: 1 copper shared tick, 2 coppers private corner.
- zu Zug 27 (notiert vor Zug 28): Narration says Brenna is on the mill floor weighing grist, while HUD Present still lists 'nobody besides Alaric' — persistent presence/time contradictions. Lodging must be paid explicitly to Brenna herself.
- zu Zug 28 (notiert vor Zug 29): Payment to Brenna succeeded this time and the corner is booked; the time contradiction persists — HUD says Day 2, 00:20 night while narration runs a mill-busy afternoon.
- zu Zug 29 (notiert vor Zug 30): Sleep in the loft was narrated; HP already full beforehand. HUD time still reads night (00:35) while narration says dusk approaches — persistent time offset, but goals panel confirms the dusk investigation is the active task.
- zu Zug 30 (notiert vor Zug 31): Narration confirms I woke at dusk and took up my sword; HUD still reads Day 2, 00:45 night — the time offset persists but travel is now the resolved next step.
- zu Zug 31 (notiert vor Zug 32): Arrival at the den area is engine-confirmed as a sign: something feeds thirty paces downslope and stopped when the night went still, so it may be alert. HUD time still reads Day 2, 01:00 night against the narrated dusk.
- zu Zug 32 (notiert vor Zug 33): Enemy confirmed as a MEDIUM Bristle-Spined Hollow Beast, 23 HP, unaware and downwind; my HP and STA are full, so fighting is a reasonable risk.
- zu Zug 33 (notiert vor Zug 34): Refusal was a range issue: Heavy Slash only reaches ENGAGED, so I must declare movement into range first. Beast is still unaware of my exact position.
- zu Zug 34 (notiert vor Zug 35): Second refusal was range again: engine now places the beast at LONG and it is loping away toward deep root cover — I must catch it before it escapes.
- zu Zug 35 (notiert vor Zug 36): The beast escaped into a root den beyond sword reach after two range-based refusals; it never counterattacked. Withdrawing to report fulfills Brenna's three-silver true-report offer instead of forcing a losing fight.
- zu Zug 36 (notiert vor Zug 37): Beast escaped into root den unreachable by sword; withdrew safely. Now at Brenna's door past 01:00 to deliver the true report.
- zu Zug 37 (notiert vor Zug 38): Three silver confirmed on the table for the true report; Brenna now offers more pay for a dusk investigation of the den dweller. HUD coin still shows 4s5c — payment likely pending my acceptance/count.
- zu Zug 38 (notiert vor Zug 39): Brenna's terms are concrete: 8 silver on proof, carcass mine, Hedric guides to the pasture gate at dawn. The three-coin payment is not yet reflected in the HUD coin total, so I will verify it after taking the coins.
- zu Zug 39 (notiert vor Zug 40): Time jumped oddly: I slept at ~02:00 but it's still night at 03:57 — sleep seems not fully processed. Coins taken (4s5c total), Hedric present at the gate as promised. He hints the sword alone may not suffice.
- zu Zug 40 (notiert vor Zug 41): HUD still shows mill floor at 04:27 with Hedric absent despite narration of the walk; the gate travel is pending engine confirmation.
- zu Zug 41 (notiert vor Zug 42): HUD still shows night at 04:52 despite narration of morning light and breakfast; time seems desynced from story. Otherwise proceeding to the birch stand as planned.
- zu Zug 42 (notiert vor Zug 43): Combat panel confirms Brissleback A, 41 HP, charging; also a second unknown living thing breathing under the roots behind the den.
- zu Zug 43 (notiert vor Zug 44): Refusal was a range issue: Heavy Slash needs ENGAGED, brissleback was at SHORT and has now closed to ENGAGED.
- zu Zug 44 (notiert vor Zug 45): First Strike Heavy Slash landed for 32, brissleback at 9 HP; it gored me for 3 (HP 92). Second breathing thing under the roots still unstirred.
- zu Zug 45 (notiert vor Zug 46): Brissleback defeated for 24 XP and F-rank loot; the den dweller under the roots remains unstirred and unidentified. Brenna's bounty terms and the ten-silver dusk offer are recorded as leads.
- zu Zug 46 (notiert vor Zug 47): Woven bark dome with grey hair confirmed at the den mouth — the breathing thing may be the ewe-taker itself, so the dusk offer looks worth considering. Thigh wound unhealed at 92/95.
- zu Zug 47 (notiert vor Zug 48): Bounty collected (+4 silver, now 8s5c); dusk offer confirmed as a promise in the HUD. Thigh wound still untreated — porridge and rest at the mill before dusk.
- zu Zug 48 (notiert vor Zug 49): Two crows now occupy the den area; the breathing thing remains unstirred through the afternoon. HUD confirms bounty paid (8s5c) and the dusk promise active.
- zu Zug 49 (notiert vor Zug 50): Dusk arrived; HUD confirms the dome is a deliberately plaited dwelling and the dweller's breathing quickened with clicking at dusk. Prior 'look inside it' was refused as arrival pending — now at the dome.
- zu Zug 50 (notiert vor Zug 51): The den dweller is larger than the dead brissleback, with a wrong multi-lumped outline and open amber eyes — too dangerous for a lone L1. I'm withdrawing to report true and collect the dusk offer.
- zu Zug 51 (notiert vor Zug 52): Ten-silver dusk report paid (now 1g8s5c). The den dweller is confirmed intelligent and dangerous — beyond a lone L1, so I'm declining further pursuit and moving on after recovery.
- zu Zug 52 (notiert vor Zug 53): Fully recovered after the mill loft night (HP 95/95, STA 100/100). Heading for Corvane as planned; den dweller mystery left for stronger spears.
- zu Zug 53 (notiert vor Zug 54): Arrived in Corvane at 18:00, Day 3; Guild hall shuts at dark and I'm deliberately not registering. Market stalls packing up — good moment to ask about buyers and a bed.
- zu Zug 54 (notiert vor Zug 55): Trader directed me to Hask (blue door, still lit) and the Iron Boar inn; Hask opens low by habit, so I'll counter if needed.
- zu Zug 55 (notiert vor Zug 56): Hask opened at 2 silver for the pair despite clean cure; the trader warned he opens low, so I'm countering.
- zu Zug 56 (notiert vor Zug 57): Hask countered at three silver for the pair; accepting rather than haggling further over a small hide.
- zu Zug 57 (notiert vor Zug 58): Narrator claimed the hide and tusk were gone, but the HUD confirms both still in Carried — treating the HUD as authoritative and re-presenting them.
- zu Zug 58 (notiert vor Zug 59): Engine repeatedly refuses the sale ('nobody to sell to') even though Hask is present and the HUD confirms I carry the hide and tusk — a clear contradiction; Hask says the three-silver offer stands if the items turn up, so I'll try selling again tomorrow and move on to lodging.
- zu Zug 59 (notiert vor Zug 60): Sale to Hask is persistently blocked by the engine ('nobody to sell to') despite HUD confirming I carry the hide and tusk; Hask offered to honor three silver tomorrow. Room request at the inn was refused with 'arrival pending' even though the HUD places me inside the Iron Boar — trying a direct address to the innkeeper.
- zu Zug 60 (notiert vor Zug 61): Innkeeper offers room 3cp, stew 4cp, ale 2cp; HUD still confirms hide and tusk carried despite engine refusals at Hask's.
- zu Zug 61 (notiert vor Zug 62): Room and stew purchased for 7 copper, key received; hide and tusk still carried despite the blocked sale at Hask's.
- zu Zug 62 (notiert vor Zug 63): Sleep completed overnight despite the 'arrival pending' refusal; it is now Day 4, 05:15, fully recovered. Heading out to fulfill Brenna's paid report on the north woods.
- zu Zug 63 (notiert vor Zug 64): Arrived at the woven bark den; the lead notes its outline is wrong for a brissleback, suggesting something bigger — scouting before engaging.
- zu Zug 64 (notiert vor Zug 65): Scouting check failed (PER 7 vs 6) — the hollow showed nothing; the den's occupant is away or hidden. Full HP/STA at the den, tracks suggest something bigger than a brissleback.
- zu Zug 65 (notiert vor Zug 66): Den confirmed empty and not a brissleback's — something bigger has been away for days; Brenna's report can now be made truthfully even without a kill.
- zu Zug 66 (notiert vor Zug 67): Beast confirmed: Great Tusked Boar-Beast, HP 68, LONG, lying over a fresh kill in a one-entrance dell. Full resources; kill earns Brenna's fourth silver.
- zu Zug 67 (notiert vor Zug 68): Combat refused because Heavy Slash could not reach LONG range; the fix is to declare the closing movement first, then the strike.
- zu Zug 68 (notiert vor Zug 69): Two refusals because movement and Heavy Slash cannot share one message; separating the declared movement from the attack.
- zu Zug 69 (notiert vor Zug 70): Movement last turn only closed LONG to MEDIUM; the beast is now alerted, standing over its kill with ears pinned.
- zu Zug 70 (notiert vor Zug 71): Beast is now charging up the slope toward me; movement-and-attack in one message was refused again, so I let it close the gap itself.
- zu Zug 71 (notiert vor Zug 72): HUD now shows the beast at SHORT range, so it is finally within Heavy Slash reach; attacking this turn.
- zu Zug 72 (notiert vor Zug 73): HUD now shows the beast at ENGAGED, contradicting the last refusal at SHORT; striking this turn.
- zu Zug 73 (notiert vor Zug 74): Combat finally started; first Heavy Slash landed for 29 damage, beast at 39/68 HP and ENGAGED; I took 12 damage (83/95 HP).
- zu Zug 74 (notiert vor Zug 75): Beast down to 12/68 HP at ENGAGED; one more Heavy Slash (25–31) should finish it. I've taken 23 damage so far (72/95).
- zu Zug 75 (notiert vor Zug 76): Boar-beast defeated: +92 XP, Level 2 with 5 free points, loot (hide, 2 tusks) gained. HP max rose to 105; I'm at 72 and wounded.
- zu Zug 76 (notiert vor Zug 77): Assignment confirmed: STR 12, VIT 11, points spent. Beast defeated with loot in pouch; kill site lies over a fresh reddish kill below the rise.
- zu Zug 77 (notiert vor Zug 78): Site was cleaned of remains; another large creature moved off uninterested nearby. Wounded at 72/115 HP with heavy loot to carry.
- zu Zug 78 (notiert vor Zug 79): Found the predator's den: a large woven bark dome with fresh deep tracks; I'm wounded (72/115) so scouting before engaging.
- zu Zug 79 (notiert vor Zug 80): Scout roll failed to confirm whether the dweller is home; fresh tracks and a silent wood suggest it may be near. At 72/115 HP with heavy loot, withdrawing to report (3s) and recover before hunting it is the sound play.
- zu Zug 80 (notiert vor Zug 81): Wounded at 72/115 HP but safe at the farm midday; Brenna hints at further paid work beyond the promised three silver.
- zu Zug 81 (notiert vor Zug 82): Brenna confirmed the promised silver is paid (coin should rise) and offered paid work: find a hired spear in Corvane to kill the den-dweller before the Crown's levy count at month's end.
- zu Zug 82 (notiert vor Zug 83): Terms confirmed: two silver finding fee, half now, half on delivering a name; token promised. Task is to find a hired spear in Corvane, not fight the beast myself.
- zu Zug 83 (notiert vor Zug 84): Writ and one silver confirmed in hand per narrator; HUD coin still shows 7s8c and no token in inventory, so I'll verify the payment and token before relying on them.
- zu Zug 84 (notiert vor Zug 85): Coin rose to 1 Gold 7 Silver 8 Copper — the finding fee seems recorded, though as a gold piece rather than the one silver Brenna counted; the writ isn't visible in the listed inventory but is confirmed by narration. Guild counter still manned at 17:25.
- zu Zug 85 (notiert vor Zug 86): Clerk confirmed private hiring, not a Guild contract; notice costs 1 cp/day, cash at counter. Hask the furrier (blue door, two streets off market) flagged as hide/tusk buyer.
- zu Zug 86 (notiert vor Zug 87): Notice and writ posted for 1 copper, coin confirmed at 1g7s7c. Clerk advises leaving lodging details so takers can find me.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t44 | 44 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t73 | 73 | 1 | – | nein | 1 | gewonnen, 92 XP |

## Quests

Keine angenommen.


## Auffälligkeiten

- Zug 87 (Runner/UI): no reply after the message
- Zug 9, Nachricht 18 (extraction_repaired): the extractor's first answer needed a repair
- Zug 10, Nachricht 20 (extraction_repaired): the extractor's first answer needed a repair
- Zug 16, Nachricht 32 (extraction_repaired): the extractor's first answer needed a repair
- Zug 18, Nachricht 36 (extraction_repaired): the extractor's first answer needed a repair
- Zug 18, Nachricht 36 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 18, Nachricht 36 (finish): extract_repair ended with finish_reason "length"
- Zug 22, Nachricht 44 (extraction_repaired): the extractor's first answer needed a repair
- Zug 25, Nachricht 50 (extraction_repaired): the extractor's first answer needed a repair
- Zug 25, Nachricht 50 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 25, Nachricht 50 (finish): extract ended with finish_reason "length"
- Zug 26, Nachricht 51 (planner_repaired): the planner's first answer needed a repair
- Zug 26, Nachricht 52 (extraction_repaired): the extractor's first answer needed a repair
- Zug 27, Nachricht 53 (planner_repaired): the planner's first answer needed a repair
- Zug 29, Nachricht 57 (planner_repaired): the planner's first answer needed a repair
- Zug 30, Nachricht 59 (planner_repaired): the planner's first answer needed a repair
- Zug 31, Nachricht 61 (planner_repaired): the planner's first answer needed a repair
- Zug 40, Nachricht 79 (planner_repaired): the planner's first answer needed a repair
- Zug 40, Nachricht 79 (finish): plan ended with finish_reason "length"
- Zug 41, Nachricht 81 (planner_repaired): the planner's first answer needed a repair
- Zug 48, Nachricht 95 (planner_repaired): the planner's first answer needed a repair
- Zug 48, Nachricht 96 (extraction_repaired): the extractor's first answer needed a repair
- Zug 49, Nachricht 97 (planner_repaired): the planner's first answer needed a repair
- Zug 49, Nachricht 98 (extraction_repaired): the extractor's first answer needed a repair
- Zug 51, Nachricht 101 (planner_repaired): the planner's first answer needed a repair
- Zug 51, Nachricht 101 (finish): plan ended with finish_reason "length"
- Zug 52, Nachricht 104 (extraction_repaired): the extractor's first answer needed a repair
- Zug 52, Nachricht 104 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 52, Nachricht 104 (finish): extract ended with finish_reason "length"
- Zug 58, Nachricht 115 (planner_repaired): the planner's first answer needed a repair
- Zug 63, Nachricht 126 (extraction_repaired): the extractor's first answer needed a repair
- Zug 66, Nachricht 132 (extraction_repaired): the extractor's first answer needed a repair
- Zug 66, Nachricht 132 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 66, Nachricht 132 (finish): extract ended with finish_reason "length"
- Zug 68, Nachricht 136 (extraction_repaired): the extractor's first answer needed a repair
- Zug 68, Nachricht 136 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 68, Nachricht 136 (finish): extract ended with finish_reason "length"
- Zug 69, Nachricht 138 (extraction_repaired): the extractor's first answer needed a repair
- Zug 77, Nachricht 153 (planner_repaired): the planner's first answer needed a repair
- Zug 77, Nachricht 153 (finish): plan ended with finish_reason "length"
- Zug 77, Nachricht 154 (extraction_repaired): the extractor's first answer needed a repair
- Zug 78, Nachricht 156 (extraction_repaired): the extractor's first answer needed a repair
- Zug 84, Nachricht 167 (planner_repaired): the planner's first answer needed a repair
- Zug 84, Nachricht 168 (extraction_repaired): the extractor's first answer needed a repair
- Zug 87, Nachricht 173 (planner_repaired): the planner's first answer needed a repair
- Seitenfehler: An unexpected error has occurred.     at sendOpenAIRequest (http://127.0.0.1:8123/scripts/openai.js:3199:19)     at async sendGenerationRequest (http://127.0.0.1:8123/script.js:6118:16)
- Hinweis (error): API returned an errorAn unexpected error has occurred.
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 20× keine gültige JSON-Entscheidung (Züge 2, 7, 12, 13, 19, 22, 23, 27, 32, 39, 42, 43, 44, 49, 50, 62, 70, 74, 79, 81)
- 9 Aufruf(e) mit finish_reason "length" (Nr. 52 extract, Nr. 75 extract, Nr. 84 narrator, Nr. 126 plan, Nr. 165 plan, Nr. 171 extract, Nr. 216 extract, Nr. 224 extract, Nr. 248 plan)

System-Panels: CLARIFY 0, NOT TAKEN 1, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: offer 5, ambient 4, time_cap 4, no_go 7, scene_context 40, world_rule 4, npc_continuity 17, pc_inventory 2, engine_owned_fact 1, coin_evidence 2, attack_commitment 4, coin_already_received 1, engine_recovery 1, place 1, object 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 5, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 98 | 14 | 2.8 s | 7.6 s | 11084 | 9761 | 108 | – | stop 95, length 3 | 3 |
| narrator | 85 | 0 | 9.9 s | 15.8 s | 11313 | 8820 | 477 | – | stop 83, length 1 | 2 |
| extract | 102 | 15 | 6.4 s | 19.6 s | 11284 | 9118 | 534 | – | stop 97, length 5 | 5 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 54:43 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 61.7 s) | 1:19 min |
| 87 Züge, Spiel (Senden bis HUD nach der Extraktion) | 44:54 min — Median 23.9 s, p90 58.9 s, max 116.8 s |
| 87 Züge, Spieler-Entscheidung | 7:07 min — Median 3.3 s, 20 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 6:56 min / 0:00 min / 15:50 min / 16:54 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 35.9 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 23:55 min, 80 Züge ≈ 47:49 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spiel | 27 | – | 116.8 s | 23.9 s |
| Spiel | 48 | – | 81.7 s | 23.9 s |
| Spiel | 25 | – | 78.9 s | 23.9 s |
| Provider narrator | 27 | 84 | 97.4 s | 9.9 s |
| Provider narrator | 70 | 231 | 49.5 s | 9.9 s |
| Provider narrator | 17 | 47 | 38.5 s | 9.9 s |
| Provider extract | 25 | 75 | 53.4 s | 6.4 s |
| Provider extract | 66 | 216 | 47.0 s | 6.4 s |
| Provider extract | 18 | 52 | 44.0 s | 6.4 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
