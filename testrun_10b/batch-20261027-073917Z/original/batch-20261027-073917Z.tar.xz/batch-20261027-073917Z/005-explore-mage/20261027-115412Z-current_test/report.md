# Avereth Live-Test 20261027-115412Z-current_test

## Kurzfassung

- **Laufprofil:** explore-mage; Startklasse Mage, Schwerpunkt explore. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** planner_failed — turn 123: the semantic Planner failed before story generation (commands[0] (offer.accept): party_words must copy the counterparty from the player message; commands[0] (offer.accept): agreed_cp contradicts the player’s state)
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 1. Sicherheitsgrenzen: 150 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** Level 1, 0 XP seit Levelaufstieg, 50 cp, HP 90, MP 96; Ort loc.stuck_cart_at_the_marshy_inlet.edas_stilt_house. Ausrüstung und Skills stehen in evaluation.json → progression.checkpoint.
- **Charakter:** mage (mage.arcane_bolt, mage.flame_lance) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: curious adventurer: follow interesting opportunities without forcing dangerous encounters
- **Züge:** 123 · **Dauer:** 105:53 min · **LLM-Aufrufe der Engine/des Erzählers:** 399
- **Auffälligkeiten:** 68
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.101 |
| Git | c9e3fa58bb57 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 15.3 s |
| Browser | chrome 156.0.8078.48 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261027-115412Z-current_test“, Seed 1613311445 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | Mage | Engine (Menü/Rückfrage) | creation_complete | Choose the Mage base class. | public roadside verge outside Ashbridge | 90/84 | 2.3 s |
| 2 | I choose Arcane Bolt and Flame Lance. | Engine (Menü/Rückfrage) | creation_complete | Pick two offensive starter skills to finish character creation. | public roadside verge outside Ashbridge | 90/96 | 2.1 s |
| 3 | I walk along the road toward Ashbridge's gates. | Erzähler | open_run_level | Enter Ashbridge to gather information, buy supplies, then head out traveling. | Ashbridge | 90/96 | 19.3 s |
| 4 | I nod to the guard and step up to the arch, walking through the gate into Ashbridge. | Erzähler | open_run_level | Enter Ashbridge through the gate to gather information and buy supplies. | Ashbridge | 90/96 | 31.5 s |
| 5 | I ask a passerby what the commotion down the side lane is about. | Erzähler | open_run_level | Investigate the angry crowd as a possible discovery or opportunity. | Ashbridge | 90/96 | 17.5 s |
| 6 | I move closer to the edge of the crowd to see and hear what is happening at the Welkins' shop door. | Erzähler | open_run_level | Investigate the Welkins family dispute as a possible discovery or opportunity. | Welkins' shop | 90/96 | 28.8 s |
| 7 | "Corlin's Ford — is that the venture upriver? I've come along the road from that direction. May I ask what the venture was?" | Erzähler | open_run_level | Speak up to Dannel and Welkins, offering possible knowledge of Corlin's Ford to find a dis… | Welkins' shop | 90/96 | 20.1 s |
| 8 | "From beyond it — I walked the road past the ford this morning. The landing site was easy to find, right where the timber sits. I could tell… | Erzähler | open_run_level | Offer Dannel a firsthand account of Corlin's Ford as paid work or a lead toward the uprive… | Welkins' shop | 90/96 | 18.8 s |
| 9 | "Your father's back room suits me. I'll tell you both what I saw of the ford and the landing — and if the venture's worth saving, maybe ther… | Erzähler | open_run_level | Accept the back-room talk, give my firsthand account, and probe for paid work at Corlin's … | Welkins' shop | 90/96 | 25.7 s |
| 10 | "A letter to Corlin suits me, and guarding a timber yard is work I can do. Write the letter, and I'll walk back up this afternoon." | Erzähler | open_run_level | Accept the guard work at Corlin's Ford and ask for the letter of introduction, turning thi… | Welkins' shop | 90/96 | 17.2 s |
| 11 | I take the letter and set out for Corlin's Ford, walking back up the road I came by this morning. | Erzähler | open_run_level | Travel upriver to Corlin's Ford with the letter to find the paid guard work. | Corlin's Ford | 90/96 | 21.7 s |
| 12 | "From Dannel Welkins, in Duskreach — he holds a share in this venture. I walked the ground this morning: the pilings stand. He sent this let… | Erzähler | open_run_level | Hand over the letter to the workman, who is presumably Corlin, and introduce myself for th… | Corlin's Ford | 90/96 | 20.4 s |
| 13 | "I'll go up to the raft camp after him — two hours' walk is nothing. Point me across the water, Harn." | Erzähler | open_run_level | Take Harn's offer to cross the river and go find Corlin at the raft camp to secure the pai… | Corlin's Ford | 90/96 | 30.4 s |
| 14 | "Not lost — looking for Corlin. Harn ferried me over and says the timber's not walking off by itself. Which of you is Corlin, or is he in ca… | Erzähler | open_run_level | Answer the aproned raftman's challenge and ask for Corlin at the raft camp. | Corlin's Ford | 90/96 | 20.9 s |
| 15 | "Dannel Welkins sent me — he holds a share in the landing. I walked the ground this morning and saw the pilings standing. He gave me this le… | Erzähler | open_run_level | Give Corlin the sealed letter, introduce myself, and press for the paid guard job. | Corlin's Ford | 90/96 | 80.3 s |
| 16 | "Alaric Red. And the staff is for more than walking — I'm a trained mage, though new to the road. I'll sit your yard a week for a silver and… | Erzähler | open_run_level | Give Corlin my name, confirm I'm a mage, and accept the week-to-week guard terms. | Corlin's Ford | 90/96 | 18.3 s |
| 17 | "I'll see the ground while there's light — show me the yard's bounds and where you'd want me standing after dark." | Erzähler | open_run_level | Take Corlin's offer to walk the yard in daylight and learn the guard post before nightfall… | Corlin's Ford | 90/96 | 18.0 s |
| 18 | I'll eat at the cook fire when the shift comes off, then take the lean-to and sleep until Corlin calls the night shift. | Erzähler | open_run_level | Eat, rest in the lean-to, then start the night watch when Corlin calls the shift. | Corlin's Ford | 90/96 | 22.8 s |
| 19 | Sleep for about four hours, until Corlin wakes me for the night shift. | Erzähler | open_run_level | Answer the engine's duration question: nap in the lean-to until Corlin calls the shift. | Corlin's Ford | 90/96 | 105.4 s |
| 20 | I take up the corner post watch and keep my eyes on the treeline through the night. | Erzähler | open_run_level | Start the night watch at the corner post, watching the treeline. | Corlin's Ford | 90/96 | 19.3 s |
| 21 | I eat from the pot at the cook fire, then ask Corlin about that game trail back along the treeline — whether he'd want it walked before toni… | Erzähler | open_run_level | Eat, then follow up on Corlin's game trail lead as a possible morning job or discovery. | Corlin's Ford | 90/96 | 19.8 s |
| 22 | "Alaric Red — the staff's for spellwork; I'm a trained mage. I'll walk that trail at midday, like you say, and tell you what's back there." | Erzähler | open_run_level | Answer Corlin's question, then follow his lead to scout the game trail at midday. | Corlin's Ford | 90/96 | 42.9 s |
| 23 | I wait for midday, then walk the game trail up past the first bend, watching for tracks or anything living along it. | Erzähler | open_run_level | Scout Corlin's game trail at midday as promised. | bedding hollow on the game trail | 90/96 | 20.7 s |
| 24 | I follow the far trail downhill a short way, cautiously, tracking prints and staying ready to retreat if the beast is ahead. | Erzähler | open_run_level | Track the beast's departure trail cautiously without engaging it. | game trail above the stream | 90/96 | 27.5 s |
| 25 | I back away quietly behind the deadfall and retreat up the trail toward the hollow, keeping downwind and not engaging the boar. | Erzähler | open_run_level | Withdraw from a fight beyond a Level 1 mage's abilities. | bedding hollow on the game trail | 90/96 | 20.7 s |
| 26 | I head back down the near trail toward the raft camp, watching my backtrail, and report to Corlin: a big scarred boar, ox-sized, is bedding … | Erzähler | open_run_level | Return to camp and deliver the scouting report to Corlin. | raft camp | 90/96 | 42.4 s |
| 27 | "My advice: let it keep. It's stayed off the yard so far — I'll cut a warning notch-mark at the first bend so none of your men wanders up th… | Erzähler | open_run_level | Advise Corlin to leave the boar alone, offer a cheap safety measure, and collect the promi… | raft camp | 90/96 | 24.7 s |
| 28 | #bag | System (Befehl) | open_run_level | Verify whether Corlin's paid silver was recorded in my coin. | raft camp | 90/96 | 2.2 s |
| 29 | I settle in at the camp until dusk, eat at the cook's pot with the men, then take the corner post night watch as agreed. | Erzähler | open_run_level | Do the promised night watch and earn the rest of the week's arrangement. | raft camp | 90/96 | 46.0 s |
| 30 | I hand Corlin the sealed letter I've been carrying: "This was meant for you — time you had it." | Erzähler | open_run_level | Deliver the sealed letter to Corlin and see what it opens. | raft camp | 90/96 | 55.3 s |
| 31 | I take a loaf from the board, thank the cook, and walk the trail behind Harn's timber to see what's back there. | Erzähler | open_run_level | Follow the camp goal and investigate the trail behind Harn's timber. | loading flat behind Harn's timber | 90/96 | 29.7 s |
| 32 | I examine the flattened grass patch and the broad paw-prints closely, looking for clues about what the creature is — claw marks, hair, scat,… | Erzähler | open_run_level | Investigate the unknown creature's sign at the loading flat before deciding whether to fol… | loading flat behind Harn's timber | 90/96 | 14.7 s |
| 33 | I follow the hillside trail where the prints left the flat, keeping watch for the creature ahead. | Erzähler | open_run_level | Track the broad-pawed creature up the hillside trail. | the lay on the hillside trail | 90/96 | 94.0 s |
| 34 | I back slowly down the trail toward the loading flat, staff in hand, watching the cat and giving it the slope. | Erzähler | open_run_level | Withdraw from the tawny cat without provoking it. | loading flat behind Harn's timber | 90/96 | 15.7 s |
| 35 | I walk back down the river track to the landing and cross the water to head up toward the raft camp after Corlin. | Erzähler | open_run_level | Withdraw done; go find Corlin at the Ford to deliver the letter and seek paid work. | raft camp | 90/96 | 30.9 s |
| 36 | I walk up to Corlin and hand him the sealed letter: "This was meant for you — time you had it. Harn also says the timber's not walking off b… | Erzähler | open_run_level | Deliver the letter to Corlin now that he is present, and relay Harn's message. | raft camp | 90/96 | 21.2 s |
| 37 | I examine the footprints going into the water and the ripples along the raft's edge, looking for which direction Corlin pushed off — upstrea… | Erzähler | open_run_level | Track Corlin's direction from the water's edge signs. | raft camp | 90/96 | 39.8 s |
| 38 | I follow the water's edge downstream past the camp's point, keeping to the brush line and watching the river for Corlin or any sign of where… | Erzähler | open_run_level | Track Corlin downstream behind the camp's point. | hidden raft camp on the rise | 90/96 | 93.8 s |
| 39 | I follow the worn path further up from the hidden raft camp, keeping to cover and watching ahead for the two men. | Erzähler | open_run_level | Trail Corlin and the heavier man beyond the hidden camp. | hidden raft camp on the rise | 90/96 | 73.5 s |
| 40 | I walk out of the tree cover toward Corlin, letter in hand: "Corlin — you're a hard man to catch. This came from Harn for you." | Erzähler | open_run_level | Deliver the letter to Corlin while he is alone. | hidden raft camp on the rise | 90/96 | 60.7 s |
| 41 | "Nobody followed. I crossed at the landing in front of Harn — he knows I came after you. Letter's delivered. Now, Harn says you're the one w… | Erzähler | open_run_level | Answer Corlin's question truthfully and ask about pay for the delivery or further work. | hidden raft camp on the rise | 90/96 | 36.5 s |
| 42 | I sit on the edge of the rock slab and listen: "I'm sitting. What's the reason the rafts are built out here?" | Erzähler | open_run_level | Hear Corlin's explanation of the hidden raft camp and look for follow-up work or pay. | hidden raft camp on the rise | 90/96 | 20.9 s |
| 43 | I ask Corlin: "If I spot it at night — do I just report, or would you want me to drive it off if it goes for a raft? And is there a bounty f… | Erzähler | open_run_level | Clarify the watcher's duties and whether there is pay or a bounty for dealing with the cre… | hidden raft camp on the rise | 90/96 | 22.5 s |
| 44 | I check the sealed letter situation with #bag. | Erzähler | open_run_level | Verify whether the letter is still recorded in inventory despite Corlin taking it. | hidden raft camp on the rise | 90/96 | 14.5 s |
| 45 | I take my bread from under the canvas and eat, then walk the timber trail behind the camp at midday as Corlin asked, keeping my eyes open fo… | Erzähler | open_run_level | Eat, then scout the midday trail for sign of the creature. | top of the timber trail above the vale | 90/96 | 27.7 s |
| 46 | I keep my distance and study the pushed-through gap in the brush from the top of the slope, looking for tracks or sign of what made it — wit… | Erzähler | open_run_level | Scout the creature's trail from a safe distance. | top of the timber trail above the vale | 90/96 | 14.1 s |
| 47 | I head back down the timber trail to the raft camp and find Corlin to report what I saw: a low, wide gap pushed through the brush at the val… | Erzähler | open_run_level | Report the found trail sign to Corlin before dark. | raft camp | 90/96 | 32.5 s |
| 48 | "Couldn't tell from the slope — too far to read the ground. If you want it fresh or not, someone has to stand close to that gap." | Erzähler | open_run_level | Answer Corlin's question honestly and offer a closer look if he wants it. | raft camp | 90/96 | 16.3 s |
| 49 | "I'll go in the morning and read that gap up close. Supper first, then I'll want my bed early." | Erzähler | open_run_level | Accept the morning scouting task and get supper and sleep before dawn. | raft camp | 90/96 | 27.0 s |
| 50 | I wake at first light and set out up the timber trail toward the vale, walking quietly with my staff in hand to read the gap up close. | Erzähler | open_run_level | Scout the gap in the vale's far corner at first light as agreed with Corlin. | the gap in the vale's far corner | 90/96 | 31.6 s |
| 51 | I back away from the gap the way I came, then return down the timber trail to the raft camp and find Corlin to report: fresh sledge traffic … | Erzähler | open_run_level | Report the fresh tracks and creaking wood to Corlin and claim the promised silver. | raft camp | 90/96 | 43.8 s |
| 52 | "Fresh sledge traffic both ways through the gap, tracks the length of my forearm — four toes, days old, not weeks. And I heard wood creak so… | Erzähler | open_run_level | Report the gap findings to Corlin and claim the promised silver. | raft camp | 90/96 | 46.5 s |
| 53 | "Then I'll stand your watch tonight, Doss. But the week's silver you agreed with Corlin is owed either way — I'll take it when he's back." | Erzähler | open_run_level | Accept the camp watch for the night and claim the agreed wage from Corlin when available. | raft camp | 90/96 | 141.8 s |
| 54 | "Quiet all night. The far slope went dead silent once, deep in the night, then started up again on its own — nothing came down. I'll take po… | Erzähler | open_run_level | Report the quiet watch to Doss and follow the second goal: scout behind Harn's timber at m… | raft camp | 90/96 | 38.7 s |
| 55 | I hand the cook two coppers for the bowl, eat the porridge, then set out at midday to walk beside the trail behind Harn's timber, keeping of… | Erzähler | open_run_level | Buy porridge, then scout the trail behind Harn's timber at midday as planned. | raft camp | 90/96 | 43.0 s |
| 56 | I stay still in the trees beside the trail and watch the wood pile quietly, keeping the ten paces between us, to see what moves beneath it. | Erzähler | open_run_level | Observe the unseen creature shifting the wood pile from a safe distance before deciding to… | raft camp | 90/96 | 30.1 s |
| 57 | I back away quietly down the trail the way I came, keeping off the lane, and return to the raft camp to tell Doss: the creaking is a huge gr… | Erzähler | open_run_level | Withdraw unseen from a bear far beyond my level and report the ramp discovery to Doss. | raft camp | 90/96 | 28.1 s |
| 58 | "I'll carry the word to Harn myself, then — nobody up the trail, I'll keep to the timber camp and tell him what I saw." | Erzähler | open_run_level | Report the bear and ramp to Harn at his timber camp. | loading flat behind Harn's timber | 90/96 | 21.4 s |
| 59 | "Harn — I've come from the raft camp with word you'll want quiet until we've talked. The creaking on your trail: I watched it. A grizzle-gra… | Erzähler | open_run_level | Report the bear and ramp discovery to Harn privately at the loading flat. | loading flat behind Harn's timber | 90/96 | 80.2 s |
| 60 | "Honest answer: I couldn't swear. It never moved, never showed a face — I'd know a person only if it moved like one. It sat like an animal w… | Erzähler | open_run_level | Answer Harn's question honestly about the pale thing at the top. | loading flat behind Harn's timber | 90/96 | 34.6 s |
| 61 | I nod to Harn. "I'll be at the raft camp when Corlin comes through tonight — the word will reach him exactly as I gave it here. Until then, … | Erzähler | open_run_level | Agree to Harn's plan and return to the raft camp to await Corlin and the evening decision. | loading flat behind Harn's timber | 90/96 | 116.3 s |
| 62 | "Pell — if it is a cub, that ramp's a road home. Either way, nobody's walking up it. What can you tell me about that outcrop — anyone ever b… | Erzähler | open_run_level | Learn more about the outcrop and the pale thing from Pell while waiting for Corlin tonight… | loading flat behind Harn's timber | 90/96 | 24.3 s |
| 63 | I keep to the camp and lend a hand with the wood and the pot until Corlin comes through at dusk — then I'll give him the report exactly as I… | Erzähler | open_run_level | Wait at the raft camp doing camp work until Corlin arrives tonight, then report to him. | loading flat behind Harn's timber | 90/96 | 126.7 s |
| 64 | "Then hear it whole. I walked the trail at midday like your rule says. Halfway up I heard creaking — a ramp of stacked logs, built piece by … | Erzähler | open_run_level | Give Corlin the full report of the ramp, the gray bear and the pale thing. | loading flat behind Harn's timber | 90/96 | 62.3 s |
| 65 | "Corlin — thirty years on this river, and Pell says you know every stone by its first name. The Bare Knuckle: anyone ever been up it? And th… | Erzähler | open_run_level | Ask Corlin about the outcrop's history and the pale thing at the top. | loading flat behind Harn's timber | 90/96 | 25.5 s |
| 66 | I'll bed down at the camp for the night, then at first light take my walk to the first bend and watch the hill quietly from there — no close… | Erzähler | open_run_level | Sleep at camp, then observe the hill from the first bend before first light, since the bui… | raft camp | 90/96 | 75.4 s |
| 67 | I walk up the trail to the first bend and watch the hill quietly from there, keeping to Corlin's rule — no closer. | Erzähler | open_run_level | Observe the Knuckle from the first bend at first light as agreed. | first bend on the hillside trail | 90/96 | 28.7 s |
| 68 | I keep watching quietly from the bend a while longer, noting anything that moves below the outcrop, then head back down to report to Corlin … | Erzähler | open_run_level | Observe a bit longer, then report the morning's sighting to Corlin and Doss at the ford. | raft camp | 90/96 | 26.5 s |
| 69 | I get something hot from the cook's pot, then settle in at the camp for the day and wait for Corlin to come back tonight so I can give him t… | Erzähler | open_run_level | Eat at the camp and wait for Corlin's return tonight to deliver the report. | raft camp | 90/96 | 164.2 s |
| 70 | "From the beginning, Corlin. Midday, the skiff run — the creak halfway up, logs seat-cut into the grade and stripped of bark, fresh work. Th… | Erzähler | open_run_level | Give Corlin the full word-for-word report, the gap especially. | raft camp | 90/96 | 212.3 s |
| 71 | "Send word downriver, Corlin. But I'd also put an eye on that gap close up come morning — knowing whether it means to climb down or only up … | Erzähler | open_run_level | Advise Corlin to send for a hunter, and commit to a close look at the gap in the morning. | raft camp | 90/96 | 58.2 s |
| 72 | I sleep at the camp and rise before the crew stirs, then walk up to the ramp's top and put a close eye on the gap of bare rock — counting wh… | Erzähler | open_run_level | Sleep, then make the promised close observation of the gap at first light. | top of the timber trail above the vale | 90/96 | 31.9 s |
| 73 | I back away from the gap without crossing the rock, then return down the trail and report to Corlin at the camp: fresh four-toed prints and … | Erzähler | open_run_level | Keep Corlin's rule, withdraw safely, and deliver the promised close-up report to Corlin. | raft camp | 90/96 | 66.6 s |
| 74 | "I'll stand watch at the camp tonight, Corlin — Doss's offer. After that, I'm for Blackwater Landing myself to see the hunter and tell the G… | Erzähler | open_run_level | Accept the paid watch at the camp and plan to move on to Blackwater Landing after, followi… | raft camp | 90/96 | 39.7 s |
| 75 | I take the loaf, sleep at the camp until morning, then set out along the river for Blackwater Landing. | Erzähler | open_run_level | Recover overnight, then travel to Blackwater Landing to find the hunter and the Guild post… | stuck cart at the marshy inlet | 90/96 | 34.5 s |
| 76 | I put my shoulder to the cart with her and lever the wheel out of the mud, then walk on toward Blackwater Landing. | Erzähler | open_run_level | Help the farmer free her cart, then continue to Blackwater Landing. | Guild post at Blackwater Landing | 90/96 | 68.7 s |
| 77 | I walk over to Vetch in the back and introduce myself: "Corlin at the timber camp sent word ahead about the Knuckle — I stood close watch on… | Erzähler | open_run_level | Approach Vetch and share what I saw at the Knuckle's gap. | Guild post at Blackwater Landing | 90/96 | 21.8 s |
| 78 | "It's waiting for something — a thing that careful with its weight isn't resting easy up there. What would you say it's after?" | Erzähler | open_run_level | Answer Vetch's question and keep the conversation going to learn more about the creature. | Guild post at Blackwater Landing | 90/96 | 21.4 s |
| 79 | "I'm in. Two pairs of eyes it is — I'll meet you at first light and we go up the north side together." | Erzähler | open_run_level | Accept Vetch's offer to investigate the overhang together at dawn. | Guild post at Blackwater Landing | 90/96 | 62.8 s |
| 80 | I look for a cheap bed for the night near the wharf, then sleep until first light. | Erzähler | open_run_level | Secure lodging, recover overnight, and be on time for the dawn meeting with Vetch. | Guild post at Blackwater Landing | 90/96 | 55.0 s |
| 81 | I take the corner cot for five copper and pay Osma, then sleep until first light. | Erzähler | open_run_level | Book the corner cot and recover overnight before the dawn meeting with Vetch. | Guild post at Blackwater Landing | 90/96 | 78.1 s |
| 82 | I climb into the corner cot and sleep until first light. | Erzähler | open_run_level | Recover overnight at the Slack Water before the dawn meeting with Vetch. | Guild post at Blackwater Landing | 90/96 | 28.3 s |
| 83 | I hurry to the south wharf pilings shed at the third raft and find Vetch, ready to head up the north side with him. | Erzähler | open_run_level | Make the dawn meeting with Vetch and start the overhang scout. | pilings shed at the third raft | 90/96 | 38.1 s |
| 84 | "I'm ready. What's in that bundle — you want me carrying anything?" | Erzähler | open_run_level | Join Vetch for the north-side scout and ask about the bundle. | pilings shed at the third raft | 90/96 | 35.1 s |
| 85 | "I've got bread and an egg — that'll do. Lead on, I'm right behind you." | Erzähler | open_run_level | Confirm I have food and set off with Vetch toward the north-side drag-marks. | pilings shed at the third raft | 90/96 | 110.1 s |
| 86 | I eat the egg as we walk, then light the head of my staff with a soft arcane glow to serve as Vetch's light on the scree. | Erzähler | open_run_level | Provide the light Vetch asked for and keep up on the scout. | pilings shed at the third raft | 90/96 | 25.6 s |
| 87 | I take the lantern and hold it low and left of the groove, following Vetch up the scree while keeping off the furrow itself. | Erzähler | open_run_level | Carry the lantern as Vetch directed and continue the scout up the drag-line. | overhang above the drag-line | 90/96 | 24.7 s |
| 88 | I steady the lantern and sweep its light slowly across the dust and the bones, staying back from the lip of rock. | Erzähler | open_run_level | Hold the light steady as Vetch asked and examine the lair from a safe distance. | overhang above the drag-line | 90/96 | 23.8 s |
| 89 | "Denning, not passing through — that's worse. I'm not fighting it up there. Vetch, what do you want to do with this — mark it for the ranger… | Erzähler | open_run_level | Report the lair findings and let Vetch decide the next move on the porch. | overhang above the drag-line | 90/96 | 18.5 s |
| 90 | "Mark and go down. I'll cut the three strokes and a hollow at the treeline if you show me how — I've got steady hands and a staff to lean on… | Erzähler | open_run_level | Help Vetch set the hunter's signs, then descend with him. | river landing by Harn's ferry | 90/96 | 112.8 s |
| 91 | "Glad to help, Vetch. I'll head back toward the landing — there was a cart stuck in the mud at the marshy inlet I said I'd see to. Good luck… | Erzähler | open_run_level | Part ways with Vetch and go help the woman with the stuck cart at the marshy inlet. | stuck cart at the marshy inlet | 90/96 | 27.5 s |
| 92 | "Push it is. I'll take the wheel on the high side while you lever — and if the plank alone won't do, I can loose a flame under the peat bloc… | Erzähler | open_run_level | Help the peat cutter free her stuck cart, offering muscle and magic as needed. | stuck cart at the marshy inlet | 90/96 | 22.9 s |
| 93 | "Gladly, Marest. I'll reload the blocks and lead the horse through the pool — and if that wheel keeps catching here, I'd wager a few stones … | Erzähler | open_run_level | Accept her paid offer: reload and lead the horse through the pool, and ask about the boggy… | stuck cart at the marshy inlet | 90/96 | 50.1 s |
| 94 | "Two coppers kept is two coppers earned, Marest. Which way are you bound now — is Blackwater Landing far? If you've room on the cart, I'd wa… | Erzähler | open_run_level | Ask Marest about riding along to Blackwater Landing as paid travel work. | stuck cart at the marshy inlet | 90/96 | 23.0 s |
| 95 | I hand the peat blocks down and help stack them, and tell Marest I'm obliged for the offer — I'm bound for Corlin with a letter first, but I… | Erzähler | open_run_level | Finish the unloading, thank Marest, and note the work offer without committing, keeping my… | stuck cart at the marshy inlet | 90/96 | 33.0 s |
| 96 | I find Eda's stilt house by the peat yard and ask if she has a corner or floor space to sleep for the night — I'll pay a copper or two, and … | Erzähler | open_run_level | Get lodging at Blackwater Landing for the night, then travel to Corlin at dawn. | Eda's stilt house | 90/96 | 24.8 s |
| 97 | "Two coppers with a meal in it suits me, Eda." I step inside and hand over the coins, thanking her for the hearth corner. | Erzähler | open_run_level | Pay for lodging and a meal at Eda's stilt house for the night. | Eda's stilt house | 90/96 | 31.0 s |
| 98 | I tuck the coins back in my purse and wait by the folded hide by the hearth for Eda to come back up from the water stair. | Erzähler | open_run_level | Pay Eda for lodging once she returns, then sleep until dawn. | Eda's stilt house | 90/96 | 152.4 s |
| 99 | "I'm off at first light myself, bound for Corlin — water for one is plenty. I'll take the hearth corner now and be gone before your rounds s… | Erzähler | open_run_level | Settle in for the night at Eda's, then leave for Corlin at dawn. | Eda's stilt house | 90/96 | 25.3 s |
| 100 | I thank Eda for the lodging, take a cup of the boiled water, and set off down the trail past Harn's timber toward the Corlin road. | Erzähler | open_run_level | Leave Eda's at morning and head for Corlin as planned. | Eda's stilt house | 90/96 | 19.3 s |
| 101 | I step onto the Corlin road and walk east toward the peat cart. | Erzähler | open_run_level | Leave the marsh behind and follow the Corlin road east, checking the unattended cart as I … | Eda's stilt house | 90/96 | 68.9 s |
| 102 | "Ride to Corlin suits me — what's the fare, and how far is it?" | Erzähler | open_run_level | Arrange a ride east toward Corlin with the peat woman. | Eda's stilt house | 90/96 | 59.0 s |
| 103 | I hand over the two coppers and climb up onto the peat load, minding the corner blocks. | Erzähler | open_run_level | Pay the 2 cp fare and ride the peat cart toward Corlin. | Eda's stilt house | 90/96 | 16.4 s |
| 104 | I climb down at the fork, thank her quietly, and head through the gate into Corlin to find the letter's recipient. | Erzähler | open_run_level | Arrive in Corlin and deliver the sealed letter to its addressee. | the chandlery by the Cornhill gate | 90/96 | 103.1 s |
| 105 | "I'm not buying today, Master Vey — I've a letter for you, from out Black Fen way." I hand him the sealed letter. | Erzähler | open_run_level | Deliver the sealed letter to Aldous Vey at the chandlery. | the chandlery by the Cornhill gate | 90/96 | 26.1 s |
| 106 | "The time's mine, Master Vey." I follow him into the back room and take the stool. | Erzähler | open_run_level | Sit for the cider while Vey counts out Dannel's promised pay. | the chandlery back room | 90/96 | 41.5 s |
| 107 | I take the eight silver and two copper from the bench and pocket them. "Night trouble on the fen — something big has been coming and going n… | Erzähler | open_run_level | Collect Dannel's promised pay and answer Vey's question honestly about the fen trouble. | the chandlery back room | 90/96 | 59.2 s |
| 108 | "Big as an ox, near enough — tracks like a man's but broader, and heavier than any dog. I never saw it clear; only heard it come and go and … | Erzähler | open_run_level | Answer Vey's question honestly and let him finish recounting the pay. | the chandlery back room | 90/96 | 128.6 s |
| 109 | "Folk at the Landing, you say. Who are they, and what would they pay to know?" | Erzähler | open_run_level | Ask Vey who at the Landing would pay for confirmation of the pale corpse and what the work… | the chandlery back room | 90/96 | 22.7 s |
| 110 | "Is there a cheap bed to be had in Corlin tonight, Master Vey? I'll want a fresh start at first light." | Erzähler | open_run_level | Get lodging in Corlin for the night, planning to return to the gap at first light to exami… | the chandlery back room | 90/96 | 89.8 s |
| 111 | "I'll take the fistful of six tallow dips, and I'll find the Wittles' room. Thank you, Master Vey." | Erzähler | open_run_level | Buy six tallow dips for 2 copper, then take the Wittles lodging for the night. | the Wittles' place | 90/96 | 20.0 s |
| 112 | "Wanting it, yes. Vey sent me." I pay the four coppers for the room. | Erzähler | open_run_level | Take the Wittles room for the night, then sleep until morning. | the Wittles' place | 90/96 | 23.0 s |
| 113 | "I'll be out at first light, Sera — leave the loaf by the door if you would." I settle into the room and sleep until morning. | Erzähler | open_run_level | Sleep at the Wittles' place until morning, then head to the gap at first light. | the Wittles' place | 90/96 | 38.8 s |
| 114 | I take the loaf and knife and set out from Corlin toward the gap in the rocks, to put an eye on the pale dead thing before the day warms. | Erzähler | open_run_level | Travel to the gap to examine the pale corpse Vey told me about. | the gap in the rocks | 90/96 | 33.2 s |
| 115 | I examine the pale carcass closely, careful not to touch it, and look at the tracks and gravel around it for any sign of what it was or wher… | Erzähler | open_run_level | Inspect the pale corpse and gather proof to sell the identification at the Landing. | the gap in the rocks | 90/96 | 119.1 s |
| 116 | I back toward the gap's mouth and cast Flame Lance at the pale thing as it turns. | Erzähler | open_run_level | Fight the waking pale creature from the gap mouth with Flame Lance. | the gap in the rocks | 90/80 | 48.8 s |
| 117 | I look into the deep passage beyond the gravel pocket for tracks or any sign of more of the pale things, keeping well back from its mouth. | Erzähler | open_run_level | Scout the deeper passage from a safe distance before deciding whether to press on or head … | the gap in the rocks | 90/80 | 22.3 s |
| 118 | I take the waxen egg from the cache and back out of the passage, then head for the Landing to sell the proof and the story to whoever pays f… | Erzähler | open_run_level | Take the pale egg as proof and leave before the parent returns, then travel to the Landing… | Blackwater Landing | 90/80 | 19.6 s |
| 119 | "The pale thing under the rocks at the gap is real, and I killed it — hound-sized, wax hide, needle teeth. Here's a fang, a strip of its ski… | Erzähler | open_run_level | Sell the identification, proof items and warning about the pale things to Corr at the Land… | Blackwater Landing | 90/80 | 47.1 s |
| 120 | "I'll take the seven silver for the lot — write it down as a fen-lurker, breeding site at the gap, bigger tracks still fresh. And I'll keep … | Erzähler | open_run_level | Accept Corr's offer of seven silver for tooth, hide and egg with a written description. | Blackwater Landing | 90/80 | 69.4 s |
| 121 | "Then six silver the lot — done. Write it in the ledger as you said: fen-lurker, breeding site at the gap, bigger tracks fresh." | Erzähler | open_run_level | Accept Corr's revised six-silver offer for tooth, hide and egg. | Blackwater Landing | 90/80 | 82.0 s |
| 122 | "Tooth at two silver — yes." | Erzähler | open_run_level | Agree to Corr's item-by-item price for the tooth, then continue with hide and egg. | Blackwater Landing | 90/80 | 17.6 s |
| 123 | "One silver eight — yes, done." | – | open_run_level | Accept Corr's offer for the hide strip and complete the sale. | Blackwater Landing | 90/80 | 43.6 s **no reply after the message** |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zum Start (notiert vor Zug 1): Character creation opened at step 1/2 outside Ashbridge; choosing Mage to get INT/WIL favored stats.
- zu Zug 1 (notiert vor Zug 2): Step 2/2 shows stats already boosted (STR/VIT/AGI/PER all 7 despite Mage only favoring INT/WIL) — odd, but INT 8 / WIL 8 confirmed. Starter gear equips automatically on completion.
- zu Zug 2 (notiert vor Zug 3): Creation complete: Level 1 Mage with Arcane Bolt and Flame Lance, 5 silver, starter gear equipped. Non-favored stats got +2 oddly, but System-confirmed.
- zu Zug 3 (notiert vor Zug 4): Creation confirmed complete; arrived at Ashbridge gate queue, guard engaging arrivals one by one.
- zu Zug 4 (notiert vor Zug 5): Entered Ashbridge without issue; narration offers several shops, an inn, and a side-lane crowd with an angry voice.
- zu Zug 5 (notiert vor Zug 6): Carter and woman identify the commotion as the Welkins' shop on Goldsmith's Row, a family money dispute — no fire or crime scene; proceeding cautiously as an observer.
- zu Zug 6 (notiert vor Zug 7): Scene confirms the dispute: Dannel owes 60 crowns from a failed venture at Corlin's Ford; he may walk off. I have no money to lend, so I offer road knowledge instead as an opening.
- zu Zug 7 (notiert vor Zug 8): Dannel engaged directly and is eager for firsthand news of the ford; possible paid opportunity or travel hook upriver.
- zu Zug 8 (notiert vor Zug 9): Dannel can pay only a silver or two; the real hook may be work at the timber landing itself. Welkins invited us into his back room to hear it together.
- zu Zug 9 (notiert vor Zug 10): Opportunity confirmed: paid guard work at Corlin's Ford with a letter to Corlin; no quest panel entry yet, so I'll verify activation before relying on it.
- zu Zug 10 (notiert vor Zug 11): Letter to Corlin confirmed in inventory; no quest panel entry despite the promised job, so I proceed on the letter itself rather than assuming quest activation.
- zu Zug 11 (notiert vor Zug 12): Reached Corlin's Ford; pilings confirmed standing. A grey-bearded workman (likely Corlin) is present and asking about the letter; no quest panel entry yet.
- zu Zug 12 (notiert vor Zug 13): Harn confirmed the pilings stand and the job exists, but Corlin (who pays) is at a raft camp two hours upstream; no quest panel entry yet.
- zu Zug 13 (notiert vor Zug 14): HUD still shows location as Corlin's Ford though narration placed me at the raft camp; minor labeling oddity. Quests panel still empty despite the promised guard job.
- zu Zug 14 (notiert vor Zug 15): Met Corlin at the raft camp; he's mid wage-dispute with raftmen over landing tolls. Quests panel still empty.
- zu Zug 15 (notiert vor Zug 16): Corlin read Welkins' letter and offered the guard job: a silver a week plus cook's pot, week to week. Still no quest panel entry; will verify once he confirms.
- zu Zug 16 (notiert vor Zug 17): Corlin confirmed the guard job verbally (a silver a week plus cook's pot, week to week), but the Quests panel is still empty and the HUD still lists only the letter in inventory.
- zu Zug 17 (notiert vor Zug 18): Guard job confirmed verbally but still no quest panel entry; search of the yard by daylight found nothing (PER check failed).
- zu Zug 18 (notiert vor Zug 19): Engine demanded an explicit sleep duration; rest action otherwise proceeding normally. XP still 0/100 and no quest entry despite confirmed paid guard work.
- zu Zug 20 (notiert vor Zug 21): Night watch passed uneventfully; no XP or quest entry yet despite the confirmed paid work. HP/MP/STA full, still Level 1, 5 silver.
- zu Zug 21 (notiert vor Zug 22): Corlin asked my name a second time despite turn 16 — an engine repetition quirk. Guard work still shows no quest entry or XP; day 2, 06:15, 5 silver.
- zu Zug 22 (notiert vor Zug 23): Corlin re-confirmed the pay (a silver the week plus pot) and the midday trail walk is now an explicit goal. Still no quest panel entry or XP despite two days of confirmed work.
- zu Zug 23 (notiert vor Zug 24): The trail's user is confirmed as a large clawed beast, not a deer; first real discovery from the trail scouting.
- zu Zug 24 (notiert vor Zug 25): Combat scene opened: Scarred Ridge-Backed Boar, HP 59, MEDIUM — far beyond L1 capability, so withdrawing per the avoid-overpowering rule.
- zu Zug 25 (notiert vor Zug 26): Clean withdrawal succeeded; boar (HP 59, MEDIUM) avoided without detection. Still XP 0 and no quest entry despite two days of paid work — worth watching.
- zu Zug 26 (notiert vor Zug 27): Scouting report delivered; Corlin confirmed he can't spare men to hunt it and asks me to decide. XP still 0 and no quest entry despite two days of paid work — pay collection is the test now.
- zu Zug 27 (notiert vor Zug 28): Corlin handed over the week's silver and the HUD confirms no combat, but the HUD still shows 5 Silver — checking whether the payment was recorded.
- zu Zug 28 (notiert vor Zug 29): Contradiction: Corlin handed over the week's silver on screen, but #bag still shows 5 Silver — the payment was not recorded. XP remains 0 and no quest entry despite two days of paid work.
- zu Zug 29 (notiert vor Zug 30): Night watch completed without incident; beast heard but stayed on the far slope. Coin contradiction persists: Corlin pressed a silver on screen twice, but #bag and HUD still show 5 Silver. XP still 0, no quest entry. A sealed letter to Corlin sits in my bag undelivered — delivering it now.
- zu Zug 30 (notiert vor Zug 31): Corlin is away downriver at the Ford over toll disputes; letter delivery must wait until he returns. XP still 0 after three days of paid work — leveling through work alone seems not to register.
- zu Zug 31 (notiert vor Zug 32): The trail behind Harn's timber leads to a loading flat with days-old broad-pawed prints (smaller stride than the hollow boar) and a body-sized flattened patch — a second unknown creature visits this spot. XP still 0 on Day 3.
- zu Zug 32 (notiert vor Zug 33): Search of the flat failed (PER check) and yielded nothing new; HUD still shows 0 XP and 5 Silver despite days of paid work.
- zu Zug 33 (notiert vor Zug 34): The trail led to the cat's lay and a live encounter: Tawny Cat A, HP 42, marked as a threat, watching from the shade. A large cat outmatches a Level 1 mage, so I withdraw rather than force the fight.
- zu Zug 34 (notiert vor Zug 35): Clean withdrawal from the tawny cat; it never pursued. XP still 0 and 5 Silver despite three days' work — leveling and pay remain unrecorded.
- zu Zug 35 (notiert vor Zug 36): Corlin is finally present at the raft camp; HUD confirms letter still in inventory. XP and coin remain unrecorded after three days of work.
- zu Zug 36 (notiert vor Zug 37): Corlin vanished between two narration beats: present at the near raft, then gone with footprints into the river and no return — engine refused the hand-off. Still no XP or pay recorded after three days' work.
- zu Zug 37 (notiert vor Zug 38): PER search succeeded and confirmed Corlin pushed off downstream; still no way to hand off the letter while he is absent — third delivery attempt pending.
- zu Zug 38 (notiert vor Zug 39): Corlin met a heavier man at a gravel spit and left with him upriver to a hidden raft frame; the letter hand-off is still impossible. XP and coin remain at 0/5 despite days of work.
- zu Zug 39 (notiert vor Zug 40): Found Corlin at a second camp with an armed bearded stranger; the bearded man just went into the tent, leaving Corlin briefly alone — fourth delivery attempt.
- zu Zug 40 (notiert vor Zug 41): Letter hand-off narratively completed (Corlin broke the seal and read it twice), yet the HUD still lists the letter in inventory — will verify with #bag. XP and coin still 0 XP / 5 Silver after three days.
- zu Zug 41 (notiert vor Zug 42): HUD still lists the sealed letter in inventory despite Corlin taking and reading it; wage agreed at a silver a week plus courier favor, Corlin about to reveal why the rafts are hidden.
- zu Zug 42 (notiert vor Zug 43): Wage confirmed at a silver a week plus courier favor; HUD oddly still lists the sealed letter in inventory despite Corlin reading it. Night creature in the east bank cut is a potential fight/quest lead.
- zu Zug 43 (notiert vor Zug 44): Wage and duties confirmed: watch, report, no bounty, no heroics. HUD still lists the sealed letter despite Corlin reading it; checking bag.
- zu Zug 44 (notiert vor Zug 45): Narrator says the letter is gone from the pouch, but the HUD still lists 'Sealed letter to Corlin' in Carried — a persistent HUD contradiction worth noting. Wage is a silver a week; first night watch is tonight.
- zu Zug 45 (notiert vor Zug 46): Bag check narratively cleared (no letter), yet the HUD still lists 'Sealed letter to Corlin' — persistent HUD contradiction. Trail walk found a large pushed-through gap leading toward darker trees.
- zu Zug 46 (notiert vor Zug 47): Search roll failed (d100 100) so no track details gained; only the gap's location and direction confirmed. HUD still lists the sealed letter despite the bag check showing it gone.
- zu Zug 47 (notiert vor Zug 48): Corlin suspects the gap was made to be used, not cut by Harn's men. HUD still lists the sealed letter; persistent contradiction.
- zu Zug 48 (notiert vor Zug 49): Corlin offered a silver for a close-up look at the gap at first light; accepted. HUD still lists the sealed letter — persistent contradiction continues.
- zu Zug 49 (notiert vor Zug 50): Slept at the camp as planned; HUD still lists the sealed letter to Corlin despite narrative removal — persistent contradiction continues.
- zu Zug 50 (notiert vor Zug 51): Gap read close up: fresh heavy sledge lane plus forearm-length four-toed prints only days old, and wood creaked down the lane — a live lead. HUD time shows Day 3 evening despite narration of a night's sleep and morning walk.
- zu Zug 51 (notiert vor Zug 52): HUD says 'Present: nobody besides Alaric' and Day 3, 20:35 evening while the narrator shows Corlin at the raft in morning — location/time contradiction. Sealed letter to Corlin still listed in Carried despite narrative removal.
- zu Zug 52 (notiert vor Zug 53): Time contradiction persists: HUD says Day 3, 20:40 evening while narration plays a morning after the dawn scout; Doss present instead of Corlin. Sealed letter to Corlin still listed in inventory.
- zu Zug 53 (notiert vor Zug 54): Watch passed uneventfully; Day 4 morning now, Doss present and Corlin away at the Ford for a couple of days. HUD goals now list the midday trail walk behind Harn's timber.
- zu Zug 54 (notiert vor Zug 55): HUD shows 5 Silver and no coppers line — paying 2 cp may need coin conversion; watch whether the payment records. Sealed letter to Corlin still listed in Carried despite narrative removal.
- zu Zug 55 (notiert vor Zug 56): Porridge purchase recorded cleanly (50→48 copper; HUD now 4s8c). Found a man-tall heap of cut wood in a hollow behind Harn's timber with something alive shifting beneath it — creature not yet seen.
- zu Zug 56 (notiert vor Zug 57): Grizzle-Gray Bear A: 76 HP at SHORT range — far beyond a Level 1 mage, so withdrawing is the sensible call. HUD still lists location 'raft camp' with Doss and Cook present while I stand behind Harn's timber; minor location contradiction.
- zu Zug 57 (notiert vor Zug 58): Narrator again shows morning (Day 4, 10:30) while my porridge was eaten at midday; minor time drift. Bear still listed as SHORT on HUD despite my retreat — noted as likely stale panel.
- zu Zug 58 (notiert vor Zug 59): Bear confirmed as a ramp-builder using Harn's logs; something small and pale sits at the outcrop top. HUD shows Camp Man B as present rather than Harn by name — watching whether the slate man is Harn or Harn arrives separately.
- zu Zug 59 (notiert vor Zug 60): Harn confirmed present and heard the full report; decision on the bear deferred until Corlin returns tonight. HUD still lists 'Camp Man B' rather than Harn by name.
- zu Zug 60 (notiert vor Zug 61): Harn has given Alaric a say in the bear decision after Corlin hears the report tonight; camp hands sworn to silence. No System changes to quests or coin.
- zu Zug 61 (notiert vor Zug 62): Back at raft camp with Pell as company; decision deferred until Corlin arrives tonight. HUD location still reads 'loading flat' though narration has us at the raft camp — minor drift.
- zu Zug 62 (notiert vor Zug 63): HUD still shows location as loading flat though we walked back to the raft camp; also lists Pell under the same npc id as the badhand youth. Old goal about 'go out in the morning' lingers in HUD despite that errand being done.
- zu Zug 63 (notiert vor Zug 64): Corlin arrived at dusk as promised; HUD still mislabels the location as loading flat and shows Pell under the badhand npc id. XP still 0/100 despite days of work — no rewards from camp labor yet.
- zu Zug 64 (notiert vor Zug 65): Corlin has judged the ramp-builder as having hands, restricted the watch to the first bend, and revealed the creature works before first light. XP still 0/100 despite days of camp work.
- zu Zug 65 (notiert vor Zug 66): Corlin confirmed no one has climbed the Knuckle in 30 years and judged the pale thing as neither goat, egg, nor person; his rule is to leave still watchers alone. XP still 0/100 after days of work — no mechanical reward yet from camp employment.
- zu Zug 66 (notiert vor Zug 67): Narration moved me to the raft camp overnight; HUD now agrees (Duskreach — raft camp, Day 5 06:00). XP still 0/100 despite days of work and a near-bear encounter.
- zu Zug 67 (notiert vor Zug 68): First-bend watch confirmed: the pale thing is hound-sized, curled and motionless; the ramp stops ten body-lengths short of the crown, work unfinished. XP still 0/100.
- zu Zug 68 (notiert vor Zug 69): Watch at the bend failed its PER roll and gave nothing new; Doss confirmed Corlin returns tonight. XP still 0/100 despite days of paid work and scouting — engine seems not to award XP for non-combat tasks.
- zu Zug 69 (notiert vor Zug 70): XP still 0/100 at Day 5 night despite days of paid work and scouting; new goal listed: put an eye on the gap close up in the morning.
- zu Zug 70 (notiert vor Zug 71): Corlin has closed the trail and treats the timber as written off; he's now asking Alaric for a judgment call. XP still 0/100 at Day 5 night despite days of paid scouting work.
- zu Zug 71 (notiert vor Zug 72): Corlin sealed a notice for the Guild post at Blackwater Landing; hunter may arrive within days. XP still 0/100 despite days of paid work.
- zu Zug 72 (notiert vor Zug 73): Close observation succeeded: fresh four-toed prints and drag-marks at the gap's mouth, and a rhythmic dragging-and-settling sound behind the outcrop — the worker is active now. XP still 0/100 at Day 6 despite days of paid work.
- zu Zug 73 (notiert vor Zug 74): XP still 0/100 at Day 6 despite a week of scouting and paid work — engine XP seems tied to combat only. The letter to Blackwater Landing gives a natural next destination.
- zu Zug 74 (notiert vor Zug 75): Watch passed uneventfully; Doss relieved me with bread and orders to leave for the Landing at dawn. XP still 0/100 after a week of work — engine XP appears combat-only.
- zu Zug 75 (notiert vor Zug 76): Still 0/100 XP at Day 7 despite a week of paid work; XP appears combat-tied. Helping the farmer may open a paid or goodwill lead at the Landing.
- zu Zug 76 (notiert vor Zug 77): Reached Blackwater Landing; Vetch is present at the Guild post, so the hunter lead is directly at hand. XP still 0/100, confirming combat-tied progression.
- zu Zug 77 (notiert vor Zug 78): Vetch confirms matching four-toed tracks and the dragging sound on the Knuckle's north side; no scat or scent-marks anywhere. He asks my read: is it settled up there or waiting?
- zu Zug 78 (notiert vor Zug 79): Vetch's offer to scout the north-side overhang together is the natural next step; the pale shape lead suggests the creature may be encountered — will need to weigh fight vs. withdraw given only 0 XP combat record.
- zu Zug 79 (notiert vor Zug 80): Evening at Blackwater Landing; meeting set for first light at the south wharf pilings shed. XP still 0/100, combat-tied.
- zu Zug 80 (notiert vor Zug 81): Lodging offered at the Slack Water: bunk 2c, corner cot 5c; must pay before sleeping.
- zu Zug 81 (notiert vor Zug 82): Payment was accepted and the room is mine; the previous refusals seem to have been a booking-activity parsing quirk, retrying sleep as a single action.
- zu Zug 82 (notiert vor Zug 83): Slept fine (nothing to recover); note the HUD oddity: location shows Guild post and Mara ENGAGED while narration puts me at the Slack Water at dawn — treating narration's first light as current and heading to the meeting.
- zu Zug 83 (notiert vor Zug 84): Met Vetch at the shed on time; he holds an oilcloth bundle not yet offered. HUD location now matches narration.
- zu Zug 84 (notiert vor Zug 85): HUD confirms I already carry a loaf and an egg, so no detour needed; dew-timing pressure means we should move now.
- zu Zug 85 (notiert vor Zug 86): Reached the Knuckle's scree; fresh four-toed prints and a drag groove confirm something hauling food up the rock. Vetch now wants my staff-light.
- zu Zug 86 (notiert vor Zug 87): Arcane glow attempt failed cleanly — I don't know that skill; Vetch supplied a shuttered lantern instead, now in my inventory. HUD location still shows the pilings shed while we're at the Knuckle scree.
- zu Zug 87 (notiert vor Zug 88): HUD location finally matches narration (overhang above the drag-line); lair appears empty but occupied recently.
- zu Zug 88 (notiert vor Zug 89): Search confirmed: creature dens here intermittently, exits over the top, human remains (Erswald the tinker, missing two years). Fresh prints days old — real threat; will avoid following it home.
- zu Zug 89 (notiert vor Zug 90): Vetch chose marking over tracking; Erswald's remains identified. Helping with the marks is free, safe progression before deciding next steps.
- zu Zug 90 (notiert vor Zug 91): Marking task completed cleanly; Vetch offered future work if the Guild pursues the denner. HUD still shows morning 11:30 despite narration of afternoon light — minor time contradiction. Open lead: cart-wheel promise at the marshy inlet.
- zu Zug 91 (notiert vor Zug 92): HUD location now matches narration (marshy inlet); Peat Cutter is a present SHORT NPC with a promise lead, plus Bay Horse A. Time shows 12:35, still lagging narration slightly.
- zu Zug 92 (notiert vor Zug 93): Cart freed; Marest offers copper for reload and horse-leading help. She's running her sister's peat rounds to Blackwater Landing — a possible paid-work and travel lead toward a new settlement.
- zu Zug 93 (notiert vor Zug 94): Paid +2 copper for the crossing work; Marest confirmed as a recurring peat-round worker heading to Blackwater Landing — a natural travel and work lead. XP still 0/100 despite two days of real work.
- zu Zug 94 (notiert vor Zug 95): Arrived at Blackwater Landing with Marest; she floated steady part-time work for Eda's rounds. HUD still shows location as the marshy inlet though we reached the landing.
- zu Zug 95 (notiert vor Zug 96): HUD still shows location as the marshy inlet with nobody present despite reaching Blackwater Landing; XP sits at 0/100 after hours of paid work and travel — no XP from non-combat effort so far.
- zu Zug 96 (notiert vor Zug 97): HUD location now shows Duskreach — Eda's stilt house though narration calls it Blackwater Landing; naming mismatch worth noting.
- zu Zug 97 (notiert vor Zug 98): Pay was refused because Eda stepped out to the water stair; coins not paid yet. HUD naming mismatch persists: HUD says Duskreach while narration calls it Blackwater Landing.
- zu Zug 98 (notiert vor Zug 99): Pay to Eda finally accepted (2 copper). Still at Level 1 with XP 0/100 after two days of paid work — combat or discovery may be needed for progress; Corlin letter delivery is the next lead.
- zu Zug 99 (notiert vor Zug 100): Slept through first light; recovery confirmed full but still Level 1 with XP 0/100 after nine days — XP seems to come only from combat or discovery, not paid work.
- zu Zug 100 (notiert vor Zug 101): Narration has me well clear of Eda's and on the Corlin road, but HUD still shows location as Eda's stilt house at 09:15 — naming/location lag persists. Still Level 1, XP 0/100 after nine days.
- zu Zug 101 (notiert vor Zug 102): Villager at the cart offers a ride for a fare; HUD still lags at Eda's stilt house. Still Level 1, XP 0/100.
- zu Zug 102 (notiert vor Zug 103): Ride offered at 2 cp, half-day to Corlin, dropped before the yards; still Level 1 with XP 0/100, HUD location lag persists.
- zu Zug 103 (notiert vor Zug 104): Ride completed and paid; narration places me at Corlin's edge while HUD still shows Eda's stilt house — location lag persists. Still Level 1, XP 0/100.
- zu Zug 104 (notiert vor Zug 105): Arrived at the chandlery; HUD location now correctly shows Corlin. Still Level 1, XP 0/100.
- zu Zug 105 (notiert vor Zug 106): Delivery succeeded; Vey confirms Dannel's letter promises pay for the weeks of yard watch, to be counted in the back room. Still Level 1, XP 0/100.
- zu Zug 106 (notiert vor Zug 107): HUD still shows 4 Silver 8 Copper — the counted pay (8s 2cp) is not yet recorded; will verify it lands before relying on it.
- zu Zug 107 (notiert vor Zug 108): Vey held the coins back to check for clipped silver before handing them over; HUD still shows 4 Silver 8 Copper, so pay is not yet recorded.
- zu Zug 108 (notiert vor Zug 109): Pay finally recorded: HUD now 1 Gold 3 Silver. Vey points to interested buyers at the Landing for the pale corpse at the gap — a possible paid lead.
- zu Zug 109 (notiert vor Zug 110): Vey names two Landing buyers: Corr, a Guild man at the wharf tavern, and the factor house, which prices only carcasses it can name — so identifying the pale thing is the commodity. Still L1, XP 0/100 after nine days of mostly non-combat work.
- zu Zug 110 (notiert vor Zug 111): Vey offers candles and lodging options; buying dips and taking the paid room before sleeping until morning.
- zu Zug 111 (notiert vor Zug 112): Purchase of tallow dips recorded; coin 1g 2s 8cp. Lodging offered at 4 cp — paying now.
- zu Zug 112 (notiert vor Zug 113): Lodging paid and recorded (coin 1g 2s 4cp); asking her to leave the loaf by the door before sleeping.
- zu Zug 113 (notiert vor Zug 114): Slept well; HP/MP/STA full, fresh loaf provided. Setting out at first light to inspect the pale corpse at the gap.
- zu Zug 114 (notiert vor Zug 115): The corpse is unlike any local animal: needle-crowded teeth, waxy hide, and untouched by scavengers or flies, suggesting something unnatural. The passage continues deeper into the rock spine.
- zu Zug 115 (notiert vor Zug 116): The 'corpse' was alive and day-old blood on it isn't its own; it woke when I pried a tooth (which I now hold as proof). Hound-sized, so I judge it fightable at Level 1.
- zu Zug 116 (notiert vor Zug 117): One-shot the pale thing with Flame Lance (44 damage, first strike) — the waxy hide burned like fat. 48 XP earned, plus loot: skin and two fangs. Passage continues deeper; prints suggest more of these creatures may exist.
- zu Zug 117 (notiert vor Zug 118): Found a warm waxy egg in a cache ten feet past the carcass, with large fresh prints of a much bigger pale thing walking in and out of the dark at the crook — a real threat I will avoid by leaving now.
- zu Zug 118 (notiert vor Zug 119): Arrived at Blackwater Landing with the egg, fangs and skin; Corr invites me to sell the story. Note: I left a dead pale thing's egg while bigger tracks remain in the passage — a lead worth mentioning.
- zu Zug 119 (notiert vor Zug 120): Corr offered 6 silver for tooth+hide plus 1 for the egg, or suggested selling the warning separately at Molland's factor house. I'm selling the lot to Corr; may still try Molland's for the story/warning value.
- zu Zug 120 (notiert vor Zug 121): The engine refused my 'seven silver' acceptance because the agreed price mismatched the actual offer; Corr revised to six (2 tooth + 3 hide + 1 egg).
- zu Zug 121 (notiert vor Zug 122): Engine enforces per-item price matching; the engine's shop panel now lists tooth 20 cp, hide 10 cp, egg 10 cp, far below Corr's spoken prices — a narration/System mismatch to watch when the sale resolves.
- zu Zug 122 (notiert vor Zug 123): Contradiction: my tooth 'sale' was processed as a PURCHASE — coin dropped 124→104 copper instead of rising. The engine seems to enforce its shop prices (10 cp items), not Corr's spoken silver prices.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t115 | 116 | 1 | – | nein | 1 | gewonnen, 48 XP |

## Quests

Keine angenommen.


## Auffälligkeiten

- Zug 123 (Runner/UI): no reply after the message
- Zug 6, Nachricht 12 (extraction_repaired): the extractor's first answer needed a repair
- Zug 26, Nachricht 51 (planner_repaired): the planner's first answer needed a repair
- Zug 26, Nachricht 51 (finish): plan ended with finish_reason "length"
- Zug 29, Nachricht 57 (planner_repaired): the planner's first answer needed a repair
- Zug 29, Nachricht 58 (extraction_repaired): the extractor's first answer needed a repair
- Zug 31, Nachricht 62 (extraction_repaired): the extractor's first answer needed a repair
- Zug 35, Nachricht 70 (extraction_repaired): the extractor's first answer needed a repair
- Zug 38, Nachricht 76 (extraction_repaired): the extractor's first answer needed a repair
- Zug 39, Nachricht 78 (extraction_repaired): the extractor's first answer needed a repair
- Zug 40, Nachricht 80 (extraction_repaired): the extractor's first answer needed a repair
- Zug 45, Nachricht 90 (extraction_repaired): the extractor's first answer needed a repair
- Zug 52, Nachricht 103 (planner_repaired): the planner's first answer needed a repair
- Zug 52, Nachricht 103 (finish): plan ended with finish_reason "length"
- Zug 54, Nachricht 108 (extraction_repaired): the extractor's first answer needed a repair
- Zug 57, Nachricht 114 (extraction_repaired): the extractor's first answer needed a repair
- Zug 61, Nachricht 122 (extraction_repaired): the extractor's first answer needed a repair
- Zug 63, Nachricht 125 (planner_repaired): the planner's first answer needed a repair
- Zug 64, Nachricht 128 (extraction_repaired): the extractor's first answer needed a repair
- Zug 66, Nachricht 132 (extraction_repaired): the extractor's first answer needed a repair
- Zug 66, Nachricht 132 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 66, Nachricht 132 (finish): extract ended with finish_reason "length"
- Zug 68, Nachricht 136 (extraction_repaired): the extractor's first answer needed a repair
- Zug 69, Nachricht 138 (extraction_repaired): the extractor's first answer needed a repair
- Zug 69, Nachricht 138 (extractor_recovery): the extractor required transport recovery (status applied)
- Zug 73, Nachricht 145 (planner_repaired): the planner's first answer needed a repair
- Zug 73, Nachricht 145 (finish): plan ended with finish_reason "length"
- Zug 75, Nachricht 150 (extraction_repaired): the extractor's first answer needed a repair
- Zug 76, Nachricht 152 (extraction_repaired): the extractor's first answer needed a repair
- Zug 79, Nachricht 158 (extraction_repaired): the extractor's first answer needed a repair
- Zug 79, Nachricht 158 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 79, Nachricht 158 (finish): extract ended with finish_reason "length"
- Zug 81, Nachricht 162 (extraction_repaired): the extractor's first answer needed a repair
- Zug 81, Nachricht 162 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 81, Nachricht 162 (finish): extract ended with finish_reason "length"
- Zug 90, Nachricht 180 (extraction_repaired): the extractor's first answer needed a repair
- Zug 90, Nachricht 180 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 90, Nachricht 180 (finish): extract_repair ended with finish_reason "length"
- Zug 90, Nachricht 180 (finish): extract_repair ended with finish_reason "length"
- Zug 91, Nachricht 182 (extraction_repaired): the extractor's first answer needed a repair
- Zug 94, Nachricht 188 (extraction_repaired): the extractor's first answer needed a repair
- Zug 97, Nachricht 193 (planner_repaired): the planner's first answer needed a repair
- Zug 101, Nachricht 202 (extraction_repaired): the extractor's first answer needed a repair
- Zug 101, Nachricht 202 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 101, Nachricht 202 (finish): extract ended with finish_reason "length"
- Zug 102, Nachricht 204 (extraction_repaired): the extractor's first answer needed a repair
- Zug 102, Nachricht 204 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 102, Nachricht 204 (finish): extract ended with finish_reason "length"
- Zug 104, Nachricht 208 (extraction_repaired): the extractor's first answer needed a repair
- Zug 107, Nachricht 214 (extraction_repaired): the extractor's first answer needed a repair
- Zug 108, Nachricht 216 (extraction_repaired): the extractor's first answer needed a repair
- Zug 108, Nachricht 216 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 108, Nachricht 216 (finish): extract ended with finish_reason "length"
- Zug 110, Nachricht 220 (extraction_repaired): the extractor's first answer needed a repair
- Zug 110, Nachricht 220 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 110, Nachricht 220 (finish): extract ended with finish_reason "length"
- Zug 116, Nachricht 231 (planner_repaired): the planner's first answer needed a repair
- Zug 116, Nachricht 231 (finish): plan ended with finish_reason "length"
- Zug 120, Nachricht 240 (extraction_repaired): the extractor's first answer needed a repair
- Zug 120, Nachricht 240 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 120, Nachricht 240 (finish): extract ended with finish_reason "length"
- Zug 121, Nachricht 242 (extraction_repaired): the extractor's first answer needed a repair
- Zug 121, Nachricht 242 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 121, Nachricht 242 (finish): extract ended with finish_reason "length"
- Zug 123, Nachricht 245 (planner_failed): the planner failed: commands[0] (offer.accept): party_words must copy the counterparty from the player message; commands[0] (offer.accept): agreed_cp contradicts the player’s stated price; clarify instead of substituting
- Zug 123, Nachricht 245 (planner_repaired): the planner's first answer needed a repair
- Zug 123, Nachricht 245 (finish): plan ended with finish_reason "length"
- Hinweis (error): Avereth Engine: planner failed (commands[0] (offer.accept): party_words must copy the counterparty from the player message; commands[0] (offer.accept): agreed_cp contradicts the player’s stated price; clarify instead of substituting). Regenerate or send the message again; no story turn was generated…
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 29× keine gültige JSON-Entscheidung (Züge 11, 17, 18, 20, 21, 24, 33, 34, 43, 48, 50, 58, 60, 63, 64, 65, 67, 68, 73, 75, 76, 80, 82, 84, 85, 97, 101, 105, 113)
- Server: Generation failed AbortError: The operation was aborted.
- 16 Aufruf(e) mit finish_reason "length" (Nr. 71 plan, Nr. 155 plan, Nr. 205 extract, Nr. 228 plan, Nr. 251 extract, Nr. 258 extract, Nr. 287 extract, Nr. 288 extract, Nr. 324 extract, Nr. 328 extract, Nr. 349 extract, Nr. 356 extract, Nr. 374 plan, Nr. 389 extract, Nr. 393 extract, Nr. 398 plan)

System-Panels: CLARIFY 0, NOT TAKEN 1, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: ambient 9, no_go 12, scene_context 52, pc_inventory 4, work_not_purchase 1, pc_decision 1, npc_continuity 68, time_cap 4, world_rule 2, npc_presence 1, offer 2, object 1, engine_owned_fact 1, coin_already_received 1, engine_booked 1, engine_owned_combat 1, guild_payout 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 10, Transport 1, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 128 | 8 | 3.1 s | 10.6 s | 11311 | 9743 | 108 | – | stop 123, length 5 | 5 |
| narrator | 119 | 0 | 11.0 s | 40.7 s | 11367 | 8773 | 509 | – | stop 119 | 0 |
| extract | 152 | 23 | 7.7 s | 27.9 s | 11507 | 9135 | 521 | – | stop 140, length 11 | 11 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 105:53 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 15.3 s) | 0:29 min |
| 123 Züge, Spiel (Senden bis HUD nach der Extraktion) | 91:35 min — Median 30.4 s, p90 94.0 s, max 212.3 s |
| 123 Züge, Spieler-Entscheidung | 11:33 min — Median 3.7 s, 29 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 10:34 min / 0:00 min / 42:09 min / 33:52 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 50.3 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 33:33 min, 80 Züge ≈ 67:05 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spieler | 22 | – | 35.0 s | 3.7 s |
| Spiel | 70 | – | 212.3 s | 30.4 s |
| Spiel | 69 | – | 164.2 s | 30.4 s |
| Spiel | 98 | – | 152.4 s | 30.4 s |
| Provider narrator | 70 | 220 | 178.5 s | 11.0 s |
| Provider narrator | 98 | 314 | 133.7 s | 11.0 s |
| Provider narrator | 53 | 160 | 130.5 s | 11.0 s |
| Provider extract | 108 | 349 | 63.0 s | 7.7 s |
| Provider extract | 81 | 258 | 55.0 s | 7.7 s |
| Provider extract | 101 | 324 | 50.3 s | 7.7 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
