# Avereth Live-Test 20261027-134010Z-current_test

## Kurzfassung

- **Laufprofil:** explore-rogue; Startklasse Rogue, Schwerpunkt explore. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** abgebrochen: Fehler im Runner — interrupted (Ctrl+C) in turn 22
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 1. Sicherheitsgrenzen: 150 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** noch nicht erreicht.
- **Charakter:** rogue (rogue.razor_cut, rogue.evasive_step) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: cautious adventurer: prepare and recover, weigh threats and withdraw when sensible
- **Züge:** 22 · **Dauer:** 16:03 min · **LLM-Aufrufe der Engine/des Erzählers:** 64
- **Auffälligkeiten:** 19
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.101 |
| Git | c9e3fa58bb57 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 16.4 s |
| Browser | chrome 156.0.8078.48 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 408 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261027-134010Z-current_test“, Seed 1613311446 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | Rogue. | Engine (Menü/Rückfrage) | creation_complete | Choose Rogue as base class | public roadside verge outside Ashbridge | 90/84 | 2.3 s |
| 2 | I choose Razor Cut and Evasive Step. | Engine (Menü/Rückfrage) | creation_complete | Select the two starter skills | public roadside verge outside Ashbridge | 90/84 | 2.1 s |
| 3 | I walk along the road toward Ashbridge's gate, keeping an eye out for travelers or merchants I might ask about the area. | Erzähler | open_run_level | Enter Ashbridge and gather local information | Ashbridge | 90/84 | 20.6 s |
| 4 | "Looking for work and supplies — any trade or rumors worth chasing around here?" | Erzähler | open_run_level | Ask the gate guard for local leads | Ashbridge | 90/84 | 19.3 s |
| 5 | I head into the market square and look for a merchant buying wolf pelts or other loot, and ask around about prices for gear and supplies. | Erzähler | open_run_level | Explore the market square for trade opportunities and prices | Ashbridge market square | 90/84 | 23.6 s |
| 6 | I step into the hide shop and ask the merchant: "Do you buy pelts, and what would you pay for wolf hides? Also, what's your stock of daggers… | Erzähler | open_run_level | Ask the hide merchant about buying pelts and gear prices | Ashbridge market square | 90/84 | 69.0 s |
| 7 | "I'll take the bedroll, the ground sheet, flint and steel, five days of rations, and ten paces of rope. That's twenty copper, so here's two … | Engine (Menü/Rückfrage) | open_run_level | Buy travel supplies from the hide merchant and ask where hunters camp along the mill road | Ashbridge market square | 90/84 | 9.5 s |
| 8 | Buy the five items for 20 cp only — and I'll still ask: where do hunters camp along the mill road? | Erzähler | open_run_level | Complete the supply purchase without a tip and get the camping information. | Ashbridge market square | 90/84 | 41.5 s |
| 9 | "Twenty for the bedroll, ground sheet, flint and steel, and two days' rations — that works." I hand over two silver and take the gear. | Erzähler | open_run_level | Complete the four-item purchase at 20 cp and get the gear booked. | Ashbridge market square | 90/84 | 14.6 s |
| 10 | I head out the west gate toward the stream bend on the mill road, looking for wolf tracks past the mill. | Erzähler | open_run_level | Travel to the mill road wolf area to hunt wolves for hides | Hunters' camp at the stream bend on the mill road | 90/84 | 74.9 s |
| 11 | I follow the old pawed track up toward the pines, moving cautiously and watching for fresher wolf sign. | Erzähler | open_run_level | Track the wolf sign into the pines to find wolves to hunt for hides. | Wolf kill clearing in the pines | 90/84 | 25.6 s |
| 12 | I follow the freshest prints uphill into the denser pines, dagger drawn, moving slowly and staying alert for the wolves. | Erzähler | open_run_level | Track the fresh wolf sign uphill to find and hunt wolves for hides. | Kill hollow in the dense pines | 90/84 | 21.4 s |
| 13 | I stay downwind and strike from ambush with Razor Cut at the feeding wolf's flank. | Erzähler | open_run_level | Ambush the lone feeding wolf for a hide. | Kill hollow in the dense pines | 90/84 | 78.8 s |
| 14 | I strike now with Razor Cut at the wolf's exposed flank from behind the fallen pine. | Erzähler | open_run_level | Ambush the feeding wolf for a hide. | Kill hollow in the dense pines | 90/84 | 26.0 s |
| 15 | I cut a generous portion of the deer's hindquarters as extra loot, then withdraw cautiously back down the trail toward the stream bend, watc… | Erzähler | open_run_level | Loot the deer meat and withdraw safely to camp with the pelt and fang. | Hunters' camp at the stream bend on the mill road | 90/84 | 37.3 s |
| 16 | I skin and prep the wolf pelt properly at the camp's work area, then rest and eat a ration portion while watching the treeline. | Erzähler | open_run_level | Process the pelt and recover at the hunters' camp. | Hunters' camp at the stream bend on the mill road | 90/84 | 21.2 s |
| 17 | I wait 3 hours while the pelt dries, then roll it up and pack it. | Erzähler | open_run_level | Let the pelt dry, then pack it and prepare to move on. | Hunters' camp at the stream bend on the mill road | 90/84 | 20.4 s |
| 18 | I shoulder my pack and walk east along the mill road toward Ashbridge, watching the light and the treeline as I go. | Erzähler | open_run_level | Leave the camp and travel to Ashbridge to sell the pelt before nightfall. | Ashbridge | 90/84 | 15.9 s |
| 19 | I queue through the gate and, when I reach the guard, nod and ask, "Anything a traveler should know about town tonight? Where's the hide tra… | Erzähler | open_run_level | Enter Ashbridge and ask the gate guard about the hide trader and local news. | Ashbridge | 90/84 | 72.3 s |
| 20 | I head down the main street to Hessel's, the green awning, and catch him before closing. "Trader Hessel? I've a fresh wolf pelt and fang fro… | Erzähler | open_run_level | Sell the wolf pelt and fang to Hessel before he closes. | Hessel's hide trader shop | 90/84 | 164.0 s |
| 21 | "Eight silver works." I hand over the pelt and fang and take the coins. | Erzähler | open_run_level | Accept Hessel's offer of 8 silver for the pelt and fang. | Hessel's hide trader shop | 90/84 | 23.6 s |
| 22 | I pocket the eight coins and head out to find an inn with a bed and supper for the night. | – | open_run_level | Confirm the sale in hand, then secure lodging and food for the night in Ashbridge. | Hessel's hide trader shop | 90/84 | 0.0 s **interrupted** |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zum Start (notiert vor Zug 1): Character creation step 1/2; Rogue gives +1 AGI/PER.
- zu Zug 2 (notiert vor Zug 3): Creation complete: Level 1 Rogue with Razor Cut and Evasive Step, starter gear equipped, 5 silver.
- zu Zug 4 (notiert vor Zug 5): Guard gave two leads: wolf signs past the mill road, and a late caravan possibly hit by bandits on the King's Road. Guild hall located off the square but I'm avoiding Guild as main route.
- zu Zug 5 (notiert vor Zug 6): Arrival pending resolved; antler-sign hide dealer found. Gear prices glimpsed: sword 1s8, cheap goods at general store.
- zu Zug 6 (notiert vor Zug 7): Shop panel confirmed stock and prices; wolf hides fetch 4s prime / 1s summer, making the mill-road wolf lead a viable income source. Purchases pending confirmation in HUD.
- zu Zug 7 (notiert vor Zug 8): System asked to clarify the ambiguous two-silver offer; purchase not yet booked. Supplies total 20 cp, leaving 4 silver 80.
- zu Zug 8 (notiert vor Zug 9): Merchant corrected the five-item math: waterskin is 1s, so 20 cp buys only four items; he offered 23 cp for five or 20 cp for four. Camping spot confirmed: stream bend half a mile past the west gate.
- zu Zug 9 (notiert vor Zug 10): Purchase booked at 20 cp (coin 3 silver); camping spot confirmed at the stream bend half a mile past the west gate.
- zu Zug 10 (notiert vor Zug 11): Arrival at the stream bend camp confirmed; purchase booked at 20 cp leaving 3 silver. Old, days-old paw sign leads toward the pines; no fresh tracks yet.
- zu Zug 11 (notiert vor Zug 12): Fresh multi-wolf sign confirmed at the kill clearing; possible pack nearby, so caution is warranted.
- zu Zug 12 (notiert vor Zug 13): Wolf A confirmed at HP 28, distracted and unaware; second wolf left uphill, so a one-on-one ambush looks favorable.
- zu Zug 13 (notiert vor Zug 14): Stealth check succeeded but the engine noted 'not taken this turn (one main action per turn)' — position gained, strike not yet made; wolf still unaware, HP 28/28.
- zu Zug 14 (notiert vor Zug 15): Ambush crit defeated Wolf A instantly: 38 damage, +48 XP (48/100), pelt and fang looted. Second wolf remains uphill, no hostility so far.
- zu Zug 15 (notiert vor Zug 16): Deer hindquarters loot refused ('someone holds it') — carcass belongs to the wolf/kill site; withdrew safely to camp with pelt and fang. XP 48/100.
- zu Zug 16 (notiert vor Zug 17): Narrator asked for a rest duration; retrying with an explicit 3-hour wait.
- zu Zug 17 (notiert vor Zug 18): Pelt dried and packed after the 3-hour wait; 3h rest recovered STA to 95/100. Oddity: the narrator first said 'he holds it already' as a refusal even though packing was the intent, but the action completed anyway.
- zu Zug 18 (notiert vor Zug 19): Reached Ashbridge at dusk without incident; pelt and fang packed. Gate open with light traffic, one bored guard present.
- zu Zug 19 (notiert vor Zug 20): Gate guard confirmed wolf-sign rumors near the roads; Hessel's hide shop located, open late for hunters.
- zu Zug 20 (notiert vor Zug 21): Hessel offered 8 silver (6 pelt + 2 fang), cash now; HUD still shows 3 silver and loot carried until the sale confirms.
- zu Zug 21 (notiert vor Zug 22): Sale scene ended with coins on the counter; HUD not yet updated (still 3 silver, loot carried) — will verify with #bag before relying on the 11 silver total.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t13 | 14 | 1 | – | ja | 1 | gewonnen, 48 XP |

## Quests

Keine angenommen.


## Auffälligkeiten

- Zug 22 (Runner/UI): interrupted
- Zug 6, Nachricht 12 (extraction_repaired): the extractor's first answer needed a repair
- Zug 6, Nachricht 12 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 6, Nachricht 12 (finish): extract ended with finish_reason "length"
- Zug 7, Nachricht 13 (planner_repaired): the planner's first answer needed a repair
- Zug 8, Nachricht 15 (planner_repaired): the planner's first answer needed a repair
- Zug 8, Nachricht 15 (finish): plan ended with finish_reason "length"
- Zug 10, Nachricht 20 (extraction_repaired): the extractor's first answer needed a repair
- Zug 10, Nachricht 20 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 10, Nachricht 20 (finish): extract ended with finish_reason "length"
- Zug 13, Nachricht 26 (extraction_repaired): the extractor's first answer needed a repair
- Zug 13, Nachricht 26 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 13, Nachricht 26 (finish): extract ended with finish_reason "length"
- Zug 19, Nachricht 38 (extraction_repaired): the extractor's first answer needed a repair
- Zug 19, Nachricht 38 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 19, Nachricht 38 (finish): extract ended with finish_reason "length"
- Zug 20, Nachricht 39 (planner_repaired): the planner's first answer needed a repair
- Zug 20, Nachricht 39 (planner_recovery): the planner required transport recovery
- Zug 21, Nachricht 41 (planner_repaired): the planner's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 6× keine gültige JSON-Entscheidung (Züge 2, 11, 12, 15, 17, 22)
- Server: Generation failed AbortError: The operation was aborted.
- Server: Generation failed AbortError: The operation was aborted.
- 5 Aufruf(e) mit finish_reason "length" (Nr. 12 extract, Nr. 16 plan, Nr. 25 extract, Nr. 35 extract, Nr. 54 extract)

System-Panels: CLARIFY 1, NOT TAKEN 1, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: ambient 2, no_go 1, scene_context 4, offer 2, sale_evidence 2.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 1, davon erfolgreich mit 0 Commands 0; Extractor leer 4, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 24 | 3 | 3.0 s | 14.5 s | 10833 | 9708 | 95 | – | stop 21, length 1 | 1 |
| narrator | 18 | 0 | 10.2 s | 14.1 s | 11091 | 8777 | 426 | – | stop 18 | 0 |
| extract | 22 | 0 | 6.8 s | 46.9 s | 10657 | 9031 | 429 | – | stop 18, length 4 | 4 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 16:03 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 16.4 s) | 0:34 min |
| 22 Züge, Spiel (Senden bis HUD nach der Extraktion) | 13:04 min — Median 22.5 s, p90 74.9 s, max 164.0 s |
| 22 Züge, Spieler-Entscheidung | 2:08 min — Median 3.3 s, 6 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 3:49 min / 0:00 min / 3:11 min / 5:20 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 41.5 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 27:39 min, 80 Züge ≈ 55:18 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spieler | 22 | – | 34.5 s | 3.3 s |
| Spiel | 20 | – | 164.0 s | 22.5 s |
| Spiel | 13 | – | 78.8 s | 22.5 s |
| Spiel | 10 | – | 74.9 s | 22.5 s |
| Provider extract | 13 | 35 | 57.8 s | 6.8 s |
| Provider extract | 10 | 25 | 57.1 s | 6.8 s |
| Provider extract | 19 | 54 | 46.9 s | 6.8 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
