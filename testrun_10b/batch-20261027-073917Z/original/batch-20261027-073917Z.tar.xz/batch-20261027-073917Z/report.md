# Avereth – 6 natürliche Testkampagnen

Status: **interrupted**. Serie abgeschlossen bedeutet, dass die Läufe beendet sind; es bedeutet nicht 6 bestandene Level-15-Abnahmen.

| Nr. | Profil | Seed | Eingaben | Level | Ende | Originalbericht |
|---|---|---:|---:|---:|---|---|
| 1 | guild-warrior | 1613311441 | 150 | 7 | limit | [report.md](001-guild-warrior/20261027-073917Z-current_test/report.md) |
| 2 | guild-mage | 1613311442 | 99 | 3 | defeat | [report.md](002-guild-mage/20261027-090159Z-current_test/report.md) |
| 3 | guild-rogue | 1613311443 | 150 | 8 | limit | [report.md](003-guild-rogue/20261027-094050Z-current_test/report.md) |
| 4 | explore-warrior | 1613311444 | 87 | 2 | ui | [report.md](004-explore-warrior/20261027-105925Z-current_test/report.md) |
| 5 | explore-mage | 1613311445 | 123 | 1 | planner_failed | [report.md](005-explore-mage/20261027-115412Z-current_test/report.md) |
| 6 | explore-rogue | 1613311446 | 22 | 1 | process_error | [report.md](006-explore-rogue/20261027-134010Z-current_test/report.md) |

