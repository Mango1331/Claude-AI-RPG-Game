# Avereth Live-Test 20261027-150205Z-current_test

## Kurzfassung

- **Laufprofil:** guild-warrior; Startklasse Warrior, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** abgebrochen: Limit erreicht — 250 turns
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 10. Sicherheitsgrenzen: 250 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** Level 4, 236 XP seit Levelaufstieg, 99 cp, HP 111, MP 84; Ort loc.ashbridge.the_sows_rest. Ausrüstung und Skills stehen in evaluation.json → progression.checkpoint.
- **Charakter:** warrior (warrior.heavy_slash, warrior.guard) · Regelstand 2 (Warrior, Mage, Rogue)
- **Ziel-Dungeon:** Mossback Warrens, Ebene 1 (Vertrag quest.clear_mossback_warrens_level_1)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: curious adventurer: follow interesting opportunities without forcing dangerous encounters
- **Züge:** 250 · **Dauer:** 105:30 min · **LLM-Aufrufe der Engine/des Erzählers:** 700
- **Beobachtete Abdeckung:** 32 unterschiedliche gebuchte Reiseziele · 22 Kämpfe · 1 Verkäufe (31 cp Umsatz, ohne Questzahlungen/Geschenke) · 4 Ausrüstungswechsel · 2 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 58
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.102 |
| Git | 57ec7f6ef982 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 15.7 s |
| Browser | chrome 156.0.8078.48 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261027-150205Z-current_test“, Seed 1604207988 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | I choose Warrior. | Engine (Menü/Rückfrage) | creation_complete | Pick base class | public roadside verge outside Ashbridge | 90/84 | 2.3 s |
| 2 | I choose Heavy Slash and Guard. | Engine (Menü/Rückfrage) | creation_complete | Pick two starter skills | public roadside verge outside Ashbridge | 95/84 | 2.1 s |
| 3 | I walk to Ashbridge and head for the Adventurers' Guild hall to register and look at the contract board. | Erzähler | open_run_level | Enter city and find Guild work | Adventurers' Guild hall, Ashbridge | 95/84 | 36.7 s |
| 4 | I pay the 2 silver registration fee and sign the roll. | Erzähler | open_run_level | Register with the Guild | Adventurers' Guild hall, Ashbridge | 95/84 | 16.4 s |
| 5 | I take the eel-hound contract slip from the board and ask the clerk to accept it for me. | Erzähler | open_run_level | Take first Guild contract | Adventurers' Guild hall, Ashbridge | 95/84 | 15.0 s |
| 6 | I head down to the fish weirs and find Warden Aldwin to ask where the eel-hound has been hunting. | Erzähler | open_run_level | Get eel-hound location from client | the fish weirs at the river shallows below Ashbridge | 95/84 | 23.8 s |
| 7 | I thank Aldwin and head to the downstream bend, keeping to the gravel shoals to wait for dusk and watch the reed edge. | Erzähler | open_run_level | Hunt the eel-hound at dusk from the gravel | the fish weirs at the river shallows below Ashbridge | 95/84 | 26.4 s |
| 8 | Since it's still morning, I spend the hours preparing: I drag the fallen willow trunk to a spot near the reed lane's mouth for cover, then s… | Erzähler | open_run_level | Set up ambush position and wait for the eel-hound | the fish weirs at the river shallows below Ashbridge | 95/84 | 23.3 s |
| 9 | I stay behind the willow trunk, keeping still and watching the reed lane as dusk approaches. | Erzähler | open_run_level | Continue the ambush until the eel-hound emerges at dusk | the fish weirs at the river shallows below Ashbridge | 95/84 | 29.6 s |
| 10 | I charge from behind the willow trunk and attack the eel-hound with Heavy Slash before it can reach the deep water. | Erzähler | open_run_level | Engage the eel-hound at the lane's mouth | the fish weirs at the river shallows below Ashbridge | 95/84 | 30.1 s |
| 11 | I rush the eel-hound at the ruined basket and strike it with Heavy Slash the moment I'm in range. | Erzähler | open_run_level | Close to ENGAGED and attack | the fish weirs at the river shallows below Ashbridge | 95/84 | 18.2 s |
| 12 | I move straight to ENGAGED with the eel-hound at the ruined basket, then strike it with Heavy Slash. | Erzähler | open_run_level | Close to ENGAGED and attack | the fish weirs at the river shallows below Ashbridge | 95/84 | 18.1 s |
| 13 | I head back upstream to Ashbridge to turn in the eel-hound contract at the Guild hall. | Erzähler | open_run_level | Turn in the completed contract | Adventurers' Guild hall, Ashbridge | 95/84 | 20.1 s |
| 14 | "What's on the board for tomorrow? I'm after another contract suitable for a Novice — something I can start in the morning." | Erzähler | open_run_level | Ask the clerk for the next Guild contract | Adventurers' Guild hall, Ashbridge | 95/84 | 16.2 s |
| 15 | I take the Clear Mossback Warrens, Level 1 slip from the board and accept it at the clerk's desk. | Erzähler | open_run_level | Accept the achievable Novice contract | Adventurers' Guild hall, Ashbridge | 95/84 | 20.1 s |
| 16 | I ask the clerk for lodging nearby, then take a room and sleep until morning. | Erzähler |  | Recover overnight before heading to the warrens | Adventurers' Guild hall, Ashbridge | 95/84 | 24.1 s |
| 17 | I take the shared loft for two silver, eat supper, and sleep until morning. | Erzähler | open_run_level | Book the cheap room and recover overnight | Adventurers' Guild hall, Ashbridge | 95/84 | 40.2 s |
| 18 | I eat the porridge, then head east along the old quarry track toward the mossy hill and the Mossback Warrens. | Erzähler | open_run_level | Travel to the warrens for the active contract | Adventurers' Guild hall, Ashbridge | 95/84 | 17.5 s |
| 19 | I buy the porridge with bread for two copper, then set off east along the old quarry track toward the Mossback Warrens. | Erzähler | open_run_level | Eat and travel to the warrens | Adventurers' Guild hall, Ashbridge | 95/84 | 20.1 s |
| 20 | I draw my longsword and enter the warren mouth cautiously, staying alert for any movement in the moss. | Erzähler | open_run_level | Enter the warrens and begin clearing the contract | Mossback Warrens | 95/84 | 25.7 s |
| 21 | I cut the goblin down before its shriek can raise the warren, lunging at it with my longsword. | Engine (Menü/Rückfrage) | open_run_level | Kill the scout quickly to prevent an alarm | Mossback Warrens | 95/84 | 10.9 s |
| 22 | I lunge at the shrieking goblin scout with my longsword before its alarm call brings the warren down on me. | Engine (Menü/Rückfrage) | open_run_level | Attack the goblin, hoping naming it registers the target | Mossback Warrens | 95/84 | 5.2 s |
| 23 | I attack the goblin scout with Basic Attack. | Engine (Menü/Rückfrage) | open_run_level | Kill the goblin using a named skill | Mossback Warrens | 95/84 | 3.7 s |
| 24 | #status | System (Befehl) | open_run_level | Inspect why no targetable actor exists in the active scene | Mossback Warrens | 95/84 | 2.1 s |
| 25 | I step forward into the tunnel widening toward the low side chamber, moving cautiously with my longsword ready. | Erzähler | open_run_level | Move to trigger a valid scene with targetable goblins | broad root-curtain gallery | 95/84 | 28.9 s |
| 26 | I charge the nearest goblin scout and strike it down with Heavy Slash. | Erzähler | open_run_level | Attack the now-targetable goblin scouts | broad root-curtain gallery | 95/84 | 17.5 s |
| 27 | I close the distance to Goblin Scout A and strike it with Heavy Slash. | Erzähler | open_run_level | Close to ENGAGED range and attack | broad root-curtain gallery | 80/84 | 22.2 s |
| 28 | I strike Goblin Scout A again with Heavy Slash. | Erzähler | open_run_level | Finish the wounded scout | broad root-curtain gallery | 65/84 | 17.8 s |
| 29 | I finish Goblin Scout A with a Basic Attack. | Erzähler | open_run_level | Kill the nearly dead scout and reduce incoming damage | broad root-curtain gallery | 57/84 | 15.9 s |
| 30 | I strike Goblin Scout B with Heavy Slash. | Erzähler | open_run_level | Kill the remaining goblins one at a time | broad root-curtain gallery | 48/84 | 17.5 s |
| 31 | I finish Goblin Scout B with another Heavy Slash. | Erzähler | open_run_level | Kill the wounded scout B | broad root-curtain gallery | 45/84 | 12.0 s |
| 32 | I kill the last goblin with Heavy Slash. | Erzähler | open_run_level | Finish the final goblin scout | broad root-curtain gallery | 42/84 | 19.6 s |
| 33 | I finish the wounded Goblin Scout C with a Basic Attack. | Erzähler | open_run_level | Conserve STA and kill the last scout | broad root-curtain gallery | 42/84 | 13.8 s |
| 34 | #assign STR 3 VIT 2 | System (Befehl) | open_run_level | Spend level-up points on STR and VIT | broad root-curtain gallery | 42/84 | 2.2 s |
| 35 | I rest a moment behind the palisade by the dying cookfire to recover stamina, keeping my sword ready. | Engine (Menü/Rückfrage) | open_run_level | Recover STA before pressing deeper into the warren | broad root-curtain gallery | 42/84 | 4.5 s |
| 36 | I rest behind the palisade for 2 hours, keeping watch over the tunnels. | Erzähler | open_run_level | Recover HP and STA before going deeper | broad root-curtain gallery | 65/84 | 16.0 s |
| 37 | I take the tunnel where something clicked and skittered, advancing slowly with my sword up. | Erzähler | open_run_level | Continue clearing warren level 1 | smoking moss-fire chamber | 65/84 | 25.4 s |
| 38 | I use Guard and hold the tunnel mouth so only one warrior can reach me at a time. | Erzähler | open_run_level | Fight the goblin warriors defensively from the chokepoint | smoking moss-fire chamber | 65/84 | 18.9 s |
| 39 | I counterattack Warrior A with Heavy Slash as the club swings in. | Erzähler | open_run_level | Trade blows with the leader at the chokepoint | smoking moss-fire chamber | 48/84 | 14.8 s |
| 40 | I finish the wounded leader with Heavy Slash. | Erzähler | open_run_level | Kill Warrior A before it swings again | smoking moss-fire chamber | 40/84 | 13.4 s |
| 41 | I use Guard to blunt their attacks, letting my stamina recover while I hold the chokepoint. | Erzähler | open_run_level | Reduce incoming damage and set up a finishing blow on the weakened goblins | smoking moss-fire chamber | 38/84 | 15.8 s |
| 42 | I strike Warrior B with Heavy Slash, then keep Guard up next round if it still stands. | Erzähler | open_run_level | Finish one goblin, keep chokepoint control | smoking moss-fire chamber | 30/84 | 13.5 s |
| 43 | I finish Warrior B with Heavy Slash. | Erzähler | open_run_level | Kill the wounded goblin before turning on the last one | smoking moss-fire chamber | 27/84 | 13.6 s |
| 44 | I strike Warrior C with Heavy Slash before it can dart in again. | Erzähler | open_run_level | Finish the last goblin warrior | smoking moss-fire chamber | 24/84 | 14.1 s |
| 45 | I finish Warrior C with a Basic Attack. | Erzähler | open_run_level | Kill the last goblin cheaply | smoking moss-fire chamber | 24/84 | 15.6 s |
| 46 | #assign STR 3 VIT 2 | System (Befehl) | open_run_level | Spend level-up points on damage and survivability | smoking moss-fire chamber | 24/84 | 2.2 s |
| 47 | I press on through the broad root-curtain gallery, moving cautiously deeper into the warrens to clear the remaining level 1 threats. | Erzähler | open_run_level | Continue clearing the dungeon despite wounds | broad root-curtain gallery | 24/84 | 19.0 s |
| 48 | I take the left-hand slope up toward the daylight, withdrawing from the warrens to recover before going back down. | Erzähler | open_run_level | Retreat wounded via the daylight exit to rest and recover | climbing passage toward gray daylight | 24/84 | 23.7 s |
| 49 | I back away quietly into the root-curtain gallery and retreat toward the warren entrance to recover before facing the chief. | Erzähler | open_run_level | Withdraw badly wounded before fighting the chief | broad root-curtain gallery | 24/84 | 18.8 s |
| 50 | I climb toward the warren mouth and daylight, getting out of the warrens to rest and recover before returning for the chief. | Erzähler | open_run_level | Exit and recover | hillside below the warren mouth | 24/84 | 20.9 s |
| 51 | I rest against the flat stone until my wounds heal and I feel fit to go back down into the warrens. | Engine (Menü/Rückfrage) | open_run_level | Rest to recover HP before re-entering | hillside below the warren mouth | 24/84 | 4.3 s |
| 52 | I rest for 3 hours, until I'm healed and rested enough to go back down. | Erzähler | open_run_level | Book a rest to recover HP | hillside below the warren mouth | 64/84 | 16.3 s |
| 53 | I climb back up and re-enter the warren mouth, moving cautiously down into the warrens to find the goblin chief. | Erzähler | open_run_level | Return to the dungeon to fight the chief | Mossback Warrens | 64/84 | 23.2 s |
| 54 | I push through the root curtain and head down through the gallery toward the chief's hollow, sword ready. | Erzähler | open_run_level | Fight the goblin chief | the chief's hollow | 64/84 | 31.7 s |
| 55 | I raise my sword and charge the chief, using Heavy Slash against it. | Erzähler | open_run_level | Fight the goblin chief | the chief's hollow | 64/84 | 19.2 s |
| 56 | I back out of the chief's hollow the way I came, retreating through the gallery to the warren mouth to rest until fully healed before facing… | Erzähler | open_run_level | Withdraw wounded and recover before fighting the chief | hillside below the warren mouth | 64/84 | 29.0 s |
| 57 | I make camp in the brush near the warren mouth and sleep until morning to heal my wounds. | Erzähler | open_run_level | Recover HP overnight before facing the chief again | hillside below the warren mouth | 135/84 | 17.9 s |
| 58 | I re-enter the warren mouth and move back down through the squeeze and the root curtains toward the chief's hollow, planning to close the di… | Erzähler | open_run_level | Fight the goblin chief | the chief's hollow | 135/84 | 23.4 s |
| 59 | I close the remaining distance and engage the chief at melee range, attacking with my longsword. | Engine (Menü/Rückfrage) | open_run_level | Fight the goblin chief at close range | the chief's hollow | 135/84 | 4.6 s |
| 60 | I engage the Palisade Chief in combat, closing to melee range and striking with my longsword. | Engine (Menü/Rückfrage) | open_run_level | Start combat with the chief as the active scene | the chief's hollow | 135/84 | 3.8 s |
| 61 | #help | System (Befehl) | open_run_level | Find how to initiate combat with the chief | the chief's hollow | 135/84 | 2.4 s |
| 62 | #combat | System (Befehl) | open_run_level | Audit the encounter to see the actual combat state in the chief's hollow | the chief's hollow | 135/84 | 2.2 s |
| 63 | I draw my longsword and commit to the fight, striking at the Palisade Chief where he stands. | Engine (Menü/Rückfrage) | open_run_level | Make a hostile commitment to activate combat with the chief | the chief's hollow | 135/84 | 4.6 s |
| 64 | I move to re-enter the chief's hollow and call out a challenge to the Palisade Chief, drawing my longsword to provoke a hostile response. | Erzähler | open_run_level | Provoke the chief into an active, targetable combat scene | the chief's hollow | 135/84 | 18.6 s |
| 65 | I strike at the Palisade Chief with my longsword as it swings at me. | Engine (Menü/Rückfrage) | open_run_level | Attack the chief now that it has closed in | the chief's hollow | 135/84 | 3.8 s |
| 66 | #combat | System (Befehl) | open_run_level | Audit the combat state to see why the chief registers as no targetable actor | the chief's hollow | 135/84 | 2.2 s |
| 67 | I attack the chief with Heavy Slash as it swings its club at me. | Engine (Menü/Rückfrage) | open_run_level | Activate combat with a properly named target using a skill attack | the chief's hollow | 135/84 | 3.8 s |
| 68 | I withdraw from the chief's hollow and head out of the Mossback Warrens toward the exit. | Erzähler | open_run_level | Leave the desynced chief encounter and exit the dungeon | hillside below the warren mouth | 135/84 | 25.2 s |
| 69 | I head to the Ashbridge Guild hall and ask the attendant about the Mossback Warrens contract, since the chief could not be engaged. | Erzähler | open_run_level | Report contract status and seek guidance on the blocked chief encounter | Adventurers' Guild hall, Ashbridge | 135/84 | 36.3 s |
| 70 | I ask the clerk what other Novice contracts are on the board right now. | Erzähler | open_run_level | Pick a new achievable contract while the warren contract sits active | Adventurers' Guild hall, Ashbridge | 135/84 | 37.0 s |
| 71 | I ask the clerk to take the eel-hound contract at the fish weirs, and I'll head there now. | Erzähler | open_run_level | Accept the achievable Novice cull contract | the fish weirs at the river shallows below Ashbridge | 135/84 | 29.1 s |
| 72 | I thank the fisherman and head to the deep pool below the last weir, keeping watch on the churned mud and the water for the eel-hound. | Erzähler | open_run_level | Stake out the eel-hound's hunting pool | the fish weirs at the river shallows below Ashbridge | 135/84 | 25.8 s |
| 73 | I meet the eel-hound at the churned mud and attack it with Heavy Slash as it drives out of the water. | Erzähler | open_run_level | Engage the eel-hound with a skill attack | the fish weirs at the river shallows below Ashbridge | 135/84 | 18.8 s |
| 74 | I attack the eel-hound with Heavy Slash now that it's engaged at the water's edge. | Erzähler | open_run_level | Engage the eel-hound in combat | the fish weirs at the river shallows below Ashbridge | 135/84 | 25.5 s |
| 75 | I return to the Ashbridge Guild hall and turn in the eel-hound contract for the reward. | Erzähler | open_run_level | Turn in the completed cull contract | Adventurers' Guild hall, Ashbridge | 135/84 | 18.5 s |
| 76 | I ask the clerk what other Novice contracts are on the board right now. | Erzähler | open_run_level | Pick another achievable Guild contract | Adventurers' Guild hall, Ashbridge | 135/84 | 14.2 s |
| 77 | I take the tusked boar contract slip from the board and ask the clerk to make it active, then head east toward the old quarry track. | Erzähler | open_run_level | Accept the boar cull and travel to the quarry track | the old quarry track east of Ashbridge | 135/84 | 18.4 s |
| 78 | I climb farther up the quarry track toward the second pit, watching the gorse banks and mud wallows for boar sign. | Erzähler | open_run_level | Search the quarry track for tusked boars | the second quarry pit | 135/84 | 20.6 s |
| 79 | I walk down the ramp into the pit and search the collapsed shed's black doorway for the boar, Heavy Slash ready. | Erzähler | open_run_level | Find and fight a tusked boar | the second quarry pit | 135/84 | 33.4 s |
| 80 | I brace and meet the charging boar with Heavy Slash as it closes. | Erzähler | open_run_level | Fight the tusked boar | the second quarry pit | 135/84 | 15.0 s |
| 81 | I hold my ground and swing Heavy Slash at the boar as it closes into sword range. | Erzähler | open_run_level | Fight the tusked boar at ENGAGED range | the second quarry pit | 126/84 | 15.0 s |
| 82 | I swing Heavy Slash again at the wounded boar to finish it. | Erzähler | open_run_level | Finish the tusked boar with Heavy Slash | the second quarry pit | 126/84 | 17.8 s |
| 83 | I search the collapsed shed's black doorway on the far side of the pit for the next boar, Heavy Slash ready. | Erzähler | open_run_level | Continue the boar cull contract (1/4) | the second quarry pit | 126/84 | 21.2 s |
| 84 | I swing Heavy Slash at Boar B as it bursts through the rubble gap. | Erzähler | open_run_level | Fight tusked boar B (2/4) | the second quarry pit | 126/84 | 19.4 s |
| 85 | I close to ENGAGED and swing Heavy Slash at the wounded Boar B before it can recover. | Erzähler | open_run_level | Finish boar B (2/4) | the second quarry pit | 126/84 | 19.6 s |
| 86 | #assign STR 2 VIT 2 AGI 1 | System (Befehl) | open_run_level | Spend level-up points | the second quarry pit | 126/84 | 2.5 s |
| 87 | I follow the old cart ruts east beyond the pit rim, Heavy Slash ready, tracking the last boar's rooting sign. | Erzähler | open_run_level | Continue boar cull (2/4) | quarry spoil clearing east of the second pit | 126/84 | 27.7 s |
| 88 | I close the distance quickly and swing Heavy Slash at the rooting Boar C before it notices me. | Erzähler | open_run_level | Attack the last boar for the cull contract (3/4) | quarry spoil clearing east of the second pit | 126/84 | 18.7 s |
| 89 | I brace to receive its charge, Guard raised, and hold my ground until it closes into ENGAGED range. | Erzähler | open_run_level | Draw boar C into range | quarry spoil clearing east of the second pit | 126/84 | 16.3 s |
| 90 | I swing Heavy Slash at the charging boar's head as it reaches me. | Erzähler | open_run_level | Strike boar C at the moment of contact | quarry spoil clearing east of the second pit | 111/84 | 17.3 s |
| 91 | I swing Heavy Slash again at the wounded boar's head before it can charge. | Erzähler | open_run_level | Finish boar C (4/4) | quarry spoil clearing east of the second pit | 111/84 | 14.1 s |
| 92 | I follow the cart track back west along the Old Quarry Track, watching for sign of a fourth tusked boar, since the count still shows 3/4. | Erzähler | open_run_level | Find and defeat the fourth boar | quarry spoil clearing east of the second pit | 111/84 | 18.5 s |
| 93 | #quest Cull the Tusked Boars on the Old Quarry Track | System (Befehl) | open_run_level | Check whether the fourth boar has now been counted | quarry spoil clearing east of the second pit | 111/84 | 2.6 s |
| 94 | I walk back to the Adventurers' Guild in Ashbridge and ask the clerk to check my cull contract — I've defeated three boars and found no sign… | Erzähler | open_run_level | Report cull progress at the Guild | Adventurers' Guild hall, Ashbridge | 111/84 | 19.4 s |
| 95 | I'll keep the boar contract active and ask the clerk to look at the Guild board for other work suitable for a Novice while I'm here. | Erzähler | open_run_level | Keep cull active; browse board for other contracts | Adventurers' Guild hall, Ashbridge | 111/84 | 17.5 s |
| 96 | I'm wounded and low on stamina, so I'll leave the board for now and ask the clerk where I can find a healer or a room for the night in Ashbr… | Erzähler | open_run_level | Recover before taking on the warrens | Adventurers' Guild hall, Ashbridge | 111/84 | 26.8 s |
| 97 | I thank the clerk and walk to the Sow's Rest, where I ask Bram for a room for the night and a bowl of stew. | Erzähler | open_run_level | Get lodging and food, then sleep until morning | the Sow's Rest | 111/84 | 24.4 s |
| 98 | I approach the innkeeper and ask his price for a room for the night and a bowl of stew. | Erzähler | open_run_level | Get an actual offer before buying lodging and food | the Sow's Rest | 111/84 | 13.7 s |
| 99 | I'll take the stew and the five-copper room off the yard, please, Bram. | Engine (Menü/Rückfrage) | open_run_level | Buy meal and lodging per confirmed offer | the Sow's Rest | 111/84 | 10.6 s |
| 100 | I'll buy the bowl of stew for 2 copper and the room off the yard with the feather bed for 5 copper, Bram — 7 copper total. | Erzähler | open_run_level | Buy meal and lodging per confirmed offer | the Sow's Rest | 111/84 | 17.7 s |
| 101 | I eat the stew and bread, then go up to my room, take off my boots and armor, and sleep until morning. | Erzähler | open_run_level | Recover overnight at the Sow's Rest | Upstairs room at the Sow's Rest | 111/84 | 31.5 s |
| 102 | Now in my upstairs room at the Sow's Rest, I take off my boots and armor, hang the sword on the hook, and sleep until morning. | Erzähler | open_run_level | Recover overnight in the confirmed room | Upstairs room at the Sow's Rest | 155/84 | 15.4 s |
| 103 | I get dressed and equipped, then head down and out of the Sow's Rest toward the Old Quarry Track to finish the boar cull — one more tusked b… | Erzähler | open_run_level | Complete the boar contract | the old quarry track east of Ashbridge | 155/84 | 23.3 s |
| 104 | I move quietly toward the rooting boar in the hollow and attack it with Heavy Slash while it's unaware. | Engine (Menü/Rückfrage) | open_run_level | Defeat the fourth boar to finish the cull contract | the old quarry track east of Ashbridge | 155/84 | 10.7 s |
| 105 | I attack the last tusked boar rooting east of the second pit with Heavy Slash while it is unaware. | Engine (Menü/Rückfrage) | open_run_level | Defeat the fourth boar to complete the cull contract | the old quarry track east of Ashbridge | 155/84 | 5.9 s |
| 106 | I follow the rooting sounds down into the shadowed hollow between the two walls on the east terrace to find the boar. | Erzähler | open_run_level | Enter the hollow to make the boar targetable | shadowed hollow between the quarry walls | 155/84 | 27.6 s |
| 107 | I brace and meet its charge with Heavy Slash aimed at its shoulder as it closes. | Erzähler | open_run_level | Defeat the last boar to complete the cull contract | shadowed hollow between the quarry walls | 155/84 | 20.9 s |
| 108 | I hold my ground and swing Heavy Slash into the boar the instant it reaches me. | Erzähler | open_run_level | Defeat the last boar | shadowed hollow between the quarry walls | 155/84 | 14.1 s |
| 109 | I swing Heavy Slash into the boar now that it's on me. | Erzähler | open_run_level | Defeat the final boar at ENGAGED range | shadowed hollow between the quarry walls | 134/84 | 17.2 s |
| 110 | I finish it with another Heavy Slash to the wounded shoulder while it gathers for its next charge. | Erzähler | open_run_level | Kill the final boar | shadowed hollow between the quarry walls | 111/84 | 31.9 s |
| 111 | I finish it with a final Heavy Slash into the wounded shoulder as it drives in. | Erzähler | open_run_level | Kill the final boar to complete the cull contract | shadowed hollow between the quarry walls | 111/84 | 16.6 s |
| 112 | #assign STR 2 VIT 2 AGI 1 | System (Befehl) | open_run_level | Spend level-up points, then head back to the Guild to turn in the boar cull | shadowed hollow between the quarry walls | 111/84 | 2.6 s |
| 113 | With the cull at 4/4, I head back along the quarry track to the Guild hall in town to turn in the boar contract. | Erzähler | open_run_level | Turn in completed boar cull at the Guild | Adventurers' Guild hall, Ashbridge | 111/84 | 24.0 s |
| 114 | I ask the clerk to pull up the Guild contract board so I can pick my next job. | Erzähler | open_run_level | Choose a new Guild contract | Adventurers' Guild hall, Ashbridge | 111/84 | 29.3 s |
| 115 | I take the eel-hound cull slip from the board and ask the clerk to register it as my active contract. | Erzähler | open_run_level | Accept the novice eel-hound contract | Adventurers' Guild hall, Ashbridge | 111/84 | 18.7 s |
| 116 | I head down through the town past tannery row to the fish weirs and hunt for the eel-hound in the river shallows below the last weir. | Erzähler | open_run_level | Hunt the eel-hound at the weirs for the active cull contract | the fish weirs at the river shallows below Ashbridge | 111/84 | 19.5 s |
| 117 | I ask the warden to point out the third pool, then pick my way down the bank past the last weir to the shallows below and look for the eel-h… | Erzähler | open_run_level | Reach the third pool and hunt the eel-hound for the active cull | the third pool below the last weir | 111/84 | 24.0 s |
| 118 | I wade carefully into the shallows toward the dark shadow among the basket frames, sword ready, and prod at it to see if it's the eel-hound. | Erzähler | open_run_level | Investigate the shadow and provoke the eel-hound into the open | the third pool below the last weir | 111/84 | 23.9 s |
| 119 | I set my feet against the current and strike at the lunging eel-hound with Heavy Slash. | Erzähler | open_run_level | Fight the engaged eel-hound for the cull contract | the third pool below the last weir | 111/84 | 16.5 s |
| 120 | I haul the eel-hound carcass up onto the shingle, then head back up past the weirs to the Guild hall in town to turn in the cull contract. | Erzähler | open_run_level | Turn in the completed eel-hound cull at the Guild | Adventurers' Guild hall, Ashbridge | 111/84 | 18.0 s |
| 121 | I ask the clerk if the Guild board has any other novice contracts besides the Mossback Warrens one, or if there's a delivery or escort job t… | Erzähler | open_run_level | Browse for new achievable contracts | Adventurers' Guild hall, Ashbridge | 111/84 | 17.8 s |
| 122 | I tell the clerk I'll take the boar cull on the quarry track as well, and ask her to mark it active for me. | Erzähler | open_run_level | Accept the tusked boar cull contract | Adventurers' Guild hall, Ashbridge | 111/84 | 12.5 s |
| 123 | I take the boar slip and head out the east gate toward the old quarry track to hunt the tusked boars. | Erzähler | open_run_level | Travel to the quarry track for the boar cull | the old quarry track east of Ashbridge | 111/84 | 18.1 s |
| 124 | I follow the terraces toward the spoil clearing east of the second pit, then charge the rooting boar from forty paces and strike it with Hea… | Erzähler | open_run_level | Hunt the tusked boar for the cull contract | quarry spoil clearing east of the second pit | 111/84 | 20.1 s |
| 125 | I press the attack and strike again at the boar with Heavy Slash before it can recover its footing. | Erzähler | open_run_level | Continue fighting the engaged boar for the cull contract | quarry spoil clearing east of the second pit | 111/84 | 17.2 s |
| 126 | I rush the ten paces to close with the boar and strike it with Heavy Slash. | Erzähler | open_run_level | Close to ENGAGED and attack the boar | quarry spoil clearing east of the second pit | 105/84 | 21.2 s |
| 127 | I finish the wounded boar with Heavy Slash. | Erzähler | open_run_level | Kill the boar for the cull contract | quarry spoil clearing east of the second pit | 105/84 | 16.0 s |
| 128 | #assign STR 3 VIT 2 | System (Befehl) | open_run_level | Spend level-up stat points on strength and vitality | quarry spoil clearing east of the second pit | 105/84 | 2.7 s |
| 129 | I check the boar slip to see how many more tusked boars the cull contract requires. | Erzähler | open_run_level | Check boar cull progress | quarry spoil clearing east of the second pit | 105/84 | 12.2 s |
| 130 | I follow the piggy stink toward the ash and beech stand against the quarry's far wall, searching the terraces for the next tusked boar. | Erzähler | open_run_level | Hunt the second boar for the cull contract | ash and beech stand against the quarry's far wall | 105/84 | 17.4 s |
| 131 | I take the left-hand route along the terraces, following the freshest rooting signs deeper into the stand. | Erzähler | open_run_level | Hunt the second tusked boar for the cull contract | slumped bowl against the quarry wall | 105/84 | 23.8 s |
| 132 | I charge the rooting boar F from behind and strike it with Heavy Slash before the other two wake. | Erzähler | open_run_level | Ambush boar F for the cull contract | slumped bowl against the quarry wall | 105/84 | 16.8 s |
| 133 | I close the thirty feet to boar F and strike it with Heavy Slash. | Erzähler | open_run_level | Charge into range and attack boar F | slumped bowl against the quarry wall | 105/84 | 17.4 s |
| 134 | I sprint the remaining dozen strides straight at boar F and engage it, then swing Heavy Slash. | Erzähler | open_run_level | Close to engaged range and attack boar F | slumped bowl against the quarry wall | 105/84 | 19.6 s |
| 135 | I strike boar F with Heavy Slash now that it's in short range. | Erzähler | open_run_level | Attack boar F at close range | slumped bowl against the quarry wall | 105/84 | 17.9 s |
| 136 | I step forward to engage boar F, then strike it with Heavy Slash. | Erzähler | open_run_level | Engage boar F at SHORT and attack for the cull contract | slumped bowl against the quarry wall | 98/84 | 17.5 s |
| 137 | I finish boar F with Heavy Slash before the other two close in. | Erzähler | open_run_level | Kill the wounded boar F for the cull contract | slumped bowl against the quarry wall | 98/84 | 17.0 s |
| 138 | I follow the fresh rooting signs left along the terraces to hunt the remaining boar for the cull contract. | Erzähler | open_run_level | Find and kill the third counted boar | second bench of the quarry | 98/84 | 25.0 s |
| 139 | I wait low among the spoil heaps and let one of the boars come closer before charging it with Heavy Slash. | Engine (Menü/Rückfrage) | open_run_level | Hunt the remaining boars for the cull contract | second bench of the quarry | 98/84 | 6.7 s |
| 140 | I hold low among the spoil heaps and wait for the nearer boar, then charge Tusked Boar J with Heavy Slash the moment it comes within reach. | Erzähler | open_run_level | Ambush boar J for the third cull kill | second bench of the quarry | 98/84 | 20.1 s |
| 141 | I sprint up the slope to close on Tusked Boar J, then strike it with Heavy Slash once engaged. | Erzähler | open_run_level | Close to ENGAGED with boar J and attack | second bench of the quarry | 98/84 | 20.5 s |
| 142 | I move up the slope toward Tusked Boar J, keeping low, closing the distance step by step. | Erzähler | open_run_level | Close to ENGAGED with boar J as movement only, so the attack can be declared separately | second bench of the quarry | 98/84 | 16.2 s |
| 143 | I close the last paces to Tusked Boar J and strike it with Heavy Slash. | Erzähler | open_run_level | Engage boar J for the third cull kill | second bench of the quarry | 98/84 | 13.9 s |
| 144 | I charge straight at Tusked Boar J to close to ENGAGED, then swing Heavy Slash the moment I reach it. | Erzähler | open_run_level | Close to ENGAGED and attack boar J for the third cull kill | second bench of the quarry | 98/84 | 15.9 s |
| 145 | I meet the charging Tusked Boar I head-on and swing Heavy Slash at it. | Erzähler | open_run_level | Kill the engaged boar for the third cull kill | second bench of the quarry | 88/84 | 18.8 s |
| 146 | I finish the wounded boar with another Heavy Slash. | Erzähler | open_run_level | Kill boar I for the third cull kill | second bench of the quarry | 88/84 | 15.0 s |
| 147 | I collect what I can from the fallen boar, then head down the quarry track toward Ashbridge. | Erzähler | open_run_level | Finish the boar cull and return to town to turn in the contract | Ashbridge | 88/84 | 42.1 s |
| 148 | I go into the Guild hall and turn in the boar cull contract at the counter. | Erzähler | open_run_level | Turn in completed cull contract | Adventurers' Guild hall, Ashbridge | 88/84 | 19.9 s |
| 149 | I walk to the notice board and read the postings, looking for a Novice contract I can still take today. | Erzähler | open_run_level | Pick the next Guild contract from the board | Adventurers' Guild hall, Ashbridge | 88/84 | 20.0 s |
| 150 | I take the Mossback Warrens slip to the counter and tell the clerk I'll take it, then ask if there's a bed free at the inn — I'll rest overn… | Erzähler | open_run_level | Accept warrens contract and plan recovery before the dungeon | Adventurers' Guild hall, Ashbridge | 88/84 | 24.0 s |
| 151 | I go to Marla's kitchen door and buy the room with supper for 20 cp, then eat and sleep until morning. | Erzähler | open_run_level | Recover overnight before the warrens | the Sow's Rest | 88/84 | 27.4 s |
| 152 | I pay Marla 20 cp for the room and supper. | Erzähler | open_run_level | Pay for lodging | the Sow's Rest | 88/84 | 17.9 s |
| 153 | I go to the Guild counter and buy the Primer of Mend for 120 cp, then read it to learn the mend skill. | Erzähler | open_run_level | Learn a self-healing skill before the warrens since HP is still low | Adventurers' Guild hall, Ashbridge | 88/84 | 29.9 s |
| 154 | I stay at the bench and keep practicing the mend exercises, working the cantrip until I can cast it once. | Engine (Menü/Rückfrage) | open_run_level | Practice the primer's exercises to actually learn mend | Adventurers' Guild hall, Ashbridge | 88/84 | 5.9 s |
| 155 | I keep practicing the mend exercises at the bench for 2 hours, working the cantrip until I can cast it once. | Erzähler | open_run_level | Practice mend with a stated duration | Adventurers' Guild hall, Ashbridge | 88/84 | 16.5 s |
| 156 | I ask the clerk at the counter if there's a bed free anywhere in Ashbridge tonight, then go and sleep until morning. | Erzähler | open_run_level | Get lodging and rest before heading to the warrens at first light | Adventurers' Guild hall, Ashbridge | 195/84 | 24.3 s |
| 157 | I ask the clerk about the duplicate warrens contract on my slate: my slip shows the Clear Mossback Warrens contract accepted twice, with two… | Erzähler | open_run_level | Resolve duplicate contract before departing | Adventurers' Guild hall, Ashbridge | 195/84 | 23.0 s |
| 158 | I'll keep both slips — two payouts for one day's work suits me. I'm off to clear the Mossback Warrens east of town now. | Erzähler | open_run_level | Keep both contract slips and head to the Mossback Warrens | Adventurers' Guild hall, Ashbridge | 195/84 | 39.7 s |
| 159 | I set my pack down, speak softly to the mule, and try to lead it forward by the halter — and if it won't move, I check whether the slipped s… | Erzähler | open_run_level | Help the carter shift the stubborn mule | Adventurers' Guild hall, Ashbridge | 195/84 | 21.9 s |
| 160 | I'll help you unload and haul the turnips past the ford, then take the copper and be on my way. | Erzähler | open_run_level | Help the carter, then continue to the warrens | Mossback Warrens | 195/84 | 23.8 s |
| 161 | I enter the Mossback Warrens through the largest tunnel mouth. | Erzähler | open_run_level | Enter the dungeon to clear the goblin warrens contract | smoking cookfire widening | 195/84 | 19.8 s |
| 162 | I rush the goblin by the fire with my longsword before they notice me, aiming a Heavy Slash at the nearer one. | Engine (Menü/Rückfrage) | open_run_level | Ambush the two goblin lookouts | smoking cookfire widening | 195/84 | 7.4 s |
| 163 | I rush Goblin Lookout A and swing my longsword in a Heavy Slash before they notice me. | Erzähler | open_run_level | Ambush the nearer goblin lookout with Heavy Slash | smoking cookfire widening | 195/84 | 16.1 s |
| 164 | I sprint the remaining paces to close with Goblin Lookout A and swing my longsword in a Heavy Slash. | Erzähler | open_run_level | Close to ENGAGED range, then attack | smoking cookfire widening | 195/84 | 16.7 s |
| 165 | I close the distance to Goblin Lookout A, moving into ENGAGED range beside the fire, and strike him with a Basic Attack. | Erzähler | open_run_level | Close to ENGAGED and attack with an in-range skill | smoking cookfire widening | 195/84 | 15.2 s |
| 166 | I move to ENGAGED range with Goblin Lookout A, closing the ten paces to his side. | Erzähler | open_run_level | Declare movement alone so the engine registers the range change | smoking cookfire widening | 195/84 | 18.5 s |
| 167 | I strike Goblin Lookout A with a Heavy Slash. | Erzähler | open_run_level | Attack the nearer lookout now in range | smoking cookfire widening | 195/84 | 13.2 s |
| 168 | I move to ENGAGED range with Goblin Lookout A. | Erzähler | open_run_level | Close the final range step so a Heavy Slash can land | smoking cookfire widening | 195/84 | 17.5 s |
| 169 | I strike Goblin Lookout A with a Heavy Slash. | Erzähler | open_run_level | Attack the lookout now at ENGAGED range | smoking cookfire widening | 177/84 | 17.6 s |
| 170 | I finish Goblin Lookout A with a Heavy Slash. | Erzähler | open_run_level | Kill the wounded goblin at ENGAGED range | smoking cookfire widening | 166/84 | 31.9 s |
| 171 | I strike Goblin Lookout B with a Heavy Slash. | Erzähler | open_run_level | Kill the last goblin at ENGAGED range | smoking cookfire widening | 156/84 | 18.1 s |
| 172 | I finish Goblin Lookout B with a Heavy Slash. | Erzähler | open_run_level | Kill the wounded last goblin | smoking cookfire widening | 156/84 | 25.2 s |
| 173 | #assign STR 3 VIT 2 | System (Befehl) | open_run_level | Spend level-up stat points on offense and survivability | smoking cookfire widening | 156/84 | 2.9 s |
| 174 | I loot the fallen goblins and continue down the passage deeper into the warren. | Erzähler | open_run_level | Advance the warren-clearing contract | glow-moss chamber | 156/84 | 26.4 s |
| 175 | I charge Goblin Spearman A and strike it with a Heavy Slash. | Erzähler | open_run_level | Engage the spearmen to clear the warren | glow-moss chamber | 156/84 | 18.8 s |
| 176 | I move to ENGAGED range with Goblin Spearman A and strike it with a Heavy Slash. | Erzähler | open_run_level | Close to melee range before attacking | glow-moss chamber | 150/84 | 17.6 s |
| 177 | I strike Goblin Spearman B with a Heavy Slash. | Erzähler | open_run_level | Kill the last spearman | glow-moss chamber | 144/84 | 15.7 s |
| 178 | I finish off Goblin Spearman B with a Basic Attack. | Erzähler | open_run_level | Kill the wounded last goblin | glow-moss chamber | 144/84 | 13.2 s |
| 179 | I continue down the main tunnel deeper into the warren. | Erzähler | open_run_level | Advance the warren-clearing contract | goblin camp chamber | 144/84 | 30.0 s |
| 180 | I stay hidden at the tunnel mouth and watch the camp, waiting to see if any goblin moves away from the fire where I could ambush it. | Erzähler | open_run_level | Scout the goblin camp for a favorable opening | goblin camp chamber | 144/84 | 30.0 s |
| 181 | I ambush the big goblin as it comes near the tunnel mouth, striking it with a Heavy Slash. | Engine (Menü/Rückfrage) | open_run_level | Kill the big goblin in ambush | goblin camp chamber | 144/84 | 6.7 s |
| 182 | I step out of hiding and charge the big goblin at the meat-lines, striking it with a Heavy Slash. | Engine (Menü/Rückfrage) | open_run_level | Ambush the big goblin now that it is in the open | goblin camp chamber | 144/84 | 8.1 s |
| 183 | I slip through the gap in the lashed-branch barrier into the pen and attack the large breathing creature with a Heavy Slash. | Erzähler | open_run_level | Enter the pen to engage the penned threat the System may then register as a target | goblin camp chamber | 144/84 | 33.7 s |
| 184 | I attack Penned Boar A with a Heavy Slash. | Erzähler | open_run_level | Engage the registered target | goblin camp chamber | 144/84 | 56.1 s |
| 185 | I move through the gap to close with Penned Boar A, then strike it with a Heavy Slash. | Erzähler | open_run_level | Close to ENGAGED range and attack the boar | goblin camp chamber | 133/84 | 23.4 s |
| 186 | I finish the boar with a Heavy Slash, then turn to face the small goblin at the gap. | Erzähler | open_run_level | Kill Penned Boar A and prepare for incoming goblins | goblin camp chamber | 133/84 | 28.6 s |
| 187 | I hold my position in the pen and strike the small goblin at the gap with a Heavy Slash through the lattice, ready to Guard if it or the oth… | Engine (Menü/Rückfrage) | open_run_level | Engage the hesitating small goblin from inside the pen | goblin camp chamber | 133/84 | 8.1 s |
| 188 | I step out through the gap in the barrier and advance on the small goblin with my sword raised. | Erzähler | open_run_level | Force engagement by leaving the pen and closing with the goblins | space behind the branch barrier | 133/84 | 45.0 s |
| 189 | I charge the Palisade Chief and attack it with a Heavy Slash. | Erzähler | open_run_level | Engage the registered target, the Palisade Chief | space behind the branch barrier | 120/84 | 23.5 s |
| 190 | I finish the wounded chief with a Heavy Slash before it can recover. | Erzähler | open_run_level | Kill the Palisade Chief while it is badly wounded | space behind the branch barrier | 105/84 | 35.3 s |
| 191 | I strike the chief again with a Heavy Slash to bring it down. | Erzähler | open_run_level | Finish the Palisade Chief | space behind the branch barrier | 105/84 | 43.0 s |
| 192 | #assign STR 3 VIT 2 | System (Befehl) | open_run_level | Spend level-up stat points | space behind the branch barrier | 105/84 | 3.0 s |
| 193 | I spare the trembling hide-scraper and turn back toward the camp chamber, checking the chief's dropped blade for anything worth taking. | Erzähler | open_run_level | Leave the spared goblin, loot the camp chamber | goblin camp chamber | 105/84 | 49.3 s |
| 194 | I take the chief's crude blade as loot, then head back up the entrance tunnel toward the surface. | Erzähler | open_run_level | Loot the camp sword and exit to rest and turn in cleared contracts | ledge above the flooded hollow | 105/84 | 28.9 s |
| 195 | I leave the flooded hollow alone and climb back up the tunnel toward the warren entrance, taking the passage I came in by. | Erzähler | open_run_level | Exit the warrens to rest and turn in the cleared contracts | Duskreach | 105/84 | 24.1 s |
| 196 | I travel to the Ashbridge Guild hall and turn in both cleared Mossback Warren contracts for their rewards. | Erzähler | open_run_level | Turn in cleared contracts | Adventurers' Guild hall, Ashbridge | 105/84 | 26.3 s |
| 197 | I check the Guild board for a new Novice contract I can take. | Erzähler | open_run_level | Pick a new Guild contract | Adventurers' Guild hall, Ashbridge | 105/84 | 28.3 s |
| 198 | I ask the front desk clerk to sign the eel-hound cull contract at the fish weirs as active, then I look for an inn where I can rest until mo… | Erzähler | open_run_level | Take the closest Novice contract and recover from low STA and HP | the Sow's Rest | 105/84 | 31.1 s |
| 199 | I take supper and a room from Marla, pay the two silver, and sleep until morning. | Engine (Menü/Rückfrage) | open_run_level | Pay for lodging and rest until morning to recover HP and STA | the Sow's Rest | 105/84 | 10.3 s |
| 200 | I pay the 20 cp as offered and take supper and a room, then sleep until morning. | Erzähler | open_run_level | Pay the correct offered price and rest until morning | the Sow's Rest | 235/84 | 17.0 s |
| 201 | I head downstream past the tannery lane to the fish weirs and hunt the eel-hound. | Erzähler | open_run_level | Hunt the eel-hound for the active contract | the fish weirs at the river shallows below Ashbridge | 235/84 | 26.2 s |
| 202 | I wade into the slack pool and attack the dark shadow among the basket frames, ready to fight if it is the eel-hound. | Erzähler | open_run_level | Hunt the eel-hound for the active contract | the third pool below the last weir | 234/84 | 56.3 s |
| 203 | I use Heavy Slash on the eel-hound. | Erzähler | open_run_level | Kill the eel-hound for the contract | the third pool below the last weir | 234/84 | 23.9 s |
| 204 | I haul the eel-hound's carcass out onto the bank and show the boy it's done, then head back to the Guild hall to turn in the contract. | Erzähler | open_run_level | Turn in the completed eel-hound cull contract | Adventurers' Guild hall, Ashbridge | 234/84 | 39.5 s |
| 205 | I ask the counter man to show me the open contracts board for a Novice-ranked job I can take next. | Erzähler | open_run_level | Pick a new Guild contract from the board | Adventurers' Guild hall, Ashbridge | 234/84 | 42.8 s |
| 206 | I accept the Cull Tusked Boars on the Old Quarry Track contract and head east along the quarry track to hunt boars. | Erzähler | open_run_level | Take the boar cull contract and travel to the hunting ground | the old quarry track east of Ashbridge | 234/84 | 43.4 s |
| 207 | I follow the fresh rooting sign into the oak scrub north of the track toward the heavy thing that moved, sword ready. | Erzähler | open_run_level | Hunt boars for the active contract | oak scrub north of the quarry track | 234/84 | 33.9 s |
| 208 | I meet its charge and swing Heavy Slash at the boar's head as it closes. | Erzähler | open_run_level | Fight Tusked Boar K | oak scrub north of the quarry track | 234/84 | 35.1 s |
| 209 | I sidestep the charge and swing Heavy Slash into the boar's flank now that it's in reach. | Erzähler | open_run_level | Fight Tusked Boar K at ENGAGED range | oak scrub north of the quarry track | 223/84 | 24.8 s |
| 210 | I finish it with a Basic Attack to the boar's head as it gathers for another charge. | Erzähler | open_run_level | Kill Tusked Boar K for the contract | oak scrub north of the quarry track | 223/84 | 44.6 s |
| 211 | I follow the cracked branch north through the scrub toward the older rooting, hunting the second contract boar. | Erzähler | open_run_level | Hunt boar 2 of 3 | boar wallow and rooting slope | 223/84 | 30.4 s |
| 212 | I stay behind the hawthorn and wait for the sow to turn or root toward me, then close and strike her first with Heavy Slash from her blind s… | Erzähler | open_run_level | Ambush Tusked Boar L for contract boar 2 of 3 | boar wallow and rooting slope | 223/84 | 20.1 s |
| 213 | I close the twenty paces toward the sow and engage her with Heavy Slash. | Erzähler | open_run_level | Close to ENGAGED and attack Tusked Boar L | boar wallow and rooting slope | 223/84 | 23.6 s |
| 214 | I move to ENGAGED range with Tusked Boar L, then strike her with Heavy Slash. | Erzähler | open_run_level | Close into range and attack the sow for contract boar 2 of 3 | boar wallow and rooting slope | 223/84 | 27.1 s |
| 215 | I circle wide through the oaks to approach Tusked Boar L from her flank, moving slowly and quietly until I am at ENGAGED range. | Erzähler | open_run_level | Close the distance with declared careful movement | boar wallow and rooting slope | 223/84 | 64.4 s |
| 216 | I continue the slow, careful loop down through the oaks toward Tusked Boar L's flank, closing to ENGAGED range, then strike her with Heavy S… | Erzähler | open_run_level | Continue flank approach and attack boar 2 of 3 | boar wallow and rooting slope | 223/84 | 22.1 s |
| 217 | I strike Tusked Boar L with Heavy Slash at SHORT range. | Erzähler | open_run_level | Attack contract boar 2 of 3 now that the HUD shows SHORT | boar wallow and rooting slope | 223/84 | 33.6 s |
| 218 | I rush the final stride and a half to close into ENGAGED range with Tusked Boar L, then strike her with Heavy Slash. | Erzähler | open_run_level | Close to ENGAGED and attack contract boar 2 of 3 | boar wallow and rooting slope | 214/84 | 20.0 s |
| 219 | I finish her with Heavy Slash. | Erzähler | open_run_level | Kill contract boar 2 of 3 | boar wallow and rooting slope | 214/84 | 26.9 s |
| 220 | I check the boar tracks and rooting signs around the wallow for fresh trail leading away, then follow the most recent prints to track the th… | Erzähler | open_run_level | Track and hunt the third contract boar | scrubby clearing in the green lane | 214/84 | 31.2 s |
| 221 | I rush from the hazel cover and strike Tusked Boar M with Heavy Slash before it lifts its head. | Erzähler | open_run_level | Kill the third contract boar | scrubby clearing in the green lane | 214/84 | 21.3 s |
| 222 | I run down the lane after the fleeing boar, following its fresh hoofprints, and strike it with Heavy Slash as soon as I close into range. | Erzähler | open_run_level | Chase and kill the third contract boar | scrubby clearing in the green lane | 214/84 | 21.4 s |
| 223 | I stalk north along the boar's fresh trail, moving quietly and using the scrub for cover, and if I find it stopped at a root patch, I close … | Erzähler | open_run_level | Stalk and kill the third contract boar | scrubby clearing in the green lane | 214/84 | 26.2 s |
| 224 | I strike Tusked Boar M with Heavy Slash now that it stands ENGAGED. | Erzähler | open_run_level | Kill the third contract boar from close range | scrubby clearing in the green lane | 214/84 | 20.6 s |
| 225 | I close the few paces to ENGAGED range and strike the wounded boar with Heavy Slash. | Erzähler | open_run_level | Kill the third contract boar | scrubby clearing in the green lane | 214/84 | 17.8 s |
| 226 | I head back along the green lane toward the Guild hall to turn in the completed boar cull, staying alert for whatever was moving up the lane… | Erzähler | open_run_level | Return to Guild and turn in the 3/3 boar contract | Adventurers' Guild hall, Ashbridge | 214/84 | 36.2 s |
| 227 | #assign STR 3 VIT 2 | System (Befehl) | open_run_level | Spend level-up points | Adventurers' Guild hall, Ashbridge | 214/84 | 2.9 s |
| 228 | I ask the counter man to show me the Guild board and point out contracts a Novice can handle alone. | Erzähler | open_run_level | Pick the next Guild contract | Adventurers' Guild hall, Ashbridge | 214/84 | 17.4 s |
| 229 | I take the Eel-Hound contract slip from the board and ask the counter man to register it as active. | Erzähler | open_run_level | Accept the eel-hound contract | Adventurers' Guild hall, Ashbridge | 214/84 | 19.8 s |
| 230 | I head down through the streets to the fish weirs at the river shallows and ask the weir-keepers which pool the eel-hound has been working. | Erzähler | open_run_level | Travel to the weirs and locate the eel-hound | the fish weirs at the river shallows below Ashbridge | 214/84 | 23.1 s |
| 231 | I ask the fisher which pool the eel-hound has been working, and whether it's likely to be in the water now. | Erzähler | open_run_level | Locate the eel-hound | the fish weirs at the river shallows below Ashbridge | 214/84 | 22.2 s |
| 232 | I wait at the bank by the third trap as the fisher advised, sword ready, letting the eel-hound come to the baskets. | Erzähler | open_run_level | Ambush the eel-hound at its working pool | the fish weirs at the river shallows below Ashbridge | 213/84 | 22.9 s |
| 233 | I swing a Heavy Slash at the eel-hound while it's still on the basket. | Erzähler | open_run_level | Kill the contract target | the fish weirs at the river shallows below Ashbridge | 213/84 | 18.9 s |
| 234 | I collect the pelt and fangs and head back up to the Guild hall in Duskreach to turn in the eel-hound contract. | Erzähler | open_run_level | Turn in the completed eel-hound contract at the Guild hall | Adventurers' Guild hall, Ashbridge | 213/84 | 24.8 s |
| 235 | I browse the Guild board for another achievable contract, avoiding the marsh serpent one. | Erzähler | open_run_level | Pick the next Guild contract | Adventurers' Guild hall, Ashbridge | 213/84 | 19.9 s |
| 236 | I take the crane-thinning contract slip from the board and accept it at the counter. | Erzähler | open_run_level | Accept the Reedmere cranes contract | Adventurers' Guild hall, Ashbridge | 213/84 | 15.0 s |
| 237 | Before heading out, I ask the merchant what he'd pay for eel-hound pelts and fangs. | Erzähler | open_run_level | Sell surplus loot before the crane hunt | Adventurers' Guild hall, Ashbridge | 213/84 | 20.5 s |
| 238 | I accept the merchant's offer and sell the five pelts and eleven fangs for thirty-one copper. | Erzähler | open_run_level | Sell the eel-hound loot at the agreed price | Adventurers' Guild hall, Ashbridge | 213/84 | 16.1 s |
| 239 | I book a bed for the night, then sleep until morning. | Erzähler | open_run_level | Recover overnight before the crane hunt at Reedmere | Adventurers' Guild hall, Ashbridge | 213/84 | 26.0 s |
| 240 | "I'll take the room, please — a silver, plus supper." Then I pay Marla, eat, and sleep until morning. | Erzähler | open_run_level | Book the room and sleep until morning | Adventurers' Guild hall, Ashbridge | 213/84 | 46.7 s |
| 241 | I book the room for the night and pay Marla the silver. | Erzähler | open_run_level | Actually book the room as its own step before sleeping | Adventurers' Guild hall, Ashbridge | 213/84 | 26.6 s |
| 242 | I set out east from Ashbridge toward Reedmere to hunt the Great Pale Cranes. | Erzähler | open_run_level | Travel to Reedmere for the crane contract | the reed banks of Reedmere north of the quarry track | 213/84 | 27.5 s |
| 243 | I move quietly into the reed banks toward where the crane called, using the reeds for cover and keeping downwind. | Erzähler | open_run_level | Stalk the Great Pale Cranes | the reed banks of Reedmere north of the quarry track | 213/84 | 26.9 s |
| 244 | I draw my longsword quietly and strike at the drowsed crane on the hummock with a Heavy Slash, aiming for its neck. | Erzähler | open_run_level | Ambush the isolated crane to open the hunt | the reed banks of Reedmere north of the quarry track | 213/84 | 20.9 s |
| 245 | I press the attack on the drowsed crane, following through with another Heavy Slash before it can fully rise. | Erzähler | open_run_level | Continue the crane ambush | the reed banks of Reedmere north of the quarry track | 213/84 | 25.6 s |
| 246 | I close the last stride and strike at Crane A with a Heavy Slash, aiming for its neck. | Erzähler | open_run_level | Engage and attack the nearest crane | the reed banks of Reedmere north of the quarry track | 192/84 | 20.9 s |
| 247 | I attack Great Pale Crane B with Heavy Slash. | Erzähler | open_run_level | Continue the crane fight | the reed banks of Reedmere north of the quarry track | 185/84 | 25.9 s |
| 248 | I strike at Great Pale Crane C with a Heavy Slash, aiming for its neck. | Erzähler | open_run_level | Finish the last crane | the reed banks of Reedmere north of the quarry track | 185/84 | 18.6 s |
| 249 | #assign STR 3 VIT 2 | System (Befehl) | open_run_level | Spend level-up stat points | the reed banks of Reedmere north of the quarry track | 185/84 | 3.3 s |
| 250 | I follow the distant crane call north beyond the reed line to find the fourth crane, and attack it with Heavy Slash when I reach it. | Erzähler | open_run_level | Hunt the fourth crane to finish the contract | shallow fen north of the reed line | 185/84 | 30.6 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 17 (notiert vor Zug 18): HUD location lags behind narration (still shows Guild hall); rested fully overnight.
- zu Zug 18 (notiert vor Zug 19): The engine priced the porridge separately; supper was included with the room but breakfast is not.
- zu Zug 21 (notiert vor Zug 22): System says 'no targetable actor' in the active scene despite the narrator's goblin; possible scene/target mismatch.
- zu Zug 23 (notiert vor Zug 24): Narrator shows a shrieking goblin but engine says active scene has no targetable actor; possible scene desync.
- zu Zug 24 (notiert vor Zug 25): Status confirms no active scene actors despite the HUD's goblin entry; likely scene desync, trying movement to re-sync.
- zu Zug 46 (notiert vor Zug 47): HUD shows HP 24/125 but STR/VIT already updated to 16/14; max HP may be higher now. Level 1 shows 2 of ? threats dealt with, so more remain.
- zu Zug 48 (notiert vor Zug 49): HP 24/135 vs chief HP 189 — far too wounded to fight; max HP rose to 135 after VIT assign.
- zu Zug 55 (notiert vor Zug 56): Engine refused Heavy Slash at MEDIUM range; the chief's guardian is unengaged and HP is only 64/135, so retreat is the sane play.
- zu Zug 56 (notiert vor Zug 57): Engine refused the combined retreat+rest earlier as 'arrival pending'; now at the mouth, so resting separately. Chief sits at MEDIUM range with a hidden guardian behind it — I should close properly and expect a second foe.
- zu Zug 59 (notiert vor Zug 60): System says the hollow has no targetable actor in an active scene — combat likely needs to be initiated, not just an attack declared.
- zu Zug 60 (notiert vor Zug 61): System twice says no targetable actor in active scene though narration shows the chief approaching; combat likely needs a System command to start.
- zu Zug 61 (notiert vor Zug 62): HUD says 'Present: nobody besides Alaric' in the hollow — the chief and guardian may not actually be here despite the threat notes.
- zu Zug 62 (notiert vor Zug 63): #combat says INACTIVE until hostile commitment and hollow shows nobody present despite threat notes; testing a declared attack.
- zu Zug 64 (notiert vor Zug 65): HUD still says 'Present: nobody besides Alaric' even as narration shows the chief attacking; combat target registration seems desynced.
- zu Zug 65 (notiert vor Zug 66): Chief narrated attacking while HUD says nobody present; combat scene seems desynced despite challenge and attack.
- zu Zug 67 (notiert vor Zug 68): Chief encounter is untargetable: combat stays INACTIVE with no valid target despite narration of attacks. Withdrawing to try other work.
- zu Zug 68 (notiert vor Zug 69): Chief encounter is persistently untargetable; withdrew from the warren. Warren quest still marked not cleared.
- zu Zug 70 (notiert vor Zug 71): Warren contract stays active with no time limit; chief encounter remains blocked but not a campaign blocker. Eel-hound job (rec. level 1, 25 cp) is the nearest achievable pick.
- zu Zug 73 (notiert vor Zug 74): HUD now shows Eel-Hound B as ENGAGED, so the range refusal is resolved.
- zu Zug 76 (notiert vor Zug 77): HUD still shows Mossback Warrens contract active (rec. level 1) — a sensible fallback; the boar contract (rec. level 5) is a step up but pays well.
- zu Zug 80 (notiert vor Zug 81): Engine now confirms the boar is ENGAGED; the earlier range refusal was just timing.
- zu Zug 92 (notiert vor Zug 93): Engine confirmed Tusked Boar C defeated, but the HUD quest count still reads 3/4 and the location line still lists the dead boar as present.
- zu Zug 93 (notiert vor Zug 94): Engine confirmed boar C defeated but quest panel still shows 3/4 and 'defeated: open'; location line still lists the dead boar as present.
- zu Zug 95 (notiert vor Zug 96): Mossback Warrens contract already shows as active on my slip; board lists it at 70 cp but quest panel says 60 cp — minor discrepancy.
- zu Zug 101 (notiert vor Zug 102): Engine said 'arrival pending' for sleeping despite narration placing me in the room; retrying with location named explicitly.
- zu Zug 102 (notiert vor Zug 103): Sleep recovered HP/STA fully. Boar quest stands at 3/4.
- zu Zug 105 (notiert vor Zug 106): Attack refused twice because the boar is not yet a targetable actor; need to enter its location first.
- zu Zug 108 (notiert vor Zug 109): Engine repeatedly refused attacks until the boar closed to ENGAGED; now the HUD confirms ENGAGED.
- zu Zug 114 (notiert vor Zug 115): Mossback Warrens slip still active; eel-hound pelt and fang loot in bag suggests prior eel-hound kills that may not count.
- zu Zug 119 (notiert vor Zug 120): Cull shows 1/1 defeated; still carries the active Mossback Warrens contract for later.
- zu Zug 133 (notiert vor Zug 134): Engine refused the charge twice claiming no declared movement; trying explicit movement plus attack in one declaration.
- zu Zug 134 (notiert vor Zug 135): Engine accepted movement this time: F went from LONG to SHORT after the sprint. All three boars are awake now.
- zu Zug 135 (notiert vor Zug 136): All three boars now SHORT; narrator treats one stride as enough to enter engaged range, so trying explicit step-to-engage plus attack.
- zu Zug 137 (notiert vor Zug 138): Cull counter reads 2/3 despite three boar carcasses narrated dead — the engine may not have counted one earlier kill.
- zu Zug 139 (notiert vor Zug 140): Cull counter reads 2/3 despite three narrated kills; both remaining boars still at MEDIUM range.
- zu Zug 141 (notiert vor Zug 142): Boars drifted to LONG; engine requires movement declared as its own action before attacking.
- zu Zug 146 (notiert vor Zug 147): Boar cull shows 3/3; contract should be ready to turn in at the Guild hall.
- zu Zug 148 (notiert vor Zug 149): Turn-in confirmed: +9 silver, +300 XP, XP 558/600 — nearly Level 7. Clerk flagged crane cull and marsh serpent as above rank.
- zu Zug 150 (notiert vor Zug 151): HUD shows the warrens contract accepted twice (two active copies, rewards 60 and 120 cp) — possible duplicate bug to watch.
- zu Zug 152 (notiert vor Zug 153): Sleep did not restore HP (still 88/195, wounded) despite full night's rest — recovery may need more than lodging.
- zu Zug 155 (notiert vor Zug 156): Mend practice after 2 hours produced only one faint flicker — skill not learned yet; may need repeated sessions. Duplicate active warrens contract still on the board.
- zu Zug 156 (notiert vor Zug 157): Sleep at Wren's Rest fully restored HP this time (88→195), unlike the earlier night. Duplicate active warrens contract persists.
- zu Zug 165 (notiert vor Zug 166): Three attack attempts were refused purely for range; movement must apparently be declared as its own action before attacking.
- zu Zug 167 (notiert vor Zug 168): Range ladder needs a separate move per band: MEDIUM→SHORT registered, but SHORT→ENGAGED still pending.
- zu Zug 181 (notiert vor Zug 182): System said no targetable actor despite narration placing the big goblin nearby; trying to enter combat explicitly.
- zu Zug 182 (notiert vor Zug 183): System twice reported no targetable actor despite narration placing goblins in the chamber; HUD also says 'Present: nobody besides Alaric' while narration shows a camp — possible scene-state desync.
- zu Zug 187 (notiert vor Zug 188): System repeatedly reports no targetable actor despite narration describing goblins present; combat seems to only register targets that attack or are registered like the boar.
- zu Zug 188 (notiert vor Zug 189): Combat target registration seems to require the System-registered actor; the small goblin was never targetable and fled.
- zu Zug 192 (notiert vor Zug 193): Level 8 confirmed, level 1 of warrens cleared; STA low at 29/100, HP 105/225 — recovery needed before deeper exploration.
- zu Zug 194 (notiert vor Zug 195): Level 1 is confirmed cleared this cycle; STA 29/100 and HP 105/235 make the large flooded-hollow threat unwise to probe now.
- zu Zug 195 (notiert vor Zug 196): HUD location reads 'Duskreach' though I am on the slope east of Ashbridge; possible location-label oddity.
- zu Zug 196 (notiert vor Zug 197): Both warren contracts paid out; XP 270/800, STA 29/100 low.
- zu Zug 213 (notiert vor Zug 214): Distance now shows LONG on the HUD; previous MEDIUM refusals stemmed from undeclared movement.
- zu Zug 216 (notiert vor Zug 217): HUD lists Tusked Boar L as SHORT while narration still describes her as beyond reach; trusting the HUD.
- zu Zug 220 (notiert vor Zug 221): Search roll failed but trail-following still found the third boar; count stands 2/3.
- zu Zug 222 (notiert vor Zug 223): Foot chase failed twice; Heavy Slash cannot reach LONG, so switching to stealth approach.
- zu Zug 225 (notiert vor Zug 226): Contract count confirmed 3/3; XP 796/800, one kill from level 9.
- zu Zug 233 (notiert vor Zug 234): Quest shows 1/1 defeated and ready for turn-in; kill was one-hit, good XP pacing.
- zu Zug 234 (notiert vor Zug 235): Payout confirmed at 3 silver (30 copper) despite narrator saying 'stack of copper'; level 9, XP 306/900.
- zu Zug 240 (notiert vor Zug 241): Engine keeps refusing sleep because the room was never booked despite paying narration; also the silver for the room apparently wasn't paid earlier.
- zu Zug 241 (notiert vor Zug 242): Room finally booked and night's sleep confirmed; location still shows Guild hall at 23:13 despite the sleep narration, so I'll treat travel as the next real step.
- zu Zug 242 (notiert vor Zug 243): Time shows 03:13 night despite arrival narration saying nearly noon; HUD location matches the reeds, so proceeding.
- zu Zug 243 (notiert vor Zug 244): Time still reads 03:33 night despite arrival narration saying nearly noon; HUD location matches, so proceeding.
- zu Zug 246 (notiert vor Zug 247): I took 21 damage in two rounds; HP 192/255, STA 47/100 — fine for now, but STA will run low if the fight drags.
- zu Zug 248 (notiert vor Zug 249): Engine shows quest at 3/4 defeated despite combat log listing three cranes defeated; a fourth crane is still needed.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t12 | 12 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t23 | 27 | 3 | – | nein | 3 | gewonnen, 158 XP |
| enc.t33 | 39 | 3 | – | nein | 3 | gewonnen, 158 XP |
| enc.t58 | 74 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t65 | 81 | 1 | – | nein | 1 | gewonnen, 102 XP |
| enc.t68 | 84 | 1 | – | nein | 1 | gewonnen, 124 XP |
| enc.t73 | 90 | 1 | – | nein | 1 | gewonnen, 154 XP |
| enc.t88 | 109 | 1 | – | nein | 1 | gewonnen, 224 XP |
| enc.t97 | 119 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t104 | 126 | 1 | – | nein | 1 | gewonnen, 102 XP |
| enc.t113 | 136 | 1 | – | nein | 1 | gewonnen, 102 XP |
| enc.t121 | 145 | 1 | – | nein | 1 | gewonnen, 124 XP |
| enc.t143 | 169 | 2 | – | nein | 2 | gewonnen, 236 XP |
| enc.t149 | 176 | 2 | – | nein | 2 | gewonnen, 184 XP |
| enc.t156 | 185 | 1 | – | ja | 1 | gewonnen, 128 XP |
| enc.t159 | 189 | 1 | – | nein | 1 | gewonnen, 238 XP |
| enc.t170r | 202 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t177 | 209 | 1 | – | nein | 1 | gewonnen, 152 XP |
| enc.t186 | 218 | 1 | – | nein | 1 | gewonnen, 124 XP |
| enc.t192 | 224 | 1 | – | nein | 1 | gewonnen, 180 XP |
| enc.t199r | 232 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t213 | 246 | 3 | – | nein | 3 | gewonnen, 696 XP |

## Quests

- **Cull the Snapping Eel-Hound at the Fish Weirs** — active (Zug 5) → completed (Zug 13), READY
  - Aufgabe: Kill 1 eel-hound at the fish weirs at the river shallows below Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 eel-hound killed at the fish weirs at the river shallows below Ashbridge.
- **Thin the Quarry Road Boar Sounder** — expired (Zug 70)
  - Aufgabe: Kill 4 tusked boars at the old quarry track east of Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 tusked boars killed at the old quarry track east of Ashbridge.
- **Break the Reedmere Ghost-Crane** — expired (Zug 70)
  - Aufgabe: Kill 1 great pale crane at the reed banks of Reedmere north of the quarry track. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 great pale crane killed at the reed banks of Reedmere north of the quarry track.
- **Cull the Barrow Fen Marsh Serpents** — expired (Zug 70)
  - Aufgabe: Kill 6 marsh serpents at the peat cuttings of Barrow Fen. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 6 marsh serpents killed at the peat cuttings of Barrow Fen.
- **Clear Mossback Warrens, Level 1** — active (Zug 15) → completed (Zug 196), Dungeon loc.mossback_warrens Ebene 1
  - Aufgabe: Clear level 1 of Mossback Warrens. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Mossback Warrens is clear.
- **Cull the Eel-Hound at the Fish Weirs** — active (Zug 71) → completed (Zug 75), READY
  - Aufgabe: Kill 1 eel-hound at the fish weirs at the river shallows below Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 eel-hound killed at the fish weirs at the river shallows below Ashbridge.
- **Cull the Tusked Boars on the Old Quarry Track** — active (Zug 77) → completed (Zug 113)
  - Aufgabe: Kill 4 tusked boar at the old quarry track east of Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 tusked boar killed at the old quarry track east of Ashbridge.
- **Cull the Great Pale Cranes of Reedmere** — expired (Zug 114)
  - Aufgabe: Kill 3 great pale crane at the reed banks of Reedmere north of the quarry track. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 great pale crane killed at the reed banks of Reedmere north of the quarry track.
- **Cull the Marsh Serpent of Barrow Fen** — expired (Zug 114)
  - Aufgabe: Kill 1 marsh serpent at the peat cuttings of Barrow Fen. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 marsh serpent killed at the peat cuttings of Barrow Fen.
- **Clear Mossback Warrens Level 1** — expired (Zug 114), Dungeon loc.mossback_warrens Ebene 1
  - Aufgabe: Clear level 1 of Mossback Warrens. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Mossback Warrens is clear.
- **Cull the Eel-Hound at the Fish Weirs** — active (Zug 115) → completed (Zug 120)
  - Aufgabe: Kill 1 eel-hound at the fish weirs at the river shallows below Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 eel-hound killed at the fish weirs at the river shallows below Ashbridge.
- **Cull Tusked Boars on the Old Quarry Track** — active (Zug 122) → completed (Zug 148)
  - Aufgabe: Kill 3 tusked boar at the old quarry track east of Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 tusked boar killed at the old quarry track east of Ashbridge.
- **Cull the Great Pale Cranes of Reedmere** — expired (Zug 197)
  - Aufgabe: Kill 2 great pale crane at the reed banks of Reedmere north of the quarry track. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 2 great pale crane killed at the reed banks of Reedmere north of the quarry track.
- **Cull the Marsh Serpent of Barrow Fen** — expired (Zug 197)
  - Aufgabe: Kill 1 marsh serpent at the peat cuttings of Barrow Fen. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 marsh serpent killed at the peat cuttings of Barrow Fen.
- **Clear Mossback Warrens, Level 1** — active (Zug 150) → completed (Zug 196), Dungeon loc.mossback_warrens Ebene 1
  - Aufgabe: Clear level 1 of Mossback Warrens. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Mossback Warrens is clear.
- **Cull the Eel-Hound at the Fish Weirs** — active (Zug 198) → completed (Zug 204)
  - Aufgabe: Kill 1 eel-hound at the fish weirs at the river shallows below Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 eel-hound killed at the fish weirs at the river shallows below Ashbridge.
- **Cull Four Tusked Boars on the Old Quarry Track** — expired (Zug 205)
  - Aufgabe: Kill 4 tusked boar at the old quarry track east of Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 tusked boar killed at the old quarry track east of Ashbridge.
- **Cull the Great Pale Cranes of Reedmere** — expired (Zug 205)
  - Aufgabe: Kill 3 great pale crane at the reed banks of Reedmere north of the quarry track. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 great pale crane killed at the reed banks of Reedmere north of the quarry track.
- **Cull the Marsh Serpent of Barrow Fen** — expired (Zug 205)
  - Aufgabe: Kill 1 marsh serpent at the peat cuttings of Barrow Fen. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 marsh serpent killed at the peat cuttings of Barrow Fen.
- **Clear Mossback Warrens Level 1** — expired (Zug 205), Dungeon loc.mossback_warrens Ebene 1
  - Aufgabe: Clear level 1 of Mossback Warrens. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Mossback Warrens is clear.
- **Cull the Eel-Hound at the Fish Weirs** — active (Zug 229) → completed (Zug 234)
  - Aufgabe: Kill 1 eel-hound at the fish weirs at the river shallows below Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 eel-hound killed at the fish weirs at the river shallows below Ashbridge.
- **Cull Tusked Boars on the Old Quarry Track** — active (Zug 206) → completed (Zug 226)
  - Aufgabe: Kill 3 tusked boar at the old quarry track east of Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 tusked boar killed at the old quarry track east of Ashbridge.
- **Thin the Great Pale Cranes of Reedmere** — active (Zug 236)
  - Aufgabe: Kill 4 great pale crane at the reed banks of Reedmere north of the quarry track. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 great pale crane killed at the reed banks of Reedmere north of the quarry track.

## Auffälligkeiten

- Zug 7, Nachricht 13 (planner_repaired): the planner's first answer needed a repair
- Zug 8, Nachricht 15 (planner_repaired): the planner's first answer needed a repair
- Zug 9, Nachricht 17 (planner_repaired): the planner's first answer needed a repair
- Zug 15, Nachricht 30 (extraction_repaired): the extractor's first answer needed a repair
- Zug 16, Nachricht 32 (extraction_repaired): the extractor's first answer needed a repair
- Zug 20, Nachricht 40 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (goblin): refused, no fight (Patch 8.4.1 guard)
- Zug 25, Nachricht 50 (extraction_repaired): the extractor's first answer needed a repair
- Zug 32, Nachricht 64 (extraction_repaired): the extractor's first answer needed a repair
- Zug 54, Nachricht 108 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (goblin chief): refused, no fight (Patch 8.4.1 guard)
- Zug 56, Nachricht 112 (extraction_repaired): the extractor's first answer needed a repair
- Zug 58, Nachricht 115 (planner_repaired): the planner's first answer needed a repair
- Zug 58, Nachricht 116 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (goblin chief): refused, no fight (Patch 8.4.1 guard)
- Zug 64, Nachricht 128 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (Palisade Chief): refused, no fight (Patch 8.4.1 guard)
- Zug 68, Nachricht 136 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (goblin): refused, no fight (Patch 8.4.1 guard)
- Zug 71, Nachricht 141 (planner_repaired): the planner's first answer needed a repair
- Zug 74, Nachricht 148 (extraction_repaired): the extractor's first answer needed a repair
- Zug 79, Nachricht 158 (extraction_repaired): the extractor's first answer needed a repair
- Zug 99, Nachricht 197 (planner_repaired): the planner's first answer needed a repair
- Zug 100, Nachricht 199 (planner_repaired): the planner's first answer needed a repair
- Zug 101, Nachricht 202 (extraction_repaired): the extractor's first answer needed a repair
- Zug 103, Nachricht 206 (extraction_repaired): the extractor's first answer needed a repair
- Zug 117, Nachricht 234 (extraction_repaired): the extractor's first answer needed a repair
- Zug 118, Nachricht 236 (extraction_repaired): the extractor's first answer needed a repair
- Zug 166, Nachricht 332 (extraction_repaired): the extractor's first answer needed a repair
- Zug 179, Nachricht 358 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (goblin scout): refused, no fight (Patch 8.4.1 guard)
- Zug 179, Nachricht 358 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (big goblin): refused, no fight (Patch 8.4.1 guard)
- Zug 180, Nachricht 360 (extraction_repaired): the extractor's first answer needed a repair
- Zug 180, Nachricht 360 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (goblin): refused, no fight (Patch 8.4.1 guard)
- Zug 180, Nachricht 360 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (goblin): refused, no fight (Patch 8.4.1 guard)
- Zug 180, Nachricht 360 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (goblin): refused, no fight (Patch 8.4.1 guard)
- Zug 180, Nachricht 360 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (large penned creature): refused, no fight (Patch 8.4.1 guard)
- Zug 182, Nachricht 363 (planner_repaired): the planner's first answer needed a repair
- Zug 183, Nachricht 366 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (large goblin): refused, no fight (Patch 8.4.1 guard)
- Zug 183, Nachricht 366 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (goblin): refused, no fight (Patch 8.4.1 guard)
- Zug 183, Nachricht 366 (unslotted_dungeon_creature): penned boar came into Mossback Warrens without an encounter of the engine (for review)
- Zug 185, Nachricht 370 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (goblin scout): refused, no fight (Patch 8.4.1 guard)
- Zug 186, Nachricht 372 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (goblin): refused, no fight (Patch 8.4.1 guard)
- Zug 186, Nachricht 372 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (goblin): refused, no fight (Patch 8.4.1 guard)
- Zug 186, Nachricht 372 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (goblin): refused, no fight (Patch 8.4.1 guard)
- Zug 188, Nachricht 375 (planner_repaired): the planner's first answer needed a repair
- Zug 188, Nachricht 376 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (goblin): refused, no fight (Patch 8.4.1 guard)
- Zug 188, Nachricht 376 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (goblin): refused, no fight (Patch 8.4.1 guard)
- Zug 188, Nachricht 376 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (goblin): refused, no fight (Patch 8.4.1 guard)
- Zug 189, Nachricht 378 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (goblin warrior): refused, no fight (Patch 8.4.1 guard)
- Zug 189, Nachricht 378 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (goblin warrior): refused, no fight (Patch 8.4.1 guard)
- Zug 191, Nachricht 382 (unslotted_dungeon_creature): goblin hide-scraper came into Mossback Warrens without an encounter of the engine (for review)
- Zug 193, Nachricht 386 (extraction_repaired): the extractor's first answer needed a repair
- Zug 194, Nachricht 388 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (giant pond shells): refused, no fight (Patch 8.4.1 guard)
- Zug 197, Nachricht 394 (extraction_repaired): the extractor's first answer needed a repair
- Zug 198, Nachricht 396 (extraction_repaired): the extractor's first answer needed a repair
- Zug 199, Nachricht 397 (planner_repaired): the planner's first answer needed a repair
- Zug 206, Nachricht 411 (planner_repaired): the planner's first answer needed a repair
- Zug 206, Nachricht 412 (extraction_repaired): the extractor's first answer needed a repair
- Zug 220, Nachricht 440 (extraction_repaired): the extractor's first answer needed a repair
- Zug 226, Nachricht 452 (extraction_repaired): the extractor's first answer needed a repair
- Zug 240, Nachricht 479 (planner_repaired): the planner's first answer needed a repair
- Zug 250, Nachricht 499 (planner_repaired): the planner's first answer needed a repair
- Zug 196, Nachricht 392 (turn_in): Clear Mossback Warrens, Level 1: turned in at a Guild hall, payout 180 cp booked for a contract of 60 cp
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 28× keine gültige JSON-Entscheidung (Züge 7, 9, 15, 34, 49, 55, 56, 64, 69, 73, 83, 92, 94, 104, 119, 124, 126, 128, 131, 132, 158, 160, 180, 192, 218, 223, 227, 232)

System-Panels: CLARIFY 7, NOT TAKEN 3, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: guild_canon 3, ambient 5, guild_payout 3, engine_owned_fact 24, engine_owned_memory 3, no_go 4, scene_context 28, engine_recovery 2, dungeon_foe 23, world_rule 52, group_unclear 5, attack_commitment 8, recover 1, pc_inventory 3, quest_count 3, guild_completion 2, time_cap 3, dungeon_foe_thread 1, quest_dependency 2, domain_fact 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 28/250 Erstantworten ungültig (11.2 %); 28 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 247 | 13 | 2.5 s | 4.7 s | 12190 | 9828 | 75 | – | stop 247 | 0 |
| board | 6 | 1 | 9.6 s | 11.3 s | 2473 | 2154 | 1136 | – | stop 6 | 0 |
| narrator | 214 | 0 | 8.6 s | 13.7 s | 11464 | 8747 | 379 | – | stop 214 | 0 |
| extract | 233 | 19 | 5.4 s | 9.8 s | 12458 | 9279 | 321 | – | stop 233 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 105:30 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 15.7 s) | 0:31 min |
| 250 Züge, Spiel (Senden bis HUD nach der Extraktion) | 85:38 min — Median 19.5 s, p90 31.9 s, max 64.4 s |
| 250 Züge, Spieler-Entscheidung | 13:35 min — Median 2.5 s, 28 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 13:10 min / 0:57 min / 36:05 min / 24:13 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 23.8 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 15:52 min, 80 Züge ≈ 31:45 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spiel | 215 | – | 64.4 s | 19.5 s |
| Provider narrator | 184 | 501 | 45.1 s | 8.6 s |
| Provider narrator | 202 | 554 | 31.0 s | 8.6 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
