# Avereth Live-Test 20261027-173743Z-current_test

## Kurzfassung

- **Laufprofil:** guild-rogue; Startklasse Rogue, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** Niederlage — turn 87: he died
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 2. Sicherheitsgrenzen: 250 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** noch nicht erreicht.
- **Charakter:** rogue (rogue.razor_cut, rogue.evasive_step) · Regelstand 2 (Warrior, Mage, Rogue)
- **Ziel-Dungeon:** Glimmerdeep Grotto, Ebene 1 (Vertrag quest.clear_glimmerdeep_grotto_level_1_2)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: cautious adventurer: prepare and recover, weigh threats and withdraw when sensible
- **Züge:** 87 · **Dauer:** 41:42 min · **LLM-Aufrufe der Engine/des Erzählers:** 219
- **Beobachtete Abdeckung:** 14 unterschiedliche gebuchte Reiseziele · 3 Kämpfe · 1 Verkäufe (14 cp Umsatz, ohne Questzahlungen/Geschenke) · 0 Ausrüstungswechsel · 0 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 6 · **Niederlage** in Zug 87: he died
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.102 |
| Git | 57ec7f6ef982 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 15.8 s |
| Browser | chrome 156.0.8078.48 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261027-173743Z-current_test“, Seed 1604207990 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | I choose Rogue. | Engine (Menü/Rückfrage) | creation_complete | Select Rogue class | public roadside verge outside Glassmere | 90/84 | 2.3 s |
| 2 | I choose Razor Cut and Evasive Step. | Engine (Menü/Rückfrage) | creation_complete | Finish Rogue creation with two starter skills | public roadside verge outside Glassmere | 90/84 | 2.1 s |
| 3 | I walk along the road to Glassmere and head for the Adventurers' Guild hall to look at the contract board. | Erzähler | open_run_level | Reach the Guild and find a first F-rank contract | Adventurers' Guild hall, Glassmere | 90/84 | 71.7 s |
| 4 | I approach the clerk and ask to register with the Guild as a novice adventurer, then request to take the 'Cull the One-Eared Wolf of the Tan… | Erzähler | open_run_level | Register with Guild and accept first F-rank contract | Adventurers' Guild hall, Glassmere | 90/84 | 21.3 s |
| 5 | I hand the clerk two silver and mark the sheet. | Erzähler | open_run_level | Pay registration fee to complete Guild registration | Adventurers' Guild hall, Glassmere | 90/84 | 21.5 s |
| 6 | I ask the clerk to take the 'Cull the One-Eared Wolf of the Tannery Road' contract. | Erzähler | open_run_level | Accept first F-rank contract now that registration is done | Adventurers' Guild hall, Glassmere | 90/84 | 20.0 s |
| 7 | I leave the Guild and head west along Tannery Road to hunt the one-eared wolf. | Erzähler | open_run_level | Travel to the tannery racks and find the contract wolf | the hide-drying racks along the Tannery Road outside Glassmere | 90/84 | 23.9 s |
| 8 | I thank the tanner and head toward the lime pits to search for the wolf. | Erzähler | open_run_level | Track the contract wolf to the lime pits | the lime pits beyond the hide racks | 90/84 | 17.9 s |
| 9 | I move quietly along the pit rims, checking each shaded pit and the lean-to's sacking for the wolf. | Erzähler | open_run_level | Locate the bedded-down wolf | the lime pits beyond the hide racks | 90/84 | 16.6 s |
| 10 | I widen the search toward the deeper ash trees at the basin's rim, looking for trampled ground, flattened grass, or a day-bed hollow. | Erzähler | open_run_level | Locate the wolf's day-bed in the deeper ash trees | the lime pits beyond the hide racks | 90/84 | 19.9 s |
| 11 | I circle back to the pits and check the tracks again, following the freshest line of prints where they leave the basin toward wherever they … | Erzähler | open_run_level | Track the wolf out of the basin by following its trail | the Tannery Road verge by the ditch | 90/84 | 42.5 s |
| 12 | I follow the road right toward the hide racks, watching the ditch bank and verges for the wolf or fresh sign. | Erzähler | open_run_level | Track the wolf along the road toward the racks | the hide-drying racks along the Tannery Road outside Glassmere | 90/84 | 22.6 s |
| 13 | I walk over to the tanner and greet him. "I'm hunting the one-eared wolf that's been at your racks. Have you seen it — and which way does it… | Erzähler | open_run_level | Question the tanner about the wolf's habits and direction | the hide-drying racks along the Tannery Road outside Glassmere | 90/84 | 22.5 s |
| 14 | I head down to the farthest rack and look for Heddwyn. "Your dog stares north at night, I hear — I'm hunting the wolf that's been raiding th… | Erzähler | open_run_level | Question Heddwyn about the wolf | the farthest rack by the hedgerow | 90/84 | 37.1 s |
| 15 | I thank Heddwyn and find a concealed spot with a clear view of the hedge gap, settling in to wait for dusk. | Erzähler | open_run_level | Ambush the wolf at the hedge gap after dark | the hollow under the leaning hawthorn | 90/84 | 53.2 s |
| 16 | I settle into the hollow under the hawthorn and wait, watching the hedge gap as the light fades toward dusk. | Erzähler | open_run_level | Ambush the wolf at the hedge gap after dark | the hollow under the leaning hawthorn | 90/84 | 24.8 s |
| 17 | I keep watch on the hedge gap from the hollow, bow ready, waiting for the wolf to come. | Erzähler | open_run_level | Ambush the wolf at the gap | the hollow under the leaning hawthorn | 90/84 | 26.4 s |
| 18 | I draw and loose an arrow at the wolf's flank, then nock another and stay low in the hollow. | Erzähler | open_run_level | Ambush shot at the wolf | the hollow under the leaning hawthorn | 90/84 | 24.6 s |
| 19 | I crawl low along the hedge toward the gap, circling to close the distance on the wolf along its own worn road. | Erzähler | open_run_level | Close to ENGAGED range before attacking | the hollow under the leaning hawthorn | 90/84 | 23.9 s |
| 20 | I keep crawling forward along the worn road until the wolf is in ENGAGED range, then strike with Razor Cut. | Erzähler | open_run_level | Close to ENGAGED and attack the wolf | the hollow under the leaning hawthorn | 90/84 | 24.6 s |
| 21 | I stay flat and still beside the hedge, letting the silence stretch, waiting to see if the wolf comes to investigate the gap or loses intere… | Erzähler | open_run_level | Let the wary wolf close the distance or relax before acting | the hollow under the leaning hawthorn | 90/84 | 23.3 s |
| 22 | I move to ENGAGED range with Gray Wolf A along its worn road, then strike with Razor Cut. | Erzähler | open_run_level | Explicitly close to ENGAGED and attack the wolf | the hollow under the leaning hawthorn | 90/84 | 19.7 s |
| 23 | I move to ENGAGED range with Gray Wolf A, then attack it with Razor Cut. | Erzähler | open_run_level | Close to ENGAGED and attack the wolf | the hollow under the leaning hawthorn | 90/84 | 28.6 s |
| 24 | I strike at the wolf with Razor Cut. | Erzähler | open_run_level | Attack the now-ENGAGED wolf with Razor Cut | the hollow under the leaning hawthorn | 90/84 | 19.9 s |
| 25 | I collect the pelt and fang from the dead wolf, then take the Tannery Road back to the Caelreth Guild hall to turn in the contract. | Erzähler | open_run_level | Return to Guild hall and turn in the completed wolf contract | Adventurers' Guild hall, Glassmere | 90/84 | 34.8 s |
| 26 | I ask the clerk what Novice contracts are on the board, and whether the Guild has a bed for the night. | Erzähler | open_run_level | Check board and lodging | Adventurers' Guild hall, Glassmere | 90/84 | 24.9 s |
| 27 | I take the key and pay one copper for the bunk, then go upstairs and sleep until morning. | Erzähler | open_run_level | Buy Guild lodging and sleep to recover | Guild room upstairs | 90/84 | 26.2 s |
| 28 | I lie down on the straw tick and sleep until morning. | Erzähler | open_run_level | Sleep in the Guild room to recover | Guild room upstairs | 90/84 | 25.1 s |
| 29 | I go downstairs and accept the Clear Glimmerdeep Grotto, Level 1 contract from the clerk. | Erzähler | open_run_level | Accept the Glimmerdeep Grotto Novice contract | Adventurers' Guild hall, Glassmere | 90/84 | 22.0 s |
| 30 | I ask the clerk what Novice contracts are on this morning's board. | Erzähler | open_run_level | Pick a new achievable contract | Adventurers' Guild hall, Glassmere | 90/84 | 127.8 s |
| 31 | I accept the fresh Clear Glimmerdeep Grotto, Level 1 contract from the clerk. | Erzähler | open_run_level | Accept the reposted Glimmerdeep Grotto contract | Adventurers' Guild hall, Glassmere | 90/84 | 33.9 s |
| 32 | I take the slip and set out north along the Coldharbor road toward the Glimmerdeep Grotto mouth, keeping left at the shrine stone fork. | Erzähler | open_run_level | Travel to Glimmerdeep Grotto for the active contract | the mouth of Glimmerdeep Grotto | 90/84 | 32.6 s |
| 33 | I draw my dagger and step into the grotto mouth, moving carefully toward the clicking sound. | Erzähler | open_run_level | Enter Glimmerdeep Grotto and clear level 1 | the mouth of Glimmerdeep Grotto | 90/84 | 25.0 s |
| 34 | I strike at the nearest alert beetle with my dagger. | Engine (Menü/Rückfrage) | open_run_level | Engage the beetles to thin them per the contract | the mouth of Glimmerdeep Grotto | 90/84 | 4.8 s |
| 35 | I step fully into the crystal chamber and strike at the nearest beetle with my dagger. | Engine (Menü/Rückfrage) | open_run_level | Enter the chamber scene so the beetles become targetable, then attack | the mouth of Glimmerdeep Grotto | 90/84 | 4.3 s |
| 36 | Basic Attack on the nearest beetle. | Engine (Menü/Rückfrage) | open_run_level | Answer the clarify prompt and attack the nearest beetle with Basic Attack | the mouth of Glimmerdeep Grotto | 90/84 | 4.0 s |
| 37 | I walk deeper into the grotto toward the crystal chamber, looking for the beetles. | Erzähler | open_run_level | Move into the chamber as pure movement so beetles become targetable | the mouth of Glimmerdeep Grotto | 90/84 | 25.0 s |
| 38 | Basic Attack on the nearest alert beetle facing me. | Engine (Menü/Rückfrage) | open_run_level | Attack now that beetles are present in the entered chamber | the mouth of Glimmerdeep Grotto | 90/84 | 5.6 s |
| 39 | #help | System (Befehl) | open_run_level | Find the correct combat/targeting syntax | the mouth of Glimmerdeep Grotto | 90/84 | 2.2 s |
| 40 | #combat | System (Befehl) | open_run_level | Inspect the encounter state to find why no beetle is targetable | the mouth of Glimmerdeep Grotto | 90/84 | 2.2 s |
| 41 | I draw my dagger and engage the clicking beetles deeper in the grotto, striking the nearest one with Basic Attack. | Engine (Menü/Rückfrage) | open_run_level | Make a hostile commitment to activate combat | the mouth of Glimmerdeep Grotto | 90/84 | 5.1 s |
| 42 | #system The scene shows beetles but no targetable actor. How do I declare a hostile commitment so combat becomes ACTIVE? | Erzähler | open_run_level | Learn the mechanics for activating combat in this scene | the mouth of Glimmerdeep Grotto | 90/84 | 12.8 s |
| 43 | I attack the nearest crystal beetle with my dagger. | Engine (Menü/Rückfrage) | open_run_level | Declare a hostile commitment to activate combat with the beetles | the mouth of Glimmerdeep Grotto | 90/84 | 5.9 s |
| 44 | I walk deeper into the grotto toward the clicking sound, and once I can see the beetles, I attack the nearest one with my dagger. | Erzähler | open_run_level | Enter the grotto proper so the beetles register as actors, then attack | the mouth of Glimmerdeep Grotto | 90/84 | 25.2 s |
| 45 | #combat | System (Befehl) | open_run_level | Check whether combat became ACTIVE after the strike | the mouth of Glimmerdeep Grotto | 90/84 | 2.2 s |
| 46 | I commit to hostile action: I draw my dagger and fight the beetle at the base of the pitted wall, striking it with Basic Attack. | Engine (Menü/Rückfrage) | open_run_level | Declare explicit hostile commitment to activate combat | the mouth of Glimmerdeep Grotto | 90/84 | 4.3 s |
| 47 | I strike the nearest crystal beetle with my dagger, committing to hostile action. | Engine (Menü/Rückfrage) | open_run_level | Activate combat with a simple target name | the mouth of Glimmerdeep Grotto | 90/84 | 3.8 s |
| 48 | I step past the daylight into the dark of the grotto and advance toward the clicking, then attack a beetle with my dagger. | Erzähler | open_run_level | Move into the beetles' location so a targetable actor initializes, then attack | the mouth of Glimmerdeep Grotto | 90/84 | 30.2 s |
| 49 | I strike the beetle facing me — the one whose antennae fixed on me — with my dagger. | Engine (Menü/Rückfrage) | open_run_level | Attack an initialized beetle now that I'm inside the chamber | the mouth of Glimmerdeep Grotto | 90/84 | 5.1 s |
| 50 | I attack the Crystal Beetle with my dagger. | Engine (Menü/Rückfrage) | open_run_level | Use the plain creature name as target to initialize combat | the mouth of Glimmerdeep Grotto | 90/84 | 3.8 s |
| 51 | I use Razor Cut on a crystal beetle. | Engine (Menü/Rückfrage) | open_run_level | Try a named skill to initialize combat with the beetles | the mouth of Glimmerdeep Grotto | 90/84 | 3.7 s |
| 52 | I walk deeper into the grotto, past the daylight, toward the clicking sound, and once I can see a beetle I attack it with my dagger. | Erzähler | open_run_level | Move fully into the grotto so beetles become targetable, then attack | the mouth of Glimmerdeep Grotto | 90/84 | 28.1 s |
| 53 | I strike the nearest beetle — the one whose antennae fixed on me — with my dagger. | Engine (Menü/Rückfrage) | open_run_level | Initialize combat with the beetles now that the narrator shows me striking one in the cham… | the mouth of Glimmerdeep Grotto | 90/84 | 4.6 s |
| 54 | I attack the beetle. | Engine (Menü/Rückfrage) | open_run_level | Initialize combat with the plain singular creature name | the mouth of Glimmerdeep Grotto | 90/84 | 3.8 s |
| 55 | #quest Clear Glimmerdeep Grotto | System (Befehl) | open_run_level | Inspect the active quest to see what the System expects for clearing the grotto | the mouth of Glimmerdeep Grotto | 90/84 | 2.1 s |
| 56 | The contract has expired, so I leave the grotto and travel back to the Caelreth Guild hall to return the expired slip and pick a new contrac… | Erzähler | open_run_level | Abandon the expired grotto contract and take fresh Guild work | Adventurers' Guild hall, Glassmere | 90/84 | 22.1 s |
| 57 | I take the Cull the Rack-Raiding Wolf contract from the board and ask the clerk to register it for me. | Erzähler | open_run_level | Accept a fresh achievable Guild contract | Adventurers' Guild hall, Glassmere | 90/84 | 23.9 s |
| 58 | I travel west out of the south gate along the Tannery Road to the hide-drying racks and look for the gray wolf. | Erzähler | open_run_level | Hunt the contract wolf at the racks | the hide-drying racks along the Tannery Road outside Glassmere | 90/84 | 18.3 s |
| 59 | I tell Oddren I'll wait for dusk and ask if there's a good hiding spot near the racks. | Erzähler | open_run_level | Prepare an ambush for the wolf until it arrives after dark | the hide-drying racks along the Tannery Road outside Glassmere | 90/84 | 29.0 s |
| 60 | I move toward the hedge forty paces south and attack the gray wolf feeding at the heap. | Erzähler | open_run_level | Engage the contract wolf now that it's nearby | the trodden feeding patch by the hedge | 90/84 | 26.0 s |
| 61 | I go back to the ditch behind the bramble by the fence gap and settle in to wait for dusk. | Erzähler | open_run_level | Ambush the wolf at dusk from Oddren's recommended cover | the ditch behind the bramble by the fence gap | 90/84 | 54.5 s |
| 62 | I stay low in the ditch, watching the bank across the yard and waiting for the wolf to commit to the racks — then I attack it from cover wit… | Erzähler | open_run_level | Ambush the wolf as it comes down from the bank | the ditch behind the bramble by the fence gap | 90/84 | 19.7 s |
| 63 | I burst from the ditch and lunge at the wolf's flank with Razor Cut while it's distracted pulling the hide. | Erzähler | open_run_level | Attack the contract wolf from ambush | the ditch behind the bramble by the fence gap | 90/84 | 26.5 s |
| 64 | I sprint the ten paces straight at the wolf and, once I'm in reach, slash its flank with Razor Cut. | Erzähler | open_run_level | Close to ENGAGED and attack the contract wolf | the ditch behind the bramble by the fence gap | 90/84 | 38.6 s |
| 65 | While the wolf is turned toward Oddren's light, I sprint the ten paces and slash its flank with Razor Cut the moment I'm in reach. | Erzähler | open_run_level | Close distance and attack the distracted wolf | the ditch behind the bramble by the fence gap | 90/84 | 27.2 s |
| 66 | I step around the rack rows straight at the wolf and, once I'm ENGAGED, slash its flank with Razor Cut. | Erzähler | open_run_level | Close to ENGAGED and attack the wolf | the ditch behind the bramble by the fence gap | 90/84 | 32.6 s |
| 67 | "I'm Alaric Red, a Guild novice — that wolf was the one on my cull contract. It came in through the fence gap by the bramble." | Erzähler | open_run_level | Answer Oddren and confirm the kill | the ditch behind the bramble by the fence gap | 90/84 | 25.2 s |
| 68 | I follow Oddren inside and take the offered seat by the fire. | Erzähler | open_run_level | Accept Oddren's hospitality and hear what he offers | inside the tannery shed | 90/84 | 25.1 s |
| 69 | "Three weeks at the Guild, and this cull was my first real job — the ditch just seemed the honest way to wait it out." | Erzähler | open_run_level | Answer Oddren's question and build rapport | inside the tannery shed | 90/84 | 32.7 s |
| 70 | I take the pelt with a grin. "Thank you, Oddren — I'll drink to that." I finish the cider and ask if he'll buy the two wolf pelts off the be… | Erzähler | open_run_level | Accept gift pelt and ask about selling the wolf pelts | inside the tannery shed | 90/84 | 18.3 s |
| 71 | "Fourteen copper the pair — done, Oddren." I hand over the two pelts and take the coin. | Erzähler | open_run_level | Accept Oddren's offer and sell both wolf pelts | inside the tannery shed | 90/84 | 23.9 s |
| 72 | I thank Oddren for the fire and head back to Glassmere to turn in the wolf cull at the Guild hall. | Erzähler | open_run_level | Return to Guild and turn in the completed cull contract | Adventurers' Guild hall, Glassmere | 90/84 | 40.3 s |
| 73 | #assign AGI 2 PER 2 WIL 1 | System (Befehl) | open_run_level | Spend level-up points and then check the contract board | Adventurers' Guild hall, Glassmere | 90/84 | 2.2 s |
| 74 | I ask the clerk what contracts are on the board suitable for a Novice Rogue, and whether any pay well for a quick morning's work. | Erzähler | open_run_level | Check the Guild board for a new achievable contract | Adventurers' Guild hall, Glassmere | 90/84 | 30.7 s |
| 75 | I take the bog strider contract from the board and ask the clerk to mark it active for me. | Erzähler | open_run_level | Accept the achievable Novice contract | Adventurers' Guild hall, Glassmere | 90/84 | 17.8 s |
| 76 | "Just a bed, thank you." I take the slip and my Guild room key and head up to sleep until morning. | Erzähler | open_run_level | Sleep overnight to recover and start the strider contract at dawn | Guild room upstairs | 90/84 | 15.6 s |
| 77 | Now that I'm in the Guild room, I lie down on the bed and sleep until morning. | Erzähler | open_run_level | Recover overnight before the strider hunt | Guild room upstairs | 95/88 | 13.3 s |
| 78 | I grab my gear and head out through the south gate toward the Reed Flats to hunt bog striders at the eel-weirs. | Erzähler | open_run_level | Travel to the Reed Flats for the strider contract | the eel-weirs of the Reed Flats south of Glassmere | 95/88 | 22.4 s |
| 79 | I greet the worker and ask where the bog striders have been nesting among the weirs, and whether he minds me hunting them. | Erzähler | open_run_level | Talk to the eel-weir worker about the striders | the eel-weirs of the Reed Flats south of Glassmere | 95/88 | 20.3 s |
| 80 | I thank Hennit and move quietly along the plank track toward the far brush fence, listening for the clicking. | Erzähler | open_run_level | Hunt the bog striders toward the far fence | the far brush fence | 95/88 | 64.2 s |
| 81 | I close quietly on the nearest strider and strike its flank with Razor Cut. | Engine (Menü/Rückfrage) | open_run_level | Open the ambush on the closest bog strider | the far brush fence | 95/88 | 6.2 s |
| 82 | I close quietly on Bog Strider A and strike its flank with Razor Cut. | Erzähler | open_run_level | Open the ambush on the nearest strider | the far brush fence | 95/88 | 24.4 s |
| 83 | I move quickly and low across the open stretch toward Bog Strider A, then strike its flank with Razor Cut once I reach it. | Erzähler | open_run_level | Close into range and attack the nearest strider | the far brush fence | 95/88 | 24.5 s |
| 84 | I advance the last ten yards straight at Bog Strider A and strike with Razor Cut once in reach. | Erzähler | open_run_level | Close to engaged range and attack Bog Strider A | the far brush fence | 86/88 | 24.2 s |
| 85 | I finish Bog Strider A with Razor Cut. | Erzähler | open_run_level | Kill the wounded strider before the others close | the far brush fence | 49/88 | 13.0 s |
| 86 | I cut the smallest one gripping my forearm — Bog Strider C — with Razor Cut, then use Evasive Step to pull a band away from the other two. | Erzähler | open_run_level | Kill one attacker and disengage to avoid being swarmed | the far brush fence | 14/88 | 26.8 s |
| 87 | I finish Bog Strider C with Razor Cut, then use Evasive Step to break away from the other two. | Erzähler | open_run_level | Kill the wounded strider and disengage to stop the attrition | the far brush fence | 0/88 | 18.8 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 5 (notiert vor Zug 6): Registration completed for 20 copper; HUD still shows 3 silver but engine coin says 30 copper — minor display mismatch to watch.
- zu Zug 20 (notiert vor Zug 21): Engine requires explicit movement to ENGAGED; crawling narration did not change the wolf's LONG range.
- zu Zug 23 (notiert vor Zug 24): HUD now shows Gray Wolf A as ENGAGED, matching the crawl narration.
- zu Zug 27 (notiert vor Zug 28): Payment for the bunk never registered — clerk stepped away and no one took the copper; coin still in purse.
- zu Zug 29 (notiert vor Zug 30): Glimmerdeep contract expired with the daily board renewal; clerk offers a name-list for when it reposts.
- zu Zug 30 (notiert vor Zug 31): Glimmerdeep notice reposted despite the clerk saying the Academy had not posted it today.
- zu Zug 31 (notiert vor Zug 32): Glimmerdeep contract is now confirmed active on the HUD; I also still carry an unsold wolf pelt and fang.
- zu Zug 34 (notiert vor Zug 35): System refused the attack because the beetles were not yet targetable actors in an active scene; the HUD location still shows the grotto mouth.
- zu Zug 36 (notiert vor Zug 37): System repeatedly reports no targetable actor; the beetles may only exist as a sign until I enter as movement without an attack.
- zu Zug 37 (notiert vor Zug 38): Narrator places me in the crystal chamber with beetles, but HUD location still says grotto mouth; the engine may track scenes separately from the location line.
- zu Zug 38 (notiert vor Zug 39): System says no targetable actor despite narrator placing beetles in the chamber; combat may need an explicit engage command.
- zu Zug 39 (notiert vor Zug 40): System says no targetable actor in the active scene despite narrator describing a dozen beetles facing me in the chamber.
- zu Zug 40 (notiert vor Zug 41): #combat says Combat INACTIVE until a hostile commitment; previous attacks failed because no commitment was declared.
- zu Zug 43 (notiert vor Zug 44): Attack declarations keep failing because the beetles exist only in narration at the grotto mouth; moving into their location may trigger actor initialization.
- zu Zug 44 (notiert vor Zug 45): Narrator resolved my strike but no System combat result appeared; checking combat state before attacking again.
- zu Zug 45 (notiert vor Zug 46): Combat remains INACTIVE even after narrator-resolved strikes; trying an explicit commitment statement with a specific target.
- zu Zug 46 (notiert vor Zug 47): System says no targetable actor exists in the active scene even though narration shows beetles; trying the plain creature name as target.
- zu Zug 48 (notiert vor Zug 49): Narrator placed me in the chamber with beetles oriented on me; HUD still shows grotto mouth and no combat panel.
- zu Zug 49 (notiert vor Zug 50): Narrator places me in the beetle chamber, but the System still reports no targetable actor; trying the species name as target.
- zu Zug 50 (notiert vor Zug 51): Three attack attempts failed: System reports no targetable actor in the active scene despite narrator placing beetles around me; combat never activates.
- zu Zug 51 (notiert vor Zug 52): HUD location is the grotto mouth with 'nobody besides Alaric' — the beetles may lie beyond scene bounds; moving physically deeper to initialize them.
- zu Zug 52 (notiert vor Zug 53): Narrator now narrates my strike landing scene, but no System combat result yet; HUD still shows grotto mouth and no combat panel.
- zu Zug 53 (notiert vor Zug 54): Narrator places beetles around me but the System scene remains empty across five attempts; trying the barest possible target word.
- zu Zug 54 (notiert vor Zug 55): Six attack attempts against narrator-present beetles all rejected: the System's active scene stays empty while the narrator describes the chamber fully; the HUD location also lags at the grotto mouth.
- zu Zug 55 (notiert vor Zug 56): Glimmerdeep contract expired Day 2 08:15 — its reward is void; beetles were never targetable, so the grotto may be scene-broken. Six attack attempts failed before I withdrew.
- zu Zug 56 (notiert vor Zug 57): Grotto contract given up cleanly; guild shop sells F-rank skill primers at 120 cp each — noted for later.
- zu Zug 59 (notiert vor Zug 60): HUD 'Here' sign says the wolf is at the hedge south, feeding — it may be targetable before dusk despite Oddren's timing.
- zu Zug 61 (notiert vor Zug 62): Wolf is now present on the bank at dusk; Oddren has gone into the shed with lantern out.
- zu Zug 69 (notiert vor Zug 70): Gift pelt arrived as ITEM despite the earlier seat refusal; XP 94/100, close to level.
- zu Zug 76 (notiert vor Zug 77): Sleep was refused earlier as 'arrival pending'; retrying now that arrival in the room is recorded. HUD still shows Day 2 21:35 despite narrated morning.
- zu Zug 77 (notiert vor Zug 78): Sleep recovery confirmed; HUD now Day 3 08:00.
- zu Zug 83 (notiert vor Zug 84): Engine required an explicit move declaration; strider A now at SHORT after my approach, others alerted.
- zu Zug 86 (notiert vor Zug 87): HP critical at 14/95; Evasive Step is listed as a defense option, so it may combine with an attack or need its own turn — will read the engine result.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t24 | 24 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t48 | 66 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t64 | 84 | 4 | – | nein | 2 | **tot** |

## Quests

- **Cull the One-Eared Wolf of the Tannery Road** — active (Zug 6) → completed (Zug 25)
  - Aufgabe: Kill 1 the one-eared wolf at the hide-drying racks along the Tannery Road outside Glassmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the one-eared wolf killed at the hide-drying racks along the Tannery Road outside Glassmere.
- **Thin the Reed Flats Bog Striders** — expired (Zug 30)
  - Aufgabe: Kill 6 bog striders at the eel-weirs of the Reed Flats south of Glassmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 6 bog striders killed at the eel-weirs of the Reed Flats south of Glassmere.
- **Slay the Dolorhorn Stag** — expired (Zug 30)
  - Aufgabe: Kill 1 the great Dolorhorn stag at the western groves of the Dolorhorn Chase. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the great Dolorhorn stag killed at the western groves of the Dolorhorn Chase.
- **Cull the Marrowfen Night Pack** — expired (Zug 30)
  - Aufgabe: Kill 8 great fen wolves of the night pack at the reed islands and causeways of Marrowfen. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 8 great fen wolves of the night pack killed at the reed islands and causeways of Marrowfen.
- **Clear Glimmerdeep Grotto, Level 1** — expired (Zug 30), Dungeon loc.glimmerdeep_grotto Ebene 1
  - Aufgabe: Clear level 1 of Glimmerdeep Grotto. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Glimmerdeep Grotto is clear.
- **Cull the Rack-Raiding Wolf** — active (Zug 57) → completed (Zug 72)
  - Aufgabe: Kill 1 gray wolf at the hide-drying racks along the Tannery Road outside Glassmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 gray wolf killed at the hide-drying racks along the Tannery Road outside Glassmere.
- **Thin the Bog Striders at the Eel-Weirs** — active (Zug 75)
  - Aufgabe: Kill 4 bog strider at the eel-weirs of the Reed Flats south of Glassmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 bog strider killed at the eel-weirs of the Reed Flats south of Glassmere.
- **Clear Glimmerdeep Grotto, Level 1** — active (Zug 31) → abandoned (Zug 56), Dungeon loc.glimmerdeep_grotto Ebene 1
  - Aufgabe: Clear level 1 of Glimmerdeep Grotto. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Glimmerdeep Grotto is clear.

## Auffälligkeiten

- Zug 11, Nachricht 22 (extraction_repaired): the extractor's first answer needed a repair
- Zug 15, Nachricht 29 (planner_repaired): the planner's first answer needed a repair
- Zug 15, Nachricht 30 (extraction_repaired): the extractor's first answer needed a repair
- Zug 16, Nachricht 31 (planner_repaired): the planner's first answer needed a repair
- Zug 27, Nachricht 53 (planner_repaired): the planner's first answer needed a repair
- Zug 37, Nachricht 74 (extraction_repaired): the extractor's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 25× keine gültige JSON-Entscheidung (Züge 7, 8, 9, 10, 13, 15, 16, 18, 20, 25, 26, 34, 39, 41, 42, 49, 59, 61, 63, 67, 68, 69, 79, 80, 81)

System-Panels: CLARIFY 2, NOT TAKEN 3, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: ambient 4, engine_owned_fact 6, engine_owned_memory 1, scene_context 19, no_go 1, guild_payout 1, guild_canon_price 1, entity_fact 1, engine_recovery 1, passage 5, pc_inventory 1, time_cap 1, group_unclear 2, world_rule 6.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 25/87 Erstantworten ungültig (28.7 %); 25 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 82 | 3 | 2.7 s | 7.9 s | 11892 | 9769 | 76 | – | stop 82 | 0 |
| board | 3 | 1 | 27.1 s | 94.7 s | 2452 | 2147 | 1149 | – | stop 3 | 0 |
| narrator | 66 | 0 | 10.8 s | 16.7 s | 11336 | 8739 | 419 | – | stop 66 | 0 |
| extract | 68 | 3 | 6.7 s | 11.1 s | 11947 | 9183 | 367 | – | stop 68 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 41:42 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 15.8 s) | 0:35 min |
| 87 Züge, Spiel (Senden bis HUD nach der Extraktion) | 32:40 min — Median 22.6 s, p90 37.1 s, max 127.8 s |
| 87 Züge, Spieler-Entscheidung | 7:10 min — Median 3.2 s, 25 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 5:18 min / 2:18 min / 13:02 min / 8:36 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 27.5 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 18:19 min, 80 Züge ≈ 36:38 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spieler | 7 | – | 34.6 s | 3.2 s |
| Spieler | 25 | – | 33.7 s | 3.2 s |
| Spiel | 30 | – | 127.8 s | 22.6 s |
| Spiel | 3 | – | 71.7 s | 22.6 s |
| Provider board | 30 | 90 | 94.7 s | 27.1 s |
| Provider extract | 80 | 200 | 35.9 s | 6.7 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
