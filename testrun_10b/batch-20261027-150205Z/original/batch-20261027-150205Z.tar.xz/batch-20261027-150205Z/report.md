# Avereth – 3 natürliche Testkampagnen

Status: **completed**. Serie abgeschlossen bedeutet, dass die Läufe beendet sind; es bedeutet nicht 3 bestandene Level-15-Abnahmen.

| Nr. | Profil | Seed | Eingaben | Level | Ende | Originalbericht |
|---|---|---:|---:|---:|---|---|
| 1 | guild-warrior | 1604207988 | 250 | 10 | limit | [report.md](001-guild-warrior/20261027-150205Z-current_test/report.md) |
| 2 | guild-mage | 1604207989 | 102 | 5 | planner_failed | [report.md](002-guild-mage/20261027-164744Z-current_test/report.md) |
| 3 | guild-rogue | 1604207990 | 87 | 2 | defeat | [report.md](003-guild-rogue/20261027-173743Z-current_test/report.md) |

