# Avereth Live-Test 20261028-022553Z-current_test

## Kurzfassung

- **Laufprofil:** guild-warrior; Startklasse Warrior, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** planner_failed — turn 137: the semantic Planner failed before story generation (sell seq 2: min_cp 1 is not what his words "I lay out four grey wolf pelts and nine fangs and accept you" say: 3 cp (1 silver = 10 copper, 1 gold = 100 copper))
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 7. Sicherheitsgrenzen: 250 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** Level 5, 404 XP seit Levelaufstieg, 179 cp, HP 141, MP 100; Ort loc.flat_rock_shelf_above_the_downstream_pool. Ausrüstung und Skills stehen in evaluation.json → progression.checkpoint.
- **Charakter:** warrior (warrior.heavy_slash, warrior.guard) · Regelstand 2 (Warrior, Mage, Rogue)
- **Ziel-Dungeon:** Glimmerdeep Grotto, Ebene 1 (Vertrag quest.clear_the_crystal_beetles_in_glimmerdeep_grotto_level_1)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: cautious adventurer: prepare and recover, weigh threats and withdraw when sensible
- **Züge:** 137 · **Dauer:** 57:19 min · **LLM-Aufrufe der Engine/des Erzählers:** 404
- **Beobachtete Abdeckung:** 25 unterschiedliche gebuchte Reiseziele · 12 Kämpfe · 0 Verkäufe (0 cp Umsatz, ohne Questzahlungen/Geschenke) · 0 Ausrüstungswechsel · 3 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 23
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.104 |
| Git | b9ffa2c1bfe7 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 69.0 s |
| Browser | chrome 156.0.8078.48 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261028-022553Z-current_test“, Seed 661497608 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | I choose Warrior. | Engine (Menü/Rückfrage) | creation_complete | Select base class | public roadside verge outside Glassmere | 90/84 | 2.3 s |
| 2 | I choose Heavy Slash and Guard as my two starter skills. | Engine (Menü/Rückfrage) | creation_complete | Finish character creation | public roadside verge outside Glassmere | 95/84 | 2.1 s |
| 3 | I walk toward Glassmere's gates and enter the city, heading for the Adventurers' Guild hall to look at the contract board. | Erzähler | open_run_level | Enter city and find Guild contracts | Adventurers' Guild hall, Glassmere | 95/84 | 38.3 s |
| 4 | I approach the clerk and ask to register with the Guild as a novice adventurer. | Erzähler | open_run_level | Register at the Guild before taking contracts | Adventurers' Guild hall, Glassmere | 95/84 | 20.7 s |
| 5 | "Agreed." I pay the two silver fee, place my hand on the glass bowl, and give the clerk my name: Alaric Red. | Erzähler | open_run_level | Register with the Guild | Adventurers' Guild hall, Glassmere | 95/84 | 17.4 s |
| 6 | I take the Marsh Serpent contract at Brackhollow and tell the clerk I'd like it marked active. | Erzähler | open_run_level | Accept first achievable Guild contract | Adventurers' Guild hall, Glassmere | 95/84 | 16.1 s |
| 7 | I leave the Guild hall and walk south along the Millwater road toward Brackhollow to hunt the marsh serpent at the millrace. | Erzähler | open_run_level | Travel to Brackhollow for the serpent contract | the millrace at Brackhollow | 95/84 | 25.0 s |
| 8 | I ask the miller where he's last seen the serpent and whether there's a safe spot to watch the race from. | Erzähler | open_run_level | Gather information on the serpent's habits before hunting | the millrace at Brackhollow | 95/84 | 16.6 s |
| 9 | I move to the flat rock shelf above the downstream pool and watch the water, sword drawn and ready. | Erzähler | open_run_level | Stake out the serpent's hunting pool from the safe vantage the miller described | flat rock shelf above the downstream pool | 95/84 | 20.2 s |
| 10 | I step back along the sound track to the mill and ask the miller if he can spare a duck or some offal scraps to bait the pool, since the ser… | Erzähler | open_run_level | Get bait to lure the cautious serpent up where I can strike it | the mill yard at Brackhollow | 95/84 | 25.6 s |
| 11 | I take the bucket of offal, carry it upstream to the race head, tip its contents into the water, then hurry back to the rock shelf with my s… | Erzähler | open_run_level | Bait the pool with offal and stake out the pool from the rock shelf | flat rock shelf above the downstream pool | 95/84 | 32.6 s |
| 12 | I strike at the serpent's raised neck with Heavy Slash the moment it lifts to take the bait. | Erzähler | open_run_level | Attack the surfacing serpent with Heavy Slash | flat rock shelf above the downstream pool | 95/84 | 14.6 s |
| 13 | I step down the bank to the waterline to close into sword range, then strike at the serpent's neck with Heavy Slash. | Erzähler | open_run_level | Close range and attack the serpent | flat rock shelf above the downstream pool | 95/84 | 15.1 s |
| 14 | I retrieve the empty bucket and walk back to the mill. "Got it — one serpent, dead in the pool. I'll take its skin and fangs to the Guild fo… | Erzähler | open_run_level | Report the kill to the miller and head back for the Guild turn-in | the mill yard at Brackhollow | 95/84 | 18.0 s |
| 15 | I head back along the road to the Guild hall in Brackhollow and turn in the serpent contract, presenting the skin and fangs as proof. | Erzähler | open_run_level | Turn in the serpent contract at the Guild hall | Adventurers' Guild hall, Glassmere | 95/84 | 21.8 s |
| 16 | "Just settling up — I'll take a look at the board for another contract, though. What's posted for a Novice today?" | Erzähler | open_run_level | Browse the Guild board for a new novice contract | Adventurers' Guild hall, Glassmere | 95/84 | 14.3 s |
| 17 | "Take the Glimmerdeep beetle contract down and make it active for me, please." | Erzähler | open_run_level | Accept the Glimmerdeep Grotto level 1 contract | Adventurers' Guild hall, Glassmere | 95/84 | 14.6 s |
| 18 | I ask around the hall whether anyone can point me to a cheap inn or a supply shop for a lantern and rations before I set out for Glimmerdeep… | Erzähler | open_run_level | Prepare supplies before traveling to Glimmerdeep | Adventurers' Guild hall, Glassmere | 95/84 | 19.3 s |
| 19 | I head to Wenna's on Cooper's Lane and ask her prices for a lantern with a flask of oil, flint and steel, and two days of rations. | Erzähler | open_run_level | Buy supplies at Wenna's shop | Wenna's | 95/84 | 20.8 s |
| 20 | I'll take the whole kit for two silver six, then — lantern, oil flask, flint and steel, and two days of rations. | Engine (Menü/Rückfrage) | open_run_level | Buy the supplies bundle | Wenna's | 95/84 | 6.8 s |
| 21 | Accept the whole kit at 26 copper as Wenna offered. | Engine (Menü/Rückfrage) | open_run_level | Buy the supply kit at the offered bundle price | Wenna's | 95/84 | 5.5 s |
| 22 | Accept the whole kit at 27 copper as listed. | Erzähler | open_run_level | Complete the supply purchase at the System-confirmed price | Wenna's | 95/84 | 14.4 s |
| 23 | I set out for Glimmerdeep Grotto, lantern and oil in my pack, and light the lantern if the light fails before I arrive. | Erzähler | open_run_level | Travel to Glimmerdeep Grotto for the beetle contract | Glimmerdeep Grotto | 95/84 | 19.5 s |
| 24 | I enter Glimmerdeep Grotto, level 1, lantern lit, sword ready. | Erzähler | open_run_level | Enter the dungeon to clear the beetle contract | Glimmerdeep Grotto, level 1 — first chamber | 95/84 | 54.7 s |
| 25 | I set my back to the chamber wall so none can circle behind me, and swing my longsword at the nearest beetle (A) with a Heavy Slash. | Erzähler | open_run_level | Fight the crystal beetles, starting with the closest | Glimmerdeep Grotto, level 1 — first chamber | 95/84 | 15.4 s |
| 26 | I step forward to close the gap and swing my longsword at the nearest beetle (A) with a Heavy Slash. | Erzähler | open_run_level | Close to ENGAGED and attack beetle A | Glimmerdeep Grotto, level 1 — first chamber | 87/84 | 22.3 s |
| 27 | I finish off Crystal Beetle A with a Basic Attack. | Erzähler | open_run_level | Kill the wounded beetle before it bites again | Glimmerdeep Grotto, level 1 — first chamber | 81/84 | 13.3 s |
| 28 | I swing my longsword at Crystal Beetle B with a Heavy Slash. | Erzähler | open_run_level | Kill the wounded small beetle next to reduce incoming bites | Glimmerdeep Grotto, level 1 — first chamber | 76/84 | 20.1 s |
| 29 | I swing my longsword at Crystal Beetle C with a Heavy Slash. | Erzähler | open_run_level | Kill the last beetle | Glimmerdeep Grotto, level 1 — first chamber | 71/84 | 13.3 s |
| 30 | I finish Crystal Beetle C with a Basic Attack. | Erzähler | open_run_level | Kill the last beetle | Glimmerdeep Grotto, level 1 — first chamber | 71/84 | 17.9 s |
| 31 | #assign VIT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up stat points, favoring survivability as a wounded warrior | Glimmerdeep Grotto, level 1 — first chamber | 71/84 | 2.1 s |
| 32 | Wounded and low on STA, I withdraw through the entrance passage and head back toward town to rest and turn in the beetle contract at the Gui… | Erzähler | open_run_level | Exit the grotto and return to town | Adventurers' Guild hall, Glassmere | 71/84 | 21.9 s |
| 33 | I ask the clerk whether there's lodging nearby for the night, then head to an inn to get a room and sleep until morning. | Erzähler | open_run_level | Rest overnight to recover HP and STA before clearing the rest of the grotto | the Wether's Rest | 71/84 | 21.7 s |
| 34 | I take the room with breakfast for six copper and accept Marta's offer to patch my wounds, then sleep until morning. | Erzähler | open_run_level | Buy lodging and rest to recover | the Wether's Rest | 120/92 | 32.4 s |
| 35 | After breakfast I head back to Glimmerdeep Grotto to finish clearing the first floor of crystal beetles. | Erzähler | open_run_level | Return to the grotto and clear the remaining beetles for the contract turn-in | Glimmerdeep Grotto | 120/92 | 22.9 s |
| 36 | I follow the left passage toward the ticking sound, sword ready. | Erzähler | open_run_level | Investigate the beetle tracks and clear remaining threats | Glimmerdeep Grotto, level 1 — quartz cavern | 120/92 | 18.0 s |
| 37 | I draw back to the passage mouth and attack the ooze with Heavy Slash as it reaches me at the narrow entrance, keeping it from flanking me o… | Erzähler | open_run_level | Fight the quartz ooze at the chokepoint | Glimmerdeep Grotto, level 1 — quartz cavern | 120/92 | 20.6 s |
| 38 | I step forward to close to sword range and attack the ooze with Heavy Slash now that it's within reach. | Erzähler | open_run_level | Engage the quartz ooze at the passage mouth | Glimmerdeep Grotto, level 1 — quartz cavern | 114/92 | 15.3 s |
| 39 | I attack the ooze again with Heavy Slash. | Erzähler | open_run_level | Finish the quartz ooze | Glimmerdeep Grotto, level 1 — quartz cavern | 108/92 | 16.2 s |
| 40 | I finish it with one more Heavy Slash. | Erzähler | open_run_level | Kill the quartz ooze | Glimmerdeep Grotto, level 1 — quartz cavern | 108/92 | 13.5 s |
| 41 | #assign STR 2 VIT 3 | System (Befehl) | open_run_level | Spend level-up points | Glimmerdeep Grotto, level 1 — quartz cavern | 108/92 | 2.1 s |
| 42 | I check the left passage for any further threats before heading back out of the grotto toward the Guild to turn in the beetle contract. | Erzähler | open_run_level | Clear remaining threats, then exit and turn in the contract | Adventurers' Guild hall, Glassmere | 108/92 | 25.4 s |
| 43 | I ask the clerk to note my progress on the file, then check the Guild board for any other Novice contracts I could take while the grotto sta… | Erzähler | open_run_level | Log progress and look for alternative contracts | Adventurers' Guild hall, Glassmere | 108/92 | 23.1 s |
| 44 | I ask the clerk to accept the Millrace Serpent contract and mark it active for me. | Erzähler | open_run_level | Take the achievable Novice serpent contract at Brackhollow | Adventurers' Guild hall, Glassmere | 108/92 | 18.8 s |
| 45 | I walk south along the Millwater to Brackhollow and find the mill by the race. | Erzähler | open_run_level | Travel to Brackhollow for the serpent contract | the millrace at Brackhollow | 108/92 | 22.1 s |
| 46 | I ask the miller to point out the tail race, then go there and wait for the serpent with my sword ready. | Erzähler | open_run_level | Ambush the serpent at the tail race | the tail race behind the mill | 108/92 | 18.6 s |
| 47 | I watch the culvert mouth and strike with Heavy Slash the moment the serpent comes within reach. | Erzähler | open_run_level | Attack the serpent as it emerges | the tail race behind the mill | 107/92 | 21.1 s |
| 48 | I strike with Heavy Slash at the serpent's head. | Erzähler | open_run_level | Kill the marsh serpent for the Millrace Serpent contract | the tail race behind the mill | 107/92 | 15.8 s |
| 49 | I haul the serpent carcass out of the race, then walk back to Brackhollow's Guild hall and ask the clerk to accept the turn-in for Cull the … | Erzähler | open_run_level | Turn in the completed serpent contract at the Guild | Brackhollow Guild hall | 107/92 | 34.1 s |
| 50 | I approach the counter and ask the clerk to accept the turn-in for Cull the Millrace Serpent at Brackhollow. | Erzähler | open_run_level | Turn in the serpent contract at Brackhollow Guild hall | Brackhollow Guild hall | 107/92 | 23.1 s |
| 51 | I ask the clerk for directions to Glassmere and how far the road is. | Erzähler | open_run_level | Learn the route to the paying branch | Brackhollow Guild hall | 107/92 | 21.3 s |
| 52 | I leave the Guild hall and set off south along the road toward Glassmere. | Erzähler | open_run_level | Travel to Glassmere to turn in both contracts | Glassmere | 107/92 | 21.0 s |
| 53 | I enter the Wether's Rest and ask for a room for the night and the price. | Erzähler | open_run_level | Get lodging before turning in contracts | the Wether's Rest | 107/92 | 18.9 s |
| 54 | "I'll take the loft bed and a stew with bread, please." I put the copper pieces on the counter. | Erzähler | open_run_level | Buy lodging and a meal, then sleep until morning | the Wether's Rest | 107/92 | 15.4 s |
| 55 | I climb into the loft bed and sleep until morning. | Erzähler | open_run_level | Recover overnight at the Wether's Rest | the Wether's Rest | 145/92 | 20.6 s |
| 56 | I thank Marta, eat the porridge, then head up the street to the Glassmere Guild hall and ask the clerk to turn in both contracts: Cull the M… | Erzähler | open_run_level | Turn in both completed contracts at Glassmere Guild | Adventurers' Guild hall, Glassmere | 145/92 | 20.6 s |
| 57 | I ask the clerk to read out the Novice contracts on the board, especially anything suitable for a lone Level-3 warrior. | Erzähler | open_run_level | Find the next achievable Guild contract | Adventurers' Guild hall, Glassmere | 145/92 | 24.4 s |
| 58 | "The strangle-vines contract sounds right for me — please make 'Cut Back the Strangle-Vines of the Drowned Orchard' active for me. | Erzähler | open_run_level | Accept the strangle-vines hunt | Adventurers' Guild hall, Glassmere | 145/92 | 15.8 s |
| 59 | I take the slip and head out through the Northgate, following the Millwater road downstream to the drowned orchard. | Erzähler | open_run_level | Travel to the drowned orchard for the vine hunt | the drowned orchard along the Millwater | 145/92 | 20.6 s |
| 60 | I walk the flat stones to the red-marked tree and cut at the vine low, near the root crown, with my longsword. | Erzähler | open_run_level | Attack the first strangle-vine | the drowned orchard along the Millwater | 145/92 | 18.6 s |
| 61 | I step off the last stone and wade the three feet of shallow water to the root crown, then cut at it low with my longsword. | Erzähler | open_run_level | Close to ENGAGED range and attack the vine | the drowned orchard along the Millwater | 145/92 | 18.9 s |
| 62 | I step up against the trunk and strike at the vine knot in the fork with my longsword, closing into ENGAGED range. | Erzähler | open_run_level | Attack the strangle-vine at close range | the drowned orchard along the Millwater | 138/92 | 22.1 s |
| 63 | I finish it with a Basic Attack at the wounded vine knot in the fork. | Erzähler | open_run_level | Kill Strangle-Vine A | the drowned orchard along the Millwater | 131/92 | 22.9 s |
| 64 | I strike the clinging vine once more with a Basic Attack to finish it. | Erzähler | open_run_level | Kill Strangle-Vine A | the drowned orchard along the Millwater | 131/92 | 17.4 s |
| 65 | #assign VIT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up points | the drowned orchard along the Millwater | 131/92 | 2.5 s |
| 66 | I tend my wounds with a bandage from my pack, then wade toward the second red rag deeper in the orchard, watching the water for movement. | Erzähler | open_run_level | Recover then hunt the second strangle-vine | the drowned orchard along the Millwater | 131/92 | 20.5 s |
| 67 | I rest here on the drowned trunk for two hours, tending my wounds and watching the slack vine at the second red rag. | Erzähler | open_run_level | Recover for two hours, then reassess Vine B | the drowned orchard along the Millwater | 165/100 | 19.2 s |
| 68 | I close to ENGAGED with the sleeping vine and strike its knot with Heavy Slash. | Erzähler | open_run_level | Attack Strangle-Vine B while it is still | the drowned orchard along the Millwater | 157/100 | 14.1 s |
| 69 | I finish it with a Basic Attack at the wounded vine knot. | Erzähler | open_run_level | Kill Strangle-Vine B | the drowned orchard along the Millwater | 157/100 | 16.0 s |
| 70 | I bandage my forearm, then wade toward the third red rag deeper in the orchard, sword ready and eyes on the water. | Erzähler | open_run_level | Continue the vine contract toward 4/4 | the drowned orchard along the Millwater | 157/100 | 23.4 s |
| 71 | I stay at SHORT and hurl my tin lantern's striker? No — I probe the rootwork from range first: I throw a lump of drowned bark at the water b… | Erzähler | open_run_level | Probe Vine C's rootwork before closing | the drowned orchard along the Millwater | 157/100 | 16.0 s |
| 72 | I circle wide toward the willow from the side away from the straight runner, stepping slow and quiet, and strike the knot with Heavy Slash o… | Erzähler | open_run_level | Engage Vine C via a quiet flanking approach, avoiding the known runner line | the drowned orchard along the Millwater | 149/100 | 16.8 s |
| 73 | I finish it with a Basic Attack at the torn knot. | Erzähler | open_run_level | Kill Strangle-Vine C | the drowned orchard along the Millwater | 149/100 | 15.1 s |
| 74 | I rebandage my bleeding forearm, then wade toward the last red rag deeper in the orchard, sword drawn and moving slow and quiet. | Erzähler | open_run_level | Find and kill the fourth strangle-vine | the drowned orchard along the Millwater | 149/100 | 29.9 s |
| 75 | I keep twenty feet of water between us, hold my ground with sword up, and watch how it moves as it unwinds — no closing until I see its reac… | Erzähler | open_run_level | Assess Vine D before engaging | the drowned orchard along the Millwater | 149/100 | 22.0 s |
| 76 | I back up a few slow steps, then throw a lump of bark past its collar to bait a snap — watching which water-lines twitch as the runners pull… | Erzähler | open_run_level | Bait Vine D's strike to expose submerged runner anchors before engaging | the drowned orchard along the Millwater | 149/100 | 18.2 s |
| 77 | I throw a lump of bark wide to bait another snap, then rush in along the mapped gap between the anchors and put a Heavy Slash into the trail… | Engine (Menü/Rückfrage) | open_run_level | Bait Vine D's snap, then strike the exposed runner from outside its mapped anchors | the drowned orchard along the Millwater | 149/100 | 5.6 s |
| 78 | I bait another snap with a thrown lump of bark, then rush in along the mapped gap between the anchors and put a Heavy Slash into Strangle-Vi… | Erzähler | open_run_level | Attack Strangle-Vine D through the mapped anchor gap | the drowned orchard along the Millwater | 149/100 | 21.7 s |
| 79 | I back slowly out of the vine's reach toward the near bank, sword up and eyes on the water, withdrawing from the orchard to rest and recover… | Erzähler | open_run_level | Withdraw from Strangle-Vine D to recover | the near bank of the Millwater | 149/100 | 24.0 s |
| 80 | I wade back in and keep closing on Strangle-Vine D until I am at ENGAGED range, then strike it with a Basic Attack. | Engine (Menü/Rückfrage) | open_run_level | Close to engaged range and attack Vine D | the near bank of the Millwater | 149/100 | 8.0 s |
| 81 | I wade back in and keep moving toward Strangle-Vine D, declaring my closing movement until it is at ENGAGED range, then strike it with a Bas… | Engine (Menü/Rückfrage) | open_run_level | Re-engage Vine D with explicit movement declared | the near bank of the Millwater | 149/100 | 7.0 s |
| 82 | I leave the heron be and wade back into the orchard toward the great willow, moving deeper until the fourth strangle-vine's area is the acti… | Erzähler | open_run_level | Re-enter the vine's area so it becomes the active scene and target | the drowned orchard along the Millwater | 149/100 | 30.4 s |
| 83 | I strike Strangle-Vine E's collar with a Heavy Slash. | Erzähler | open_run_level | Finish the fourth vine for the quest turn-in | the drowned orchard along the Millwater | 141/100 | 14.5 s |
| 84 | I finish Strangle-Vine E with a Basic Attack. | Erzähler | open_run_level | Kill the fourth vine for the quest | the drowned orchard along the Millwater | 141/100 | 19.0 s |
| 85 | #assign STR 3 VIT 2 | System (Befehl) | open_run_level | Spend level-up points, then head back to Asterhall for turn-in | the drowned orchard along the Millwater | 141/100 | 2.6 s |
| 86 | I head back along the bank toward Asterhall, and once in town I go to the Guild hall counter to turn in the completed contract, Cut Back the… | Erzähler | open_run_level | Turn in the finished vine contract at the Guild hall | Adventurers' Guild hall, Asterhall | 141/100 | 21.0 s |
| 87 | I ask the clerk what Novice contracts are on the board today, preferably something nearby and suitable for a solo swordsman. | Erzähler | open_run_level | Pick the next Guild contract | Adventurers' Guild hall, Asterhall | 141/100 | 29.6 s |
| 88 | I tell the clerk I'll take the Serpent at Brackhollow Millrace contract and ask her to mark it active. | Erzähler | open_run_level | Accept the achievable Novice serpent contract | Adventurers' Guild hall, Asterhall | 141/100 | 16.6 s |
| 89 | I buy the Primer of Guard for 120 copper, then leave by the west gate and follow the Drover Road toward the Brackhollow turning. | Erzähler | open_run_level | Learn Guard skill and travel for the serpent contract | the Brackhollow turning | 141/100 | 62.5 s |
| 90 | I follow the track down toward the mill and the millrace, watching the water for the marsh serpent. | Erzähler | open_run_level | Reach the millrace and hunt the serpent | the millrace at Brackhollow | 141/100 | 23.6 s |
| 91 | I tell the miller to leave the water as it is, then take position on the open bank by the washing-stones and wait for the serpent to come up… | Erzähler | open_run_level | Hunt the marsh serpent on open ground at dusk | flat rock shelf above the downstream pool | 141/100 | 32.4 s |
| 92 | I stay on the open bank by the washing-stones, sword ready, and wait for dusk when the serpent comes up to feed. | Erzähler | open_run_level | Hunt the marsh serpent at its feeding time on open ground | flat rock shelf above the downstream pool | 141/100 | 30.6 s |
| 93 | I activate Guard and hold behind the washing-stones, waiting for the serpent to come within reach, then strike it with Heavy Slash. | Erzähler | open_run_level | Fight the marsh serpent from open ground | flat rock shelf above the downstream pool | 141/100 | 22.0 s |
| 94 | I strike the serpent's neck with Heavy Slash while it feeds. | Erzähler | open_run_level | Attack the marsh serpent | flat rock shelf above the downstream pool | 141/100 | 18.4 s |
| 95 | I step out from behind the washing-stones and move toward the serpent's feeding head to close into striking range, then attack with Heavy Sl… | Erzähler | open_run_level | Close to ENGAGED range and strike the serpent | flat rock shelf above the downstream pool | 141/100 | 24.3 s |
| 96 | I strike at the serpent's head with Heavy Slash from the shallows. | Erzähler | open_run_level | Attack the serpent now that it is at SHORT range | flat rock shelf above the downstream pool | 141/100 | 19.4 s |
| 97 | I wade forward through the shallows until I am at ENGAGED range with the serpent, then strike its neck with Heavy Slash. | Erzähler | open_run_level | Close to ENGAGED and attack the serpent | flat rock shelf above the downstream pool | 141/100 | 19.4 s |
| 98 | I leave the millrace and travel back to the Brackhollow Guild hall, then present my guild plate and report the defeated marsh serpent to tur… | Erzähler | open_run_level | Turn in the serpent contract at the Guild hall | flat rock shelf above the downstream pool | 141/100 | 16.4 s |
| 99 | I take a room at the Brackhollow inn and sleep until morning. | Erzähler | open_run_level | Recover overnight at the inn before the day's walk to the Guild branch | flat rock shelf above the downstream pool | 141/100 | 15.8 s |
| 100 | I accept the room for two copper and pay the innkeeper, then go up to bed and sleep until morning. | Erzähler | open_run_level | Book the room at the agreed price, then sleep | flat rock shelf above the downstream pool | 141/100 | 18.9 s |
| 101 | I book the room from the innkeeper for two copper, pay her, and sleep until morning. | Erzähler | open_run_level | Book and pay for the room explicitly, then sleep | flat rock shelf above the downstream pool | 141/100 | 23.5 s |
| 102 | I tell the innkeeper I am booking a room for the night at her offered price of two copper, hand her the two copper as payment for the bookin… | Erzähler | open_run_level | Book the room explicitly and sleep | flat rock shelf above the downstream pool | 141/100 | 19.6 s |
| 103 | I pick up the serpent's skin and fangs from the rock shelf and walk back through Brackhollow to the inn; once inside, I ask the innkeeper to… | Erzähler | open_run_level | Return to the actual location (inn) and book the room there | the inn at Brackhollow | 141/100 | 20.2 s |
| 104 | I sleep until morning at the inn. | Erzähler | open_run_level | Recover overnight | the inn at Brackhollow | 160/100 | 15.3 s |
| 105 | I buy a bowl of porridge for one copper from the innkeeper and eat it, then set out on the road to the nearest Guild branch to turn in the s… | Erzähler | open_run_level | Eat breakfast, then travel to the Guild branch for the turn-in | Brackhollow Guild hall | 160/100 | 20.2 s |
| 106 | I approach the counter and hand the clerk the sealed contract slip, asking to turn in the Serpent at Brackhollow Millrace contract and colle… | Erzähler | open_run_level | Turn in the serpent contract at the Guild hall | Brackhollow Guild hall | 160/100 | 25.0 s |
| 107 | I thank the clerk, ask whether there are any contracts on the board here in Brackhollow I could take on my way, and then set out on the sout… | Erzähler | open_run_level | Ask about local contracts, then travel to Glassmere for the turn-in | Glassmere | 160/100 | 30.6 s |
| 108 | I walk through the gate and head three streets up to the Guild hall with the lanterns, then ask the counter clerk to turn in the Serpent at … | Erzähler | open_run_level | Turn in serpent contract at the Glassmere branch | Adventurers' Guild hall, Glassmere | 160/100 | 19.8 s |
| 109 | I ask the clerk to show me the contracts currently posted on the Guild board. | Erzähler | open_run_level | Pick a new Guild contract | Adventurers' Guild hall, Glassmere | 160/100 | 31.4 s |
| 110 | I tell the clerk I'll take the Grey Wolves of the Gorse Breaks contract and ask him to make it active for me. | Erzähler | open_run_level | Accept the grey wolf contract | Adventurers' Guild hall, Glassmere | 160/100 | 17.0 s |
| 111 | It's too late to walk half a day into wolf country, so I ask around the hall for a nearby inn with a bed, and once lodged I sleep until morn… | Erzähler | open_run_level | Book lodging and rest overnight before hunting wolves | Adventurers' Guild hall, Glassmere | 160/100 | 22.1 s |
| 112 | I eat a bowl of porridge at the Wether's Rest, then head out the south gate and take the Drover Road north-west toward the gorse breaks to h… | Erzähler | open_run_level | Travel to the gorse breaks and start the wolf hunt | the gorse breaks beside the Caelreth Drover Road | 160/100 | 21.6 s |
| 113 | I follow the freshest animal run into the gorse slowly, sword drawn, staying alert for the pack and ready to back toward the open road if mo… | Erzähler | open_run_level | Hunt grey wolves along the fresh run | wolf kill clearing in the gorse breaks | 160/100 | 27.7 s |
| 114 | I ready my shield-side stance and strike first at Grey Wolf A with Heavy Slash before it can charge. | Erzähler | open_run_level | Engage the two visible wolves, starting with Wolf A | wolf kill clearing in the gorse breaks | 160/100 | 20.1 s |
| 115 | I swing my Heavy Slash at Grey Wolf A as it leaps at me. | Erzähler | open_run_level | Attack Wolf A with Heavy Slash | wolf kill clearing in the gorse breaks | 160/100 | 13.0 s |
| 116 | I raise my Guard as the wolf closes, and strike with Heavy Slash the moment it reaches me. | Erzähler | open_run_level | Defend against the leaping wolf, then counterattack in range | wolf kill clearing in the gorse breaks | 160/100 | 17.2 s |
| 117 | I hold Guard against the wolf wrenching my blade, and drive a Basic Attack at it at ENGAGED range. | Erzähler | open_run_level | Fight Wolf A at close range with Basic Attack | wolf kill clearing in the gorse breaks | 160/100 | 27.7 s |
| 118 | I drive a Basic Attack at the wolf on my blade. | Erzähler | open_run_level | Damage Wolf A at ENGAGED range with a single action | wolf kill clearing in the gorse breaks | 148/100 | 20.2 s |
| 119 | I finish Grey Wolf A with a Basic Attack. | Erzähler | open_run_level | Kill the wounded wolf at ENGAGED range | wolf kill clearing in the gorse breaks | 148/100 | 24.2 s |
| 120 | #assign VIT 3 WIL 2 | System (Befehl) | open_run_level | Spend the five free stat points from level 6 | wolf kill clearing in the gorse breaks | 148/100 | 2.7 s |
| 121 | I accept the Ironward Riposte skill. | Erzähler | open_run_level | Accept the offered skill | wolf kill clearing in the gorse breaks | 148/100 | 26.9 s |
| 122 | I press on into the gorse breaks, hunting the remaining wolves, keeping my Guard ready as I track them. | Erzähler | open_run_level | Continue the wolf contract toward 4/4 | wolf kill clearing in the gorse breaks | 148/100 | 23.6 s |
| 123 | I creep to the edge of the hollow and count the wolves at the kill before choosing a target. | Erzähler | open_run_level | Scout the feeding wolves before engaging | wolf kill clearing in the gorse breaks | 148/100 | 20.6 s |
| 124 | I retreat quietly back down the cattle lane to put distance between me and the four wolves before deciding how to fight them. | Erzähler | open_run_level | Withdraw to safer ground rather than fight four wolves at once | track junction below the wolf hollow | 148/100 | 22.5 s |
| 125 | I take the track out toward the open ground and the Drover Road, leaving the gorse breaks to recover away from the wolves. | Erzähler | open_run_level | Withdraw to safe ground to recover before re-engaging | field's edge above the Drover Road | 148/100 | 26.5 s |
| 126 | I look for a safe place to rest for the night — the farmhouse with the lit window seems the best option — and ask if I can shelter there unt… | Erzähler | open_run_level | Recover HP and STA before re-engaging the three remaining wolves | stone farmhouse by the Drover Road | 148/100 | 25.6 s |
| 127 | "It's from the first wolf — it got through my guard before I put it down. The rest of the pack is still in the breaks, feeding on a kill; th… | Erzähler | open_run_level | Pay for lodging and rest until morning | stone farmhouse by the Drover Road | 215/108 | 23.6 s |
| 128 | I take up my sword, thank the farmer, and head back out along the Drover Road toward the gorse breaks to finish the wolf contract. | Erzähler | open_run_level | Return to the gorse breaks fully recovered to hunt the remaining three wolves | the gorse breaks beside the Caelreth Drover Road | 215/108 | 18.0 s |
| 129 | I follow the fresh wolf tracks toward the hollow, sword drawn, keeping to the open track where I can see them coming. | Erzähler | open_run_level | Hunt the remaining three wolves at the kill site | wolf kill clearing in the gorse breaks | 215/108 | 27.6 s |
| 130 | I keep my back to the hollow wall so no wolf gets behind me, and open with Heavy Slash on the big wounded gray wolf. | Erzähler | open_run_level | Fight the three visible wolves one at a time, wall at my back | wolf kill clearing in the gorse breaks | 215/108 | 15.7 s |
| 131 | I step forward to close the distance to the big wounded gray wolf and attack it with Heavy Slash. | Erzähler | open_run_level | Close to ENGAGED and strike the wounded gray wolf | wolf kill clearing in the gorse breaks | 215/108 | 21.8 s |
| 132 | I follow the pack's crashing retreat up the slope into the thorn, tracking the broken branches, sword ready. | Erzähler | open_run_level | Pursue the two remaining wolves to finish the 4-wolf contract | wolf kill clearing in the gorse breaks | 215/108 | 37.3 s |
| 133 | Two wolves are still close — I move from SHORT to ENGAGED on Grey Wolf G and attack it with Heavy Slash. | Erzähler | open_run_level | Finish the 4-wolf contract by defeating the remaining wolves | wolf kill clearing in the gorse breaks | 182/108 | 18.1 s |
| 134 | I finish the wounded Grey Wolf G with Heavy Slash. | Erzähler | open_run_level | Kill Grey Wolf G to reach 3/4 on the wolf contract | wolf kill clearing in the gorse breaks | 175/108 | 15.9 s |
| 135 | I finish Grey Wolf H with Heavy Slash before it lunges. | Erzähler | open_run_level | Kill the last wolf to complete the 4-wolf contract | wolf kill clearing in the gorse breaks | 175/108 | 13.0 s |
| 136 | With the contract at 4/4, I head back toward the Guild hall in town to turn in the wolf contract and sell the surplus pelts and fangs. | Erzähler | open_run_level | Turn in completed wolf contract at the Guild hall | Adventurers' Guild hall, Glassmere | 175/108 | 23.0 s |
| 137 | I lay out four grey wolf pelts and nine fangs and accept your price — two copper a pelt, a copper apiece for the fangs. | – | open_run_level | Sell surplus wolf loot to the Guild merchant | Adventurers' Guild hall, Glassmere | 175/108 | 27.2 s **no reply after the message** |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 9 (notiert vor Zug 10): Passive watching drew nothing: the serpent hunts only live prey in the water and avoids a standing man, so bait or a lure seems needed.
- zu Zug 20 (notiert vor Zug 21): System flagged a price discrepancy between listed total (27 cp) and Wenna's offer (26 cp); chose the offer.
- zu Zug 21 (notiert vor Zug 22): Wenna's 26 cp offer is not bookable; System only honors the 27 cp listed total, contradicting her spoken discount.
- zu Zug 22 (notiert vor Zug 23): Purchase booked at 27 cp; coin 2s8c. Contract active, travel next.
- zu Zug 31 (notiert vor Zug 32): Stat points assigned confirmed (VIT 12, WIL 9); HP cap rose to 105 but current HP/STA not refilled.
- zu Zug 36 (notiert vor Zug 37): Beetles already cleared (3/3); the ooze is the remaining threat on level 1 before the contract can be turned in.
- zu Zug 42 (notiert vor Zug 43): Turn-in refused: the beetle contract pays only when the whole grotto level 1 is cleared; fresh beetle tracks lead from a wall crack in the left passage, so more beetles remain.
- zu Zug 61 (notiert vor Zug 62): Vine retreated up the tree; System lists it at SHORT, so I must explicitly close to ENGAGED before attacking.
- zu Zug 65 (notiert vor Zug 66): HUD stat block appears stale (shows VIT 17/WIL 9, free 5) while the System confirms VIT 20/WIL 11, 0 free — trusting System.
- zu Zug 67 (notiert vor Zug 68): Vine B appears dormant; a fish-shaped thing near the river channel keeps recurring as a possible threat.
- zu Zug 69 (notiert vor Zug 70): Quest shows 2/4; a recurring fish-shaped swirl near the channel may be a lurking threat.
- zu Zug 77 (notiert vor Zug 78): System requires a named valid target; 'the trailing runner' was refused, so I target the vine entity directly.
- zu Zug 79 (notiert vor Zug 80): System requires explicit declared movement to reach LONG-range targets; vine retreats when pressed, so a sustained push may be needed.
- zu Zug 80 (notiert vor Zug 81): System says active scene is Heron A at SHORT — the vine may need re-entering its area to become targetable again.
- zu Zug 81 (notiert vor Zug 82): Active scene stuck on Heron A after withdrawal; the vine only becomes targetable by re-entering its area.
- zu Zug 91 (notiert vor Zug 92): HUD shows Guard P1 learned despite the earlier 'no such line' purchase refusal; location label briefly reads Caelreth instead of Brackhollow.
- zu Zug 96 (notiert vor Zug 97): Range system requires explicit movement declaration; previous swings at SHORT/MEDIUM were refused without rolling.
- zu Zug 97 (notiert vor Zug 98): Serpent killed with a single Heavy Slash first strike; loot gained 1 skin and 1 fang. HUD still labels the location Caelreth instead of Brackhollow.
- zu Zug 98 (notiert vor Zug 99): No Guild hall exists in Brackhollow; turn-in requires a day's walk to the nearest town branch. HUD location still reads Caelreth even though narration places me in Brackhollow.
- zu Zug 100 (notiert vor Zug 101): Two prior attempts: engine accepted payment narration but refused the sleep because the purchase was never booked; needs an explicit booking.
- zu Zug 101 (notiert vor Zug 102): Engine repeatedly refuses the room purchase even though narration confirms payment and room; HUD still shows location Caelreth/rock shelf at 23:00 despite being in the inn.
- zu Zug 102 (notiert vor Zug 103): HUD shows I am still at the rock shelf at 23:00 — earlier 'room booked' narration was travel-conflict; must re-travel to the inn before booking.
- zu Zug 104 (notiert vor Zug 105): Recovery confirmed after a properly booked night; serpent contract shows 1/1 defeated and ready to turn in.
- zu Zug 106 (notiert vor Zug 107): Brackhollow is only a posting house; serpent contract payment requires the full branch in Glassmere, a day's walk south.
- zu Zug 111 (notiert vor Zug 112): HUD still shows Day 4, 20:45 at the Guild hall despite the narration of sleeping until morning at the inn — trusting narration for now but noting the time/location mismatch.
- zu Zug 112 (notiert vor Zug 113): HUD shows Day 4, 22:25 night in the gorse breaks while narration describes midmorning — second straight time/location contradiction after the inn; proceeding on narration but noting it.
- zu Zug 113 (notiert vor Zug 114): Third time HUD time/night conflicts with narrated morning; combat panels present so proceeding by engine state. XP 450/500 — close to level 6.
- zu Zug 114 (notiert vor Zug 115): Last turn's action was marked NOT TAKEN (one main action per turn); retrying the attack cleanly.
- zu Zug 117 (notiert vor Zug 118): Combined Guard+attack was again rejected; single actions only. Wolf A ENGAGED, B SHORT, third wolf position unknown behind me.
- zu Zug 123 (notiert vor Zug 124): Four wolves alive, not three as narration first implied; HP and STA are low (148/215, 76/100) — recovery needed before a four-wolf fight.
- zu Zug 132 (notiert vor Zug 133): Narrator said the two wolves fled, but the HUD still lists Grey Wolf G and H present at SHORT and the quest at 2/4 — trusting the HUD.
- zu Zug 136 (notiert vor Zug 137): Level 7 confirmed, 5 free stat points pending; wolf contract paid out 90 copper though engine line said +9 silver.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t13 | 13 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t24 | 26 | 3 | – | nein | 3 | gewonnen, 168 XP |
| enc.t35 | 38 | 1 | – | nein | 1 | gewonnen, 120 XP |
| enc.t43r | 47 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t58 | 62 | 1 | – | nein | 1 | gewonnen, 144 XP |
| enc.t63 | 68 | 1 | – | nein | 1 | gewonnen, 168 XP |
| enc.t67 | 72 | 1 | – | nein | 1 | gewonnen, 174 XP |
| enc.t75 | 83 | 1 | – | nein | 1 | gewonnen, 120 XP |
| enc.t88 | 97 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t109 | 118 | 1 | – | nein | 1 | gewonnen, 120 XP |
| enc.t121 | 131 | 1 | – | nein | 1 | gewonnen, 144 XP |
| enc.t123 | 133 | 2 | – | nein | 2 | gewonnen, 312 XP |

## Quests

- **Clear the Crystal Beetles in Glimmerdeep Grotto, Level 1** — active (Zug 17) → completed (Zug 56), Dungeon loc.glimmerdeep_grotto Ebene 1
  - Aufgabe: Clear level 1 of Glimmerdeep Grotto. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Glimmerdeep Grotto is clear.
- **One Marsh Serpent at the Millrace** — active (Zug 6) → completed (Zug 15)
  - Aufgabe: Kill 1 the young marsh serpent at the millrace at Brackhollow. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the young marsh serpent killed at the millrace at Brackhollow.
- **Thin the Strangle-Vines of the Drowned Orchard** — expired (Zug 43)
  - Aufgabe: Kill 8 animate strangle-vines at the drowned orchard along the Millwater. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 8 animate strangle-vines killed at the drowned orchard along the Millwater.
- **Cull the Mudwyr at the Eel-Weirs** — expired (Zug 43)
  - Aufgabe: Kill 5 mudwyr at the eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 5 mudwyr killed at the eel-weirs of the Reed Flats.
- **Slay the Pale Stag of the Charwood** — expired (Zug 43)
  - Aufgabe: Kill 1 the Pale Stag at the Charwood kiln clearings. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the Pale Stag killed at the Charwood kiln clearings.
- **Cull the Millrace Serpent at Brackhollow** — active (Zug 44) → completed (Zug 56), READY
  - Aufgabe: Kill 1 marsh serpent at the millrace at Brackhollow. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 marsh serpent killed at the millrace at Brackhollow.
- **Clear the Strangle-Vines from the Drowned Orchard** — expired (Zug 57)
  - Aufgabe: Kill 5 strangle-vine at the drowned orchard along the Millwater. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 5 strangle-vine killed at the drowned orchard along the Millwater.
- **Thin the Mudwyrs at the Reed Flats Eel-Weirs** — expired (Zug 57)
  - Aufgabe: Kill 4 mudwyr at the eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 mudwyr killed at the eel-weirs of the Reed Flats.
- **Hunt the Pale Stag of the Charwood Kiln Clearings** — expired (Zug 57)
  - Aufgabe: Kill 1 Pale Stag at the Charwood kiln clearings. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 Pale Stag killed at the Charwood kiln clearings.
- **Clear Glimmerdeep Grotto, Level 1** — expired (Zug 57), Dungeon loc.glimmerdeep_grotto Ebene 1
  - Aufgabe: Clear level 1 of Glimmerdeep Grotto. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Glimmerdeep Grotto is clear.
- **Cull the Marsh Serpent at the Brackhollow Millrace** — expired (Zug 109)
  - Aufgabe: Kill 1 marsh serpent at the millrace at Brackhollow. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 marsh serpent killed at the millrace at Brackhollow.
- **Cut Back the Strangle-Vines of the Drowned Orchard** — active (Zug 58) → completed (Zug 86)
  - Aufgabe: Kill 4 strangle-vine at the drowned orchard along the Millwater. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 strangle-vine killed at the drowned orchard along the Millwater.
- **Thin the Mudwyrs at the Reed Flats Eel-Weirs** — expired (Zug 109)
  - Aufgabe: Kill 3 mudwyr at the eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 mudwyr killed at the eel-weirs of the Reed Flats.
- **Hunt the Pale Stag of the Charwood Kiln Clearings** — expired (Zug 109)
  - Aufgabe: Kill 1 Pale Stag at the Charwood kiln clearings. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 Pale Stag killed at the Charwood kiln clearings.
- **Clear Glimmerdeep Grotto, Level 1** — expired (Zug 109), Dungeon loc.glimmerdeep_grotto Ebene 1
  - Aufgabe: Clear level 1 of Glimmerdeep Grotto. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Glimmerdeep Grotto is clear.
- **Serpent at Brackhollow Millrace** — active (Zug 88) → completed (Zug 108)
  - Aufgabe: Kill 1 marsh serpent at the millrace at Brackhollow. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 marsh serpent killed at the millrace at Brackhollow.
- **Thin the Grey Wolves of the Gorse Breaks** — active (Zug 110) → completed (Zug 136)
  - Aufgabe: Kill 4 grey wolf at the gorse breaks beside the Caelreth Drover Road. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 grey wolf killed at the gorse breaks beside the Caelreth Drover Road.

## Auffälligkeiten

- Zug 137 (Runner/UI): no reply after the message
- Zug 11, Nachricht 22 (extraction_repaired): the extractor's first answer needed a repair
- Zug 20, Nachricht 39 (planner_repaired): the planner's first answer needed a repair
- Zug 21, Nachricht 41 (planner_repaired): the planner's first answer needed a repair
- Zug 24, Nachricht 47 (planner_repaired): the planner's first answer needed a repair
- Zug 24, Nachricht 47 (finish): plan ended with finish_reason "length"
- Zug 42, Nachricht 84 (extraction_repaired): the extractor's first answer needed a repair
- Zug 49, Nachricht 98 (extraction_repaired): the extractor's first answer needed a repair
- Zug 74, Nachricht 148 (extraction_repaired): the extractor's first answer needed a repair
- Zug 80, Nachricht 159 (planner_repaired): the planner's first answer needed a repair
- Zug 81, Nachricht 161 (planner_repaired): the planner's first answer needed a repair
- Zug 82, Nachricht 163 (planner_repaired): the planner's first answer needed a repair
- Zug 82, Nachricht 164 (extraction_repaired): the extractor's first answer needed a repair
- Zug 89, Nachricht 178 (extraction_repaired): the extractor's first answer needed a repair
- Zug 91, Nachricht 182 (extraction_repaired): the extractor's first answer needed a repair
- Zug 106, Nachricht 212 (extraction_repaired): the extractor's first answer needed a repair
- Zug 107, Nachricht 214 (extraction_repaired): the extractor's first answer needed a repair
- Zug 111, Nachricht 222 (extraction_repaired): the extractor's first answer needed a repair
- Zug 125, Nachricht 250 (extraction_repaired): the extractor's first answer needed a repair
- Zug 127, Nachricht 253 (planner_repaired): the planner's first answer needed a repair
- Zug 137, Nachricht 273 (planner_failed): the planner failed: sell seq 2: min_cp 1 is not what his words "I lay out four grey wolf pelts and nine fangs and accept you" say: 3 cp (1 silver = 10 copper, 1 gold = 100 copper)
- Zug 137, Nachricht 273 (planner_repaired): the planner's first answer needed a repair
- Hinweis (error): Avereth Engine: planner failed (sell seq 2: min_cp 1 is not what his words "I lay out four grey wolf pelts and nine fangs and accept you" say: 3 cp (1 silver = 10 copper, 1 gold = 100 copper)). Regenerate or send the message again; no story turn was generated.
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 23× keine gültige JSON-Entscheidung (Züge 2, 7, 8, 9, 31, 36, 38, 45, 46, 47, 54, 55, 62, 76, 77, 79, 90, 91, 93, 116, 127, 130, 132)
- 1 Aufruf(e) mit finish_reason "length" (Nr. 65 plan)

System-Panels: CLARIFY 2, NOT TAKEN 4, REFUSED 2, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: ambient 4, guild_canon 4, scene_context 13, guild_completion 3, engine_owned_fact 15, engine_owned_memory 2, offer 3, world_rule 9, engine_recovery 1, entity_fact 2, no_go 6, time_cap 1, attack_commitment 1, group_unclear 3.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 23/137 Erstantworten ungültig (16.8 %); 23 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 138 | 8 | 2.5 s | 4.0 s | 12302 | 9858 | 86 | – | stop 137, length 1 | 1 |
| board | 6 | 1 | 9.8 s | 10.8 s | 2438 | 2149 | 986 | – | stop 6 | 0 |
| narrator | 124 | 0 | 8.5 s | 11.6 s | 11356 | 8685 | 407 | – | stop 124 | 0 |
| extract | 135 | 11 | 5.4 s | 8.5 s | 12577 | 9297 | 336 | – | stop 135 | 0 |
| forge | 1 | 0 | 2.1 s | 2.1 s | 395 | 0 | 73 | – | stop 1 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 57:19 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 69.0 s) | 1:28 min |
| 137 Züge, Spiel (Senden bis HUD nach der Extraktion) | 45:49 min — Median 20.1 s, p90 29.6 s, max 62.5 s |
| 137 Züge, Spieler-Entscheidung | 7:35 min — Median 2.2 s, 23 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 6:47 min / 0:56 min / 18:47 min / 13:33 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 23.4 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 15:35 min, 80 Züge ≈ 31:11 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spieler | 76 | – | 33.8 s | 2.2 s |
| Spiel | 89 | – | 62.5 s | 20.1 s |
| Provider extract | 89 | 256 | 34.0 s | 5.4 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
