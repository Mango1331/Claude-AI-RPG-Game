# Avereth Live-Test 20261028-032318Z-current_test

## Kurzfassung

- **Laufprofil:** guild-mage; Startklasse Mage, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** extractor_failed — turn 46: the World Extractor failed after story message 92; its world changes were not committed ($.scene: matches none of anyOf; $.deltas[1] (person.new): .scene: matches none of anyOf; $.deltas[2] (offer): .scene: matches none of anyOf; $.deltas[3] (fact):)
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 5. Sicherheitsgrenzen: 250 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** noch nicht erreicht.
- **Charakter:** mage (mage.arcane_bolt, mage.arcane_ward) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: pragmatic adventurer: sell surplus loot and invest in useful equipment and techniques
- **Züge:** 46 · **Dauer:** 18:37 min · **LLM-Aufrufe der Engine/des Erzählers:** 131
- **Beobachtete Abdeckung:** 9 unterschiedliche gebuchte Reiseziele · 6 Kämpfe · 1 Verkäufe (17 cp Umsatz, ohne Questzahlungen/Geschenke) · 0 Ausrüstungswechsel · 0 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 9
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.104 |
| Git | b9ffa2c1bfe7 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 10.2 s |
| Browser | chrome 156.0.8078.48 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261028-032318Z-current_test“, Seed 661497609 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | Mage | Engine (Menü/Rückfrage) | creation_complete | Choose Mage class | public roadside verge outside Glassmere | 90/84 | 2.3 s |
| 2 | I choose Arcane Bolt and Arcane Ward. | Engine (Menü/Rückfrage) | creation_complete | Pick two starter skills | public roadside verge outside Glassmere | 90/96 | 2.1 s |
| 3 | I walk to Glassmere's city gate and enter the city, then head to the Adventurers' Guild hall to register and look at the contract board. | Erzähler | open_run_level | Enter Glassmere and reach the Guild | Adventurers' Guild hall, Glassmere | 90/96 | 68.0 s |
| 4 | I sign the form and pay the scribe two silver for registration. | Erzähler | open_run_level | Register with the Guild | Adventurers' Guild hall, Glassmere | 90/96 | 27.7 s |
| 5 | I take the Reed Flats bog strider contract from the board and ask the scribe to mark it active. | Erzähler | open_run_level | Accept first Novice contract | Adventurers' Guild hall, Glassmere | 90/96 | 29.5 s |
| 6 | I head out the south gate, follow the river road and plank path to the eel-weirs at the Reed Flats, and look for the bog strider. | Erzähler | open_run_level | Travel to Reed Flats and hunt the bog strider | the eel-weirs of the Reed Flats | 90/96 | 22.5 s |
| 7 | I head up the plank walkway toward the upper weir, staff ready, and cast Arcane Bolt at the bog strider as soon as I have a clear sight of i… | Erzähler | open_run_level | Engage the bog strider with Arcane Bolt | the eel-weirs of the Reed Flats | 90/96 | 23.3 s |
| 8 | I release the Arcane Bolt at the bog strider. | Erzähler | open_run_level | Fire the charged bolt at the strider | the eel-weirs of the Reed Flats | 90/86 | 19.6 s |
| 9 | I take the proof of the kill and head back to the eel fisherman, then return to the Guild hall in Glassmere to turn in the contract and coll… | Erzähler | open_run_level | Turn in the completed bog strider contract | Adventurers' Guild hall, Glassmere | 90/86 | 26.5 s |
| 10 | I ask the scribe what fresh work is on the board for a Novice mage. | Erzähler | open_run_level | Pick the next Guild contract | Adventurers' Guild hall, Glassmere | 90/86 | 14.9 s |
| 11 | I take the Howling Gorse Wolves contract from the board and ask the scribe to mark it active. | Erzähler | open_run_level | Accept the wolf cull contract | Adventurers' Guild hall, Glassmere | 90/86 | 12.4 s |
| 12 | I set out west along the Millbrook road toward the Gorse Downs, then look for the Howling Gorse and the wolf pack. | Erzähler | open_run_level | Travel to the wolf hunting grounds | Adventurers' Guild hall, Glassmere | 90/86 | 15.4 s |
| 13 | I take the track off the road and walk toward the dark stand of gorse ahead, watching for wolves as I go. | Erzähler | open_run_level | Travel to the Howling Gorse | the Howling Gorse, Gorse Downs | 90/86 | 23.5 s |
| 14 | I follow the wolf tracks deeper into the densest part of the gorse, staff ready, staying quiet where the ground lets me. | Erzähler | open_run_level | Track the wolf pack to its den | Wolf den clearing in the dense gorse | 90/86 | 23.2 s |
| 15 | I cast Arcane Bolt at Grey Wolf A, the bigger one, and keep my footing near the clearing's edge in case both charge. | Erzähler | open_run_level | Open the wolf fight on the bigger target | Wolf den clearing in the dense gorse | 50/76 | 19.9 s |
| 16 | I cast Arcane Bolt at Grey Wolf A again. | Erzähler | open_run_level | Finish the wounded alpha before it bites again | Wolf den clearing in the dense gorse | 50/66 | 14.4 s |
| 17 | #assign INT 2 WIL 2 VIT 1 | System (Befehl) | open_run_level | Spend level-up stat points | Wolf den clearing in the dense gorse | 50/66 | 2.1 s |
| 18 | I cast Arcane Bolt at Grey Wolf B while it hesitates at the gorse line. | Erzähler | open_run_level | Continue the 4-wolf cull contract on the second wolf | Wolf den clearing in the dense gorse | 38/56 | 30.2 s |
| 19 | I cast Arcane Bolt at Grey Wolf B to finish it before it lunges again. | Erzähler | open_run_level | Finish the second wolf | Wolf den clearing in the dense gorse | 38/46 | 21.6 s |
| 20 | #assign VIT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up stat points, prioritizing HP | Wolf den clearing in the dense gorse | 38/46 | 2.2 s |
| 21 | I bandage my wounds and retreat to the clearing's edge to rest and recover MP before seeking the last two wolves. | Engine (Menü/Rückfrage) | open_run_level | Recover HP/MP before continuing the cull | Wolf den clearing in the dense gorse | 38/46 | 5.8 s |
| 22 | I rest for 2 hours at the clearing's edge to recover HP and MP. | Erzähler | open_run_level | Recover before hunting the last two wolves | Wolf den clearing in the dense gorse | 62/91 | 29.0 s |
| 23 | I search the clearing's edge for the wolves' trail toward the den, following any tracks or scent marks I find. | Erzähler | open_run_level | Track the last two wolves | Wolf den clearing in the dense gorse | 62/91 | 16.0 s |
| 24 | With no trail and night falling, I skin the two wolf carcasses for any usable pelts, then make camp here at the clearing's edge and rest unt… | Erzähler | open_run_level | Camp overnight, recover, then track wolves in daylight | Wolf den clearing in the dense gorse | 120/152 | 32.0 s |
| 25 | In full daylight, I search the clearing's edge again for the wolves' fresh trail toward the den. | Erzähler | open_run_level | Track remaining wolves in daylight | Wolf den clearing in the dense gorse | 120/152 | 15.4 s |
| 26 | I push into the gorse thicket through the widest gaps, searching the interior for the wolves' den. | Erzähler | open_run_level | Hunt the last two wolves inside the thicket | Hollow at the den-mouth in the gorse | 120/152 | 21.7 s |
| 27 | I open the fight with Arcane Bolt at the heavy-chested wolf at the hollow's edge, keeping my back to the tunnel-mouth so nothing circles beh… | Erzähler | open_run_level | Engage the last two wolves at range | Hollow at the den-mouth in the gorse | 103/142 | 19.1 s |
| 28 | I finish the wounded wolf with Arcane Bolt at Grey Wolf C. | Erzähler | open_run_level | Kill the badly hurt wolf before the second joins | Hollow at the den-mouth in the gorse | 103/132 | 13.3 s |
| 29 | I cast Arcane Bolt at the retreating lean wolf, Grey Wolf D, before it can reach the den-mouth. | Erzähler | open_run_level | Finish the last wolf for the contract | Hollow at the den-mouth in the gorse | 71/122 | 23.0 s |
| 30 | I cast Arcane Bolt at Grey Wolf D to finish it. | Erzähler | open_run_level | Kill the last wolf for the contract | Hollow at the den-mouth in the gorse | 71/112 | 19.6 s |
| 31 | #assign WIL 3 INT 2 | System (Befehl) | open_run_level | Spend level-up points | Hollow at the den-mouth in the gorse | 71/112 | 2.2 s |
| 32 | I head back along my trail toward Asterhall's Guild branch to turn in the completed wolf contract. | Erzähler | open_run_level | Return to the Guild for turn-in | Adventurers' Guild hall, Asterhall | 71/112 | 25.9 s |
| 33 | I spend my points with #assign VIT 3 WIL 2 | Erzähler | open_run_level | Allocate level-up stats for durability and magic | Adventurers' Guild hall, Asterhall | 71/112 | 28.0 s |
| 34 | #assign VIT 2 INT 1 WIL 2 | System (Befehl) | open_run_level | Spend the new level-up points | Adventurers' Guild hall, Asterhall | 71/112 | 2.2 s |
| 35 | I look over the contract board for a new achievable Novice contract. | Erzähler | open_run_level | Pick the next Guild contract | Adventurers' Guild hall, Asterhall | 71/112 | 32.8 s |
| 36 | I ask the clerk to make the Bog Strider contract at the Reed Flats Eel-Weirs active for me. | Erzähler | open_run_level | Accept an achievable Novice contract | Adventurers' Guild hall, Asterhall | 71/112 | 19.1 s |
| 37 | I head west along the marsh road toward the Reed Flats eel-weirs. | Erzähler | open_run_level | Travel to the bog strider contract site | the eel-weirs of the Reed Flats | 71/112 | 20.2 s |
| 38 | I approach the old man mending the net and ask him to point me to the weirs the bog striders have been chewing up. | Erzähler | open_run_level | Get directions to the strider-damaged weirs | the eel-weirs of the Reed Flats | 71/112 | 18.3 s |
| 39 | I follow the staked willow-wand path out to the third weir and settle on the drying rack to wait for dusk. | Erzähler | open_run_level | Ambush the bog strider at dusk | the third weir | 71/112 | 17.8 s |
| 40 | I stay still on the drying rack, eyes on the gnawed gate, waiting for dusk and the strider's approach. | Erzähler | open_run_level | Wait for the bog strider at dusk | the third weir | 71/112 | 22.1 s |
| 41 | I cast Arcane Bolt at the bog strider climbing the gate. | Erzähler | open_run_level | Attack the strider at dusk | the third weir | 71/102 | 18.0 s |
| 42 | I head back east along the willow-wand path toward the eel-fishers' camp and the marsh road, to return to the Guild hall and turn in the str… | Erzähler | open_run_level | Return from completed contract | Adventurers' Guild hall, Glassmere | 71/102 | 29.1 s |
| 43 | I ask the scribe what contracts are on the board suitable for a Novice mage, and whether he'll take six bog strider chitin plates and eleven… | Erzähler | open_run_level | Turn in done, look for next contract and sell loot | Adventurers' Guild hall, Glassmere | 71/102 | 33.0 s |
| 44 | Yes, I sell the six plates and eleven fangs for seventeen copper, and take the Cull the Grey Wolves of the Howling Gorse contract. | Erzähler | open_run_level | Sell loot and accept wolf cull contract | Adventurers' Guild hall, Glassmere | 71/102 | 15.6 s |
| 45 | I take lodging for the night and sleep until morning, then set out west on the Downs road for the Howling Gorse. | Erzähler | open_run_level | Recover overnight, then travel to wolf cull | Adventurers' Guild hall, Glassmere | 71/102 | 26.5 s |
| 46 | I take the six-copper bed with supper and breakfast, and sleep until morning. |  | open_run_level | Book lodging and recover | Adventurers' Guild hall, Glassmere | 71/102 | 31.6 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 6 (notiert vor Zug 7): HUD shows the contract as 'Cull the Reed Flats Bog Striders' while the scribe described a single strider; quest tracker reads 0/1 defeated.
- zu Zug 23 (notiert vor Zug 24): Tracking failed in failing light; remaining 2 wolves unlocated. Contract at 2/4.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t8 | 8 | 1 | – | nein | 1 | gewonnen, 30 XP |
| enc.t15 | 15 | 1 | – | nein | 1 | gewonnen, 204 XP |
| enc.t17 | 18 | 1 | – | nein | 1 | gewonnen, 120 XP |
| enc.t24 | 27 | 1 | – | nein | 1 | gewonnen, 168 XP |
| enc.t26 | 29 | 1 | – | nein | 1 | gewonnen, 168 XP |
| enc.t36 | 41 | 1 | – | nein | 1 | gewonnen, 24 XP |

## Quests

- **Cull the Reed Flats Bog Striders** — active (Zug 5) → completed (Zug 9)
  - Aufgabe: Kill 1 bog striders at the eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 bog striders killed at the eel-weirs of the Reed Flats.
- **Thin the Howling Gorse Wolves** — active (Zug 11) → completed (Zug 32)
  - Aufgabe: Kill 4 wolves of the Howling Gorse pack at the Howling Gorse, Gorse Downs. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 wolves of the Howling Gorse pack killed at the Howling Gorse, Gorse Downs.
- **Cull the Quarry Slimes** — expired (Zug 43)
  - Aufgabe: Kill 6 mineral slimes at the flooded lower pits of Greymarl Quarry. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 6 mineral slimes killed at the flooded lower pits of Greymarl Quarry.
- **Cull the Old Barrow Boar** — expired (Zug 43)
  - Aufgabe: Kill 1 the great tusked boar of the Old Barrow thicket at the Old Barrow thicket above the Millbrook road. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the great tusked boar of the Old Barrow thicket killed at the Old Barrow thicket above the Millbrook road.
- **Clear Glimmerdeep Grotto Level 1** — expired (Zug 43), Dungeon loc.glimmerdeep_grotto Ebene 1
  - Aufgabe: Clear level 1 of Glimmerdeep Grotto. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Glimmerdeep Grotto is clear.
- **Cull the Bog Strider at the Reed Flats Eel-Weirs** — active (Zug 36) → completed (Zug 42)
  - Aufgabe: Kill 1 bog strider at the eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 bog strider killed at the eel-weirs of the Reed Flats.
- **Cull the Grey Wolves of the Howling Gorse** — active (Zug 44)
  - Aufgabe: Kill 4 grey wolves at the Howling Gorse, Gorse Downs. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 grey wolves killed at the Howling Gorse, Gorse Downs.

## Auffälligkeiten

- Zug 3, Nachricht 6 (extraction_repaired): the extractor's first answer needed a repair
- Zug 4, Nachricht 8 (extraction_repaired): the extractor's first answer needed a repair
- Zug 5, Nachricht 10 (extraction_repaired): the extractor's first answer needed a repair
- Zug 9, Nachricht 18 (extraction_repaired): the extractor's first answer needed a repair
- Zug 36, Nachricht 72 (extraction_repaired): the extractor's first answer needed a repair
- Zug 40, Nachricht 79 (planner_repaired): the planner's first answer needed a repair
- Zug 42, Nachricht 84 (extraction_repaired): the extractor's first answer needed a repair
- Zug 46, Nachricht 92 (extraction_failed): the extractor failed: $.scene: matches none of anyOf; $.deltas[1] (person.new): .scene: matches none of anyOf; $.deltas[2] (offer): .scene: matches none of anyOf; $.deltas[3] (fact): .scene: matches none of anyOf; $.deltas
- Zug 46, Nachricht 92 (extraction_repaired): the extractor's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 9× keine gültige JSON-Entscheidung (Züge 15, 17, 23, 24, 27, 29, 38, 39, 41)

System-Panels: CLARIFY 1, NOT TAKEN 0, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: guild_canon 2, ambient 2, domain_fact 1, engine_owned_fact 5, guild_completion 1, scene_context 4, world_rule 5, time_cap 1, engine_owned_combat 1, guild_payout 1, engine_owned_memory 1, no_go 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 9/46 Erstantworten ungültig (19.6 %); 9 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 41 | 1 | 2.4 s | 4.3 s | 11538 | 9761 | 76 | – | stop 41 | 0 |
| board | 5 | 2 | 8.5 s | 13.2 s | 2444 | 2149 | 1013 | – | stop 5 | 0 |
| narrator | 39 | 0 | 8.5 s | 16.8 s | 11367 | 8719 | 402 | – | stop 39 | 0 |
| extract | 46 | 7 | 5.7 s | 9.6 s | 11859 | 9151 | 309 | – | stop 46 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 18:37 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 10.2 s) | 0:25 min |
| 46 Züge, Spiel (Senden bis HUD nach der Extraktion) | 15:39 min — Median 20.0 s, p90 31.6 s, max 68.0 s |
| 46 Züge, Spieler-Entscheidung | 1:55 min — Median 2.1 s, 9 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 2:09 min / 0:44 min / 6:29 min / 4:36 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 22.9 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 15:17 min, 80 Züge ≈ 30:34 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spiel | 3 | – | 68.0 s | 20.0 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
