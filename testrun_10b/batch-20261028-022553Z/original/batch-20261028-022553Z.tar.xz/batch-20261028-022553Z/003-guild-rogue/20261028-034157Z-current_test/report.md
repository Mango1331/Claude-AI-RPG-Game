# Avereth Live-Test 20261028-034157Z-current_test

## Kurzfassung

- **Laufprofil:** guild-rogue; Startklasse Rogue, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** Niederlage — turn 29: he died
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 2. Sicherheitsgrenzen: 250 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** noch nicht erreicht.
- **Charakter:** rogue (rogue.razor_cut, rogue.feint) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: pragmatic adventurer: sell surplus loot and invest in useful equipment and techniques
- **Züge:** 29 · **Dauer:** 12:21 min · **LLM-Aufrufe der Engine/des Erzählers:** 82
- **Beobachtete Abdeckung:** 6 unterschiedliche gebuchte Reiseziele · 3 Kämpfe · 0 Verkäufe (0 cp Umsatz, ohne Questzahlungen/Geschenke) · 0 Ausrüstungswechsel · 0 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 6 · **Niederlage** in Zug 29: he died
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.104 |
| Git | b9ffa2c1bfe7 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 13.8 s |
| Browser | chrome 156.0.8078.48 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261028-034157Z-current_test“, Seed 661497610 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | I choose Rogue. | Engine (Menü/Rückfrage) | creation_complete | Select base class | public roadside verge outside Glassmere | 90/84 | 2.1 s |
| 2 | I choose Razor Cut and Feint. | Engine (Menü/Rückfrage) | creation_complete | Finish Rogue character creation with chosen starter skills | public roadside verge outside Glassmere | 90/84 | 2.1 s |
| 3 | I walk to Glassmere and head to the Guild hall to look at the contract board. | Erzähler | open_run_level | Find a first Guild contract | Adventurers' Guild hall, Glassmere | 90/84 | 34.6 s |
| 4 | I approach the clerk and ask to register with the Guild, then request to take the 'Thin the Quarry Ridge Wolves' contract. | Erzähler | open_run_level | Register and accept the wolf contract | Adventurers' Guild hall, Glassmere | 90/84 | 12.4 s |
| 5 | I pay the two silver and sign the ledger as Alaric Red, then ask to take the 'Thin the Quarry Ridge Wolves' contract. | Erzähler | open_run_level | Register with the Guild and accept the wolf contract | Adventurers' Guild hall, Glassmere | 90/84 | 15.6 s |
| 6 | I take the sealed slip and leave the Guild hall, heading northeast up the ridge road toward the old quarry workings to hunt wolves. | Erzähler | open_run_level | Travel to Quarry Ridge for the wolf contract | the old quarry workings on Quarry Ridge | 90/84 | 23.7 s |
| 7 | I greet the quarry worker and ask where the wolves have been coming for the mule feed, then head down toward the lower terraces in the direc… | Erzähler | open_run_level | Get the wolves' location from the worker, then start hunting | the deep cut | 90/84 | 37.4 s |
| 8 | I move carefully up the lane toward the dark seam, watching for wolves and staying ready to strike the first one that shows itself. | Erzähler | open_run_level | Hunt wolves at the den entrance | the deep cut | 76/84 | 19.3 s |
| 9 | I use Feint, then attack Grey Wolf A with Razor Cut. | Erzähler | open_run_level | Open combat with Feint plus Razor Cut on the wolf | the deep cut | 61/84 | 12.8 s |
| 10 | I attack Grey Wolf A with Razor Cut, using the Feint bonus. | Erzähler | open_run_level | Deal boosted damage to the wolf | the deep cut | 46/84 | 17.7 s |
| 11 | I attack Grey Wolf A with Razor Cut. | Erzähler | open_run_level | Deal damage with the Feint bonus before it expires | the deep cut | 31/84 | 12.5 s |
| 12 | I finish Grey Wolf A with a Basic Attack. | Erzähler | open_run_level | Kill the wounded wolf | the deep cut | 31/84 | 13.5 s |
| 13 | #assign AGI 2 PER 2 VIT 1 | System (Befehl) | open_run_level | Spend level-up points on agility, perception, vitality | the deep cut | 31/84 | 2.1 s |
| 14 | I press on along the lane, watching for the next wolf and staying ready to use Feint on the first one that comes at me. | Erzähler | open_run_level | Continue the wolf contract toward 5 kills | the deep cut | 31/84 | 18.3 s |
| 15 | I withdraw from the fork and make my way back out of the quarry toward town, keeping clear of any wolves, to rest and recover before continu… | Erzähler | open_run_level | Recover from badly wounded HP before continuing the wolf contract | the deep cut | 31/84 | 22.7 s |
| 16 | I wash my wounds in the stream under the bridge, then walk on into Glassmere to find Marta at the Weary Cart and have her stitch me up. | Erzähler | open_run_level | Recover HP before resuming the wolf hunt | the Weary Cart | 31/84 | 27.1 s |
| 17 | I take the dry stitching and say, "Do it, Marta — all the stitches I need." | Erzähler | open_run_level | Accept Marta's confirmed offer and get stitched up | the Weary Cart | 31/84 | 18.5 s |
| 18 | I ask the innkeeper for a room for the night and, once I have it, go up and sleep until morning. | Erzähler | open_run_level | Recover HP overnight before resuming the wolf contract | the Weary Cart | 31/84 | 12.1 s |
| 19 | I take the room for four coppers and the stew supper for two, then eat and go up to sleep until morning. | Engine (Menü/Rückfrage) | open_run_level | Book lodging and recover overnight | the Weary Cart | 31/84 | 9.8 s |
| 20 | I say to the innkeeper: "I'll buy the room for the night at four coppers and the stew supper at two coppers — six coppers total." Once he's … | Erzähler | open_run_level | Book room and supper with clarified price, then sleep | the Weary Cart | 100/84 | 21.3 s |
| 21 | I head out of the Weary Cart and make my way back to the Quarry Ridge wolf territory to continue hunting the pack, taking care to approach a… | Erzähler | open_run_level | Resume the wolf contract (1/5 defeated) at full health | the old quarry workings on Quarry Ridge | 100/84 | 41.6 s |
| 22 | I track the wolf sign toward the right-hand steps where the barks carried, moving quietly with my dagger ready. | Erzähler | open_run_level | Hunt the wolf pack (1/5) | the right-hand steps | 100/84 | 35.3 s |
| 23 | I burst from the gorse cover and strike first at the big white-muzzled wolf B with Feint, then cut at it with Razor Cut. | Erzähler | open_run_level | Initiate combat on the pack leader from cover | the right-hand steps | 100/84 | 41.7 s |
| 24 | I follow the feint with a Razor Cut at the white-muzzled wolf B as it drives up at me. | Erzähler | open_run_level | Attack pack leader with Razor Cut | the right-hand steps | 86/84 | 18.1 s |
| 25 | I strike at the white-muzzled wolf B with a Basic Attack as it springs at me. | Erzähler | open_run_level | Attack the pack leader now that it's in range | the right-hand steps | 71/84 | 17.8 s |
| 26 | I finish the white-muzzled wolf with a Razor Cut while it's wounded and in range. | Erzähler | open_run_level | Kill pack leader Grey Wolf B | the right-hand steps | 71/84 | 54.0 s |
| 27 | I keep my dagger up and advance on the nearest grey wolf C, closing to engaged range before it can decide to flee or charge. | Erzähler | open_run_level | Attack wolf C at close range | the right-hand steps | 71/84 | 15.1 s |
| 28 | I attack the grey wolf C with Razor Cut while it hesitates at dagger's reach. | Erzähler | open_run_level | Kill wolf C, 3/5 | the right-hand steps | 11/84 | 22.8 s |
| 29 | I finish the wounded grey wolf C with a Basic Attack before it can bite again. | Erzähler | open_run_level | Kill the wounded wolf to thin the pack | the right-hand steps | 0/84 | 14.8 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 9 (notiert vor Zug 10): One main action per turn: the Razor Cut after Feint was NOT taken and must be repeated now.
- zu Zug 14 (notiert vor Zug 15): Contract shows 1/5 defeated; HP 31/100 with no healing items noted, so recovering first is the safe branch.
- zu Zug 20 (notiert vor Zug 21): Supper was paid but never actually delivered — engine confirmed recovery anyway. Level 2, XP 20/200.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t8r | 8 | 1 | – | nein | 1 | gewonnen, 120 XP |
| enc.t22r | 24 | 1 | – | nein | 1 | gewonnen, 144 XP |
| enc.t26 | 28 | 4 | – | nein | 1 | **tot** |

## Quests

- **Thin the Quarry Ridge Wolves** — active (Zug 5)
  - Aufgabe: Kill 5 wolves at the old quarry workings on Quarry Ridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 5 wolves killed at the old quarry workings on Quarry Ridge.

## Auffälligkeiten

- Zug 7, Nachricht 14 (extraction_repaired): the extractor's first answer needed a repair
- Zug 17, Nachricht 33 (planner_repaired): the planner's first answer needed a repair
- Zug 19, Nachricht 37 (planner_repaired): the planner's first answer needed a repair
- Zug 26, Nachricht 52 (extraction_repaired): the extractor's first answer needed a repair
- Zug 26, Nachricht 52 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 26, Nachricht 52 (finish): extract ended with finish_reason "length"
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 6× keine gültige JSON-Entscheidung (Züge 2, 4, 5, 8, 18, 23)
- 1 Aufruf(e) mit finish_reason "length" (Nr. 72 extract)

System-Panels: CLARIFY 1, NOT TAKEN 3, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: world_rule 9, engine_recovery 1, group_unclear 1, attack_commitment 2, engine_owned_fact 2.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 1, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 6/29 Erstantworten ungültig (20.7 %); 6 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 28 | 2 | 2.5 s | 4.6 s | 11419 | 9712 | 86 | – | stop 28 | 0 |
| board | 2 | 1 | 7.8 s | 8.6 s | 2928 | 2459 | 1124 | – | stop 2 | 0 |
| narrator | 25 | 0 | 8.3 s | 11.8 s | 11132 | 8689 | 374 | – | stop 25 | 0 |
| extract | 27 | 1 | 4.7 s | 15.5 s | 11524 | 9119 | 326 | – | stop 26, length 1 | 1 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 12:21 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 13.8 s) | 0:28 min |
| 29 Züge, Spiel (Senden bis HUD nach der Extraktion) | 9:57 min — Median 18.1 s, p90 41.6 s, max 54.0 s |
| 29 Züge, Spieler-Entscheidung | 1:33 min — Median 1.9 s, 6 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 1:25 min / 0:16 min / 3:46 min / 3:28 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 23.8 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 15:51 min, 80 Züge ≈ 31:42 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Provider extract | 26 | 72 | 38.1 s | 4.7 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
