# Avereth Live-Test 20261028-051914Z-current_test

## Kurzfassung

- **Laufprofil:** guild-warrior; Startklasse Warrior, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** abgebrochen: Limit erreicht — 250 turns
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 7. Sicherheitsgrenzen: 250 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** Level 2, 66 XP seit Levelaufstieg, 26 cp, HP 91, MP 84; Ort loc.glimmerdeep_grotto.fallen_crystal_hall. Ausrüstung und Skills stehen in evaluation.json → progression.checkpoint.
- **Charakter:** warrior (warrior.heavy_slash, warrior.guard) · Regelstand 2 (Warrior, Mage, Rogue)
- **Ziel-Dungeon:** Glimmerdeep Grotto, Ebene 1 (Vertrag quest.clear_glimmerdeep_grotto_level_1)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: curious adventurer: follow interesting opportunities without forcing dangerous encounters
- **Züge:** 250 · **Dauer:** 110:06 min · **LLM-Aufrufe der Engine/des Erzählers:** 714
- **Beobachtete Abdeckung:** 38 unterschiedliche gebuchte Reiseziele · 16 Kämpfe · 1 Verkäufe (4 cp Umsatz, ohne Questzahlungen/Geschenke) · 2 Ausrüstungswechsel · 4 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 47
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.106 |
| Git | 75a436636fa0 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 14.3 s |
| Browser | chrome 156.0.8078.48 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261028-051914Z-current_test“, Seed 1098264377 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | I choose Warrior. | Engine (Menü/Rückfrage) | creation_complete | Pick Warrior as base class | public roadside verge outside Glassmere | 90/84 | 2.3 s |
| 2 | I select Heavy Slash and Guard as my two skills. | Engine (Menü/Rückfrage) | creation_complete | Finish Warrior creation with a balanced offense/defense pair | public roadside verge outside Glassmere | 95/84 | 2.1 s |
| 3 | I walk toward the city gate of Glassmere and enter the city. | Erzähler | open_run_level | Enter Glassmere to find the Guild hall | Glassmere | 95/84 | 20.1 s |
| 4 | I walk to the Adventurers' Guild hall and look for the contract board. | Erzähler | open_run_level | Find Guild contracts | Adventurers' Guild hall, Glassmere | 95/84 | 52.0 s |
| 5 | I approach the clerk at the desk and ask about Guild registration and what work is available. | Erzähler | open_run_level | Register with the Guild and ask about contracts | Adventurers' Guild hall, Glassmere | 95/84 | 17.5 s |
| 6 | I place two silver on the counter and register with the Guild. | Erzähler | open_run_level | Pay the registration fee and sign the roll | Adventurers' Guild hall, Glassmere | 95/84 | 37.1 s |
| 7 | I pick up my Guild plate, thank the clerk, and head north to the Glimmerdeep to cull beetles and slimes in the outer grottos. | Erzähler | open_run_level | Take the plate and hunt at Glimmerdeep since the board is empty until tomorrow | Glimmerdeep Cleft lodge | 95/84 | 45.7 s |
| 8 | I show my Guild plate and give the gatekeeper my name and the hour, then head into the first grotto mouth left of the stream to cull beetles… | Erzähler | open_run_level | Register with the gatekeeper and start hunting | Glimmerdeep Cleft lodge | 95/84 | 29.8 s |
| 9 | I draw my longsword and move carefully toward the clicking sound deeper in the first grotto, watching the floor for slimes and the crystal v… | Erzähler | open_run_level | Hunt beetles and slimes in the first grotto | Glimmerdeep Cleft lodge | 95/84 | 42.1 s |
| 10 | I strike the closest beetle overhead with Heavy Slash, then watch for it falling or the slime in the pool moving. | Engine (Menü/Rückfrage) | open_run_level | Attack the nearest crystal beetle | Glimmerdeep Cleft lodge | 95/84 | 4.3 s |
| 11 | I head into the first grotto and attack the nearest crystal beetle on the vein with Heavy Slash. | Erzähler | open_run_level | Enter the grotto scene and start the cull | Glimmerdeep Cleft lodge | 95/84 | 29.8 s |
| 12 | I pay the gatekeeper ten coppers for the charter fee and head into the first grotto. | Erzähler | open_run_level | Pay the charter fee and enter the grotto to hunt | Glimmerdeep Cleft lodge | 95/84 | 18.8 s |
| 13 | I walk up the path into the first grotto mouth on the left bank, sword drawn, and approach the shifting shape in the dark. | Erzähler | open_run_level | Enter the first grotto and engage the cull targets | Glimmerdeep Cleft lodge | 95/84 | 50.3 s |
| 14 | I strike the nearest slime in its pool with Heavy Slash. | Engine (Menü/Rückfrage) | open_run_level | Begin the cull against the closest slime | Glimmerdeep Cleft lodge | 95/84 | 3.7 s |
| 15 | I leave the gatekeeper's side and walk alone into the first grotto, then attack the slime in the nearest pool with Heavy Slash. | Erzähler | open_run_level | Disengage from the gatekeeper scene and start the cull | Glimmerdeep Cleft lodge | 95/84 | 18.5 s |
| 16 | I pay the gatekeeper the ten coppers for entry, then walk through the gate into the first grotto and strike the slime in the nearest pool wi… | Erzähler | open_run_level | Pay the fee, enter the grotto, begin the cull | Glimmerdeep Cleft lodge | 95/84 | 21.6 s |
| 17 | I swing Heavy Slash down into the slime in the nearest pool. | Engine (Menü/Rückfrage) | open_run_level | Begin the cull on the closest slime | Glimmerdeep Cleft lodge | 95/84 | 5.1 s |
| 18 | I thank the gatekeeper, tell him I'm heading into the first grotto, and leave his lodge to walk up the left-bank path into the first grotto … | Erzähler | open_run_level | End the gatekeeper scene and start the slime cull | Glimmerdeep Cleft lodge | 95/84 | 25.4 s |
| 19 | I step away from the gatekeeper's lodge without another word and walk into the first grotto mouth alone. Once the gatekeeper scene is behind… | Erzähler | open_run_level | Break the engaged gatekeeper scene and start the slime cull | Glimmerdeep Cleft lodge | 95/84 | 23.6 s |
| 20 | I end my talk with the gatekeeper and close the conversation, then declare the slime in the nearest pool as my target and attack it with Hea… | Engine (Menü/Rückfrage) | open_run_level | Close the engaged gatekeeper dialogue explicitly, then fight the slime | Glimmerdeep Cleft lodge | 95/84 | 4.0 s |
| 21 | "Farewell." I turn and walk out of the lodge, ending the conversation with the gatekeeper. | Erzähler | open_run_level | Close the engaged gatekeeper scene so combat targeting unlocks | Glimmerdeep Cleft lodge | 95/84 | 24.4 s |
| 22 | I accept the gatekeeper's offer and pay the ten coppers to open the gate. | Erzähler | open_run_level | Pay the confirmed gate fee offer so the gate opens and the grotto scene unlocks | Glimmerdeep Cleft lodge | 95/84 | 12.6 s |
| 23 | I leave the lodge through the open gate, climb the left-bank path into the first grotto mouth, and once inside I target the slime in the nea… | Erzähler | open_run_level | Enter the first grotto and begin the slime cull | Glimmerdeep Cleft lodge | 95/84 | 25.7 s |
| 24 | I end my conversation with the gatekeeper and close the scene, then attack the nearest slime in the first pool with Heavy Slash. | Engine (Menü/Rückfrage) | open_run_level | Clear the stale engaged gatekeeper scene and start the slime cull | Glimmerdeep Cleft lodge | 95/84 | 4.8 s |
| 25 | #help | System (Befehl) | open_run_level | Find how to close the stuck engaged Gatekeeper scene | Glimmerdeep Cleft lodge | 95/84 | 2.2 s |
| 26 | #system How do I close or end the currently engaged Gatekeeper scene so I can act in the grotto? | Erzähler | open_run_level | Resolve the stuck ENGAGED scene | Glimmerdeep Cleft lodge | 95/84 | 8.0 s |
| 27 | "I'm short on coin right now," I tell the gatekeeper. "Is there work around the lodge, or can I settle the fee when I come back out?" | Erzähler | open_run_level | Resolve the unpaid gate fee with 0 copper | Glimmerdeep Cleft lodge | 95/84 | 19.9 s |
| 28 | "I'll haul the moss scrapings down to the lodge house," I tell the gatekeeper. "Hand me the stack and point me the way." | Erzähler | open_run_level | Accept the hauling job to earn coin for the gate fee | Glimmerdeep Cleft lodge | 95/84 | 21.7 s |
| 29 | I shoulder the sacking bundle and head down the road toward the lodge house with the blue lamp, past the stream ford, to find Marta before t… | Erzähler | open_run_level | Deliver Bren's moss to Marta for a copper and stew | Lodge house with the blue lamp | 95/84 | 30.9 s |
| 30 | I take the copper from the shelf and ladle myself a bowl of stew at the pot out back. | Erzähler | open_run_level | Collect the promised payment and stew from Marta | Lodge house with the blue lamp | 95/84 | 18.1 s |
| 31 | #bag | System (Befehl) | open_run_level | Verify coin count after the copper payment | Lodge house with the blue lamp | 95/84 | 2.2 s |
| 32 | I finish the stew and set the empty bowl down for the grey cat, then head back inside to ask Marta if there's any paid work around the lodge… | Erzähler | open_run_level | Earn more coin toward the ten-copper gate fee | Lodge house with the blue lamp | 95/84 | 24.0 s |
| 33 | "Done," I tell Marta, and head through the far door into the store-room to start clearing: sorting crates into keepable and rotten, stacking… | Erzähler | open_run_level | Do the store-room clearing for two copper and crate pickings | Lodge house with the blue lamp | 95/84 | 20.9 s |
| 34 | I take the hand-axe and iron pitons from the keepable pile, then ask Marta for directions to the outer grottos where the slime culling work … | Erzähler | open_run_level | Collect crate pickings and head toward the slime-culling job | Lodge house with the blue lamp | 95/84 | 18.8 s |
| 35 | I take the sacking bundle and head back across the ford where the rail post leans, then follow the stream upstream on my right to find the t… | Erzähler | open_run_level | Travel to the outer grottos for the slime-culling work | Lodge house with the blue lamp | 95/84 | 20.2 s |
| 36 | I step into the lowest grotto mouth, hand-axe ready, and look for the slimes to cull. | Erzähler | open_run_level | Start the slime culling in the first outer grotto | Lodge house with the blue lamp | 95/84 | 21.1 s |
| 37 | "Ten copper's more than I'm carrying — I've got two. Could I work off the rest, or would the academy take these moss scrapings or pitons aga… | Erzähler | open_run_level | Negotiate the ten-copper gate fee with only two copper | Lodge house with the blue lamp | 95/84 | 35.0 s |
| 38 | "Done. Show me where you want the four pitons set, and I'll drive them good and deep." | Erzähler | open_run_level | Accept the piton-work deal to cover the gate fee | Lodge house with the blue lamp | 95/84 | 23.2 s |
| 39 | I mark the register for the fee, then set the four pitons as the keeper showed: starter holes with the axe point, driven quiet and at a slan… | Erzähler | open_run_level | Pay the fee and complete the piton work to enter the grottos | Lodge house with the blue lamp | 95/84 | 53.1 s |
| 40 | I hand the keeper my two coppers and head down to the lowest mouth, quiet, axe in hand, to start the slime culling. | Erzähler | open_run_level | Pay the remaining fee and enter the lowest grotto for the slime work | Lodge house with the blue lamp | 95/84 | 20.2 s |
| 41 | I move in quiet and swing the hand-axe at the broad slime six paces in, splitting it on the wet shelf. | Engine (Menü/Rückfrage) | open_run_level | Start culling slimes in the lowest grotto | Lodge house with the blue lamp | 95/84 | 4.6 s |
| 42 | I return to the lowest grotto mouth down the cut steps and swing my hand-axe at the broad slime on the low shelf. | Erzähler | open_run_level | Retry the slime attack after the scene error | Glimmerdeep Grotto | 95/84 | 20.5 s |
| 43 | "The keeper's already marked my fee in the register — two coppers paid at the lodge. Check your ledger; I'm registered to work the lowest mo… | Erzähler | open_run_level | Get the gate warden to admit me based on the paid registration | Glimmerdeep Grotto | 95/84 | 36.8 s |
| 44 | I swing my hand-axe at the broad slime on the low shelf six paces in. | Engine (Menü/Rückfrage) | open_run_level | Cull the nearest slime in the lowest grotto | Glimmerdeep Grotto | 95/84 | 4.9 s |
| 45 | I tell the warden I'm heading down to the lowest mouth and step through the gate onto the cut steps, then move in quiet on the broad slime s… | Erzähler | open_run_level | Exit the stuck gate scene and attack the slime | Glimmerdeep Grotto | 95/84 | 13.1 s |
| 46 | #quests | System (Befehl) | open_run_level | Check whether the slime culling work is a recorded quest and what it requires | Glimmerdeep Grotto | 95/84 | 2.2 s |
| 47 | "I've no coin to spare tonight, so I'll earn it elsewhere first. Guard, is there paid work near the cleft — or can I sell these moss scrapin… | Erzähler | open_run_level | Find a way to earn the 10 cp gate fee instead of forcing entry | Glimmerdeep Grotto | 95/84 | 18.1 s |
| 48 | I walk down the track to the lodge and ask the keeper whether he's buying moss scrapings tonight, holding out the sacking bundle. | Erzähler | open_run_level | Sell moss scrapings to fund the gate fee | Lodge house with the blue lamp | 95/84 | 13.3 s |
| 49 | I set the sacking bundle on the counter. "Warden said you buy cleft moss scrapings. What will you give me for this bundle?" | Erzähler | open_run_level | Sell moss scrapings to the lodge keeper | Lodge house with the blue lamp | 95/84 | 19.4 s |
| 50 | "Four tonight will do. I'll take the four copper, keeper, and I'll keep the iron pitons and longsword out of the bargain." | Erzähler | open_run_level | Accept the confirmed four-copper offer for the wet moss bundle | Lodge house with the blue lamp | 95/84 | 17.9 s |
| 51 | I pocket the four copper and walk down the track to Marta's inn, then ask her what evening work she has going tonight. | Erzähler |  | Earn more coin via inn work toward the gate fee and lodging | Marta's inn | 95/84 | 37.4 s |
| 52 | I ask Marta for the goat errand details — where Hessel's house is and whether she'll point me to his granddaughter. | Erzähler | open_run_level | Take the goat recovery errand to earn coin | Marta's inn | 95/84 | 35.0 s |
| 53 | I skip the stew and walk down the lane to Hessel's house — white door, crooked gate — and knock, asking for him or his granddaughter Tilla a… | Erzähler | open_run_level | Take the goat recovery errand at Hessel's house | Hessel's house | 95/84 | 25.3 s |
| 54 | I name my price plainly while Tilla listens: "Five silver to bring Nanny back down safe tonight." | Erzähler | open_run_level | Agree a fee for the goat recovery | Hessel's house | 95/84 | 21.4 s |
| 55 | I take the four silver from Tilla and head out behind the house past the beanpatch, climbing toward the scree and calling patiently for Nann… | Erzähler | open_run_level | Take the four-silver advance and recover the goat | Scree behind Hessel's house | 95/84 | 22.7 s |
| 56 | I take out my bundle of iron pitons and rope if I have any, and check whether I can anchor a line from above — if not, I climb down slowly t… | Erzähler | open_run_level | Rescue the goat from the ledge | Scree behind Hessel's house | 95/84 | 28.3 s |
| 57 | I coax Nanny to climb the thirty feet of scree with me, staying below her on the slope and guiding her by horn and collar, talking steadily … | Erzähler | open_run_level | Lead the goat safely up the scree | Scree behind Hessel's house | 95/84 | 17.7 s |
| 58 | I knock and tell Hessel and Tilla the goat is penned safe, and ask for the rest of my pay. | Erzähler | open_run_level | Collect the agreed five-silver fee | Scree behind Hessel's house | 95/84 | 87.8 s |
| 59 | "She's walking sound — a scraped knee and nothing more. She likely wandered down after a straying kid, that's my guess." I give Tilla a nod … | Erzähler | open_run_level | Answer Hessel honestly but tactfully and seek lodging or supper | Scree behind Hessel's house | 95/84 | 18.0 s |
| 60 | I eat the stew and bread, thank Hessel and Tilla, and settle down by the hearth to sleep until morning. | Erzähler | open_run_level | Supper and overnight recovery at Hessel's hearth | Scree behind Hessel's house | 95/84 | 52.9 s |
| 61 | I eat the porridge, then set the leaning gatepost straight for Hessel before shouldering my gear and walking back to town. | Erzähler | open_run_level | Earn the floor, then return to town for Guild work | Glassmere | 95/84 | 19.5 s |
| 62 | I walk to the Glassmere Guild hall and read the contract board for jobs suited to a novice warrior. | Erzähler | open_run_level | Find an achievable Guild contract at the board | Adventurers' Guild hall, Glassmere | 95/84 | 36.1 s |
| 63 | "Taking one," I tell the clerk, and take the Biter in the Reeds contract — one bog cat for thirty copper sounds right for a novice. "I'll ac… | Erzähler | open_run_level | Accept a novice Guild contract from the board | Adventurers' Guild hall, Glassmere | 95/84 | 21.0 s |
| 64 | I head south out of Glassmere along the mill road toward the Oaklow reed beds to find Ferrin Oaklow. | Erzähler | open_run_level | Travel to the contract site and meet the client | the Oaklow reed beds south of Glassmere | 95/84 | 23.2 s |
| 65 | "Come along and beat the reeds if you're willing — an extra set of eyes on soft ground could save my hide. I'll lead toward the third stake … | Erzähler | open_run_level | Hunt the bog cat with Ferrin's help | the Oaklow reed beds south of Glassmere | 95/84 | 24.8 s |
| 66 | I grip my longsword and move to intercept the bog cat where the track narrows, keeping the pool at my side so it can't flank me. | Erzähler | open_run_level | Fight the bog cat at the narrows | the Oaklow reed beds south of Glassmere | 95/84 | 20.7 s |
| 67 | I take a two-handed grip and strike at the bog cat with Heavy Slash as it lands on the narrow track. | Erzähler | open_run_level | Kill the bog cat for the contract | the Oaklow reed beds south of Glassmere | 95/84 | 19.6 s |
| 68 | "That's all I need — I'll head back to Glassmere and have the slip sealed at the Guild hall." I walk back along the shore track toward the m… | Erzähler | open_run_level | Return to Glassmere to turn in the contract | Glassmere | 95/84 | 19.5 s |
| 69 | I enter Glassmere and walk to the Guild hall to turn in the A Biter in the Reeds contract slip. | Erzähler | open_run_level | Turn in the completed contract at the Guild hall | Adventurers' Guild hall, Glassmere | 95/84 | 18.1 s |
| 70 | I walk to the contract board and look over the fresh postings. | Erzähler | open_run_level | Choose the next Guild contract | Adventurers' Guild hall, Glassmere | 95/84 | 32.0 s |
| 71 | I take the Clear Glimmerdeep Grotto, Level 1 posting to the clerk and ask to accept it. | Erzähler | open_run_level | Accept a level-appropriate dungeon contract | Adventurers' Guild hall, Glassmere | 95/84 | 17.7 s |
| 72 | I pocket the slip and ask the clerk where I can buy rations and a torch before the shops close. | Erzähler | open_run_level | Provision for the dungeon trip | Adventurers' Guild hall, Glassmere | 95/84 | 11.5 s |
| 73 | I walk to Doran's general store with the green awning and ask what rations and torches he has and at what price. | Erzähler | open_run_level | Buy provisions for the dungeon trip | Doran's general store | 95/84 | 15.0 s |
| 74 | I take Doran's suggestion: two pitch-soaked torches and three packets of the waxed travel bread and sausage, and pay him the 14 copper. | Erzähler | open_run_level | Buy provisions for the Grotto trip | Doran's general store | 95/84 | 20.9 s |
| 75 | I buy three packets of the waxed travel bread and sausage at two copper each, six copper total. | Erzähler | open_run_level | Complete the provisioning purchase | Doran's general store | 95/84 | 18.1 s |
| 76 | #bag | System (Befehl) | open_run_level | Verify rations and torches are recorded before heading to the Grotto | Doran's general store | 95/84 | 2.5 s |
| 77 | I thank Doran and head for the Grotto's lowest mouth to start the slime culling contract. | Erzähler | open_run_level | Travel to the Grotto and begin the active contract | Glimmerdeep Grotto | 95/84 | 25.5 s |
| 78 | I light a torch and enter the Grotto, keeping my light low and away from the crystals. | Erzähler | open_run_level | Enter the dungeon and start the slime culling | Glimmerdeep Grotto | 95/84 | 20.0 s |
| 79 | I draw my longsword and strike the slime with Heavy Slash, keeping my torch held away from it. | Engine (Menü/Rückfrage) | open_run_level | Fight the crystal slime | Glimmerdeep Grotto | 95/84 | 4.5 s |
| 80 | I move away from the warden, deeper along the crystal shelf toward the slime, and strike the mineral slime with Heavy Slash. | Engine (Menü/Rückfrage) | open_run_level | Shift the active scene into the dungeon and fight the slime | Glimmerdeep Grotto | 95/84 | 4.4 s |
| 81 | I engage the crystal slime blocking my path on the crystal shelf and strike it with Heavy Slash. | Engine (Menü/Rückfrage) | open_run_level | Shift the active scene into the slime fight and attack | Glimmerdeep Grotto | 95/84 | 4.2 s |
| 82 | I speak to the warden: "I'm heading down to the lowest mouth for the slime culling now — anything I should know before I go?" | Erzähler | open_run_level | Interact with the warden to shift the active scene, then proceed to the slimes | Glimmerdeep Grotto | 95/84 | 24.3 s |
| 83 | I strike the sitting mineral slime with Heavy Slash. | Erzähler | open_run_level | Attack the slime now that the scene shows it | Glimmerdeep Grotto | 95/84 | 12.9 s |
| 84 | I step up to the mineral slime and strike it with Heavy Slash at close range. | Erzähler | open_run_level | Close to ENGAGED range and attack the slime | Glimmerdeep Grotto | 91/84 | 14.5 s |
| 85 | I strike the mineral slime again with Heavy Slash. | Erzähler | open_run_level | Finish the slime | Glimmerdeep Grotto | 91/84 | 19.9 s |
| 86 | #assign STR 3 VIT 2 | System (Befehl) | open_run_level | Spend level-up points on offense and survivability | Glimmerdeep Grotto | 91/84 | 2.5 s |
| 87 | I pick up the glowstone shard and continue down the crystal shelf into the first level, keeping alert for more slimes or beetles. | Erzähler | open_run_level | Loot the shard and press deeper toward clearing the grotto contract | quartz stubble chamber | 91/84 | 27.5 s |
| 88 | I strike the Quartz Ooze with Heavy Slash before it finishes stirring. | Erzähler | open_run_level | Engage and kill the quartz ooze | quartz stubble chamber | 91/84 | 18.3 s |
| 89 | I close the last stride to ENGAGED range and strike the Quartz Ooze with Heavy Slash. | Erzähler | open_run_level | Engage the ooze at proper range and attack | quartz stubble chamber | 91/84 | 16.1 s |
| 90 | I spend the level-up points, then continue through the darker gap in the far wall: #assign STR 2 VIT 1 | Erzähler | open_run_level | Assign level-up stats and press deeper into the grotto | fallen crystal hall | 91/84 | 21.9 s |
| 91 | I check the arched doorway past the dais for danger, then advance through it carefully, sword ready. | Erzähler | open_run_level | Explore the main route through the fallen hall | queen's crystal chamber | 91/84 | 23.5 s |
| 92 | I retreat back through the archway into the fallen hall, keeping my sword ready — the queen and her brood are too much for me now; I'll clea… | Erzähler | open_run_level | Disengage from the Glimmer Queen and clear weaker threats first | fallen crystal hall | 91/84 | 19.4 s |
| 93 | I squeeze past the fallen slab into the side passage, torch first and sword ready, checking for threats as I go. | Erzähler | open_run_level | Explore the side passage while the torch lasts | beetle nest chamber | 91/84 | 32.0 s |
| 94 | I squeeze through the gap at the rockfall's edge toward the cloth and metal, prying at the flat slab to free whatever's beneath it. | Erzähler | open_run_level | Loot the dead traveller's remains | beetle nest chamber | 91/84 | 24.5 s |
| 95 | I draw my sword and strike the beetle with Heavy Slash before it can close the distance. | Engine (Menü/Rückfrage) | open_run_level | Fight the ambushing beetle | beetle nest chamber | 91/84 | 4.6 s |
| 96 | I attack the beetle with Basic Attack before it can reach me. | Engine (Menü/Rückfrage) | open_run_level | Fight the ambushing beetle with a valid target name | beetle nest chamber | 91/84 | 4.1 s |
| 97 | I ready my sword and engage the beetle in combat, striking at it as it comes over the husks. | Engine (Menü/Rückfrage) | open_run_level | Enter combat with the beetle so it becomes a valid target | beetle nest chamber | 91/84 | 4.5 s |
| 98 | I hold my ground, sword raised, and watch the beetle's approach without striking. | Erzähler | open_run_level | See whether the beetle becomes a targetable actor before attacking again | beetle nest chamber | 91/84 | 18.4 s |
| 99 | I pry at the flat slab to free the rotted pack pinned beneath it. | Erzähler | open_run_level | Loot the dead traveller's remains | beetle nest chamber | 91/84 | 25.0 s |
| 100 | I take up my torch and sword and head back through the passage toward the fallen hall and the queen's chamber. | Erzähler | open_run_level | Continue the grotto-clearing contract by confronting the Glimmer Queen | fallen crystal hall | 91/84 | 37.9 s |
| 101 | I advance along the winding path between the crystal spikes toward the queen's chamber, sword and torch ready. | Erzähler | open_run_level | Confront the Glimmer Queen to clear the grotto contract | queen's crystal chamber | 91/84 | 23.6 s |
| 102 | I raise my sword and engage the Glimmer Queen, striking at her with Heavy Slash. | Erzähler | open_run_level | Fight the Glimmer Queen to clear the grotto contract | queen's crystal chamber | 91/84 | 15.0 s |
| 103 | I close the remaining distance to the basin's rim and strike at the Glimmer Queen with Heavy Slash. | Erzähler | open_run_level | Engage the Glimmer Queen in melee range | queen's crystal chamber | 91/84 | 15.3 s |
| 104 | I move down the basin's inner slope to close into ENGAGED range with the Glimmer Queen, then strike her with Heavy Slash. | Erzähler | open_run_level | Close distance and attack the queen | queen's crystal chamber | 91/84 | 16.2 s |
| 105 | I back out of the basin and retreat up the slope toward the arched doorway, keeping my torch raised and watching the queen. | Erzähler | open_run_level | Withdraw from the out-of-reach queen and leave the chamber | queen's crystal chamber | 91/84 | 17.3 s |
| 106 | I leave the queen's chamber through the arched doorway and follow the passage down, keeping my torch raised. | Erzähler | open_run_level | Withdraw from the unreachable queen and explore the grotto's lower passage | great cavern ledge below the queen's passage | 91/84 | 18.4 s |
| 107 | I strike at the Glimmer Queen with Heavy Slash while she is within reach. | Erzähler | open_run_level | Attack the queen now that the HUD shows her at SHORT range | great cavern ledge below the queen's passage | 91/84 | 17.2 s |
| 108 | I retreat back up the passage away from the ledge, keeping my torch up and my sword ready, heading for the grotto entrance. | Erzähler | open_run_level | Withdraw from the unbeatable queen and exit the dungeon | Glimmerdeep Cleft | 91/84 | 25.3 s |
| 109 | I walk down the rock path to the lodge and knock, asking the keeper for a bed for the night and whether the grotto counts as cleared with th… | Erzähler | open_run_level | Get lodging and clarify the contract status with the lodge keeper | Glimmerdeep Cleft lodge | 91/84 | 16.4 s |
| 110 | I step inside the lodge and ask the keeper for a bed for the night, and whether the grotto counts as cleared with the queen still alive. | Erzähler | open_run_level | Get lodging and clarify contract status | Glimmerdeep Cleft lodge | 91/84 | 22.7 s |
| 111 | I accept the bed for 2 copper and the stew with bread for 1 copper, pay Bren, eat, and sleep until morning. | Erzähler | open_run_level | Recover overnight at the lodge | Glimmerdeep Cleft lodge | 115/84 | 21.2 s |
| 112 | I tell Bren I'm heading back to Asterstead to report the Queen to the Guild, thank him, and set out on the road for Asterstead; on arrival I… | Erzähler | open_run_level | Report to Guild and find new work to level up before facing the queen | Adventurers' Guild hall, Asterhall | 115/84 | 72.3 s |
| 113 | I tell the clerk I'll withdraw nothing yet, and ask to take the Tusked Boar of the Spoil Heaps contract from the Novice board. | Erzähler | open_run_level | Accept a new achievable cull contract to level up | Adventurers' Guild hall, Asterhall | 115/84 | 26.2 s |
| 114 | I thank the clerk and set out on the Stonefield road for Stonefield Quarry. | Erzähler | open_run_level | Travel to the boar contract site | Adventurers' Guild hall, Asterhall | 115/84 | 25.1 s |
| 115 | I draw my longsword and set my stance, then attack the boar with Heavy Slash. | Erzähler | open_run_level | Engage the first boar | Adventurers' Guild hall, Asterhall | 115/84 | 18.1 s |
| 116 | I close to ENGAGED and attack the boar with Heavy Slash. | Erzähler | open_run_level | Close range and strike the boar | Adventurers' Guild hall, Asterhall | 112/84 | 25.8 s |
| 117 | I finish the wounded boar with Heavy Slash. | Erzähler | open_run_level | Kill boar A before the second joins | Adventurers' Guild hall, Asterhall | 112/84 | 22.3 s |
| 118 | I track the second boar toward the darker terraces, close to ENGAGED, and attack it with Heavy Slash. | Erzähler | open_run_level | Hunt the second boar for the cull contract | the Stonefield Quarry spoil heaps | 112/84 | 23.8 s |
| 119 | I attack the boar from behind with Heavy Slash before it turns on me. | Erzähler | open_run_level | Strike Boar B with first-strike advantage | the Stonefield Quarry spoil heaps | 112/84 | 59.0 s |
| 120 | I move silently along the spine of packed rubble to close to ENGAGED, then strike the boar from behind with Heavy Slash. | Erzähler | open_run_level | Close to ENGAGED and land the first strike on Boar B | the Stonefield Quarry spoil heaps | 112/84 | 21.1 s |
| 121 | I meet the boar head-on and attack it with Heavy Slash. | Erzähler | open_run_level | Fight Boar B at ENGAGED | the Stonefield Quarry spoil heaps | 97/84 | 30.6 s |
| 122 | I finish the wounded boar with Heavy Slash. | Erzähler | open_run_level | Kill Boar B | the Stonefield Quarry spoil heaps | 81/84 | 15.0 s |
| 123 | I finish it with another Heavy Slash. | Erzähler | open_run_level | Kill Boar B | the Stonefield Quarry spoil heaps | 81/84 | 14.6 s |
| 124 | #assign STR 2 VIT 3 | System (Befehl) | open_run_level | Spend level-up points on damage and survivability | the Stonefield Quarry spoil heaps | 81/84 | 2.7 s |
| 125 | I head back to Caelreth town and look for lodging for the night, then sleep until morning to recover. | Engine (Menü/Rückfrage) | open_run_level | Recover from wounds overnight in town | the Stonefield Quarry spoil heaps | 81/84 | 6.1 s |
| 126 | I head back to Asterhall and look for lodging for the night, then sleep until morning to recover. | Erzähler | open_run_level | Recover overnight in Asterhall | Asterhall | 81/84 | 21.5 s |
| 127 | I go to the Crooked Rail and ask for a cheap bed for the night, then sleep until morning. | Erzähler | open_run_level | Get lodging and recover overnight | the Crooked Rail | 81/84 | 22.3 s |
| 128 | I take the copper bed in the back room, pay the innkeeper, and sleep until morning. | Erzähler | open_run_level | Buy lodging and recover overnight | the Crooked Rail | 140/84 | 20.4 s |
| 129 | I leave the Crooked Rail and head back to the spoil heaps to hunt the remaining tusked boars for the cull contract. | Erzähler | open_run_level | Continue boar cull contract | the Stonefield Quarry spoil heaps | 140/84 | 16.9 s |
| 130 | I follow the fresh rooting sign past the third heap and search the low ground for tusked boars. | Erzähler | open_run_level | Hunt remaining boars for the cull contract | the low ground basin | 140/84 | 24.8 s |
| 131 | I follow the fresh trail into the reedbed at the reed-margin, sword ready, looking for the boar that went in. | Erzähler | open_run_level | Hunt remaining boars for the cull contract | the reedbed | 140/84 | 23.6 s |
| 132 | I attack the boar with Heavy Slash. | Erzähler | open_run_level | Fight Tusked Boar C for the cull contract | the reedbed | 140/84 | 15.1 s |
| 133 | I charge through the mud to close with the boar and bring it to ENGAGED, then attack with Heavy Slash. | Erzähler | open_run_level | Close to melee range and attack Tusked Boar C | the reedbed | 140/84 | 22.7 s |
| 134 | I advance on the boar to close into ENGAGED range. | Erzähler | open_run_level | Close to melee range with Tusked Boar C | the reedbed | 140/84 | 36.8 s |
| 135 | I attack the boar with Heavy Slash now that it's at SHORT. | Erzähler | open_run_level | Strike Tusked Boar C in melee | the reedbed | 140/84 | 13.1 s |
| 136 | I step in to ENGAGED range and attack the boar with Heavy Slash. | Erzähler | open_run_level | Close to ENGAGED and strike Tusked Boar C | the reedbed | 125/84 | 18.5 s |
| 137 | I attack the boar with Heavy Slash again. | Erzähler | open_run_level | Finish Tusked Boar C | the reedbed | 110/84 | 15.5 s |
| 138 | I finish the boar with a Basic Attack. | Erzähler | open_run_level | Kill Tusked Boar C for the cull contract | the reedbed | 110/84 | 14.0 s |
| 139 | I head back to the Guild hall in Caelreth and turn in the boar cull contract, then ask the chirurgeon at the watchman's post to treat my tus… | Engine (Menü/Rückfrage) | open_run_level | Turn in the 3/3 cull contract and get healing | the reedbed | 110/84 | 25.8 s |
| 140 | I head for the Glassmere Guild hall and turn in the boar cull contract, then ask the chirurgeon at the watchman's post to treat my tusk woun… | Erzähler | open_run_level | Turn in the completed cull contract and get healing | the watchman's post | 110/84 | 33.9 s |
| 141 | I pay the chirurgeon four copper for the stitches and dressing. | Erzähler | open_run_level | Accept the healer's confirmed offer | the watchman's post | 110/84 | 24.7 s |
| 142 | I buckle my armor plate back on and head out along the quarry road to the spoil heaps to hunt the third tusked boar. | Erzähler | open_run_level | Hunt the third boar for the cull contract | the Stonefield Quarry spoil heaps | 110/84 | 18.5 s |
| 143 | I search the reedbeds around the fresh wallow for the boar that made it, keeping my longsword ready. | Erzähler | open_run_level | Hunt the third boar for the cull contract | the Stonefield Quarry spoil heaps | 110/84 | 21.0 s |
| 144 | I plant myself beside the tunnel mouth and strike with Heavy Slash as the boar emerges. | Erzähler | open_run_level | Kill Tusked Boar D for the cull contract | the Stonefield Quarry spoil heaps | 110/84 | 16.6 s |
| 145 | I step back a few paces from the tunnel mouth and wait with my sword ready, hoping the boar charges out after me. | Erzähler | open_run_level | Lure the boar into sword range | the Stonefield Quarry spoil heaps | 110/84 | 98.0 s |
| 146 | I hold my ground and swing Heavy Slash at the boar as it charges. | Erzähler | open_run_level | Kill Tusked Boar D for the cull contract | the Stonefield Quarry spoil heaps | 110/84 | 27.1 s |
| 147 | I draw a thrown stone from my pouch and hurl it at the boar, then ready my sword to meet its charge if it comes. | Engine (Menü/Rückfrage) | open_run_level | Provoke the boar into charging into sword range | the Stonefield Quarry spoil heaps | 110/84 | 4.5 s |
| 148 | I close the ten paces to ENGAGED and swing Heavy Slash at the boar's neck as I arrive. | Erzähler | open_run_level | Close to range and attack the boar | the Stonefield Quarry spoil heaps | 110/84 | 24.1 s |
| 149 | I declare movement to ENGAGED with Tusked Boar D, then use Heavy Slash on its neck once in range. | Erzähler | open_run_level | Close the gap and attack the boar | the Stonefield Quarry spoil heaps | 100/84 | 22.1 s |
| 150 | I swing Heavy Slash at the boar's neck again. | Erzähler | open_run_level | Finish the wounded boar | the Stonefield Quarry spoil heaps | 100/84 | 23.2 s |
| 151 | I harvest the boar's hide and tusks with my hand-axe, then head back toward town to find the watchman's post and its chirurgeon for my wound… | Erzähler | open_run_level | Loot the kill and get healing | the watchman's post | 100/84 | 28.4 s |
| 152 | I sit down and accept the stitching for four copper. | Erzähler | open_run_level | Pay for healing at the chirurgeon | the watchman's post | 100/84 | 20.2 s |
| 153 | I ask the healer directly: "What's your price for cleaning and stitching this leg wound?" | Erzähler | open_run_level | Get a valid purchase offer for the wound treatment | the watchman's post | 100/84 | 13.0 s |
| 154 | I accept the healer's offer and buy the cleaning and stitching for four copper. | Erzähler | open_run_level | Purchase the wound treatment at the confirmed offer price | the watchman's post | 100/84 | 34.1 s |
| 155 | I head to the Guild hall and turn in the Cull the Tusked Boar contract — the recorded count stands at 3/3 defeated. | Erzähler | open_run_level | Turn in the completed boar cull at the Guild hall | Adventurers' Guild hall, Asterhall | 100/84 | 33.1 s |
| 156 | #assign STR 2 VIT 2 AGI 1 | System (Befehl) | open_run_level | Spend the 5 free stat points from the level-up | Adventurers' Guild hall, Asterhall | 100/84 | 3.0 s |
| 157 | I look over the Guild board for a new novice-level contract I can take, then find lodging for the night to recover. | Erzähler | open_run_level | Pick next contract and rest overnight | the Drowned Owl | 100/84 | 69.1 s |
| 158 | I pay the landlady two copper for the common room lodging, then sleep until morning. | Erzähler | open_run_level | Buy lodging and sleep to recover overnight | the Drowned Owl | 160/84 | 16.9 s |
| 159 | I walk to the Guild hall and ask to accept the Cull the Reed-Bog Cat contract from the board. | Erzähler | open_run_level | Accept a new novice Guild contract | Adventurers' Guild hall, Asterhall | 160/84 | 27.6 s |
| 160 | I ask the clerk to tell me about the wall work and the courier run on the new board, since the bog cat posting is gone. | Erzähler | open_run_level | Pick an achievable contract from the fresh board | Adventurers' Guild hall, Asterhall | 160/84 | 35.6 s |
| 161 | I accept the courier run to Millbrook from the board. | Engine (Menü/Rückfrage) | open_run_level | Take the courier contract | Adventurers' Guild hall, Asterhall | 160/84 | 6.3 s |
| 162 | I read the board to find the courier run posting. | Erzähler | open_run_level | Read the board before accepting | Adventurers' Guild hall, Asterhall | 160/84 | 36.8 s |
| 163 | I accept the Cull the Bog Cat at the Oaklow Reed Beds contract from the board. | Erzähler | open_run_level | Take the achievable bog cat cull contract | Adventurers' Guild hall, Asterhall | 160/84 | 39.4 s |
| 164 | I take the contract slip and head south along the road toward Glassmere and the Oaklow reed beds. | Erzähler | open_run_level | Travel to the bog cat cull site | road fork by the Oaklow reed beds | 160/84 | 26.8 s |
| 165 | I follow the boy's advice onto the causeway toward the east channel, watching the reed margins for the bog cat. | Erzähler | open_run_level | Hunt the bog cat at the east channel | east channel fishing platform | 160/84 | 24.2 s |
| 166 | I draw my longsword and face the bog cat as it comes out of the reeds, meeting it on the firm causeway ground. | Erzähler | open_run_level | Fight the bog cat for the cull contract | east channel fishing platform | 159/84 | 20.4 s |
| 167 | I use Heavy Slash on the bog cat. | Erzähler | open_run_level | Kill the bog cat for the cull contract | east channel fishing platform | 159/84 | 17.0 s |
| 168 | I take the contract slip and head back north along the causeway toward Glassmere to turn in the bog cat cull at the Guild hall. | Erzähler | open_run_level | Turn in the bog cat cull contract at the Guild | Adventurers' Guild hall, Glassmere | 159/84 | 19.6 s |
| 169 | I ask the clerk what other contracts are on the board today. | Erzähler | open_run_level | Pick the next Guild contract | Adventurers' Guild hall, Glassmere | 159/84 | 23.4 s |
| 170 | I tell the clerk I'll take the Tusked Boar contract and ask her to mark it active for me. | Erzähler | open_run_level | Accept the boar cull contract | Adventurers' Guild hall, Glassmere | 159/84 | 19.1 s |
| 171 | I thank the clerk and head for the Stonefield Quarry spoil heaps to hunt tusked boar, watching the scree for them. | Erzähler | open_run_level | Travel to Stonefield and hunt the 5 boar | the Stonefield Quarry spoil heaps | 159/84 | 20.8 s |
| 172 | I wait for the two rooting boar to separate, then move downwind and use Heavy Slash on the smaller one (boar G) from its flank. | Erzähler | open_run_level | Engage the boar pair one at a time | the Stonefield Quarry spoil heaps | 159/84 | 18.6 s |
| 173 | I move closer to boar G across the scree until it's in reach, then use Heavy Slash on it from its flank. | Erzähler | open_run_level | Close to MEDIUM range and strike boar G | the Stonefield Quarry spoil heaps | 159/84 | 60.9 s |
| 174 | I charge the last thirty paces straight at boar G and engage it, swinging Heavy Slash as I close. | Erzähler | open_run_level | Close to ENGAGED with boar G and strike | the Stonefield Quarry spoil heaps | 159/84 | 56.5 s |
| 175 | I close the remaining distance to boar G and engage it in melee. | Erzähler | open_run_level | Move to ENGAGED with boar G | the Stonefield Quarry spoil heaps | 159/84 | 19.5 s |
| 176 | I charge straight at boar G, closing until we are engaged in melee, and attack it there. | Erzähler | open_run_level | Close to ENGAGED with boar G and attack | the Stonefield Quarry spoil heaps | 159/84 | 18.0 s |
| 177 | I climb the shale slope toward boar G, moving steadily until we are engaged in melee, then attack it. | Erzähler | open_run_level | Close to ENGAGED with boar G and attack | the Stonefield Quarry spoil heaps | 159/84 | 25.2 s |
| 178 | I move to engage boar F at MEDIUM, closing to melee with it, and attack it with Heavy Slash. | Erzähler | open_run_level | Engage the closer boar with declared movement | the Stonefield Quarry spoil heaps | 159/84 | 16.0 s |
| 179 | I move down the slope to close from MEDIUM to ENGAGED with boar E, then attack it with Heavy Slash. | Erzähler | open_run_level | Engage boar E with declared movement and strike | the Stonefield Quarry spoil heaps | 159/84 | 16.4 s |
| 180 | I move across the broken ground toward boar E, closing the distance until it is ENGAGED, then attack it with Heavy Slash. | Erzähler | open_run_level | Close on boar E with declared movement and strike | the Stonefield Quarry spoil heaps | 159/84 | 17.5 s |
| 181 | I sprint straight at boar F at MEDIUM, running flat-out until it is ENGAGED, and attack it with Heavy Slash. | Erzähler | open_run_level | Close to ENGAGED with boar F and attack | the Stonefield Quarry spoil heaps | 159/84 | 16.7 s |
| 182 | I spend this turn only on movement: I run at boar E until it is ENGAGED, no attack yet. | Erzähler | open_run_level | Close with boar E as a dedicated move action | the Stonefield Quarry spoil heaps | 159/84 | 15.6 s |
| 183 | I take the last stride to boar E, closing SHORT to ENGAGED, and attack it with Heavy Slash. | Erzähler | open_run_level | Finish the last stride and strike boar E | the Stonefield Quarry spoil heaps | 144/84 | 18.0 s |
| 184 | I attack boar E with Heavy Slash. | Erzähler | open_run_level | Finish boar E | the Stonefield Quarry spoil heaps | 127/84 | 27.3 s |
| 185 | I attack boar E with Heavy Slash to finish it. | Erzähler | open_run_level | Kill boar E | the Stonefield Quarry spoil heaps | 127/84 | 21.4 s |
| 186 | #assign STR 2 VIT 2 AGI 1 | System (Befehl) | open_run_level | Spend level-up stat points | the Stonefield Quarry spoil heaps | 127/84 | 2.8 s |
| 187 | I chase down boar F before it escapes the spoil heaps, closing to ENGAGED, then attack it with Heavy Slash. | Erzähler | open_run_level | Pursue retreating boar F and attack | the Stonefield Quarry spoil heaps | 127/84 | 18.7 s |
| 188 | I spend this turn only on movement: I run after boar F along the spoil's base until it is ENGAGED, no attack yet. | Erzähler | open_run_level | Close the gap to boar F as a dedicated move action | the Stonefield Quarry spoil heaps | 127/84 | 14.6 s |
| 189 | I attack boar F with Heavy Slash. | Erzähler | open_run_level | Kill boar F now that it is in range | the Stonefield Quarry spoil heaps | 127/84 | 12.9 s |
| 190 | I step in to ENGAGED and attack boar F with Heavy Slash. | Erzähler | open_run_level | Close to ENGAGED and attack | the Stonefield Quarry spoil heaps | 120/84 | 19.8 s |
| 191 | I finish boar F with Heavy Slash. | Erzähler | open_run_level | Kill boar F | the Stonefield Quarry spoil heaps | 120/84 | 15.4 s |
| 192 | I search the spoil heaps for any sign of the remaining three boars before deciding whether to press on or head back to town to have my thigh… | Erzähler | open_run_level | Continue boar contract while weighing healing | the Stonefield Quarry spoil heaps | 120/84 | 20.2 s |
| 193 | I follow the two boars' trail west toward the far heaps, staying downwind, and engage the nearer of the pair with Heavy Slash. | Erzähler | open_run_level | Hunt the two western boars to finish the 5-boar contract | broad hollow between the western spoil heaps | 120/84 | 36.8 s |
| 194 | I attack boar H with Heavy Slash, keeping my shield side angled so boar I cannot flank me. | Erzähler | open_run_level | Kill the engaged boar before the second closes | broad hollow between the western spoil heaps | 114/84 | 32.7 s |
| 195 | I finish boar H with Heavy Slash. | Erzähler | open_run_level | Kill the wounded boar before the second one commits | broad hollow between the western spoil heaps | 114/84 | 24.9 s |
| 196 | I take the hide and tusks from boar H and head back toward Caelreth, making for the watchman's post left of the fountain to have my thigh wo… | Erzähler | open_run_level | Return to town, get healing | Healer on Tannery Row | 114/84 | 39.3 s |
| 197 | I sit on the bench and let the chirurgeon treat my thigh wound, paying whatever she asks. | Erzähler | open_run_level | Get healing at the healer's post | Healer on Tannery Row | 114/84 | 20.5 s |
| 198 | "Eight copper, understood — I accept. Here's the payment for stitching and dressing the wound," I say, counting out eight copper to the chir… | Erzähler | open_run_level | Complete payment for the treatment | Healer on Tannery Row | 114/84 | 16.2 s |
| 199 | I thank the healer and head to the Guild hall to check the boar contract board before finding lodging for the night. | Erzähler | open_run_level | Return to town, get healing — noted: Boar I fled west unhurt; contract at 3/5, so I need t… | Adventurers' Guild hall, Asterhall | 114/84 | 18.1 s |
| 200 | I look for lodging near the Guild hall and take a room for the night, then sleep until morning. | Erzähler | open_run_level | Rest overnight to recover before finishing the boar contract | The Coppersmith's Rest | 114/84 | 22.6 s |
| 201 | "I'll take the room and a supper — three copper total," I say, counting out the coins, then eat and sleep until morning. | Engine (Menü/Rückfrage) | open_run_level | Buy lodging and supper, then sleep | The Coppersmith's Rest | 114/84 | 9.7 s |
| 202 | "Room and supper, please — that's two copper for the room and one for supper, three total," I say, paying the innkeeper, then eat and sleep … | Engine (Menü/Rückfrage) | open_run_level | Buy lodging and supper, then sleep | The Coppersmith's Rest | 114/84 | 10.6 s |
| 203 | I buy the room for the night for 2 copper and the supper for 1 copper from Innkeeper C — 3 copper total — then eat and sleep until morning. | Erzähler | open_run_level | Buy lodging and supper explicitly, then sleep | The Coppersmith's Rest | 180/84 | 21.8 s |
| 204 | I set out from the inn for the Stonefield Spoil Heaps to hunt the two remaining boars and finish the contract. | Erzähler | open_run_level | Finish the boar contract (3/5) | the Stonefield Quarry spoil heaps | 180/84 | 20.7 s |
| 205 | I follow the trail toward the gorse where the boar is grunting, and attack it with Heavy Slash when it charges or comes into view. | Erzähler | open_run_level | Hunt the fourth boar to reach 4/5 on the contract | the Stonefield Quarry spoil heaps | 180/84 | 20.3 s |
| 206 | I meet the charge with a Heavy Slash to its shoulder, then sidestep to keep my blade between us. | Erzähler | open_run_level | Fight the fourth boar | the Stonefield Quarry spoil heaps | 173/84 | 18.8 s |
| 207 | I finish it with a Basic Attack to the head or neck. | Erzähler | open_run_level | Kill the fourth boar (14 HP left) | the Stonefield Quarry spoil heaps | 173/84 | 22.9 s |
| 208 | I follow the trail toward the old wash-run gully to the southeast and hunt the fifth boar. | Erzähler | open_run_level | Hunt the last boar to finish the contract | the wash-run at the edge of the Stonefield Quarry spoil heaps | 173/84 | 37.9 s |
| 209 | I take the younger boar first with a Heavy Slash, hoping to finish it fast before the sow engages. | Erzähler | open_run_level | Attack the smaller boar for the fifth kill | the wash-run at the edge of the Stonefield Quarry spoil heaps | 173/84 | 17.7 s |
| 210 | I close the distance toward the younger boar and attack it with Heavy Slash. | Erzähler | open_run_level | Close to ENGAGED and kill the fifth boar | the wash-run at the edge of the Stonefield Quarry spoil heaps | 161/84 | 15.3 s |
| 211 | I finish the young boar with another Heavy Slash before it charges again. | Erzähler | open_run_level | Kill the fifth boar (38 HP left) | the wash-run at the edge of the Stonefield Quarry spoil heaps | 161/84 | 19.4 s |
| 212 | If the sow turns to flee, I let her go and check my contract count; if she keeps closing on me, I meet her with a Heavy Slash. | Erzähler | open_run_level | Finish the fifth boar kill or let the sow retreat | the wash-run at the edge of the Stonefield Quarry spoil heaps | 161/84 | 18.9 s |
| 213 | I assign all 5 free Stat Points into VIT. | Erzähler | open_run_level | Spend level-up points before hunting the fifth boar | the wash-run at the edge of the Stonefield Quarry spoil heaps | 161/84 | 15.7 s |
| 214 | #assign VIT 5 | System (Befehl) | open_run_level | Spend level-up points | the wash-run at the edge of the Stonefield Quarry spoil heaps | 161/84 | 3.3 s |
| 215 | I dress the wound on my thigh as best I can, then push north up the spoil heaps to find and kill the fifth tusked boar. | Erzähler | open_run_level | Finish the boar contract (5th kill) | the Stonefield Quarry spoil heaps | 161/84 | 23.7 s |
| 216 | I charge down the open shale and meet the big boar with Heavy Slash. | Erzähler | open_run_level | Attack the fifth boar to finish the contract | the Stonefield Quarry spoil heaps | 161/84 | 19.6 s |
| 217 | I move down the slope toward the boar, closing to ENGAGED, then attack it with Heavy Slash. | Erzähler | open_run_level | Close distance and attack the fifth boar | the Stonefield Quarry spoil heaps | 161/84 | 17.6 s |
| 218 | I advance straight across the open hollow toward the boar until we are ENGAGED, then attack it with Heavy Slash. | Erzähler | open_run_level | Close to ENGAGED and attack the fifth boar | the Stonefield Quarry spoil heaps | 161/84 | 21.2 s |
| 219 | I brace and meet the boar's charge with Heavy Slash. | Erzähler | open_run_level | Kill the fifth boar | the Stonefield Quarry spoil heaps | 142/84 | 22.5 s |
| 220 | I use Heavy Slash on the boar again. | Erzähler | open_run_level | Kill the fifth boar | the Stonefield Quarry spoil heaps | 123/84 | 19.4 s |
| 221 | I finish the boar with a Basic Attack. | Erzähler | open_run_level | Kill the fifth boar | the Stonefield Quarry spoil heaps | 123/84 | 36.5 s |
| 222 | I bind my thigh wound properly, then start back toward the quarry watchman's post to see the chirurgeon and turn in the boar contract at the… | Erzähler | open_run_level | Recover and turn in the completed boar contract | Adventurers' Guild hall, Glassmere | 123/84 | 22.0 s |
| 223 | I ask the clerk what contracts are on the board suitable for a Novice, besides the Glimmerdeep Grotto clearance I already carry. | Erzähler | open_run_level | Assign stat points and browse the board | Adventurers' Guild hall, Glassmere | 123/84 | 25.4 s |
| 224 | I take the Gray Fen Wolves contract at the counter, then #assign VIT 2 AGI 2 WIL 1. | Erzähler | open_run_level | Accept wolf contract and spend level-up points | Adventurers' Guild hall, Glassmere | 123/84 | 17.2 s |
| 225 | #assign VIT 2 AGI 2 WIL 1 | System (Befehl) | open_run_level | Spend the 5 free stat points that the HUD still shows unspent | Adventurers' Guild hall, Glassmere | 123/84 | 3.4 s |
| 226 | I leave the Guild hall and go to the watchman's post left of the fountain, then ask the chirurgeon to treat my tusk wounds. | Erzähler | open_run_level | Get the boar wound properly treated before heading to Grayfen | watchman's post treatment room | 123/84 | 27.3 s |
| 227 | "I'll pay. Go ahead and treat it," and I hand over the 30 copper the shop lists for the treatment. | Erzähler | open_run_level | Accept the chirurgeon's confirmed 30 cp treatment offer | watchman's post treatment room | 123/84 | 17.2 s |
| 228 | I thank her and leave, then find lodging at an inn in Glassmere, pay for a room if one is offered, and sleep until morning to let the leg he… | Erzähler | open_run_level | Rest overnight as the chirurgeon advised before hunting the Gray Fen wolves | Leaping Trout inn | 123/84 | 22.7 s |
| 229 | "I'll take the room and the stew," and I hand over 10 copper. | Erzähler | open_run_level | Pay for lodging and meal | Leaping Trout inn | 123/84 | 17.4 s |
| 230 | I eat breakfast downstairs, then set out for the Gray Fen causeway to hunt the wolves. | Erzähler | open_run_level | Travel to the wolf contract area after resting | Leaping Trout inn | 123/84 | 22.5 s |
| 231 | "Bread and ham's fine," and I hand over 3 copper, then eat and set out for the Gray Fen causeway. | Erzähler | open_run_level | Buy breakfast at the confirmed price, then travel to the wolf contract area | the paddocks and causeway of Grayfen | 123/84 | 25.1 s |
| 232 | I walk down the causeway toward the small dark shape, sword ready, watching for wolves. | Erzähler | open_run_level | Investigate the carcass and start the wolf hunt | the paddocks and causeway of Grayfen | 123/84 | 40.1 s |
| 233 | I brace at the causeway's crown and meet the pale-muzzled wolf head-on, swinging Heavy Slash at it as it comes in range. | Erzähler | open_run_level | Fight the Gray Fen wolf pack, starting with the nearest wolf | the paddocks and causeway of Grayfen | 123/84 | 20.3 s |
| 234 | I step forward to close the last of the distance and swing Heavy Slash at the pale-muzzled wolf. | Erzähler | open_run_level | Close to ENGAGED range and attack the wolf | the paddocks and causeway of Grayfen | 123/84 | 19.6 s |
| 235 | I advance on the pale-muzzled wolf, moving to ENGAGED range with it. | Erzähler | open_run_level | Close distance as a declared move so attacks can connect next turn | the paddocks and causeway of Grayfen | 123/84 | 17.0 s |
| 236 | I swing Heavy Slash at the pale-muzzled wolf in front of me. | Erzähler | open_run_level | Attack the ENGAGED wolf | the paddocks and causeway of Grayfen | 99/84 | 22.0 s |
| 237 | I finish the pale-muzzled wolf with a Basic Attack, keeping my footing against the other two. | Erzähler | open_run_level | Kill the wounded wolf | the paddocks and causeway of Grayfen | 99/84 | 20.8 s |
| 238 | I follow the two wolves' trail into the drowned paddocks, hunting the third of the five. | Erzähler | open_run_level | Continue the wolf cull contract | collapsed byre in the drowned paddocks | 99/84 | 24.0 s |
| 239 | I position at the yard-wide gap where only one wolf can reach me at a time, then step in and swing Heavy Slash at the nearest wolf inside. | Engine (Menü/Rückfrage) | open_run_level | Hunt the remaining wolves at the byre choke point | collapsed byre in the drowned paddocks | 99/84 | 7.3 s |
| 240 | I step through the yard-wide gap into the byre and face the wolves inside, readying my blade. | Erzähler | open_run_level | Enter the byre so the wolves become targetable | inside the collapsed byre | 99/84 | 26.0 s |
| 241 | I swing Heavy Slash at Gray Fen Wolf F, the nearest wolf. | Erzähler | open_run_level | Attack the now-targetable nearest wolf | inside the collapsed byre | 99/84 | 19.9 s |
| 242 | I hold my ground and swing Basic Attack at Gray Fen Wolf F as it comes within reach. | Erzähler | open_run_level | Engage the closing wolf at proper range | inside the collapsed byre | 99/84 | 16.1 s |
| 243 | Wolf F is ENGAGED now, so I swing Heavy Slash at it. | Erzähler | open_run_level | Attack the engaged wolf with Heavy Slash | inside the collapsed byre | 71/84 | 16.8 s |
| 244 | I finish Gray Fen Wolf F with a Basic Attack. | Erzähler | open_run_level | Kill the wounded wolf before the others join | inside the collapsed byre | 71/84 | 32.9 s |
| 245 | I retreat slowly out of the byre toward the causeway, blade raised to keep the three wolves off, and head back to town before more wolves ar… | Erzähler | open_run_level | Withdraw wounded to town, recover, return for remaining wolves | Glassmere | 71/84 | 31.5 s |
| 246 | I tell the guard what happened out at the byre and ask where I can find the chirurgeon tonight — I need this leg seen to and a bed before I … | Erzähler | open_run_level | Get healing and lodging for the night | Glassmere | 71/84 | 22.8 s |
| 247 | I thank Hesk and walk to Tam Wray's house, the one with the blue door past the well square, and knock. "Hesk sent me — fen wolf got my leg o… | Erzähler | open_run_level | Get the leg wound treated by the chirurgeon | Tam Wray's chirurgeon house | 71/84 | 27.0 s |
| 248 | "Teeth through the boot — a big fen wolf, maybe two hours back now. I washed it with water from my flask on the road, nothing else. It needs… | Erzähler | open_run_level | Get the leg wound treated and lodging for the night | Tam Wray's chirurgeon house | 71/84 | 23.8 s |
| 249 | "All three — stitching, the bed, and the supper. That's three silver and a copper by my count." I count out the coins and hand them over. | Erzähler | open_run_level | Pay for healing, lodging and supper | Tam Wray's chirurgeon house | 71/84 | 18.7 s |
| 250 | I eat the supper, prop my leg up as told, pull the bolt across, and sleep until morning. | Erzähler | open_run_level | Recover overnight at the chirurgeon's | Tam Wray's chirurgeon house | 235/88 | 22.5 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 4 (notiert vor Zug 5): Contract board is nearly bare; new postings only at first bell tomorrow. Guild rank not yet registered.
- zu Zug 10 (notiert vor Zug 11): System says the active scene is still the gatekeeper at the lodge; combat targets not valid until the grotto scene opens.
- zu Zug 11 (notiert vor Zug 12): System's merchant panel confirms the charter fee as a purchase; ten coppers is affordable within 3 silver.
- zu Zug 12 (notiert vor Zug 13): HUD still shows lodge as location after the purchase; must physically move before combat targets are valid.
- zu Zug 14 (notiert vor Zug 15): System still lists the gatekeeper as the active engaged scene despite travel narration; will retry combat after explicitly leaving him.
- zu Zug 15 (notiert vor Zug 16): The earlier charter fee payment did not register as paid to the gatekeeper; the engine now presents it as a shop offer to accept.
- zu Zug 16 (notiert vor Zug 17): Fee purchase registered and the gatekeeper opened the gate; narration places me at the first grotto pool, though the HUD still lists the lodge.
- zu Zug 17 (notiert vor Zug 18): Fee purchase is confirmed and the gate was opened in narration, yet the System still lists Gatekeeper as the ENGAGED scene, blocking target selection; I am explicitly ending the conversation this time.
- zu Zug 18 (notiert vor Zug 19): Fee paid, gate opened, and narration twice places me inside the grotto, yet the System still lists Gatekeeper as the ENGAGED scene, blocking target selection.
- zu Zug 21 (notiert vor Zug 22): The engine re-presented the gate opening as a shop offer after my farewell; earlier payment apparently did not carry to the gatekeeper scene.
- zu Zug 23 (notiert vor Zug 24): HUD still lists Glimmerdeep Cleft lodge / Gatekeeper ENGAGED despite narration placing me inside the grotto; the stale scene keeps blocking combat.
- zu Zug 24 (notiert vor Zug 25): Paid the gate fee again (-10 copper, coin now 0) yet the System still shows Gatekeeper scene ENGAGED and blocks all combat targeting; stale scene persists across travel and farewells.
- zu Zug 26 (notiert vor Zug 27): System confirms fee never booked and I am still at the lodge; my earlier 'payment' messages never took effect.
- zu Zug 28 (notiert vor Zug 29): The earlier 'not enough coin' refusal was a misparse of my acceptance as a purchase; the bundle was actually handed over and the delivery promise is now on the HUD.
- zu Zug 30 (notiert vor Zug 31): Narration says the copper clicked into my pouch but the HUD still shows 0 Copper; checking inventory. A Grey Cat A combat scene (HP 30, SHORT) appeared while eating stew.
- zu Zug 31 (notiert vor Zug 32): Bag still shows 0 Copper despite the engine result confirming the copper clicked into my pouch — inventory ledger lags the narration. The sacking bundle also still lists in my bag though it was delivered.
- zu Zug 39 (notiert vor Zug 40): Keeper already pocketed two coppers into the lockbox earlier, yet HUD still shows 2 Copper and he asks again — possible double-charge; will verify coin after.
- zu Zug 40 (notiert vor Zug 41): HUD location still shows lodge house while narration places me at the lowest mouth; coin now 0 after second fee charge, confirming the double-charge.
- zu Zug 42 (notiert vor Zug 43): Keeper took the fee twice (paid 10 cp total via pitons plus 2 cp); narration keeps teleporting me between lodge, gate and lowest mouth while the active scene resets. Now back at the gate with Guard B.
- zu Zug 45 (notiert vor Zug 46): Gate fee is 10 cp but I have 0 Copper after paying twice; the warden blocks entry without it. I have no coin, so I need another way in or money first.
- zu Zug 58 (notiert vor Zug 59): Fee was four silver advance plus one silver owed — only the one silver was paid; HUD shows just 4 copper, so the coin seems unrecorded. Noted as a possible contradiction.
- zu Zug 61 (notiert vor Zug 62): The goat rescue left no quest record and no XP (still 0/100) — private jobs don't seem to advance Guild progress, so I'll prioritize board contracts.
- zu Zug 74 (notiert vor Zug 75): The combined buy partially failed: torches purchased (-8 cp) but the rations needed a separate offer acceptance.
- zu Zug 75 (notiert vor Zug 76): Engine said 'no single valid canonical offer' for the rations while narration showed the sale; checking inventory against the contradiction.
- zu Zug 76 (notiert vor Zug 77): Bag confirms 3 rations and 2 torches; contradictory purchase messages resolved — inventory is correct.
- zu Zug 79 (notiert vor Zug 80): Attack refused because the active scene is still Npc.npcacademy_warden despite narration placing me inside the Grotto — scene tracking lags narration.
- zu Zug 80 (notiert vor Zug 81): Scene tracking still shows Npc.npcacademy_warden despite narration placing me deep in the Grotto; two attack attempts refused.
- zu Zug 86 (notiert vor Zug 87): Stats confirmed STR 12, VIT 11 after assignment; slime culling at lowest mouth started with one kill and gel loot.
- zu Zug 95 (notiert vor Zug 96): Heavy Slash was refused: 'pale-jawed beetle' not a valid target in the active scene — the engine may need explicit combat engagement wording.
- zu Zug 96 (notiert vor Zug 97): System says 'ACTIVE SCENE — no targetable actor' even though the narrator described the beetle attacking; combat may need explicit engagement wording.
- zu Zug 97 (notiert vor Zug 98): Three attack attempts refused: 'no targetable actor' in the active scene even though the narrator described a beetle attacking — possible scene-sync contradiction.
- zu Zug 103 (notiert vor Zug 104): Engine says MEDIUM range persists even after narrated closing; must explicitly declare movement to ENGAGED before attacking.
- zu Zug 104 (notiert vor Zug 105): Queen's range reads LONG in the engine result but MEDIUM in the HUD; she closes faster than I can cross the drift, so melee seems unreachable at Level 2.
- zu Zug 105 (notiert vor Zug 106): Queen stays at LONG/MEDIUM regardless of approach — melee unreachable at L2; contract may still count as cleared once level-1 threats are handled.
- zu Zug 106 (notiert vor Zug 107): HUD lists the queen as Present at SHORT despite narration placing her across the vault — testing whether the engine now allows melee.
- zu Zug 107 (notiert vor Zug 108): Engine confirms the queen is SHORT but out of Heavy Slash's ENGAGED range; at L2 she seems unbeatable — may need to return after leveling.
- zu Zug 108 (notiert vor Zug 109): Engine confirms the queen is unreachable by Heavy Slash even at SHORT; contract still reads not cleared. May need to level up or find another way before returning.
- zu Zug 109 (notiert vor Zug 110): Engine refused the previous ask because arrival was pending; now at the door with Bren present, retrying inside.
- zu Zug 111 (notiert vor Zug 112): Queen unreachable by melee at L2; contract requires her death. Plan: level via other contracts first.
- zu Zug 113 (notiert vor Zug 114): Narrator gave a duplicate/different retelling of the Guild visit; the HUD confirms the boar contract is active at 0/3.
- zu Zug 117 (notiert vor Zug 118): HUD still shows boar cull at 0/3 despite a confirmed defeat and loot — count may update late or need reporting.
- zu Zug 118 (notiert vor Zug 119): HUD still shows boar cull at 0/3 despite two confirmed defeats; will report at Guild if it doesn't update.
- zu Zug 124 (notiert vor Zug 125): Boar cull now shows 1/3 in HUD despite two confirmed defeats; will verify count at Guild turn-in.
- zu Zug 133 (notiert vor Zug 134): Engine counts the boar at MEDIUM even though narration described ten yards; my earlier charge did not register as movement.
- zu Zug 140 (notiert vor Zug 141): HUD shows cull at 2/3 despite narrator claiming three killed; a third boar is still needed before turn-in.
- zu Zug 141 (notiert vor Zug 142): HUD shows Asterhall, not Glassmere — the turn-in attempt apparently happened at the wrong hall or narration misplaced it; cull confirmed 2/3, not READY.
- zu Zug 147 (notiert vor Zug 148): Engine demands declared movement to reach MEDIUM targets; plain 'close and strike' may still need explicit movement wording.
- zu Zug 148 (notiert vor Zug 149): HUD now shows Tusked Boar D at SHORT while narrator says a body-length gap; engine requires explicit declared movement before attacks.
- zu Zug 151 (notiert vor Zug 152): Harvest of hide and tusks was flagged 'not possible — already held', so loot is already in the pouch.
- zu Zug 152 (notiert vor Zug 153): Previous purchase was refused: 'no single valid canonical offer' despite the healer quoting four copper; engine may need an explicit offer request.
- zu Zug 162 (notiert vor Zug 163): The clerk's wall work and Millbrook courier jobs are not on the actual board; only culls listed. Glimmerdeep queen still unresolved (60 cp pending).
- zu Zug 176 (notiert vor Zug 177): Engine says boar G is at LONG despite narrator placing it at thirty paces; earlier closing attempts were refused for lacking declared movement.
- zu Zug 177 (notiert vor Zug 178): Boar G retreated over the ridge; count still 0/5. Present targets now F and E at MEDIUM.
- zu Zug 178 (notiert vor Zug 179): Engine requires explicit declared movement; closing phrases without it were refused three times.
- zu Zug 179 (notiert vor Zug 180): HUD shows E and F now at LONG, not MEDIUM as narrator claimed; narrator keeps describing positions the engine contradicts.
- zu Zug 181 (notiert vor Zug 182): Engine refuses combined move+attack; boars retreat to keep range, so I will try movement as its own action.
- zu Zug 185 (notiert vor Zug 186): Level 5 confirmed; boar contract at 1/5 after killing E; F is retreating.
- zu Zug 195 (notiert vor Zug 196): Boar I fled west unhurt; contract at 3/5, so I need two more boars after recovering.
- zu Zug 198 (notiert vor Zug 199): Treatment succeeded after explicitly accepting the quoted 8 copper price; paid 119 copper remaining.
- zu Zug 201 (notiert vor Zug 202): System asked to clarify prices; confirmed room 2 cp + supper 1 cp = 3 cp, matching the quoted total.
- zu Zug 202 (notiert vor Zug 203): System required a fully itemized buy statement; rephrasing with explicit goods and total price.
- zu Zug 203 (notiert vor Zug 204): Purchase finally confirmed after itemizing goods and merchant; recovery complete overnight.
- zu Zug 224 (notiert vor Zug 225): Turn 224's assign did not register: HUD still shows Free Stat Points 5 and old stats, so I repeat the command.
- zu Zug 225 (notiert vor Zug 226): Assign worked this time: VIT 30, AGI 11, WIL 8, 0 points left. Boar contract no longer listed among active quests, so it seems turned in.
- zu Zug 226 (notiert vor Zug 227): Narrator says three silver but the System shop panel prices the treatment at 30 cp; going with the System price.
- zu Zug 230 (notiert vor Zug 231): Narrator time is Day 7 morning but HUD still shows Day 6, 15:38; trusting the newer engine result on arrival.
- zu Zug 234 (notiert vor Zug 235): Two attacks refused because the wolf stays at MEDIUM and retreats as I advance; trying a pure movement declaration.
- zu Zug 239 (notiert vor Zug 240): System says no valid target though the narrator placed wolves inside; likely need to enter the scene before combat can register.
- zu Zug 241 (notiert vor Zug 242): Heavy Slash only reaches ENGAGED; wolves at MEDIUM/SHORT must close first. Wolf F is now SHORT and approaching.
- zu Zug 244 (notiert vor Zug 245): Wolves hold byre at dusk with more howling nearby; 2/5 wolves defeated, worth returning after healing and rest.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t56 | 67 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t69 | 84 | 1 | – | nein | 1 | gewonnen, 72 XP |
| enc.t73 | 89 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t97 | 116 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t102 | 121 | 1 | – | nein | 1 | gewonnen, 152 XP |
| enc.t115 | 136 | 1 | – | nein | 1 | gewonnen, 152 XP |
| enc.t126 | 149 | 1 | – | nein | 1 | gewonnen, 102 XP |
| enc.t141r | 166 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t158 | 183 | 1 | – | nein | 1 | gewonnen, 180 XP |
| enc.t164 | 190 | 1 | – | nein | 1 | gewonnen, 102 XP |
| enc.t168 | 194 | 1 | – | nein | 1 | gewonnen, 102 XP |
| enc.t178 | 206 | 1 | – | nein | 1 | gewonnen, 102 XP |
| enc.t182 | 210 | 1 | – | nein | 1 | gewonnen, 152 XP |
| enc.t190 | 219 | 1 | – | nein | 1 | gewonnen, 224 XP |
| enc.t206 | 236 | 1 | – | nein | 1 | gewonnen, 216 XP |
| enc.t212 | 243 | 1 | – | nein | 1 | gewonnen, 240 XP |

## Quests

- **A Biter in the Reeds** — active (Zug 63) → completed (Zug 69), READY
  - Aufgabe: Kill 1 bog cat at the Oaklow reed beds south of Glassmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 bog cat killed at the Oaklow reed beds south of Glassmere.
- **Cull the Quarry Boars** — expired (Zug 169)
  - Aufgabe: Kill 4 tusked boars at Stonefield Quarry spoil heaps. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 tusked boars killed at Stonefield Quarry spoil heaps.
- **Thin the Howlers of Grayfen** — expired (Zug 169)
  - Aufgabe: Kill 6 gray fen wolves at the paddocks and causeway of Grayfen. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 6 gray fen wolves killed at the paddocks and causeway of Grayfen.
- **The Bear of Hollowmere Wood** — expired (Zug 169)
  - Aufgabe: Kill 1 great scarred bear at the charcoal camps of Hollowmere Wood. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 great scarred bear killed at the charcoal camps of Hollowmere Wood.
- **Clear Glimmerdeep Grotto, Level 1** — active (Zug 71), Dungeon loc.glimmerdeep_grotto Ebene 1
  - Aufgabe: Clear level 1 of Glimmerdeep Grotto. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Glimmerdeep Grotto is clear.
- **Cull the Reed-Bed Bog Cat** — expired (Zug 157)
  - Aufgabe: Kill 1 bog cat at the Oaklow reed beds south of Glassmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 bog cat killed at the Oaklow reed beds south of Glassmere.
- **Cull the Tusked Boar of the Spoil Heaps** — active (Zug 113) → completed (Zug 155), READY
  - Aufgabe: Kill 3 tusked boar at the Stonefield Quarry spoil heaps. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 tusked boar killed at the Stonefield Quarry spoil heaps.
- **Thin the Gray Fen Wolf Pack** — expired (Zug 157)
  - Aufgabe: Kill 4 gray fen wolf at the paddocks and causeway of Grayfen. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 gray fen wolf killed at the paddocks and causeway of Grayfen.
- **Slay the Great Scarred Bear of Hollowmere** — expired (Zug 157)
  - Aufgabe: Kill 1 great scarred bear at the charcoal camps of Hollowmere Wood. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 great scarred bear killed at the charcoal camps of Hollowmere Wood.
- **Drive Out the Grayfen Paddock Wolves** — expired (Zug 157)
  - Aufgabe: Kill 5 gray fen wolf at the old paddock ditches of Grayfen. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 5 gray fen wolf killed at the old paddock ditches of Grayfen.
- **Cull the Reed-Bed Bog Cat** — expired (Zug 162)
  - Aufgabe: Kill 1 bog cat at the Oaklow reed beds south of Glassmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 bog cat killed at the Oaklow reed beds south of Glassmere.
- **Thin the Tusked Boars of the Spoil Heaps** — expired (Zug 162)
  - Aufgabe: Kill 4 tusked boars at the Stonefield Quarry spoil heaps. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 tusked boars killed at the Stonefield Quarry spoil heaps.
- **Drive Down the Grayfen Wolf Pack** — expired (Zug 162)
  - Aufgabe: Kill 5 gray fen wolves at the paddocks and causeway of Grayfen. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 5 gray fen wolves killed at the paddocks and causeway of Grayfen.
- **Clear the Old Paddock Ditches** — expired (Zug 162)
  - Aufgabe: Kill 6 gray fen wolves at the old paddock ditches of Grayfen. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 6 gray fen wolves killed at the old paddock ditches of Grayfen.
- **Slay the Scarred Bear of Hollowmere** — expired (Zug 162)
  - Aufgabe: Kill 1 great scarred bear at the charcoal camps of Hollowmere Wood. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 great scarred bear killed at the charcoal camps of Hollowmere Wood.
- **Cull the Bog Cat at the Oaklow Reed Beds** — active (Zug 163) → completed (Zug 168), READY
  - Aufgabe: Kill 1 bog cat at the Oaklow reed beds south of Glassmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 bog cat killed at the Oaklow reed beds south of Glassmere.
- **Cull the Bog Cat of the Oaklow Reed Beds** — expired (Zug 223)
  - Aufgabe: Kill 1 bog cat at the Oaklow reed beds south of Glassmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 bog cat killed at the Oaklow reed beds south of Glassmere.
- **Thin the Tusked Boar on the Stonefield Spoil Heaps** — active (Zug 170) → completed (Zug 222)
  - Aufgabe: Kill 5 tusked boar at the Stonefield Quarry spoil heaps. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 5 tusked boar killed at the Stonefield Quarry spoil heaps.
- **Drive Down the Gray Fen Wolves of the Causeway** — expired (Zug 223)
  - Aufgabe: Kill 4 gray fen wolf at the paddocks and causeway of Grayfen. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 gray fen wolf killed at the paddocks and causeway of Grayfen.
- **Slay the Great Scarred Bear of Hollowmere** — expired (Zug 223)
  - Aufgabe: Kill 1 great scarred bear at the charcoal camps of Hollowmere Wood. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 great scarred bear killed at the charcoal camps of Hollowmere Wood.
- **Clear Glimmerdeep Grotto Level 1** — expired (Zug 223), Dungeon loc.glimmerdeep_grotto Ebene 1
  - Aufgabe: Clear level 1 of Glimmerdeep Grotto. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Glimmerdeep Grotto is clear.
- **Drive Down the Gray Fen Wolves of the Causeway** — active (Zug 224)
  - Aufgabe: Kill 5 gray fen wolf at the paddocks and causeway of Grayfen. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 5 gray fen wolf killed at the paddocks and causeway of Grayfen.

## Auffälligkeiten

- Zug 4, Nachricht 7 (board_failed): the board generator failed
- Zug 6, Nachricht 12 (extraction_repaired): the extractor's first answer needed a repair
- Zug 7, Nachricht 14 (extraction_repaired): the extractor's first answer needed a repair
- Zug 8, Nachricht 16 (extraction_repaired): the extractor's first answer needed a repair
- Zug 11, Nachricht 22 (extraction_repaired): the extractor's first answer needed a repair
- Zug 12, Nachricht 24 (extraction_repaired): the extractor's first answer needed a repair
- Zug 13, Nachricht 25 (planner_repaired): the planner's first answer needed a repair
- Zug 16, Nachricht 32 (extraction_repaired): the extractor's first answer needed a repair
- Zug 23, Nachricht 46 (extraction_repaired): the extractor's first answer needed a repair
- Zug 32, Nachricht 64 (extraction_repaired): the extractor's first answer needed a repair
- Zug 39, Nachricht 78 (extraction_repaired): the extractor's first answer needed a repair
- Zug 43, Nachricht 86 (extraction_repaired): the extractor's first answer needed a repair
- Zug 52, Nachricht 104 (extraction_repaired): the extractor's first answer needed a repair
- Zug 56, Nachricht 112 (extraction_repaired): the extractor's first answer needed a repair
- Zug 65, Nachricht 130 (extraction_repaired): the extractor's first answer needed a repair
- Zug 66, Nachricht 131 (planner_repaired): the planner's first answer needed a repair
- Zug 68, Nachricht 136 (extraction_repaired): the extractor's first answer needed a repair
- Zug 74, Nachricht 147 (planner_repaired): the planner's first answer needed a repair
- Zug 78, Nachricht 156 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (quartz ooze): refused, no fight (Patch 8.4.1 guard)
- Zug 91, Nachricht 182 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (crystal beetle): refused, no fight (Patch 8.4.1 guard)
- Zug 93, Nachricht 186 (extraction_repaired): the extractor's first answer needed a repair
- Zug 94, Nachricht 188 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (crystal beetle): refused, no fight (Patch 8.4.1 guard)
- Zug 98, Nachricht 196 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (crystal beetle): refused, no fight (Patch 8.4.1 guard)
- Zug 101, Nachricht 202 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (Glimmer Queen): refused, no fight (Patch 8.4.1 guard)
- Zug 112, Nachricht 224 (extraction_repaired): the extractor's first answer needed a repair
- Zug 119, Nachricht 238 (extraction_repaired): the extractor's first answer needed a repair
- Zug 119, Nachricht 238 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 119, Nachricht 238 (finish): extract ended with finish_reason "length"
- Zug 130, Nachricht 260 (extraction_repaired): the extractor's first answer needed a repair
- Zug 139, Nachricht 277 (planner_repaired): the planner's first answer needed a repair
- Zug 139, Nachricht 277 (finish): plan ended with finish_reason "length"
- Zug 140, Nachricht 280 (extraction_repaired): the extractor's first answer needed a repair
- Zug 141, Nachricht 282 (extraction_repaired): the extractor's first answer needed a repair
- Zug 173, Nachricht 346 (extraction_repaired): the extractor's first answer needed a repair
- Zug 173, Nachricht 346 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 173, Nachricht 346 (finish): extract ended with finish_reason "length"
- Zug 174, Nachricht 348 (extraction_repaired): the extractor's first answer needed a repair
- Zug 174, Nachricht 348 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 174, Nachricht 348 (finish): extract ended with finish_reason "length"
- Zug 196, Nachricht 392 (extraction_repaired): the extractor's first answer needed a repair
- Zug 201, Nachricht 401 (planner_repaired): the planner's first answer needed a repair
- Zug 202, Nachricht 403 (planner_repaired): the planner's first answer needed a repair
- Zug 203, Nachricht 405 (planner_repaired): the planner's first answer needed a repair
- Zug 213, Nachricht 425 (stat_words): the player spent Stat Points in words, not with #assign; nothing was assigned (for review: did the story tell them as done?)
- Zug 228, Nachricht 456 (extraction_repaired): the extractor's first answer needed a repair
- Zug 232, Nachricht 464 (extraction_repaired): the extractor's first answer needed a repair
- Zug 245, Nachricht 490 (extraction_repaired): the extractor's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 26× keine gültige JSON-Entscheidung (Züge 21, 27, 28, 30, 34, 37, 38, 41, 42, 45, 49, 53, 67, 92, 107, 125, 129, 132, 141, 143, 145, 153, 156, 158, 181, 223)
- 4 Aufruf(e) mit finish_reason "length" (Nr. 332 extract, Nr. 387 plan, Nr. 488 extract, Nr. 492 extract)

System-Panels: CLARIFY 6, NOT TAKEN 2, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: ambient 8, guild_canon 1, passage 11, scene_context 61, offer 3, no_go 6, gate_fee 1, attack_commitment 8, guild_completion 1, engine_owned_fact 10, pc_inventory 7, dungeon_foe 5, world_rule 15, dungeon_foe_thread 1, engine_owned_combat 1, quest_count 1, guild_payout 2, entity_fact 2, time_cap 1, group_unclear 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 3, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 26/250 Erstantworten ungültig (10.4 %); 26 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 244 | 7 | 2.5 s | 4.5 s | 12164 | 9895 | 79 | – | stop 243, length 1 | 1 |
| narrator | 218 | 0 | 8.4 s | 13.3 s | 11376 | 8731 | 408 | – | stop 218 | 0 |
| extract | 243 | 23 | 5.7 s | 9.6 s | 12501 | 9325 | 333 | – | stop 240, length 3 | 3 |
| board | 9 | 2 | 10.6 s | 18.1 s | 2359 | 2148 | 1113 | – | stop 9 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 110:06 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 14.3 s) | 0:31 min |
| 250 Züge, Spiel (Senden bis HUD nach der Extraktion) | 91:46 min — Median 20.3 s, p90 36.5 s, max 98.0 s |
| 250 Züge, Spieler-Entscheidung | 12:00 min — Median 2.2 s, 26 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 13:22 min / 1:50 min / 36:38 min / 28:25 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 24.9 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 16:36 min, 80 Züge ≈ 33:12 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spiel | 145 | – | 98.0 s | 20.3 s |
| Spiel | 58 | – | 87.8 s | 20.3 s |
| Spiel | 112 | – | 72.3 s | 20.3 s |
| Provider narrator | 58 | 157 | 77.5 s | 8.4 s |
| Provider narrator | 60 | 163 | 38.8 s | 8.4 s |
| Provider narrator | 157 | 439 | 30.2 s | 8.4 s |
| Provider extract | 145 | 408 | 84.6 s | 5.7 s |
| Provider extract | 119 | 332 | 44.6 s | 5.7 s |
| Provider extract | 173 | 488 | 39.5 s | 5.7 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
