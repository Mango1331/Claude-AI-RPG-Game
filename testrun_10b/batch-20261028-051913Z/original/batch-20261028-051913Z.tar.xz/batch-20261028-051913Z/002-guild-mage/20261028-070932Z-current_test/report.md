# Avereth Live-Test 20261028-070932Z-current_test

## Kurzfassung

- **Laufprofil:** guild-mage; Startklasse Mage, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** abgebrochen: Limit erreicht — 250 turns
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 10. Sicherheitsgrenzen: 250 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** Level 6, 502 XP seit Levelaufstieg, 304 cp, HP 159, MP 215; Ort loc.old_burial_ground_above_the_old_crown_catacombs. Ausrüstung und Skills stehen in evaluation.json → progression.checkpoint.
- **Charakter:** mage (mage.arcane_bolt, mage.arcane_ward) · Regelstand 2 (Warrior, Mage, Rogue)
- **Ziel-Dungeon:** Old Crown Catacombs, Ebene 1 (Vertrag quest.clear_the_old_crown_catacombs_level_1_2)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: pragmatic adventurer: sell surplus loot and invest in useful equipment and techniques
- **Züge:** 250 · **Dauer:** 141:55 min · **LLM-Aufrufe der Engine/des Erzählers:** 708
- **Beobachtete Abdeckung:** 37 unterschiedliche gebuchte Reiseziele · 23 Kämpfe · 4 Verkäufe (357 cp Umsatz, ohne Questzahlungen/Geschenke) · 0 Ausrüstungswechsel · 2 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 38
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.106 |
| Git | 75a436636fa0 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 69.6 s |
| Browser | chrome 156.0.8078.48 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261028-070932Z-current_test“, Seed 1098264378 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | Mage. | Engine (Menü/Rückfrage) | creation_complete | Choose Mage as base class | public roadside verge outside Alderwatch | 90/84 | 2.3 s |
| 2 | I choose Arcane Bolt and Arcane Ward as my two starter skills. | Engine (Menü/Rückfrage) | creation_complete | Pick starter skills | public roadside verge outside Alderwatch | 90/96 | 2.1 s |
| 3 | I walk to the city gate of Alderwatch and enter the city. | Erzähler | open_run_level | Enter Alderwatch to find the Guild hall | Alderwatch | 90/96 | 17.5 s |
| 4 | I ask around the gate square for directions to the Adventurers' Guild hall. | Erzähler | open_run_level | Find the Guild hall to register | Alderwatch | 90/96 | 15.6 s |
| 5 | I enter the Guild hall and ask to register as an adventurer. | Erzähler | open_run_level | Register at the Adventurers' Guild | Adventurers' Guild hall, Alderwatch | 90/96 | 17.2 s |
| 6 | I place two silver on the counter, put my hand on the stone, and say my name plainly: "Alaric Red." I pay the registration fee. | Erzähler | open_run_level | Register at the Guild | Adventurers' Guild hall, Alderwatch | 90/96 | 16.4 s |
| 7 | I walk to the contract board and look over what's posted. | Erzähler | open_run_level | Browse Guild contracts for a novice job | Adventurers' Guild hall, Alderwatch | 90/96 | 31.7 s |
| 8 | I take the Mire Adder notice to the clerk and ask to accept the contract. | Erzähler | open_run_level | Accept the novice adder hunt contract | Adventurers' Guild hall, Alderwatch | 90/96 | 15.1 s |
| 9 | I leave the Guild hall and travel to the Millrace Ponds below Lower Weir, heading for the reed margins where the mire adder hunts. | Erzähler | open_run_level | Travel to the contract site for the adder hunt | the Millrace Ponds below Lower Weir | 90/96 | 107.7 s |
| 10 | I walk the firm ground along the reed margins, scanning the water and reeds for the mire adder, staying clear of the soft mud. | Erzähler | open_run_level | Search for the adder from firm ground | the Millrace Ponds below Lower Weir | 90/96 | 26.7 s |
| 11 | I ask at the mill where the adder is usually seen, then search that spot from firm ground. | Erzähler | open_run_level | Get local info and retry the search | the mill by the weir | 90/96 | 30.6 s |
| 12 | I walk down to the third pond and search the shallows at the cattle-drink from firm ground, watching the reed line for a sunning adder. | Erzähler | open_run_level | Hunt the mire adder at the third pond | the third pond | 90/96 | 27.4 s |
| 13 | I search the third pond now that I've arrived, scanning the reed line and mud from the firm cattle lane for the sunning adder. | Erzähler | open_run_level | Search the arrived-at third pond for the adder | the third pond | 90/96 | 32.8 s |
| 14 | I move along the cattle lane to the far stretch of shore near the old fishhook stake and search the reed line there again. | Erzähler | open_run_level | Search a new stretch of the third pond for the sunning adder | the third pond | 90/96 | 17.3 s |
| 15 | I search the reed stand near the old fishhook stake, following the shed-skin sign into the reeds from firm ground. | Erzähler | open_run_level | Track the adder by the shed skin | the third pond | 90/96 | 28.1 s |
| 16 | I cast Arcane Bolt at the adder from my firm footing before it can move. | Erzähler | open_run_level | Open combat against the mire adder | the third pond | 90/86 | 15.7 s |
| 17 | I harvest the adder's parts and head back to the Millrace Guild hall to turn in the contract. | Erzähler | open_run_level | Complete the adder hunt and turn it in | Adventurers' Guild hall, Alderwatch | 90/86 | 20.4 s |
| 18 | I ask the clerk to show me the Guild board's current novice contracts, looking for another hunt or gathering job I can start today. | Erzähler | open_run_level | Pick the next contract from the board | Adventurers' Guild hall, Alderwatch | 90/86 | 17.8 s |
| 19 | I accept the boar-thinning contract from the clerk and set out east for the Sunfield Terraces vineyards. | Erzähler | open_run_level | Take the achievable boar contract and travel for it | the Sunfield Terraces vineyards east of Alderwatch | 90/86 | 31.0 s |
| 20 | I climb the terraces toward the dry-stone wall where the boars are said to gather, staff ready, and look for the boar by the olives. | Erzähler | open_run_level | Hunt the boars on the upper terraces | the Sunfield Terraces vineyards east of Alderwatch | 90/86 | 24.3 s |
| 21 | I cast Arcane Bolt at the boar rooting under the third olive. | Engine (Menü/Rückfrage) | open_run_level | Attack the first brambleback boar | the Sunfield Terraces vineyards east of Alderwatch | 90/86 | 6.7 s |
| 22 | I step through the gap in the wall and cast Arcane Bolt at the boar under the third olive. | Erzähler | open_run_level | Engage the boar as a valid target by entering the scene | the Sunfield Terraces vineyards east of Alderwatch | 90/86 | 26.8 s |
| 23 | I cast Arcane Bolt at Brambleback Boar A. | Erzähler | open_run_level | Attack the boar | the Sunfield Terraces vineyards east of Alderwatch | 37/76 | 23.3 s |
| 24 | I cast Arcane Bolt at Brambleback Boar A. | Erzähler | open_run_level | Keep attacking the boar | the Sunfield Terraces vineyards east of Alderwatch | 14/66 | 42.4 s |
| 25 | I cast Arcane Bolt at Brambleback Boar A to finish it. | Erzähler | open_run_level | Kill the boar before it gores me again | the Sunfield Terraces vineyards east of Alderwatch | 14/56 | 29.7 s |
| 26 | #assign VIT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up points to survive future fights | the Sunfield Terraces vineyards east of Alderwatch | 14/56 | 2.2 s |
| 27 | I accept Boar-Tempered Grit with #passives, then call down to the farmer that one of his boars is dead and I'm badly hurt. | Erzähler | open_run_level | Take the offered passive and get help/recovery after near-death fight | the Sunfield Terraces vineyards east of Alderwatch | 14/56 | 39.1 s |
| 28 | I lean on the farmer and let him help me down to the house to be treated and rest. | Erzähler | open_run_level | Recover from near-death with the farmers' help | Osser's farmhouse | 14/56 | 39.9 s |
| 29 | I let Marta finish treating my wounds, then ask if I can rest here until morning. | Erzähler | open_run_level | Get treated and sleep to recover HP | Osser's farmhouse | 110/116 | 25.3 s |
| 30 | I get up, thank Osser and Marta, and head back up to the vineyard to finish the boar contract—three more to kill. | Erzähler | open_run_level | Continue the boar contract | the Sunfield Terraces vineyards east of Alderwatch | 110/116 | 41.1 s |
| 31 | I follow the tracks over the stone wall toward the bramble fold, staff ready, and cast Arcane Bolt at the first boar I spot. | Erzähler | open_run_level | Hunt the remaining boars | the bramble fold | 110/116 | 38.6 s |
| 32 | I cast Arcane Bolt at the rooting boar below, keeping the slope between me and the watchful one. | Erzähler | open_run_level | Open the fight on the closer boar | the bramble fold | 86/106 | 35.2 s |
| 33 | I cast Arcane Bolt at the wounded boar below me. | Erzähler | open_run_level | Finish off Boar B before dealing with C | the bramble fold | 62/96 | 34.5 s |
| 34 | I cast Arcane Bolt at the wounded boar to finish it. | Erzähler | open_run_level | Kill Boar B before facing C | the bramble fold | 62/86 | 22.2 s |
| 35 | #assign WIL 3 VIT 2 | System (Befehl) | open_run_level | Spend level-up points to boost casting and survivability | the bramble fold | 62/86 | 2.2 s |
| 36 | I take a moment to bind my torn hip with a strip of cloth, then follow the fold down toward where the second boar went, moving carefully alo… | Erzähler | open_run_level | Recover slightly and continue hunting the third boar | rooted clearing in the bramble fold | 62/86 | 26.5 s |
| 37 | I keep the bramble edge between us, step back out of its charge line, and cast Arcane Bolt at Boar D. | Erzähler | open_run_level | Engage the last boar at range | rooted clearing in the bramble fold | 62/76 | 15.4 s |
| 38 | I cast Arcane Bolt at Boar D again before it can charge. | Erzähler | open_run_level | Finish the wounded boar at range | rooted clearing in the bramble fold | 49/66 | 17.5 s |
| 39 | I cast Arcane Bolt at Boar D to finish it. | Erzähler | open_run_level | Kill the wounded boar | rooted clearing in the bramble fold | 49/56 | 14.9 s |
| 40 | #assign WIL 3 VIT 2 | System (Befehl) | open_run_level | Spend level-up points to survive the wounded state and next fight | rooted clearing in the bramble fold | 49/56 | 2.2 s |
| 41 | I bind my hip properly with fresh cloth, then follow the bramble fold downhill toward the vine rows, searching for the fourth boar's rooting… | Erzähler | open_run_level | Hunt the fourth and final contract boar near the vine rows | the Sunfield Terraces vineyards east of Alderwatch | 49/56 | 48.9 s |
| 42 | I follow the old rooting downhill through the torn vine rows, staying alert for the fourth boar. | Erzähler | open_run_level | Find and hunt the fourth contract boar | the Sunfield Terraces vineyards east of Alderwatch | 49/56 | 29.6 s |
| 43 | I keep the vine rows between us, back away along the row out of its charge line, and cast Arcane Bolt at the old boar. | Erzähler | open_run_level | Engage the fourth boar at range from cover while badly wounded | the Sunfield Terraces vineyards east of Alderwatch | 49/46 | 17.3 s |
| 44 | I cast Arcane Ward, then brace behind it as it charges. | Erzähler | open_run_level | Block the incoming charge with a barrier | the Sunfield Terraces vineyards east of Alderwatch | 49/36 | 17.3 s |
| 45 | I cast Arcane Bolt point-blank at the boar's head. | Erzähler | open_run_level | Finish the fourth boar with a ranged strike before the ward drops | the Sunfield Terraces vineyards east of Alderwatch | 32/26 | 15.3 s |
| 46 | I cast Arcane Bolt at the boar's skull as it wheels over me. | Erzähler | open_run_level | Finish the boar before it gores again | the Sunfield Terraces vineyards east of Alderwatch | 32/16 | 14.7 s |
| 47 | I harvest what I can from the old bull, then head down to Osser's farmyard to report the vineyard is cleared and collect the tusks and hides… | Erzähler | open_run_level | Complete the boar contract turn-in | Osser's farmhouse | 32/16 | 37.9 s |
| 48 | I accept Osser's invitation and go inside to let Marta look at my leg, then ask about the contract completion for the four boars. | Erzähler | open_run_level | Get treated and confirm contract completion | inside Osser's farmhouse | 32/16 | 47.8 s |
| 49 | I thank Marta and Osser, eat some bread and ham, then set out for the Guild hall in Alderwatch to turn in the boar contract. | Erzähler | open_run_level | Turn in the completed contract | Adventurers' Guild hall, Alderwatch | 32/16 | 20.4 s |
| 50 | #assign WIL 3 VIT 2 | System (Befehl) | open_run_level | Spend the five level-up stat points | Adventurers' Guild hall, Alderwatch | 32/16 | 2.5 s |
| 51 | I ask the desk clerk what contracts are posted on the board suitable for a Novice mage, and mention I have boar hides and tusks to sell. | Erzähler | open_run_level | Find the next contract and sell loot | Adventurers' Guild hall, Alderwatch | 32/16 | 29.3 s |
| 52 | I ask the clerk to stamp the Mire Adder contract for me, then ask where I can find a cheap bed for the night nearby. | Erzähler | open_run_level | Accept an easy contract and recover overnight | Adventurers' Guild hall, Alderwatch | 32/16 | 50.7 s |
| 53 | #quests | System (Befehl) | open_run_level | Verify the Mire Adder contract is ACTIVE | Adventurers' Guild hall, Alderwatch | 32/16 | 2.5 s |
| 54 | I hand the clerk the Mire Adder skin, fang, and venom sac as proof of the kill and ask to turn in the completed Mire Adder contract. | Erzähler | open_run_level | Turn in the adder contract proof | Adventurers' Guild hall, Alderwatch | 32/16 | 22.0 s |
| 55 | I take road one: I ask the clerk to stamp the Mire Adder cull for me now, and as soon as it's stamped I hand her the same skin, fang and ven… | Erzähler | open_run_level | Stamp the contract then immediately turn in the held proof | Adventurers' Guild hall, Alderwatch | 32/16 | 18.9 s |
| 56 | I pocket the copper and ask the clerk to point me to the cheapest nearby bed, then head there, take the room, and sleep until morning. | Erzähler | open_run_level | Recover overnight before the next contract | The Sleepy Ewe | 32/16 | 107.8 s |
| 57 | I ask the innkeeper for a pallet for the night and a bowl of the supper, and hand over the two and a half copper. | Erzähler | open_run_level | Buy lodging and supper, then sleep | The Sleepy Ewe | 32/16 | 30.3 s |
| 58 | I settle onto the window pallet and sleep through until morning. | Erzähler | open_run_level | Actually sleep to recover HP before next contract | The Sleepy Ewe | 155/188 | 25.6 s |
| 59 | I head to the Guild hall and ask to see the contract board for new Novice contracts. | Erzähler | open_run_level | Pick the next Guild contract | Adventurers' Guild hall, Alderwatch | 155/188 | 31.8 s |
| 60 | I ask the clerk to accept the board's Brambleback Boar contract — I already hold four hides and seven tusks from the Sunfield Terraces as pr… | Erzähler | open_run_level | Turn in boar proof against the fresh board contract | Adventurers' Guild hall, Alderwatch | 155/188 | 23.5 s |
| 61 | I carry the four boar hides and seven tusks to the tannery off Copper Row and ask the tanner what he'll pay for the lot. | Erzähler | open_run_level | Sell surplus boar loot at the tannery before hunting fresh proof | tannery off Copper Row | 155/188 | 21.6 s |
| 62 | I accept the tanner's offer and take the seventy copper for the four hides and seven tusks. | Erzähler | open_run_level | Sell surplus boar loot at the confirmed offer | tannery off Copper Row | 155/188 | 14.2 s |
| 63 | I head east out of Alderwatch to the Sunfield Terraces and hunt the four brambleback boars for the contract. | Erzähler | open_run_level | Hunt boars for the active contract | the Sunfield Terraces vineyards east of Alderwatch | 155/188 | 16.2 s |
| 64 | I follow the fresh clover-print trail up the third terrace's waste strip toward the dense scrub, staff ready, and cast Arcane Bolt at the fi… | Erzähler | open_run_level | Engage a boar along the fresh trail for the contract | the bramble fold | 155/188 | 39.1 s |
| 65 | I cast Arcane Bolt at the boar in the hollow. | Erzähler | open_run_level | Fight the boar for the contract | the bramble fold | 140/178 | 14.3 s |
| 66 | I cast Arcane Bolt at the boar. | Erzähler | open_run_level | Kill the boar for the contract | the bramble fold | 125/168 | 12.6 s |
| 67 | I cast Arcane Bolt at the boar to finish it. | Erzähler | open_run_level | Kill the boar for the contract | the bramble fold | 125/158 | 15.7 s |
| 68 | I follow the cloven prints deeper into the scrub, staff ready, and cast Arcane Bolt at the next brambleback boar I find. | Erzähler | open_run_level | Hunt the second boar for the 4-count contract | trampled clearing above the vine rows | 125/158 | 24.4 s |
| 69 | I cast Arcane Bolt at the small boar nearest me before the others close in. | Erzähler | open_run_level | Kill boar 2 of 4 for the contract | trampled clearing above the vine rows | 89/149 | 18.2 s |
| 70 | I cast Arcane Bolt at Brambleback Boar G to finish it. | Erzähler | open_run_level | Kill boar 3 of 4 | trampled clearing above the vine rows | 61/140 | 18.1 s |
| 71 | I finish Brambleback Boar G with another Arcane Bolt. | Erzähler | open_run_level | Kill boar 3 of 4 | trampled clearing above the vine rows | 52/131 | 45.4 s |
| 72 | I cast Arcane Bolt at Brambleback Boar H. | Erzähler | open_run_level | Kill boar 4 of 4 | trampled clearing above the vine rows | 42/122 | 22.1 s |
| 73 | I cast Arcane Bolt at Brambleback Boar H to finish it. | Erzähler | open_run_level | Kill boar 4 of 4 | trampled clearing above the vine rows | 42/113 | 27.7 s |
| 74 | I assign my 5 free stat points: #assign WIL 2 INT 2 VIT 1 | Erzähler | open_run_level | Spend level-up points, then recover before the bull boar | trampled clearing above the vine rows | 42/113 | 18.5 s |
| 75 | I head down the rooting trail to Osser's farmhouse and take rest there until my wounds mend, keeping clear of the bull boar at the compost h… | Erzähler | open_run_level | Recover HP at the farmhouse before hunting the fourth boar | Osser's farmhouse | 42/113 | 25.6 s |
| 76 | I go inside the farmhouse, bar the door, and rest on the bench until my wounds mend. | Erzähler | open_run_level | Recover HP at the farmhouse | inside Osser's farmhouse | 42/113 | 22.5 s |
| 77 | #assign WIL 2 INT 2 VIT 1 | System (Befehl) | open_run_level | Retry the stat assignment that did not register | inside Osser's farmhouse | 42/113 | 2.6 s |
| 78 | I stay resting on the bench by the hearth and sleep until my wounds are fully healed. | Engine (Menü/Rückfrage) | open_run_level | Continue recovering HP before hunting the fourth boar | inside Osser's farmhouse | 42/113 | 4.7 s |
| 79 | I sleep on the bench for 6 hours to recover from my wounds. | Erzähler | open_run_level | Recover HP with a named duration | inside Osser's farmhouse | 141/224 | 17.0 s |
| 80 | I open the door to Osser and buy a share of his bread and bacon for a fair price. | Erzähler | open_run_level | Buy food, then hunt the fourth boar | inside Osser's farmhouse | 141/224 | 16.7 s |
| 81 | I buy one cut of bacon and a share of the bread from Osser for 3 copper and eat at his table. | Erzähler | open_run_level | Buy food, then hunt the fourth boar | inside Osser's farmhouse | 141/224 | 24.6 s |
| 82 | I thank Osser, bar the door, and sleep until morning; at dawn I go after the bull boar at the compost heap and attack it with Arcane Bolt. | Erzähler | open_run_level | Recover fully overnight, then finish the 4/4 boar contract | inside Osser's farmhouse | 165/224 | 45.0 s |
| 83 | I cast Arcane Bolt at the bull boar at the compost heap. | Erzähler | open_run_level | Attack the fourth boar to finish the contract | inside Osser's farmhouse | 126/215 | 20.2 s |
| 84 | I cast Arcane Bolt at the boar again. | Erzähler | open_run_level | Finish the fourth boar to complete the 4/4 contract | inside Osser's farmhouse | 126/206 | 18.1 s |
| 85 | I tell Osser I can walk, and go inside to let him see to the wound and rest until the bleeding stops. | Engine (Menü/Rückfrage) | open_run_level | Recover from reopened wound at Osser's house | inside Osser's farmhouse | 126/206 | 5.2 s |
| 86 | I rest until the bleeding stops and Osser finishes seeing to the wound, about two hours. | Erzähler | open_run_level | Recover from the reopened wound at Osser's house | inside Osser's farmhouse | 159/224 | 19.7 s |
| 87 | I set out for the Guild hall in Alderwatch and turn in the boar contract there, showing the slip and the hide and tusk. | Erzähler | open_run_level | Turn in the 4/4 boar contract at the Alderwatch Guild hall | Adventurers' Guild hall, Alderwatch | 159/224 | 22.7 s |
| 88 | I ask the desk woman what contracts she has on the board suitable for a Novice mage, and mention I still have the active Mire Adder cull at … | Erzähler | open_run_level | Browse the Guild board for the next achievable contract | Adventurers' Guild hall, Alderwatch | 159/224 | 21.6 s |
| 89 | I ask the clerk to accept the Mire Adder cull contract turn-in, presenting the adder skin, fang and venom sac as proof of the kill. | Erzähler | open_run_level | Turn in the active Mire Adder contract with carried proof | Adventurers' Guild hall, Alderwatch | 159/224 | 12.9 s |
| 90 | Since the adder kill didn't count, I'll take the Clear the Old Crown Catacombs, Level 1 contract instead and ask the clerk to accept it. | Erzähler | open_run_level | Take the catacombs contract | Adventurers' Guild hall, Alderwatch | 159/224 | 18.4 s |
| 91 | I head east past the tanners' row to the old burial ground and find the entrance to the Old Crown Catacombs. | Erzähler | open_run_level | Travel to the catacombs for the active contract | old burial ground above the Old Crown Catacombs | 159/224 | 26.9 s |
| 92 | I slip through the slab door and descend the stone steps into the catacombs with my staff ready. | Erzähler | open_run_level | Enter the Old Crown Catacombs to clear Level 1 | old burial ground above the Old Crown Catacombs | 159/224 | 35.4 s |
| 93 | I take the left passage, quiet and level, staff ready, moving carefully down the corridor. | Erzähler | open_run_level | Explore the quiet left gallery toward clearing Level 1 | old burial ground above the Old Crown Catacombs | 159/224 | 31.2 s |
| 94 | I cast Arcane Bolt at the skeleton before it can rise. | Engine (Menü/Rückfrage) | open_run_level | Attack the skeleton first | old burial ground above the Old Crown Catacombs | 159/224 | 9.5 s |
| 95 | I cast Arcane Bolt at the seated skeleton in the corner of the basin chamber before it can rise. | Engine (Menü/Rückfrage) | open_run_level | Attack the skeleton with a valid target | old burial ground above the Old Crown Catacombs | 159/224 | 4.5 s |
| 96 | I stand my ground in the doorway, staff raised, and wait to see if the skeleton rises. | Erzähler | open_run_level | Observe the inert skeleton until it becomes a target | old burial ground above the Old Crown Catacombs | 159/224 | 40.2 s |
| 97 | I cast Arcane Bolt at Restless Skeleton A. | Erzähler | open_run_level | Attack the skeleton now that it is a targetable actor | old burial ground above the Old Crown Catacombs | 159/215 | 21.5 s |
| 98 | I cross the basin chamber and take the far passage, following the fresh dragging scuffs deeper into the catacombs. | Erzähler | open_run_level | Continue clearing Catacombs Level 1 toward the quest target | old burial ground above the Old Crown Catacombs | 159/215 | 26.6 s |
| 99 | I cast Arcane Bolt at the nearer of the two skeletons in the dark gallery. | Engine (Menü/Rückfrage) | open_run_level | Engage the two skeletons from the archway | old burial ground above the Old Crown Catacombs | 159/215 | 4.2 s |
| 100 | I step through the archway into the gallery and advance toward the sounds in the dark until the skeletons come into view. | Erzähler | open_run_level | Enter the gallery so the skeletons become targetable actors | old burial ground above the Old Crown Catacombs | 159/215 | 31.1 s |
| 101 | I descend the worn steps into the catacombs, following the green moss-light down toward the two voices at the stair's foot. | Erzähler | open_run_level | Re-enter the catacombs and reach the gallery so the skeletons become targetable | old burial ground above the Old Crown Catacombs | 159/215 | 39.2 s |
| 102 | I cast Arcane Bolt at Restless Skeleton A. | Engine (Menü/Rückfrage) | open_run_level | Engage the two closing skeletons | old burial ground above the Old Crown Catacombs | 159/215 | 6.3 s |
| 103 | I level my staff and attack the nearer skeleton as it closes on me. | Engine (Menü/Rückfrage) | open_run_level | Engage the skeletons that narration shows closing in the vault, since the lettered names w… | old burial ground above the Old Crown Catacombs | 159/215 | 5.8 s |
| 104 | I cast Arcane Bolt at the standing skeleton with the thigh-bone club as it lunges at me. | Engine (Menü/Rückfrage) | open_run_level | Engage the closing skeleton with a descriptive target | old burial ground above the Old Crown Catacombs | 159/215 | 8.9 s |
| 105 | #map | System (Befehl) | open_run_level | Check confirmed location and exits to resync with the active scene | old burial ground above the Old Crown Catacombs | 159/215 | 2.6 s |
| 106 | I enter the Old Crown Catacombs through the way in from the burial ground above. | Erzähler | open_run_level | Descend into the catacombs so combat targets become valid | Landing chamber of the Old Crown Catacombs | 159/215 | 50.2 s |
| 107 | I follow the drag-mark down the narrow passage toward the creaking sounds, staff ready. | Erzähler | open_run_level | Descend toward the sounds to find targetable undead for the catacombs quest | Landing chamber of the Old Crown Catacombs | 159/215 | 40.7 s |
| 108 | The narrow way is sealed, so I return to the landing chamber and take the level broad passage instead, staff ready. | Erzähler | open_run_level | Explore the open passage since the narrow one is barred | burial gallery with three ranks of niches | 159/215 | 51.5 s |
| 109 | I cast Arcane Bolt at Restless Skeleton B, the nearest with the sword-shard, as it charges me. | Erzähler | open_run_level | Fight the three synced skeletons for the catacombs quest | burial gallery with three ranks of niches | 126/206 | 35.7 s |
| 110 | I cast Arcane Bolt at Restless Skeleton C, the smaller one jabbing at my ribs. | Erzähler | open_run_level | Defeat the remaining skeletons for the catacombs quest | burial gallery with three ranks of niches | 114/197 | 21.9 s |
| 111 | I cast Arcane Bolt at Restless Skeleton D. | Erzähler | open_run_level | Defeat the last skeleton | burial gallery with three ranks of niches | 101/188 | 22.3 s |
| 112 | I cast Arcane Bolt at Restless Skeleton D to finish it. | Erzähler | open_run_level | Defeat the last skeleton | burial gallery with three ranks of niches | 101/179 | 21.5 s |
| 113 | #assign INT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up points | burial gallery with three ranks of niches | 101/179 | 2.7 s |
| 114 | I continue down the broad passage toward the deeper dark, staff ready. | Erzähler | open_run_level | Explore the catacombs toward clearing level 1 | Dripping pool chamber below the broad passage | 101/179 | 59.1 s |
| 115 | I examine the pale bone heap on the lowest step, staff ready, before going on. | Engine (Menü/Rückfrage) | open_run_level | Inspect the bone heap for clues or loot | Dripping pool chamber below the broad passage | 101/179 | 6.4 s |
| 116 | I examine the pale bone heap on the lowest step, staff ready, staying alert for anything moving below. | Erzähler | open_run_level | Inspect the bone heap, then continue clearing level 1 | Dripping pool chamber below the broad passage | 101/179 | 34.5 s |
| 117 | I follow the worn path through the rough breach, staff ready and moving quietly. | Erzähler | open_run_level | Track the bone-cracking creature through the rough breach | Low-niche corridor with candle stubs | 101/179 | 50.9 s |
| 118 | I cast Arcane Bolt at the Skeletal Gravekeeper. | Erzähler | open_run_level | Open combat with the gravekeeper | Low-niche corridor with candle stubs | 101/170 | 29.9 s |
| 119 | I search the gravekeeper's remains and take the satchel of unburnt candle stubs, then continue down the corridor toward the larger space pas… | Erzähler | open_run_level | Loot, then keep clearing catacombs level 1 | larger space past the shallow recess | 101/170 | 38.6 s |
| 120 | I cast Arcane Bolt at the Gallery Warden. | Erzähler | open_run_level | Fight the Gallery Warden to clear catacombs level 1 | larger space past the shallow recess | 101/170 | 28.5 s |
| 121 | I cast Arcane Bolt at the Gallery Warden, now in range. | Erzähler | open_run_level | Fight the Warden at MEDIUM range | larger space past the shallow recess | 81/161 | 54.0 s |
| 122 | I cast Arcane Bolt at the Gallery Warden. | Erzähler | open_run_level | Keep damaging the Warden at ENGAGED range | larger space past the shallow recess | 66/152 | 25.0 s |
| 123 | I cast Arcane Bolt at the Gallery Warden to finish it. | Erzähler | open_run_level | Kill the Warden with one more bolt | larger space past the shallow recess | 66/143 | 24.6 s |
| 124 | I take the glinting object above the altar-slab, then head back toward the catacomb entrance to leave and turn in the cleared level-1 contra… | Erzähler | open_run_level | Claim loot and exit to turn in contract | Adventurers' Guild hall, Alderwatch | 66/143 | 48.0 s |
| 125 | I check the contract board for a Novice contract I can take. | Erzähler | open_run_level | Pick next Guild contract after turning in catacombs job | Adventurers' Guild hall, Alderwatch | 66/143 | 26.5 s |
| 126 | I accept the Brambleback Boars contract from the board, then head to the temple to have my shoulder and ribs healed before it closes. | Erzähler | open_run_level | Take boar contract, then get healed | Healer's row | 66/143 | 34.3 s |
| 127 | I pay the two silver for the full healing of my shoulder and ribs. | Engine (Menü/Rückfrage) | open_run_level | Buy full healing before boar hunt | Healer's row | 66/143 | 14.4 s |
| 128 | I pay the 20 copper as offered for the full healing of my shoulder and ribs. | Erzähler | open_run_level | Pay the healer's correct price | Healer's row | 170/143 | 31.0 s |
| 129 | I thank the healer and head east toward the Sunfield Terraces to hunt the four brambleback boars. | Erzähler | open_run_level | Travel to boar hunt grounds for active contract | the Sunfield Terraces vineyards east of Alderwatch | 170/143 | 39.2 s |
| 130 | I thank the worker for the warning and head down toward the lower terrace by the stream to find the boars while there's still light, staff r… | Erzähler | open_run_level | Hunt the four brambleback boars before dark | lower terrace by the stream | 170/143 | 44.1 s |
| 131 | I step back uphill to put the rows and a stone wall between us, then cast Arcane Bolt at the nearest sow. | Engine (Menü/Rückfrage) | open_run_level | Open the boar fight from cover | lower terrace by the stream | 170/143 | 11.2 s |
| 132 | I step back uphill to put the rows and a stone wall between us, then cast Arcane Bolt at Brambleback Boars A. | Erzähler | open_run_level | Open the boar fight from cover using a valid target ID | lower terrace by the stream | 170/143 | 34.5 s |
| 133 | I move down the slope along the dry-stone wall until the nearest boar is at MEDIUM range, then cast Arcane Bolt at Brambleback Boars A. | Erzähler | open_run_level | Close into spell range and open the boar fight | lower terrace by the stream | 170/134 | 37.9 s |
| 134 | I cast Arcane Bolt at Brambleback Boars A. | Erzähler | open_run_level | Finish the wounded boar before the others close | lower terrace by the stream | 170/125 | 42.1 s |
| 135 | I cast Arcane Ward to hold against their next charge, then plan to bolt the pale-tusked boar next turn. | Erzähler | open_run_level | Defend against three boars at SHORT range | lower terrace by the stream | 170/115 | 21.3 s |
| 136 | I cast Arcane Bolt at Brambleback Boars B. | Erzähler | open_run_level | Kill the weakest boar while they are engaged | lower terrace by the stream | 126/106 | 43.6 s |
| 137 | I cast Arcane Bolt at Brambleback Boars B. | Erzähler | open_run_level | Finish the 6 HP boar to cut incoming damage | lower terrace by the stream | 97/97 | 71.8 s |
| 138 | I cast Arcane Bolt at Brambleback Boars C. | Erzähler | open_run_level | Kill boar C with Arcane Bolt before it gores again | lower terrace by the stream | 72/88 | 31.1 s |
| 139 | I cast Arcane Bolt at Brambleback Boars C. | Erzähler | open_run_level | Finish the 19 HP boar to cut incoming damage to one | lower terrace by the stream | 63/79 | 31.4 s |
| 140 | I cast Arcane Bolt at Brambleback Boars D. | Erzähler | open_run_level | Kill the last boar before it gores again | lower terrace by the stream | 54/70 | 32.0 s |
| 141 | I cast Arcane Bolt at Brambleback Boars D. | Erzähler | open_run_level | Finish the wounded boar at 21 HP | lower terrace by the stream | 54/61 | 29.2 s |
| 142 | #assign WIL 3 INT 2 | System (Befehl) | open_run_level | Spend the five free stat points | lower terrace by the stream | 54/61 | 2.9 s |
| 143 | I head to Osser's farmhouse and report the four boars are dead, asking him to confirm the cull for my Guild contract. | Erzähler | open_run_level | Turn in the boar cull with Osser | Osser's farmhouse | 54/61 | 58.4 s |
| 144 | Yes, please bind my wounds with the linen and salve, and shout Osser down from the terraces so he can confirm the cull. | Erzähler | open_run_level | Get wounds bound and Osser's confirmation for the boar contract turn-in | Osser's farmhouse | 54/61 | 55.7 s |
| 145 | I thank Osser, show him the two boar tusks and hide as proof, and ask him to confirm the cull so I can turn in the contract at the Guild hal… | Erzähler | open_run_level | Get Osser's confirmation of the boar cull for the Guild turn-in | Osser's farmhouse | 54/61 | 40.2 s |
| 146 | Thank you, Osser — I'll take the roof and breakfast. I finish the stew and sleep here until morning. | Erzähler | open_run_level | Recover overnight at Osser's before Guild turn-in | Osser's farmhouse | 54/61 | 54.3 s |
| 147 | I take Tam up on the offered free pallet and sleep there until morning. | Erzähler | open_run_level | Recover overnight at Osser's offered hospitality | Osser's farmhouse | 175/308 | 40.8 s |
| 148 | I eat breakfast, thank Osser and Tam, and set out for the Guild hall in Alderwatch to turn in the boar cull contract. | Erzähler | open_run_level | Turn in the completed boar contract at the Guild hall | Adventurers' Guild hall, Alderwatch | 175/308 | 41.3 s |
| 149 | I ask the clerk to show me the novice board, and read what contracts are posted. | Erzähler | open_run_level | Read the Guild board for the next contract | Adventurers' Guild hall, Alderwatch | 175/308 | 66.7 s |
| 150 | I set out for the Millrace Ponds below Lower Weir to hunt the mire adder for my active contract. | Erzähler | open_run_level | Travel to Millrace Ponds for the adder cull | the Millrace Ponds below Lower Weir | 175/308 | 44.3 s |
| 151 | I thank the fisherman for the directions and wade carefully toward the reed bed past the sunken willow in the middle field, watching the wat… | Erzähler | open_run_level | Hunt the mire adder for the active contract | reed bed past the sunken willow | 173/308 | 21.0 s |
| 152 | I cast Arcane Bolt at the mire adder. | Erzähler | open_run_level | Kill the adder for the contract | reed bed past the sunken willow | 173/299 | 64.9 s |
| 153 | I confirm to the fisherman that it was the big one, then head back to the Guild hall in Alderwatch to turn in the adder cull contract. | Erzähler | open_run_level | Turn in the completed adder contract | Adventurers' Guild hall, Alderwatch | 173/299 | 45.9 s |
| 154 | I ask the clerk to show me the novice board for another contract. | Erzähler | open_run_level | Pick the next Guild contract | Adventurers' Guild hall, Alderwatch | 173/299 | 25.7 s |
| 155 | I take the Brambleback Boars contract and ask the clerk to register it as active. | Erzähler | open_run_level | Accept the boar thinning contract | Adventurers' Guild hall, Alderwatch | 173/299 | 47.3 s |
| 156 | I set out east along the road to the Sunfield Terraces to hunt the brambleback boars. | Erzähler | open_run_level | Travel for the boar contract | the Sunfield Terraces vineyards east of Alderwatch | 173/299 | 25.0 s |
| 157 | I'm after all four on the contract. Lead the way to the bramble scrub past the top wall where they're bedding. | Erzähler | open_run_level | Hunt the brambleback boars for the active contract | the bramble fold | 173/299 | 23.9 s |
| 158 | I leave Tam at the wall and creep into the thickest bramble stand toward the flattened bedding patch, staff ready, looking for the boars. | Erzähler | open_run_level | Hunt the boars for the active contract | the bramble fold | 173/299 | 27.2 s |
| 159 | I stay hidden in the bedding hollow, watching the boar tunnel toward the heath for the sounder's return. | Erzähler | open_run_level | Ambush the boars at the bedding patch | the bramble fold | 173/299 | 27.1 s |
| 160 | I hold still in the hollow and wait for the lead boar to step into the bedding patch, then cast Arcane Bolt at the closest one. | Engine (Menü/Rückfrage) | open_run_level | Ambush the returning sounder | the bramble fold | 173/299 | 7.3 s |
| 161 | I hold still in the bedding hollow and wait until a boar steps into the bramble fold, then cast Arcane Bolt at that boar. | Engine (Menü/Rückfrage) | open_run_level | Ambush the returning sounder | the bramble fold | 173/299 | 9.7 s |
| 162 | I climb out of the bedding hollow and head up the boar tunnel toward the rooting sounds; when a boar comes into view, I cast Arcane Bolt at … | Erzähler | open_run_level | Engage the returning sounder for the boar contract | gorse slope above the boar tunnel | 173/299 | 38.2 s |
| 163 | I cast Arcane Bolt at the yearling rooting beside the sow. | Erzähler | open_run_level | Attack a named valid boar to progress the 0/4 contract | gorse slope above the boar tunnel | 173/299 | 23.1 s |
| 164 | I creep up the open slope toward the yearling, staying low in the bent grass, and cast Arcane Bolt at it once I'm within thirty paces. | Engine (Menü/Rückfrage) | open_run_level | Close to MEDIUM range and engage the yearling for the boar contract | gorse slope above the boar tunnel | 173/299 | 7.0 s |
| 165 | I creep up the open slope toward the yearling, staying low in the bent grass, and cast Arcane Bolt at Brambleback Boar M once it's within th… | Erzähler | open_run_level | Close to MEDIUM and attack the named boar | gorse slope above the boar tunnel | 173/299 | 19.5 s |
| 166 | I creep the last paces closer until Brambleback Boar M is within twenty, then cast Arcane Bolt at it. | Erzähler | open_run_level | Close into Arcane Bolt range and attack the named boar | gorse slope above the boar tunnel | 173/290 | 36.9 s |
| 167 | I cast Arcane Bolt at Brambleback Boar M to finish it. | Erzähler | open_run_level | Kill the wounded yearling | gorse slope above the boar tunnel | 173/281 | 21.1 s |
| 168 | I step back to MEDIUM range and cast Arcane Bolt at Brambleback Boar N. | Erzähler | open_run_level | Kite the two boars and kill one with Arcane Bolt | gorse slope above the boar tunnel | 173/272 | 22.3 s |
| 169 | I cast Arcane Bolt at Brambleback Boar N to finish it. | Erzähler | open_run_level | Kill the wounded boar | gorse slope above the boar tunnel | 159/263 | 19.4 s |
| 170 | I step back to MEDIUM range and cast Arcane Bolt at Brambleback Boar L. | Erzähler | open_run_level | Kill the last boar with kiting | gorse slope above the boar tunnel | 144/254 | 20.5 s |
| 171 | I cast Arcane Bolt at Brambleback Boar L to finish it. | Erzähler | open_run_level | Kill the last boar | gorse slope above the boar tunnel | 144/245 | 28.9 s |
| 172 | #assign WIL 3 INT 2 | System (Befehl) | open_run_level | Spend level-up stat points | gorse slope above the boar tunnel | 144/245 | 2.9 s |
| 173 | I search the gorse slope and bramble stands for a fourth Brambleback Boar to finish the contract count. | Erzähler | open_run_level | Complete 4/4 boar contract | gorse slope above the boar tunnel | 144/245 | 21.8 s |
| 174 | The fourth boar is dead at the Sunfield Terraces, hide spoiled but tusks whole—I take its tusks as proof, then walk back down toward Alderwa… | Erzähler | open_run_level | Turn in the 4/4 boar contract at the Guild | Adventurers' Guild hall, Alderwatch | 144/245 | 20.4 s |
| 175 | I ask the clerk whether the contract roll counts a fresh boar kill tomorrow, or if I should look elsewhere for work tonight. | Erzähler | open_run_level | Clarify contract status with the clerk | Adventurers' Guild hall, Alderwatch | 144/245 | 16.3 s |
| 176 | I check the Guild board for the pond and gully contracts. | Erzähler | open_run_level | Pick a new achievable contract | Adventurers' Guild hall, Alderwatch | 144/245 | 18.6 s |
| 177 | I ask the clerk to register me for the Mire Adder cull at the Millrace Ponds, then check the temple's hours for stitching before it closes. | Erzähler | open_run_level | Accept adder contract and get wounds treated | Adventurers' Guild hall, Alderwatch | 144/245 | 25.7 s |
| 178 | I hurry to the healer's hall on Temple Row and ask the brother at the door to stitch my wounds before the ninth bell. | Erzähler | open_run_level | Get wounds treated before temple closes | Healer's hall on Temple Row | 144/245 | 34.9 s |
| 179 | I drop one copper in the offering box quietly, then head out to the Millrace Ponds and ask the eel men at the weir where the adder has been … | Erzähler | open_run_level | Pay and travel to the adder contract | the Millrace Ponds below Lower Weir | 144/245 | 32.6 s |
| 180 | I follow the cattle path along the water to the west bank, staff ready, and scan the reeds where they thin by the cattle's drinking spot for… | Erzähler | open_run_level | Hunt the mire adder at its west bank haunt | the Millrace Ponds below Lower Weir | 144/245 | 38.8 s |
| 181 | I cast Arcane Bolt at the mire adder as it swims toward the bank. | Erzähler | open_run_level | Attack the adder for the cull contract | the Millrace Ponds below Lower Weir | 144/236 | 25.7 s |
| 182 | I tell the older eel man the snake is dead for good, then start back along the cattle path toward the city to turn in the adder cull at the … | Erzähler | open_run_level | Confirm the kill and return for the Guild turn-in | Alderwatch | 144/236 | 26.7 s |
| 183 | I go through the wicket gate to the side door and ask the clerk on duty to take my turn-in for the Mire Adder cull, then the boar cull if th… | Erzähler | open_run_level | Turn in the adder cull at the Guild hall side door | Adventurers' Guild hall, Alderwatch | 144/236 | 31.2 s |
| 184 | I take back the boar slip, thank the clerk, and head to the tavern near the south gate to ask about a room for the night. | Erzähler | open_run_level | Get lodging and sleep to recover | tavern near the south gate | 144/236 | 23.2 s |
| 185 | I take the corner room for two coppers, then go up and sleep until morning. | Erzähler | open_run_level | Buy lodging and sleep to recover | tavern near the south gate | 180/348 | 21.5 s |
| 186 | I head out the south gate east to the Sunfield Terraces and hunt for the fourth brambleback boar. | Erzähler | open_run_level | Finish the boar cull | the Sunfield Terraces vineyards east of Alderwatch | 180/348 | 31.6 s |
| 187 | I follow the turned soil toward the scrub where the two terraces meet, staff ready, and scan for the fourth boar's fresh sign. | Erzähler | open_run_level | Locate the fourth brambleback boar | scrub where the two terraces meet | 180/348 | 27.6 s |
| 188 | I cast Arcane Bolt at the dark rounded shape under the blackthorn to flush or strike the boar. | Engine (Menü/Rückfrage) | open_run_level | Attack the fourth boar | scrub where the two terraces meet | 180/348 | 5.9 s |
| 189 | I step closer to the dark rounded shape under the blackthorn and examine it. | Erzähler | open_run_level | Identify the shape before attacking | scrub where the two terraces meet | 180/348 | 30.8 s |
| 190 | I name Brambleback Boar O as my target and cast Arcane Bolt at it before it fully wakes. | Erzähler | open_run_level | Attack the sleeping fourth boar with a valid target name | scrub where the two terraces meet | 180/339 | 14.0 s |
| 191 | I head back through the south gate to the Valedorn Guild hall and turn in the completed boar cull contract. | Erzähler | open_run_level | Turn in the finished 4/4 boar contract | Adventurers' Guild hall, Alderwatch | 180/339 | 26.0 s |
| 192 | I ask the clerk what contracts are on the board for a Novice mage. | Erzähler | open_run_level | Pick the next Guild contract | Adventurers' Guild hall, Alderwatch | 180/339 | 35.5 s |
| 193 | I accept the Mire Adder cull contract at the Millrace Ponds and ask the clerk to make it active. | Erzähler | open_run_level | Take the adder contract, then sell surplus adder parts | Adventurers' Guild hall, Alderwatch | 180/339 | 22.2 s |
| 194 | I head to the market and offer a merchant my three mire adder skins, fangs and venom sacs, asking what he'll pay for the lot. | Erzähler | open_run_level | Sell surplus adder loot before heading east | market square south of the Guild hall | 180/339 | 34.9 s |
| 195 | I accept your offer and hand over the three adder skins, fangs and venom sacs for three silver and seven copper. | Erzähler | open_run_level | Sell adder loot at the confirmed offer | market square south of the Guild hall | 180/339 | 30.2 s |
| 196 | I take the east road past the vineyard turn to Lower Weir and, once there, ask the eel fishers which pond the big mire adder has been haunti… | Erzähler | open_run_level | Travel to the Millrace Ponds and locate the adder for the active cull contract | the Millrace Ponds below Lower Weir | 180/339 | 36.1 s |
| 197 | I tell the older fisherman I've come about the big mire adder and ask where it's been haunting. | Erzähler | open_run_level | Locate the adder for the active cull | the Millrace Ponds below Lower Weir | 180/339 | 26.2 s |
| 198 | I thank the fisherman and head up the chain of ponds toward the middle pond, watching the reeds for the slick trail and flattened patch he d… | Erzähler | open_run_level | Hunt the big mire adder for the active cull contract | the middle pond | 180/339 | 24.1 s |
| 199 | I search the shed skin and the flattened patch for anything useful, then settle in near the slick with a clear line to the water, waiting qu… | Erzähler | open_run_level | Ambush the mire adder at its basking spot | the middle pond | 180/339 | 35.6 s |
| 200 | I stay still until the adder settles fully, then cast Arcane Bolt at its head. | Erzähler | open_run_level | Ambush the adder with Arcane Bolt | the middle pond | 180/330 | 21.7 s |
| 201 | I head back along the fisherman's track to Lower Weir and go to the Guild hall there to turn in the completed adder cull. | Erzähler | open_run_level | Turn in the READY adder cull contract | Adventurers' Guild hall, Alderwatch | 180/330 | 26.9 s |
| 202 | I check the Guild board for any contracts I can take, then look for a merchant in Alderwatch who'll buy four adder skins, four fangs and fou… | Erzähler | open_run_level | Find new work and sell surplus loot | Wedge and Son, Skins and Parts Bought | 180/330 | 34.8 s |
| 203 | I accept the offer and sell Wedge all four adder skins, four fangs and four venom sacs for two silver, then ask if he wants a brambleback bo… | Engine (Menü/Rückfrage) | open_run_level | Sell surplus loot | Wedge and Son, Skins and Parts Bought | 180/330 | 10.2 s |
| 204 | I sell Wedge four mire adder skins, four fangs and four venom sacs for two silver total, then ask whether he also wants one brambleback boar… | Engine (Menü/Rückfrage) | open_run_level | Sell surplus loot to Wedge | Wedge and Son, Skins and Parts Bought | 180/330 | 13.4 s |
| 205 | SELL to Merchant B at Wedge and Son: 4 mire adder skins, 4 mire adder fangs, 4 mire adder venom sacs, total price 2 silver as offered. After… | Engine (Menü/Rückfrage) | open_run_level | Complete the loot sale with explicit terms | Wedge and Son, Skins and Parts Bought | 180/330 | 9.1 s |
| 206 | I sell to Merchant B: my 4 F-Rank Mire Adder Skins, 4 F-Rank Mire Adder Fangs and 4 F-Rank Mire Adder Venom Sacs, for a total price of 2 sil… | Engine (Menü/Rückfrage) | open_run_level | Complete the loot sale with explicit terms | Wedge and Son, Skins and Parts Bought | 180/330 | 34.6 s |
| 207 | I am selling, not buying: Merchant B buys from me 4 F-Rank Mire Adder Skins, 4 F-Rank Mire Adder Fangs and 4 F-Rank Mire Adder Venom Sacs, a… | Engine (Menü/Rückfrage) | open_run_level | Complete the adder parts sale to Merchant B with explicit sell direction and payment | Wedge and Son, Skins and Parts Bought | 180/330 | 7.8 s |
| 208 | I sell my 4 mire adder skins, 4 mire adder fangs and 4 mire adder venom sacs to Wedge for 2 silver total. | Erzähler | open_run_level | Complete the loot sale using the merchant's name Wedge instead of Merchant B | Wedge and Son, Skins and Parts Bought | 180/330 | 19.6 s |
| 209 | I offer Wedge my brambleback boar hides and tusks and ask what he'll pay for the lot. | Erzähler | open_run_level | Sell remaining boar loot to Wedge | Wedge and Son, Skins and Parts Bought | 180/330 | 33.1 s |
| 210 | I sell Wedge all twelve brambleback boar hides and eighteen tusks for eight silver and eight copper total. | Engine (Menü/Rückfrage) | open_run_level | Accept Wedge's stated offer for the full boar lot | Wedge and Son, Skins and Parts Bought | 180/330 | 12.5 s |
| 211 | I sell to Wedge 12 boar hides and 18 boar tusks for 168 copper total. | Erzähler | open_run_level | Complete the boar loot sale with the phrasing that worked before | Wedge and Son, Skins and Parts Bought | 180/330 | 16.4 s |
| 212 | I head to the Alderwatch Guild hall and look at the contract board for available novice contracts. | Erzähler | open_run_level | Pick up a new Guild contract before dusk | Adventurers' Guild hall, Alderwatch | 180/330 | 21.3 s |
| 213 | I accept the contract 'Cull the Brambleback Boars in the Sunfield Terraces'. | Erzähler | open_run_level | Accept the boar cull contract | Adventurers' Guild hall, Alderwatch | 180/330 | 19.3 s |
| 214 | I travel east to the Sunfield Terraces and hunt brambleback boars on the upper slopes before dark. | Erzähler | open_run_level | Work the active boar cull contract | the Sunfield Terraces vineyards east of Alderwatch | 180/330 | 25.6 s |
| 215 | I cast Arcane Bolt at the brambleback boar rooting on the fourth terrace below me. | Erzähler | open_run_level | Start the boar cull with the easier target | the Sunfield Terraces vineyards east of Alderwatch | 180/321 | 20.5 s |
| 216 | #assign WIL 3 INT 2 | System (Befehl) | open_run_level | Spend the five level-up stat points | the Sunfield Terraces vineyards east of Alderwatch | 180/321 | 3.0 s |
| 217 | I climb the workers' stair to the upper terrace and cast Arcane Bolt at the nearest boar in the sounder. | Erzähler | open_run_level | Continue the boar cull uphill | upper terrace | 180/321 | 24.1 s |
| 218 | I cast Arcane Bolt at the nearest small boar, Brambleback Boar R, before the sounder scatters. | Erzähler | open_run_level | Continue the boar cull on the upper terrace | upper terrace | 161/312 | 39.5 s |
| 219 | I cast Arcane Bolt at the wounded Brambleback Boar R to finish it. | Erzähler | open_run_level | Kill the injured boar before the others charge | upper terrace | 161/303 | 85.6 s |
| 220 | I rest behind the dead boar out of the remaining boars' sight and bandage my thigh, then track the two fleeing boars uphill in the last ligh… | Erzähler | open_run_level | Recover slightly and continue the cull | thorn tangle on the eighth terrace | 161/303 | 34.3 s |
| 221 | I wait for moonrise at the edge of the thorn tangle, keeping downwind of the wallows, then go in after the two boars once I have moonlight t… | Erzähler | open_run_level | Wait for moonrise before pushing into the boars' thorn ground | thorn tangle on the eighth terrace | 161/303 | 40.8 s |
| 222 | I cast Arcane Bolt at the charging big boar, Brambleback Boar S. | Erzähler | open_run_level | Fight the two remaining boars in the thorn hollow | thorn tangle on the eighth terrace | 161/294 | 27.3 s |
| 223 | I cast Arcane Bolt at the wounded Brambleback Boar S to finish it before it charges. | Erzähler | open_run_level | Finish the big boar | thorn tangle on the eighth terrace | 161/285 | 36.6 s |
| 224 | I cast Arcane Bolt at Brambleback Boar Q — the panel still lists it as engaged. | Erzähler | open_run_level | Finish the fourth boar so the cull count reaches 4/4 | thorn tangle on the eighth terrace | 161/276 | 74.7 s |
| 225 | I head back down the dark road to Alderwatch and go to the Guild hall front desk to turn in the boar cull. | Erzähler | open_run_level | Turn in the 4/4 cull contract at the Guild | Adventurers' Guild hall, Alderwatch | 161/276 | 33.8 s |
| 226 | I ask the clerk what Novice contracts are on the board for tomorrow morning. | Erzähler | open_run_level | Pick the next Guild contract | Adventurers' Guild hall, Alderwatch | 161/276 | 26.0 s |
| 227 | I tell the clerk I'll take the Old Crown Catacombs Level 1 contract, and ask her to mark it mine now. | Erzähler | open_run_level | Accept the catacombs clearing contract | Adventurers' Guild hall, Alderwatch | 161/276 | 33.1 s |
| 228 | I ask the clerk if the Guild has rooms or a bed for the night, or where's cheapest to sleep until dawn. | Erzähler | open_run_level | Get lodging and sleep until morning before the catacombs | Adventurers' Guild hall, Alderwatch | 161/276 | 46.0 s |
| 229 | I go to the Wayfarer's Rest on Mill Lane, pay Doss two coppers for the shared loft, and sleep until dawn. | Erzähler | open_run_level | Get lodging and sleep until morning before the catacombs | Wayfarer's Rest | 161/276 | 50.5 s |
| 230 | I climb the ladder to the loft, lie down on the straw pallet, and sleep until dawn. | Erzähler | open_run_level | Actually sleep at the Wayfarer's Rest until morning before heading to the catacombs | Wayfarer's Rest | 161/276 | 46.8 s |
| 231 | I lie back down on the pallet and sleep until morning. | Erzähler | open_run_level | Actually sleep until dawn before the catacombs | Wayfarer's Rest | 185/388 | 25.1 s |
| 232 | I head up the hill past the temple close to the Crown yard and report to the wardens at the catacomb gate about the Level 1 catacombs contra… | Erzähler | open_run_level | Verify quest status and turn in at the catacomb gate | old Crown yard | 185/388 | 58.2 s |
| 233 | I thank the wardens and head to the Guild hall counter, where I tell the clerk plainly: I went down and killed skeletons myself — gravekeepe… | Erzähler | open_run_level | Turn in catacombs contract with kill proof at the Guild counter | Adventurers' Guild hall, Alderwatch | 185/388 | 28.6 s |
| 234 | I accept the refusal, gather my bones, and ask the clerk who buys grave dust and skeleton bones here, or check the board for a fresh Novice … | Erzähler | open_run_level | Sell surplus loot and take a new Guild contract after the catacombs turn-in was refused | Adventurers' Guild hall, Alderwatch | 185/388 | 60.5 s |
| 235 | I take the Mire Adder contract slip from the board and ask the clerk to register it as active, then ask where at Ferren's I can sell my bone… | Erzähler | open_run_level | Take a new achievable Novice contract, then sell surplus loot | Adventurers' Guild hall, Alderwatch | 185/388 | 42.4 s |
| 236 | I go to Ferren's trade door on the alley side and tell Ferren the Guild sent me, offering my six skeleton bones, two pouches of grave dust, … | Erzähler | open_run_level | Sell surplus loot at Ferren's before heading to Lower Weir | Ferren's material broker | 185/388 | 57.4 s |
| 237 | I accept Ferren's offer and sell him all of it — six skeleton bones, two pouches of grave dust, and the gravekeeper's bone — for eight silve… | Engine (Menü/Rückfrage) | open_run_level | Sell surplus loot at Ferren's | Ferren's material broker | 185/388 | 21.6 s |
| 238 | I accept Ferren's bid of 99 copper and sell him all of it. | Erzähler | open_run_level | Accept the correct confirmed price | Ferren's material broker | 185/388 | 24.8 s |
| 239 | I sell Ferren the surplus boar hide, tusk, and the armoured skeleton bone if he wants them, then head downriver toward the Millrace Ponds to… | Erzähler | open_run_level | Sell remaining loot, then travel to the mire adder contract | the Millrace Ponds below Lower Weir | 185/388 | 55.2 s |
| 240 | I walk to the middle pond's basking spot and scan the shallows for the mire adder, staff ready. | Erzähler | open_run_level | Hunt the mire adder at its basking spot | the middle pond | 185/388 | 24.8 s |
| 241 | I wait quietly at the spit's edge, watching the warm shallows for the adder to surface, staff ready. | Erzähler | open_run_level | Hunt the mire adder at its basking spot | the middle pond | 185/388 | 32.0 s |
| 242 | I cast Arcane Bolt at the basking adder before it can lift its head. | Erzähler | open_run_level | Open the fight against the mire adder | the middle pond | 185/379 | 20.6 s |
| 243 | I check the contract slip's seal, then head back upriver toward the Guild hall in town to turn in the completed mire adder cull. | Erzähler | open_run_level | Turn in the completed adder contract at the Guild | Adventurers' Guild hall, Alderwatch | 185/379 | 21.6 s |
| 244 | I ask the clerk what contracts are on the board suitable for a Novice mage. | Erzähler | open_run_level | Pick the next Guild contract | Adventurers' Guild hall, Alderwatch | 185/379 | 21.0 s |
| 245 | I take the Brambleback Boars cull contract from the board and ask the clerk to accept it. | Erzähler | open_run_level | Accept the boar cull contract | Adventurers' Guild hall, Alderwatch | 185/379 | 20.4 s |
| 246 | I take the slip and set out east toward the Sunfield Terraces to hunt the brambleback boars. | Erzähler | open_run_level | Travel to the boar cull grounds | the Sunfield Terraces vineyards east of Alderwatch | 185/379 | 24.3 s |
| 247 | I search the thorn tangle on the eighth terrace where the two fleeing boars went to ground. | Erzähler | open_run_level | Hunt the remaining brambleback boars for the active cull | thorn tangle on the eighth terrace | 185/379 | 33.6 s |
| 248 | I climb through the gap in the dry-stone wall and follow the churned boar tracks up toward the grey boulders on the ridgeline. | Erzähler | open_run_level | Pursue the two boars that fled uphill for the active cull | grey boulders on the ridgeline | 185/379 | 40.0 s |
| 249 | I cast Arcane Bolt at the young boar rooting half in the open. | Erzähler | open_run_level | Open the boar fight with a surprise bolt at the exposed target | grey boulders on the ridgeline | 185/379 | 30.3 s |
| 250 | I move down the open slope toward the boars, closing to Medium range. | Erzähler | open_run_level | Close distance so Arcane Bolt can reach the target | grey boulders on the ridgeline | 185/379 | 35.6 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 12 (notiert vor Zug 13): Prior searches were refused as 'arrival pending'; now confirmed at the third pond.
- zu Zug 21 (notiert vor Zug 22): Combat target refused while boar was only a sign; may need to enter the olive shade scene first.
- zu Zug 24 (notiert vor Zug 25): Critical HP 14/90; another Gore could kill me. Will need recovery after this fight.
- zu Zug 29 (notiert vor Zug 30): Recovery confirmed 110/110 HP; contract at 1/4, reward 90 cp.
- zu Zug 39 (notiert vor Zug 40): Contract at 3/4 boars; narrator mentions a third boar off the wild ridge this month, possibly the fourth.
- zu Zug 51 (notiert vor Zug 52): Boar contract already paid out; mire adder contract still on board despite being trivially easy.
- zu Zug 53 (notiert vor Zug 54): Quest panel shows the adder hunt already 'completed' while the stamped copy is only 'listed'; the parts in my bag may serve as proof for the completed entry.
- zu Zug 55 (notiert vor Zug 56): Adder contract closed for 20 copper despite odd stamp-then-turn-in order; HUD quest still shows active 0/1, minor inconsistency.
- zu Zug 56 (notiert vor Zug 57): Engine said 'arrival pending' for taking the room, so the purchase must be made explicitly at the counter.
- zu Zug 57 (notiert vor Zug 58): Supper bought but pallet purchase not booked; HUD still shows Day 2 evening and HP 32/155, so sleep is not yet confirmed.
- zu Zug 60 (notiert vor Zug 61): Boar contract is logged active but HUD counts 0/4 defeated — the four earlier kills don't count toward the slip. Adder quest still lists active 0/1 despite the 20 cp payout last night.
- zu Zug 63 (notiert vor Zug 64): HUD 'Here' still lists the old bull sighting at Osser's farmyard as a threat while 'Present' says nobody besides me — likely a stale line.
- zu Zug 70 (notiert vor Zug 71): Boar I listed ENGAGED though narrator says it hasn't joined; sow may be Boar I. Taking heavy damage—HP 61/155.
- zu Zug 74 (notiert vor Zug 75): HUD still lists Free Stat Points 5 despite the narrator describing the assign as done — will verify stats after resting.
- zu Zug 75 (notiert vor Zug 76): HUD shows Free Stat Points 5 and pre-assign stats (WIL 24, INT 13, VIT 16) — the #assign may not have registered; will verify after resting.
- zu Zug 76 (notiert vor Zug 77): Resting only partially healed (42/160) and Free Stat Points still 5; will continue resting after assign.
- zu Zug 77 (notiert vor Zug 78): Stat assignment confirmed this time (WIL 26, INT 15, VIT 17, 0 free points).
- zu Zug 81 (notiert vor Zug 82): Engine refused 'eat at his table' as not held, but narration confirmed the meal and coins were taken — treat purchase as done but watch coin count.
- zu Zug 84 (notiert vor Zug 85): Boar contract now 4/4 defeated but still active — needs turn-in at a Guild hall.
- zu Zug 95 (notiert vor Zug 96): System says the active scene has no targetable actor despite the skeleton being described; it may need to act first.
- zu Zug 100 (notiert vor Zug 101): Narrator contradicted my previous action by placing me outside the arch; the HUD now confirms I am at the burial ground above, so I must descend again.
- zu Zug 102 (notiert vor Zug 103): System says no targetable actor in active scene even though narration shows two skeletons ten paces off and closing — possible scene sync issue; trying an unlettered attack.
- zu Zug 103 (notiert vor Zug 104): HUD contradicts System: HUD places me at the burial ground with Restless Skeleton A (dead), while narration has me in the vault with two live skeletons; System says no targetable actor — scene desync.
- zu Zug 104 (notiert vor Zug 105): Third failed attack: System reports no targetable actor while HUD shows a dead skeleton present; possible scene sync issue worth noting.
- zu Zug 105 (notiert vor Zug 106): #map confirms I am still at the burial ground above; the vault skeletons existed only in narration, so the earlier attacks failed for lack of a synced scene.
- zu Zug 106 (notiert vor Zug 107): HUD now confirms I am inside the landing chamber with two passages; the vault skeletons from earlier narration were never a synced scene.
- zu Zug 107 (notiert vor Zug 108): Narrow passage is rune-sealed (go: sealed); a dragging sound approached from behind but HUD shows nobody present — possible sync lag again.
- zu Zug 114 (notiert vor Zug 115): Drag-mark sign points toward the narrow passage with a sawing creak—likely a ghoul nearby.
- zu Zug 127 (notiert vor Zug 128): The System corrected my stated price: full healing is 20 cp, not two silver as the narrator's dialogue implied.
- zu Zug 136 (notiert vor Zug 137): Ward expired at the start of my next turn, and the boars bypassed it through the loose stone. Killing B first drops the per-round damage from three boars to two.
- zu Zug 144 (notiert vor Zug 145): Tam's binding was confirmed only by narration (stew item granted); wounds may or may not be healed mechanically. A bull boar remains on the terraces, uncounted by the 4/4 contract.
- zu Zug 145 (notiert vor Zug 146): Quest shows 4/4 boars defeated; narration offers lodging and turn-in ready at Guild hall.
- zu Zug 146 (notiert vor Zug 147): Engine demanded a priced purchase but narration and Osser confirm the lodging is free hospitality; retrying as acceptance of the offered pallet.
- zu Zug 147 (notiert vor Zug 148): Recovery confirmed: HP/MP fully restored. Contract slip seal shown ready for turn-in.
- zu Zug 161 (notiert vor Zug 162): System refuses Arcane Bolt while the active scene is 'Tam · SHORT'; combat may require leaving that scene or a named target.
- zu Zug 164 (notiert vor Zug 165): System requires the exact scene name; 'the yearling' was refused.
- zu Zug 173 (notiert vor Zug 174): Quest panel still shows 3/4 defeated; the fourth boar died of old wounds, not by my hand—turn-in may be contested.
- zu Zug 174 (notiert vor Zug 175): Turn-in refused: engine counts 3/4, only own-hand kills count; the fourth boar died of old wounds. Guild sells 120 cp skill primers.
- zu Zug 179 (notiert vor Zug 180): Engine refused the offering-box payment (nobody to pay); adder already struck once per HUD lead.
- zu Zug 195 (notiert vor Zug 196): Coin rose to 6g 2s 7c matching the confirmed sale, but the HUD still lists the three adder skins, fangs and sacs as carried — possible inventory lag; check #bag before relying on them. XP 800/900, close to level 10.
- zu Zug 204 (notiert vor Zug 205): System clarify refused the sale twice despite explicit wording; trying a stricter SELL statement.
- zu Zug 205 (notiert vor Zug 206): System refused the sale three times despite explicit wording; merchant stays ENGAGED, maybe a keyword like 'paid to me' is needed.
- zu Zug 206 (notiert vor Zug 207): Sale clarify refused 3 times despite explicit wording; trying one more phrasing emphasizing direction and payment before moving on.
- zu Zug 207 (notiert vor Zug 208): Sale clarify refused 4 times under multiple explicit phrasings; trying the named merchant 'Wedge' as the trading partner before abandoning this sale.
- zu Zug 208 (notiert vor Zug 209): Sale finally succeeded with the short phrasing 'I sell ... to Wedge for 2 silver total' after 4 refusals; engine paid 20 copper while narrator said two silver — trusting the engine coin count.
- zu Zug 223 (notiert vor Zug 224): Narrator said the smaller boar was already dead, but the engine lists Brambleback Boar Q as present and ENGAGED and the quest at 3/4 — trusting the engine over narration.
- zu Zug 228 (notiert vor Zug 229): Quest panel oddly says the catacombs quest is 'cleared by others' while still active — will verify at the gate in the morning.
- zu Zug 229 (notiert vor Zug 230): Narration described paying Doss and sleeping till dawn, but the HUD still shows Day 7, 00:54 (night) with HP/MP unrecovered — the sleep didn't register; retrying now that the HUD confirms I'm at the Rest.
- zu Zug 230 (notiert vor Zug 231): HUD still shows Day 7, 02:54 night with unrecovered HP/MP despite narrated dawn twice — sleep may not be registering mechanically.
- zu Zug 231 (notiert vor Zug 232): Sleep recovery finally registered (HP/MP full). Quest panel still shows 'cleared by others' contradiction to resolve at the gate.
- zu Zug 233 (notiert vor Zug 234): Catacombs Level 1 contract permanently dead — cleared and paid to Ironbark crew; quest panel still lists it active, a contradiction to ignore.
- zu Zug 237 (notiert vor Zug 238): System flagged a price mismatch between my words and Ferren's actual bid — my narration misread his offer.
- zu Zug 239 (notiert vor Zug 240): Ferren's standing offer of 7 silver 6 cp for hide/tusk/bone lapsed when I left; may re-offer tomorrow. Coin and sale confirmed at 99 cp.
- zu Zug 246 (notiert vor Zug 247): Contract acceptance was refused as already active — boar cull was active all along; slip likely not reissued. Currently 0/4 boars recorded.
- zu Zug 247 (notiert vor Zug 248): HUD still records 0/4 boars defeated despite narration of a dead sow and a bolt-killed boar below; trusting the HUD count.
- zu Zug 248 (notiert vor Zug 249): Engine spawned two fresh full-HP boars (T, U) at the ridgeline, consistent with the HUD's 0/4 cull count despite narrated earlier kills.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t16 | 16 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t22 | 23 | 1 | – | nein | 1 | gewonnen, 190 XP |
| enc.t30 | 32 | 1 | – | nein | 1 | gewonnen, 190 XP |
| enc.t34 | 37 | 1 | – | nein | 1 | gewonnen, 152 XP |
| enc.t39 | 43 | 1 | – | nein | 1 | gewonnen, 190 XP |
| enc.t59 | 65 | 1 | – | nein | 1 | gewonnen, 128 XP |
| enc.t63 | 69 | 2 | – | nein | 2 | gewonnen, 304 XP |
| enc.t75 | 83 | 1 | – | nein | 1 | gewonnen, 154 XP |
| enc.t86 | 97 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t93 | 109 | 3 | – | nein | 3 | gewonnen, 240 XP |
| enc.t100 | 118 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t103 | 121 | 1 | – | nein | 1 | gewonnen, 252 XP |
| enc.t113 | 133 | 4 | – | nein | 4 | gewonnen, 474 XP |
| enc.t130r | 151 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t142 | 166 | 3 | – | nein | 3 | gewonnen, 428 XP |
| enc.t156 | 181 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t164 | 190 | 1 | – | nein | 1 | gewonnen, 180 XP |
| enc.t174 | 200 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t183 | 215 | 1 | – | nein | 1 | gewonnen, 124 XP |
| enc.t185 | 218 | 1 | – | nein | 1 | gewonnen, 180 XP |
| enc.t189 | 222 | 1 | – | nein | 1 | gewonnen, 102 XP |
| enc.t191 | 224 | 1 | – | nein | 1 | gewonnen, 124 XP |
| enc.t208 | 242 | 1 | – | nein | 1 | gewonnen, 24 XP |

## Quests

- **Hunt the Mire Adder at the Millrace Ponds** — active (Zug 8) → completed (Zug 17)
  - Aufgabe: Kill 1 mire adder at the Millrace Ponds below Lower Weir. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 mire adder killed at the Millrace Ponds below Lower Weir.
- **Thin the Brambleback Boars Rooting the Vineyard Rows** — active (Zug 19) → completed (Zug 49)
  - Aufgabe: Kill 4 brambleback boars at the Sunfield Terraces vineyards east of Alderwatch. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 brambleback boars killed at the Sunfield Terraces vineyards east of Alderwatch.
- **Hunt the Pale Stag of the Hollowfen** — expired (Zug 51)
  - Aufgabe: Kill 1 the Pale Stag at the deep Hollowfen, south of the Alderwatch road. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the Pale Stag killed at the deep Hollowfen, south of the Alderwatch road.
- **Cull the Ashwyrm Brood in the Cinder Gully** — expired (Zug 51)
  - Aufgabe: Kill 3 ashwyrms at the Cinder Gully kilns, a half-day north of Alderwatch. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 ashwyrms killed at the Cinder Gully kilns, a half-day north of Alderwatch.
- **Clear the Old Crown Catacombs, Level 1** — expired (Zug 51), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of Old Crown Catacombs. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Old Crown Catacombs is clear.
- **Cull the Mire Adder at the Millrace Ponds** — active (Zug 55) → completed (Zug 153)
  - Aufgabe: Kill 1 mire adder at the Millrace Ponds below Lower Weir. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 mire adder killed at the Millrace Ponds below Lower Weir.
- **Cull Brambleback Boars in the Sunfield Terraces** — expired (Zug 59)
  - Aufgabe: Kill 4 brambleback boars at the Sunfield Terraces vineyards east of Alderwatch. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 brambleback boars killed at the Sunfield Terraces vineyards east of Alderwatch.
- **Hunt the Pale Stag of the Hollowfen** — expired (Zug 59)
  - Aufgabe: Kill 1 the Pale Stag at the deep Hollowfen, south of the Alderwatch road. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the Pale Stag killed at the deep Hollowfen, south of the Alderwatch road.
- **Cull Ashwyrms at the Cinder Gully Kilns** — expired (Zug 59)
  - Aufgabe: Kill 6 ashwyrms at the Cinder Gully kilns, a half-day north of Alderwatch. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 6 ashwyrms killed at the Cinder Gully kilns, a half-day north of Alderwatch.
- **Clear Old Crown Catacombs Level 1** — expired (Zug 59), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of Old Crown Catacombs. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Old Crown Catacombs is clear.
- **Cull the Mire Adder at the Millrace Ponds** — expired (Zug 88)
  - Aufgabe: Kill 1 mire adder at the Millrace Ponds below Lower Weir. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 mire adder killed at the Millrace Ponds below Lower Weir.
- **Thin the Brambleback Boars of Sunfield Terraces** — active (Zug 60) → completed (Zug 87)
  - Aufgabe: Kill 4 brambleback boars at the Sunfield Terraces vineyards east of Alderwatch. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 brambleback boars killed at the Sunfield Terraces vineyards east of Alderwatch.
- **The Pale Stag of Hollowfen** — expired (Zug 88)
  - Aufgabe: Kill 1 the Pale Stag at the deep Hollowfen, south of the Alderwatch road. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the Pale Stag killed at the deep Hollowfen, south of the Alderwatch road.
- **Burn Out the Ashwyrms of Cinder Gully** — expired (Zug 88)
  - Aufgabe: Kill 3 ashwyrms at the Cinder Gully kilns, a half-day north of Alderwatch. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 ashwyrms killed at the Cinder Gully kilns, a half-day north of Alderwatch.
- **Clear Old Crown Catacombs, Level 1** — expired (Zug 88), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of Old Crown Catacombs. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Old Crown Catacombs is clear.
- **Cull the Mire Adder at the Millrace Ponds** — expired (Zug 149)
  - Aufgabe: Kill 1 mire adder at the Millrace Ponds below Lower Weir. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 mire adder killed at the Millrace Ponds below Lower Weir.
- **Thin the Brambleback Boars of Sunfield Terraces** — active (Zug 126) → completed (Zug 148)
  - Aufgabe: Kill 4 brambleback boars at the Sunfield Terraces vineyards east of Alderwatch. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 brambleback boars killed at the Sunfield Terraces vineyards east of Alderwatch.
- **End the Pale Stag of the Hollowfen** — expired (Zug 149)
  - Aufgabe: Kill 1 the Pale Stag at the deep Hollowfen, south of the Alderwatch road. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the Pale Stag killed at the deep Hollowfen, south of the Alderwatch road.
- **Burn Out the Ashwyrms of Cinder Gully** — expired (Zug 149)
  - Aufgabe: Kill 3 ashwyrms at the Cinder Gully kilns, a half-day north of Alderwatch. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 ashwyrms killed at the Cinder Gully kilns, a half-day north of Alderwatch.
- **Clear the Old Crown Catacombs, Level 1** — active (Zug 90) → completed (Zug 124), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of Old Crown Catacombs. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Old Crown Catacombs is clear.
- **Cull the Mire Adder at the Millrace Ponds** — active (Zug 177) → completed (Zug 183)
  - Aufgabe: Kill 1 mire adder at the Millrace Ponds below Lower Weir. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 mire adder killed at the Millrace Ponds below Lower Weir.
- **Thin the Brambleback Boars of Sunfield Terraces** — active (Zug 155) → completed (Zug 191)
  - Aufgabe: Kill 4 brambleback boars at the Sunfield Terraces vineyards east of Alderwatch. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 brambleback boars killed at the Sunfield Terraces vineyards east of Alderwatch.
- **Hunt the Pale Stag of the Deep Hollowfen** — expired (Zug 192)
  - Aufgabe: Kill 1 the Pale Stag at the deep Hollowfen, south of the Alderwatch road. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the Pale Stag killed at the deep Hollowfen, south of the Alderwatch road.
- **Cull the Ashwyrms of Cinder Gully** — expired (Zug 192)
  - Aufgabe: Kill 3 ashwyrms at the Cinder Gully kilns, a half-day north of Alderwatch. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 ashwyrms killed at the Cinder Gully kilns, a half-day north of Alderwatch.
- **Clear the Old Crown Catacombs, Level 1** — expired (Zug 192), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of Old Crown Catacombs. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Old Crown Catacombs is clear.
- **Cull the Mire Adder at the Millrace Ponds** — active (Zug 193) → completed (Zug 201)
  - Aufgabe: Kill 1 mire adder at the Millrace Ponds below Lower Weir. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 mire adder killed at the Millrace Ponds below Lower Weir.
- **Cull the Brambleback Boars in the Sunfield Terraces** — active (Zug 213) → completed (Zug 225)
  - Aufgabe: Kill 4 brambleback boars at the Sunfield Terraces vineyards east of Alderwatch. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 brambleback boars killed at the Sunfield Terraces vineyards east of Alderwatch.
- **The Pale Stag of the Deep Hollowfen** — expired (Zug 234)
  - Aufgabe: Kill 1 the Pale Stag at the deep Hollowfen, south of the Alderwatch road. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the Pale Stag killed at the deep Hollowfen, south of the Alderwatch road.
- **Cull the Ashwyrms at the Cinder Gully Kilns** — expired (Zug 234)
  - Aufgabe: Kill 6 ashwyrms at the Cinder Gully kilns, a half-day north of Alderwatch. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 6 ashwyrms killed at the Cinder Gully kilns, a half-day north of Alderwatch.
- **Clear Old Crown Catacombs, Level 1** — active (Zug 227), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of Old Crown Catacombs. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Old Crown Catacombs is clear.
- **Cull the Mire Adder at the Millrace Ponds** — active (Zug 235) → completed (Zug 243)
  - Aufgabe: Kill 1 mire adder at the Millrace Ponds below Lower Weir. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 mire adder killed at the Millrace Ponds below Lower Weir.
- **Cull Brambleback Boars in the Sunfield Terraces** — active (Zug 245)
  - Aufgabe: Kill 4 brambleback boars at the Sunfield Terraces vineyards east of Alderwatch. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 brambleback boars killed at the Sunfield Terraces vineyards east of Alderwatch.

## Auffälligkeiten

- Zug 22, Nachricht 44 (extraction_repaired): the extractor's first answer needed a repair
- Zug 30, Nachricht 60 (extraction_repaired): the extractor's first answer needed a repair
- Zug 36, Nachricht 71 (planner_repaired): the planner's first answer needed a repair
- Zug 41, Nachricht 81 (planner_repaired): the planner's first answer needed a repair
- Zug 42, Nachricht 84 (extraction_repaired): the extractor's first answer needed a repair
- Zug 48, Nachricht 96 (extraction_repaired): the extractor's first answer needed a repair
- Zug 57, Nachricht 113 (planner_repaired): the planner's first answer needed a repair
- Zug 74, Nachricht 147 (stat_words): the player spent Stat Points in words, not with #assign; nothing was assigned (for review: did the story tell them as done?)
- Zug 75, Nachricht 149 (planner_repaired): the planner's first answer needed a repair
- Zug 81, Nachricht 161 (planner_repaired): the planner's first answer needed a repair
- Zug 107, Nachricht 214 (extraction_repaired): the extractor's first answer needed a repair
- Zug 108, Nachricht 216 (extraction_repaired): the extractor's first answer needed a repair
- Zug 124, Nachricht 248 (extraction_repaired): the extractor's first answer needed a repair
- Zug 127, Nachricht 253 (planner_repaired): the planner's first answer needed a repair
- Zug 128, Nachricht 256 (extraction_repaired): the extractor's first answer needed a repair
- Zug 136, Nachricht 272 (extraction_repaired): the extractor's first answer needed a repair
- Zug 148, Nachricht 295 (planner_repaired): the planner's first answer needed a repair
- Zug 153, Nachricht 306 (extraction_repaired): the extractor's first answer needed a repair
- Zug 161, Nachricht 321 (planner_repaired): the planner's first answer needed a repair
- Zug 180, Nachricht 360 (extraction_repaired): the extractor's first answer needed a repair
- Zug 182, Nachricht 364 (extraction_repaired): the extractor's first answer needed a repair
- Zug 189, Nachricht 378 (extraction_repaired): the extractor's first answer needed a repair
- Zug 195, Nachricht 389 (planner_repaired): the planner's first answer needed a repair
- Zug 203, Nachricht 405 (planner_repaired): the planner's first answer needed a repair
- Zug 204, Nachricht 407 (planner_repaired): the planner's first answer needed a repair
- Zug 205, Nachricht 409 (planner_repaired): the planner's first answer needed a repair
- Zug 206, Nachricht 411 (planner_repaired): the planner's first answer needed a repair
- Zug 206, Nachricht 411 (finish): plan_repair ended with finish_reason "length"
- Zug 207, Nachricht 413 (planner_repaired): the planner's first answer needed a repair
- Zug 208, Nachricht 415 (planner_repaired): the planner's first answer needed a repair
- Zug 210, Nachricht 419 (planner_repaired): the planner's first answer needed a repair
- Zug 211, Nachricht 421 (planner_repaired): the planner's first answer needed a repair
- Zug 219, Nachricht 438 (extraction_repaired): the extractor's first answer needed a repair
- Zug 219, Nachricht 438 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 219, Nachricht 438 (finish): extract ended with finish_reason "length"
- Zug 221, Nachricht 442 (extraction_repaired): the extractor's first answer needed a repair
- Zug 237, Nachricht 473 (planner_repaired): the planner's first answer needed a repair
- Zug 239, Nachricht 478 (extraction_repaired): the extractor's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 31× keine gültige JSON-Entscheidung (Züge 5, 10, 12, 15, 16, 17, 21, 42, 54, 74, 75, 92, 93, 94, 99, 104, 118, 124, 157, 158, 159, 161, 162, 166, 172, 174, 189, 198, 216, 217, 222)
- 2 Aufruf(e) mit finish_reason "length" (Nr. 576 plan, Nr. 612 extract)

System-Panels: CLARIFY 11, NOT TAKEN 2, REFUSED 2, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: no_go 2, guild_canon 4, scene_context 33, engine_owned_fact 27, world_rule 48, quest_count 4, engine_owned_combat 5, offer 4, time_cap 3, group_unclear 4, recover 2, passage 4, attack_commitment 5, ambient 6, sale_evidence 3, engine_owned_memory 1, quest_dependency 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 1, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 31/250 Erstantworten ungültig (12.4 %); 31 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 255 | 18 | 3.1 s | 8.3 s | 12742 | 9931 | 81 | – | stop 254, length 1 | 1 |
| narrator | 214 | 0 | 11.0 s | 20.8 s | 11773 | 8846 | 399 | – | stop 214 | 0 |
| extract | 230 | 15 | 7.3 s | 15.9 s | 13087 | 9351 | 352 | – | stop 229, length 1 | 1 |
| board | 8 | 1 | 12.2 s | 19.8 s | 2466 | 2157 | 1026 | – | stop 8 | 0 |
| forge | 1 | 0 | 7.8 s | 7.8 s | 367 | 0 | 68 | – | stop 1 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 141:55 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 69.6 s) | 1:27 min |
| 250 Züge, Spiel (Senden bis HUD nach der Extraktion) | 116:32 min — Median 25.7 s, p90 47.3 s, max 107.8 s |
| 250 Züge, Spieler-Entscheidung | 17:26 min — Median 2.9 s, 31 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 19:00 min / 1:45 min / 48:49 min / 34:56 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 32.2 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 21:26 min, 80 Züge ≈ 42:52 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spieler | 230 | – | 38.6 s | 2.9 s |
| Spiel | 56 | – | 107.8 s | 25.7 s |
| Spiel | 9 | – | 107.7 s | 25.7 s |
| Spiel | 219 | – | 85.6 s | 25.7 s |
| Provider narrator | 56 | 154 | 88.7 s | 11.0 s |
| Provider narrator | 152 | 421 | 47.4 s | 11.0 s |
| Provider narrator | 143 | 392 | 43.4 s | 11.0 s |
| Provider extract | 9 | 23 | 95.0 s | 7.3 s |
| Provider extract | 219 | 612 | 63.7 s | 7.3 s |
| Provider extract | 155 | 432 | 33.2 s | 7.3 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
