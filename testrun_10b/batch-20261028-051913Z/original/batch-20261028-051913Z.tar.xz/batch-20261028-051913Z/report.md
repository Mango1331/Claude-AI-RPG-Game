# Avereth – 3 natürliche Testkampagnen

Status: **interrupted**. Serie abgeschlossen bedeutet, dass die Läufe beendet sind; es bedeutet nicht 3 bestandene Level-15-Abnahmen.

| Nr. | Profil | Seed | Eingaben | Level | Ende | Originalbericht |
|---|---|---:|---:|---:|---|---|
| 1 | guild-warrior | 1098264377 | 250 | 7 | limit | [report.md](001-guild-warrior/20261028-051914Z-current_test/report.md) |
| 2 | guild-mage | 1098264378 | 250 | 10 | limit | [report.md](002-guild-mage/20261028-070932Z-current_test/report.md) |
| 3 | guild-rogue | 1098264379 | 0 | – | process_error | [report.md](003-guild-rogue/20261028-093139Z-current_test/report.md) |

