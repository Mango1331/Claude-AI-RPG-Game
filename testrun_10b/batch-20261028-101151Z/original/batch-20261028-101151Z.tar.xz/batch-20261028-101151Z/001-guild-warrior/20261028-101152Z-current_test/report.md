# Avereth Live-Test 20261028-101152Z-current_test

## Kurzfassung

- **Laufprofil:** guild-warrior; Startklasse Warrior, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** abgebrochen: Fehler im Runner — interrupted (Ctrl+C) in turn 15
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 1. Sicherheitsgrenzen: 150 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** noch nicht erreicht.
- **Charakter:** warrior (warrior.heavy_slash, warrior.guard) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: curious adventurer: follow interesting opportunities without forcing dangerous encounters
- **Züge:** 15 · **Dauer:** 8:24 min · **LLM-Aufrufe der Engine/des Erzählers:** 35
- **Beobachtete Abdeckung:** 1 unterschiedliche gebuchte Reiseziele · 0 Kämpfe · 0 Verkäufe (0 cp Umsatz, ohne Questzahlungen/Geschenke) · 0 Ausrüstungswechsel · 0 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 1
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.110 |
| Git | da933e9371d0 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 10.1 s |
| Browser | chrome 156.0.8078.48 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261028-101152Z-current_test“, Seed 579890790 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | I choose Warrior. | Engine (Menü/Rückfrage) | creation_complete | Pick Warrior base class | public roadside verge outside Glassmere | 90/84 | 2.1 s |
| 2 | I select Heavy Slash and Guard. | Engine (Menü/Rückfrage) | creation_complete | Finish character creation with two Warrior starter skills | public roadside verge outside Glassmere | 95/84 | 2.1 s |
| 3 | I walk along the road toward the city gates of Glassmere, looking for the Adventurers' Guild. | Erzähler | open_run_level | Enter Glassmere and find the Guild to take contracts | Glassmere | 95/84 | 36.1 s |
| 4 | I approach the front counter and ask the clerk how I can register with the Guild. | Erzähler | open_run_level | Register at the Adventurers' Guild | Glassmere | 95/84 | 26.4 s |
| 5 | Yes, I agree to the two silver fee — register me under the name Alaric. | Erzähler | open_run_level | Register with the Guild | Glassmere | 95/84 | 32.7 s |
| 6 | Warrior. | Erzähler | creation_complete | Answer the forced creation menu with Warrior | Glassmere | 95/84 | 46.6 s |
| 7 | Cleave and Bull's Stamina. | Erzähler | creation_complete | Finish creation step 2 with two Warrior skills | Glassmere | 95/84 | 25.9 s |
| 8 | I select Cleave and Bull's Stamina from the Warrior skill pool. | Erzähler | creation_complete | Complete creation step 2 skill selection in a fresh phrasing | Glassmere | 95/84 | 18.8 s |
| 9 | I put my hand flat on the measuring stone as the clerk instructed. | Erzähler | creation_complete | Complete registration by touching the measuring stone | Glassmere | 95/84 | 24.8 s |
| 10 | "I'm a Warrior." | Erzähler | open_run_level | Complete registration by stating my class to the clerk | Glassmere | 95/84 | 37.0 s |
| 11 | I hand the clerk two silver. | Erzähler | open_run_level | Pay registration fee and get the contract slip | Glassmere | 95/84 | 53.0 s |
| 12 | I walk to the notice board by the hearth and read the curled paper pinned there. | Erzähler | open_run_level | Read the Guild board for a first contract | Glassmere | 95/84 | 23.3 s |
| 13 | #audit | System (Befehl) | open_run_level | Check why the engine says I'm not at a Guild hall | Glassmere | 95/84 | 2.1 s |
| 14 | I return to the counter and hand the clerk two silver to finish my registration. | Erzähler | open_run_level | Complete Guild registration by paying the fee | Glassmere | 95/84 | 30.6 s |
| 15 | I take the registration slip from the counter and thank the clerk. | – | open_run_level | Collect registration slip | Glassmere | 95/84 | 16.4 s **interrupted** |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 4 (notiert vor Zug 5): Narrator shows a clerk at the counter, but the engine refused register with 'not at a Guild hall'; retrying the registration explicitly here.
- zu Zug 5 (notiert vor Zug 6): HUD already shows L1 Warrior with skills, yet engine reopened creation step 1/2; answering the menu to resolve the contradiction.
- zu Zug 6 (notiert vor Zug 7): HUD already shows Heavy Slash and Guard, but the creation menu offers a different skill pool; answering the menu to resolve it.
- zu Zug 7 (notiert vor Zug 8): HUD already lists Heavy Slash and Guard as my skills, conflicting with the creation menu's skill pool; engine rejects skill picks as 'development.accept: no offer'.
- zu Zug 8 (notiert vor Zug 9): Skill selection prompt rejects all phrasings with development.accept: no offer, yet HUD already shows Heavy Slash and Guard as skills; proceeding with the clerk's stone reading instead.
- zu Zug 9 (notiert vor Zug 10): Skill selection prompt still rejects all choices ('development.accept: no offer'), yet HUD already shows Heavy Slash and Guard as skills; proceeding with registration and will address the prompt separately.
- zu Zug 10 (notiert vor Zug 11): Skill selection prompt still unresolved (development.accept: no offer) despite HUD already showing Heavy Slash and Guard; registration now nearly complete.
- zu Zug 11 (notiert vor Zug 12): HUD still shows Guild Rank — (not registered) and 5 Silver despite the clerk taking two silver and handing over a slip; the guild.register action refused as 'not at a Guild hall' though narration placed me at the counter. Registration state contradicts narration.
- zu Zug 12 (notiert vor Zug 13): Narrator confirms payment and slip, but engine refuses guild.register ('not at a Guild hall') and board.read ('no Guild board here'); HUD still shows not registered with 5 Silver.
- zu Zug 13 (notiert vor Zug 14): Engine audit rejects the narrator's claim of payment and registration; engine still demands two silver at the counter despite the same payment already narrated.
- zu Zug 14 (notiert vor Zug 15): Engine still charged 2 silver (COIN 50→30 copper) but HUD shows 3 Silver and Guild Rank 'not registered' — registration may not be engine-confirmed; slip is narrated only.

## Kämpfe

Kein Kampf.

## Quests

Keine angenommen.


## Auffälligkeiten

- Zug 15 (Runner/UI): interrupted
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Server: Generation failed AbortError: The operation was aborted.

System-Panels: CLARIFY 0, NOT TAKEN 0, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: scene_context 17, pc_inventory 1, engine_owned_fact 2, guild_canon 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 1/15 Erstantworten ungültig (6.7 %); 1 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 12 | 0 | 2.2 s | 3.1 s | 10607 | 9722 | 76 | – | stop 12 | 0 |
| narrator | 12 | 0 | 16.3 s | 26.1 s | 11134 | 0 | 529 | – | stop 11 | 0 |
| extract | 11 | 0 | 7.6 s | 15.9 s | 10484 | 9141 | 355 | – | stop 11 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 8:24 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 10.1 s) | 0:24 min |
| 15 Züge, Spiel (Senden bis HUD nach der Extraktion) | 6:18 min — Median 25.9 s, p90 46.6 s, max 53.0 s |
| 15 Züge, Spieler-Entscheidung | 1:32 min — Median 5.1 s, 1 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 0:28 min / 0:00 min / 3:23 min / 1:44 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 31.3 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 20:52 min, 80 Züge ≈ 41:43 min (ohne Einrichtung) |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
