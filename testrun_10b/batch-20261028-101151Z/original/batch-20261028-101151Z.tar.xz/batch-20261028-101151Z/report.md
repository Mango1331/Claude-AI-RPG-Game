# Avereth – 3 natürliche Testkampagnen

Status: **interrupted**. Serie abgeschlossen bedeutet, dass die Läufe beendet sind; es bedeutet nicht 3 bestandene Level-15-Abnahmen.

| Nr. | Profil | Seed | Eingaben | Level | Ende | Originalbericht |
|---|---|---:|---:|---:|---|---|
| 1 | guild-warrior | 579890790 | 15 | 1 | process_error | [report.md](001-guild-warrior/20261028-101152Z-current_test/report.md) |
| 2 | guild-mage | 579890791 | – | – | pending | – |
| 3 | guild-rogue | 579890792 | – | – | pending | – |

