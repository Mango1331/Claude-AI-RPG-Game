# Avereth Live-Test 20261028-111133Z-current_test

## Kurzfassung

- **Laufprofil:** guild-warrior; Startklasse Warrior, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** Niederlage — turn 80: he died
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 6. Sicherheitsgrenzen: 150 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** noch nicht erreicht.
- **Charakter:** warrior (warrior.heavy_slash, warrior.guard) · Regelstand 2 (Warrior, Mage, Rogue)
- **Ziel-Dungeon:** Mossback Warrens, Ebene 1 (Vertrag quest.clear_mossback_warrens_level_1_2)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: pragmatic adventurer: sell surplus loot and invest in useful equipment and techniques
- **Züge:** 80 · **Dauer:** 34:44 min · **LLM-Aufrufe der Engine/des Erzählers:** 234
- **Beobachtete Abdeckung:** 16 unterschiedliche gebuchte Reiseziele · 10 Kämpfe · 2 Verkäufe (67 cp Umsatz, ohne Questzahlungen/Geschenke) · 0 Ausrüstungswechsel · 0 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 15 · **Niederlage** in Zug 80: he died
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.112 |
| Git | d9c259f98f2d (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 66.1 s |
| Browser | chrome 156.0.8078.48 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261028-111133Z-current_test“, Seed 1846470028 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | Warrior. | Engine (Menü/Rückfrage) | creation_complete | Choose Warrior as base class | public roadside verge outside Ashbridge | 90/84 | 2.2 s |
| 2 | I choose Heavy Slash and Guard. | Engine (Menü/Rückfrage) | creation_complete | Select two starter skills | public roadside verge outside Ashbridge | 95/84 | 2.1 s |
| 3 | I walk into Ashbridge and head for the Guild hall to look at the contract board. | Erzähler | open_run_level | Find a starter Guild contract | Adventurers' Guild hall, Ashbridge | 95/84 | 33.6 s |
| 4 | I tell the clerk I'd like to register with the Guild and take the 'Thin the Quarry Track Wolves' contract. | Erzähler | open_run_level | Register and accept the wolf contract | Adventurers' Guild hall, Ashbridge | 95/84 | 33.5 s |
| 5 | I pay the two silver registration fee and sign the roll. | Erzähler | open_run_level | Register with the Guild | Adventurers' Guild hall, Ashbridge | 95/84 | 17.1 s |
| 6 | I sign the back of the wolf contract slip. | Erzähler | open_run_level | Accept the wolf culling contract | Adventurers' Guild hall, Ashbridge | 95/84 | 15.0 s |
| 7 | I head out the east gate, follow the cart ruts past the tanneries onto the quarry track, and look for the wolves. | Erzähler | open_run_level | Travel to the quarry track for the wolf culling | the old quarry track east of Ashbridge | 95/84 | 28.5 s |
| 8 | I draw my sword and approach the shed door cautiously, ready for whatever is inside. | Erzähler | open_run_level | Investigate the shed threat | inside the trackside shed | 95/84 | 20.3 s |
| 9 | I meet its leap with Heavy Slash aimed at its head as it crosses the floor. | Erzähler | open_run_level | Fight the wolf with Heavy Slash | inside the trackside shed | 75/84 | 14.3 s |
| 10 | I finish it with Heavy Slash to the head. | Erzähler | open_run_level | Kill the wolf | inside the trackside shed | 75/84 | 18.2 s |
| 11 | I search the quarryman's body and the shed for anything useful, then check the churned prints outside to pick up the other wolves' trail. | Erzähler | open_run_level | Loot the shed and track remaining wolves | the quarry floor | 75/84 | 41.5 s |
| 12 | I spend my stat points, then ready my sword and shield my line against the big wolf as it closes. | Erzähler | open_run_level | Assign stats and fight the pack | the quarry floor | 62/84 | 16.7 s |
| 13 | I answer its lunge with Heavy Slash to the head. | Erzähler | open_run_level | Damage the pack leader | the quarry floor | 49/84 | 19.9 s |
| 14 | I finish the big wolf with another Heavy Slash to the head before it can reset. | Erzähler | open_run_level | Kill pack leader | the quarry floor | 49/84 | 13.2 s |
| 15 | I skin nothing I can't carry and instead head up the far ramp after the two lean wolves, following their trail over the spoil heap. | Erzähler | open_run_level | Hunt the remaining two wolves for the contract | the wolves' den fold | 49/84 | 19.6 s |
| 16 | I approach the den mouth cautiously, shield up, and try to flush the two wolves out rather than crawl in after them. | Erzähler | open_run_level | Hunt the last two wolves at the den | the wolves' den fold | 49/84 | 28.3 s |
| 17 | I plant my feet behind the shield, raise Guard, and brace to meet the first wolf's charge head-on. | Erzähler | open_run_level | Weather the two-wolf charge defensively before counterattacking | the wolves' den fold | 49/84 | 15.0 s |
| 18 | I take the first wolf's impact on the shield and counter with Heavy Slash at the second wolf curving in from my right. | Erzähler | open_run_level | Defend against the charge and damage the flanking wolf | the wolves' den fold | 49/84 | 20.3 s |
| 19 | I square to the nearer circling wolf and step toward it, keeping my back to the slab, and swing Heavy Slash at Grey Wolf E as it comes into … | Erzähler | open_run_level | Close with and damage one wolf | the wolves' den fold | 30/84 | 19.1 s |
| 20 | I finish Grey Wolf E with a Heavy Slash before it can wrench free. | Erzähler | open_run_level | Kill the wounded wolf | the wolves' den fold | 30/84 | 40.1 s |
| 21 | #assign VIT 3 STR 2 | System (Befehl) | open_run_level | Spend level-up stat points | the wolves' den fold | 30/84 | 2.1 s |
| 22 | I follow the fleeing wolf's tracks toward the trees, shield up, watching for the last wolf I need. | Erzähler | open_run_level | Hunt the fourth wolf to finish the contract | the wood's edge under the trees | 30/84 | 24.8 s |
| 23 | I keep my shield high and advance the last twenty paces, then swing Heavy Slash at Grey Wolf G the moment she lunges or comes into reach. | Erzähler | open_run_level | Finish the fourth wolf for the contract | the wood's edge under the trees | 30/84 | 23.5 s |
| 24 | I start the long walk back toward the Guild branch at Ashbridge, keeping to the road and my shield up. | Erzähler | open_run_level | Return for the contract turn-in and recover | Adventurers' Guild hall, Ashbridge | 30/84 | 41.2 s |
| 25 | I hand the clerk the contract slip and report all four quarry track wolves defeated, and ask to collect the ninety copper reward. | Erzähler | open_run_level | Turn in the completed wolf contract | Adventurers' Guild hall, Ashbridge | 30/84 | 15.7 s |
| 26 | I ask the clerk to read me what's on the contract board. | Erzähler | open_run_level | Pick a new achievable contract | Adventurers' Guild hall, Ashbridge | 30/84 | 14.0 s |
| 27 | I accept the Millrace Serpent contract from the board, then ask where I can find Marta's house and a bed for the night. | Erzähler | open_run_level | Take the achievable serpent contract and recover overnight | Adventurers' Guild hall, Ashbridge | 30/84 | 21.7 s |
| 28 | I walk to Marta's house on Rope Street and knock, asking her to stitch my leg wound. | Erzähler | open_run_level | Get healing, then rest | Marta's house | 30/84 | 20.3 s |
| 29 | I pay Marta the four coppers for the stitching. | Erzähler | open_run_level | Accept healing offer, then rest | Marta's house | 30/84 | 14.1 s |
| 30 | I thank Marta for the advice and head to the Drowned Ox to get a room for the night, then sleep until morning. | Erzähler | open_run_level | Recover overnight before the serpent hunt | the Drowned Ox | 30/84 | 20.2 s |
| 31 | I ask the innkeeper for a room for the night and pay his price, then go up and sleep until morning. | Erzähler | open_run_level | Get lodging and recover overnight | the Drowned Ox | 30/84 | 16.3 s |
| 32 | I take the corner room for ten coppers and the stew for two, pay the twelve, eat the supper and sleep until morning. | Erzähler | open_run_level | Book lodging, eat, recover overnight | the Drowned Ox | 140/84 | 123.1 s |
| 33 | #assign STR 3 VIT 3 AGI 2 WIL 2 | System (Befehl) | open_run_level | Spend free stat points, then hunt the millrace serpent | the Drowned Ox | 140/84 | 2.1 s |
| 34 | I head out of the Drowned Ox and travel to the millrace to hunt the serpent for my contract. | Erzähler | open_run_level | Pursue the active serpent contract | the millrace sluice below the Ashbridge mill | 140/84 | 19.8 s |
| 35 | I call over to the miller and ask whether those boot-prints and the dragged log by the sluice are his doing, or whether someone's been inter… | Erzähler | open_run_level | Ask the miller about the tracks and the log before hunting the serpent | the millrace sluice below the Ashbridge mill | 140/84 | 16.9 s |
| 36 | I confirm I'm from the Guild and took the culling notice, then ask the miller to clear the walkway log or lend a hand while I hunt the serpe… | Erzähler | open_run_level | Hunt the serpent for the contract | the millrace sluice below the Ashbridge mill | 140/84 | 21.1 s |
| 37 | I draw my sword and approach the dark pool by the sluice wall, watching the reeds, and prod the water's edge to draw the serpent out. | Erzähler | open_run_level | Hunt the serpent for the contract | the millrace sluice below the Ashbridge mill | 140/84 | 22.9 s |
| 38 | I strike at the serpent's head as it lunges, using Heavy Slash. | Erzähler | open_run_level | Fight the serpent | the millrace sluice below the Ashbridge mill | 140/84 | 15.7 s |
| 39 | I wade into the shallows toward the serpent, closing to sword range, and swing at its head with Heavy Slash as I come in range. | Erzähler | open_run_level | Close to ENGAGED and strike the serpent | the millrace sluice below the Ashbridge mill | 140/84 | 21.0 s |
| 40 | I climb up to dry ground, thank the miller, and tell him I'll claim the promised flour when I collect it — then head back to the Guild hall … | Erzähler | open_run_level | Collect flour promise, travel to Guild hall and turn in the serpent contract | Adventurers' Guild hall, Ashbridge | 140/84 | 23.9 s |
| 41 | I ask the clerk to buy my four grey wolf pelts, eight grey wolf fangs, and the serpent skin and fangs, and what he'll pay for the lot. | Erzähler | open_run_level | Sell surplus loot at the Guild | Adventurers' Guild hall, Ashbridge | 140/84 | 17.5 s |
| 42 | I accept the offer and take the thirty-one coppers for the lot. | Erzähler | open_run_level | Sell surplus loot to the Guild clerk | Adventurers' Guild hall, Ashbridge | 140/84 | 39.8 s |
| 43 | I ask the clerk to see the Guild's contract board for Novice-rank jobs I can take today. | Erzähler | open_run_level | Pick the next Guild contract | Adventurers' Guild hall, Ashbridge | 140/84 | 21.2 s |
| 44 | I take the Thin the Quarry Track Wolves slip and ask the clerk to accept the contract. | Erzähler | open_run_level | Accept the wolf-culling contract | Adventurers' Guild hall, Ashbridge | 140/84 | 13.7 s |
| 45 | I sign the ledger for the wolves contract, then head out the north gate and follow the old quarry track east to hunt grey wolves. | Erzähler | open_run_level | Travel to the quarry track and hunt wolves for the active contract | the old quarry track east of Ashbridge | 140/84 | 16.5 s |
| 46 | I draw my longsword and follow the carcass drag toward the alder stand, moving carefully to find the wolves before they find me. | Erzähler | open_run_level | Hunt the wolf pack at the fresh sign | the alder stand | 140/84 | 21.2 s |
| 47 | I charge the wolf holding before me and swing a Heavy Slash at it before it can flank me. | Engine (Menü/Rückfrage) | open_run_level | Engage the wolves, starting with the one facing me | the alder stand | 140/84 | 6.7 s |
| 48 | I hold my ground with longsword ready, waiting for the wolves to close, then strike at the first one that attacks me. | Erzähler | open_run_level | Engage the two wolves defensively | the alder stand | 126/84 | 18.0 s |
| 49 | I swing a Heavy Slash at Grey Wolf H, the one biting at my sword-side. | Erzähler | open_run_level | Attack the engaged wolf | the alder stand | 117/84 | 17.3 s |
| 50 | I swing a Heavy Slash at Grey Wolf I. | Erzähler | open_run_level | Defeat the last wolf for the contract | the alder stand | 117/84 | 14.6 s |
| 51 | #assign STR 3 VIT 2 | System (Befehl) | open_run_level | Allocate level-up points | the alder stand | 117/84 | 2.1 s |
| 52 | I follow the quarry track away from the alder stand, searching for more wolf sign. | Erzähler | open_run_level | Continue the wolf contract hunt | rocky saddle above the quarry | 117/84 | 33.0 s |
| 53 | I charge down the open slab at the larger wolf, Grey Wolf J, swinging a Heavy Slash the moment I reach it. | Erzähler | open_run_level | Attack the feeding wolves before they scatter | rocky saddle above the quarry | 117/84 | 15.7 s |
| 54 | I head back to the fresh wolf sign by the alder stand and search the cover there for the last wolf. | Erzähler | open_run_level | Hunt the fourth wolf for the contract | the alder stand | 117/84 | 24.5 s |
| 55 | I charge Grey Wolf K and swing a Heavy Slash at it. | Erzähler | open_run_level | Defeat the fourth wolf for the contract | the alder stand | 117/84 | 25.2 s |
| 56 | I close the distance to Grey Wolf K and swing a Heavy Slash at it. | Erzähler | open_run_level | Move into range and finish the fourth wolf | the alder stand | 117/84 | 32.1 s |
| 57 | I walk back along the quarry track to the Ashbridge Guild hall and turn in the completed contract, Thin the Quarry Track Wolves. | Erzähler | open_run_level | Turn in the finished wolf contract at the Guild | Adventurers' Guild hall, Ashbridge | 117/84 | 17.2 s |
| 58 | #assign STR 2 VIT 2 AGI 1 | System (Befehl) | open_run_level | Spend level-up points on combat stats | Adventurers' Guild hall, Ashbridge | 117/84 | 2.1 s |
| 59 | I ask the clerk what contracts are on the board for a Novice, and whether the Guild buys wolf pelts and fangs here. | Erzähler | open_run_level | Check board and sell surplus loot | Adventurers' Guild hall, Ashbridge | 117/84 | 16.6 s |
| 60 | I go to the broker's side window and offer three wolf pelts and four wolf fangs for sale, asking his price. | Erzähler | open_run_level | Sell surplus wolf loot at the Guild broker | Adventurers' Guild hall, Ashbridge | 117/84 | 29.4 s |
| 61 | I accept the broker's offer of thirty-six copper for the three pelts and four fangs, and hand the goods over. | Erzähler | open_run_level | Sell surplus wolf loot at the confirmed price | Adventurers' Guild hall, Ashbridge | 117/84 | 15.8 s |
| 62 | I ask the clerk to accept the Millrace Water Serpent contract and mark it active for me. | Erzähler | open_run_level | Take the achievable Novice serpent contract | Adventurers' Guild hall, Ashbridge | 117/84 | 16.4 s |
| 63 | I walk south to the mill and down to the sluice below the wheel, then look for the banded water serpent. | Erzähler | open_run_level | Travel to the millrace to hunt the serpent | the millrace sluice below the Ashbridge mill | 117/84 | 18.4 s |
| 64 | I watch the churned pool and the muddy far bank from the safe boards, keeping clear of the lower planks, and wait for the serpent to show it… | Erzähler | open_run_level | Locate the serpent before engaging | the millrace sluice below the Ashbridge mill | 117/84 | 22.7 s |
| 65 | I circle along the bank above the pool, keeping off the slick lower boards, and attack the serpent with Heavy Slash as soon as I'm in reach. | Erzähler | open_run_level | Engage the banded water serpent for the contract kill | the millrace sluice below the Ashbridge mill | 117/84 | 19.1 s |
| 66 | I move around the pool by the gravel and rush clumps on the near bank, keeping off the slick boards, until I'm close enough to reach the ser… | Erzähler | open_run_level | Close to MEDIUM range and engage the serpent | the millrace sluice below the Ashbridge mill | 117/84 | 19.2 s |
| 67 | I climb the sluice gate and cross the walk over the top of it, then attack the serpent with Heavy Slash once I'm in reach on the far side. | Erzähler | open_run_level | Cross the sluice walk to engage the serpent | the millrace sluice below the Ashbridge mill | 117/84 | 16.6 s |
| 68 | I step into the mud right up to the serpent and strike it with Heavy Slash. | Erzähler | open_run_level | Close to ENGAGED and attack | the millrace sluice below the Ashbridge mill | 117/84 | 40.8 s |
| 69 | I tell the miller the serpent's done and collect the proof from the carcass, then head back to the Guild hall in Duskreach to turn in the co… | Erzähler | open_run_level | Turn in the completed serpent contract | Adventurers' Guild hall, Ashbridge | 117/84 | 29.5 s |
| 70 | I ask the clerk to see the contract board for a new job. | Erzähler | open_run_level | Pick the next Guild contract | Adventurers' Guild hall, Ashbridge | 117/84 | 14.1 s |
| 71 | I take the Mossback Warrens Level 1 contract and ask the clerk to register it as active. | Erzähler | open_run_level | Accept the achievable novice dungeon contract | Adventurers' Guild hall, Ashbridge | 117/84 | 17.5 s |
| 72 | I tell the clerk I'll head out in the morning, then find a cheap lodging in Ashbridge and take a room for the night. | Erzähler | open_run_level | Recover overnight before the half-day trek to the warrens | the Drowned Ox | 117/84 | 23.7 s |
| 73 | I'll take the room and supper for eight copper, then sleep until morning. | Engine (Menü/Rückfrage) | open_run_level | Buy room and supper, recover overnight | the Drowned Ox | 117/84 | 8.7 s |
| 74 | I buy one room for the night and one supper from the innkeeper for eight copper total, then sleep until morning. | Engine (Menü/Rückfrage) | open_run_level | Clarify purchase, pay, recover overnight | the Drowned Ox | 117/84 | 9.5 s |
| 75 | I buy one room for the night (6 copper) and one supper (2 copper) from the innkeeper at the Drowned Ox, 8 copper total, then eat and sleep u… | Erzähler | open_run_level | Pay for lodging and recover overnight | the Drowned Ox | 195/92 | 16.7 s |
| 76 | I set out from Ashbridge on the west road toward Mossback Warrens to clear the warrens. | Erzähler | open_run_level | Travel to the warrens for the active contract | Mossback Warrens | 195/92 | 18.2 s |
| 77 | I enter the dungeon and head into the warrens, sword drawn, following the sounds of gravel and chittering. | Erzähler | open_run_level | Enter Mossback Warrens to clear level 1 | carved entry chamber of the Mossback Warrens | 195/92 | 25.7 s |
| 78 | I take the rough goblin-made stair down toward level 1, sword ready. | Erzähler | open_run_level | Descend into level 1 and clear goblin threats for the active contract | plunder gallery | 195/92 | 27.8 s |
| 79 | I charge the cleaver-bearer and use Heavy Slash on it. | Erzähler | open_run_level | Fight the three goblin warriors, starting with the cleaver-bearer | plunder gallery | 87/92 | 29.7 s |
| 80 | I finish the wounded cleaver-bearer with Heavy Slash on Goblin Warrior C. | Erzähler | open_run_level | Kill the weakest goblin to reduce incoming damage | plunder gallery | 0/92 | 38.5 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 2 (notiert vor Zug 3): Creation complete: Warrior with Heavy Slash and Guard, starter gear equipped, 5 silver.
- zu Zug 10 (notiert vor Zug 11): Level 2 after first wolf; spent no stat points yet.
- zu Zug 11 (notiert vor Zug 12): Contract says 4 wolves but quarryman carved 'MORE THAN FOUR' — pack may be larger.
- zu Zug 16 (notiert vor Zug 17): Quest panel already counts 2/4 defeated; these two lean wolves are the last required kills.
- zu Zug 17 (notiert vor Zug 18): HP 49/105 — badly hurt; consider recovery after this fight.
- zu Zug 19 (notiert vor Zug 20): HP down to 30/105; Grey Wolf F still unhurt at SHORT — likely need recovery after this fight.
- zu Zug 21 (notiert vor Zug 22): Quest still shows 3/4; the fled wolf likely counts as the fourth kill.
- zu Zug 23 (notiert vor Zug 24): Contract shows 4/4 defeated; HP 30/130 — badly wounded, will need rest or healing before taking another job.
- zu Zug 30 (notiert vor Zug 31): HP only 30/140; 10 free stat points unassigned — consider #assign after rest.
- zu Zug 32 (notiert vor Zug 33): Rest confirmed full recovery; stew wasn't purchased (no open offer) — fine.
- zu Zug 40 (notiert vor Zug 41): Narration said I walked to Duskreach's Guild hall, but HUD and engine place me in Ashbridge's Guild hall.
- zu Zug 53 (notiert vor Zug 54): Wolf K fled into the far gorse; contract shows 3/4.
- zu Zug 61 (notiert vor Zug 62): HUD still shows leftover pelt/fang stacks in inventory despite confirmed sale; note as minor discrepancy.
- zu Zug 62 (notiert vor Zug 63): HUD still shows leftover pelt/fang stacks despite the confirmed sale — minor discrepancy.
- zu Zug 74 (notiert vor Zug 75): System clarify loop keeps rejecting purchase phrasing despite explicit goods and total; trying itemized pricing format.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t9 | 9 | 1 | – | nein | 1 | gewonnen, 120 XP |
| enc.t12r | 12 | 1 | – | nein | 1 | gewonnen, 144 XP |
| enc.t19 | 19 | 1 | – | nein | 1 | gewonnen, 120 XP |
| enc.t22 | 23 | 1 | – | nein | 1 | gewonnen, 96 XP |
| enc.t37 | 39 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t45r | 48 | 2 | – | nein | 2 | gewonnen, 240 XP |
| enc.t49 | 53 | 1 | – | nein | 1 | gewonnen, 168 XP |
| enc.t52 | 56 | 1 | – | nein | 1 | gewonnen, 144 XP |
| enc.t63 | 68 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t72 | 79 | 3 | – | nein | 0 | **tot** |

## Quests

- **Cull the Serpent at the Millrace** — active (Zug 27) → completed (Zug 40), READY
  - Aufgabe: Kill 1 banded water serpent at the millrace sluice below the Ashbridge mill. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 banded water serpent killed at the millrace sluice below the Ashbridge mill.
- **Thin the Quarry Track Wolves** — active (Zug 6) → completed (Zug 25)
  - Aufgabe: Kill 4 grey wolves at the old quarry track east of Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 grey wolves killed at the old quarry track east of Ashbridge.
- **Slay the Barrow Boar of Thornfell** — expired (Zug 43)
  - Aufgabe: Kill 1 the barrow boar at the barrow fields above Thornfell. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the barrow boar killed at the barrow fields above Thornfell.
- **Slay the Ashwood Ravening Cat** — expired (Zug 43)
  - Aufgabe: Kill 1 the ravening cat at the deep Ashwood charcoal camps. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the ravening cat killed at the deep Ashwood charcoal camps.
- **Clear Mossback Warrens Level 1** — expired (Zug 43), Dungeon loc.mossback_warrens Ebene 1
  - Aufgabe: Clear level 1 of Mossback Warrens. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Mossback Warrens is clear.
- **Cull the Millrace Water Serpent** — active (Zug 62) → completed (Zug 69)
  - Aufgabe: Kill 1 banded water serpent at the millrace sluice below the Ashbridge mill. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 banded water serpent killed at the millrace sluice below the Ashbridge mill.
- **Thin the Quarry Track Wolves** — active (Zug 44) → completed (Zug 57), READY
  - Aufgabe: Kill 4 grey wolf at the old quarry track east of Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 grey wolf killed at the old quarry track east of Ashbridge.
- **Clear Mossback Warrens Level 1** — active (Zug 71), Dungeon loc.mossback_warrens Ebene 1
  - Aufgabe: Clear level 1 of Mossback Warrens. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Mossback Warrens is clear.

## Auffälligkeiten

- Zug 11, Nachricht 22 (extraction_repaired): the extractor's first answer needed a repair
- Zug 12, Nachricht 23 (stat_words): the player spent Stat Points in words, not with #assign; nothing was assigned (for review: did the story tell them as done?)
- Zug 16, Nachricht 32 (extraction_repaired): the extractor's first answer needed a repair
- Zug 32, Nachricht 63 (planner_repaired): the planner's first answer needed a repair
- Zug 37, Nachricht 74 (extraction_repaired): the extractor's first answer needed a repair
- Zug 40, Nachricht 80 (extraction_repaired): the extractor's first answer needed a repair
- Zug 60, Nachricht 119 (planner_repaired): the planner's first answer needed a repair
- Zug 60, Nachricht 120 (extraction_repaired): the extractor's first answer needed a repair
- Zug 61, Nachricht 121 (planner_repaired): the planner's first answer needed a repair
- Zug 62, Nachricht 124 (extraction_repaired): the extractor's first answer needed a repair
- Zug 64, Nachricht 128 (extraction_repaired): the extractor's first answer needed a repair
- Zug 69, Nachricht 138 (extraction_repaired): the extractor's first answer needed a repair
- Zug 73, Nachricht 145 (planner_repaired): the planner's first answer needed a repair
- Zug 74, Nachricht 147 (planner_repaired): the planner's first answer needed a repair
- Zug 77, Nachricht 154 (extraction_repaired): the extractor's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 13× keine gültige JSON-Entscheidung (Züge 2, 4, 11, 21, 22, 35, 37, 48, 51, 52, 67, 78, 79)
- 1 Aufruf(e) mit finish_reason "length" (Nr. 91 narrator)

System-Panels: CLARIFY 2, NOT TAKEN 1, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: ambient 4, engine_owned_fact 8, attack_commitment 7, pc_inventory 3, world_rule 3, quest_count 1, engine_recovery 1, engine_owned_combat 1, guild_payout 2, scene_context 9, no_go 1, engine_owned_memory 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 1 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 1 mit Erzähltext, 0 leer, 0 ohne Antwort; 1 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 13/80 Erstantworten ungültig (16.3 %); 13 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 79 | 5 | 2.5 s | 6.5 s | 11765 | 9869 | 83 | – | stop 79 | 0 |
| board | 3 | 1 | 7.7 s | 9.9 s | 2463 | 2150 | 1086 | – | stop 3 | 0 |
| narrator | 72 | 0 | 8.1 s | 11.4 s | 11361 | 8759 | 412 | – | stop 71, length 1 | 1 |
| extract | 80 | 9 | 4.8 s | 8.4 s | 11966 | 9301 | 342 | – | stop 80 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 34:44 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 66.1 s) | 1:22 min |
| 80 Züge, Spiel (Senden bis HUD nach der Extraktion) | 28:33 min — Median 19.1 s, p90 33.6 s, max 123.1 s |
| 80 Züge, Spieler-Entscheidung | 3:32 min — Median 1.9 s, 13 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 5:08 min / 0:24 min / 10:45 min / 7:39 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 24.1 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 16:02 min, 80 Züge ≈ 32:04 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spiel | 32 | – | 123.1 s | 19.1 s |
| Provider narrator | 32 | 91 | 93.6 s | 8.1 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
