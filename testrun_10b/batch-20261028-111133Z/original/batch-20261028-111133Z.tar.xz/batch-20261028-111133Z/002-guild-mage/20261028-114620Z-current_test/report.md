# Avereth Live-Test 20261028-114620Z-current_test

## Kurzfassung

- **Laufprofil:** guild-mage; Startklasse Mage, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** abgebrochen: Limit erreicht — 150 turns
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 8. Sicherheitsgrenzen: 150 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** Level 6, 438 XP seit Levelaufstieg, 279 cp, HP 155, MP 252; Ort loc.alderwatch.the_anchorstone_inn. Ausrüstung und Skills stehen in evaluation.json → progression.checkpoint.
- **Charakter:** mage (mage.arcane_bolt, mage.arcane_ward) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: curious adventurer: follow interesting opportunities without forcing dangerous encounters
- **Züge:** 150 · **Dauer:** 64:12 min · **LLM-Aufrufe der Engine/des Erzählers:** 432
- **Beobachtete Abdeckung:** 22 unterschiedliche gebuchte Reiseziele · 16 Kämpfe · 1 Verkäufe (73 cp Umsatz, ohne Questzahlungen/Geschenke) · 0 Ausrüstungswechsel · 1 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 21
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.112 |
| Git | d9c259f98f2d (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 15.7 s |
| Browser | chrome 156.0.8078.48 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261028-114620Z-current_test“, Seed 1846470029 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | I choose Mage. | Engine (Menü/Rückfrage) | creation_complete | Select Mage as base class | public roadside verge outside Alderwatch | 90/84 | 2.3 s |
| 2 | I choose Arcane Bolt and Arcane Ward. | Engine (Menü/Rückfrage) | creation_complete | Finish character creation with two starter skills | public roadside verge outside Alderwatch | 90/96 | 2.1 s |
| 3 | I walk to Alderwatch and head to the Adventurers' Guild to look at the contract board. | Erzähler | open_run_level | Enter the city and find Guild contracts | Adventurers' Guild hall, Alderwatch | 90/96 | 28.3 s |
| 4 | I approach the clerk and ask to register with the Guild as a novice adventurer. | Erzähler | open_run_level | Register at the Guild so contracts can be accepted | Adventurers' Guild hall, Alderwatch | 90/96 | 10.9 s |
| 5 | I pay the two silver, give my name as Alaric Red, and place my hand on the measuring stone. | Erzähler | open_run_level | Register with the Guild | Adventurers' Guild hall, Alderwatch | 90/96 | 12.8 s |
| 6 | I take the marsh cat contract from the novice board. "I'll take the marsh cat cull at the fishing stakes." | Erzähler | open_run_level | Accept the novice marsh cat contract | Adventurers' Guild hall, Alderwatch | 90/96 | 13.3 s |
| 7 | I head south through the gate to the fishing stakes to hunt the marsh cat. | Erzähler | open_run_level | Travel to the contract site | fish-drying stakes on the riverbank south of Alderwatch | 90/96 | 24.7 s |
| 8 | I search the reed beds upstream of the racks for the marsh cat. | Erzähler | open_run_level | Find and kill the contract marsh cat | fish-drying stakes on the riverbank south of Alderwatch | 90/96 | 16.9 s |
| 9 | I cross to the other side of the racks where the boat ties up and search there for the marsh cat. | Erzähler | open_run_level | Find the marsh cat at the boat tie-up | muddy boat landing below the racks | 90/96 | 19.5 s |
| 10 | I follow the paw prints leading downstream from the landing into the reeds and search there for the marsh cat. | Erzähler | open_run_level | Track the marsh cat from the landing prints | reed hollow downstream of the racks | 90/96 | 24.1 s |
| 11 | I cast Arcane Bolt at the marsh cat. | Erzähler | open_run_level | Attack the contract marsh cat | reed hollow downstream of the racks | 90/86 | 17.2 s |
| 12 | I return to the Alderwatch Guild hall and turn in the marsh cat contract, presenting the pelt, claw, and fangs as proof. | Erzähler | open_run_level | Turn in completed contract at the Guild hall | Adventurers' Guild hall, Alderwatch | 90/86 | 23.7 s |
| 13 | I ask the clerk what novice contracts are on the board today. | Erzähler | open_run_level | Pick next Guild contract | Adventurers' Guild hall, Alderwatch | 90/86 | 22.1 s |
| 14 | I take the boar contract slip and tell the clerk I'm accepting 'Thin the Reed Flats Boar Sounder'. | Erzähler | open_run_level | Accept achievable boar cull contract | Adventurers' Guild hall, Alderwatch | 90/86 | 17.2 s |
| 15 | I head east out of Alderwatch toward the Reed Flats eel-weirs and look for the boars there. | Erzähler | open_run_level | Travel to contract site and hunt boars | eel-weirs of the Reed Flats | 90/86 | 18.2 s |
| 16 | I tell the eel fishers I'm here on the Guild boar contract and ask where the boars have been causing the most trouble. | Erzähler | open_run_level | Get boar location from fishers | eel-weirs of the Reed Flats | 90/86 | 55.2 s |
| 17 | I head west past the third weir, following the churned mud and torn wattling, and listen for rattling traps. | Erzähler | open_run_level | Hunt the contract boars | eel-weirs of the Reed Flats | 90/86 | 16.7 s |
| 18 | I wade around the lagoon's edge toward the swaying reeds and cast Arcane Bolt at the nearest boar. | Erzähler | open_run_level | Engage the boar sounder | eel-weirs of the Reed Flats | 90/86 | 21.6 s |
| 19 | I step back out of charge range and cast Arcane Bolt again at the nearest boar. | Erzähler | open_run_level | Keep hitting boar A while avoiding its charge | eel-weirs of the Reed Flats | 90/76 | 15.4 s |
| 20 | I cast Arcane Bolt at Reed-Bed Boar B and step back out of its charge range. | Erzähler | open_run_level | Continue the boar fight | eel-weirs of the Reed Flats | 90/66 | 14.0 s |
| 21 | I cast Arcane Bolt at Reed-Bed Boar B to finish it, then step back out of charge range. | Erzähler | open_run_level | Kill the wounded boar | eel-weirs of the Reed Flats | 90/56 | 16.8 s |
| 22 | #assign INT 2 WIL 2 VIT 1 | System (Befehl) | open_run_level | Spend the 5 level-up stat points to boost damage, mana and survivability | eel-weirs of the Reed Flats | 90/56 | 2.1 s |
| 23 | I follow the churned trail the two boars left into the reed bed, keeping low and listening for their movement. | Erzähler | open_run_level | Track and engage the remaining two contract boars | boar wallow in the reed bed | 90/56 | 20.4 s |
| 24 | I follow the eastern trail toward the alder line, moving quietly and keeping my staff ready, listening for the sound of the boars. | Erzähler | open_run_level | Track the remaining two contract boars toward the alder line | reed edge above the boar pool | 90/56 | 32.6 s |
| 25 | I cast Arcane Bolt at the boar grazing on the mud shelf, then retreat a step back into the reeds for cover. | Erzähler | open_run_level | Open the fight against boar C from the reed edge | reed edge above the boar pool | 90/46 | 23.3 s |
| 26 | I cast Arcane Bolt at the wounded Reed-Bed Boar D to finish it, then step back deeper into the reeds. | Erzähler | open_run_level | Kill the crippled boar before the big one arrives | reed edge above the boar pool | 90/36 | 16.7 s |
| 27 | #assign INT 2 WIL 2 VIT 1 | System (Befehl) | open_run_level | Spend the new 5 level-up stat points | reed edge above the boar pool | 90/36 | 2.1 s |
| 28 | I back away slowly through the reeds, keeping low and out of the big boar's sight line, and withdraw toward the fishing weir to look for the… | Erzähler | open_run_level | Disengage from the big boar and seek the nearby fisher | reed edge above the boar pool | 90/36 | 13.5 s |
| 29 | I walk out of the reeds toward the weir and look around for the fisher who uses it, keeping clear of the boar pool. | Erzähler | open_run_level | Find the fisher at the weir, away from the big boar | eel weir with wicker trap | 90/36 | 24.4 s |
| 30 | I walk up to the weir's trap cage and look inside to see what is knocking against its walls. | Erzähler | open_run_level | Inspect the occupied eel trap | eel weir with wicker trap | 90/36 | 23.6 s |
| 31 | I step back from the trap and call out toward the hut, "Anyone here? Your weir trap is full of fish—and a very persistent coot." | Erzähler | open_run_level | Find the fisher at the hut | eel weir with wicker trap | 90/36 | 20.5 s |
| 32 | "The boars—I'm on the Guild contract to thin the sounder, two down so far. Is there a reward or information in it if I clear the big one tha… | Erzähler | open_run_level | Talk to the fisher about the boar contract and the big boar | eel weir with wicker trap | 90/36 | 19.5 s |
| 33 | "Boars it is. Mind if I release that coot from your trap and rest by your hut an hour? I'm low on mana and want a full well before I go back… | Erzähler | open_run_level | Ask the fisher for a safe rest spot and free the trapped coot | eel weir with wicker trap | 90/36 | 20.8 s |
| 34 | I thank the fisher for the food and information, then head back into the reeds toward the boar pool, keeping downwind of the Old Man as I ap… | Erzähler | open_run_level | Hunt the Old Man boar with restored preparation, using the wind | reed edge above the boar pool | 90/36 | 19.6 s |
| 35 | I cast Arcane Ward on myself first, then step toward the reed stand and shout to wake the Old Man, staff ready, backing toward the pool's op… | Erzähler | open_run_level | Fight the Old Man boar with ward up and open ground | reed edge above the boar pool | 90/36 | 18.2 s |
| 36 | I sidestep the charge across the mud and fire Arcane Bolt at the Old Man's flank as he passes. | Erzähler | open_run_level | Dodge the boar charge and counterattack | reed edge above the boar pool | 63/26 | 21.3 s |
| 37 | I cast Arcane Ward on myself to blunt the next gore, holding my staff low between us. | Erzähler | open_run_level | Defend while mana is low | reed edge above the boar pool | 63/16 | 19.0 s |
| 38 | I fire Arcane Bolt at the Old Man's wounded flank. | Erzähler | open_run_level | Finish the boar with a second bolt | reed edge above the boar pool | 34/6 | 15.9 s |
| 39 | I grab my staff from the water and strike at the Old Man's head with a basic attack. | Erzähler | open_run_level | Finish the dying boar with a basic attack | reed edge above the boar pool | 34/6 | 18.5 s |
| 40 | I check my wounds and drink a healing potion if I have one, otherwise bandage my leg, then collect the Old Man's hide and tusk before headin… | Erzähler | open_run_level | Recover and harvest the Old Man's proof | eel weir with wicker trap | 34/6 | 25.9 s |
| 41 | I rest here at the weir until evening, then head back to the Guild hall to turn in the boar contract. | Erzähler | open_run_level | Rest to recover, then turn in the contract | Adventurers' Guild hall, Alderwatch | 49/41 | 26.7 s |
| 42 | I ask the clerk to keep the contract active so I can hunt the fourth boar, then head to the inn, take a room, and sleep until morning. | Erzähler | open_run_level | Recover overnight, keep contract active | inn | 49/41 | 23.2 s |
| 43 | I'll take the stew and room with bread for three copper, then eat and sleep until morning. | Erzähler | open_run_level | Buy meal and lodging, recover overnight | inn | 110/168 | 17.5 s |
| 44 | I head back out the river path to the Reed Flats and hunt the fourth reed-bed boar. | Erzähler | open_run_level | Hunt the last boar for the contract | eel-weirs of the Reed Flats | 110/168 | 19.9 s |
| 45 | I follow the fresh trail toward the third weir, readying my staff, and cast Arcane Bolt at the big gray boar when I spot it. | Erzähler | open_run_level | Hunt the fourth boar for the contract | third weir | 110/168 | 21.9 s |
| 46 | I cast Arcane Bolt at the gray boar. | Erzähler | open_run_level | Fight the fourth boar for the contract | third weir | 88/158 | 13.4 s |
| 47 | I cast Arcane Bolt at the gray boar. | Erzähler | open_run_level | Finish the fourth boar for the contract turn-in | third weir | 65/148 | 14.2 s |
| 48 | I cast Arcane Bolt at the gray boar to finish it. | Erzähler | open_run_level | Kill the fourth boar | third weir | 65/138 | 12.6 s |
| 49 | #assign INT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up stat points | third weir | 65/138 | 2.2 s |
| 50 | I slip away quietly along the river path back to town, and once at the Guild hall I hand in the contract slip and report all four boars to c… | Erzähler | open_run_level | Return to the Guild hall and turn in the completed boar contract | Adventurers' Guild hall, Alderwatch | 65/138 | 45.2 s |
| 51 | #assign VIT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up points toward durability | Adventurers' Guild hall, Alderwatch | 65/138 | 2.4 s |
| 52 | I ask the clerk to see the Guild contract board for available novice jobs. | Erzähler | open_run_level | Pick a new Guild contract after turn-in | Adventurers' Guild hall, Alderwatch | 65/138 | 20.8 s |
| 53 | I accept the 'Cull the Marsh Cat at the Fish-Drying Stakes' contract, then head to the Temple to have my wounded leg healed before hunting. | Erzähler | open_run_level | Take easy contract, then heal at Temple | Temple of Alderwatch | 65/138 | 22.7 s |
| 54 | I take the healing rite for 60 copper. | Erzähler | open_run_level | Buy full healing to restore HP | Temple of Alderwatch | 65/138 | 16.5 s |
| 55 | #status | System (Befehl) | open_run_level | Verify whether the healing rite actually cleared the wounded condition, since the HUD stil… | Temple of Alderwatch | 65/138 | 2.1 s |
| 56 | The rite closed the wound but my HP still shows 65/135. Healer, is something else keeping me from regaining my strength? | Erzähler | open_run_level | Ask the healer why HP hasn't recovered after the healing rite | Temple of Alderwatch | 65/138 | 81.7 s |
| 57 | I buy a broth and bread meal for 1 copper. | Erzähler | open_run_level | Recover HP per healer's advice | Temple of Alderwatch | 65/138 | 14.4 s |
| 58 | I head south out the river gate to the fish-drying stakes and hunt the marsh cat there. | Erzähler | open_run_level | Pursue the active marsh cat cull contract | fish-drying stakes on the riverbank south of Alderwatch | 65/138 | 19.9 s |
| 59 | I follow the churned prints into the reed bed, staff ready, feeling for the cat's trail in the mud. | Erzähler | open_run_level | Track and hunt the marsh cat for the cull contract | tussock island in the reed bed | 65/138 | 24.3 s |
| 60 | I cast Arcane Bolt at the marsh cat before it can leap. | Erzähler | open_run_level | Attack the marsh cat first | tussock island in the reed bed | 65/128 | 58.7 s |
| 61 | I head back through the reeds along the trail to the fish-drying stakes. | Erzähler | open_run_level | Return to the fisherman after completing the cat cull | fish-drying stakes on the riverbank south of Alderwatch | 65/128 | 23.0 s |
| 62 | I take the torn perch with thanks and walk back through the river gate to the Guild hall in Alderwatch to turn in the marsh cat cull. | Erzähler | open_run_level | Turn in the completed cull contract at the Guild | Adventurers' Guild hall, Alderwatch | 65/128 | 23.2 s |
| 63 | I look over the Guild board for another achievable contract. | Erzähler | open_run_level | Pick the next contract | Adventurers' Guild hall, Alderwatch | 65/128 | 16.7 s |
| 64 | I ask the clerk to accept the Reed-Bed Boars cull contract at the eel-weirs. | Erzähler | open_run_level | Take the boar cull contract | Adventurers' Guild hall, Alderwatch | 65/128 | 15.9 s |
| 65 | I head to an inn, take a room for the night, and sleep until morning. | Erzähler | open_run_level | Recover HP overnight before hunting boars | inn | 65/128 | 20.4 s |
| 66 | I buy the room for the night with breakfast for 4 copper, then sleep until morning. | Erzähler | open_run_level | Pay for lodging and recover overnight | inn | 135/232 | 15.9 s |
| 67 | I set out from Alderwatch along the road to the Reed Flats, heading for the eel-weirs to hunt the boars. | Erzähler | open_run_level | Travel to the eel-weirs for the boar cull | eel-weirs of the Reed Flats | 135/232 | 20.9 s |
| 68 | I ask the eel-gutter where the boars were seen past the middle weirs, then move carefully along the causeway toward that spot, watching for … | Erzähler | open_run_level | Hunt the boars for the cull contract | middle weirs | 135/232 | 36.6 s |
| 69 | I cast Arcane Bolt at the closer boar, keeping my footing on firm timber. | Erzähler | open_run_level | Fight the two boars for the cull contract | middle weirs | 108/222 | 22.6 s |
| 70 | I cast Arcane Bolt at the wounded boar B to finish it. | Erzähler | open_run_level | Kill the near-dead boar first | middle weirs | 94/212 | 20.6 s |
| 71 | I cast Arcane Bolt at the remaining boar. | Erzähler | open_run_level | Finish the boar fight | middle weirs | 80/202 | 44.4 s |
| 72 | I cast Arcane Bolt at the crippled boar to finish it. | Erzähler | open_run_level | Finish the boar fight | middle weirs | 80/192 | 15.4 s |
| 73 | I press on along the causeway toward the next weir, keeping watch for more boars. | Erzähler | open_run_level | Continue the boar cull (2/4) | third weir | 80/192 | 17.4 s |
| 74 | I follow the large boar tracks north into the reed beds, staff ready, watching for the big boar. | Erzähler | open_run_level | Hunt the large boar to progress the cull contract | boar wallow in the reed bed | 80/192 | 22.2 s |
| 75 | I cast Arcane Bolt at the charging giant boar, backing onto firmer ground. | Erzähler | open_run_level | Fight the giant boar | boar wallow in the reed bed | 80/192 | 21.4 s |
| 76 | I retreat along the reed lane back toward the weir, keeping my eyes on the giant boar and not turning my back on it. | Erzähler | open_run_level | Disengage from the too-strong giant boar and continue the cull on regular boars | boar wallow in the reed bed | 80/192 | 19.0 s |
| 77 | I cast Arcane Bolt at the giant boar, then retreat another stretch down the lane toward the weir. | Erzähler | open_run_level | Chip at the boar from MEDIUM range while keeping distance | boar wallow in the reed bed | 80/182 | 20.4 s |
| 78 | I cast Arcane Bolt at the giant boar at SHORT range, then keep backing toward the weir. | Erzähler | open_run_level | Finish the wounded giant boar while it is close enough to hit | boar wallow in the reed bed | 80/172 | 20.3 s |
| 79 | I cast Arcane Bolt at the boar in the dense reed stand north of the pool, keeping the weir between us if it charges. | Engine (Menü/Rückfrage) | open_run_level | Hunt the fourth boar to finish the cull contract | boar wallow in the reed bed | 80/172 | 5.2 s |
| 80 | I move down the lane toward the weir, watching for a reed-bed boar away from the dense reed stand. | Erzähler | open_run_level | Find the fourth boar for the cull contract | third weir | 80/172 | 17.0 s |
| 81 | I search the flats and reed margins around the third weir for a single reed-bed boar to finish the cull. | Erzähler | open_run_level | Hunt the fourth boar near the third weir | third weir | 80/172 | 15.7 s |
| 82 | I try the second weir's reed margins for a fresh boar trail or wallow, working the waterline. | Erzähler | open_run_level | Find the fourth boar at a different weir | second weir | 80/172 | 17.1 s |
| 83 | I follow the trail of broken stems into the reed stand at the second weir's far margin, staff ready, hunting the boar that made the fresh wa… | Erzähler | open_run_level | Track and kill the fourth boar from the fresh sign | reed stand at the second weir's far margin | 62/172 | 23.6 s |
| 84 | I cast Arcane Bolt at the reed-bed boar at ENGAGED range. | Erzähler | open_run_level | Kill the fourth boar to finish the cull | reed stand at the second weir's far margin | 62/162 | 18.4 s |
| 85 | I cast Arcane Bolt at the wounded boar. | Erzähler | open_run_level | Finish the fourth boar and complete the cull | reed stand at the second weir's far margin | 62/152 | 14.6 s |
| 86 | #assign VIT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up stat points | reed stand at the second weir's far margin | 62/152 | 2.5 s |
| 87 | I head back along the waterline toward the Guild hall in Valedorn Crown to turn in the completed boar cull. | Erzähler | open_run_level | Return and turn in the finished cull contract | Adventurers' Guild hall, Alderwatch | 62/152 | 37.3 s |
| 88 | I ask the clerk what contracts are on the novice board today, and whether the Guild buys boar hides and tusks. | Erzähler | open_run_level | Turn in done; find next work and sell surplus | Adventurers' Guild hall, Alderwatch | 62/152 | 28.4 s |
| 89 | I take the Marsh Cat cull slip from the board and ask the clerk to register it as my active contract. | Erzähler | open_run_level | Accept the marsh cat cull contract | Adventurers' Guild hall, Alderwatch | 62/152 | 16.5 s |
| 90 | I wait at the broker's counter for Hesk and offer him my reed-bed boar hides and tusks to weigh and price. | Erzähler | open_run_level | Sell surplus boar loot at the Guild broker | Adventurers' Guild hall, Alderwatch | 62/152 | 30.8 s |
| 91 | I accept Hesk's offer of three silver thirteen copper for the lot of hides and tusks. | Engine (Menü/Rückfrage) | open_run_level | Sell boar loot to Hesk | Adventurers' Guild hall, Alderwatch | 62/152 | 7.7 s |
| 92 | I sell all my boar hides and tusks to Hesk for the agreed total of three silver thirteen copper. | Engine (Menü/Rückfrage) | open_run_level | Clarify and complete the loot sale | Adventurers' Guild hall, Alderwatch | 62/152 | 6.7 s |
| 93 | I sell all my boar hides and tusks to Hesk at his bid of 73 copper for the lot. | Erzähler | open_run_level | Accept Hesk's 73 copper offer | Adventurers' Guild hall, Alderwatch | 62/152 | 17.9 s |
| 94 | I ask the clerk where the Fish-Drying Stakes are, and whether there's a healer or a cheap room in town where I can patch this wound before h… | Erzähler | open_run_level | Get directions and recovery options before hunting the marsh cat | Adventurers' Guild hall, Alderwatch | 62/152 | 19.8 s |
| 95 | I head to Maren's house on Cooper's Row, blue door, and ask her to treat my wound. | Erzähler | open_run_level | Get healed before hunting the marsh cat | Maren's house on Cooper's Row | 62/152 | 24.6 s |
| 96 | I pay Maren the two copper for the stitching and salve. | Erzähler | open_run_level | Pay for healing | Maren's house on Cooper's Row | 62/152 | 19.8 s |
| 97 | I thank Maren, eat the stew, then take a room at the Anchorstone and sleep until morning. | Erzähler | open_run_level | Recover HP overnight before hunting the marsh cat | the Anchorstone inn | 62/152 | 17.6 s |
| 98 | I pay the innkeeper nine copper for the corner room for the night. | Erzähler | open_run_level | Buy lodging so I can sleep and recover HP | the Anchorstone inn | 62/152 | 17.3 s |
| 99 | I go up to my corner room at the Anchorstone and sleep until morning. | Erzähler | open_run_level | Actually sleep to recover HP before the marsh cat hunt | the Anchorstone inn | 62/152 | 22.6 s |
| 100 | I go upstairs to the corner room I paid for, shut the door, and sleep until morning. | Erzähler | open_run_level | Sleep in the purchased room to recover HP | the Anchorstone inn | 155/252 | 21.4 s |
| 101 | I eat breakfast downstairs, then head out to the fish-drying stakes to hunt the marsh cat. | Erzähler | open_run_level | Hunt the marsh cat for the active cull contract | fish-drying stakes on the riverbank south of Alderwatch | 155/252 | 30.8 s |
| 102 | I ask the fisherman where the flat stone by the reed fence is, then head upriver past the third row to look for the marsh cat's tracks and i… | Erzähler | open_run_level | Scout the marsh cat's approach route for the cull contract | flat stone by the reed fence | 155/252 | 31.9 s |
| 103 | I climb onto the flat stone and cast Arcane Bolt into the tunnel of broken stalks to flush out the marsh cat. | Erzähler | open_run_level | Hunt the marsh cat at its reed tunnel | flat stone by the reed fence | 155/242 | 20.2 s |
| 104 | I follow the tunnel of broken stalks into the reeds, staff ready, searching for the marsh cat. | Erzähler | open_run_level | Enter the reed stand to find and fight the marsh cat | crushed-reed day-bed hollow | 155/242 | 25.2 s |
| 105 | I cast Arcane Bolt at the marsh cat. | Erzähler | open_run_level | Attack the marsh cat to complete the cull contract | crushed-reed day-bed hollow | 155/232 | 14.8 s |
| 106 | I take the marsh cat's pelt and claws, then head back out of the reeds toward the fish-drying stakes. | Erzähler | open_run_level | Return to the Guild hall to turn in the completed cull contract | fish-drying stakes on the riverbank south of Alderwatch | 155/232 | 21.3 s |
| 107 | I tell the fisherman the marsh cat is dead in its day-bed, then head back to the Guild hall in Alderwatch to turn in the cull contract. | Erzähler | open_run_level | Turn in the completed cull contract | Adventurers' Guild hall, Alderwatch | 155/232 | 57.6 s |
| 108 | I check the Guild contract board for a new novice contract. | Erzähler | open_run_level | Pick the next Guild contract | Adventurers' Guild hall, Alderwatch | 155/232 | 22.8 s |
| 109 | I accept the contract 'Cull the Reed-Bed Boars at the Eel-Weirs' from the board. | Erzähler | open_run_level | Take the boar cull contract | Adventurers' Guild hall, Alderwatch | 155/232 | 15.7 s |
| 110 | I ask Hesk what he'll pay for three marsh cat pelts, six claws, and four fangs. | Erzähler | open_run_level | Sell surplus loot at Hesk's counter before heading out | Adventurers' Guild hall, Alderwatch | 155/232 | 15.2 s |
| 111 | I accept Hesk's offer and hand over the three pelts, six claws, and four fangs for three Silver six Copper, then head south-west toward the … | Erzähler | open_run_level | Sell loot and travel to boar hunt | eel-weirs of the Reed Flats | 155/232 | 34.8 s |
| 112 | I ask the fishers to point me to the third weir and follow the broken-stem trail, keeping to the causeway as the woman advised. | Erzähler | open_run_level | Track and hunt the reed-bed boars | third weir | 155/232 | 18.6 s |
| 113 | I cast Arcane Bolt at the boar on the trail, then step back along the causeway to keep the mud behind me. | Erzähler | open_run_level | Fight the boar from the causeway | third weir | 155/222 | 15.4 s |
| 114 | I cast Arcane Bolt at the boar again. | Erzähler | open_run_level | Finish the wounded boar | third weir | 155/212 | 33.9 s |
| 115 | #assign INT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up stat points | third weir | 155/212 | 2.7 s |
| 116 | I follow the broken-stem trail toward the second weir's far reed margins to hunt the next boar. | Erzähler | open_run_level | Continue boar cull (1/4) | reed stand at the second weir's far margin | 155/212 | 18.6 s |
| 117 | I step quietly along the causeway spine toward the feeding sounds and cast Arcane Bolt at the boar in the reeds. | Erzähler | open_run_level | Engage the second boar from the causeway | boar wallow in the reed bed | 155/212 | 19.8 s |
| 118 | I cast Arcane Bolt at the boar before it can turn fully. | Erzähler | open_run_level | Open the fight with a first strike | boar wallow in the reed bed | 139/202 | 15.5 s |
| 119 | I cast Arcane Bolt at the boar to finish it. | Erzähler | open_run_level | Kill the wounded boar before it charges again | boar wallow in the reed bed | 139/192 | 25.4 s |
| 120 | I check my wounds and mana, then decide whether to press on toward the third boar or rest behind cover first. | Erzähler | open_run_level | Assess condition before continuing the cull | boar wallow in the reed bed | 139/192 | 17.3 s |
| 121 | I press on along the causeway spine toward the third weir, following the fresh rooting smell, and cast Arcane Bolt at the next boar I spot b… | Erzähler | open_run_level | Hunt the third boar toward the third weir | third weir | 139/192 | 32.4 s |
| 122 | I cast Arcane Bolt at the boar's back while it feeds, then ready a second bolt in case it charges. | Erzähler | open_run_level | Open the fight against boar H with a first strike | third weir | 139/183 | 24.3 s |
| 123 | I cast Arcane Bolt at the wounded boar to finish it. | Erzähler | open_run_level | Finish boar H at short range | third weir | 139/174 | 23.7 s |
| 124 | The contract shows 3/4, so I follow the causeway back toward the wallow country, keeping clear of the heavy reed stand, and look for a fourt… | Erzähler | open_run_level | Find and kill the fourth boar to complete the contract count | boar wallow in the reed bed | 139/174 | 21.6 s |
| 125 | I work the open wallow pans away from the heavy reed stand, scanning for an ordinary reed-bed boar, and cast Arcane Bolt at the first one I … | Engine (Menü/Rückfrage) | open_run_level | Hunt the fourth boar to complete the 3/4 contract count | boar wallow in the reed bed | 139/174 | 5.8 s |
| 126 | I leave the heavy reed stand alone and walk back out to the third weir flats, scanning the open reed beds there for a boar; if I spot one, I… | Erzähler | open_run_level | Find and cull the fourth boar near the third weir | third weir | 139/174 | 33.6 s |
| 127 | I cast Arcane Bolt at the feeding boar, then ready a second bolt in case it charges. | Erzähler | open_run_level | First-strike boar I to reach 4/4 | third weir | 139/174 | 22.1 s |
| 128 | I creep closer to the boar using the scattered hummocks and reed clumps as cover; once within MEDIUM range, I cast Arcane Bolt at it. | Erzähler | open_run_level | Close to MEDIUM range with cover, then first-strike boar I to reach 4/4 | third weir | 139/174 | 19.4 s |
| 129 | I keep moving from hummock to hummock until I am within MEDIUM range of the boar, then cast Arcane Bolt at it. | Erzähler | open_run_level | Close to MEDIUM and first-strike boar I | third weir | 139/165 | 21.3 s |
| 130 | I cast Arcane Bolt at the wounded boar. | Erzähler | open_run_level | Finish the boar at SHORT range to reach 4/4 | third weir | 139/156 | 20.2 s |
| 131 | With the count at 4/4, I leave the big thing in the reed stand alone and head back along the causeway toward the Guild hall in Valedorn Crow… | Erzähler | open_run_level | Turn in the completed 4/4 boar cull at the Guild hall | Adventurers' Guild hall, Alderwatch | 139/156 | 24.6 s |
| 132 | #assign WIL 3 INT 2 | System (Befehl) | open_run_level | Spend level-up points | Adventurers' Guild hall, Alderwatch | 139/156 | 2.8 s |
| 133 | I ask the clerk what contracts are on the board suitable for a Novice mage. | Erzähler | open_run_level | Pick next Guild contract | Adventurers' Guild hall, Alderwatch | 139/156 | 16.8 s |
| 134 | I accept the Marsh Cat cull contract at the Fish-Drying Stakes. | Erzähler | open_run_level | Take achievable Novice contract | Adventurers' Guild hall, Alderwatch | 139/156 | 23.5 s |
| 135 | I sell Hesk the Old Man's tusk and the F-Rank Reed-bed Boar Hide, then head south past the tanning yards to the fish-drying stakes. | Erzähler | open_run_level | Sell surplus loot, then hunt the marsh cat before dark | fish-drying stakes on the riverbank south of Alderwatch | 139/156 | 53.5 s |
| 136 | I accept Hesk's twelve-copper offer for the tusk and hide, then take up a position near the drying stakes and watch the reed stand for the m… | Erzähler | open_run_level | Sell loot, then hunt the marsh cat at dusk | fish-drying stakes on the riverbank south of Alderwatch | 139/156 | 47.2 s |
| 137 | I cast Arcane Bolt at the marsh cat while it's turning back toward the reeds. | Erzähler | open_run_level | Attack the marsh cat to complete the cull contract | fish-drying stakes on the riverbank south of Alderwatch | 139/156 | 18.9 s |
| 138 | I move toward the reed stand to close to MEDIUM range, then cast Arcane Bolt at the marsh cat. | Erzähler | open_run_level | Engage the marsh cat at castable range | fish-drying stakes on the riverbank south of Alderwatch | 139/147 | 20.0 s |
| 139 | I gather the pelt, claws and fang from the marsh cat, thank the fisherman for his word to the Guild, and head back north to the Guild hall i… | Erzähler | open_run_level | Collect loot and turn in the completed cull contract | Adventurers' Guild hall, Alderwatch | 139/147 | 53.5 s |
| 140 | I ask the clerk what Novice contracts are on the board for tomorrow. | Erzähler | open_run_level | Check board for next contract | Adventurers' Guild hall, Alderwatch | 139/147 | 16.7 s |
| 141 | I accept the Pale Ghouls cull contract, then ask the clerk where I can find a cheap bed for the night. | Erzähler | open_run_level | Take the ghoul contract, then lodge and rest | Adventurers' Guild hall, Alderwatch | 139/147 | 19.4 s |
| 142 | I head to the Wheatsheaf, take a room for eight copper, and sleep until morning. | Erzähler | open_run_level | Lodge and rest before the ghoul hunt | the Wheatsheaf | 139/147 | 23.1 s |
| 143 | I pay the innkeeper the eight copper for the room she offered, then go up and sleep until morning. | Erzähler | open_run_level | Book the confirmed room offer and actually sleep | the Wheatsheaf | 139/147 | 19.6 s |
| 144 | The coin is for tonight's bed — please book me the second-door room for tonight, then I go up and sleep until morning. | Erzähler | open_run_level | Book tonight's room with the already-paid coin and sleep | the Wheatsheaf | 139/147 | 17.3 s |
| 145 | I accept the offer: here are eight copper for the second-door room for tonight — I buy it, then go up and sleep until morning. | Erzähler | open_run_level | Book the room at the confirmed offer and sleep | the Wheatsheaf | 165/336 | 16.7 s |
| 146 | I head out to the Sunken Cart Lane and hunt the Pale Ghouls for the cull contract. | Erzähler | open_run_level | Travel to the ghoul hunting ground and start the active cull contract | sunken cart lane between Millbrook and the old toll bridge | 165/336 | 21.8 s |
| 147 | I follow the drag marks toward the broken bank by the ditch, staff ready, and search for the ghouls there. | Erzähler | open_run_level | Hunt Pale Ghouls for the active cull contract | broken bank by the ditch | 165/336 | 19.5 s |
| 148 | I attack the first Pale Ghoul that emerges from the hollow with Arcane Bolt. | Engine (Menü/Rückfrage) | open_run_level | Engage the ghoul in the dug-out hollow | broken bank by the ditch | 165/336 | 5.0 s |
| 149 | I call out toward the hollow's mouth, baiting whatever is inside to come up: "Come out of there!" Staff raised, Arcane Bolt ready for whatev… | Erzähler | open_run_level | Draw the hidden ghoul out so it becomes a targetable enemy | broken bank by the ditch | 165/336 | 19.5 s |
| 150 | I cast Arcane Bolt at Pale Ghoul A. | Erzähler | open_run_level | Attack the now-targetable ghoul | broken bank by the ditch | 97/327 | 18.5 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 2 (notiert vor Zug 3): Character creation complete: Level 1 Mage with Arcane Bolt and Arcane Ward, 5 silver.
- zu Zug 21 (notiert vor Zug 22): Level 2 confirmed with 5 free points; boar contract at 1/4, the two remaining boars withdrew deeper into the reed bed.
- zu Zug 27 (notiert vor Zug 28): Big boar C is guarding the carcass and searching the reed line methodically; fighting it now with MP 36 seems risky, so I withdraw and may return after rest.
- zu Zug 33 (notiert vor Zug 34): MP still 36 after the hour rest—no mana recovery was confirmed; may need to check recovery or fight carefully.
- zu Zug 34 (notiert vor Zug 35): MP only 36/168 despite the hour's rest—rest at the hut did not restore mana.
- zu Zug 36 (notiert vor Zug 37): Ward burst on the second tusk; MP only 26, so limited to two more Bolts or wards—may need to retreat or finish with basic attacks after mana runs out.
- zu Zug 39 (notiert vor Zug 40): Old Man was a bonus kill, not counted in the 3/4 boar contract; XP 298/300, nearly level 4.
- zu Zug 45 (notiert vor Zug 46): Narration mentions the Old Man charging, but HUD shows only Gray Reed-Bed Boar A present; trusting the HUD.
- zu Zug 49 (notiert vor Zug 50): Stat assignment confirmed (INT 18, WIL 17), but HP is still 65/115 wounded — recovery needed before the next fight.
- zu Zug 51 (notiert vor Zug 52): Level 5 confirmed; HP still wounded (65/120) — should get healing at the Temple before the next fight.
- zu Zug 54 (notiert vor Zug 55): Narrator described full healing, but HUD still shows wounded at 65/135 after the purchase — checking status once.
- zu Zug 55 (notiert vor Zug 56): Healing rite purchase confirmed but HP remains 65/135 with no active effects — wound healed narratively yet HP unchanged; asking the healer once before moving on.
- zu Zug 56 (notiert vor Zug 57): Healer explains low HP is blood loss plus rite drain; recovery via meals and sleep, not another rite.
- zu Zug 67 (notiert vor Zug 68): HUD journal mentions an 'Old Man' boar charging, but the newest narration shows only the gutting woman present and no attack; the eel-weir HUD 'Here' signs seem from a different visit—trusting the newest narration.
- zu Zug 72 (notiert vor Zug 73): HUD quest counter shows 2/4 despite two kills this fight plus earlier progress; loot names differ slightly between engine result and HUD (Gray Reed-bed Boar Hide counts).
- zu Zug 73 (notiert vor Zug 74): HUD quest counter still reads 2/4 despite engine confirming four boar defeats total; may only count toward this contract's specific targets.
- zu Zug 75 (notiert vor Zug 76): Giant boar is a LONG-range engagement my P1 Arcane Bolt cannot reach; cull counter still 2/4, so I'll seek normal boars near the weirs.
- zu Zug 79 (notiert vor Zug 80): Cull counter reads 3/4; the giant boar defeat did not count. Something large still breathes in the reed stand north of the pool.
- zu Zug 88 (notiert vor Zug 89): Coin payout already confirmed by engine despite clerk's second stamping; wound needs healing soon.
- zu Zug 92 (notiert vor Zug 93): System misread 'three silver thirteen' as 43 cp; Hesk's bid is 73 cp — clarifying explicitly.
- zu Zug 93 (notiert vor Zug 94): Engine confirmed +73 cp (290 total) but HUD still shows 2 Gold 9 Silver — coin display contradiction; trusting engine count.
- zu Zug 96 (notiert vor Zug 97): Maren's healing didn't restore HP (still 62/155, wounded), so planning a night's rest before the hunt.
- zu Zug 98 (notiert vor Zug 99): HUD still shows Day 3 16:16 and HP 62/155 despite sleep narration — treating sleep as not yet engine-confirmed and repeating it explicitly.
- zu Zug 99 (notiert vor Zug 100): Engine confirmed the room purchase (-9 cp) and narrated a full night's sleep, yet HUD still shows Day 3 16:41 and HP 62/155 — sleep still not engine-confirmed.
- zu Zug 100 (notiert vor Zug 101): Sleep recovery confirmed: HP/MP full. Note: HUD shows 0/1 defeated despite carrying pelts/claws/fangs from earlier kills.
- zu Zug 101 (notiert vor Zug 102): Contract shows 0/1 defeated despite carrying pelts/claws/fangs from earlier kills — the contract may require kills made under it, or an unconfirmed count.
- zu Zug 105 (notiert vor Zug 106): Contract now shows 1/1 defeated after the kill under it, confirming earlier kills didn't count. Loot pelt/claws only — no fangs dropped this time.
- zu Zug 115 (notiert vor Zug 116): Contract shows 1/4 defeated despite HUD earlier; boar hide and tusk loot confirmed.
- zu Zug 123 (notiert vor Zug 124): Narrator said four boars done, but the quest panel reads 3/4 — trusting the panel.
- zu Zug 124 (notiert vor Zug 125): Engine refused a fourth hunt earlier as 'arrival pending' though I was already at the wallow; narrator again claims four boars done while panel reads 3/4 — still trusting the panel.
- zu Zug 125 (notiert vor Zug 126): System says no targetable boar in scene despite narrator claiming four done; quest panel still 3/4 — the 'something big' in the heavy reed stand is likely the Old Man, which I'm avoiding.
- zu Zug 130 (notiert vor Zug 131): Boar I defeated; contract count now confirmed 4/4. Something big still lurks in the reed stand — left alone deliberately.
- zu Zug 142 (notiert vor Zug 143): Engine refused the prior sleep as 'arrival pending' and did not book the room even though narration showed the night passing; HUD still shows Day 4, 21:46.
- zu Zug 143 (notiert vor Zug 144): Engine booked the -8 payment but sleep was refused as 'room not booked'; the widow says I paid twice for one bed. Possible double-charge to watch in #audit.
- zu Zug 144 (notiert vor Zug 145): Engine required an explicit purchase acceptance at the stated price; previous payments were double-charged despite booking refusals — check #audit after.
- zu Zug 145 (notiert vor Zug 146): Room finally booked only via explicit purchase acceptance; two extra 8cp charges likely from earlier attempts — worth #audit later. Fully rested, Day 5, ghoul contract active 0/3.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t11 | 11 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t19 | 19 | 1 | – | nein | 1 | gewonnen, 124 XP |
| enc.t24 | 25 | 1 | – | nein | 1 | gewonnen, 180 XP |
| enc.t34 | 36 | 1 | – | nein | 1 | gewonnen, 224 XP |
| enc.t44 | 46 | 1 | – | nein | 1 | gewonnen, 154 XP |
| enc.t55 | 60 | 1 | – | nein | 1 | gewonnen, 30 XP |
| enc.t64 | 69 | 2 | – | nein | 2 | gewonnen, 204 XP |
| enc.t71r | 76 | 1 | – | nein | 1 | gewonnen, 154 XP |
| enc.t77r | 83 | 1 | – | nein | 1 | gewonnen, 152 XP |
| enc.t96 | 105 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t104 | 113 | 1 | – | nein | 1 | gewonnen, 180 XP |
| enc.t108 | 118 | 1 | – | nein | 1 | gewonnen, 124 XP |
| enc.t112 | 122 | 1 | – | nein | 1 | gewonnen, 224 XP |
| enc.t118 | 129 | 1 | – | nein | 1 | gewonnen, 180 XP |
| enc.t126 | 138 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t137 | 150 | 1 | – | nein | – | offen |

## Quests

- **Cull the Lone Marsh Cat at the Alderwatch Fishing Stakes** — active (Zug 6) → completed (Zug 12), READY
  - Aufgabe: Kill 1 marsh cat at fish-drying stakes on the riverbank south of Alderwatch. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 marsh cat killed at fish-drying stakes on the riverbank south of Alderwatch.
- **Thin the Reed Flats Boar Sounder** — active (Zug 14) → completed (Zug 50)
  - Aufgabe: Kill 4 reed-bed boars at eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 reed-bed boars killed at eel-weirs of the Reed Flats.
- **Cull the Gloomcap Ghouls of the Sunken Lane** — expired (Zug 52)
  - Aufgabe: Kill 3 pale ghouls at sunken cart lane between Millbrook and the old toll bridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 pale ghouls killed at sunken cart lane between Millbrook and the old toll bridge.
- **Slay the Antlered Marsh Terror of Lake Vane** — expired (Zug 52)
  - Aufgabe: Kill 1 antlered armored beast at north shore of Lake Vane. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 antlered armored beast killed at north shore of Lake Vane.
- **Clear the Old Crown Catacombs, Level 1** — expired (Zug 52), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of Old Crown Catacombs. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Old Crown Catacombs is clear.
- **Cull the Marsh Cat at the Fish-Drying Stakes** — active (Zug 53) → completed (Zug 62)
  - Aufgabe: Kill 1 marsh cat at fish-drying stakes on the riverbank south of Alderwatch. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 marsh cat killed at fish-drying stakes on the riverbank south of Alderwatch.
- **Cull the Reed-Bed Boars at the Eel-Weirs** — active (Zug 64) → completed (Zug 87)
  - Aufgabe: Kill 4 reed-bed boar at eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 reed-bed boar killed at eel-weirs of the Reed Flats.
- **Cull the Pale Ghouls of the Sunken Cart Lane** — expired (Zug 88)
  - Aufgabe: Kill 3 pale ghoul at sunken cart lane between Millbrook and the old toll bridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 pale ghoul killed at sunken cart lane between Millbrook and the old toll bridge.
- **Cull the Antlered Armored Beast of Lake Vane** — expired (Zug 88)
  - Aufgabe: Kill 1 antlered armored beast at north shore of Lake Vane. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 antlered armored beast killed at north shore of Lake Vane.
- **Clear the Old Crown Catacombs, Level 1** — expired (Zug 88), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of Old Crown Catacombs. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Old Crown Catacombs is clear.
- **Cull the Marsh Cat at the Fish-Drying Stakes** — active (Zug 89) → completed (Zug 107)
  - Aufgabe: Kill 1 marsh cat at fish-drying stakes on the riverbank south of Alderwatch. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 marsh cat killed at fish-drying stakes on the riverbank south of Alderwatch.
- **Cull Reed-Bed Boars at the Eel-Weirs** — expired (Zug 108)
  - Aufgabe: Kill 3 reed-bed boar at eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 reed-bed boar killed at eel-weirs of the Reed Flats.
- **Cull the Pale Ghouls on the Sunken Cart Lane** — expired (Zug 108)
  - Aufgabe: Kill 4 pale ghoul at sunken cart lane between Millbrook and the old toll bridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 pale ghoul killed at sunken cart lane between Millbrook and the old toll bridge.
- **Cull the Antlered Armored Beast of Lake Vane** — expired (Zug 108)
  - Aufgabe: Kill 1 antlered armored beast at north shore of Lake Vane. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 antlered armored beast killed at north shore of Lake Vane.
- **Clear Old Crown Catacombs, Level 1** — expired (Zug 108), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of Old Crown Catacombs. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Old Crown Catacombs is clear.
- **Cull the Marsh Cat at the Fish-Drying Stakes** — active (Zug 134) → completed (Zug 139)
  - Aufgabe: Kill 1 marsh cat at fish-drying stakes on the riverbank south of Alderwatch. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 marsh cat killed at fish-drying stakes on the riverbank south of Alderwatch.
- **Cull the Reed-Bed Boars at the Eel-Weirs** — active (Zug 109) → completed (Zug 131)
  - Aufgabe: Kill 4 reed-bed boar at eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 reed-bed boar killed at eel-weirs of the Reed Flats.
- **Cull the Pale Ghouls on the Sunken Cart Lane** — active (Zug 141)
  - Aufgabe: Kill 3 pale ghoul at sunken cart lane between Millbrook and the old toll bridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 pale ghoul killed at sunken cart lane between Millbrook and the old toll bridge.

## Auffälligkeiten

- Zug 16, Nachricht 32 (extraction_repaired): the extractor's first answer needed a repair
- Zug 16, Nachricht 32 (extractor_recovery): the extractor required empty recovery (status applied)
- Zug 16, Nachricht 32 (finish): extract ended with finish_reason "length"
- Zug 40, Nachricht 80 (extraction_repaired): the extractor's first answer needed a repair
- Zug 41, Nachricht 82 (extraction_repaired): the extractor's first answer needed a repair
- Zug 42, Nachricht 84 (extraction_repaired): the extractor's first answer needed a repair
- Zug 53, Nachricht 106 (extraction_repaired): the extractor's first answer needed a repair
- Zug 68, Nachricht 136 (extraction_repaired): the extractor's first answer needed a repair
- Zug 87, Nachricht 173 (planner_repaired): the planner's first answer needed a repair
- Zug 87, Nachricht 173 (finish): plan ended with finish_reason "length"
- Zug 91, Nachricht 181 (planner_repaired): the planner's first answer needed a repair
- Zug 92, Nachricht 183 (planner_repaired): the planner's first answer needed a repair
- Zug 95, Nachricht 190 (extraction_repaired): the extractor's first answer needed a repair
- Zug 96, Nachricht 192 (extraction_repaired): the extractor's first answer needed a repair
- Zug 102, Nachricht 204 (extraction_repaired): the extractor's first answer needed a repair
- Zug 107, Nachricht 214 (extraction_repaired): the extractor's first answer needed a repair
- Zug 109, Nachricht 218 (extraction_repaired): the extractor's first answer needed a repair
- Zug 111, Nachricht 221 (planner_repaired): the planner's first answer needed a repair
- Zug 111, Nachricht 222 (extraction_repaired): the extractor's first answer needed a repair
- Zug 135, Nachricht 270 (extraction_repaired): the extractor's first answer needed a repair
- Zug 139, Nachricht 278 (extraction_repaired): the extractor's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 22× keine gültige JSON-Entscheidung (Züge 8, 9, 10, 11, 16, 17, 18, 31, 33, 39, 42, 47, 49, 59, 73, 83, 103, 115, 128, 136, 138, 147)
- 2 Aufruf(e) mit finish_reason "length" (Nr. 43 extract, Nr. 241 plan)

System-Panels: CLARIFY 2, NOT TAKEN 3, REFUSED 1, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: ambient 2, guild_payout 3, engine_owned_memory 2, attack_commitment 7, world_rule 17, engine_owned 1, quest_count 3, engine_owned_fact 8, pc_inventory 1, guild_completion 2, no_go 1, scene_context 4, time_cap 2, offer 3, sale_evidence 3, engine_recovery 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 1, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 22/150 Erstantworten ungültig (14.7 %); 22 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 144 | 4 | 2.4 s | 5.0 s | 12021 | 9980 | 75 | – | stop 143, length 1 | 1 |
| board | 4 | 0 | 9.0 s | 9.9 s | 2460 | 2154 | 965 | – | stop 4 | 0 |
| narrator | 135 | 0 | 8.4 s | 12.6 s | 11425 | 8850 | 374 | – | stop 135 | 0 |
| extract | 149 | 13 | 5.3 s | 9.2 s | 12335 | 9437 | 302 | – | stop 148, length 1 | 1 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 64:12 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 15.7 s) | 0:30 min |
| 150 Züge, Spiel (Senden bis HUD nach der Extraktion) | 52:30 min — Median 19.7 s, p90 32.6 s, max 81.7 s |
| 150 Züge, Spieler-Entscheidung | 8:16 min — Median 2.4 s, 22 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 7:49 min / 0:36 min / 22:04 min / 15:55 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 24.3 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 16:12 min, 80 Züge ≈ 32:24 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spiel | 56 | – | 81.7 s | 19.7 s |
| Provider narrator | 56 | 153 | 72.0 s | 8.4 s |
| Provider extract | 16 | 43 | 40.1 s | 5.3 s |
| Provider extract | 107 | 306 | 39.8 s | 5.3 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
