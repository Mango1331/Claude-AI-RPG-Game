# Avereth – 3 natürliche Testkampagnen

Status: **interrupted**. Serie abgeschlossen bedeutet, dass die Läufe beendet sind; es bedeutet nicht 3 bestandene Level-15-Abnahmen.

| Nr. | Profil | Seed | Eingaben | Level | Ende | Originalbericht |
|---|---|---:|---:|---:|---|---|
| 1 | guild-warrior | 1846470028 | 80 | 6 | defeat | [report.md](001-guild-warrior/20261028-111133Z-current_test/report.md) |
| 2 | guild-mage | 1846470029 | 150 | 8 | limit | [report.md](002-guild-mage/20261028-114620Z-current_test/report.md) |
| 3 | guild-rogue | 1846470030 | 0 | – | process_error | [report.md](003-guild-rogue/20261028-125039Z-current_test/report.md) |

