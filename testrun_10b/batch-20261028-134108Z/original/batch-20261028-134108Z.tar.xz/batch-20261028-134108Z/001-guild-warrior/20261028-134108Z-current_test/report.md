# Avereth Live-Test 20261028-134108Z-current_test

## Kurzfassung

- **Laufprofil:** guild-warrior; Startklasse Warrior, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** abgebrochen: unerwarteter UI-Zustand — turn 22: no reply after the message
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 1. Sicherheitsgrenzen: 150 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** noch nicht erreicht.
- **Charakter:** warrior (warrior.heavy_slash, warrior.guard) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: cautious adventurer: prepare and recover, weigh threats and withdraw when sensible
- **Züge:** 22 · **Dauer:** 10:20 min · **LLM-Aufrufe der Engine/des Erzählers:** 61
- **Beobachtete Abdeckung:** 5 unterschiedliche gebuchte Reiseziele · 1 Kämpfe · 1 Verkäufe (4 cp Umsatz, ohne Questzahlungen/Geschenke) · 0 Ausrüstungswechsel · 0 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 5
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.113 |
| Git | 55c547f47701 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 61.3 s |
| Browser | chrome 156.0.8078.48 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261028-134108Z-current_test“, Seed 1361220374 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | I choose Warrior. | Engine (Menü/Rückfrage) | creation_complete | Select Warrior as base class | public roadside verge outside Glassmere | 90/84 | 2.3 s |
| 2 | I choose Heavy Slash and Guard. | Engine (Menü/Rückfrage) | creation_complete | Select two Warrior starter skills | public roadside verge outside Glassmere | 95/84 | 2.2 s |
| 3 | I walk to Glassmere and head to the Guild hall to look at the contract board. | Erzähler | open_run_level | Find a first Guild contract | Adventurers' Guild hall, Glassmere | 95/84 | 37.7 s |
| 4 | I ask the clerk how I register with the Guild as an adventurer. | Erzähler | open_run_level | Register with the Guild | Adventurers' Guild hall, Glassmere | 95/84 | 17.1 s |
| 5 | I pay the two silver fee and ask the clerk to register me under the name Alaric Red. | Erzähler | open_run_level | Register with the Guild | Adventurers' Guild hall, Glassmere | 95/84 | 19.0 s |
| 6 | I buy a cup of tea and wait at the hearth until the midday bell, then go to the contract board to read the new postings. | Erzähler | open_run_level | Wait for postings, then take a first contract | Adventurers' Guild hall, Glassmere | 95/84 | 31.9 s |
| 7 | I tell the crossbow woman, "First day, yes. I'm Alaric." Then I take the feral dog contract slip from the board and ask the clerk to accept … | Erzähler | open_run_level | Take the level-1 feral dog contract | Adventurers' Guild hall, Glassmere | 95/84 | 19.4 s |
| 8 | I head to the Tannery Rows and look for a lone feral dog along the drainage paths. | Erzähler | open_run_level | Hunt the contracted feral dog | the Tannery Rows of Glassmere | 95/84 | 21.0 s |
| 9 | I walk past the third sluice toward the scrap pit and look for the big brindled feral dog. | Erzähler | open_run_level | Find the contracted feral dog | the scrap pit past the third sluice | 95/84 | 28.8 s |
| 10 | I draw my longsword and close to attack the big brindled feral dog at the scrap pit. | Erzähler | open_run_level | Fight the contracted feral dog | the scrap pit past the third sluice | 92/84 | 20.5 s |
| 11 | I use Basic Attack on the feral dog. | Erzähler | open_run_level | Attack the contracted feral dog | the scrap pit past the third sluice | 89/84 | 14.8 s |
| 12 | I finish it with another Basic Attack on the feral dog. | Erzähler | open_run_level | Kill the contracted feral dog | the scrap pit past the third sluice | 89/84 | 14.5 s |
| 13 | The slip shows READY with 1/1 defeated, so I head back to the Guild hall and ask the clerk to turn in the feral dog contract for my reward. | Erzähler | open_run_level | Turn in the completed dog contract | Adventurers' Guild hall, Glassmere | 89/84 | 16.6 s |
| 14 | I sell the feral dog pelt and fang to the Guild, then ask the clerk what novice contracts are on the board. | Erzähler | open_run_level | Sell loot and pick a new contract | Adventurers' Guild hall, Glassmere | 89/84 | 16.5 s |
| 15 | I accept the six copper for the pelt and fang, then ask the clerk to take the bog strider contract—four striders at the Reed Flats. | Engine (Menü/Rückfrage) | open_run_level | Sell loot and accept the bog strider contract | Adventurers' Guild hall, Glassmere | 89/84 | 5.2 s |
| 16 | I accept 4 copper for the pelt and fang, then ask the clerk to take the bog strider contract—four striders at the Reed Flats. | Erzähler | open_run_level | Sell loot at corrected price and accept the bog strider contract | Adventurers' Guild hall, Glassmere | 89/84 | 16.5 s |
| 17 | I take the slip and head out the east gate, following the eel-cart ruts toward the Reed Flats weirs. | Erzähler | open_run_level | Travel to the bog strider hunting grounds | the eel-weirs of the Reed Flats | 89/84 | 23.4 s |
| 18 | I ask the keeper where she last saw the striders, and whether the shallow water near the cut line is passable if I stay on the stumps. | Erzähler | open_run_level | Gather intel before hunting bog striders | the eel-weirs of the Reed Flats | 89/84 | 23.2 s |
| 19 | I take the keeper up on the bench inside the hut and sit out the afternoon, keeping watch on the shallows for the striders. | Erzähler | open_run_level | Wait for dusk when striders hunt the shallows | the eel-weirs of the Reed Flats | 89/84 | 26.5 s |
| 20 | I draw my longsword, step onto the weir rack for dry footing, and hit the small bog strider at the cut line with Heavy Slash. | Erzähler | open_run_level | Attack the first bog strider from dry footing | the eel-weirs of the Reed Flats | 89/84 | 19.5 s |
| 21 | I hold my ground on the rack with my longsword ready, watching the dark channel below for the strider's approach, and wait for it to come wi… | Erzähler | open_run_level | Wait for the strider to close into engagement range before attacking | the eel-weirs of the Reed Flats | 89/84 | 21.6 s |
| 22 | I strike the strider's exposed head at the third rack post with Heavy Slash. | – | open_run_level | Attack Bog Strider A now that it is within reach | the eel-weirs of the Reed Flats | 89/84 | 48.3 s **no reply after the message** |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 3 (notiert vor Zug 4): Contract board is empty until midday bell; not yet Guild-registered.
- zu Zug 6 (notiert vor Zug 7): Coin shows 2 Silver 8 Copper in HUD vs 28 copper after tea purchase — consistent, fine.
- zu Zug 14 (notiert vor Zug 15): Sale offer (6 cp) not yet confirmed in engine result; must verify acceptance.
- zu Zug 19 (notiert vor Zug 20): HUD says 17:20 while narration describes dusk; combat panel shows Bog Strider A at 38 HP.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t10r | 10 | 1 | – | nein | 1 | gewonnen, 30 XP |

## Quests

- **Cull the Feral Dogs at the Tannery Rows** — active (Zug 7) → completed (Zug 13)
  - Aufgabe: Kill 1 feral dog at the Tannery Rows of Glassmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 feral dog killed at the Tannery Rows of Glassmere.
- **Thin the Reed Flats Bog Striders** — active (Zug 16)
  - Aufgabe: Kill 4 bog striders at the eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 bog striders killed at the eel-weirs of the Reed Flats.

## Auffälligkeiten

- Zug 22 (Runner/UI): no reply after the message
- Zug 3, Nachricht 5 (board_failed): the board generator failed
- Zug 10, Nachricht 19 (planner_repaired): the planner's first answer needed a repair
- Seitenfehler: Too Many Requests     at sendOpenAIRequest (http://127.0.0.1:8123/scripts/openai.js:3199:19)     at async sendGenerationRequest (http://127.0.0.1:8123/script.js:6118:16)
- Hinweis (error): API returned an errorToo Many Requests
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 4× keine gültige JSON-Entscheidung (Züge 9, 10, 19, 21)
- Server: Chat completion request error:  Too Many Requests {"error":{"message":"Your current plan only allows you to switch models 100 times per minute. Please try again later or upgrade your plan to increase this limit.","type":"rate_limit_error","param":null,"code":"model_switching_limit_exceeded"}}

System-Panels: CLARIFY 1, NOT TAKEN 0, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: guild_canon 3, engine_owned_fact 1, scene_context 4, world_rule 1, guild_payout 1, time_cap 1, attack_commitment 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 4/22 Erstantworten ungültig (18.2 %); 4 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 21 | 1 | 2.6 s | 3.4 s | 11622 | 9890 | 95 | – | stop 21 | 0 |
| board | 3 | 1 | 11.2 s | 11.7 s | 2359 | 2359 | 1126 | – | stop 3 | 0 |
| narrator | 19 | 0 | 9.1 s | 11.8 s | 11583 | 0 | 399 | – | stop 18 | 0 |
| extract | 18 | 0 | 4.8 s | 8.3 s | 11670 | 9323 | 346 | – | stop 18 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 10:20 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 61.3 s) | 1:21 min |
| 22 Züge, Spiel (Senden bis HUD nach der Extraktion) | 7:27 min — Median 19.5 s, p90 31.9 s, max 48.3 s |
| 22 Züge, Spieler-Entscheidung | 1:15 min — Median 2.3 s, 4 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 1:01 min / 0:31 min / 2:53 min / 1:37 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 23.7 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 15:49 min, 80 Züge ≈ 31:37 min (ohne Einrichtung) |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
