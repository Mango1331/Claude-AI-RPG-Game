# Avereth – 3 natürliche Testkampagnen

Status: **interrupted**. Serie abgeschlossen bedeutet, dass die Läufe beendet sind; es bedeutet nicht 3 bestandene Level-15-Abnahmen.

| Nr. | Profil | Seed | Eingaben | Level | Ende | Originalbericht |
|---|---|---:|---:|---:|---|---|
| 1 | guild-warrior | 1361220374 | 22 | 1 | ui | [report.md](001-guild-warrior/20261028-134108Z-current_test/report.md) |
| 2 | guild-mage | 1361220375 | 0 | – | process_error | [report.md](002-guild-mage/20261028-135130Z-current_test/report.md) |
| 3 | guild-rogue | 1361220376 | – | – | pending | – |

