# Avereth Live-Test 20261028-140432Z-current_test

## Kurzfassung

- **Laufprofil:** guild-warrior; Startklasse Warrior, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** abgebrochen: Limit erreicht — 150 turns
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 9. Sicherheitsgrenzen: 150 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** Level 6, 432 XP seit Levelaufstieg, 199 cp, HP 205, MP 92; Ort realm.caelreth.the_cinder_orchards_hills_south_of_glassmere. Ausrüstung und Skills stehen in evaluation.json → progression.checkpoint.
- **Charakter:** warrior (warrior.heavy_slash, warrior.guard) · Regelstand 2 (Warrior, Mage, Rogue)
- **Ziel-Dungeon:** Glimmerdeep Grotto, Ebene 1 (Vertrag quest.clear_glimmerdeep_grotto_level_1_2)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: pragmatic adventurer: sell surplus loot and invest in useful equipment and techniques
- **Züge:** 150 · **Dauer:** 61:17 min · **LLM-Aufrufe der Engine/des Erzählers:** 426
- **Beobachtete Abdeckung:** 21 unterschiedliche gebuchte Reiseziele · 14 Kämpfe · 1 Verkäufe (11 cp Umsatz, ohne Questzahlungen/Geschenke) · 0 Ausrüstungswechsel · 2 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 15
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.113 |
| Git | 55c547f47701 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 17.4 s |
| Browser | chrome 156.0.8078.48 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261028-140432Z-current_test“, Seed 2053701138 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | I choose Warrior. | Engine (Menü/Rückfrage) | creation_complete | Select Warrior class | public roadside verge outside Glassmere | 90/84 | 2.3 s |
| 2 | I choose Heavy Slash and Guard. | Engine (Menü/Rückfrage) | creation_complete | Finish character creation with two chosen skills | public roadside verge outside Glassmere | 95/84 | 2.1 s |
| 3 | I walk toward the city of Glassmere and head to the Adventurers' Guild hall to register and look at the contract board. | Erzähler | creation_complete | Enter Glassmere and reach the Guild to take contracts | Adventurers' Guild hall, Glassmere | 95/84 | 44.1 s |
| 4 | I pay the clerk two silver to register with the Guild, then ask to accept the feral dog cull contract at Tannery Row. | Erzähler | open_run_level | Register with the Guild and take the achievable five-dog contract | Adventurers' Guild hall, Glassmere | 95/84 | 16.7 s |
| 5 | I take the slip and head east through the city to the abandoned tanning pits at Tannery Row to hunt the feral dogs. | Erzähler | open_run_level | Travel to Tannery Row and start the dog cull | Tannery Row, Glassmere outskirts | 95/84 | 21.8 s |
| 6 | I draw my sword and charge Feral Dog A, attacking with Heavy Slash. | Erzähler | open_run_level | Engage the two visible dogs, starting with the one facing me | Tannery Row, Glassmere outskirts | 95/84 | 18.3 s |
| 7 | I move up to Feral Dog A and attack with Heavy Slash. | Erzähler | open_run_level | Close to ENGAGED range and strike the first dog | Tannery Row, Glassmere outskirts | 59/84 | 19.3 s |
| 8 | I finish Feral Dog A with another Heavy Slash. | Erzähler | open_run_level | Kill the wounded dog first | Tannery Row, Glassmere outskirts | 52/84 | 15.1 s |
| 9 | I strike Feral Dog B with Heavy Slash. | Erzähler | open_run_level | Finish the second dog before reinforcements arrive | Tannery Row, Glassmere outskirts | 45/84 | 14.8 s |
| 10 | I finish Feral Dog B with a Basic Attack. | Erzähler | open_run_level | Kill the last dog for the cull count | Tannery Row, Glassmere outskirts | 45/84 | 16.1 s |
| 11 | #assign VIT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up stat points | Tannery Row, Glassmere outskirts | 45/84 | 2.1 s |
| 12 | I search the tannery shed for a safe spot to rest and bandage my wounds before hunting the remaining three dogs. | Erzähler | open_run_level | Recover HP before continuing the cull | Tannery Row, Glassmere outskirts | 45/84 | 16.9 s |
| 13 | I rest in the corner by the fallen beam for 2 hours, keeping watch on the door. | Erzähler | open_run_level | Recover HP before hunting the remaining dogs | Tannery Row, Glassmere outskirts | 69/92 | 17.3 s |
| 14 | I head out into the sunken pits to hunt the remaining three feral dogs, keeping low between the rims. | Erzähler | open_run_level | Continue the dog cull contract | the sunken tanning pits | 69/92 | 25.1 s |
| 15 | I charge the two feeding dogs in the big pit, opening with Heavy Slash on Dog D. | Erzähler | open_run_level | Attack the pack for the cull | the sunken tanning pits | 69/92 | 22.0 s |
| 16 | I declare a charge: I move across the crust to close with Dog D and attack it with Heavy Slash once in range. | Erzähler | open_run_level | Close distance properly, then strike | the sunken tanning pits | 69/92 | 18.6 s |
| 17 | I draw back behind the tanning frame, out of the scarred dog's line of sight, and wait quietly for one of the feeding dogs to stray up the p… | Erzähler | open_run_level | Ambush a dog at closer range instead of charging across open ground | the sunken tanning pits | 69/92 | 19.1 s |
| 18 | I brace behind the tanning frame and attack the climbing gray dog with Heavy Slash the moment it comes within reach of the rim. | Erzähler | open_run_level | Fight the dogs one at a time as they come up | the sunken tanning pits | 69/92 | 14.8 s |
| 19 | I step toward the gray dog braced at the rim and strike it with Heavy Slash, closing into blade reach first. | Erzähler | open_run_level | Close the last stride and attack Dog C | the sunken tanning pits | 56/92 | 20.2 s |
| 20 | I finish the crippled dog with a Basic Attack, then turn to face the scarred one closing along the basin floor. | Erzähler | open_run_level | Kill Dog C and prepare for Dog E | the sunken tanning pits | 56/92 | 19.1 s |
| 21 | I assign 2 points to VIT and 3 to AGI, then keep hunting the remaining two dogs toward the pit country where the scarred one fled. | Erzähler | open_run_level | Spend level-up points and continue the cull | the spine between the diggings | 56/92 | 22.4 s |
| 22 | #assign VIT 2 AGI 3 | System (Befehl) | open_run_level | Spend free stat points | the spine between the diggings | 56/92 | 2.2 s |
| 23 | I move forward into the hollow and attack Feral Dog D with Heavy Slash. | Erzähler | open_run_level | Continue the dog cull at the den | the spine between the diggings | 56/92 | 18.5 s |
| 24 | I back away off the spine and retreat from the hollow, keeping my blade between me and the big dog, toward the tannery row. | Erzähler | open_run_level | Disengage from the pack den to recover before fighting on | Tannery Row, Glassmere outskirts | 56/92 | 29.7 s |
| 25 | I close on the young gray dog at the shed threshold and attack it with Basic Attack. | Erzähler | open_run_level | Kill dog 4 of 5 toward the cull | Tannery Row, Glassmere outskirts | 50/92 | 18.1 s |
| 26 | I finish Feral Dog D with a Basic Attack before it can lunge. | Erzähler | open_run_level | Kill dog 4 of 5 for the cull | Tannery Row, Glassmere outskirts | 50/92 | 33.3 s |
| 27 | I take cover behind a brick pit wall, recover, and watch for a fifth dog to finish the cull. | Erzähler | open_run_level | Recover then hunt the fifth dog | Tannery Row, Glassmere outskirts | 50/92 | 17.8 s |
| 28 | I rest behind the wall until evening fully sets, then engage Feral Dog F with Heavy Slash. | Erzähler | open_run_level | Recover briefly, then kill the fifth dog for the cull | Tannery Row, Glassmere outskirts | 50/92 | 16.5 s |
| 29 | I move toward Feral Dog F to close the distance, then attack her with Heavy Slash. | Erzähler | open_run_level | Close on and kill the fifth dog for the cull | Tannery Row, Glassmere outskirts | 50/92 | 20.5 s |
| 30 | I charge straight at Feral Dog F, close to engaged range, and swing Heavy Slash at her. | Erzähler | open_run_level | Close into engaged range and kill the fifth dog for the cull | Tannery Row, Glassmere outskirts | 50/92 | 14.9 s |
| 31 | I swing Heavy Slash at Feral Dog F, now at SHORT range. | Erzähler | open_run_level | Kill the fifth dog for the cull | Tannery Row, Glassmere outskirts | 50/92 | 16.8 s |
| 32 | I step the last sword-length into engaged range with Feral Dog F and strike her with Basic Attack. | Erzähler | open_run_level | Close to ENGAGED and kill the fifth dog for the cull | Tannery Row, Glassmere outskirts | 31/92 | 18.0 s |
| 33 | I finish Feral Dog F with Basic Attack, then immediately Guard against the other two dogs. | Erzähler | open_run_level | Kill the fifth dog and defend against the flanking pair | Tannery Row, Glassmere outskirts | 31/92 | 15.5 s |
| 34 | I back away slowly toward the town side of the row, sword up in Guard, and disengage from the two remaining dogs. | Erzähler | open_run_level | Break contact at 31/140 HP with the cull count already complete | Tannery Row, Glassmere outskirts | 31/92 | 31.0 s |
| 35 | I walk back into Glassmere and head straight for the Guild hall to turn in the completed dog-cull contract. | Erzähler | open_run_level | Turn in the 5/5 cull and get healed/recover | Adventurers' Guild hall, Glassmere | 31/92 | 20.2 s |
| 36 | #assign VIT 3 STR 2 | System (Befehl) | open_run_level | Spend level-up points for survivability | Adventurers' Guild hall, Glassmere | 31/92 | 2.2 s |
| 37 | I ask the clerk where the surgeon is, then head two streets up to have my leg wound washed and stitched. | Erzähler | open_run_level | Get treatment for the leg wound at the surgeon | Merrin's surgeon house | 31/92 | 21.9 s |
| 38 | I take the good salve and pay her the three copper. | Erzähler | open_run_level | Buy the good salve treatment | Merrin's surgeon house | 31/92 | 21.0 s |
| 39 | I head to the Guild hall to turn in the five dog pelts and fangs for the cull contract payment. | Erzähler | open_run_level | Turn in the completed contract | Adventurers' Guild hall, Glassmere | 31/92 | 37.7 s |
| 40 | I go to Halloran's shop on Cordwainer Street toward the tannery end and ask what he'll pay for five dog pelts and thirteen fangs. | Erzähler | open_run_level | Sell surplus loot to the broker | Halloran's brokerage, Cordwainer Street | 31/92 | 20.8 s |
| 41 | I take the eleven copper for the lot. | Erzähler | open_run_level | Sell all pelts and fangs at the offered price | Halloran's brokerage, Cordwainer Street | 31/92 | 12.8 s |
| 42 | I look for an inn nearby with a room for the night, then take a bed and sleep until morning. | Erzähler | open_run_level | Recover overnight at an inn | The Goose | 31/92 | 19.4 s |
| 43 | I pay the three copper for the room and supper, then eat, wash, and sleep until morning. | Engine (Menü/Rückfrage) | open_run_level | Buy lodging and supper, then recover overnight | The Goose | 31/92 | 9.1 s |
| 44 | I buy the room for two copper and the supper for one copper from the innkeeper, three copper total, then eat, wash, and sleep until morning. | Erzähler | open_run_level | Buy lodging and supper, then recover overnight | The Goose | 165/92 | 19.6 s |
| 45 | I eat the included breakfast downstairs, then head to the Guild hall and ask for the contract board. | Erzähler | open_run_level | Recover done; pick a new Guild contract | Adventurers' Guild hall, Glassmere | 165/92 | 28.7 s |
| 46 | "I'd like to take the Feral Dogs cull on Tannery Row — four dogs for the tanners. Please mark it as mine." | Erzähler | open_run_level | Accept the dog cull contract | Adventurers' Guild hall, Glassmere | 165/92 | 16.8 s |
| 47 | I head out through the east tanners' gate to Tannery Row and look for the feral dogs in the scrap-pits behind the yards. | Erzähler | open_run_level | Travel to the contract site and hunt the dogs | Tannery Row, Glassmere outskirts | 165/92 | 17.3 s |
| 48 | I charge the two feral dogs holding at the lane's mouth and open with Heavy Slash on the closer one. | Engine (Menü/Rückfrage) | open_run_level | Attack the feral dogs | Tannery Row, Glassmere outskirts | 165/92 | 9.4 s |
| 49 | I approach the two deep-voiced dogs at the lane's mouth and attack the nearer one with Heavy Slash. | Engine (Menü/Rückfrage) | open_run_level | Engage the feral dogs for the cull contract | Tannery Row, Glassmere outskirts | 165/92 | 8.8 s |
| 50 | I walk through the broken fence into the scrap-pits and search the trenches for the feral dogs. | Erzähler | open_run_level | Find targetable dogs in the pits | the scrap-pits | 165/92 | 26.7 s |
| 51 | I meet the charging Feral Dog I and strike it with Heavy Slash. | Erzähler | open_run_level | Fight the four feral dogs for the cull contract | the scrap-pits | 158/92 | 19.5 s |
| 52 | I finish Feral Dog I with a Basic Attack. | Erzähler | open_run_level | Kill the wounded dog | the scrap-pits | 158/92 | 21.2 s |
| 53 | I cross the bank of rotting hide scraps and track the three fleeing dogs by their paw prints and the dragged offal smear, following them tow… | Erzähler | open_run_level | Track and hunt the remaining three dogs for the cull contract | the den bowl | 158/92 | 43.5 s |
| 54 | I charge the gray leader and open with Heavy Slash. | Erzähler | open_run_level | Fight the three remaining dogs at the den | the den bowl | 158/92 | 15.7 s |
| 55 | I rush the gray leader to close the distance, then strike it with Heavy Slash. | Erzähler | open_run_level | Close to ENGAGED range and attack | the den bowl | 158/92 | 17.2 s |
| 56 | I sprint the full twenty paces across the bowl to close to ENGAGED range with the gray leader; once in range, I strike it with Heavy Slash. | Engine (Menü/Rückfrage) | open_run_level | Close to ENGAGED range and attack the gray leader | the den bowl | 158/92 | 7.6 s |
| 57 | I sprint the full twenty paces across the bowl to close to ENGAGED range with Feral Dog M; once in range, I strike it with Heavy Slash. | Erzähler | open_run_level | Close with the gray leader and attack | the den bowl | 158/92 | 19.2 s |
| 58 | I close the distance to Feral Dog M until we are at ENGAGED range. | Erzähler | open_run_level | Close to melee range as a standalone movement action, then attack next turn | the den bowl | 158/92 | 17.4 s |
| 59 | I attack Feral Dog M with Heavy Slash. | Erzähler | open_run_level | Kill the gray leader now that it is in range | the den bowl | 158/92 | 12.5 s |
| 60 | I attack Feral Dog M with Basic Attack. | Erzähler | open_run_level | Kill the gray leader now that all three dogs are at SHORT, within Basic Attack reach | the den bowl | 158/92 | 13.0 s |
| 61 | I attack Feral Dog M with Heavy Slash. | Erzähler | open_run_level | All three dogs are now ENGAGED; kill the gray leader | the den bowl | 95/92 | 17.5 s |
| 62 | I attack Feral Dog M with Heavy Slash. | Erzähler | open_run_level | Finish off the crippled gray leader | the den bowl | 75/92 | 15.2 s |
| 63 | I attack Feral Dog N with Heavy Slash. | Erzähler | open_run_level | Finish the wounded dog with a Heavy Slash while both are in range | the den bowl | 57/92 | 13.9 s |
| 64 | I attack Feral Dog N with Basic Attack to finish it off. | Erzähler | open_run_level | Kill the crippled dog, saving STA | the den bowl | 48/92 | 15.3 s |
| 65 | I attack Feral Dog O with Basic Attack. | Erzähler | open_run_level | Kill the last unhurt dog with steady Basic Attacks to conserve STA | the den bowl | 38/92 | 15.1 s |
| 66 | I attack Feral Dog O with Basic Attack to finish it off. | Erzähler | open_run_level | Kill the last badly wounded dog with a Basic Attack | the den bowl | 38/92 | 18.6 s |
| 67 | #assign VIT 3 STR 2 | System (Befehl) | open_run_level | Spend the 5 level-up stat points on VIT and STR | the den bowl | 38/92 | 2.4 s |
| 68 | #passives | System (Befehl) | open_run_level | Accept the offered passive Grit of the Cornered Hound | the den bowl | 38/92 | 2.5 s |
| 69 | I accept the Grit of the Cornered Hound passive into a free slot. | Erzähler | open_run_level | Accept offered passive | the den bowl | 38/92 | 14.4 s |
| 70 | I climb out of the den bowl and head back toward Tannery Row to turn in the dog cull contract at the Guild hall. | Erzähler | open_run_level | Travel back and turn in the completed contract | Tannery Row, Glassmere outskirts | 38/92 | 19.3 s |
| 71 | I walk from Tannery Row into Glassmere proper and go to the Guild hall to turn in the dog cull contract. | Erzähler | open_run_level | Turn in completed contract at Guild hall | Adventurers' Guild hall, Glassmere | 38/92 | 22.4 s |
| 72 | #assign VIT 3 STR 2 | System (Befehl) | open_run_level | Spend the 5 level-up stat points | Adventurers' Guild hall, Glassmere | 38/92 | 2.5 s |
| 73 | I go to the Guild board and look for a new Novice contract I can take. | Erzähler | open_run_level | Pick next Guild contract | Adventurers' Guild hall, Glassmere | 38/92 | 13.6 s |
| 74 | I take the Ridge Boars contract slip to the clerk and accept it. | Erzähler | open_run_level | Accept achievable Level 5 contract | Adventurers' Guild hall, Glassmere | 38/92 | 14.3 s |
| 75 | I ask the clerk where I can get wounds treated or a room to rest before heading out. | Erzähler | open_run_level | Recover before the boar hunt | Adventurers' Guild hall, Glassmere | 38/92 | 17.7 s |
| 76 | I head east off the fountain square to Maren's shop with the green shutter and ask her to treat my wounds for two coppers. | Erzähler | open_run_level | Get healing at Maren's before the boar hunt | Maren's healing shop | 38/92 | 15.4 s |
| 77 | I sit on the bench and let Maren look at my wounds. | Erzähler | open_run_level | Get treated at Maren's before the boar hunt | Maren's healing shop | 38/92 | 17.7 s |
| 78 | I accept the stitching for two coppers, then head out of town east toward the Cinder Orchards to hunt the ridge boars. | Erzähler | open_run_level | Pay for healing and travel to the boar contract | the Cinder Orchards, hills south of Glassmere | 38/92 | 28.2 s |
| 79 | I move quietly up the orchard rows toward the sound of brush, keeping trees between me and whatever made the noise, and scout before engagin… | Erzähler | open_run_level | Hunt ridge boars cautiously | the Cinder Orchards, hills south of Glassmere | 38/92 | 18.6 s |
| 80 | I open with Heavy Slash on Ridge Boar A the moment it quarters into range, then guard against its charge. | Erzähler | open_run_level | Attack the boar at ten paces | the Cinder Orchards, hills south of Glassmere | 38/92 | 15.5 s |
| 81 | I close the gap quickly, moving to ENGAGED with Ridge Boar A while its head is down, and attack with Heavy Slash as soon as I reach it. | Erzähler | open_run_level | Close to ENGAGED and attack the boar | the Cinder Orchards, hills south of Glassmere | 32/92 | 29.0 s |
| 82 | I finish it with Heavy Slash before it can gore me again. | Erzähler | open_run_level | Kill the wounded boar with Heavy Slash | the Cinder Orchards, hills south of Glassmere | 32/92 | 17.7 s |
| 83 | I skin and dress the fallen boar for its hide, then track the second boar uphill cautiously, keeping trees between us. | Erzähler | open_run_level | Loot the kill and hunt the second boar for the 3/3 contract | boar wallow hollow | 32/92 | 32.8 s |
| 84 | I back away from the brush wall quietly and withdraw down the trail toward town — I'm too badly hurt to fight the big one now, and I'll retu… | Erzähler | open_run_level | Withdraw at near-death HP before hunting the third boar | Glassmere | 32/92 | 23.9 s |
| 85 | I enter the Guild hall and ask about healing for my wounds — my HP still reads 32/215 despite paying for stitching earlier, and I need prope… | Erzähler | open_run_level | Get wounds properly healed at the Guild hall | Adventurers' Guild hall, Glassmere | 32/92 | 20.3 s |
| 86 | I ask the clerk to point me to the hospice on Lantern Row, then head there and request treatment for my wounds. | Erzähler | open_run_level | Get healed cheaply at the hospice | Temple of Saint Vered's hospice | 32/92 | 24.8 s |
| 87 | I pay two copper for the cleaning and closing, plus a copper for a bed tonight — I'll take your advice and rest properly before going back u… | Erzähler | open_run_level | Buy wound treatment and a bed at the hospice | Temple of Saint Vered's hospice | 32/92 | 20.3 s |
| 88 | I take the bed and sleep until morning. | Erzähler | open_run_level | Recover overnight at the hospice | Temple of Saint Vered's hospice | 32/92 | 21.1 s |
| 89 | I ask the healer to book the bed for the night for one copper, then sleep in it until morning. | Erzähler | open_run_level | Book the hospice bed properly and recover overnight | Temple of Saint Vered's hospice | 32/92 | 20.1 s |
| 90 | I book a room for the night at the hospice — one bed, one copper — and then sleep in it until morning. | Erzähler | open_run_level | Book the hospice room with canonical wording and recover overnight | Temple of Saint Vered's hospice | 32/92 | 19.2 s |
| 91 | I take the booked bed and sleep until morning. | Erzähler | open_run_level | Recover overnight in the booked hospice bed | Temple of Saint Vered's hospice | 215/92 | 14.4 s |
| 92 | I ask the healer about the Ridge Boar contract — I've killed two boars but the slip only counts one; is there anything she knows about how t… | Erzähler | open_run_level | Resolve the boar count discrepancy | Temple of Saint Vered's hospice | 215/92 | 18.9 s |
| 93 | I thank the healer and head to the Guild branch at the Counter to sort out the boar tally with the clerk. | Erzähler | open_run_level | Resolve the boar count at the Guild and turn in the contract | Adventurers' Guild hall, Glassmere | 215/92 | 42.4 s |
| 94 | I lay the Ridge Boar Hide on the counter. "Two boars, both in the Cinder Orchards — here's a hide from the second. Amend the tally to two of… | Erzähler | open_run_level | Prove the second boar kill with the hide and get the tally amended | Adventurers' Guild hall, Glassmere | 215/92 | 28.7 s |
| 95 | I take the hide back. "Fair enough — I'll go finish the third boar. Is there a bounty on anything else around while I'm out?" I glance over … | Erzähler | open_run_level | Hunt the third boar and look for a second contract to combine | Adventurers' Guild hall, Glassmere | 215/92 | 28.3 s |
| 96 | "The new boar cull — I'll take that slip too. Same hills, so I'll finish my tally and theirs in one trip." | Erzähler | open_run_level | Accept the second boar cull contract alongside the first | Adventurers' Guild hall, Glassmere | 215/92 | 17.0 s |
| 97 | I head out the south gate road to the Cinder Orchards and hunt boars there until both tallies are done. | Erzähler | open_run_level | Travel to the orchards and continue both boar culls | the Cinder Orchards, hills south of Glassmere | 215/92 | 23.3 s |
| 98 | I meet the charging boar head-on and strike at it with Heavy Slash. | Erzähler | open_run_level | Attack the incoming boar | the Cinder Orchards, hills south of Glassmere | 215/92 | 14.7 s |
| 99 | I brace and strike at the boar with Heavy Slash now that it's on me. | Erzähler | open_run_level | Attack the engaged boar in melee range | the Cinder Orchards, hills south of Glassmere | 205/92 | 18.1 s |
| 100 | I finish it with Heavy Slash before it can charge again. | Erzähler | open_run_level | Kill the wounded boar | the Cinder Orchards, hills south of Glassmere | 205/92 | 30.0 s |
| 101 | I thank Harn for the tip about the kiln flats and check my quest tallies — the first contract needs one more boar, the second three. I head … | Erzähler | open_run_level | Finish both boar cull tallies, starting with the unseen animal in the hollow | boar wallow hollow | 205/92 | 23.8 s |
| 102 | I circle through the reeds to strike at the great boar's flank with Heavy Slash while it's still lying down. | Erzähler | open_run_level | Ambush the resting wallow boar | boar wallow hollow | 205/92 | 18.0 s |
| 103 | I brace and charge straight across the churned mud to close into melee range, then strike at the great boar with Heavy Slash the moment I re… | Erzähler | open_run_level | Close to ENGAGED and attack the wallow boar | boar wallow hollow | 205/92 | 61.0 s |
| 104 | I hold my ground at the reed rim and ready a Heavy Slash, striking the moment the boar charges into melee range. | Erzähler | open_run_level | Bait the boar into charging so it closes to ENGAGED, then counterattack | boar wallow hollow | 205/92 | 18.8 s |
| 105 | I wait for the boar to close into ENGAGED range, then strike it with Heavy Slash as it reaches me. | Erzähler | open_run_level | Counter the charging boar once it enters melee range | boar wallow hollow | 205/92 | 19.0 s |
| 106 | I step deliberately across the churned mud toward the boar, closing to ENGAGED range, and swing Heavy Slash at it the moment I'm in reach. | Erzähler | open_run_level | Close the distance myself and attack | boar wallow hollow | 205/92 | 20.7 s |
| 107 | I swing Heavy Slash at the boar now that it's in reach. | Erzähler | open_run_level | Attack the boar at ENGAGED range | boar wallow hollow | 205/92 | 15.9 s |
| 108 | I push through the churn to close to ENGAGED range with the wounded boar and swing Heavy Slash the moment I'm in reach. | Erzähler | open_run_level | Close from SHORT and finish the boar | boar wallow hollow | 205/92 | 15.6 s |
| 109 | I check #quests to confirm the boar cull counts and whether either contract is READY for turn-in. | Erzähler | open_run_level | Verify contract progress after the boar kill | boar wallow hollow | 205/92 | 17.4 s |
| 110 | I hunt the ridge boars on the orchard slopes until the second contract's remaining two are killed. | Erzähler | open_run_level | Finish the 4-boar contract (2/4) | boar wallow hollow | 205/92 | 17.0 s |
| 111 | I head down to Glassmere and turn in the READY contract 'Cull the Ridge Boars in the Cinder Orchards' at the Guild counter for the hundred c… | Erzähler | open_run_level | Turn in the READY boar contract at the Guild hall | Adventurers' Guild hall, Glassmere | 205/92 | 21.5 s |
| 112 | #assign STR 3 VIT 2 | System (Befehl) | open_run_level | Spend level-up points | Adventurers' Guild hall, Glassmere | 205/92 | 2.8 s |
| 113 | I ask the clerk what contracts are on the board suitable for a Novice F-rank warrior. | Erzähler | open_run_level | Pick the next Guild contract | Adventurers' Guild hall, Glassmere | 205/92 | 14.7 s |
| 114 | I take the 'Cull the Tannery Row Dogs' slip from the Novice row and accept it with the clerk. | Erzähler | open_run_level | Accept the 6-dog cull contract | Adventurers' Guild hall, Glassmere | 205/92 | 15.7 s |
| 115 | I walk out to Tannery Row and hunt the feral dogs near the rendering pits until I've killed all six for the contract. | Erzähler | open_run_level | Perform the 6-dog cull | Tannery Row, Glassmere outskirts | 205/92 | 20.8 s |
| 116 | I charge the nearest dog behind the pit troughs and attack it with Heavy Slash. | Erzähler | open_run_level | Fight the three dogs at the pits toward the 6-kill contract | Tannery Row, Glassmere outskirts | 205/92 | 16.8 s |
| 117 | I close the distance to the nearest dog and attack it with Heavy Slash once in range. | Engine (Menü/Rückfrage) | open_run_level | Engage the feral dogs at proper range | Tannery Row, Glassmere outskirts | 205/92 | 6.4 s |
| 118 | I close on Feral Dog P and attack it with Heavy Slash once in range. | Erzähler | open_run_level | Engage the nearest dog | Tannery Row, Glassmere outskirts | 205/92 | 16.5 s |
| 119 | I step to Feral Dog Q and use Heavy Slash on it. | Erzähler | open_run_level | Continue the 6-dog cull | Tannery Row, Glassmere outskirts | 203/92 | 18.6 s |
| 120 | I use Heavy Slash on Feral Dog R to finish the last kill. | Erzähler | open_run_level | Complete the 6-dog cull contract | Tannery Row, Glassmere outskirts | 203/92 | 15.9 s |
| 121 | I push into the alder scrub behind the rendering pits and hunt down the remaining three feral dogs for the cull. | Erzähler | open_run_level | Continue the 6-dog cull in the alder scrub | Tannery Row, Glassmere outskirts | 203/92 | 23.6 s |
| 122 | I follow the dragged offal smear into the scrap-pits behind the far yards and search for the remaining three dogs there. | Erzähler | open_run_level | Continue the 6-dog cull in the scrap-pits | the scrap-pits | 203/92 | 18.4 s |
| 123 | I move toward the feeding sounds at the second pit in and engage the nearest feral dog with Heavy Slash once in range. | Erzähler | open_run_level | Find and fight the remaining three dogs at the scrap-pits | the scrap-pits | 203/92 | 26.4 s |
| 124 | I press the attack on the wounded Feral Dog S with Heavy Slash before it can circle me. | Erzähler | open_run_level | Finish the wounded dog | the scrap-pits | 203/92 | 19.1 s |
| 125 | I close the gap and attack Feral Dog S with Heavy Slash. | Erzähler | open_run_level | Finish the wounded dog at SHORT range | the scrap-pits | 203/92 | 23.3 s |
| 126 | I push into the northern cuttings after the fleeing one-eyed dog and its companion, hunting them with Heavy Slash once I close to ENGAGED. | Erzähler | open_run_level | Continue the 6-dog cull — two dogs remain | the trampled hollow in the northern cuttings | 201/92 | 32.2 s |
| 127 | I attack Feral Dog V with Heavy Slash. | Erzähler | open_run_level | Kill the wounded one-eyed dog first | the trampled hollow in the northern cuttings | 194/92 | 25.2 s |
| 128 | I attack Feral Dog W with Heavy Slash. | Erzähler | open_run_level | Kill the black-and-tan dog | the trampled hollow in the northern cuttings | 194/92 | 19.1 s |
| 129 | #assign VIT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up points on VIT and WIL | the trampled hollow in the northern cuttings | 194/92 | 2.8 s |
| 130 | I head back to the Tannery Row yards to find the Guild contact and report the completed dog cull. | Erzähler | open_run_level | Turn in the finished 6/6 dog cull contract | Tannery Row, Glassmere outskirts | 194/92 | 29.5 s |
| 131 | I head to the Glassmere Guild hall and turn in the completed 'Cull the Tannery Row Dogs' contract for my reward. | Erzähler | open_run_level | Turn in the 6/6 dog cull at the Guild hall | Adventurers' Guild hall, Glassmere | 194/92 | 20.5 s |
| 132 | I look over the Guild board for fresh Novice contracts I can take tonight or tomorrow morning. | Erzähler | open_run_level | Find new Guild work | Adventurers' Guild hall, Glassmere | 194/92 | 17.0 s |
| 133 | I take the 'Clear Glimmerdeep Grotto Level 1' contract slip and ask the clerk to mark it active before the hall shuts. | Erzähler | open_run_level | Accept the nearest Novice contract | Adventurers' Guild hall, Glassmere | 194/92 | 17.0 s |
| 134 | I ask the healer at Saint Vered's for wound treatment and a bed for the night, then sleep until morning. | Erzähler | open_run_level | Recover overnight before the grotto | Temple of Saint Vered's hospice | 194/92 | 23.2 s |
| 135 | I take the treatment and the bed together for forty coppers, then sleep until morning. | Erzähler | open_run_level | Buy healing and lodging, recover overnight | Temple of Saint Vered's hospice | 260/100 | 20.7 s |
| 136 | I set out from the hospice toward the mill road and find a carter heading out to the quarries to point me at the Glimmerdeep path. | Erzähler | open_run_level | Travel toward Glimmerdeep Grotto for the active clearing contract | foot of the scarp below Glimmerdeep | 260/100 | 36.4 s |
| 137 | I check the crates and grotto mouth for anyone about, then head into Glimmerdeep Grotto level 1 to clear it. | Erzähler | open_run_level | Enter the grotto and start the clearing contract | Glimmerdeep Grotto | 260/100 | 27.1 s |
| 138 | I follow the cart-ruts toward the scraping sound, sword up, keeping low past the bend. | Erzähler | open_run_level | Advance into the grotto toward the scraping | crystal vein chamber | 260/100 | 56.9 s |
| 139 | I charge the chewing beetle with Heavy Slash, striking before it can turn. | Erzähler | open_run_level | Open combat on the distracted beetle | crystal vein chamber | 260/100 | 15.1 s |
| 140 | I keep my sword up and advance on the nearer beetle, closing to engaged range before attacking. | Erzähler | open_run_level | Close distance so Heavy Slash can reach the beetles | crystal vein chamber | 260/100 | 16.4 s |
| 141 | I strike the nearer beetle with Heavy Slash now that it's within reach. | Erzähler | open_run_level | Attack the beetle at SHORT range with Heavy Slash | crystal vein chamber | 260/100 | 14.4 s |
| 142 | I step in to ENGAGED range of Glass Beetle A and strike it with Heavy Slash. | Erzähler | open_run_level | Close the last stride and attack | crystal vein chamber | 259/100 | 14.8 s |
| 143 | I strike Glass Beetle B with Heavy Slash. | Erzähler | open_run_level | Defeat the last beetle | crystal vein chamber | 259/100 | 17.1 s |
| 144 | I follow the deeper passage toward the scraping sound, sword ready. | Erzähler | open_run_level | Continue clearing Grotto level 1 | old miners' camp | 259/100 | 29.5 s |
| 145 | I take the left tunnel, sword ready. | Erzähler | open_run_level | Continue clearing Grotto level 1 | left-wall tunnel | 259/100 | 25.1 s |
| 146 | I close on Mineral Slime A and strike it with Heavy Slash. | Erzähler | open_run_level | Fight the slimes to clear Grotto level 1 | left-wall tunnel | 256/100 | 16.2 s |
| 147 | I finish Mineral Slime A with Heavy Slash. | Erzähler | open_run_level | Defeat the wounded slime first | left-wall tunnel | 255/100 | 24.4 s |
| 148 | I strike Mineral Slime B with Heavy Slash. | Erzähler | open_run_level | Defeat the last slime and clear the chamber | left-wall tunnel | 254/100 | 16.9 s |
| 149 | I finish Mineral Slime B with Heavy Slash. | Erzähler | open_run_level | Defeat the last slime | left-wall tunnel | 254/100 | 15.4 s |
| 150 | #assign STR 2 VIT 3 | System (Befehl) | open_run_level | Spend level-up points | left-wall tunnel | 254/100 | 3.0 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 2 (notiert vor Zug 3): Character creation complete: Level 1 Warrior with Heavy Slash and Guard, starter gear equipped, 5 silver.
- zu Zug 4 (notiert vor Zug 5): Registration cost only 20 copper despite the clerk quoting two silver; coin now 30 copper (3 silver shown in HUD) — minor contradiction.
- zu Zug 23 (notiert vor Zug 24): Hollow holds a dozen-plus dogs plus a very large one; HP 56/140 with 3/5 cull progress — pressing on risks death.
- zu Zug 28 (notiert vor Zug 29): HP only 50/140 and deep dogs are answering from the main hall; may need to retreat after this kill.
- zu Zug 29 (notiert vor Zug 30): Engine shows three dogs (F, G, H) at LONG range; movement must be explicitly declared within the same message for the attack to land.
- zu Zug 30 (notiert vor Zug 31): Engine now lists F at SHORT; closing worked despite the refusal messages. Three dogs are encircling me while badly wounded — retreat may be needed after this kill.
- zu Zug 31 (notiert vor Zug 32): Engine repeatedly requires explicit movement in the same message; HUD now shows G and H also at SHORT, so the circle has closed while I am at 50/140 HP.
- zu Zug 33 (notiert vor Zug 34): Contract shows 5/5 defeated — cull is complete. A very large paw print suggests a big beast runs with the pack; not engaging at low HP.
- zu Zug 40 (notiert vor Zug 41): Contract was already paid at turn-in; the pelts were loot, not quest proof.
- zu Zug 49 (notiert vor Zug 50): HUD threat mentions two dogs at the lane's mouth but the System says no targetable actors in the scene; narration and System scene state conflict.
- zu Zug 57 (notiert vor Zug 58): The engine refuses combined movement+attack declarations even when movement is spelled out; trying movement alone.
- zu Zug 59 (notiert vor Zug 60): Range bands: Heavy Slash reaches ENGAGED only; Basic Attack presumably works at SHORT. Dogs all at SHORT now and closing.
- zu Zug 79 (notiert vor Zug 80): HP still 38/215 despite stitching purchase — healing may not have applied; will check after the fight.
- zu Zug 81 (notiert vor Zug 82): Second boar sound is descending the slope — possible second fight after this one.
- zu Zug 83 (notiert vor Zug 84): HUD still shows HP 32/215 despite paying for stitching earlier — healing purchase may not have applied; will verify in town.
- zu Zug 84 (notiert vor Zug 85): HUD HP 32/215 despite earlier stitching payment — healing purchase may not have applied; verifying at Guild hall.
- zu Zug 85 (notiert vor Zug 86): HUD HP 32/215 despite earlier stitching purchase — healing not applied; quest panel says 1/3 boars though I killed two.
- zu Zug 86 (notiert vor Zug 87): Quest panel still counts only 1/3 boars despite two kills — will check the contract slip or Guild ledger later.
- zu Zug 87 (notiert vor Zug 88): Bed purchase confirmed (-1 copper); cleaning done but HUD HP not yet updated — will check after sleep.
- zu Zug 88 (notiert vor Zug 89): Bed purchase failed as 'room not booked' despite narration of handing over a copper — coin may have been taken without booking; will verify after.
- zu Zug 89 (notiert vor Zug 90): Bed purchase failed twice with 'room not booked' though coin may have been taken; HP still 32/215 after paid wound treatment — healing not applied either.
- zu Zug 90 (notiert vor Zug 91): Room booking finally confirmed via SERVICE entry; HP still 32/215 — will check after sleep.
- zu Zug 100 (notiert vor Zug 101): Two active boar contracts overlap: 2/3 and 1/4, so at least four more kills needed total.
- zu Zug 105 (notiert vor Zug 106): Boar and I are in a standoff; only declared movement will close MEDIUM range.
- zu Zug 121 (notiert vor Zug 122): HUD quest still shows 3/6 despite three kills; remaining dogs may be at the scrap-pits per the sign.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t7 | 7 | 2 | – | nein | 2 | gewonnen, 240 XP |
| enc.t18 | 19 | 1 | – | nein | 1 | gewonnen, 96 XP |
| enc.t23 | 25 | 1 | – | nein | 1 | gewonnen, 96 XP |
| enc.t30 | 32 | 1 | – | nein | 1 | gewonnen, 116 XP |
| enc.t45 | 51 | 1 | – | nein | 1 | gewonnen, 120 XP |
| enc.t54 | 61 | 3 | – | nein | 3 | gewonnen, 480 XP |
| enc.t71 | 81 | 1 | – | nein | 1 | gewonnen, 152 XP |
| enc.t89 | 99 | 1 | – | nein | 1 | gewonnen, 152 XP |
| enc.t97 | 107 | 1 | – | nein | 1 | gewonnen, 128 XP |
| enc.t106 | 118 | 3 | – | nein | 3 | gewonnen, 312 XP |
| enc.t113 | 125 | 1 | – | nein | 1 | gewonnen, 96 XP |
| enc.t114r | 126 | 2 | – | nein | 2 | gewonnen, 240 XP |
| enc.t129 | 142 | 2 | – | nein | 2 | gewonnen, 216 XP |
| enc.t133 | 146 | 2 | – | nein | 2 | gewonnen, 216 XP |

## Quests

- **Clear the Crystal Beetles of Glimmerdeep Grotto, Level 1** — expired (Zug 45), Dungeon loc.glimmerdeep_grotto Ebene 1
  - Aufgabe: Clear level 1 of Glimmerdeep Grotto. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Glimmerdeep Grotto is clear.
- **Cull the Marsh Serpent of Eelweir Bend** — expired (Zug 45)
  - Aufgabe: Kill 1 the marsh serpent striking at the eel-weirs at Eelweir Bend, the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the marsh serpent striking at the eel-weirs killed at Eelweir Bend, the Reed Flats.
- **Thin the Feral Dog Pack of the Tannery Row** — active (Zug 4) → completed (Zug 35)
  - Aufgabe: Kill 5 feral dogs of the abandoned tanning pits at Tannery Row, Glassmere outskirts. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 5 feral dogs of the abandoned tanning pits killed at Tannery Row, Glassmere outskirts.
- **Hunt the Ridge Boar Sow of the Cinder Orchards** — expired (Zug 45)
  - Aufgabe: Kill 1 the ridge boar sow trampling the orchard rows at the Cinder Orchards, hills south of Glassmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the ridge boar sow trampling the orchard rows killed at the Cinder Orchards, hills south of Glassmere.
- **Hunt the Pale Stalker of the Sinking Pines** — expired (Zug 45)
  - Aufgabe: Kill 1 the pale stalker preying on the woodcutters' camp at the Sinking Pines, north of the cleft road. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the pale stalker preying on the woodcutters' camp killed at the Sinking Pines, north of the cleft road.
- **Cull the Marsh Serpent at Eelweir Bend** — expired (Zug 95)
  - Aufgabe: Kill 1 marsh serpent at Eelweir Bend, the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 marsh serpent killed at Eelweir Bend, the Reed Flats.
- **Cull the Feral Dogs of Tannery Row** — active (Zug 46) → completed (Zug 71)
  - Aufgabe: Kill 4 feral dog at Tannery Row, Glassmere outskirts. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 feral dog killed at Tannery Row, Glassmere outskirts.
- **Cull the Ridge Boars in the Cinder Orchards** — active (Zug 74) → completed (Zug 111), READY
  - Aufgabe: Kill 3 ridge boar at the Cinder Orchards, hills south of Glassmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 ridge boar killed at the Cinder Orchards, hills south of Glassmere.
- **Hunt the Pale Stalker of the Sinking Pines** — expired (Zug 95)
  - Aufgabe: Kill 1 pale stalker at the Sinking Pines, north of the cleft road. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 pale stalker killed at the Sinking Pines, north of the cleft road.
- **Clear Glimmerdeep Grotto, Level 1** — expired (Zug 95), Dungeon loc.glimmerdeep_grotto Ebene 1
  - Aufgabe: Clear level 1 of Glimmerdeep Grotto. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Glimmerdeep Grotto is clear.
- **Cull the Tannery Row Dogs** — active (Zug 114) → completed (Zug 131)
  - Aufgabe: Kill 6 feral dogs at Tannery Row, Glassmere outskirts. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 6 feral dogs killed at Tannery Row, Glassmere outskirts.
- **Cull Ridge Boar in the Cinder Orchards** — active (Zug 96)
  - Aufgabe: Kill 4 ridge boar at the Cinder Orchards, hills south of Glassmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 ridge boar killed at the Cinder Orchards, hills south of Glassmere.
- **Clear Glimmerdeep Grotto Level 1** — active (Zug 133), Dungeon loc.glimmerdeep_grotto Ebene 1
  - Aufgabe: Clear level 1 of Glimmerdeep Grotto. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Glimmerdeep Grotto is clear.

## Auffälligkeiten

- Zug 5, Nachricht 10 (extraction_repaired): the extractor's first answer needed a repair
- Zug 19, Nachricht 37 (planner_repaired): the planner's first answer needed a repair
- Zug 21, Nachricht 41 (stat_words): the player spent Stat Points in words, not with #assign; nothing was assigned (for review: did the story tell them as done?)
- Zug 24, Nachricht 48 (extraction_repaired): the extractor's first answer needed a repair
- Zug 34, Nachricht 68 (extraction_repaired): the extractor's first answer needed a repair
- Zug 38, Nachricht 76 (extraction_repaired): the extractor's first answer needed a repair
- Zug 43, Nachricht 85 (planner_repaired): the planner's first answer needed a repair
- Zug 48, Nachricht 95 (planner_repaired): the planner's first answer needed a repair
- Zug 49, Nachricht 97 (planner_repaired): the planner's first answer needed a repair
- Zug 50, Nachricht 100 (extraction_repaired): the extractor's first answer needed a repair
- Zug 83, Nachricht 166 (extraction_repaired): the extractor's first answer needed a repair
- Zug 136, Nachricht 272 (extraction_repaired): the extractor's first answer needed a repair
- Zug 137, Nachricht 274 (extraction_repaired): the extractor's first answer needed a repair
- Zug 138, Nachricht 276 (extraction_repaired): the extractor's first answer needed a repair
- Zug 144, Nachricht 288 (extraction_repaired): the extractor's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 20× keine gültige JSON-Entscheidung (Züge 7, 14, 15, 22, 24, 25, 27, 48, 49, 54, 71, 72, 85, 86, 98, 104, 111, 121, 138, 141)

System-Panels: CLARIFY 3, NOT TAKEN 5, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: guild_canon 2, group_unclear 7, world_rule 18, engine_owned_fact 9, no_go 4, scene_context 9, quest_count 2, pc_inventory 2, guild_payout 1, offer 3, engine_recovery 1, ambient 5, engine_owned_memory 2, attack_commitment 9, engine_booked 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 20/150 Erstantworten ungültig (13.3 %); 20 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 143 | 4 | 2.5 s | 4.1 s | 12030 | 9962 | 82 | – | stop 143 | 0 |
| board | 3 | 0 | 9.2 s | 12.8 s | 2444 | 2151 | 986 | – | stop 3 | 0 |
| narrator | 134 | 0 | 8.3 s | 11.3 s | 11514 | 8791 | 382 | – | stop 134 | 0 |
| extract | 144 | 10 | 4.6 s | 9.3 s | 12382 | 9431 | 306 | – | stop 144 | 0 |
| forge | 2 | 0 | 2.4 s | 2.4 s | 379 | 0 | 68 | – | stop 2 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 61:17 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 17.4 s) | 0:33 min |
| 150 Züge, Spiel (Senden bis HUD nach der Extraktion) | 48:09 min — Median 18.2 s, p90 29.5 s, max 61.0 s |
| 150 Züge, Spieler-Entscheidung | 9:34 min — Median 2.0 s, 20 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 7:06 min / 0:30 min / 20:25 min / 13:45 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 23.1 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 15:23 min, 80 Züge ≈ 30:46 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spieler | 3 | – | 68.7 s | 2.0 s |
| Spieler | 2 | – | 35.2 s | 2.0 s |
| Spiel | 103 | – | 61.0 s | 18.2 s |
| Spiel | 138 | – | 56.9 s | 18.2 s |
| Provider extract | 138 | 391 | 33.7 s | 4.6 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
