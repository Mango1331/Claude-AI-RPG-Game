# Avereth Live-Test 20261028-150556Z-current_test

## Kurzfassung

- **Laufprofil:** guild-mage; Startklasse Mage, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** Niederlage — turn 77: he died
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 5. Sicherheitsgrenzen: 150 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** noch nicht erreicht.
- **Charakter:** mage (mage.arcane_bolt, mage.arcane_ward) · Regelstand 2 (Warrior, Mage, Rogue)
- **Ziel-Dungeon:** Old Crown Catacombs, Ebene 1 (Vertrag quest.clear_the_old_crown_catacombs_level_1)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: pragmatic adventurer: sell surplus loot and invest in useful equipment and techniques
- **Züge:** 77 · **Dauer:** 33:22 min · **LLM-Aufrufe der Engine/des Erzählers:** 216
- **Beobachtete Abdeckung:** 10 unterschiedliche gebuchte Reiseziele · 7 Kämpfe · 1 Verkäufe (130 cp Umsatz, ohne Questzahlungen/Geschenke) · 0 Ausrüstungswechsel · 0 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 27 · **Niederlage** in Zug 77: he died
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.113 |
| Git | 55c547f47701 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 17.7 s |
| Browser | chrome 156.0.8078.48 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261028-150556Z-current_test“, Seed 2053701139 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | Mage | Engine (Menü/Rückfrage) | creation_complete | Choose Mage class | public roadside verge outside Alderwatch | 90/84 | 2.3 s |
| 2 | I choose Arcane Bolt and Arcane Ward. | Engine (Menü/Rückfrage) | creation_complete | Pick two starter skills | public roadside verge outside Alderwatch | 90/96 | 2.1 s |
| 3 | I walk to Alderwatch's gate and enter the city, then head to the Adventurers' Guild to look at the contract board. | Erzähler | open_run_level | Enter Alderwatch and find Guild contracts | Adventurers' Guild hall, Alderwatch | 90/96 | 31.9 s |
| 4 | I take the Millpond Serpent slip to the counter and ask the clerk to register me with the Guild and accept the contract. | Erzähler | open_run_level | Register and take the serpent contract | Adventurers' Guild hall, Alderwatch | 90/96 | 20.6 s |
| 5 | I pay the 2 silver registration fee and sign the Guild roll. | Erzähler | open_run_level | Register with the Guild | Adventurers' Guild hall, Alderwatch | 90/96 | 22.1 s |
| 6 | I head east along the mill road to Hollis Mill and search the millpond for the water serpent. | Erzähler | open_run_level | Travel to the millpond and hunt the contracted serpent | Hollis Mill millpond, two miles east of Alderwatch along the mill road | 90/96 | 25.2 s |
| 7 | I wait near the reed bank until evening, watching the water for the serpent. | Erzähler | open_run_level | Ambush the contracted serpent at its active hour | Hollis Mill millpond, two miles east of Alderwatch along the mill road | 90/96 | 21.7 s |
| 8 | I cast Arcane Bolt at the serpent's head where it breaks the surface. | Engine (Menü/Rückfrage) | open_run_level | Attack the contracted serpent with Arcane Bolt | Hollis Mill millpond, two miles east of Alderwatch along the mill road | 90/96 | 5.2 s |
| 9 | #quests | System (Befehl) | open_run_level | Check whether the serpent contract is actually active before hunting | Hollis Mill millpond, two miles east of Alderwatch along the mill road | 90/96 | 2.1 s |
| 10 | I cast Arcane Bolt at the long ridge gliding across the pond. | Engine (Menü/Rückfrage) | open_run_level | Attack the serpent now that the active scene shows it as a threat | Hollis Mill millpond, two miles east of Alderwatch along the mill road | 90/96 | 4.0 s |
| 11 | I turn to the miller and ask what she knows about the serpent in her pond, and whether it has harmed anyone or anything yet. | Erzähler | open_run_level | Gather information from the miller before attacking | Hollis Mill millpond, two miles east of Alderwatch along the mill road | 90/96 | 20.2 s |
| 12 | I keep quiet and ready my staff, watching the reed bed for the serpent to come up onto the bank. | Erzähler | open_run_level | Ambush the serpent at close range so it becomes a valid target | Hollis Mill millpond, two miles east of Alderwatch along the mill road | 90/96 | 17.2 s |
| 13 | I cast Arcane Bolt at the Millpond Water Serpent A on the bank. | Erzähler | open_run_level | Attack the serpent now that it is a valid target | Hollis Mill millpond, two miles east of Alderwatch along the mill road | 90/86 | 22.0 s |
| 14 | I show Hollis the serpent's fang, then travel back along the mill road to the Alderwatch Guild hall to report the kill and turn in the contr… | Erzähler | open_run_level | Turn in the serpent contract at the Guild hall | Adventurers' Guild hall, Alderwatch | 90/86 | 44.7 s |
| 15 | I ask the clerk to put the millpond serpent contract under my name now, then turn in the fang and skin for the reward. | Erzähler | open_run_level | Sign the open contract at the desk and complete the turn-in | Adventurers' Guild hall, Alderwatch | 90/86 | 28.8 s |
| 16 | I tell the clerk to close out the contract against the slip and pay the reward here. | Erzähler | open_run_level | Turn in the signed serpent contract at the counter | Adventurers' Guild hall, Alderwatch | 90/86 | 23.3 s |
| 17 | I thank the clerk and take the slip, then find lodging for the night; in the morning I'll take the mill road back and kill another pond serp… | Erzähler | open_run_level | The engine counts 0/1 serpent defeated, so I'll defeat one while the contract is active, t… | Adventurers' Guild hall, Alderwatch | 90/86 | 20.4 s |
| 18 | I'll take the bed and a bowl of the mutton supper — thirteen copper total. | Erzähler | open_run_level | Pay the offered inn price for bed and supper | Adventurers' Guild hall, Alderwatch | 90/86 | 21.7 s |
| 19 | I head out at dawn and take the mill road to the millpond, then cast Arcane Bolt at a water serpent there. | Erzähler | open_run_level | Kill a serpent while the contract is active | Hollis Mill millpond, two miles east of Alderwatch along the mill road | 90/86 | 16.5 s |
| 20 | I cast Arcane Bolt at the serpent's head. | Erzähler | open_run_level | Kill the pond serpent while the contract is active | Hollis Mill millpond, two miles east of Alderwatch along the mill road | 90/76 | 19.1 s |
| 21 | I tell the miller I was working a Guild cull contract, and that if more serpents show I'll be back. Then I take the mill road back to Alderw… | Erzähler | open_run_level | Turn in completed serpent contract at the Guild hall | Adventurers' Guild hall, Alderwatch | 90/76 | 25.7 s |
| 22 | I ask the clerk what contracts are on the board for a Novice mage. | Erzähler | open_run_level | Pick the next Guild contract | Adventurers' Guild hall, Alderwatch | 90/76 | 18.0 s |
| 23 | I ask the clerk to sign me up for the Old Crown Catacombs contract, level 1. | Erzähler | open_run_level | Accept the catacombs contract, best fit for my level | Adventurers' Guild hall, Alderwatch | 90/76 | 16.2 s |
| 24 | I take the man's advice and buy two torches, then head west on the King's Road to the chapel above the Old Crown Catacombs. | Erzähler | open_run_level | Travel to the catacombs for the active contract | Adventurers' Guild hall, Alderwatch | 90/76 | 16.8 s |
| 25 | I take the two torches and pay the shopkeeper four copper for the pair, then head west on the King's Road toward the chapel above the Old Cr… | Erzähler | open_run_level | Buy torches at confirmed price, travel to catacombs | Old Crown Catacombs | 90/76 | 46.5 s |
| 26 | I light my torch and enter the dungeon, heading down the stairs behind the altar into level 1. | Erzähler | open_run_level | Enter the catacombs and begin the clear | Old Crown Catacombs, level 1 corridor | 90/76 | 21.7 s |
| 27 | I cast Arcane Bolt at Risen Bones A, the closer of the two. | Erzähler | open_run_level | Fight the risen bones | Old Crown Catacombs, level 1 corridor | 90/66 | 20.1 s |
| 28 | I cast Arcane Bolt at Risen Bones A to finish it off. | Erzähler | open_run_level | Kill the wounded skeleton before it strikes | Old Crown Catacombs, level 1 corridor | 76/56 | 14.6 s |
| 29 | I cast Arcane Bolt at Risen Bones B. | Erzähler | open_run_level | Finish the last skeleton | Old Crown Catacombs, level 1 corridor | 61/46 | 25.9 s |
| 30 | I cast Arcane Bolt at Risen Bones B to finish it. | Erzähler | open_run_level | Kill the wounded skeleton before it hits again | Old Crown Catacombs, level 1 corridor | 61/36 | 13.8 s |
| 31 | #assign INT 2 WIL 2 VIT 1 | System (Befehl) | open_run_level | Spend level-up points | Old Crown Catacombs, level 1 corridor | 61/36 | 2.2 s |
| 32 | I continue deeper into the level 1 corridor, torch up, watching for more threats. | Erzähler | open_run_level | Push on clearing dungeon level 1 | Old Crown Catacombs, level 1 burial chamber | 61/36 | 16.5 s |
| 33 | I cast Arcane Bolt at Restless Skeleton A, the one coming straight on. | Erzähler | open_run_level | Fight the restless skeletons | Old Crown Catacombs, level 1 burial chamber | 39/26 | 15.1 s |
| 34 | I cast Arcane Bolt at Restless Skeleton A to finish it. | Erzähler | open_run_level | Kill the wounded skeleton before it hits again | Old Crown Catacombs, level 1 burial chamber | 30/16 | 29.4 s |
| 35 | I cast Arcane Bolt at Restless Skeleton B. | Erzähler | open_run_level | Finish the last skeleton | Old Crown Catacombs, level 1 burial chamber | 30/6 | 17.2 s |
| 36 | #assign INT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up points | Old Crown Catacombs, level 1 burial chamber | 30/6 | 2.2 s |
| 37 | Badly wounded and nearly out of mana, I head back up the corridor toward the stairs to leave the catacombs and rest in town. | Erzähler | open_run_level | Withdraw to recover before pushing deeper | Alderwatch | 30/6 | 29.1 s |
| 38 | I go into the Lanternrest and ask for a room for the night. | Erzähler | open_run_level | Get lodging and sleep to recover | Lanternrest inn | 30/6 | 15.5 s |
| 39 | I sit down by the hearth as she says, then ask for a room and anything warm to eat. | Erzähler | open_run_level | Get lodging and food to recover | Lanternrest inn | 30/6 | 35.0 s |
| 40 | I eat the soup and bread, wash my cuts, then pay her the ten coppers for the room and meal and go up to sleep until morning. | Engine (Menü/Rückfrage) | open_run_level | Recover overnight | Lanternrest inn | 30/6 | 28.1 s |
| 41 | I buy the room for the night and the warmed barley soup with bread from Innkeeper B for 10 coppers total, then eat, wash my cuts, and sleep … | Engine (Menü/Rückfrage) | open_run_level | Pay for lodging and meal, then sleep to recover | Lanternrest inn | 30/6 | 16.5 s |
| 42 | I buy 1 room for the night (8 cp) and 1 warmed barley soup with bread (2 cp) from Innkeeper B for 10 coppers total, pay, then sleep until mo… | Erzähler | open_run_level | Purchase lodging and meal explicitly, then sleep | Lanternrest inn | 89/155 | 69.1 s |
| 43 | I buy the eggs and bread breakfast from Innkeeper B for 2 coppers, then head to the Guild hall to report on the catacombs contract and turn … | Erzähler | open_run_level | Eat breakfast, sell loot, continue catacombs contract | Adventurers' Guild hall, Alderwatch | 89/155 | 41.6 s |
| 44 | I ask the clerk where the den sites are in the catacombs and how I can tell when the level counts as fully cleared. | Erzähler | open_run_level | Learn what remains to clear the catacombs contract | Adventurers' Guild hall, Alderwatch | 89/155 | 25.1 s |
| 45 | I thank the clerk and head back to the Old Crown Catacombs to clear the remaining den sites, starting with the collapsed ossuary at the west… | Erzähler | open_run_level | Return to catacombs and clear the west ossuary den site | Old Crown Catacombs | 89/155 | 32.1 s |
| 46 | I cast Arcane Bolt at the closest skeleton rising from the bone drift. | Engine (Menü/Rückfrage) | open_run_level | Fight the ossuary skeletons, then break the nest den | Old Crown Catacombs | 89/155 | 4.6 s |
| 47 | I climb through the gap in the rubble and step into the ossuary, raising my staff toward the rising skeletons. | Erzähler | open_run_level | Enter the ossuary so the skeletons become targetable | ossuary | 89/155 | 27.9 s |
| 48 | The ossuary is already cleared, so I head back out of the catacombs and return to the Guild hall to turn in the Clear the Old Crown Catacomb… | Erzähler | open_run_level | Turn in the completed catacombs contract | Adventurers' Guild hall, Alderwatch | 89/155 | 54.5 s |
| 49 | #assign INT 3 WIL 2 | System (Befehl) | open_run_level | Spend the 5 free stat points from the level-up | Adventurers' Guild hall, Alderwatch | 89/155 | 2.2 s |
| 50 | I ask the clerk if the Guild buys serpent skins, fangs and grave dust, and what she'd offer for my lot. | Erzähler | open_run_level | Sell surplus loot at the Guild | Adventurers' Guild hall, Alderwatch | 89/155 | 22.0 s |
| 51 | "Twelve silver three copper is thin, Bren. Make it fourteen even and the lot is yours." | Erzähler | open_run_level | Haggle up the loot offer before selling | Adventurers' Guild hall, Alderwatch | 89/155 | 23.1 s |
| 52 | "Thirteen it is, Bren. The lot is yours." | Engine (Menü/Rückfrage) | open_run_level | Accept Bren's confirmed 13 silver offer for the whole lot | Adventurers' Guild hall, Alderwatch | 89/155 | 8.5 s |
| 53 | I accept Bren's new price of 1300 cp — thirteen silver for the whole lot. | Engine (Menü/Rückfrage) | open_run_level | Accept the correct thirteen-silver price | Adventurers' Guild hall, Alderwatch | 89/155 | 14.2 s |
| 54 | I mean 130 cp — thirteen silver equals 130 copper, so I accept Bren's bid of 130 cp for the whole lot. | Engine (Menü/Rückfrage) | open_run_level | Resolve the units confusion and complete the loot sale at Bren's recorded bid | Adventurers' Guild hall, Alderwatch | 89/155 | 12.1 s |
| 55 | I accept offer.t102.4 — Bren's bid of 130 cp for the whole lot. | Erzähler | open_run_level | Complete the loot sale at Bren's recorded bid | Adventurers' Guild hall, Alderwatch | 89/155 | 18.6 s |
| 56 | I thank Bren and turn to the Guild clerk to ask what beast contracts are on the board, especially anything about a second millpond serpent. | Erzähler | open_run_level | Pick a new Guild contract | Adventurers' Guild hall, Alderwatch | 89/155 | 38.8 s |
| 57 | I ask the clerk to take the Hollis Mill serpent contract and mark it mine. | Erzähler | open_run_level | Accept the serpent contract | Adventurers' Guild hall, Alderwatch | 89/155 | 20.3 s |
| 58 | I head east along the mill road to Hollis Mill, and on arrival I introduce myself to Millward Osen and ask him to point me to the serpent. | Erzähler | open_run_level | Travel to Hollis Mill and meet the client | Hollis Mill millpond, two miles east of Alderwatch along the mill road | 89/155 | 21.5 s |
| 59 | "Yes — I killed the millpond serpent at Bren's Mill yesterday," I say. "I'll circle past the willow and look for it basking on the warm end.… | Erzähler | open_run_level | Answer Osen and scout the serpent's basking spot | Hollis Mill millpond, two miles east of Alderwatch along the mill road | 89/155 | 40.9 s |
| 60 | I keep the willow between us and cast Arcane Bolt at the serpent's head. | Erzähler | open_run_level | Attack the basking serpent from cover | Hollis Mill millpond, two miles east of Alderwatch along the mill road | 89/145 | 18.1 s |
| 61 | I tell Osen the serpent is done and collect his confirmation, then head back along the mill road to Alderwatch and turn the contract in at t… | Erzähler | open_run_level | Turn in the serpent contract at the Guild | Adventurers' Guild hall, Alderwatch | 89/145 | 25.7 s |
| 62 | "What else is on the board for a Novice? I'm after another contract, ideally beast work, and I'd also sell this serpent skin and fang if the… | Erzähler | open_run_level | Ask the clerk for the board and sell loot | Adventurers' Guild hall, Alderwatch | 89/145 | 23.7 s |
| 63 | "Sold — thirteen for the pair." I hand over the skin and fang, then take the boar cull contract: "I'll take Cull the Thornback Boars. Mark i… | Engine (Menü/Rückfrage) | open_run_level | Sell loot and accept the boar cull contract | Adventurers' Guild hall, Alderwatch | 89/145 | 10.6 s |
| 64 | I accept the sale at 13 copper as agreed with the clerk. | Engine (Menü/Rückfrage) | open_run_level | Confirm the loot sale at the agreed price | Adventurers' Guild hall, Alderwatch | 89/145 | 8.6 s |
| 65 | I sell the F-Rank Millpond Water Serpent Skin and Fang to the Guild materiel clerk for 13 copper total. | Engine (Menü/Rückfrage) | open_run_level | Complete the clarified loot sale | Adventurers' Guild hall, Alderwatch | 89/145 | 9.4 s |
| 66 | Sell: 1 Millpond Water Serpent Skin and 1 Millpond Water Serpent Fang, sold by me to the Guild materiel clerk, total price 13 copper. | Erzähler | open_run_level | Complete the loot sale in the requested clarify format | Adventurers' Guild hall, Alderwatch | 89/145 | 31.4 s |
| 67 | I tell the clerk I'll leave the materiel for now and take the Thornback Boar cull contract — mark it ACTIVE for me. | Erzähler | open_run_level | Take the boar cull contract and move on | Adventurers' Guild hall, Alderwatch | 89/145 | 17.6 s |
| 68 | I head west out of Alderwatch toward the charcoal camps on the western slopes of Thornback Wood to hunt the Thornback Boars. | Erzähler | open_run_level | Travel to the boar cull site | Adventurers' Guild hall, Alderwatch | 89/145 | 24.3 s |
| 69 | "The middle camp first, where the damage is worst. And I'll mind the north camp — I won't fire near Kettleman's hut." | Erzähler | open_run_level | Confirm the middle camp as the hunting ground and heed the warning | Adventurers' Guild hall, Alderwatch | 89/145 | 26.9 s |
| 70 | I follow the track up to the middle camp and search the rooted ground around the cracked kiln for fresh boar sign. | Erzähler | open_run_level | Hunt boars at the middle camp | middle charcoal camp | 89/145 | 24.9 s |
| 71 | I follow the fresh boar tracks north of the cracked kiln into the trees, staff ready, looking for the boars. | Erzähler | open_run_level | Track and hunt the boars | boar wallow hollow above the middle camp | 89/145 | 32.1 s |
| 72 | I cast Arcane Bolt at the nearest sow, Boar B, from behind the hazel brush. | Erzähler | open_run_level | Open the boar fight with ranged magic from cover | boar wallow hollow above the middle camp | 89/135 | 28.4 s |
| 73 | I cast Arcane Bolt at Thornback Boar C while the brush still hides me. | Erzähler | open_run_level | Continue the ambush with ranged magic | boar wallow hollow above the middle camp | 89/125 | 18.4 s |
| 74 | I cast Arcane Bolt at Thornback Boar C to finish it before it charges in. | Erzähler | open_run_level | Finish the wounded boar at short range | boar wallow hollow above the middle camp | 72/115 | 20.6 s |
| 75 | I cast Arcane Bolt at Thornback Boar D before it can gore me again. | Erzähler | open_run_level | Finish the last sow | boar wallow hollow above the middle camp | 53/105 | 16.5 s |
| 76 | I cast Arcane Bolt at Thornback Boar D to finish it. | Erzähler | open_run_level | Finish the last wounded boar | boar wallow hollow above the middle camp | 53/95 | 18.5 s |
| 77 | I cast Arcane Bolt at Thornback Boar A to finish the cull. | Erzähler | open_run_level | Kill the fourth boar for the contract | boar wallow hollow above the middle camp | 0/85 | 18.0 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 5 (notiert vor Zug 6): HUD shows 3 Silver and no active quest despite engine confirming purchase and activation; coin discrepancy (30 cp vs 3 Silver) noted.
- zu Zug 8 (notiert vor Zug 9): HUD shows Quests: — and the serpent is not a valid combat target, so the contract may never have been accepted.
- zu Zug 11 (notiert vor Zug 12): Quest panel lists the serpent contract but HUD still shows Quests: —, so the kill may not register; will verify with proof-of-kill turn-in at the Guild.
- zu Zug 15 (notiert vor Zug 16): Reward was posted as six silver in the ledger but the clerk and HUD both state 40 copper; noted discrepancy.
- zu Zug 16 (notiert vor Zug 17): Contract requires a defeat recorded while signed, not the earlier kill; reward discrepancy 6 silver vs 40 cp persists.
- zu Zug 18 (notiert vor Zug 19): HUD location lags behind narration (still shows Guild hall at night); narration confirms morning at the inn.
- zu Zug 19 (notiert vor Zug 20): HUD time still lags (Day 1, 22:20 night) while narration shows dawn at the millpond.
- zu Zug 20 (notiert vor Zug 21): HUD still lags: shows Day 1 22:20 night while narration has dawn. Loot now 2 skins, 3 fangs (one skin/fang surplus from the earlier unrecorded kill).
- zu Zug 25 (notiert vor Zug 26): HUD now matches narration (Day 2, 00:20). Dungeon gate panel present; entry requires explicit statement.
- zu Zug 40 (notiert vor Zug 41): System wants explicit purchase clarification; earlier pay attempt changed nothing.
- zu Zug 41 (notiert vor Zug 42): System twice refused identical buy phrasing; possibly expects shop command format or item-by-item purchase.
- zu Zug 46 (notiert vor Zug 47): System says the scene has no targetable actors despite narration describing rising skeletons; may need to enter the chamber first.
- zu Zug 47 (notiert vor Zug 48): HUD confirms level 1 CLEARED this cycle by me; the ossuary skeletons were already dead, so no fight was needed.
- zu Zug 52 (notiert vor Zug 53): System flagged a units mismatch between Bren's recorded bid (130 cp) and his spoken thirteen silver; clarifying before sale.
- zu Zug 53 (notiert vor Zug 54): System treats silver as 10 copper (13 silver = 130 cp), so Bren's bid was correct all along.
- zu Zug 54 (notiert vor Zug 55): System keeps flip-flopping on whether 13 silver equals 130 or 1300 cp; accepting the recorded offer by ID to force resolution.
- zu Zug 55 (notiert vor Zug 56): Sale resolved at 130 cp despite Bren's narration handing over a gold piece plus thirteen silver; HUD coin (308 cp) matches the engine result.
- zu Zug 57 (notiert vor Zug 58): Narrator slip says 25 silver while the engine board and HUD say 25 cp (2 Silver 5 Copper); trusting the engine.
- zu Zug 63 (notiert vor Zug 64): System flagged a mismatch between the recorded bid (8 cp) and the clerk's offer (13 cp); answering the clarify prompt.
- zu Zug 64 (notiert vor Zug 65): System asked twice for clarification; restating the sale explicitly with goods, buyer, and total price.
- zu Zug 65 (notiert vor Zug 66): Clarify prompt keeps rejecting the sale wording; third attempt, will try #audit or a different channel if refused again.
- zu Zug 66 (notiert vor Zug 67): HUD lists the serpent skin and fang as carried while the engine result and narration say they are gone; the materiel clerk is not listed as present, which may explain the sale refusals.
- zu Zug 67 (notiert vor Zug 68): HUD still lists the serpent skin and fang as carried though the engine says they are gone; contract confirmed ACTIVE, 0/4.
- zu Zug 68 (notiert vor Zug 69): HUD still lists the serpent skin and fang as carried though the engine says they are gone; HUD location also lags behind narration.
- zu Zug 69 (notiert vor Zug 70): HUD location and inventory lag behind narration — still shows Guild hall and the serpent skin/fang already reported sold; noted as a HUD sync quirk.
- zu Zug 75 (notiert vor Zug 76): HP down to 53 after two gores; will need recovery after the fight.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t10 | 13 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t17 | 20 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t24 | 27 | 2 | – | nein | 2 | gewonnen, 168 XP |
| enc.t29 | 33 | 2 | – | nein | 2 | gewonnen, 168 XP |
| enc.t48 | 60 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t57 | 72 | 3 | – | nein | 3 | gewonnen, 378 XP |
| enc.t62 | 77 | 1 | – | nein | 0 | **tot** |

## Quests

- **Cull the Millpond Serpent** — active (Zug 15) → completed (Zug 21)
  - Aufgabe: Kill 1 the millpond water serpent at Hollis Mill millpond, two miles east of Alderwatch along the mill road. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the millpond water serpent killed at Hollis Mill millpond, two miles east of Alderwatch along the mill road.
- **Thin the Boar Sounder of Thornback Wood** — expired (Zug 56)
  - Aufgabe: Kill 4 tusked boars of Thornback Wood at Thornback Wood, the charcoal camps on the western slopes. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 tusked boars of Thornback Wood killed at Thornback Wood, the charcoal camps on the western slopes.
- **Cull the Gloomfang Pack** — expired (Zug 56)
  - Aufgabe: Kill 5 Gloomfang wolves at the Gloomfen marsh edge south of Wetford Hamlet. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 5 Gloomfang wolves killed at the Gloomfen marsh edge south of Wetford Hamlet.
- **Slay the Barrow Wyrm** — expired (Zug 56)
  - Aufgabe: Kill 1 the barrow wyrm at the old barrow field north of the King's Road, half a day's ride from Alderwatch. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the barrow wyrm killed at the old barrow field north of the King's Road, half a day's ride from Alderwatch.
- **Clear the Old Crown Catacombs, Level 1** — active (Zug 23) → completed (Zug 48), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of Old Crown Catacombs. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Old Crown Catacombs is clear.
- **Serpent at Hollis Mill** — active (Zug 57) → completed (Zug 61)
  - Aufgabe: Kill 1 millpond water serpent at Hollis Mill millpond, two miles east of Alderwatch along the mill road. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 millpond water serpent killed at Hollis Mill millpond, two miles east of Alderwatch along the mill road.
- **Cull the Thornback Boars** — active (Zug 67)
  - Aufgabe: Kill 4 Thornback boar at the charcoal camps on the western slopes of Thornback Wood. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 Thornback boar killed at the charcoal camps on the western slopes of Thornback Wood.

## Auffälligkeiten

- Zug 4, Nachricht 8 (extraction_repaired): the extractor's first answer needed a repair
- Zug 5, Nachricht 10 (extraction_repaired): the extractor's first answer needed a repair
- Zug 14, Nachricht 28 (extraction_repaired): the extractor's first answer needed a repair
- Zug 15, Nachricht 29 (cull_count): Cull the Millpond Serpent: its objective counts 1, its texts say 1, 2 (for review)
- Zug 15, Nachricht 30 (extraction_repaired): the extractor's first answer needed a repair
- Zug 29, Nachricht 58 (extraction_repaired): the extractor's first answer needed a repair
- Zug 40, Nachricht 79 (planner_repaired): the planner's first answer needed a repair
- Zug 41, Nachricht 81 (planner_repaired): the planner's first answer needed a repair
- Zug 42, Nachricht 83 (planner_repaired): the planner's first answer needed a repair
- Zug 43, Nachricht 85 (planner_repaired): the planner's first answer needed a repair
- Zug 45, Nachricht 90 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (restless skeleton): refused, no fight (Patch 8.4.1 guard)
- Zug 45, Nachricht 90 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (large bone-thing of the matted nest): refused, no fight (Patch 8.4.1 guard)
- Zug 48, Nachricht 96 (extraction_repaired): the extractor's first answer needed a repair
- Zug 51, Nachricht 102 (extraction_repaired): the extractor's first answer needed a repair
- Zug 52, Nachricht 103 (planner_repaired): the planner's first answer needed a repair
- Zug 53, Nachricht 105 (planner_repaired): the planner's first answer needed a repair
- Zug 54, Nachricht 107 (planner_repaired): the planner's first answer needed a repair
- Zug 57, Nachricht 113 (cull_count): Serpent at Hollis Mill: its objective counts 1, its texts say 1, 2 (for review)
- Zug 59, Nachricht 118 (extraction_repaired): the extractor's first answer needed a repair
- Zug 61, Nachricht 122 (extraction_repaired): the extractor's first answer needed a repair
- Zug 63, Nachricht 125 (planner_repaired): the planner's first answer needed a repair
- Zug 64, Nachricht 127 (planner_repaired): the planner's first answer needed a repair
- Zug 65, Nachricht 129 (planner_repaired): the planner's first answer needed a repair
- Zug 66, Nachricht 131 (planner_repaired): the planner's first answer needed a repair
- Zug 69, Nachricht 138 (extraction_repaired): the extractor's first answer needed a repair
- Zug 74, Nachricht 148 (extraction_repaired): the extractor's first answer needed a repair
- Zug 76, Nachricht 152 (extraction_repaired): the extractor's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 12× keine gültige JSON-Entscheidung (Züge 7, 8, 9, 10, 11, 13, 39, 45, 51, 59, 60, 69)

System-Panels: CLARIFY 8, NOT TAKEN 0, REFUSED 1, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: engine_owned_fact 16, ambient 3, quest 1, quest_dependency 1, no_go 4, scene_context 10, time_cap 1, engine_owned 1, group_unclear 2, world_rule 9, attack_commitment 2, dungeon_foe 2, pc_inventory 2, guild_payout 1, offer 1, entity_fact 1, engine_owned_memory 1, quest_count 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 12/77 Erstantworten ungültig (15.6 %); 12 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 82 | 11 | 3.0 s | 8.6 s | 11951 | 9932 | 79 | – | stop 82 | 0 |
| board | 2 | 0 | 11.4 s | 12.6 s | 2424 | 2142 | 1068 | – | stop 2 | 0 |
| narrator | 60 | 0 | 9.1 s | 16.6 s | 11673 | 8721 | 386 | – | stop 60 | 0 |
| extract | 72 | 12 | 5.8 s | 9.8 s | 12212 | 9354 | 311 | – | stop 72 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 33:22 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 17.7 s) | 0:35 min |
| 77 Züge, Spiel (Senden bis HUD nach der Extraktion) | 27:28 min — Median 20.4 s, p90 35.0 s, max 69.1 s |
| 77 Züge, Spieler-Entscheidung | 4:07 min — Median 2.5 s, 12 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 5:28 min / 0:23 min / 10:59 min / 7:44 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 24.6 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 16:24 min, 80 Züge ≈ 32:49 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spiel | 42 | – | 69.1 s | 20.4 s |
| Provider narrator | 48 | 128 | 35.0 s | 9.1 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
