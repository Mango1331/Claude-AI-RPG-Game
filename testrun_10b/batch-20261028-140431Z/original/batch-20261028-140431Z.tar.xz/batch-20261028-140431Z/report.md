# Avereth – 3 natürliche Testkampagnen

Status: **interrupted**. Serie abgeschlossen bedeutet, dass die Läufe beendet sind; es bedeutet nicht 3 bestandene Level-15-Abnahmen.

| Nr. | Profil | Seed | Eingaben | Level | Ende | Originalbericht |
|---|---|---:|---:|---:|---|---|
| 1 | guild-warrior | 2053701138 | 150 | 9 | limit | [report.md](001-guild-warrior/20261028-140432Z-current_test/report.md) |
| 2 | guild-mage | 2053701139 | 77 | 5 | defeat | [report.md](002-guild-mage/20261028-150556Z-current_test/report.md) |
| 3 | guild-rogue | 2053701140 | 0 | – | process_error | [report.md](003-guild-rogue/20261028-153922Z-current_test/report.md) |

