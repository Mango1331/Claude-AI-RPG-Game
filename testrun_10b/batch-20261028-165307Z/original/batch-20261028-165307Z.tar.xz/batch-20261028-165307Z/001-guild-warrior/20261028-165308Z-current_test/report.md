# Avereth Live-Test 20261028-165308Z-current_test

## Kurzfassung

- **Laufprofil:** guild-warrior; Startklasse Warrior, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** extractor_failed — turn 72: the World Extractor failed after story message 144; its world changes were not committed (the LLM call failed (HTTP 200: Internal Server Error))
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 3. Sicherheitsgrenzen: 150 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** noch nicht erreicht.
- **Charakter:** warrior (warrior.heavy_slash, warrior.guard) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: pragmatic adventurer: sell surplus loot and invest in useful equipment and techniques
- **Züge:** 72 · **Dauer:** 30:56 min · **LLM-Aufrufe der Engine/des Erzählers:** 202
- **Beobachtete Abdeckung:** 7 unterschiedliche gebuchte Reiseziele · 6 Kämpfe · 1 Verkäufe (32 cp Umsatz, ohne Questzahlungen/Geschenke) · 0 Ausrüstungswechsel · 1 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 6
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.114 |
| Git | 89aaf08d1313 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 17.2 s |
| Browser | chrome 156.0.8078.48 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261028-165308Z-current_test“, Seed 314367447 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | Warrior. | Engine (Menü/Rückfrage) | creation_complete | Choose Warrior class | public roadside verge outside Ashbridge | 90/84 | 2.3 s |
| 2 | I choose Heavy Slash and Guard. | Engine (Menü/Rückfrage) | creation_complete | Finish character creation with two starter skills | public roadside verge outside Ashbridge | 95/84 | 2.2 s |
| 3 | I walk into Ashbridge and head straight for the Adventurers' Guild hall to register and see the contract board. | Erzähler | open_run_level | Enter city, find Guild, get contracts | Adventurers' Guild hall, Ashbridge | 95/84 | 23.0 s |
| 4 | I pay the two silver for registration and place my hand on the measuring stone. | Erzähler | open_run_level | Register with the Guild | Adventurers' Guild hall, Ashbridge | 95/84 | 23.7 s |
| 5 | I ask the clerk: is there any novice work or standing escort job available right now, since the board is empty? | Erzähler | open_run_level | Get a first contract from the Guild desk | Adventurers' Guild hall, Ashbridge | 95/84 | 46.3 s |
| 6 | I ask the clerk to make the Millrace Serpent contract active for me. | Erzähler | open_run_level | Take the easiest novice contract first | Adventurers' Guild hall, Ashbridge | 95/84 | 42.2 s |
| 7 | I head down the millrace lane past the fullers' yards to Widow Hessa's mill and tell her I'm there about the snake in the pond. | Erzähler | open_run_level | Travel to the mill and start the serpent contract | Hessa's mill | 95/84 | 32.3 s |
| 8 | I ask Hessa whether I can borrow her small boat or a raft, since it hunts the shallows and I'd rather meet it on my own footing than wait on… | Erzähler | open_run_level | Plan the serpent fight at the pond | Hessa's mill | 95/84 | 28.8 s |
| 9 | I take the punt out onto the pond and pole toward the shallows near the reeds, gaff hook and sword ready, waiting for the serpent to come at… | Erzähler | open_run_level | Hunt the serpent from the boat | the millrace pond below Hessa's mill, Ashbridge | 95/84 | 23.3 s |
| 10 | I brace as the serpent passes under the punt and strike down at it with the gaff hook, then follow with my sword if it surfaces. | Engine (Menü/Rückfrage) | open_run_level | Attack the serpent from the boat | the millrace pond below Hessa's mill, Ashbridge | 95/84 | 4.7 s |
| 11 | I use Basic Attack to strike down with the gaff hook as the serpent passes under the punt. | Erzähler | open_run_level | Attack the serpent with the gaff hook | the millrace pond below Hessa's mill, Ashbridge | 95/84 | 15.3 s |
| 12 | I hold my ground in the punt and let the serpent close the distance, then strike with Basic Attack the moment it comes within reach of the g… | Erzähler | open_run_level | Engage the serpent at close range before attacking | the millrace pond below Hessa's mill, Ashbridge | 95/84 | 23.7 s |
| 13 | I strike with Basic Attack at the serpent's head while it is inside the punt. | Erzähler | open_run_level | Attack the serpent now that it is ENGAGED | the millrace pond below Hessa's mill, Ashbridge | 95/84 | 16.8 s |
| 14 | I pole the leaking punt back to Hessa's bank, return her boat, and tell her the serpent is dead. | Erzähler | open_run_level | Return the punt and report the kill before turning in the contract | Hessa's mill | 95/84 | 18.0 s |
| 15 | I walk back to the pond with Hessa and show her the dead serpent floating by the millrace. | Erzähler | open_run_level | Confirm the kill with Hessa, then turn in the contract at the Guild | the millrace pond below Hessa's mill, Ashbridge | 95/84 | 18.5 s |
| 16 | "Ten silver's fair for a morning's work, Hessa—coin's what I need most. And I'll take the dried-out boat's worth of thanks already given." | Erzähler | open_run_level | Name a fair price for the serpent kill | the millrace pond below Hessa's mill, Ashbridge | 95/84 | 22.2 s |
| 17 | I accept a slice of her fresh bread with thanks, then head back to the Ashbridge Guild hall to turn in the serpent contract. | Erzähler | open_run_level | Turn in the completed serpent contract at the Guild | Adventurers' Guild hall, Ashbridge | 95/84 | 24.5 s |
| 18 | I ask the clerk to buy the Primer of Strike for 80 copper, and ask what she'll offer for an old water serpent skin and fang. | Erzähler | open_run_level | Buy a skill primer and sell serpent loot | Adventurers' Guild hall, Ashbridge | 95/84 | 24.6 s |
| 19 | I sell both the serpent skin and fang to the clerk for thirty-two copper, then ask to buy the Primer of Strike for eighty copper once the sa… | Erzähler | open_run_level | Sell loot and buy Strike primer | Adventurers' Guild hall, Ashbridge | 95/84 | 18.3 s |
| 20 | I study the Primer of Strike to learn the skill, then ask the clerk for a Floor One contract that pays better than pond work. | Engine (Menü/Rückfrage) | open_run_level | Learn Strike, take a better-paying contract | Adventurers' Guild hall, Ashbridge | 95/84 | 6.9 s |
| 21 | I study the Primer of Strike for 2 hours at the Guild counter. | Erzähler | open_run_level | Learn Strike skill | Adventurers' Guild hall, Ashbridge | 95/84 | 19.3 s |
| 22 | I go to the contract board and look for a Floor One contract that pays better than pond work. | Erzähler | open_run_level | Find a better-paying Guild contract | Adventurers' Guild hall, Ashbridge | 95/84 | 21.9 s |
| 23 | I take the wolf cull slip to the clerk and ask to accept the contract. | Erzähler | open_run_level | Accept the Quarry-Track Wolves contract | Adventurers' Guild hall, Ashbridge | 95/84 | 13.4 s |
| 24 | I leave the Guild and head east along the old quarry track to hunt grey wolves. | Erzähler | open_run_level | Travel to the wolf contract area | the old quarry track east of Ashbridge | 95/84 | 17.0 s |
| 25 | I follow the wolf sign toward the quarry cuttings, searching the scrap piles and ledges for the grey wolves. | Erzähler | open_run_level | Hunt the contract wolves | the old quarry track east of Ashbridge | 95/84 | 14.1 s |
| 26 | I follow the direction the paw prints were heading, tracking the wolves' trail away from the quarry toward their den. | Erzähler | open_run_level | Track the wolves by their sign | the wolves' den hollow | 95/84 | 21.9 s |
| 27 | I draw my sword and meet the scarred lead wolf head-on, opening with Heavy Slash at Grey Wolf A. | Erzähler | open_run_level | Fight the wolf pack, starting with the leader | the wolves' den hollow | 95/84 | 17.2 s |
| 28 | I advance into the hollow and close to engaged range with Grey Wolf A, then swing Heavy Slash at it. | Erzähler | open_run_level | Close distance and attack the lead wolf | the wolves' den hollow | 95/84 | 13.1 s |
| 29 | I close the remaining distance to Grey Wolf A at a run and, once engaged, swing Heavy Slash at it. | Erzähler | open_run_level | Close to ENGAGED range and attack the lead wolf | the wolves' den hollow | 95/84 | 16.4 s |
| 30 | I swing Heavy Slash at Grey Wolf B, the flanker already at SHORT range on my right. | Erzähler | open_run_level | Attack the wolf actually in melee range | the wolves' den hollow | 95/84 | 23.5 s |
| 31 | I step toward Grey Wolf B to come within sword's reach, then swing Heavy Slash at it once engaged. | Erzähler | open_run_level | Close to ENGAGED range on the flanker and attack | the wolves' den hollow | 86/84 | 18.6 s |
| 32 | I swing Heavy Slash at Grey Wolf C. | Erzähler | open_run_level | Kill the engaged wolf C with Heavy Slash | the wolves' den hollow | 83/84 | 13.9 s |
| 33 | I swing Heavy Slash at Grey Wolf D while it circles at ENGAGED range. | Erzähler | open_run_level | Kill the engaged wolf D with Heavy Slash | the wolves' den hollow | 83/84 | 19.4 s |
| 34 | #assign STR 2 VIT 2 AGI 1 | System (Befehl) | open_run_level | Spend level-up stat points | the wolves' den hollow | 83/84 | 2.1 s |
| 35 | I advance on Grey Wolf A at the den mouths and, once in reach, swing Heavy Slash at it. | Erzähler | open_run_level | Kill the fourth wolf to complete the contract count | the wolves' den hollow | 83/84 | 19.5 s |
| 36 | I chase Grey Wolf A, keep moving until I'm within ENGAGED range, then swing Heavy Slash at it. | Erzähler | open_run_level | Pursue and kill the fourth wolf | the wolves' den hollow | 83/84 | 17.0 s |
| 37 | I keep closing on Grey Wolf A until it is at ENGAGED range, then swing Heavy Slash at it. | Erzähler | open_run_level | Close to ENGAGED range and kill the fourth wolf | the wolves' den hollow | 83/84 | 19.8 s |
| 38 | I return to the den hollow and harvest pelts and fangs from the three dead wolves, then head back along the quarry track toward Ashbridge be… | Erzähler | open_run_level | Harvest loot from kills and return before nightfall | Ashbridge | 83/84 | 26.7 s |
| 39 | I tell the guard I've come in from the quarry track after clearing wolves, and ask if the gate is open to travelers this late. | Erzähler | open_run_level | Pass the gate and reach the Guild or lodging | Ashbridge | 83/84 | 18.6 s |
| 40 | I head to the Drowned Otter, ask for a bed for the night, and if one is available, pay for it and sleep until morning. | Erzähler | open_run_level | Lodging and overnight recovery | the Drowned Otter | 83/84 | 19.4 s |
| 41 | I take the box bed for the night and a bowl of stew, paying the 6 coppers, then eat and sleep until morning. | Erzähler | open_run_level | Buy lodging and food, recover overnight | the Drowned Otter | 115/84 | 18.1 s |
| 42 | I head to the Guild hall, tell the clerk I killed three of the quarry-track wolves, and try to turn in the contract with the three pelts and… | Erzähler | open_run_level | Turn in wolf contract at the Guild hall | Adventurers' Guild hall, Ashbridge | 115/84 | 41.4 s |
| 43 | I check the contract board for other Novice contracts I could take alongside or instead of the wolf job. | Erzähler | open_run_level | Look for additional achievable contracts | Adventurers' Guild hall, Ashbridge | 115/84 | 40.4 s |
| 44 | I ask the clerk to accept the Serpent at the Millrace contract, and once it's active, I head to the millrace pond below Hessa's mill to hunt… | Erzähler | open_run_level | Take the in-town serpent contract and hunt it | the millrace pond below Hessa's mill, Ashbridge | 115/84 | 27.1 s |
| 45 | I ask Hessa for bait or scraps to lure the serpent to the water's edge, then wait hidden near the bank where it takes the ducks. | Erzähler | open_run_level | Lure the water serpent within reach | the millrace pond below Hessa's mill, Ashbridge | 115/84 | 24.3 s |
| 46 | I burst from cover behind the willow and swing my longsword in a Heavy Slash at the serpent's neck while it's focused on the bait. | Erzähler | open_run_level | Ambush the water serpent with Heavy Slash | the millrace pond below Hessa's mill, Ashbridge | 115/84 | 16.4 s |
| 47 | I drag the serpent carcass out onto the bank, then take Hessa's coin thanks and head back to the Guild hall to turn in the Serpent at the Mi… | Erzähler | open_run_level | Turn in the serpent contract | Adventurers' Guild hall, Ashbridge | 115/84 | 23.8 s |
| 48 | I head to the quarry tracks to hunt wolves for the Thin the Quarry-Track Wolves contract. | Erzähler | open_run_level | Hunt quarry-track wolves | the old quarry track east of Ashbridge | 115/84 | 19.9 s |
| 49 | I follow the fresh sign toward the eastern pine rim, keeping low and watching the tree-line for movement. | Erzähler | open_run_level | Track the wolf pack | the old quarry track east of Ashbridge | 115/84 | 25.2 s |
| 50 | I draw my longsword and meet the larger wolf head-on, swinging a Heavy Slash at it as it steps onto the open track. | Erzähler | open_run_level | Fight the two visible wolves | the old quarry track east of Ashbridge | 115/84 | 20.3 s |
| 51 | I brace as the big wolf lunges and swing a Heavy Slash at it at close quarters. | Erzähler | open_run_level | Fight the engaged wolf | the old quarry track east of Ashbridge | 96/84 | 14.1 s |
| 52 | I finish the wounded wolf with a Basic Attack before it gathers itself. | Erzähler | open_run_level | Kill Grey Wolf E | the old quarry track east of Ashbridge | 96/84 | 19.3 s |
| 53 | #assign STR 3 VIT 2 | System (Befehl) | open_run_level | Spend level-up points on damage and survivability | the old quarry track east of Ashbridge | 96/84 | 2.5 s |
| 54 | #quest Thin the Quarry-Track Wolves | System (Befehl) | open_run_level | Verify contract wolf count before hunting more | the old quarry track east of Ashbridge | 96/84 | 2.2 s |
| 55 | I follow the fleeing pack's trail east into the pine cover, hunting the fourth wolf the contract still counts. | Erzähler | open_run_level | Track down the last wolf for the contract | the wolves' den hollow | 96/84 | 23.5 s |
| 56 | I finish the crippled wolf with a Heavy Slash, leaving the pups alone unless they attack me. | Erzähler | open_run_level | Kill the fourth contracted wolf | the wolves' den hollow | 96/84 | 17.8 s |
| 57 | I close the distance up the shale slope and attack the crippled wolf at close quarters with a Heavy Slash. | Erzähler | open_run_level | Enter SHORT range and finish the fourth contracted wolf | the wolves' den hollow | 96/84 | 17.9 s |
| 58 | #quest Thin the Quarry-Track Wolves | System (Befehl) | open_run_level | Verify the contract count before turning in | the wolves' den hollow | 96/84 | 2.4 s |
| 59 | I return to Ashbridge and present the contract slip at the Guild counter, asking the clerk to record the fourth wolf and pay out the contrac… | Erzähler | open_run_level | Turn in the completed wolf contract | Adventurers' Guild hall, Ashbridge | 96/84 | 18.4 s |
| 60 | I take the healing draught at the dispensary for two copper, then set out east along the quarry track again to hunt the three wolves the led… | Erzähler | open_run_level | Recover lightly and hunt the remaining contracted wolves | the old quarry track east of Ashbridge | 96/84 | 22.8 s |
| 61 | I follow the fresh tracks up the shale toward the den hollow, hunting the wolves the ledger still counts, and use the healing draught from m… | Erzähler | open_run_level | Hunt remaining contracted wolves and recover | the wolves' den hollow | 96/84 | 22.7 s |
| 62 | I open the fight with a Heavy Slash at the larger wolf G guarding the den mouth. | Erzähler | open_run_level | Fight the two wolves blocking the den | the wolves' den hollow | 91/84 | 16.1 s |
| 63 | I take a step to close with the larger wolf G and swing a Heavy Slash at it. | Erzähler | open_run_level | Enter ENGAGED and strike wolf G | the wolves' den hollow | 90/84 | 18.6 s |
| 64 | I swing a Heavy Slash at Grey Wolf H. | Erzähler | open_run_level | Finish the fight and claim the fourth contracted wolf kill | the wolves' den hollow | 90/84 | 17.3 s |
| 65 | I check the quest panel to see whether these two den-mouth kills have been recorded toward the wolf contract. | Erzähler | open_run_level | Verify contract kill count after den fight | the wolves' den hollow | 90/84 | 18.0 s |
| 66 | It's nearly dark and the slip still counts only one wolf, so I take a pelt and a fang from the fresh kills and press them against the Guild … | Erzähler | open_run_level | Try to register the den kills toward the wolf contract via proof | the wolves' den hollow | 90/84 | 16.3 s |
| 67 | I shoulder my gear and head west down the quarry track toward Ashbridge, trusting the count to settle once I'm back in Guild territory. | Erzähler | open_run_level | Return to Ashbridge so the contract count can update or turn in | the wolves' den hollow | 90/84 | 28.5 s |
| 68 | "Aye, the den hollow—thinned three wolves there today. Are you headed back toward Ashbridge? I'll walk with you to the Guild hall and settle… | Erzähler | open_run_level | Walk to Ashbridge with the carter and turn in the contract | Adventurers' Guild hall, Ashbridge | 90/84 | 34.3 s |
| 69 | I ask the clerk whether the seal only counts wolves taken inside the contract's marked ground, and whether she can show me where that ground… | Erzähler | open_run_level | Learn why the count stays at 1/4 and where to hunt the remaining wolves | Adventurers' Guild hall, Ashbridge | 90/84 | 32.5 s |
| 70 | "The slip names the old quarry track east of Ashbridge, and I killed three grey wolves on that track today. Why does the seal count only one… | Erzähler | open_run_level | Learn from the clerk why the seal counts only one wolf | Adventurers' Guild hall, Ashbridge | 90/84 | 28.8 s |
| 71 | I ask the clerk to buy six of my grey wolf pelts at a fair price, keeping one, and whether the Guild has a culling contract for the wolf den… | Erzähler | open_run_level | Sell surplus pelts and look for the den culling contract | Adventurers' Guild hall, Ashbridge | 90/84 | 26.4 s |
| 72 | I answer him honestly: "Three grown wolves, and pups whining in the back—whelping den, north side off the track. I couldn't dig them out alo… |  | open_run_level | Share den intel with the adventurer and accept the culling contract | Adventurers' Guild hall, Ashbridge | 90/84 | 22.3 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 11 (notiert vor Zug 12): Combat requires ENGAGED range; Basic Attack from SHORT failed. Serpent is closing on its own.
- zu Zug 16 (notiert vor Zug 17): Payment from Hessa (10 silver) not yet reflected in HUD coin, which still shows 3 silver; also carrying serpent skin and fang as potential sellable loot.
- zu Zug 22 (notiert vor Zug 23): HUD shows 2 Silver 2 Copper — the 10 silver from Hessa still not reflected; also skill list lacks Strike despite learning result (only Guard P1 shown, no Strike), worth rechecking later.
- zu Zug 29 (notiert vor Zug 30): Engine refused three closing attempts; flanking wolves B-D are at SHORT, so I target one of them instead.
- zu Zug 33 (notiert vor Zug 34): Quest panel still shows 0/4 defeated despite engine confirming three wolves defeated — check count before turning in.
- zu Zug 34 (notiert vor Zug 35): Quest panel still shows 0/4 defeated despite engine confirming B, C, D defeated — recheck before turn-in.
- zu Zug 35 (notiert vor Zug 36): Quest panel still shows 0/4 defeated despite engine confirming three wolves defeated — count may not be recording.
- zu Zug 36 (notiert vor Zug 37): Engine keeps treating my movement as undeclared; wolf A flees at MEDIUM range. Quest count still 0/4 despite three confirmed kills.
- zu Zug 37 (notiert vor Zug 38): Wolf A fled for good; contract count stuck at 0/4 despite three confirmed kills — check #quests and turn in three pelts at the Guild, noting the discrepancy.
- zu Zug 40 (notiert vor Zug 41): Engine flagged previous lodging attempt as 'arrival pending' though HUD shows the Drowned Otter; retrying now that I'm engaged with the innkeeper.
- zu Zug 41 (notiert vor Zug 42): Lodging purchase worked and recovery confirmed; engine bought both beds for 6 cp instead of bed plus stew, though narration implied a 2 cp refund.
- zu Zug 52 (notiert vor Zug 53): Pack fled east after the leader died; only 1/4 wolves counted so far, need 3 more for the contract.
- zu Zug 53 (notiert vor Zug 54): Narrator says three wolves dead, but quest panel showed 1/4 defeated; checking the authoritative quest record.
- zu Zug 55 (notiert vor Zug 56): Quest panel still shows 1/4 defeated despite narrator counting three kills; only engine-recorded kills count.
- zu Zug 57 (notiert vor Zug 58): Engine confirmed the fourth wolf defeated with loot, but the HUD quest line still reads 1/4; checking the quest panel.
- zu Zug 58 (notiert vor Zug 59): Quest panel text was stale (still 1/4) while the engine result confirmed the fourth wolf's defeat; the panel also truncated mid-sentence about the fourth wolf.
- zu Zug 59 (notiert vor Zug 60): Engine counts only 1/4 wolf kills despite four confirmed combat defeats; possible that only kills near the old cuttings population register. Will test by hunting there.
- zu Zug 65 (notiert vor Zug 66): Contract still reads 1/4 despite two fresh defeated wolves; possibly kills must occur in a specific zone or the slip updates only on return.
- zu Zug 69 (notiert vor Zug 70): Narrator flip-flopped: my earlier hall scene was replayed as if it never happened, while the HUD and engine result still place me in the Guild hall with the clerk; treating the HUD as authoritative.
- zu Zug 70 (notiert vor Zug 71): Clerk confirmed the seal counts only kills on the track itself; den kills don't register.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t12 | 13 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t29 | 31 | 3 | – | nein | 3 | gewonnen, 144 XP |
| enc.t43 | 46 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t48 | 51 | 1 | – | nein | 1 | gewonnen, 116 XP |
| enc.t52 | 57 | 1 | – | nein | 1 | gewonnen, 58 XP |
| enc.t56r | 62 | 2 | – | nein | 2 | gewonnen, 82 XP |

## Quests

- **Slay the Millrace Serpent** — active (Zug 6) → completed (Zug 17), READY
  - Aufgabe: Kill 1 old water serpent at the millrace pond below Hessa's mill, Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 old water serpent killed at the millrace pond below Hessa's mill, Ashbridge.
- **Thin the Quarry-Track Wolves** — active (Zug 23)
  - Aufgabe: Kill 4 grey wolves at the old quarry track east of Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 grey wolves killed at the old quarry track east of Ashbridge.
- **Cull the Bog Striders at the Reed Flats** — expired (Zug 43)
  - Aufgabe: Kill 6 bog striders at the eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 6 bog striders killed at the eel-weirs of the Reed Flats.
- **Slay the Hill Boar Called Old Tusk** — expired (Zug 43)
  - Aufgabe: Kill 1 Old Tusk, the huge lone hill boar at the barley fields and wooded slopes south of Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 Old Tusk, the huge lone hill boar killed at the barley fields and wooded slopes south of Ashbridge.
- **Clear Mossback Warrens Level 1** — expired (Zug 43), Dungeon loc.mossback_warrens Ebene 1
  - Aufgabe: Clear level 1 of Mossback Warrens. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Mossback Warrens is clear.
- **Serpent at the Millrace** — active (Zug 44) → completed (Zug 47)
  - Aufgabe: Kill 1 water serpent at the millrace pond below Hessa's mill, Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 water serpent killed at the millrace pond below Hessa's mill, Ashbridge.
- **Cull the Quarry Track Wolves** — active (Zug 72)
  - Aufgabe: Kill 4 grey wolf at the old quarry track east of Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 grey wolf killed at the old quarry track east of Ashbridge.

## Auffälligkeiten

- Zug 38, Nachricht 76 (extraction_repaired): the extractor's first answer needed a repair
- Zug 44, Nachricht 87 (planner_repaired): the planner's first answer needed a repair
- Zug 47, Nachricht 94 (extraction_repaired): the extractor's first answer needed a repair
- Zug 68, Nachricht 136 (extraction_repaired): the extractor's first answer needed a repair
- Zug 72, Nachricht 144 (extraction_failed): the extractor failed: the LLM call failed (HTTP 200: Internal Server Error)
- Zug 72, Nachricht 144 (extraction_repaired): the extractor's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 14× keine gültige JSON-Entscheidung (Züge 5, 9, 10, 25, 26, 31, 37, 38, 45, 48, 50, 59, 62, 67)
- Server: Chat completion request error:  Internal Server Error {"error":{"message":"An unexpected error has occurred.","type":"server_error","code":"internal_server_error","param":null}}

System-Panels: CLARIFY 2, NOT TAKEN 0, REFUSED 3, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: guild_canon 2, guild_canon_price 1, pc_inventory 1, guild_payout 1, offer 3, group_unclear 2, no_go 1, scene_context 13, engine_recovery 1, engine_owned_fact 5, attack_commitment 2, world_rule 2, quest_count 1, ambient 2.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 14/72 Erstantworten ungültig (19.4 %); 14 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 67 | 1 | 2.6 s | 4.9 s | 11908 | 9870 | 75 | – | stop 67 | 0 |
| narrator | 64 | 0 | 8.7 s | 12.1 s | 11329 | 8746 | 403 | – | stop 64 | 0 |
| extract | 68 | 4 | 5.8 s | 9.6 s | 12030 | 9306 | 384 | – | stop 67 | 0 |
| board | 3 | 1 | 9.5 s | 11.9 s | 2555 | 2235 | 1128 | – | stop 3 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 30:56 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 17.2 s) | 0:32 min |
| 72 Züge, Spiel (Senden bis HUD nach der Extraktion) | 24:10 min — Median 19.3 s, p90 28.8 s, max 46.3 s |
| 72 Züge, Spieler-Entscheidung | 5:08 min — Median 2.6 s, 14 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 3:30 min / 0:30 min / 10:22 min / 7:05 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 24.4 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 16:17 min, 80 Züge ≈ 32:33 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spieler | 31 | – | 33.5 s | 2.6 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
