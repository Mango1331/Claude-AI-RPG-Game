# Avereth Live-Test 20261028-180647Z-current_test

## Kurzfassung

- **Laufprofil:** guild-rogue; Startklasse Rogue, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** Niederlage — turn 58: he died
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 2. Sicherheitsgrenzen: 150 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** noch nicht erreicht.
- **Charakter:** rogue (rogue.razor_cut, rogue.evasive_step) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: pragmatic adventurer: sell surplus loot and invest in useful equipment and techniques
- **Züge:** 58 · **Dauer:** 28:58 min · **LLM-Aufrufe der Engine/des Erzählers:** 175
- **Beobachtete Abdeckung:** 7 unterschiedliche gebuchte Reiseziele · 4 Kämpfe · 2 Verkäufe (49 cp Umsatz, ohne Questzahlungen/Geschenke) · 0 Ausrüstungswechsel · 0 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 11 · **Niederlage** in Zug 58: he died
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.114 |
| Git | 89aaf08d1313 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 16.3 s |
| Browser | chrome 156.0.8078.48 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261028-180647Z-current_test“, Seed 314367449 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | Rogue | Engine (Menü/Rückfrage) | creation_complete | Choose the Rogue base class | public roadside verge outside Ashbridge | 90/84 | 2.3 s |
| 2 | I choose Razor Cut and Evasive Step. | Engine (Menü/Rückfrage) | creation_complete | Select two starter skills to finish character creation | public roadside verge outside Ashbridge | 90/84 | 2.2 s |
| 3 | I walk to Ashbridge and head to the Guild hall to look at the contract board. | Erzähler | open_run_level | Find first Guild contract | Adventurers' Guild hall, Ashbridge | 90/84 | 41.6 s |
| 4 | I tell the clerk I'll take the mire adder contract at Sedgehole Pond and ask him to register it for me. | Erzähler | open_run_level | Accept the achievable novice contract | Adventurers' Guild hall, Ashbridge | 90/84 | 25.5 s |
| 5 | I pay the two silver registration fee and ask the clerk to put my name in the book. | Erzähler | open_run_level | Register with the Guild | Adventurers' Guild hall, Ashbridge | 90/84 | 23.6 s |
| 6 | "Take it." I reach for the slip and pen to accept the mire adder contract. | Erzähler | open_run_level | Accept the mire adder contract now that I'm a registered Novice | Adventurers' Guild hall, Ashbridge | 90/84 | 32.1 s |
| 7 | I head east along the shore to the reed bed and move into the knee-deep shallows, watching for the adder's wake. | Erzähler | open_run_level | Hunt the mire adder in the eastern reeds | Sedgehole Pond, at the eel-weirs south of Ashbridge | 90/84 | 19.7 s |
| 8 | I wade out to knee-deep water and move toward the spot where the wake slid into the reeds, dagger ready. | Erzähler | open_run_level | Hunt the mire adder in the reeds | Sedgehole Pond, at the eel-weirs south of Ashbridge | 90/84 | 26.3 s |
| 9 | I strike at the adder's head with Razor Cut the moment it's in reach. | Erzähler | open_run_level | Attack the mire adder | Sedgehole Pond, at the eel-weirs south of Ashbridge | 90/84 | 30.2 s |
| 10 | I step in to close the gap and strike at the adder's head with Razor Cut. | Erzähler | open_run_level | Close to ENGAGED and attack the adder | Sedgehole Pond, at the eel-weirs south of Ashbridge | 90/84 | 18.4 s |
| 11 | I wade back to shore and head back to the Guild hall in Duskreach to turn in the completed mire adder contract. | Erzähler | open_run_level | Turn in the adder contract at the Guild | Adventurers' Guild hall, Ashbridge | 90/84 | 33.7 s |
| 12 | I ask the clerk to check the board for contracts suited to a Novice rogue, and mention I have mire adder parts to sell if anyone buys them. | Erzähler | open_run_level | Find the next contract and sell loot | Adventurers' Guild hall, Ashbridge | 90/84 | 19.4 s |
| 13 | I take the feral dog contract to the clerk and ask her to mark it active, then show Doran my adder skin, fang and venom sac and ask what he'… | Erzähler | open_run_level | Accept dog contract and sell adder parts | Adventurers' Guild hall, Ashbridge | 90/84 | 18.8 s |
| 14 | "I'll take the twenty-six for the lot," I tell Doran, handing over the skin, fang and sac. | Erzähler | open_run_level | Sell adder parts to Doran | Adventurers' Guild hall, Ashbridge | 90/84 | 13.1 s |
| 15 | I head out the east gate and search the old quarry track for the feral dogs. | Erzähler | open_run_level | Travel to quarry track and hunt dogs | old quarry track east of Ashbridge | 90/84 | 18.7 s |
| 16 | I follow the dog prints deeper along the quarry track toward the den. | Erzähler | open_run_level | Track the feral dog pack to their den | old quarry floor den | 90/84 | 19.2 s |
| 17 | I circle wide behind the spoil heaps and strike the grey-muzzled dog from behind with Razor Cut. | Erzähler | open_run_level | Ambush the closest dog to open the fight on my terms | old quarry floor den | 90/84 | 18.4 s |
| 18 | I sprint straight across the open floor and strike the grey-muzzled dog with Razor Cut as I close into range. | Erzähler | open_run_level | Close to ENGAGED and attack Feral Dog A | old quarry floor den | 90/84 | 20.4 s |
| 19 | I close the last strides and strike the grey-muzzled dog with Razor Cut. | Erzähler | open_run_level | Engage and attack Feral Dog A | old quarry floor den | 90/84 | 18.9 s |
| 20 | I spend my level-up points: #assign AGI 2 PER 2 STR 1 | Erzähler | open_run_level | Allocate free stat points after Level 2 | old quarry floor den | 90/84 | 14.3 s |
| 21 | #assign AGI 2 PER 2 STR 1 | System (Befehl) | open_run_level | Re-apply stat allocation the HUD shows as unspent | old quarry floor den | 90/84 | 2.1 s |
| 22 | I charge the two shade-dogs at the slope's foot and strike the closer one with Razor Cut. | Erzähler | open_run_level | Engage the remaining pack dogs for the contract count | old quarry floor den | 90/84 | 37.4 s |
| 23 | I advance toward the two shade-dogs, closing to ENGAGED with the closer one, then strike it with Razor Cut. | Erzähler | open_run_level | Close distance and attack Feral Dog B for the contract | old quarry floor den | 90/84 | 20.3 s |
| 24 | I run straight at Feral Dog B, closing the distance, and strike it with Razor Cut once I'm in range. | Erzähler | open_run_level | Explicitly declare movement to close from LONG to ENGAGED, then attack | old quarry floor den | 90/84 | 28.5 s |
| 25 | I move in on Feral Dog B until I'm engaged with it, then attack it with Razor Cut. | Erzähler | open_run_level | Close to ENGAGED and attack Feral Dog B | old quarry floor den | 84/84 | 28.9 s |
| 26 | I strike Feral Dog C with Razor Cut. | Erzähler | open_run_level | Finish the last dog for the contract count | old quarry floor den | 84/84 | 15.2 s |
| 27 | I travel back to the Ashbridge Guild hall and turn in the contract 'Thin the Feral Dog Pack on the Quarry Track'. | Erzähler | open_run_level | Turn in completed dog contract at the Guild | Adventurers' Guild hall, Ashbridge | 84/84 | 15.4 s |
| 28 | I tell the clerk the work is done — I defeated four feral dogs on the quarry track — and ask her how the count can be confirmed or fixed. | Erzähler | open_run_level | Resolve the contract count discrepancy | Adventurers' Guild hall, Ashbridge | 84/84 | 23.4 s |
| 29 | I tell Marda I'll go tonight, and head up the quarry track to Hedwin Corr's stone cottage above the workings. | Erzähler | open_run_level | Get client confirmation for the dog contract tonight | Hedwin Corr's stone cottage | 84/84 | 37.5 s |
| 30 | "Evening, mistress. Marda at the Guild evening desk sent me — four feral dogs killed on the quarry track today, and she needs your word to s… | Erzähler | open_run_level | Get Hedwin's confirmation for the dog contract | Hedwin Corr's stone cottage | 84/84 | 32.2 s |
| 31 | "Alaric Red, Rogue out of the Ashbridge Guild. If the offer holds, I'll take that bench by the fire and wait for daylight — much obliged, mi… | Erzähler | open_run_level | Accept Hedwin's shelter and wait for her morning walk of the track | Hedwin Corr's stone cottage | 84/84 | 55.3 s |
| 32 | A bowl would be welcome, mistress — thank you. Then I'll walk down to Ashbridge and see the desk about my coin. | Erzähler | open_run_level | Take porridge, then return to the Guild to turn in the confirmed contract | Ashbridge | 84/84 | 29.3 s |
| 33 | I enter the Guild hall and turn in the contract 'Thin the Feral Dog Pack on the Quarry Track' — Hedwin Corr has confirmed the count of four. | Erzähler | open_run_level | Turn in the confirmed dog contract at the Guild hall | Adventurers' Guild hall, Ashbridge | 84/84 | 35.1 s |
| 34 | "Yes — four, killed yesterday on the quarry track, and Hedwin walked it herself this morning and counted the bodies. Note my claim, and I'll… | Erzähler | open_run_level | Have the clerk record my claim; return after Marda posts Hedwin's word | Adventurers' Guild hall, Ashbridge | 84/84 | 22.7 s |
| 35 | I ask Doran his rates on three feral dog pelts and seven fangs. | Erzähler | open_run_level | Get an offer for surplus loot before the midday turn-in | Adventurers' Guild hall, Ashbridge | 84/84 | 53.1 s |
| 36 | "Deal — twenty-three copper for the lot." I hand Doran the three pelts and seven fangs and take the coins. | Erzähler | open_run_level | Sell surplus loot to Doran at his named rates | Adventurers' Guild hall, Ashbridge | 84/84 | 32.9 s |
| 37 | While I wait for the midday bell, I go to the contract board and look for a Novice contract I can take this morning. | Erzähler | open_run_level | Pick up another achievable Guild contract while waiting for the turn-in | Adventurers' Guild hall, Ashbridge | 84/84 | 44.7 s |
| 38 | I check the Guild shop counter and buy the Primer of Bolt for 80 copper. | Erzähler | open_run_level | Learn a useful new skill while waiting for midday | Adventurers' Guild hall, Ashbridge | 84/84 | 31.1 s |
| 39 | I take the Primer of Bolt out to the yard range and study it, practicing the hand positions on a target until I can use the skill. | Erzähler | open_run_level | Learn the bolt skill from the purchased primer | butt range behind the Guild hall | 84/84 | 19.6 s |
| 40 | I sit at the near butt and study the Primer of Bolt, working through the diagrams and practicing the grip and hand positions on the crossbow… | Engine (Menü/Rückfrage) | open_run_level | Learn bolt skill from the primer at the yard range | butt range behind the Guild hall | 84/84 | 7.3 s |
| 41 | I sit at the near butt and study the Primer of Bolt for 2 hours, working through the diagrams and practicing the grip and hand positions on … | Erzähler | open_run_level | Learn bolt skill with a named study duration | butt range behind the Guild hall | 84/84 | 20.6 s |
| 42 | I pack up the primer and head back inside to find Doran, asking if we should walk out to the quarry now to hear Hedwin's side before the rol… | Erzähler | open_run_level | Follow up on the quarry lead before midday | Adventurers' Guild hall, Ashbridge | 84/84 | 35.1 s |
| 43 | I tell Doran I only want his opinion, not his company, and set out east past the toll field for Hedwin Corr's place at the quarry. | Erzähler | open_run_level | Walk to the quarry to hear Hedwin's side before the roll turns | Hedwin Corr's stone cottage | 84/84 | 31.0 s |
| 44 | I introduce myself: "Alaric Red, out of the Guild in Duskreach. I'm carrying the dog-pack contract — Marda's seal on it. I'd like to hear yo… | Erzähler | open_run_level | Speak with Hedwin about the dog contract | Hedwin Corr's stone cottage | 84/84 | 25.9 s |
| 45 | I answer Hedwin: "The Guild can write it that way. I'll carry your terms back to Marda — four dogs, the deep wild hunters only, and the two … | Erzähler | open_run_level | Relay Hedwin's terms to Marda before the seal goes firm | Hedwin Corr's stone cottage | 84/84 | 23.2 s |
| 46 | I accept the porridge, then walk back west to Duskreach to find Marda at the market and relay Hedwin's terms before the seal goes firm. | Erzähler | open_run_level | Carry Hedwin's terms back to Marda | Adventurers' Guild hall, Ashbridge | 84/84 | 40.1 s |
| 47 | I answer Marda: "Then hold your confirmation a day or two as you offered. I'm the one who'll work it — I'll watch the fence line at dusk and… | Erzähler | open_run_level | Secure Marda's hold on the confirmation and keep the contract mine | Adventurers' Guild hall, Ashbridge | 84/84 | 40.9 s |
| 48 | I head out of the Guild hall and walk east toward the quarry track to scout the fence line at dusk before starting the cull. | Erzähler | open_run_level | Scout the quarry track before hunting | old quarry track east of Ashbridge | 84/84 | 37.1 s |
| 49 | I shadow the three wild dogs that swung back north toward the cutting, keeping to cover, and strike the rearmost one with my dagger when I'm… | Engine (Menü/Rückfrage) | open_run_level | Ambush a wild dog to start the cull | old quarry track east of Ashbridge | 84/84 | 12.9 s |
| 50 | I shadow Feral Dog F, the rearmost of the three wild dogs moving north, and strike it with my dagger from cover. | Erzähler | open_run_level | Ambush the rearmost wild dog to start the cull | old quarry track east of Ashbridge | 84/84 | 19.9 s |
| 51 | I circle wide through the spoil heaps to get ahead of the pack's line of travel, then wait in cover at the rabbit run for Feral Dog F to pas… | Erzähler | open_run_level | Close to ambush range before attacking Feral Dog F | old quarry track east of Ashbridge | 84/84 | 17.3 s |
| 52 | I use Razor Cut on Feral Dog H, the one within engaged range. | Erzähler | open_run_level | Attack the dog confirmed in engaged range | old quarry track east of Ashbridge | 67/84 | 19.8 s |
| 53 | I use Razor Cut on Feral Dog H again to finish it before the others close. | Erzähler | open_run_level | Kill the wounded engaged dog | old quarry track east of Ashbridge | 67/84 | 14.9 s |
| 54 | I step back with Evasive Step to put distance on the two dogs, then strike Feral Dog F with Razor Cut. | Erzähler | open_run_level | Manage two dogs at SHORT by moving back one band before attacking | old quarry track east of Ashbridge | 67/84 | 16.6 s |
| 55 | I use Razor Cut on Feral Dog F. | Erzähler | open_run_level | Damage the engaged sentry dog | old quarry track east of Ashbridge | 67/84 | 22.6 s |
| 56 | I hold my ground and let the dogs come to me, ready to strike with my dagger whichever one lunges into engaged range first. | Erzähler | open_run_level | Bait a lunge into engaged range before attacking | old quarry track east of Ashbridge | 37/84 | 21.9 s |
| 57 | I use Razor Cut on Feral Dog F, the wounded one at ENGAGED range. | Erzähler | open_run_level | Kill the injured sentry dog | old quarry track east of Ashbridge | 8/84 | 22.4 s |
| 58 | I use Razor Cut on Feral Dog F to finish it before it strikes again. | Erzähler | open_run_level | Kill the nearly dead dog | old quarry track east of Ashbridge | 0/84 | 16.6 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 20 (notiert vor Zug 21): HUD still shows Free Stat Points 5 despite the narrator confirming the assignment; re-issuing the command.
- zu Zug 23 (notiert vor Zug 24): Engine rejects attacks unless movement is declared as a separate part of the action; prior messages named closing but were not accepted as declared movement.
- zu Zug 24 (notiert vor Zug 25): Dogs flanked to SHORT range; movement as a separate declared step seems required before the attack resolves.
- zu Zug 27 (notiert vor Zug 28): Turn-in refused: engine counts 0/4 feral dogs despite COMBAT END confirming four defeats; possible count registration bug.
- zu Zug 32 (notiert vor Zug 33): Turn-in previously refused because location was Hedwin's cottage, not the Guild hall; now back in Ashbridge.
- zu Zug 41 (notiert vor Zug 42): Bolt study only gave LP (15/100), skill not learned yet.
- zu Zug 43 (notiert vor Zug 44): HUD journal text is stale — mentions a chained door and a woman, but the engine scene shows Hedwin Corr as a man with an open door.
- zu Zug 46 (notiert vor Zug 47): HUD journal text is stale — it describes Hedwin as a woman with a chained door; the engine scene shows a man with an open door.
- zu Zug 51 (notiert vor Zug 52): Narration showed my ambush strike on Feral Dog F beginning, but the HUD still lists F at LONG and H as the only ENGAGED dog — no kill confirmed, quest count still 0/4.
- zu Zug 57 (notiert vor Zug 58): HP 8/95 and a third dog descending — this fight may be unwinnable; if F falls and another bite lands I may need to retreat.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t10 | 10 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t19 | 19 | 1 | – | nein | 1 | gewonnen, 48 XP |
| enc.t24 | 25 | 2 | – | nein | 2 | gewonnen, 48 XP |
| enc.t49 | 52 | 3 | – | nein | 2 | **tot** |

## Quests

- **Cull the Mire Adder at Sedgehole Pond** — active (Zug 6) → completed (Zug 11), READY
  - Aufgabe: Kill 1 mire adder at Sedgehole Pond, at the eel-weirs south of Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 mire adder killed at Sedgehole Pond, at the eel-weirs south of Ashbridge.
- **Thin the Feral Dog Pack on the Quarry Track** — active (Zug 13)
  - Aufgabe: Kill 4 feral dogs at old quarry track east of Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 feral dogs killed at old quarry track east of Ashbridge.

## Auffälligkeiten

- Zug 6, Nachricht 12 (extraction_repaired): the extractor's first answer needed a repair
- Zug 8, Nachricht 16 (extraction_repaired): the extractor's first answer needed a repair
- Zug 28, Nachricht 56 (extraction_repaired): the extractor's first answer needed a repair
- Zug 29, Nachricht 58 (extraction_repaired): the extractor's first answer needed a repair
- Zug 30, Nachricht 60 (extraction_repaired): the extractor's first answer needed a repair
- Zug 32, Nachricht 64 (extraction_repaired): the extractor's first answer needed a repair
- Zug 37, Nachricht 73 (board_failed): the board generator failed
- Zug 37, Nachricht 74 (extraction_repaired): the extractor's first answer needed a repair
- Zug 43, Nachricht 85 (planner_repaired): the planner's first answer needed a repair
- Zug 43, Nachricht 86 (extraction_repaired): the extractor's first answer needed a repair
- Zug 46, Nachricht 92 (extraction_repaired): the extractor's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 18× keine gültige JSON-Entscheidung (Züge 7, 9, 10, 14, 16, 18, 20, 28, 34, 35, 36, 39, 42, 45, 46, 47, 48, 49)

System-Panels: CLARIFY 2, NOT TAKEN 1, REFUSED 2, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: guild_canon_price 1, no_go 1, scene_context 7, ambient 4, world_rule 13, engine_owned_fact 6, quest_count 1, quest_dependency 1, guild_canon 2.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 18/58 Erstantworten ungültig (31.0 %); 18 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 56 | 1 | 2.4 s | 7.5 s | 11711 | 9871 | 77 | – | stop 56 | 0 |
| board | 4 | 2 | 9.6 s | 14.1 s | 3014 | 2516 | 981 | – | stop 4 | 0 |
| narrator | 53 | 0 | 9.7 s | 17.9 s | 11519 | 8820 | 370 | – | stop 53 | 0 |
| extract | 62 | 9 | 6.2 s | 11.6 s | 11842 | 9302 | 360 | – | stop 62 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 28:58 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 16.3 s) | 0:30 min |
| 58 Züge, Spiel (Senden bis HUD nach der Extraktion) | 23:48 min — Median 22.5 s, p90 40.1 s, max 55.3 s |
| 58 Züge, Spieler-Entscheidung | 3:47 min — Median 3.1 s, 18 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 3:26 min / 0:40 min / 9:45 min / 7:48 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 28.5 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 19:01 min, 80 Züge ≈ 38:03 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Provider narrator | 35 | 103 | 31.5 s | 9.7 s |
| Provider extract | 31 | 91 | 35.1 s | 6.2 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
