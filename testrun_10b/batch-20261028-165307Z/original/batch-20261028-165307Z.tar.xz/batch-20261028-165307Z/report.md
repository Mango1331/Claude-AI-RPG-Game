# Avereth – 3 natürliche Testkampagnen

Status: **completed**. Serie abgeschlossen bedeutet, dass die Läufe beendet sind; es bedeutet nicht 3 bestandene Level-15-Abnahmen.

| Nr. | Profil | Seed | Eingaben | Level | Ende | Originalbericht |
|---|---|---:|---:|---:|---|---|
| 1 | guild-warrior | 314367447 | 72 | 3 | extractor_failed | [report.md](001-guild-warrior/20261028-165308Z-current_test/report.md) |
| 2 | guild-mage | 314367448 | 89 | 7 | defeat | [report.md](002-guild-mage/20261028-172407Z-current_test/report.md) |
| 3 | guild-rogue | 314367449 | 58 | 2 | defeat | [report.md](003-guild-rogue/20261028-180647Z-current_test/report.md) |

