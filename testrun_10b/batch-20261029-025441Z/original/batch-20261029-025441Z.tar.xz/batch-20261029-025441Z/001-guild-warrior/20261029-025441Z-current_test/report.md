# Avereth Live-Test 20261029-025441Z-current_test

## Kurzfassung

- **Laufprofil:** guild-warrior; Startklasse Warrior, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** abgebrochen: Limit erreicht — 150 turns
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 6. Sicherheitsgrenzen: 150 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** Level 4, 30 XP seit Levelaufstieg, 39 cp, HP 155, MP 84; Ort loc.dunlow.the_lamb. Ausrüstung und Skills stehen in evaluation.json → progression.checkpoint.
- **Charakter:** warrior (warrior.heavy_slash, warrior.quick_slash) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: pragmatic adventurer: sell surplus loot and invest in useful equipment and techniques
- **Züge:** 150 · **Dauer:** 75:52 min · **LLM-Aufrufe der Engine/des Erzählers:** 440
- **Beobachtete Abdeckung:** 38 unterschiedliche gebuchte Reiseziele · 10 Kämpfe · 1 Verkäufe (30 cp Umsatz, ohne Questzahlungen/Geschenke) · 0 Ausrüstungswechsel · 0 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 32
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.115 |
| Git | 9c65e9ada6a2 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 51.7 s |
| Browser | chrome 156.0.8078.49 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261029-025441Z-current_test“, Seed 254542102 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | Warrior | Engine (Menü/Rückfrage) | creation_complete | Choose Warrior as base class | public roadside verge outside Alderwatch | 90/84 | 2.1 s |
| 2 | I choose Heavy Slash and Quick Slash as my two skills. | Engine (Menü/Rückfrage) | creation_complete | Complete Warrior creation | public roadside verge outside Alderwatch | 95/84 | 2.1 s |
| 3 | I walk to Alderwatch and head for the Guild hall to look at the contract board. | Erzähler | open_run_level | Reach the Guild and find a starter contract | Adventurers' Guild hall, Alderwatch | 95/84 | 41.1 s |
| 4 | I approach the clerk and ask how to register with the Guild as an adventurer. | Erzähler | open_run_level | Register with the Guild so I can take official contracts | Adventurers' Guild hall, Alderwatch | 95/84 | 16.1 s |
| 5 | Yes, I'll register. I hand over the two silver, sign the slip, and place my hand on the measuring stone. | Erzähler | open_run_level | Register with the Guild | Adventurers' Guild hall, Alderwatch | 95/84 | 20.7 s |
| 6 | I ask the clerk if there's any work or training available before the midday postings, or if there's anything else a new Novice should know. | Erzähler | open_run_level | Gather useful info while waiting for the board | Adventurers' Guild hall, Alderwatch | 95/84 | 38.8 s |
| 7 | I'll take the Mire Lynx contract — it's the one suited to my level. | Erzähler | open_run_level | Accept the achievable Novice contract | Adventurers' Guild hall, Alderwatch | 95/84 | 15.3 s |
| 8 | I leave the Guild and walk down through the mill gate to the millpond reed bank to hunt the mire lynx, asking Ferrow the miller where he's l… | Erzähler | open_run_level | Travel to the contract site and gather a lead from the client | the reed bank of the Alderwatch millpond | 95/84 | 31.6 s |
| 9 | I head north along the reed bank toward the old mooring posts and search the thick reeds for the lynx or its tracks. | Erzähler | open_run_level | Hunt the mire lynx at its reported spot | the old mooring posts | 95/84 | 18.5 s |
| 10 | I follow the lynx's trail fifty paces into the reedbed toward the willow hummock, keeping low and quiet, sword drawn. | Erzähler | open_run_level | Track and hunt the mire lynx | the willow hummock | 95/84 | 17.7 s |
| 11 | I swing my sword in a Heavy Slash at the lynx as it springs at me. | Erzähler | open_run_level | Fight the mire lynx | the willow hummock | 95/84 | 13.3 s |
| 12 | I skin nothing further and head back along the reed bank to the Guild hall in Valedorn to turn in the completed Cull the Mire Lynx contract. | Erzähler | open_run_level | Turn in the finished contract | Adventurers' Guild hall, Alderwatch | 95/84 | 20.3 s |
| 13 | I ask the clerk what's on the Novice board today, and check for anything suited to my level. | Erzähler | open_run_level | Pick the next contract from the board | Adventurers' Guild hall, Alderwatch | 95/84 | 12.8 s |
| 14 | I tell the clerk I'll take the Cull the Orchard Strikers contract, and ask her to mark it active for me. | Erzähler | open_run_level | Accept the orchard strikers cull contract | Adventurers' Guild hall, Alderwatch | 95/84 | 14.9 s |
| 15 | I set out south on the crown road for Bramblewick, and on arrival ask at the orchard gates for the damaged rows where the whip-tailed strike… | Erzähler | open_run_level | Travel to Bramblewick and start the striker hunt | the Bramblewick cider orchards | 95/84 | 20.3 s |
| 16 | I head into the north strip past the second windbreak, sword drawn, and search the damaged rows for the whip-tailed strikers. | Erzähler | open_run_level | Hunt the strikers | the north strip past the second windbreak | 95/84 | 18.3 s |
| 17 | I move quietly up the row toward the pale thing in the lower branches, sword ready, watching for movement. | Erzähler | open_run_level | Investigate the sign and find the strikers | the striker larder branch | 91/84 | 21.3 s |
| 18 | I attack the striker with a Heavy Slash. | Erzähler | open_run_level | Fight the striker | the striker larder branch | 91/84 | 15.8 s |
| 19 | #assign STR 3 VIT 2 | System (Befehl) | open_run_level | Spend level-up points on STR and VIT | the striker larder branch | 91/84 | 2.1 s |
| 20 | I continue along the row toward the dark barrel-mouth hole under the hedgerow roots, watching the trampled grass for more strikers. | Erzähler | open_run_level | Continue hunting the remaining strikers near the burrow | the striker den under the hedgerow roots | 91/84 | 18.0 s |
| 21 | I back off a few paces from the den mouth, then ready my sword and provoke whatever is inside to come out where I can fight it. | Erzähler | open_run_level | Draw the den's striker out into the open | the striker den under the hedgerow roots | 91/84 | 18.0 s |
| 22 | I meet its charge with a Heavy Slash aimed at its neck as it closes. | Erzähler | open_run_level | Fight Striker B | the striker den under the hedgerow roots | 75/84 | 14.7 s |
| 23 | I finish it with a Basic Attack to the neck. | Erzähler | open_run_level | Kill the wounded striker | the striker den under the hedgerow roots | 75/84 | 13.3 s |
| 24 | #assign STR 3 VIT 2 | System (Befehl) | open_run_level | Spend level-up points | the striker den under the hedgerow roots | 75/84 | 2.1 s |
| 25 | I peer into the den mouth, sword ready, listening for what is still inside. | Erzähler | open_run_level | Investigate the den for the remaining strikers | the striker den under the hedgerow roots | 75/84 | 13.8 s |
| 26 | I sit down a few paces from the den mouth, sword across my knees, and wait to see whether the young striker works up the nerve to come out. | Erzähler | open_run_level | Wait out the young striker hiding in the den | the striker den under the hedgerow roots | 75/84 | 18.3 s |
| 27 | I stand and charge the young striker at the den mouth, cutting it down with a Heavy Slash before it can retreat inside. | Erzähler | open_run_level | Kill Striker C to finish the cull contract | the striker den under the hedgerow roots | 75/84 | 21.3 s |
| 28 | I rush the young striker and cut it down with a Quick Slash as I close the distance. | Erzähler | open_run_level | Kill Striker C with a closing attack | the striker den under the hedgerow roots | 75/84 | 16.2 s |
| 29 | I dig at the den mouth with my sword and a broken branch, trying to widen or collapse the entrance enough to reach the young striker inside. | Erzähler | open_run_level | Flush or expose the retreated striker | the striker den under the hedgerow roots | 75/84 | 22.2 s |
| 30 | I back off a few paces, stand ready at the widened den mouth, and wait for the young striker to come out or come to the bend. | Erzähler | open_run_level | Wait at the den mouth to catch the cornered striker | the striker den under the hedgerow roots | 75/84 | 34.5 s |
| 31 | I smoke it out: I gather dry grass and the broken branch, pile them at the widened den mouth, and light a small smoldering fire to drive the… | Erzähler | open_run_level | Flush the hiding striker with smoke | the striker den under the hedgerow roots | 75/84 | 22.8 s |
| 32 | I hold my stance beside the smoking den mouth and cut the young striker down with a Heavy Slash the instant it breaks the surface. | Engine (Menü/Rückfrage) | open_run_level | Kill Striker C as it bolts from the smoke | the striker den under the hedgerow roots | 75/84 | 4.5 s |
| 33 | I stay ready at the smoking den mouth and attack the young striker with a Heavy Slash the moment it emerges from the tunnel. | Engine (Menü/Rückfrage) | open_run_level | Kill Striker C as it exits the smoke-filled den | the striker den under the hedgerow roots | 75/84 | 4.2 s |
| 34 | I step back from the smoke and keep my sword up, waiting for the striker to actually surface so it becomes a target I can strike. | Erzähler | open_run_level | Let the striker emerge as a targetable actor before attacking | the striker den under the hedgerow roots | 75/84 | 26.6 s |
| 35 | I cut the young striker down with a Heavy Slash while it's still staggered and half blind. | Erzähler | open_run_level | Kill Striker C to reach 3/4 | the striker den under the hedgerow roots | 75/84 | 22.1 s |
| 36 | I sprint after the fleeing striker and cut it down with a Quick Slash as soon as I close into range. | Erzähler | open_run_level | Chase and kill Striker C to reach 3/4 | the striker den under the hedgerow roots | 75/84 | 19.6 s |
| 37 | I keep sprinting after the fleeing striker, closing to ENGAGED range, and strike it with a Quick Slash. | Erzähler | open_run_level | Close the gap and kill Striker C | the striker den under the hedgerow roots | 75/84 | 18.3 s |
| 38 | I close the last stride to ENGAGED range and cut the fleeing striker down with a Quick Slash. | Erzähler | open_run_level | Close to ENGAGED and kill Striker C for 3/4 | the striker den under the hedgerow roots | 75/84 | 14.3 s |
| 39 | I head back to the striker den under the hedgerow and check it for the fourth striker, sword ready. | Erzähler | open_run_level | Hunt the fourth striker in the den | the striker den under the hedgerow roots | 75/84 | 21.4 s |
| 40 | I search the trampled ground around the den for fresh tracks leading away, and follow any trail I find. | Erzähler | open_run_level | Track the fourth striker before full dark | the striker den under the hedgerow roots | 75/84 | 20.6 s |
| 41 | I give up the search for tonight and head back to Bramblewick to find lodging and sleep until morning. | Erzähler | open_run_level | Recover overnight, hunt the fourth striker at dawn | Bramblewick | 75/84 | 36.3 s |
| 42 | I enter the inn and ask for a room for the night. | Erzähler | open_run_level | Get lodging and sleep until morning | the inn on the village lane | 75/84 | 19.6 s |
| 43 | I take the room for the night and the supper, pay the 2 silver 5 copper, and head to bed after eating, sleeping until morning. | Erzähler | open_run_level | Buy lodging and supper, then sleep | the inn on the village lane | 135/84 | 20.7 s |
| 44 | After breakfast I ask the innkeeper where I might find old Hessel, the picker who was struck by a whip-tailed striker. | Erzähler | open_run_level | Follow the rumor lead about Hessel | the inn on the village lane | 135/84 | 17.8 s |
| 45 | I follow the orchard lane from the well to the pickers' hut past the presses and look for Hessel. | Erzähler | open_run_level | Visit old Hessel for a lead on the fourth striker | the pickers' hut | 135/84 | 21.9 s |
| 46 | "I'm Guild," I say, showing my plate and the contract slip. "Hessel, can you tell me where the strikers nest? I've taken three already and n… | Erzähler | open_run_level | Get a lead on the fourth striker from Hessel | the pickers' hut | 135/84 | 25.0 s |
| 47 | I ask Hessel to mark out the two scratch trees along the north wall, then head into the old wood rows to find the fourth striker before the … | Erzähler | open_run_level | Hunt the old cock striker using Hessel's lead | the old wood rows along the north wall | 135/84 | 33.1 s |
| 48 | I follow the beaten low path north from the scratch tree toward the stream fold, sword drawn, watching the bramble for the old cock striker. | Erzähler | open_run_level | Track the fourth striker via its run | the old wood rows along the north wall | 135/84 | 38.1 s |
| 49 | I meet the old cock's charge with Heavy Slash, aiming to catch it as it leaps from the bramble. | Erzähler | open_run_level | Attack the fourth striker | the old wood rows along the north wall | 135/84 | 21.5 s |
| 50 | Now in range, I swing Heavy Slash at the old cock as it coils to strike. | Erzähler | open_run_level | Attack the fourth striker now that it is in range | the old wood rows along the north wall | 135/84 | 24.5 s |
| 51 | I close the ten paces straight at the old cock and, once ENGAGED, swing Heavy Slash at it as it strikes. | Erzähler | open_run_level | Close to ENGAGED and attack the fourth striker | the old wood rows along the north wall | 135/84 | 37.5 s |
| 52 | "Aye, that's my kill—the fourth and last striker, Guild work," I call back, then shoulder my pack and head for the Guild hall in Bramblewick… | Erzähler | open_run_level | Claim the kill and turn in the contract | the old wood rows along the north wall | 135/84 | 28.0 s |
| 53 | I set off east along the road past the mill toward Dunlow's market hall, a day's walk, to turn in Cull the Orchard Strikers at the Guild cou… | Erzähler | open_run_level | Travel to the nearest Guild hall for the turn-in | the old wood rows along the north wall | 135/84 | 26.3 s |
| 54 | I take the copper and set my shoulder to the wheel rim, lifting while the wagon woman packs the rut with stones. | Erzähler | open_run_level | Help free the wagon for 1 copper, then continue toward Dunlow | the old wood rows along the north wall | 135/84 | 35.1 s |
| 55 | I go to the Guild counter inside the west door of the Dunlow market hall and turn in Cull the Orchard Strikers with the contract slip. |  | open_run_level | Turn in the completed contract at the Dunlow Guild counter | the old wood rows along the north wall | 135/84 | 42.0 s |
| 56 | I ask the clerk where the Lamb is, then head there and take a bed for the night. | Erzähler | open_run_level | Lodge overnight in Dunlow before catching the morning ferry to Millbrook | the Lamb | 135/84 | 24.3 s |
| 57 | "I'll take the bed and the pottage—six copper, coin now." I pay the landlady and eat, then sleep until morning. | Erzähler | open_run_level | Buy lodging and sleep overnight at the Lamb | the Lamb | 135/84 | 15.3 s |
| 58 | I set out from the Lamb along the river road to Stony Ford, aiming to catch the morning ferry to Millbrook. | Erzähler | open_run_level | Travel toward the Millbrook Guild branch for the turn-in | Stony Ford | 135/84 | 25.8 s |
| 59 | I pay the ferryman a copper and board, riding across to Millbrook. | Erzähler | open_run_level | Cross at Stony Ford toward the Millbrook Guild branch | Millbrook | 135/84 | 15.5 s |
| 60 | I go to the Guild post near the square and turn in Cull the Orchard Strikers with the contract slip. | Erzähler | open_run_level | Turn in the completed contract at the Millbrook Guild post | Guild message post near the square | 135/84 | 40.4 s |
| 61 | I take the slip back and head up Water Street past the mill to the Guild hall, then turn in Cull the Orchard Strikers with Master Oren at th… | Erzähler | open_run_level | Turn in the contract at the proper Millbrook Guild hall | Guild message post near the square | 135/84 | 27.3 s |
| 62 | I take the slip back and walk south out of town along the lane to Bramblewick, then turn in Cull the Orchard Strikers at the Bramblewick Gui… | Erzähler | open_run_level | Travel to Bramblewick to turn in the contract at its issuing hall | Bramblewick branch Guild hall | 135/84 | 26.0 s |
| 63 | I ask Clerk C to record my feather and talon proof against the posting and request a transfer to Millbrook, since both halls point at each o… | Erzähler | open_run_level | Break the turn-in loop via the transfer route the clerks mentioned | Bramblewick branch Guild hall | 135/84 | 22.8 s |
| 64 | Have the letter written and sent regardless, then I walk back up to Millbrook and present the seal to Master Oren once more. | Erzähler | open_run_level | Retry the turn-in at Oren's counter with the recorded proof and transfer letter behind me | Bramblewick branch Guild hall | 135/84 | 19.4 s |
| 65 | I accept: write and seal the letter for three coppers, then I walk back to Millbrook and present the slip and seal to Master Oren once more. | Erzähler | open_run_level | Pay for the sealed letter and retry the turn-in at Millbrook | Millbrook | 135/84 | 22.7 s |
| 66 | I lay the contract slip on the counter and ask Master Oren to close out Cull the Orchard Strikers and pay the reward. | Erzähler | open_run_level | Turn in the contract at Millbrook with the slip and sealed letter behind me | Millbrook | 135/84 | 18.6 s |
| 67 | I thank Oren and head east out of Millbrook along the road past the mill, walking toward Dunlow, and on arrival I go to the Guild hall there… | Erzähler | open_run_level | Travel to the true Guild hall at Dunlow and turn in the contract | Dunlow | 135/84 | 23.7 s |
| 68 | I go into the tavern, buy a room for the night and a hot meal, and ask the innkeeper where the nearest true Guild hall with a paying counter… | Erzähler | open_run_level | Recover overnight and get a real lead on a paying Guild hall | the Lamb | 135/84 | 35.2 s |
| 69 | I accept the innkeeper's offer and pay three coppers for the stew and the room, then eat, go up, and sleep until morning. | Engine (Menü/Rückfrage) | open_run_level | Buy lodging and meal, sleep until morning to recover | the Lamb | 135/84 | 8.3 s |
| 70 | I pay 5 cp for the room and stew, then eat, go up, and sleep until morning. | Erzähler | open_run_level | Pay the clarified price, eat and sleep until morning | the Lamb | 135/84 | 24.6 s |
| 71 | I head north out of Bramblewick toward Harrowgate, and once I arrive I go to the Guild hall there to turn in Cull the Orchard Strikers. | Erzähler | open_run_level | Travel to the paying Guild hall at Harrowgate and turn in the contract | Harrowgate | 135/84 | 35.7 s |
| 72 | I ask the carter which of the two, Crownheart or Marlesford, is closer, and which road to take. | Erzähler | open_run_level | Get directions to a real paying Guild hall | Harrowgate | 135/84 | 17.6 s |
| 73 | I ask the carter for lodging he'd recommend in Harrowgate for the night, then head there to sleep until morning. | Erzähler | open_run_level | Overnight in Harrowgate before the half-day walk to Marlesford | the Woolpack | 135/84 | 33.4 s |
| 74 | I set out from Harrowgate down the river road west toward Marlesford, and when I arrive I look for a Guild hall with a paying counter there. | Erzähler | open_run_level | Travel to Marlesford to find a paying Guild hall and turn in the striker contract | the Marlesford Guildhouse | 135/84 | 44.0 s |
| 75 | I ask the caretaker: since there's no paying clerk here, do the notices on the board pay out through the town itself, or do any offer reward… | Erzähler | open_run_level | Check whether Marlesford's board offers work with collectable pay before committing to the… | the Marlesford Guildhouse | 135/84 | 22.3 s |
| 76 | I go outside and read the Guild board, looking for private notices with a name and door to knock at. | Erzähler | open_run_level | Find payable work on the Marlesford board | the Guild board outside | 135/84 | 33.3 s |
| 77 | I go back inside and ask the caretaker whether she knows of anyone in town with paid work to offer—a woolmaster, the mill, a farmer—since th… | Erzähler | open_run_level | Find private paid work in Marlesford via the caretaker | the Marlesford Guildhouse | 135/84 | 26.5 s |
| 78 | I head to the big mill by the bridge and find Dace the miller about the rat problem. | Erzähler | open_run_level | Take the miller's rat-culling work | the big mill by the bridge | 135/84 | 48.8 s |
| 79 | I accept Dace's terms—two copper a tail, all the big greys gone—and ask him to show me into the grain store and wheel housing so I can start… | Erzähler | open_run_level | Take the miller's rat-culling job | the big mill by the bridge | 135/84 | 33.0 s |
| 80 | I take the lamp and go down into the wheel pit, drawing my sword, and strike at the big grey rat gnawing on the timber. | Erzähler | open_run_level | Start culling the mill rats, beginning with the one in the wheel pit | the wheel pit | 135/84 | 25.2 s |
| 81 | I press my attack on Big Grey Rat A, pinning it to the timber and cutting it down, keeping my back to the pit wall so Rat B can't drop onto … | Erzähler | open_run_level | Kill the engaged big grey rat | the wheel pit | 135/84 | 24.3 s |
| 82 | #assign STR 3 VIT 2 | System (Befehl) | open_run_level | Spend level-up points | the wheel pit | 135/84 | 2.5 s |
| 83 | I call up to Dace that I got one big grey, and go hunting the rest—checking behind the pit boards for the rats that fled. | Erzähler | open_run_level | Continue the rat cull | the wheel pit | 135/84 | 15.3 s |
| 84 | I call up to Dace that the pit's empty for now—the rest ran deep into the timbers—and ask him to let me into the grain store to hunt the gre… | Erzähler | open_run_level | Continue rat cull in the grain store | the wheel pit | 135/84 | 17.2 s |
| 85 | I take the lamp down the lane between the sack stacks toward the gnawing at the far corner, sword drawn, and hunt the big greys there. | Erzähler | open_run_level | Continue the rat cull in the grain store | the wheel pit | 135/84 | 17.4 s |
| 86 | I set the lamp on a sack by the chewed corner and stand back in shadow, sword ready, waiting to see if the greys return to feed. | Erzähler | open_run_level | Ambush the grain store rats | the wheel pit | 135/84 | 21.1 s |
| 87 | I rush the smaller rat at the spilled grain and cut it down with a Quick Slash before it can bolt. | Erzähler | open_run_level | Attack the feeding rat first | the wheel pit | 135/84 | 21.9 s |
| 88 | I step in to ENGAGED and cut the smaller rat down with a Quick Slash before it can bolt. | Erzähler | open_run_level | Close distance then attack the rat | the wheel pit | 135/84 | 13.0 s |
| 89 | I collect the tail from the dead rat and tell Dace the big greys are gone from both the wheel pit and grain store, then ask him to pay two c… | Erzähler | open_run_level | Sell rat tails to Dace and close out the rat work | the wheel pit | 135/84 | 23.7 s |
| 90 | I take the four coppers and ask Dace where the nearest Guild hall is, since I have a finished striker cull contract to turn in. | Erzähler | open_run_level | Get paid for rat tails and find a Guild hall for the turn-in | the wheel pit | 135/84 | 22.7 s |
| 91 | I take a cheap bed at the Wandering Buck for the night and sleep until morning, so I can walk to Dunlow at first light and turn in the strik… | Erzähler | open_run_level | Lodge overnight, then head for the Dunlow Guild hall | the wheel pit | 135/84 | 16.0 s |
| 92 | I take the bed at two copper and the supper for one more, then sleep until morning. | Erzähler | open_run_level | Book lodging at the quoted price and sleep | the wheel pit | 135/84 | 21.5 s |
| 93 | I take the key from the hook, go up to the small room, and sleep in the straw tick until morning. | Erzähler | open_run_level | Actually sleep at the booked room to recover overnight | the small room upstairs | 135/84 | 33.1 s |
| 94 | I lie down on the straw tick, pull the blanket over me, and sleep until morning. | Erzähler | open_run_level | Sleep in the booked room now that arrival is confirmed | the small room upstairs | 155/84 | 15.5 s |
| 95 | I hand the key back at the counter and set out east on the road past the mill, walking toward Dunlow. | Erzähler | open_run_level | Turn in the striker cull at Dunlow Guildhouse | the small room upstairs | 155/84 | 17.2 s |
| 96 | I walk through the Dunlow gate and head to the Guild hall to turn in the striker cull contract. | Erzähler | open_run_level | Enter Dunlow and turn in the striker cull at the Guild hall | the Dunlow Guildhouse | 155/84 | 24.1 s |
| 97 | I step up to the counter and hand the clerk my READY contract slip, asking to turn in Cull the Orchard Strikers. | Erzähler | open_run_level | Turn in the striker cull at the Dunlow Guildhouse counter | the Dunlow Guildhouse | 155/84 | 22.6 s |
| 98 | I walk to the notice board and read what contracts are posted for the Dunlow district. | Erzähler | open_run_level | Find local work while carrying the striker slip toward Crownheart | the Dunlow Guildhouse | 155/84 | 25.0 s |
| 99 | I ask the clerk at the counter whether the Guildhouse can post word of the striker cull to Crownheart, or whether I must carry the slip back… | Erzähler | open_run_level | Resolve how to turn in the READY slip since Dunlow cannot pay | the Dunlow Guildhouse | 155/84 | 28.1 s |
| 100 | I ask the clerk to send word to Crownheart that the striker cull is done, then I look for lodging in Dunlow for the night. | Erzähler | open_run_level | Send word west and rest overnight | the Lamb | 155/84 | 38.0 s |
| 101 | I'll take the bed and supper — eight copper total — then sleep until morning. | Erzähler | open_run_level | Buy lodging and meal, then rest overnight | the Lamb | 155/84 | 39.5 s |
| 102 | I head down to the market square to look for a buyer for my surplus lynx pelt and claws. | Erzähler | open_run_level | Sell surplus loot in Dunlow | the market square | 155/84 | 25.6 s |
| 103 | I offer the merchant the mire lynx pelt and my two lynx claws and ask what he'll pay for the lot. | Erzähler | open_run_level | Sell surplus loot to the pelt trader | the market square | 155/84 | 27.9 s |
| 104 | Thirty-eight is fair — I'll take it. | Engine (Menü/Rückfrage) | open_run_level | Sell pelt and claws at the offered price | the market square | 155/84 | 7.1 s |
| 105 | I accept the merchant's 38 copper offer for the pelt and both claws. | Engine (Menü/Rückfrage) | open_run_level | Complete the loot sale at the offered price | the market square | 155/84 | 8.1 s |
| 106 | I accept the merchant's 38 cp counteroffer — book the deal at 38 copper for the pelt and both claws. | Engine (Menü/Rückfrage) | open_run_level | Complete the loot sale at 38 copper | the market square | 155/84 | 7.8 s |
| 107 | I accept the 30 cp bid (offer.t206.9) — book the sale of the pelt and both claws at 30 copper. | Engine (Menü/Rückfrage) | open_run_level | Close the loot sale at the recorded bid to end the clarification loop | the market square | 155/84 | 6.6 s |
| 108 | 38 cp the lot | Engine (Menü/Rückfrage) | open_run_level | Answer the clarification by picking the merchant's 38 cp option verbatim to close the sale | the market square | 155/84 | 6.9 s |
| 109 | accept the bid at 30 cp | Erzähler | open_run_level | Close the pelt sale by picking the exact option wording | the market square | 155/84 | 24.7 s |
| 110 | I leave the market and head for the Dunlow Guildhouse to check the contract board for a turn-in or new work. | Erzähler | open_run_level | Turn in the striker contract and pick new work | the Dunlow Guildhouse | 155/84 | 20.6 s |
| 111 | I tell Clerk E I'm here for a turn-in on Cull the Orchard Strikers, 4 of 4 defeated, and show my contract slip and feathers. | Erzähler | open_run_level | Turn in the striker contract at the Guildhouse counter | the Dunlow Guildhouse | 155/84 | 17.5 s |
| 112 | I ask Clerk E if the Dunlow board has any contracts that pay out here in Dunlow, suited to a Novice F-Rank, before I decide about the Crownh… | Erzähler | open_run_level | Find local-paying work before travelling | the Dunlow Guildhouse | 155/84 | 22.8 s |
| 113 | I head to Dunlow's square and take the carrier's cart east to Crownheart to turn in the striker contract at the Guildhall. | Erzähler | open_run_level | Travel to Crownheart for the turn-in | Crownheart | 155/84 | 46.8 s |
| 114 | I enter the Crownheart Guildhall and present my contract slip to turn in Cull the Orchard Strikers, 4 of 4 defeated. | Erzähler | open_run_level | Turn in striker contract at Crownheart Guildhall | Adventurers' Guild hall, Crownheart | 155/84 | 18.2 s |
| 115 | I look over the big contract board for a fresh Novice F-Rank contract I can take. | Erzähler | open_run_level | Pick new Guild work after the turn-in | Adventurers' Guild hall, Crownheart | 155/84 | 42.5 s |
| 116 | I take the slip for Thin the Whip-Tailed Strikers of Bramblewick Orchards from the board and take it to the intake counter to accept it befo… | Erzähler | open_run_level | Accept a repeatable achievable hunt contract | Adventurers' Guild hall, Crownheart | 155/84 | 16.8 s |
| 117 | I ask Clerk G if the Guild has beds for the night, and if so, take one and sleep until morning. | Erzähler | open_run_level | Secure lodging and rest before the two-day trip to Bramblewick | Adventurers' Guild hall, Crownheart | 155/84 | 34.7 s |
| 118 | I grab bread and porridge at the common room, then head out the Southgate and take the carrier road west toward Bramblewick. | Erzähler | open_run_level | Eat and set out for the striker contract | Bramblewick | 155/84 | 19.1 s |
| 119 | I head into the orchard rows past the presses and hunt whip-tailed strikers until I've defeated 3. | Erzähler | open_run_level | Hunt strikers for the active contract | the Bramblewick cider orchards | 155/84 | 23.5 s |
| 120 | I follow the two-note chittering call down the left rows and attack the first whip-tailed striker I spot, fighting until I've defeated 3. | Erzähler | open_run_level | Hunt strikers in the orchard | the Bramblewick cider orchards | 155/84 | 26.2 s |
| 121 | I close the distance and attack the striker in the tree, using Heavy Slash as soon as I'm in reach. | Erzähler | open_run_level | Engage the first striker | the Bramblewick cider orchards | 155/84 | 27.4 s |
| 122 | I close to melee range with the striker and attack it with Heavy Slash. | Erzähler | open_run_level | Engage the striker at proper range | the Bramblewick cider orchards | 155/84 | 23.2 s |
| 123 | I move into ENGAGED range beneath the striker's tree and attack it with Heavy Slash the moment it's within reach. | Erzähler | open_run_level | Explicitly close to ENGAGED before striking the treetop striker | the Bramblewick cider orchards | 155/84 | 14.7 s |
| 124 | I step into ENGAGED range beside the striker's low perch and strike it with Quick Slash. | Erzähler | open_run_level | Attack the now-SHORT striker with declared movement | the Bramblewick cider orchards | 155/84 | 16.5 s |
| 125 | #assign STR 3 VIT 2 | System (Befehl) | open_run_level | Allocate level-up points into STR and VIT | the Bramblewick cider orchards | 155/84 | 2.7 s |
| 126 | I hunt the ditch behind the black hedge for the next striker and attack it, using declared movement to ENGAGED range before striking with Qu… | Erzähler | open_run_level | Continue the striker hunt, 1/3 done | the Bramblewick cider orchards | 155/84 | 15.2 s |
| 127 | I follow the rustling of heavy feathers thirty yards off behind the black hedge, and when I spot the striker there, I move to ENGAGED range … | Erzähler | open_run_level | Hunt the second striker using the fresh sign | the reed pool behind the black hedge | 155/84 | 32.6 s |
| 128 | I keep pressing the striker at ENGAGED range, attacking with Quick Slash. | Erzähler | open_run_level | Fight striker G at engaged range | the reed pool behind the black hedge | 155/84 | 16.3 s |
| 129 | I assign my five free stat points: #assign STR 3 PER 2 | Erzähler | open_run_level | Spend level-up points | the reed pool behind the black hedge | 155/84 | 14.0 s |
| 130 | I track the ditch along the hedge toward where it bends, searching for the last striker's sign, and when I find it I move to ENGAGED range a… | Erzähler | open_run_level | Hunt the third and final striker for the contract | the fallen willow roost at the ditch bend | 155/84 | 18.3 s |
| 131 | I search the fallen willow's tangle for the last striker, and when I find it I move to ENGAGED range and attack with Quick Slash. | Engine (Menü/Rückfrage) | open_run_level | Hunt the final striker at the roost | the fallen willow roost at the ditch bend | 155/84 | 7.7 s |
| 132 | I probe the fallen willow's tangle carefully with my sword, flushing out the striker hiding inside, and attack it with Quick Slash once it's… | Engine (Menü/Rückfrage) | open_run_level | Flush and fight the last striker | the fallen willow roost at the ditch bend | 155/84 | 13.8 s |
| 133 | I step onto the beaten patch and push toward the willow's tangle, moving to ENGAGED range with whatever is hiding inside, sword ready. | Erzähler | open_run_level | Close with the hidden striker to make it targetable | the willow's tangle | 155/84 | 29.3 s |
| 134 | I attack Whip-Tailed Striker H with Quick Slash. | Erzähler | open_run_level | Fight the final striker to complete the contract | the willow's tangle | 155/84 | 21.8 s |
| 135 | With all three strikers defeated, I head back to the Guild hall to turn in the contract. | Erzähler | open_run_level | Turn in the completed striker contract | Adventurers' Guild hall, Alderwatch | 155/84 | 29.1 s |
| 136 | #assign STR 3 VIT 2 | System (Befehl) | open_run_level | Spend level-up points, then check the board | Adventurers' Guild hall, Alderwatch | 155/84 | 2.7 s |
| 137 | I check the Guild board for fresh contracts. | Erzähler | open_run_level | Pick a new contract from the board | Adventurers' Guild hall, Alderwatch | 155/84 | 49.9 s |
| 138 | I ask the clerk to accept the contract 'Thin the Whip-Tailed Strikers in the Cider Orchards'. | Erzähler | open_run_level | Accept the repeatable striker contract | Adventurers' Guild hall, Alderwatch | 155/84 | 22.5 s |
| 139 | I buy the Primer of Guard for 80 copper and read it to learn the guard skill. | Erzähler | open_run_level | Learn a defensive skill before heading to the orchards | Adventurers' Guild hall, Alderwatch | 155/84 | 22.8 s |
| 140 | I buy the Primer of Guard from the clerk at the counter for 80 copper, then read it to learn guard. | Erzähler | open_run_level | Retry the refused primer purchase with the present seller | Adventurers' Guild hall, Alderwatch | 155/84 | 25.1 s |
| 141 | I give up on the primer for now and look for lodging in Alderwatch for the night. | Erzähler | open_run_level | Recover overnight before the orchard hunt | Adventurers' Guild hall, Alderwatch | 155/84 | 327.4 s |
| 142 | I take a room at the Crooked Eel and sleep until morning. | Erzähler | open_run_level | Recover overnight before the orchard contract | Adventurers' Guild hall, Alderwatch | 155/84 | 17.2 s |
| 143 | I accept the landlady's price: I take the room and the stew for six copper, then eat and sleep until morning. | Erzähler | open_run_level | Book the room and recover overnight | Adventurers' Guild hall, Alderwatch | 155/84 | 49.9 s |
| 144 | I ask the landlady to book the room for four copper, then sleep in it until morning. | Erzähler | open_run_level | Book the room explicitly and recover overnight | Adventurers' Guild hall, Alderwatch | 155/84 | 38.1 s |
| 145 | #help | System (Befehl) | open_run_level | Check commands for booking lodging or sleeping | Adventurers' Guild hall, Alderwatch | 155/84 | 2.9 s |
| 146 | #system How do I book a room for the night so the engine records it? What counts as a valid canonical offer for lodging? | Erzähler | open_run_level | Find the engine's accepted way to book lodging | Adventurers' Guild hall, Alderwatch | 155/84 | 9.8 s |
| 147 | I take the woman's offer: I pay four copper for the room and sleep in it until morning. | Erzähler | open_run_level | Accept the established lodging offer and rest | Adventurers' Guild hall, Alderwatch | 155/84 | 31.6 s |
| 148 | I walk down from the Guild hall into the river lanes and look for a lodging house or inn with a keeper present, then ask for a room for the … | Erzähler | open_run_level | Find a real lodging seller and get an offer | the Black Duck lodging house | 155/84 | 45.7 s |
| 149 | I take the back chamber for three copper and the stew for one, pay her four copper, then eat and sleep until morning. | Erzähler | open_run_level | Book lodging and recover overnight | the Black Duck lodging house | 195/84 | 86.8 s |
| 150 | I ask the innkeeper for a bowl of stew for one copper, then eat it. | Erzähler | open_run_level | Buy breakfast with an explicit offer acceptance | the Black Duck lodging house | 195/84 | 21.1 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 7 (notiert vor Zug 8): Coin discrepancy: registration narration said two silver but engine charged only 20 copper; HUD shows 3 Silver.
- zu Zug 19 (notiert vor Zug 20): Level 2 confirmed, points assigned; contract shows 1/4 strikers defeated.
- zu Zug 29 (notiert vor Zug 30): Digging failed to expose Striker C; den too deep under roots. Contract still 2/4.
- zu Zug 32 (notiert vor Zug 33): System refused 'young striker breaking the surface' as target; must wait for it to be a targetable actor.
- zu Zug 35 (notiert vor Zug 36): Heavy Slash refused at SHORT range; striker fled into the meadow, now at LONG.
- zu Zug 38 (notiert vor Zug 39): Striker C defeated after two refused chase attacks (range MEDIUM/LONG); loot auto-credited, quest 3/4.
- zu Zug 49 (notiert vor Zug 50): Striker closed from MEDIUM to SHORT on its own; the earlier range refusal was positional, not a mechanic failure.
- zu Zug 50 (notiert vor Zug 51): Engine requires declared movement to change range; SHORT still out of Heavy Slash reach.
- zu Zug 52 (notiert vor Zug 53): No Guild branch in Bramblewick; nearest hall a day's walk east past the mill. Engine said turn-in 'needs step 1' — likely requires arriving at a Guild node.
- zu Zug 55 (notiert vor Zug 56): Dunlow market counter is not a Guild branch; turn-in must go to Millbrook branch via Stony Ford ferry (half a day). HUD location still shows the wood rows—stale, narration confirms Dunlow.
- zu Zug 61 (notiert vor Zug 62): HUD location still stale (shows the post). Two turn-in refusals so far; Bramblewick issuance is the stated fix.
- zu Zug 62 (notiert vor Zug 63): Turn-in refused three times: Millbrook claims Bramblewick pays, Bramblewick claims Millbrook holds the coin; both mentioned a ledger transfer as the alternative.
- zu Zug 66 (notiert vor Zug 67): Turn-in loop finally explained: neither Millbrook nor Bramblewick has a paying hall; Dunlow, a day's walk east, is the real counter.
- zu Zug 67 (notiert vor Zug 68): Dunlow has no Guild hall despite being called the nearest paying counter — third contradictory pointer. XP 278/300, close to level 4.
- zu Zug 68 (notiert vor Zug 69): Narrator says the Lamb is in Bramblewick after a night walk, but the HUD and engine shop still show Dunlow at 20:35 — location contradiction; trusting the System panels. Next lead: paying Guild hall at Harrowgate, two days north.
- zu Zug 69 (notiert vor Zug 70): System clarified prices differ from the landlady's spoken total; also the narrator placed me in Bramblewick but the HUD still shows Dunlow at 20:35 — trusting the System.
- zu Zug 71 (notiert vor Zug 72): Harrowgate also lacks a Guild hall — fourth town without one; turn-in engine error said it 'needs step 2', suggesting a proper hall node is required.
- zu Zug 76 (notiert vor Zug 77): Marlesford's Guild board is rain-ruined; no payable notices. Fifth town without a working Guild counter; turn-ins seem to require Crownheart.
- zu Zug 77 (notiert vor Zug 78): Every town so far lacks a working Guild counter; private work (rat tails, wild dogs) is the fallback here.
- zu Zug 92 (notiert vor Zug 93): Engine refused sleep until the keeper's offer was accepted; the 3 coppers and supper now appear confirmed by narration, HUD still shows old coin/time.
- zu Zug 95 (notiert vor Zug 96): Narration confirms arrival at Dunlow by evening, but HUD still lists Marlesford and 18:00; treating the travel as done per the newest narration.
- zu Zug 96 (notiert vor Zug 97): HUD note says Dunlow has no paying counter and the turn-in must happen elsewhere, yet the Guild hall with clerks is present here; trying the counter to resolve the contradiction.
- zu Zug 97 (notiert vor Zug 98): Dunlow Guildhouse cannot pay out; the striker cull turn-in requires the Crownheart Guildhall, two days west.
- zu Zug 98 (notiert vor Zug 99): Dunlow Guildhouse has no contract board and no paying counter; turn-in must happen at the Crownheart branch hall, two days west.
- zu Zug 105 (notiert vor Zug 106): System clarification loop keeps pitting the merchant's spoken 38 cp against a 30 cp catalog bid; answering explicitly this time.
- zu Zug 106 (notiert vor Zug 107): Third clarification loop over the same sale; giving up the 8 cp difference to move on.
- zu Zug 107 (notiert vor Zug 108): Fourth clarification loop on the same pelt sale; answering with the exact option wording this time.
- zu Zug 108 (notiert vor Zug 109): Fifth clarification loop on the same sale; if this fails again I'll abandon the sale and head to the Guildhouse turn-in.
- zu Zug 109 (notiert vor Zug 110): Sale finally closed at 30 cp after five clarification loops; HUD shows 6 Silver 1 Copper, so the payout may have been booked as silver — minor coin discrepancy to watch.
- zu Zug 110 (notiert vor Zug 111): Coin discrepancy persists: sale added 30 copper but HUD shows 6 Silver 1 Copper; note it but proceed.
- zu Zug 117 (notiert vor Zug 118): HUD still shows Day 8 22:55 despite narrated morning sleep; time panel may lag.
- zu Zug 119 (notiert vor Zug 120): Arrival now confirmed; quest counter 0/3.
- zu Zug 122 (notiert vor Zug 123): Two refusals: Heavy Slash needs a declared movement step, not just 'closing'.
- zu Zug 132 (notiert vor Zug 133): Engine keeps refusing attacks: no targetable actor in scene despite fresh sign; may need movement first to trigger the encounter.
- zu Zug 139 (notiert vor Zug 140): Engine refused the buy ('seller is not here') even though the narrator described the purchase and reading; skills list still lacks guard, so I repeat the purchase explicitly.
- zu Zug 140 (notiert vor Zug 141): Primer of Guard purchase refused three times ('no valid canonical offer') despite narrator describing it; abandoning this optional buy and proceeding without guard skill.
- zu Zug 143 (notiert vor Zug 144): Engine refused the combined room+stew purchase twice despite the narrator taking six copper and giving a key; HUD coin unchanged at 3G4S1C, so no payment actually recorded. Trying a room-only booking.
- zu Zug 144 (notiert vor Zug 145): Room purchases refused three times despite narrator confirming payment; HUD coin unchanged. HUD oddly shows location as Guild hall at 17:33 while narrator is at the inn.
- zu Zug 145 (notiert vor Zug 146): Lodging purchases refused 3+ times while narrator confirms payment; HUD coins never change. Asking the System directly for the canonical mechanic.
- zu Zug 147 (notiert vor Zug 148): Engine voided lodging because no seller existed at the Guild hall; HUD location was Guild hall all along. Must establish a present innkeeper and stated price before paying.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t11 | 11 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t17r | 17 | 1 | – | nein | 1 | gewonnen, 96 XP |
| enc.t21 | 22 | 1 | – | nein | 1 | gewonnen, 148 XP |
| enc.t34 | 38 | 1 | – | nein | 1 | gewonnen, 96 XP |
| enc.t47 | 51 | 1 | – | nein | 1 | gewonnen, 168 XP |
| enc.t76 | 81 | 1 | – | nein | 1 | gewonnen, 28 XP |
| enc.t82 | 88 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t113 | 124 | 1 | – | nein | 1 | gewonnen, 144 XP |
| enc.t116 | 128 | 1 | – | nein | 1 | gewonnen, 116 XP |
| enc.t120 | 134 | 1 | – | nein | 1 | gewonnen, 120 XP |

## Quests

- **Cull the Mire Lynx** — active (Zug 7) → completed (Zug 12)
  - Aufgabe: Kill 1 the mire lynx at the reed bank of the Alderwatch millpond. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the mire lynx killed at the reed bank of the Alderwatch millpond.
- **Cull the Orchard Strikers** — active (Zug 14) → completed (Zug 114), READY
  - Aufgabe: Kill 4 whip-tailed strikers at the Bramblewick cider orchards. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 whip-tailed strikers killed at the Bramblewick cider orchards.
- **Cull the Barrowfield Ghouls** — expired (Zug 137)
  - Aufgabe: Kill 6 grave ghouls at the barrowfield pits east of the crown road. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 6 grave ghouls killed at the barrowfield pits east of the crown road.
- **Cull the Fenwyrm of Blackmere** — expired (Zug 137)
  - Aufgabe: Kill 1 the fenwyrm at the drowned peat of Blackmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the fenwyrm killed at the drowned peat of Blackmere.
- **Clear Old Crown Catacombs, Level 1** — expired (Zug 137), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of Old Crown Catacombs. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Old Crown Catacombs is clear.
- **Thin the Whip-Tailed Strikers of Bramblewick Orchards** — active (Zug 116) → completed (Zug 135)
  - Aufgabe: Kill 3 whip-tailed strikers at the Bramblewick cider orchards. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 whip-tailed strikers killed at the Bramblewick cider orchards.
- **Thin the Whip-Tailed Strikers in the Cider Orchards** — active (Zug 138)
  - Aufgabe: Kill 3 whip-tailed strikers at the Bramblewick cider orchards. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 whip-tailed strikers killed at the Bramblewick cider orchards.

## Auffälligkeiten

- Zug 3, Nachricht 5 (board_failed): the board generator failed
- Zug 5, Nachricht 9 (planner_repaired): the planner's first answer needed a repair
- Zug 8, Nachricht 16 (extraction_repaired): the extractor's first answer needed a repair
- Zug 41, Nachricht 82 (extraction_repaired): the extractor's first answer needed a repair
- Zug 43, Nachricht 86 (extraction_repaired): the extractor's first answer needed a repair
- Zug 53, Nachricht 106 (extraction_repaired): the extractor's first answer needed a repair
- Zug 54, Nachricht 108 (extraction_repaired): the extractor's first answer needed a repair
- Zug 55, Nachricht 110 (extraction_failed): the extractor failed: $.deltas[7] (place.reported): .place: matches none of anyOf; Place reference at deltas[7].place: use a known place id or {"new":{"name":"exact name","kind":"interior","parent":"known parent id"}}; a n
- Zug 55, Nachricht 110 (extraction_repaired): the extractor's first answer needed a repair
- Zug 56, Nachricht 112 (extraction_repaired): the extractor's first answer needed a repair
- Zug 58, Nachricht 116 (extraction_repaired): the extractor's first answer needed a repair
- Zug 64, Nachricht 127 (planner_repaired): the planner's first answer needed a repair
- Zug 65, Nachricht 129 (planner_repaired): the planner's first answer needed a repair
- Zug 69, Nachricht 137 (planner_repaired): the planner's first answer needed a repair
- Zug 71, Nachricht 141 (planner_repaired): the planner's first answer needed a repair
- Zug 73, Nachricht 146 (extraction_repaired): the extractor's first answer needed a repair
- Zug 74, Nachricht 148 (extraction_repaired): the extractor's first answer needed a repair
- Zug 79, Nachricht 158 (extraction_repaired): the extractor's first answer needed a repair
- Zug 98, Nachricht 196 (extraction_repaired): the extractor's first answer needed a repair
- Zug 100, Nachricht 200 (extraction_repaired): the extractor's first answer needed a repair
- Zug 104, Nachricht 207 (planner_repaired): the planner's first answer needed a repair
- Zug 105, Nachricht 209 (planner_repaired): the planner's first answer needed a repair
- Zug 106, Nachricht 211 (planner_repaired): the planner's first answer needed a repair
- Zug 107, Nachricht 213 (planner_repaired): the planner's first answer needed a repair
- Zug 108, Nachricht 215 (planner_repaired): the planner's first answer needed a repair
- Zug 113, Nachricht 226 (extraction_repaired): the extractor's first answer needed a repair
- Zug 117, Nachricht 234 (extraction_repaired): the extractor's first answer needed a repair
- Zug 129, Nachricht 257 (stat_words): the player spent Stat Points in words, not with #assign; nothing was assigned (for review: did the story tell them as done?)
- Zug 131, Nachricht 261 (planner_repaired): the planner's first answer needed a repair
- Zug 132, Nachricht 263 (planner_repaired): the planner's first answer needed a repair
- Zug 143, Nachricht 286 (extraction_repaired): the extractor's first answer needed a repair
- Zug 149, Nachricht 297 (planner_repaired): the planner's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 29× keine gültige JSON-Entscheidung (Züge 2, 4, 5, 26, 27, 29, 32, 33, 40, 46, 49, 60, 61, 76, 77, 79, 86, 87, 89, 90, 98, 102, 103, 112, 113, 119, 125, 132, 142)

System-Panels: CLARIFY 6, NOT TAKEN 0, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: engine_owned_fact 16, guild_canon_price 1, guild_canon 5, engine_owned_combat 5, attack_commitment 10, world_rule 5, scene_context 37, ambient 13, no_go 10, offer 2, place 2, engine_owned_memory 1, time_cap 2, group_unclear 1, domain_fact 1, engine_recovery 1, entity_fact 1, guild_payout 2, quest_count 1, pc_inventory 2, npc_presence 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 29/150 Erstantworten ungültig (19.3 %); 29 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 154 | 13 | 2.5 s | 4.5 s | 11812 | 9947 | 102 | – | stop 154 | 0 |
| board | 7 | 3 | 9.7 s | 25.4 s | 2560 | 2454 | 979 | – | stop 7 | 0 |
| narrator | 132 | 0 | 9.3 s | 16.4 s | 11312 | 8689 | 394 | – | stop 132 | 0 |
| extract | 147 | 16 | 5.9 s | 14.0 s | 12060 | 9415 | 399 | – | stop 147 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 75:52 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 51.7 s) | 1:07 min |
| 150 Züge, Spiel (Senden bis HUD nach der Extraktion) | 61:46 min — Median 21.5 s, p90 38.1 s, max 327.4 s |
| 150 Züge, Spieler-Entscheidung | 10:11 min — Median 2.5 s, 29 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 8:13 min / 1:23 min / 27:44 min / 18:11 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 28.8 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 19:11 min, 80 Züge ≈ 38:23 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spieler | 150 | – | 36.2 s | 2.5 s |
| Spiel | 141 | – | 327.4 s | 21.5 s |
| Spiel | 149 | – | 86.8 s | 21.5 s |
| Provider narrator | 141 | 415 | 291.3 s | 9.3 s |
| Provider extract | 149 | 437 | 53.7 s | 5.9 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
