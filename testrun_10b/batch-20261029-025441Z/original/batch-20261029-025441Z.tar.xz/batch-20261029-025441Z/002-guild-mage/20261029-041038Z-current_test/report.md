# Avereth Live-Test 20261029-041038Z-current_test

## Kurzfassung

- **Laufprofil:** guild-mage; Startklasse Mage, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** Niederlage — turn 19: he died
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 2. Sicherheitsgrenzen: 150 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** noch nicht erreicht.
- **Charakter:** mage (mage.arcane_bolt, mage.arcane_ward) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: cautious adventurer: prepare and recover, weigh threats and withdraw when sensible
- **Züge:** 19 · **Dauer:** 12:45 min · **LLM-Aufrufe der Engine/des Erzählers:** 45
- **Beobachtete Abdeckung:** 4 unterschiedliche gebuchte Reiseziele · 2 Kämpfe · 0 Verkäufe (0 cp Umsatz, ohne Questzahlungen/Geschenke) · 0 Ausrüstungswechsel · 0 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 1 · **Niederlage** in Zug 19: he died
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.115 |
| Git | 9c65e9ada6a2 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 14.3 s |
| Browser | chrome 156.0.8078.49 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261029-041038Z-current_test“, Seed 254542103 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | I choose Mage. | Engine (Menü/Rückfrage) | creation_complete | Select Mage class | public roadside verge outside Alderwatch | 90/84 | 2.3 s |
| 2 | I select Arcane Bolt and Arcane Ward. | Engine (Menü/Rückfrage) | creation_complete | Choose starter skills | public roadside verge outside Alderwatch | 90/96 | 2.2 s |
| 3 | I walk through the gates into Alderwatch and head for the Adventurers' Guild to look at the contract board. | Erzähler | open_run_level | Enter city and find Guild contracts | Adventurers' Guild hall, Alderwatch | 90/96 | 68.9 s |
| 4 | "Good morning. I'd like to register with the Guild, and I'm interested in the Stray Hound Pack contract on the Tannery Road — five feral dog… | Erzähler | open_run_level | Register with the Guild and accept the hound cull contract | Adventurers' Guild hall, Alderwatch | 90/96 | 36.3 s |
| 5 | I place two silver on the counter, sign the ledger line, and rest my hand on the measuring stone. If registration succeeds, I ask her to mak… | Erzähler | open_run_level | Register with the Guild and accept the hound cull contract | Adventurers' Guild hall, Alderwatch | 90/96 | 77.5 s |
| 6 | I head out the east gate and follow the Tannery Road toward Bram Osker's scrap pits to hunt the feral dogs. | Erzähler | open_run_level | Travel to Tannery Road and hunt feral dogs | the Tannery Road east of Alderwatch | 90/96 | 63.3 s |
| 7 | I cast Arcane Bolt at Feral Dog A. | Erzähler | open_run_level | Attack the feral dog | the Tannery Road east of Alderwatch | 77/86 | 26.2 s |
| 8 | I cast Arcane Bolt at Feral Dog A to finish it. | Erzähler | open_run_level | Kill the wounded dog with a second bolt | the Tannery Road east of Alderwatch | 77/76 | 25.5 s |
| 9 | I wait a moment and watch the alder copse for movement. If no dog approaches, I cast Arcane Bolt at any feral dog that shows itself. | Erzähler | open_run_level | Assign stat points, then keep hunting the pack | the Tannery Road east of Alderwatch | 77/76 | 34.0 s |
| 10 | I walk down to the stocky figure by the sheds and ask if he is Bram Osker, and where the feral dogs den at night. | Erzähler | open_run_level | Talk to the villager, identify Bram Osker, learn pack habits | Bram Osker's tanning sheds | 77/76 | 28.4 s |
| 11 | #assign INT 2 WIL 2 VIT 1 | System (Befehl) | open_run_level | Spend level-up stat points | Bram Osker's tanning sheds | 77/76 | 2.1 s |
| 12 | I wash the bite in the stream behind the sheds, then ask Bram if I can shelter near his sheds until dusk, when the pack comes down to the pi… | Erzähler | open_run_level | Recover a little and position for the dusk hunt | Bram Osker's tanning sheds | 77/76 | 24.2 s |
| 13 | I thank Bram for the shelter and head up the road toward the quarry workings, keeping low and listening for the dogs' approach. | Erzähler | open_run_level | Position for dusk hunt toward the quarry | Bram Osker's tanning sheds | 77/76 | 36.7 s |
| 14 | I take Bram's advice and wait by the stream along the cart track, keeping low and out of the wind, and cast Arcane Bolt at the first dog tha… | Engine (Menü/Rückfrage) | open_run_level | Ambush the pack at the stream crossing as they come down to water | Bram Osker's tanning sheds | 77/76 | 13.5 s |
| 15 | I take cover by the stream crossing and wait for the dogs to come down to the water; as soon as one is within sight in the open, I cast Arca… | Engine (Menü/Rückfrage) | open_run_level | Ambush the descending pack at the stream | Bram Osker's tanning sheds | 77/76 | 7.1 s |
| 16 | I stay hidden by the stream and wait for the dogs to reach the water; when a dog appears before me, I cast Arcane Bolt at that dog. | Engine (Menü/Rückfrage) | open_run_level | Ambush the feral dog pack at the stream crossing | Bram Osker's tanning sheds | 77/76 | 4.9 s |
| 17 | I leave cover and climb toward the ridge above the tanning sheds where the low shapes were seen, approaching the pack in the scrub. | Erzähler | open_run_level | Engage the feral dog pack directly near the ridge | the ridge above the tanning sheds | 77/76 | 39.6 s |
| 18 | I cast Arcane Ward, then Arcane Bolt at the forward dog before it can charge. | Erzähler | open_run_level | Buff then strike the lead dog now that targets are active | the ridge above the tanning sheds | 77/76 | 41.8 s |
| 19 | I cast Arcane Bolt at the lead dog lunging at me. | Erzähler | open_run_level | Fire the uncast bolt at the charging lead dog | the ridge above the tanning sheds | 0/66 | 28.6 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 9 (notiert vor Zug 10): Level 2 confirmed, 5 free stat points pending; dog count 1/5.
- zu Zug 16 (notiert vor Zug 17): System repeatedly says 'no targetable actor' despite narration showing dogs on the ridge; the pack may not be an active scene until I move to them.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t7 | 7 | 1 | – | nein | 1 | gewonnen, 120 XP |
| enc.t15 | 19 | 5 | – | nein | 0 | **tot** |

## Quests

- **Cull the Stray Hound Pack on the Tannery Road** — active (Zug 5)
  - Aufgabe: Kill 5 feral dogs at the Tannery Road east of Alderwatch. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 5 feral dogs killed at the Tannery Road east of Alderwatch.

## Auffälligkeiten

- Zug 12, Nachricht 23 (planner_repaired): the planner's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 6× keine gültige JSON-Entscheidung (Züge 6, 7, 9, 10, 16, 17)

System-Panels: CLARIFY 0, NOT TAKEN 1, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: engine_owned_fact 1, npc_presence 1, group_unclear 3, attack_commitment 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 6/19 Erstantworten ungültig (31.6 %); 6 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 17 | 1 | 3.4 s | 30.0 s | 11679 | 9934 | 100 | – | stop 17 | 0 |
| board | 2 | 1 | 16.3 s | 20.3 s | 2943 | 2392 | 962 | – | stop 2 | 0 |
| narrator | 13 | 0 | 16.9 s | 25.4 s | 11377 | 8774 | 396 | – | stop 13 | 0 |
| extract | 13 | 0 | 6.8 s | 22.0 s | 11894 | 9384 | 284 | – | stop 13 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 12:45 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 14.3 s) | 0:29 min |
| 19 Züge, Spiel (Senden bis HUD nach der Extraktion) | 9:23 min — Median 28.4 s, p90 68.9 s, max 77.5 s |
| 19 Züge, Spieler-Entscheidung | 2:38 min — Median 5.0 s, 6 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 2:08 min / 0:33 min / 3:40 min / 2:22 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 38.0 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 25:19 min, 80 Züge ≈ 50:37 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spieler | 6 | – | 33.9 s | 5.0 s |
| Spieler | 16 | – | 31.4 s | 5.0 s |
| Provider plan | 5 | 9 | 33.7 s | 3.4 s |
| Provider plan | 6 | 12 | 30.0 s | 3.4 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
