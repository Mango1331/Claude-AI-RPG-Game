# Avereth Live-Test 20261029-042325Z-current_test

## Kurzfassung

- **Laufprofil:** guild-rogue; Startklasse Rogue, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** Niederlage — turn 23: he died
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 1. Sicherheitsgrenzen: 150 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** noch nicht erreicht.
- **Charakter:** rogue (rogue.razor_cut, rogue.piercing_thrust) · Regelstand 2 (Warrior, Mage, Rogue)
- **Ziel-Dungeon:** Mossback Warrens, Ebene 1 (Vertrag quest.clear_mossback_warrens_level_1)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: pragmatic adventurer: sell surplus loot and invest in useful equipment and techniques
- **Züge:** 23 · **Dauer:** 8:19 min · **LLM-Aufrufe der Engine/des Erzählers:** 65
- **Beobachtete Abdeckung:** 4 unterschiedliche gebuchte Reiseziele · 2 Kämpfe · 0 Verkäufe (0 cp Umsatz, ohne Questzahlungen/Geschenke) · 0 Ausrüstungswechsel · 0 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 4 · **Niederlage** in Zug 23: he died
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.115 |
| Git | 9c65e9ada6a2 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 13.7 s |
| Browser | chrome 156.0.8078.49 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261029-042325Z-current_test“, Seed 254542104 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | Rogue. | Engine (Menü/Rückfrage) | creation_complete | Choose Rogue as base class | public roadside verge outside Ashbridge | 90/84 | 2.3 s |
| 2 | I choose Razor Cut and Piercing Thrust. | Engine (Menü/Rückfrage) | creation_complete | Finish character creation with two Rogue starter skills | public roadside verge outside Ashbridge | 90/84 | 2.1 s |
| 3 | I walk to the Ashbridge city gate and enter the city, heading for the Adventurers' Guild to look at the contract board. | Erzähler | open_run_level | Enter Ashbridge and find the Guild board | Adventurers' Guild hall, Ashbridge | 90/84 | 40.7 s |
| 4 | "Register me, please — here's two silver." I hand the clerk two silver. | Erzähler | open_run_level | Register with the Guild | Adventurers' Guild hall, Ashbridge | 90/84 | 19.3 s |
| 5 | "Alaric. Here's the two silver fee — that's exactly two silver for registration." I slide two silver across the counter and give the clerk m… | Engine (Menü/Rückfrage) | open_run_level | Register with the Guild, paying exactly 2 silver | Adventurers' Guild hall, Ashbridge | 90/84 | 5.7 s |
| 6 | Yes, I accept the registration fee of 20 cp. My name is Alaric Red — write it down and I'll use the measuring stone. | Erzähler | open_run_level | Accept the registration offer and complete registration | Adventurers' Guild hall, Ashbridge | 90/84 | 14.8 s |
| 7 | I wait near the counter for the contract courier and ask the clerk what Novice contracts usually pay. | Erzähler | open_run_level | Wait for the board and scout contract options | Adventurers' Guild hall, Ashbridge | 90/84 | 18.2 s |
| 8 | I stay by the counter and watch as the courier brings the contract notices in, ready to take a look at the board once they're posted. | Erzähler | open_run_level | Wait for the courier to post contracts and view the board | Adventurers' Guild hall, Ashbridge | 90/84 | 31.8 s |
| 9 | I take the feral dogs notice and my Guild plate to Marta's desk and ask to accept the contract. | Erzähler | open_run_level | Accept the achievable level-1 dog cull contract | Adventurers' Guild hall, Ashbridge | 90/84 | 18.2 s |
| 10 | I head down along the river lane to Tannery Row and follow the smell to the middens, keeping my eyes out for the feral dog. | Erzähler | open_run_level | Travel to the middens and hunt the feral dog | Tannery Row middens, Ashbridge | 90/84 | 20.2 s |
| 11 | I draw my dagger and approach the shed, ready to attack the feral dog under it. | Erzähler | open_run_level | Fight the feral dog | Tannery Row middens, Ashbridge | 84/84 | 15.1 s |
| 12 | I strike with Piercing Thrust as the dog lunges at my legs. | Erzähler | open_run_level | Attack the feral dog with my strongest available attack | Tannery Row middens, Ashbridge | 84/84 | 15.8 s |
| 13 | I check the contract slip, then head back up the river lane to the Guild hall to turn in the completed dog cull. | Erzähler | open_run_level | Turn in the finished contract at the Guild hall | Adventurers' Guild hall, Ashbridge | 84/84 | 23.2 s |
| 14 | I take the coins, then ask Marta if there are any new contracts posted on the board I could take. | Erzähler | open_run_level | Turn done; look for the next contract | Adventurers' Guild hall, Ashbridge | 84/84 | 13.9 s |
| 15 | I take the Mossback Warrens notice to Marta and ask her to make it active for me. | Erzähler | open_run_level | Accept the level-1 warrens clear contract | Adventurers' Guild hall, Ashbridge | 84/84 | 15.9 s |
| 16 | No questions — I head south along the river on the Mossback road toward the warrens, keeping an eye out for the Guild-marked entrance. | Erzähler | open_run_level | Travel to Mossback Warrens | Mossback Warrens | 84/84 | 19.8 s |
| 17 | I enter the dungeon, drawing my dagger and moving cautiously with the cold air at my back. | Erzähler | open_run_level | Enter Mossback Warrens level 1 | Mossback Warrens, level 1 — goblin camp chamber | 84/84 | 23.0 s |
| 18 | I rush the one with the spear and use Piercing Thrust before the others can flank me. | Engine (Menü/Rückfrage) | open_run_level | Attack the spear-wielding goblin first | Mossback Warrens, level 1 — goblin camp chamber | 84/84 | 6.1 s |
| 19 | I rush Goblin Scout A and use Piercing Thrust on him before the others can flank me. | Erzähler | open_run_level | Attack the spear-wielding goblin by its scene name | Mossback Warrens, level 1 — goblin camp chamber | 84/84 | 20.1 s |
| 20 | I close the distance to Goblin Scout A and use Piercing Thrust on him. | Erzähler | open_run_level | Close to ENGAGED, then attack the spear goblin | Mossback Warrens, level 1 — goblin camp chamber | 56/84 | 20.1 s |
| 21 | I finish Goblin Scout A with Piercing Thrust before he can rally. | Erzähler | open_run_level | Kill the wounded spear goblin | Mossback Warrens, level 1 — goblin camp chamber | 21/84 | 16.4 s |
| 22 | I finish Goblin Scout A with Razor Cut, then turn on Goblin Scout B with Piercing Thrust if he falls. | Erzähler | open_run_level | Kill the wounded goblin, then press the next | Mossback Warrens, level 1 — goblin camp chamber | 1/84 | 15.9 s |
| 23 | I use Piercing Thrust on Goblin Scout B. | Erzähler | open_run_level | Kill Scout B before he strikes again | Mossback Warrens, level 1 — goblin camp chamber | 0/84 | 15.2 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 6 (notiert vor Zug 7): Registration complete: F-rank Novice, 3 silver left, board still bare awaiting courier.
- zu Zug 22 (notiert vor Zug 23): HP 1/90 — a single hit will kill me; this turn is do-or-die.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t10r | 11 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t18 | 20 | 3 | – | nein | 1 | **tot** |

## Quests

- **Cull the Feral Dogs at the Tannery Row Middens** — active (Zug 9) → completed (Zug 13)
  - Aufgabe: Kill 1 feral dog at Tannery Row middens, Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 feral dog killed at Tannery Row middens, Ashbridge.
- **Clear Mossback Warrens, Level 1** — active (Zug 15), Dungeon loc.mossback_warrens Ebene 1
  - Aufgabe: Clear level 1 of Mossback Warrens. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Mossback Warrens is clear.

## Auffälligkeiten

- Zug 3, Nachricht 5 (board_failed): the board generator failed
- Zug 4, Nachricht 7 (planner_repaired): the planner's first answer needed a repair
- Zug 5, Nachricht 9 (planner_repaired): the planner's first answer needed a repair
- Zug 9, Nachricht 17 (planner_repaired): the planner's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 2× keine gültige JSON-Entscheidung (Züge 4, 11)

System-Panels: CLARIFY 1, NOT TAKEN 0, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: ambient 2, guild_canon_price 1, guild_canon 1, domain_fact 1, engine_owned_fact 1, guild_payout 1, world_rule 7.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 2/23 Erstantworten ungültig (8.7 %); 2 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 24 | 3 | 2.2 s | 4.0 s | 11177 | 9897 | 69 | – | stop 24 | 0 |
| board | 3 | 1 | 10.2 s | 10.7 s | 2470 | 2470 | 1094 | – | stop 3 | 0 |
| narrator | 19 | 0 | 8.6 s | 11.2 s | 11851 | 8748 | 411 | – | stop 19 | 0 |
| extract | 19 | 0 | 4.4 s | 7.4 s | 11628 | 9365 | 351 | – | stop 19 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 8:19 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 13.7 s) | 0:35 min |
| 23 Züge, Spiel (Senden bis HUD nach der Extraktion) | 6:34 min — Median 16.4 s, p90 23.2 s, max 40.7 s |
| 23 Züge, Spieler-Entscheidung | 0:52 min — Median 1.9 s, 2 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 1:00 min / 0:29 min / 2:45 min / 1:31 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 19.4 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 12:55 min, 80 Züge ≈ 25:50 min (ohne Einrichtung) |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
