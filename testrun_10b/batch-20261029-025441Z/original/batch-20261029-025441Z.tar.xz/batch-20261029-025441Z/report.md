# Avereth – 3 natürliche Testkampagnen

Status: **completed**. Serie abgeschlossen bedeutet, dass die Läufe beendet sind; es bedeutet nicht 3 bestandene Level-15-Abnahmen.

| Nr. | Profil | Seed | Eingaben | Level | Ende | Originalbericht |
|---|---|---:|---:|---:|---|---|
| 1 | guild-warrior | 254542102 | 150 | 6 | limit | [report.md](001-guild-warrior/20261029-025441Z-current_test/report.md) |
| 2 | guild-mage | 254542103 | 19 | 2 | defeat | [report.md](002-guild-mage/20261029-041038Z-current_test/report.md) |
| 3 | guild-rogue | 254542104 | 23 | 1 | defeat | [report.md](003-guild-rogue/20261029-042325Z-current_test/report.md) |

