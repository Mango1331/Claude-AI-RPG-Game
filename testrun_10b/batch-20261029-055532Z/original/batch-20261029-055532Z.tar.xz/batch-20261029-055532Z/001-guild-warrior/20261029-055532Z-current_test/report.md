# Avereth Live-Test 20261029-055532Z-current_test

## Kurzfassung

- **Laufprofil:** guild-warrior; Startklasse Warrior, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** Niederlage — turn 31: he died
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 1. Sicherheitsgrenzen: 150 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** noch nicht erreicht.
- **Charakter:** warrior (warrior.guard, warrior.cleave) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: cautious adventurer: prepare and recover, weigh threats and withdraw when sensible
- **Züge:** 31 · **Dauer:** 12:50 min · **LLM-Aufrufe der Engine/des Erzählers:** 93
- **Beobachtete Abdeckung:** 8 unterschiedliche gebuchte Reiseziele · 2 Kämpfe · 0 Verkäufe (0 cp Umsatz, ohne Questzahlungen/Geschenke) · 0 Ausrüstungswechsel · 0 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 5 · **Niederlage** in Zug 31: he died
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.116 |
| Git | 41a17fc50ba2 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 46.1 s |
| Browser | chrome 156.0.8078.49 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261029-055532Z-current_test“, Seed 1908782372 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | I choose Warrior. | Engine (Menü/Rückfrage) | creation_complete | Select Warrior base class | public roadside verge outside Glassmere | 90/84 | 2.2 s |
| 2 | I select Cleave and Guard as my two skills. | Engine (Menü/Rückfrage) | creation_complete | Finish character creation with Cleave and Guard | public roadside verge outside Glassmere | 95/84 | 2.2 s |
| 3 | I walk along the road into Glassmere and head for the Adventurers' Guild hall to look at the contract board. | Erzähler | open_run_level | Enter city and find Guild contracts | Adventurers' Guild hall, Glassmere | 95/84 | 19.5 s |
| 4 | I approach the clerk and ask how to register with the Guild as a new F-rank adventurer. | Erzähler | open_run_level | Register with the Guild | Adventurers' Guild hall, Glassmere | 95/84 | 14.8 s |
| 5 | I pay the two silver, give my name — Alaric Red, twenty, Warrior class — and place my hand on the measuring stone. | Erzähler | open_run_level | Register with the Guild as F-rank | Adventurers' Guild hall, Glassmere | 95/84 | 17.7 s |
| 6 | I sign my name in the ledger, then read the papers pinned in the NOVICE — F RANK row of the contract board. | Erzähler | open_run_level | Register complete; inspect novice contracts | Adventurers' Guild hall, Glassmere | 95/84 | 24.3 s |
| 7 | I take the marsh serpent contract slip and bring it to the clerk to accept it. | Erzähler | open_run_level | Accept the achievable level-1 cull contract | Adventurers' Guild hall, Glassmere | 95/84 | 15.0 s |
| 8 | I head out of the Guild hall and follow the south road past the tanners' row toward the eel-weirs. | Erzähler | open_run_level | Travel to the eel-weirs for the serpent contract | the eel-weirs south of Glassmere | 95/84 | 25.6 s |
| 9 | I ask the weavers whether the deep pool can be safely watched from the dike, or whether I should wait for dusk here. | Erzähler | open_run_level | Plan the serpent hunt with locals | the eel-weirs south of Glassmere | 95/84 | 18.7 s |
| 10 | I take up position at the willow clump on the east bank overlooking the deep pool and settle in to wait for dusk. | Erzähler | open_run_level | Stake out the deep pool at the firm overlook before dusk | the willow clump on the east bank | 95/84 | 20.1 s |
| 11 | I draw my longsword and strike at the serpent's risen ridge with a Basic Attack. | Erzähler | open_run_level | Engage the marsh serpent | the willow clump on the east bank | 95/84 | 17.4 s |
| 12 | I move quickly along the firm ground to cut it off at the water's edge near the weirs, then close to ENGAGED and strike with Cleave as soon … | Erzähler | open_run_level | Close distance and engage the serpent with Cleave | the willow clump on the east bank | 95/84 | 19.3 s |
| 13 | I strike the serpent's risen shape at the water's edge with Cleave. | Erzähler | open_run_level | Attack the serpent now in range with Cleave | the willow clump on the east bank | 95/84 | 27.5 s |
| 14 | I wade out across the drop-off toward the serpent at the torn basket and strike it with Cleave once it's in reach. | Erzähler | open_run_level | Close into ENGAGED range by wading, then attack | the willow clump on the east bank | 95/84 | 18.8 s |
| 15 | I retrieve the serpent carcass as best I can and head back through the weavers' huts toward the Guild hall in Caelreth to turn in the comple… | Erzähler | open_run_level | Turn in the serpent contract at the Guild | Adventurers' Guild hall, Glassmere | 95/84 | 24.3 s |
| 16 | I ask the clerk what contracts are currently on the board. | Erzähler | open_run_level | Pick a new Guild contract | Adventurers' Guild hall, Glassmere | 95/84 | 14.8 s |
| 17 | I tell the clerk I'll take the Cull the Boar Sounder contract and ask her to mark it active for me. | Erzähler | open_run_level | Accept the boar cull contract | Adventurers' Guild hall, Glassmere | 95/84 | 15.9 s |
| 18 | I ask the clerk if there's lodging nearby for the night, then find a bed and sleep until morning. | Erzähler | open_run_level | Recover overnight before the boar hunt | The Coopered Barrel | 95/84 | 26.9 s |
| 19 | I buy the bed for the night and the stew, then go up to the third door and sleep until morning. | Erzähler | open_run_level | Purchase lodging and sleep overnight | Room at the Coopered Barrel | 95/84 | 18.0 s |
| 20 | I eat the promised breakfast downstairs, then head up to the terraced vineyard slopes and ask the vintners' hands where the boars have been … | Erzähler | open_run_level | Start boar cull contract by finding the sounder | the terraced vineyards above Glassmere | 95/84 | 23.8 s |
| 21 | I head north along the terrace line into the gully wood, moving quietly and watching for boar sign along the stream-cut. | Erzähler | open_run_level | Hunt the boar sounder in the gully wood | the gully wood along the stream-cut | 95/84 | 29.6 s |
| 22 | I move quietly downslope toward the feeding sound, keeping downwind and my sword ready, and get a look at the boars before committing. | Erzähler | open_run_level | Scout the boar sounder before engaging | the clearing where the stream bends | 95/84 | 19.6 s |
| 23 | I charge the nearest middling boar and swing Cleave across it and any pig beside it, keeping the oak trunk at my back so none gets behind me… | Erzähler | open_run_level | Engage the boar sounder with Cleave from a defensible position | the clearing where the stream bends | 95/84 | 16.6 s |
| 24 | I move in close on the nearest middling boar, and once I'm within reach I swing Cleave across it and any pig beside it, keeping the oak trun… | Erzähler | open_run_level | Engage the boar sounder with Cleave at proper range | the clearing where the stream bends | 95/84 | 17.7 s |
| 25 | I close the last of the distance to the nearest rooting boar and engage it in melee, then swing Cleave across it and any pig beside it, back… | Erzähler | open_run_level | Engage the nearest boar at sword range so Cleave becomes valid | the clearing where the stream bends | 95/84 | 20.5 s |
| 26 | I swing Cleave at the boar standing SHORT at the stream edge, cutting across it and any pig beside it. | Erzähler | open_run_level | Attack the SHORT-range boar with Cleave | the clearing where the stream bends | 95/84 | 22.2 s |
| 27 | I hold at the oak and wait for the sow to close into sword reach, then swing Cleave across her and any boar beside her. | Erzähler | open_run_level | Let the charge come into melee range, then Cleave | the clearing where the stream bends | 95/84 | 19.1 s |
| 28 | I engage the sow (Wild Boar A) in melee combat as she closes, holding my ground at the oak. | Erzähler | open_run_level | Formally declare engagement so Cleave becomes valid next turn | the clearing where the stream bends | 95/84 | 16.9 s |
| 29 | I swing Cleave across the engaged sow and any boar beside her. | Erzähler | open_run_level | Use Cleave now that the sow is ENGAGED | the clearing where the stream bends | 36/84 | 18.3 s |
| 30 | I take Guard to blunt the next goring, planning to break away toward the stream if I get an opening. | Erzähler | open_run_level | Reduce incoming damage at low HP | the clearing where the stream bends | 3/84 | 19.0 s |
| 31 | I use a Healing Draught if I have one in my bag, then retreat toward the stream. | Erzähler | open_run_level | Survive at 3 HP — heal and withdraw | the clearing where the stream bends | 0/84 | 16.1 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 5 (notiert vor Zug 6): HUD shows 3 Silver after paying 2 silver fee; engine said 30 copper — minor coin discrepancy, HUD authoritative.
- zu Zug 11 (notiert vor Zug 12): Serpent is now MEDIUM per HUD; LONG range blocked Basic Attack earlier, so must close before striking.
- zu Zug 19 (notiert vor Zug 20): Engine kept refusing 'sleep until morning' as 'arrival pending' but narration and HUD confirm a full night's rest with recovered stats.
- zu Zug 24 (notiert vor Zug 25): Engine refuses Cleave until a target is formally ENGAGED after movement; narration treats boars as MEDIUM distance. Trying explicit engagement declaration.
- zu Zug 26 (notiert vor Zug 27): Engine repeatedly refuses Cleave because targets never reach ENGAGED; narration keeps enemies at MEDIUM/SHORT. Trying to let the charge close the distance instead of declaring movement.
- zu Zug 27 (notiert vor Zug 28): Engine requires an explicit engagement declaration; narration keeps enemies at range labels regardless.
- zu Zug 29 (notiert vor Zug 30): Alaric HP 36/95 with two boars engaged and two closing; Cleave finally resolved once targets were formally ENGAGED.
- zu Zug 30 (notiert vor Zug 31): HP 3/95 with three boars ENGAGED; a fourth SHORT. Withdrawal is now mandatory.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t14 | 14 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t29 | 29 | 4 | – | nein | 0 | **tot** |

## Quests

- **Cull the Marsh Serpent of the Eel-Weirs** — active (Zug 7) → completed (Zug 15), READY
  - Aufgabe: Kill 1 the marsh serpent at the eel-weirs south of Glassmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the marsh serpent killed at the eel-weirs south of Glassmere.
- **Cull the Boar Sounder Rooting Up the Vineyards** — active (Zug 17)
  - Aufgabe: Kill 4 wild boars of the vineyard sounder at the terraced vineyards above Glassmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 wild boars of the vineyard sounder killed at the terraced vineyards above Glassmere.

## Auffälligkeiten

- Zug 4, Nachricht 8 (extraction_repaired): the extractor's first answer needed a repair
- Zug 5, Nachricht 9 (planner_repaired): the planner's first answer needed a repair
- Zug 17, Nachricht 34 (extraction_repaired): the extractor's first answer needed a repair
- Zug 18, Nachricht 36 (extraction_repaired): the extractor's first answer needed a repair
- Zug 21, Nachricht 42 (extraction_repaired): the extractor's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 10× keine gültige JSON-Entscheidung (Züge 4, 5, 9, 11, 14, 17, 21, 22, 24, 26)

System-Panels: CLARIFY 0, NOT TAKEN 1, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: ambient 1, guild_canon_price 1, engine_owned_memory 1, engine_owned_fact 1, attack_commitment 4, world_rule 8.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 10/31 Erstantworten ungültig (32.3 %); 10 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 30 | 1 | 2.5 s | 3.4 s | 11657 | 9904 | 103 | – | stop 30 | 0 |
| narrator | 29 | 0 | 8.0 s | 11.9 s | 11231 | 8657 | 378 | – | stop 29 | 0 |
| extract | 33 | 4 | 5.2 s | 7.2 s | 11773 | 9374 | 380 | – | stop 33 | 0 |
| board | 1 | 0 | 10.4 s | 10.4 s | 2445 | 0 | 1132 | – | stop 1 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 12:50 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 46.1 s) | 1:10 min |
| 31 Züge, Spiel (Senden bis HUD nach der Extraktion) | 9:43 min — Median 18.8 s, p90 25.6 s, max 29.6 s |
| 31 Züge, Spieler-Entscheidung | 1:33 min — Median 2.6 s, 10 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 1:17 min / 0:10 min / 4:15 min / 2:51 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 21.8 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 14:31 min, 80 Züge ≈ 29:03 min (ohne Einrichtung) |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
