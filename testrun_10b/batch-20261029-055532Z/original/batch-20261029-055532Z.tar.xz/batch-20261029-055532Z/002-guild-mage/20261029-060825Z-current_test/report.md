# Avereth Live-Test 20261029-060825Z-current_test

## Kurzfassung

- **Laufprofil:** guild-mage; Startklasse Mage, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** abgebrochen: Limit erreicht — 150 turns
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 8. Sicherheitsgrenzen: 150 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** Level 6, 354 XP seit Levelaufstieg, 494 cp, HP 92, MP 169; Ort loc.ashbridge.guild_hall. Ausrüstung und Skills stehen in evaluation.json → progression.checkpoint.
- **Charakter:** mage (mage.arcane_bolt, mage.arcane_wave) · Regelstand 2 (Warrior, Mage, Rogue)
- **Ziel-Dungeon:** Mossback Warrens, Ebene 1 (Vertrag quest.clear_mossback_warrens_level_1_4)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: cautious adventurer: prepare and recover, weigh threats and withdraw when sensible
- **Züge:** 150 · **Dauer:** 53:40 min · **LLM-Aufrufe der Engine/des Erzählers:** 424
- **Beobachtete Abdeckung:** 23 unterschiedliche gebuchte Reiseziele · 15 Kämpfe · 3 Verkäufe (95 cp Umsatz, ohne Questzahlungen/Geschenke) · 0 Ausrüstungswechsel · 2 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 21
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.116 |
| Git | 41a17fc50ba2 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 11.8 s |
| Browser | chrome 156.0.8078.49 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261029-060825Z-current_test“, Seed 1908782373 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | I choose Mage. | Engine (Menü/Rückfrage) | creation_complete | Select Mage as base class | public roadside verge outside Ashbridge | 90/84 | 2.3 s |
| 2 | I select Arcane Wave and Arcane Bolt as my two starter skills. | Engine (Menü/Rückfrage) | creation_complete | Finish character creation with mandatory Arcane Wave | public roadside verge outside Ashbridge | 90/96 | 2.1 s |
| 3 | I walk into Ashbridge and head to the Guild hall to look at the contract board. | Erzähler | open_run_level | Reach the Guild and view contracts | Adventurers' Guild hall, Ashbridge | 90/96 | 37.2 s |
| 4 | I approach the clerk and ask to register for the Ford Adder contract at Miller's Crossing. | Erzähler | open_run_level | Accept first novice Guild contract | Adventurers' Guild hall, Ashbridge | 90/96 | 18.0 s |
| 5 | I pay the two silver and register with the Guild. | Erzähler | open_run_level | Register as Guild member | Adventurers' Guild hall, Ashbridge | 90/96 | 30.5 s |
| 6 | I take the Ford Adder contract slip and ask the clerk to make it active. | Erzähler | open_run_level | Accept first Guild contract | Adventurers' Guild hall, Ashbridge | 90/96 | 34.7 s |
| 7 | I set out along the Silt Road through the south gate, keeping the river on my left, and walk to Miller's Crossing. | Erzähler | open_run_level | Travel to the ford to hunt the adder | the stony shallows of Miller's Crossing on the Silt Road | 90/96 | 16.6 s |
| 8 | I search the bank for a long stick or pole to probe the water ahead of my feet, then wade slowly into the shallows, watching for any movemen… | Erzähler |  | Hunt the ford adder cautiously | the stony shallows of Miller's Crossing on the Silt Road | 90/96 | 22.2 s |
| 9 | I cast Arcane Bolt at the adder as it strikes. | Erzähler | open_run_level | Fight the ford adder at range | the stony shallows of Miller's Crossing on the Silt Road | 90/86 | 13.0 s |
| 10 | I wade back to the near bank, dry off as best I can, and walk back along the Silt Road to Duskreach, then go to the Guild hall and ask the c… | Erzähler | open_run_level | Return to the Guild and turn in the completed adder cull | Adventurers' Guild hall, Ashbridge | 90/86 | 30.2 s |
| 11 | I ask the clerk what contracts are on the board suitable for a Novice mage. | Erzähler | open_run_level | Take the next Guild contract | Adventurers' Guild hall, Ashbridge | 90/86 | 13.8 s |
| 12 | I take the Quarry-Track Boars contract slip and ask the clerk to make it active. | Erzähler | open_run_level | Accept the boar-thinning contract | Adventurers' Guild hall, Ashbridge | 90/86 | 17.4 s |
| 13 | I head out the east gate and follow the quarry track east to the scrub verges, keeping alert for boar tracks and rooting damage. | Erzähler | open_run_level | Travel to the boar hunting ground | the old quarry track and its scrub verges east of Ashbridge | 90/86 | 22.7 s |
| 14 | I circle quietly downwind of the gorse thicket to get a clear view of the rooting boar before engaging. | Erzähler | open_run_level | Scout the boar and fight it at range | the old quarry track and its scrub verges east of Ashbridge | 90/86 | 18.5 s |
| 15 | I cast Arcane Bolt at the unaware boar from my cover in the hawthorn. | Erzähler | open_run_level | Ambush Boar A with Arcane Bolt | the old quarry track and its scrub verges east of Ashbridge | 90/76 | 14.1 s |
| 16 | I cast Arcane Bolt at the charging boar again before it can close the distance. | Erzähler | open_run_level | Finish the wounded boar with a second Arcane Bolt | the old quarry track and its scrub verges east of Ashbridge | 69/66 | 13.3 s |
| 17 | I cast Arcane Bolt at the wounded boar at point-blank range to finish it. | Erzähler | open_run_level | Kill Boar A before it gores again | the old quarry track and its scrub verges east of Ashbridge | 69/56 | 17.3 s |
| 18 | #assign VIT 2 INT 2 WIL 1 | System (Befehl) | open_run_level | Spend level-up points, favor survivability | the old quarry track and its scrub verges east of Ashbridge | 69/56 | 2.2 s |
| 19 | I bind my torn thigh with a strip of cloth, then circle downwind toward the gorse thicket to scout the second boar before engaging. | Erzähler | open_run_level | Treat wound and hunt the second boar cautiously | the leaning boulder by the gorse thicket | 69/56 | 29.6 s |
| 20 | I wait behind the boulder until the boar emerges from the northern side of the thicket to feed, keeping downwind, then cast Arcane Bolt at i… | Engine (Menü/Rückfrage) | open_run_level | Ambush the second boar as it leaves the thicket | the leaning boulder by the gorse thicket | 69/56 | 9.3 s |
| 21 | I move quietly to the northern edge of the gorse thicket to get a clear view of the boar, then cast Arcane Bolt at it. | Erzähler | open_run_level | Get a targetable boar and ambush it | the leaning boulder by the gorse thicket | 69/56 | 18.6 s |
| 22 | I cast Arcane Bolt at Tusked Boar B. | Erzähler | open_run_level | Attack the targetable boar confirmed by the engine | the leaning boulder by the gorse thicket | 69/46 | 17.8 s |
| 23 | I cast Arcane Bolt at Tusked Boar B to finish it. | Erzähler | open_run_level | Kill the wounded boar before it can charge | the leaning boulder by the gorse thicket | 69/36 | 12.8 s |
| 24 | #assign VIT 2 WIL 2 INT 1 | System (Befehl) | open_run_level | Spend level-up points, favor survivability | the leaning boulder by the gorse thicket | 69/36 | 2.2 s |
| 25 | I withdraw to the leaning boulder and rest there, keeping watch over the thicket, until my mana recovers enough for another fight. | Engine (Menü/Rückfrage) | open_run_level | Recover MP before engaging the third boar | the leaning boulder by the gorse thicket | 69/36 | 4.8 s |
| 26 | I rest for two hours behind the leaning boulder, keeping watch over the thicket. | Erzähler | open_run_level | Recover MP before hunting the third boar | the leaning boulder by the gorse thicket | 93/82 | 13.0 s |
| 27 | I move toward the northern edge of the gorse thicket to get a clear view of the feeding boar, then cast Arcane Bolt at it. | Erzähler | open_run_level | Get line of sight on the third boar and ambush it | the northern edge of the gorse thicket | 93/82 | 17.2 s |
| 28 | I check the contract slip to see if the boars must be taken on the quarry track specifically, and whether hunting in the dark is feasible or… | Erzähler | open_run_level | Clarify remaining contract conditions before hunting in darkness | the northern edge of the gorse thicket | 93/82 | 16.5 s |
| 29 | I head back to Ashbridge, take lodging for the night, and sleep until morning before resuming the hunt at first light. | Erzähler | open_run_level | Recover safely overnight, resume boar hunt at dawn | lodging house with the painted bush sign | 93/82 | 22.0 s |
| 30 | I take the room for eight copper and the warmed supper for nine, then sleep until morning. | Engine (Menü/Rückfrage) | open_run_level | Buy lodging and meal, then recover overnight | lodging house with the painted bush sign | 93/82 | 6.7 s |
| 31 | I buy the room for eight copper and the warmed supper for nine, seventeen copper total, from the innkeeper, then eat and sleep until morning… | Engine (Menü/Rückfrage) | open_run_level | Purchase lodging and meal, then recover overnight | lodging house with the painted bush sign | 93/82 | 9.3 s |
| 32 | I buy one room for the night and one warmed supper from the innkeeper for eight copper plus nine copper, seventeen copper total, then eat th… | Erzähler | open_run_level | Purchase lodging and meal, then rest overnight | lodging house with the painted bush sign | 120/156 | 16.2 s |
| 33 | I head out of the lodging house toward the quarry track to hunt the two remaining boars. | Erzähler | open_run_level | Resume the boar hunt at dawn | the old quarry track and its scrub verges east of Ashbridge | 120/156 | 17.8 s |
| 34 | I move slowly along the southern verge toward where the branch cracked, staff ready, watching for boar sign. | Erzähler | open_run_level | Track the remaining boars in the southern scrub | the wallow hollow in the southern verge | 120/156 | 18.1 s |
| 35 | I back off a few paces to open ground near the wallow's edge, then cast Arcane Bolt at the bramble where the rooting sound comes from. | Engine (Menü/Rückfrage) | open_run_level | Engage the rooting boar from a safe distance | the wallow hollow in the southern verge | 120/156 | 5.3 s |
| 36 | I wait at the wallow's edge for the rooting animal to come down the middle path into the open, staff ready, and cast Arcane Bolt at it as so… | Engine (Menü/Rückfrage) | open_run_level | Lure the hidden boar into view, then attack | the wallow hollow in the southern verge | 120/156 | 4.6 s |
| 37 | I walk down the middle path toward the rooting sound, staff ready, keeping my eyes on the bramble ahead. | Erzähler | open_run_level | Close in until the boar becomes a targetable actor | the mud clearing past the gorse | 120/156 | 22.3 s |
| 38 | I cast Arcane Bolt at Tusked Boar Sow A before she charges. | Erzähler | open_run_level | Open combat on the now-targetable sow | the mud clearing past the gorse | 120/156 | 19.4 s |
| 39 | I advance across the open mud toward Tusked Boar Sow A to bring her within Arcane Bolt range, then cast Arcane Bolt at her. | Erzähler | open_run_level | Close to MEDIUM and attack the sow | the mud clearing past the gorse | 98/146 | 15.7 s |
| 40 | I cast Arcane Bolt at Tusked Boar Sow A. | Erzähler | open_run_level | Finish the wounded sow with Arcane Bolt | the mud clearing past the gorse | 76/136 | 15.6 s |
| 41 | I cast Arcane Bolt at Tusked Boar Sow A to finish her. | Erzähler | open_run_level | Kill the wounded sow | the mud clearing past the gorse | 76/126 | 17.0 s |
| 42 | I bind my wounded leg with a strip of cloth from my pouch, then withdraw back along the middle path toward the quarry track, keeping watch o… | Erzähler | open_run_level | Recover and avoid the hidden creature, hunt the fourth boar elsewhere | the old quarry track and its scrub verges east of Ashbridge | 76/126 | 20.7 s |
| 43 | I follow the quarry track east, keeping watch on the verges and moving quietly, looking for sign of the fourth boar. | Erzähler | open_run_level | Hunt the fourth and final contract boar | the verge above the flooded quarry cut | 76/126 | 23.8 s |
| 44 | I take the fallen-tree line along the rim of the cut, moving quietly to get above the big boar at the reed bed, then cast Arcane Bolt at it … | Erzähler | open_run_level | Ambush the fourth boar from the high dry line | the verge above the flooded quarry cut | 76/126 | 19.6 s |
| 45 | I climb along the fallen-tree line on the rim, moving quietly to get above the reed bed and spot the big boar. | Erzähler | open_run_level | Ambush the fourth boar from the high rim | the verge above the flooded quarry cut | 76/126 | 15.8 s |
| 46 | I climb the fallen tree along the rim to get a clear view of the boar below. | Erzähler | open_run_level | Position above the reed bed for the ambush | the high end of the flooded quarry cut | 76/126 | 17.3 s |
| 47 | I cast Arcane Bolt at Tusked Boar C below. | Erzähler | open_run_level | Ambush the fourth boar from cover | the high end of the flooded quarry cut | 76/126 | 14.7 s |
| 48 | I climb down along the fallen tree partway toward the reed bed, closing to Medium range, keeping the trunk at my back for a quick retreat. | Erzähler | open_run_level | Close to spell range for the ambush | the low end of the fallen tree above the reed bed | 76/126 | 19.4 s |
| 49 | I cast Arcane Bolt at Tusked Boar C. | Erzähler | open_run_level | Ambush the fourth boar now in Medium range | the low end of the fallen tree above the reed bed | 76/116 | 17.0 s |
| 50 | I strike at Tusked Boar C with my staff (Basic Attack). | Erzähler | open_run_level | Finish the wounded boar at Short range | the low end of the fallen tree above the reed bed | 58/116 | 15.2 s |
| 51 | I strike again at Tusked Boar C with my staff (Basic Attack) to finish it. | Erzähler | open_run_level | Finish the wounded boar | the low end of the fallen tree above the reed bed | 58/116 | 17.3 s |
| 52 | #assign VIT 2 WIL 2 INT 1 | System (Befehl) | open_run_level | Spend level-up points, then plan recovery | the low end of the fallen tree above the reed bed | 58/116 | 2.2 s |
| 53 | I collect the boar's hide and tusks, then head back toward the Guild hall in town to turn in the contract and rest. | Erzähler | open_run_level | Loot, return to town for turn-in and recovery | Adventurers' Guild hall, Ashbridge | 58/116 | 21.8 s |
| 54 | I ask the clerk: does the Guild buy boar hides and tusks, and where can I find a healer or a bed for the night? | Erzähler | open_run_level | Sell surplus loot and arrange recovery | Adventurers' Guild hall, Ashbridge | 58/116 | 18.5 s |
| 55 | I head to Maren's on Coil Street, the green shutters past the mill, and ask her to treat my wounded leg. | Erzähler | open_run_level | Get healing at the healer | Maren's healing house | 58/116 | 23.1 s |
| 56 | I pay Maren the four copper for the stitching and salve. | Erzähler | open_run_level | Pay for healing | Maren's healing house | 58/116 | 12.3 s |
| 57 | I thank Maren and head to Hessel's tannery yard with the boar hides and tusks to ask his prices. | Erzähler | open_run_level | Sell surplus loot | Hessel's tanner yard | 58/116 | 20.2 s |
| 58 | I lay out the three boar hides, five boar tusks, the sow hide and two sow tusks on the table and ask what he'll pay for the lot. | Erzähler | open_run_level | Sell all surplus boar loot to Hessel | Hessel's tanner yard | 58/116 | 17.9 s |
| 59 | I accept the offer and sell him the whole lot for fifty copper. | Erzähler | open_run_level | Sell all boar loot to Hessel | Hessel's tanner yard | 58/116 | 31.7 s |
| 60 | "Done — fifty copper," I say, and hand him the whole lot across the table. | Erzähler | open_run_level | Confirm the sale to Hessel for fifty copper | Hessel's tanner yard | 58/116 | 17.1 s |
| 61 | I sell Hessel the ford adder skin and both fangs, asking his price for the lot. | Erzähler | open_run_level | Sell remaining adder loot to Hessel | Hessel's tanner yard | 58/116 | 14.5 s |
| 62 | "Word — twenty copper," I say, and hand him the adder skin and both fangs. | Erzähler | open_run_level | Confirm adder loot sale to Hessel | Hessel's tanner yard | 58/116 | 11.8 s |
| 63 | "Nothing else today," I say, and head back toward the Guild hall to look at the contract board. | Erzähler | open_run_level | Return to the Guild hall for a new contract | Adventurers' Guild hall, Ashbridge | 58/116 | 24.0 s |
| 64 | I take the Ford Adder cull slip from the Novice board and ask the clerk to register it as an active contract. | Erzähler | open_run_level | Accept the Miller's Crossing adder contract | Adventurers' Guild hall, Ashbridge | 58/116 | 12.8 s |
| 65 | With the contract registered, I leave the Guild hall and take the Silt Road east toward Miller's Crossing. | Erzähler | open_run_level | Travel to the adder shallows | the stony shallows of Miller's Crossing on the Silt Road | 58/116 | 24.2 s |
| 66 | I find cover behind the willows and rest a while to recover my strength before approaching the deepest pool slowly, staff ready, and cast Ar… | Erzähler | open_run_level | Recover HP, then hunt the ford adder at the deepest pool | the stony shallows of Miller's Crossing on the Silt Road | 58/116 | 15.7 s |
| 67 | I rest in the willow hollow for 2 hours to recover, then approach the deepest pool slowly and cast Arcane Bolt the moment the adder shows it… | Erzähler | open_run_level | Rest 2 hours, then hunt the ford adder | the deepest pool | 82/171 | 17.4 s |
| 68 | I cast Arcane Bolt at the adder. | Erzähler | open_run_level | Kill the ford adder for the cull contract | the deepest pool | 82/162 | 16.8 s |
| 69 | With the adder dead and the cull at 1/1, I take the Silt Road back to the Guild hall in town to turn in the contract. | Erzähler | open_run_level | Return to Guild to turn in the adder contract | Adventurers' Guild hall, Ashbridge | 82/162 | 21.4 s |
| 70 | #assign INT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up stat points | Adventurers' Guild hall, Ashbridge | 82/162 | 2.5 s |
| 71 | "Just this, thank you." I check the contract board for a new job suited to a novice mage. | Erzähler | open_run_level | Look for the next Guild contract | Adventurers' Guild hall, Ashbridge | 82/162 | 18.8 s |
| 72 | "The boar cull on the quarry track suits me. I'll take that one." I accept the contract and wait for it to be marked active under my name. | Erzähler | open_run_level | Accept the boar cull contract | Adventurers' Guild hall, Ashbridge | 82/162 | 13.3 s |
| 73 | It's too late to hunt tonight, so I'll take a room at the inn, sleep until morning, then set out east for the quarry track. | Erzähler | open_run_level | Lodging and overnight recovery before the boar hunt | Adventurers' Guild hall, Ashbridge | 82/162 | 16.3 s |
| 74 | "Six copper, then — supper and bread in the morning." I pay the innkeeper for the room and meal, then go up and sleep until morning. | Erzähler | open_run_level | Book room and sleep | Adventurers' Guild hall, Ashbridge | 82/162 | 17.3 s |
| 75 | I take the iron key, climb to the room at the end on the left, and sleep until morning. | Erzähler | open_run_level | Sleep overnight with the booked room key | room at the end on the left | 82/162 | 14.6 s |
| 76 | I lie down on the bed and sleep until morning. | Erzähler | open_run_level | Sleep to recover overnight | room at the end on the left | 140/228 | 18.6 s |
| 77 | I eat the bread downstairs, then head out the east gate and follow the quarry track toward the boar grounds, asking the gate guard for Wend. | Erzähler | open_run_level | Set out east for the boar cull | the old quarry track and its scrub verges east of Ashbridge | 140/228 | 28.9 s |
| 78 | I stay downwind in the gorse and watch the reed bed, waiting for the boar to show itself clearly before I move closer. | Erzähler | open_run_level | Scout the boar from cover before engaging | the old quarry track and its scrub verges east of Ashbridge | 140/228 | 22.2 s |
| 79 | I stay hidden in the gorse and cast Arcane Bolt at the boar's flank from ambush. | Erzähler | open_run_level | Ambush the boar with Arcane Bolt | the old quarry track and its scrub verges east of Ashbridge | 140/219 | 14.9 s |
| 80 | I cast Arcane Bolt at the wounded boar's head before it can charge. | Erzähler | open_run_level | Finish the boar with Arcane Bolt | the old quarry track and its scrub verges east of Ashbridge | 140/210 | 14.5 s |
| 81 | I check the contract slip's terms, then follow the fresh rooting sign along the quarry verges to hunt the second boar. | Erzähler | open_run_level | Continue the boar cull toward 2/2 | the sheltered hollow in the terrace's far corner | 140/210 | 30.1 s |
| 82 | I cast Arcane Wave to catch both boars in the hollow, then finish the badly wounded one with Arcane Bolt. | Engine (Menü/Rückfrage) | open_run_level | Fight the boar pair with AoE since both are in range | the sheltered hollow in the terrace's far corner | 140/210 | 6.8 s |
| 83 | I cast Arcane Wave at Tusked Boar E, aiming to catch both boars in the hollow. | Erzähler | open_run_level | Retry AoE with a named target | the sheltered hollow in the terrace's far corner | 108/196 | 17.6 s |
| 84 | I finish the badly wounded Tusked Boar F with Arcane Bolt. | Erzähler | open_run_level | Kill the weaker boar first | the sheltered hollow in the terrace's far corner | 92/187 | 15.3 s |
| 85 | I cast Arcane Bolt at Tusked Boar E before it charges again. | Erzähler | open_run_level | Finish the last boar | the sheltered hollow in the terrace's far corner | 92/178 | 16.1 s |
| 86 | I walk back along the quarry track to Ashbridge's Guild hall and turn in the boar cull contract. | Erzähler | open_run_level | Turn in the READY contract and level up | Adventurers' Guild hall, Ashbridge | 92/178 | 22.4 s |
| 87 | #assign INT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up stat points | Adventurers' Guild hall, Ashbridge | 92/178 | 2.6 s |
| 88 | I ask the clerk what contracts are on the board today, ideally something suited to a mage recovering from wounds. | Erzähler | open_run_level | Pick the next Guild contract | Adventurers' Guild hall, Ashbridge | 92/178 | 24.3 s |
| 89 | I accept the Miller's Crossing ford adder cull contract from the clerk. | Erzähler | open_run_level | Take the light adder contract | Adventurers' Guild hall, Ashbridge | 92/178 | 15.1 s |
| 90 | I walk south along the Silt Road to Miller's Crossing and, on arrival, search the stony shallows for the ford adder. | Erzähler | open_run_level | Travel to the shallows and hunt the adder | the stony shallows of Miller's Crossing on the Silt Road | 92/178 | 18.1 s |
| 91 | I walk slowly among the shallows toward the deepest pool, watching for the adder. | Erzähler | open_run_level | Hunt the ford adder at the marked pool | the stony shallows of Miller's Crossing on the Silt Road | 92/178 | 18.9 s |
| 92 | I keep still at the pool's edge and watch the sun-warmed slab and margins for the adder. | Erzähler | open_run_level | Spot the adder before engaging | the stony shallows of Miller's Crossing on the Silt Road | 92/178 | 15.5 s |
| 93 | I cast Arcane Bolt at the adder on the sun-warmed slab. | Erzähler | open_run_level | Attack the spotted ford adder | the stony shallows of Miller's Crossing on the Silt Road | 92/169 | 13.6 s |
| 94 | The cull count is 1/1, so I head back north along the Silt Road to the Guild hall in town to turn in the contract. | Erzähler | open_run_level | Turn in the completed adder cull at the Guild | Adventurers' Guild hall, Ashbridge | 92/169 | 19.5 s |
| 95 | I check the Guild board for fresh contracts suitable for a Novice. | Erzähler | open_run_level | Pick the next Guild contract | Adventurers' Guild hall, Ashbridge | 92/169 | 12.8 s |
| 96 | I accept the contract 'Cull the Tusked Boar on the Old Quarry Track' from the board. | Erzähler | open_run_level | Take the next achievable cull contract | Adventurers' Guild hall, Ashbridge | 92/169 | 15.7 s |
| 97 | The hunt can wait until morning; I ask the clerk where I can find a cheap bed for the night, then take a room and sleep until dawn. | Erzähler | open_run_level | Recover overnight before hunting the boar | Adventurers' Guild hall, Ashbridge | 92/169 | 23.8 s |
| 98 | I take the private room at the Sign of the Eel for eight copper and sleep until morning. |  | open_run_level | Book a room and recover overnight | Adventurers' Guild hall, Ashbridge | 92/169 | 36.9 s |
| 99 | I book the private room at the Sign of the Eel for eight copper, and once it's booked, I sleep there until morning. | Erzähler | open_run_level | Book the room and sleep overnight | Adventurers' Guild hall, Ashbridge | 92/169 | 28.2 s |
| 100 | I accept the innkeeper's offer: one private room at the Sign of the Eel for eight copper, paid now. | Erzähler | open_run_level | Book the room by explicitly accepting the quoted offer | Adventurers' Guild hall, Ashbridge | 92/169 | 22.2 s |
| 101 | I go to the Wether's Head inn and ask the innkeeper there for a room for the night. | Erzähler | open_run_level | Book lodging at a different inn after repeated failures at the Sign of the Eel | Wether's Head | 92/169 | 19.5 s |
| 102 | I take the common floor bunk for three copper, pay now, and sleep until morning. | Erzähler | open_run_level | Book lodging at the Wether's Head and recover overnight | Wether's Head | 145/272 | 17.1 s |
| 103 | I head to the Old Quarry Track to hunt the tusked boar for my active contract. | Erzähler | open_run_level | Travel to the boar hunting ground for the active cull contract | the old quarry track and its scrub verges east of Ashbridge | 145/272 | 20.3 s |
| 104 | I ready my staff and cast Arcane Bolt at the dark bulk moving in the bracken. | Engine (Menü/Rückfrage) | open_run_level | Engage the tusked boar for the cull contract | the old quarry track and its scrub verges east of Ashbridge | 145/272 | 4.9 s |
| 105 | I move quietly along the lane toward the bracken and wait for the animal to step into clear view, staff ready. | Erzähler | open_run_level | Get close enough for the boar to become a targetable actor | the old quarry track and its scrub verges east of Ashbridge | 145/272 | 25.8 s |
| 106 | I cast Arcane Bolt at the tusked boar broadside in the lane. | Erzähler | open_run_level | Open the fight with a bolt on the now-targetable boar | the old quarry track and its scrub verges east of Ashbridge | 145/263 | 18.5 s |
| 107 | I check my quest panel to confirm the boar cull now reads 1/1, then head back to the Guild hall in Ashbridge to turn in the contract. | Erzähler | open_run_level | Turn in the completed cull contract | Adventurers' Guild hall, Ashbridge | 145/263 | 21.5 s |
| 108 | #assign INT 3 WIL 2 | System (Befehl) | open_run_level | Spend the five free stat points from the level-up, then look at the Guild board for the ne… | Adventurers' Guild hall, Ashbridge | 145/263 | 2.6 s |
| 109 | I ask the clerk what contracts are on the board for a Novice mage. | Erzähler | open_run_level | Look for the next Guild contract | Adventurers' Guild hall, Ashbridge | 145/263 | 24.7 s |
| 110 | I take the Ford Adder contract slip from the board and ask the clerk to register it as active. | Erzähler | open_run_level | Accept the Miller's Crossing adder cull contract | Adventurers' Guild hall, Ashbridge | 145/263 | 17.9 s |
| 111 | I sell my surplus pelts and fangs to Hessel at the tanner yard, then follow the Silt Road east to Miller's Crossing and walk down to the sto… | Erzähler | open_run_level | Sell loot on the way, then travel to the adder site | Hessel's tanner yard | 145/263 | 36.5 s |
| 112 | I accept Hessel's offer of twenty-five coppers for the whole table and hand over the skins, hide, tusks and fangs. | Erzähler | open_run_level | Sell all surplus loot for the offered 25 cp | Hessel's tanner yard | 145/263 | 29.1 s |
| 113 | I follow the Silt Road east to Miller's Crossing and walk to the stony shallows, keeping to the bank to scan the water and reeds for the add… | Erzähler | open_run_level | Travel to the ford adder site and scout it | the stony shallows of Miller's Crossing on the Silt Road | 145/263 | 19.8 s |
| 114 | I search the reeds along the near bank for the adder before stepping onto the crossing stones. | Erzähler | open_run_level | Locate the ford adder at the shallows | the stony shallows of Miller's Crossing on the Silt Road | 145/263 | 16.4 s |
| 115 | I cast Arcane Bolt at the ford adder basking on the sun-warmed slab in the shallows. | Engine (Menü/Rückfrage) | open_run_level | Attack the spotted ford adder from range | the stony shallows of Miller's Crossing on the Silt Road | 145/263 | 4.7 s |
| 116 | I walk out across the crossing stones, watching the water and the far reeds for the adder. | Erzähler | open_run_level | Cross the ford and search for the adder on the far side | the stony shallows of Miller's Crossing on the Silt Road | 145/263 | 16.6 s |
| 117 | I cast Arcane Bolt at the ford adder striking at me in the deep stretch. | Erzähler | open_run_level | Fight the engaged ford adder at range | the stony shallows of Miller's Crossing on the Silt Road | 145/254 | 16.3 s |
| 118 | I follow the Silt Road back to the Duskreach Guild hall and turn in the completed contract, Cull the Ford Adder at Miller's Crossing, with i… | Erzähler | open_run_level | Turn in the completed adder contract at the Guild hall | Adventurers' Guild hall, Ashbridge | 145/254 | 20.4 s |
| 119 | I ask the clerk what's on the contract board today. | Erzähler | open_run_level | Check the Guild board for a new achievable contract | Adventurers' Guild hall, Ashbridge | 145/254 | 15.5 s |
| 120 | I accept the contract Cull the Tusked Boar on the Old Quarry Track and confirm it's ACTIVE before heading out. | Erzähler | open_run_level | Take the boar cull contract | Adventurers' Guild hall, Ashbridge | 145/254 | 22.4 s |
| 121 | I walk east along the old quarry track, watching the scrub on both sides for the tusked boar. | Erzähler | open_run_level | Travel the Old Quarry Track and search for the boar | Adventurers' Guild hall, Ashbridge | 145/254 | 16.2 s |
| 122 | I walk east along the old quarry track toward the quarry face. | Erzähler | open_run_level | Travel the track properly to find the boar | Adventurers' Guild hall, Ashbridge | 145/254 | 19.2 s |
| 123 | I cast Arcane Bolt at the charging boar. | Engine (Menü/Rückfrage) | open_run_level | Engage the charging boar at range | Adventurers' Guild hall, Ashbridge | 145/254 | 6.1 s |
| 124 | I cast Arcane Bolt at the tusked boar. | Engine (Menü/Rückfrage) | open_run_level | Engage the boar with a correctly named target | Adventurers' Guild hall, Ashbridge | 145/254 | 4.8 s |
| 125 | I leave the Guild hall and set out east along the Old Quarry Track. | Erzähler | open_run_level | Fix the scene mismatch by explicitly leaving the hall before travelling | the old quarry track and its scrub verges east of Ashbridge | 145/254 | 18.9 s |
| 126 | I follow the rooting sign east along the track toward the quarry steps, staff ready. | Erzähler | open_run_level | Track the boar toward the quarry | the base of the quarry steps | 145/254 | 25.5 s |
| 127 | I cast Arcane Bolt at the Tusked Boar H. | Erzähler | open_run_level | Engage the boar at range with the valid target name | the base of the quarry steps | 145/254 | 15.1 s |
| 128 | I hold my ground and let the boar close to MEDIUM, then cast Arcane Bolt at it. | Erzähler | open_run_level | Wait for the boar to enter spell range before casting | the base of the quarry steps | 145/245 | 15.4 s |
| 129 | I cast Arcane Bolt at the Tusked Boar H. | Erzähler | open_run_level | Finish the wounded boar before it gored me | the base of the quarry steps | 145/236 | 13.1 s |
| 130 | I head west along the Old Quarry Track back toward Ashbridge to turn in the boar cull at the Guild hall. | Erzähler | open_run_level | Return to the Guild and turn in the completed contract | Adventurers' Guild hall, Ashbridge | 145/236 | 17.4 s |
| 131 | I ask the clerk for a new Guild contract suitable for a Novice mage, ideally something I can finish by tomorrow. | Erzähler | open_run_level | Pick up the next contract | Adventurers' Guild hall, Ashbridge | 145/236 | 17.5 s |
| 132 | I take the Clear Mossback Warrens, Level 1 slip from the board and tell the clerk I accept it. | Erzähler | open_run_level | Accept the achievable goblin warrens contract from the Guild board | Adventurers' Guild hall, Ashbridge | 145/236 | 17.6 s |
| 133 | Before I go, I ask the two hunters at the far table what they know about the Mossback Warrens and the man who came back down the hill alone. | Erzähler | open_run_level | Gather rumor details on the warrens before resting | Adventurers' Guild hall, Ashbridge | 145/236 | 26.0 s |
| 134 | I buy the Primer of Guard from the clerk for 80 copper and use it to learn the skill. | Erzähler | open_run_level | Learn Guard before the warrens; then rest | Adventurers' Guild hall, Ashbridge | 145/236 | 18.4 s |
| 135 | I take a Guild bunk for the night and study the Primer of Guard until I've learned the skill, then sleep until morning. | Erzähler | open_run_level | Learn Guard and rest before the warrens | Adventurers' Guild hall, Ashbridge | 145/236 | 23.2 s |
| 136 | I take the latching cell for two coppers, then study the Primer of Guard for two hours by lamplight before sleeping until morning. | Erzähler | open_run_level | Book bunk, learn Guard, rest | Adventurers' Guild hall, Ashbridge | 150/316 | 21.7 s |
| 137 | I leave the Guild hall and travel to the Mossback Warrens to clear its level 1. | Erzähler | open_run_level | Travel to the warrens and clear level 1 | Mossback Warrens | 150/316 | 22.3 s |
| 138 | I enter the Mossback Warrens through the tunnel mouth, advancing cautiously and watching for traps or goblins. | Erzähler | open_run_level | Enter the dungeon and clear level 1 | Mossback Warrens, level 1 entry chamber | 150/316 | 22.1 s |
| 139 | I cast Arcane Bolt at the wounded-looking Goblin Lookout B, staying in the tunnel mouth where the narrow gap limits how many can reach me. | Erzähler | open_run_level | Open the fight with the weaker lookout from a chokepoint | Mossback Warrens, level 1 entry chamber | 135/307 | 17.3 s |
| 140 | I cast Arcane Bolt at Goblin Lookout A at point-blank range. | Erzähler | open_run_level | Finish the remaining lookout | Mossback Warrens, level 1 entry chamber | 120/298 | 17.2 s |
| 141 | I cast Arcane Bolt at Goblin Lookout A to finish it. | Erzähler | open_run_level | Finish the wounded goblin | Mossback Warrens, level 1 entry chamber | 120/289 | 13.5 s |
| 142 | #assign INT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up stat points | Mossback Warrens, level 1 entry chamber | 120/289 | 2.8 s |
| 143 | I take stock of my wounds — HP 120/150, lightly hurt — and press carefully deeper into the level 1 warrens past the far gap, advancing slowl… | Erzähler | open_run_level | Clear Mossback Warrens level 1 | goblin camp past the far gap | 120/289 | 20.9 s |
| 144 | I stay in the tunnel mouth as a chokepoint and cast Arcane Bolt at Goblin Spearman A. | Erzähler | open_run_level | Fight the spearmen from the narrow gap | goblin camp past the far gap | 112/280 | 16.5 s |
| 145 | I shove the goblin back a step and cast Arcane Bolt at Goblin Spearman B point-blank. | Erzähler | open_run_level | Finish the last spearman | goblin camp past the far gap | 112/271 | 12.5 s |
| 146 | I press on carefully down the tunnel beyond the camp, staff ready, heading toward where the muttering went quiet. | Erzähler | open_run_level | Continue clearing Mossback Warrens level 1 | worked chamber with the ring-sign door | 112/271 | 22.8 s |
| 147 | I take the right passage, dry and well-used, advancing cautiously with my staff ready. | Erzähler | open_run_level | Continue clearing Mossback Warrens level 1 | goblin camp past the far gap | 112/271 | 23.7 s |
| 148 | I stay behind the netting curtain as cover and cast Arcane Bolt at the Palisade Chief. | Erzähler | open_run_level | Engage the chief from the chokepoint | goblin camp past the far gap | 89/262 | 20.5 s |
| 149 | I cast Arcane Bolt at the Palisade Chief. | Erzähler | open_run_level | Finish the chief with bolts | goblin camp past the far gap | 89/253 | 34.5 s |
| 150 | I check the crawl-hole briefly for danger, then turn back and head for the exit — level 1 is cleared, so I return to the Guild hall in Ashbr… | Erzähler | open_run_level | Turn in the cleared warrens contract at the Guild | Adventurers' Guild hall, Ashbridge | 89/253 | 34.2 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 5 (notiert vor Zug 6): HUD shows 3 Silver but engine said 30 copper after paying 20; coin display may be inconsistent.
- zu Zug 6 (notiert vor Zug 7): Coin display now consistent at 3 Silver (30 copper).
- zu Zug 16 (notiert vor Zug 17): Second boar suspected in the scrub beyond the thicket; watch for it after this fight.
- zu Zug 18 (notiert vor Zug 19): Contract progress 1/4; second boar sign still in the gorse thicket upslope.
- zu Zug 20 (notiert vor Zug 21): System refused a target on narration alone; need actual line of sight before attacking.
- zu Zug 21 (notiert vor Zug 22): Narration showed the bolt loosed, but HUD still reads 66/66 — the engine result shows no damage yet, so I re-attack the confirmed target.
- zu Zug 27 (notiert vor Zug 28): No third boar was present at the northern fold despite earlier narration of a feeding boar; only 2/4 confirmed defeated.
- zu Zug 28 (notiert vor Zug 29): Contract has no deadline or location restriction; hunting in the dark is unwise on unfamiliar ground.
- zu Zug 32 (notiert vor Zug 33): Purchase succeeded on the third attempt with explicit phrasing; sleep restored full HP and MP.
- zu Zug 36 (notiert vor Zug 37): System repeatedly reports 'no targetable actor' in the active scene despite narration of the rooting boar; approaching directly to trigger the encounter.
- zu Zug 38 (notiert vor Zug 39): Sow at LONG blocks Arcane Bolt (MEDIUM max); second unseen animal approaching from behind.
- zu Zug 41 (notiert vor Zug 42): 3/4 boars defeated; a second creature in the southern scrub remains untargetable and unengaged — withdrawing instead of provoking it.
- zu Zug 44 (notiert vor Zug 45): Engine resolves one main action per turn; split move and attack.
- zu Zug 53 (notiert vor Zug 54): Contract paid out 1g4s and 300 XP; loot was already held. Level 4, HP 58/135 wounded.
- zu Zug 59 (notiert vor Zug 60): Narrator repeated the offer instead of confirming the sale; HUD still shows the loot carried.
- zu Zug 64 (notiert vor Zug 65): Contract confirmed active in HUD (0/1). HP still low at 58/135 — may need rest before the fight.
- zu Zug 68 (notiert vor Zug 69): XP 394/400 — next kill or turn-in likely levels me up.
- zu Zug 75 (notiert vor Zug 76): Room booking was refused as 'arrival pending'; now inside the room, trying plain sleep.
- zu Zug 81 (notiert vor Zug 82): Narration was heavily garbled with visible self-corrections; engine panels stayed consistent.
- zu Zug 82 (notiert vor Zug 83): Arcane Wave required an explicitly named target; nothing was spent on the failed cast.
- zu Zug 98 (notiert vor Zug 99): Engine says the room was not booked despite narration showing payment; HUD still shows me at the Guild hall. Retrying the purchase explicitly.
- zu Zug 99 (notiert vor Zug 100): Engine repeatedly fails to book the room despite narration showing payment; trying explicit offer-acceptance wording.
- zu Zug 100 (notiert vor Zug 101): Engine repeatedly refused the Sign of the Eel room booking ('nobody to pay', 'no valid canonical offer') and HUD keeps placing me at the Guild hall despite inn narration; giving up on that inn after three failures.
- zu Zug 102 (notiert vor Zug 103): Lodging finally worked at the Wether's Head after repeated Sign of the Eel failures; full recovery confirmed.
- zu Zug 103 (notiert vor Zug 104): Quest panel shows 0/1 boar defeated despite carrying boar hides and tusks, so earlier kills apparently were not counted toward this contract.
- zu Zug 104 (notiert vor Zug 105): System refused to target 'dark bulk' because it is only sign, not an actor; must wait for the boar to actually appear.
- zu Zug 106 (notiert vor Zug 107): Kill finally counted: quest panel shows 1/1 defeated after the ambush crit.
- zu Zug 107 (notiert vor Zug 108): Level 7 confirmed after boar turn-in; surplus boar hides and tusks can be sold to Hessel at the tanner yard.
- zu Zug 112 (notiert vor Zug 113): HUD still lists location as Hessel's tanner yard despite narration of arrival at the shallows; travel explicitly to settle it.
- zu Zug 121 (notiert vor Zug 122): Previous move refused for 'watching scrub' phrasing; HUD still shows me at the Guild hall despite narration placing me at the track mouth — trusting HUD, walking again.
- zu Zug 122 (notiert vor Zug 123): HUD location still says Guild hall despite narration placing me on the track — trusting the newest narration plus active quest state.
- zu Zug 123 (notiert vor Zug 124): System says active scene is Clerk B at the Guild hall while narration places me facing the boar — scene/location mismatch; retrying with exact target name.
- zu Zug 124 (notiert vor Zug 125): System repeatedly keeps ACTIVE SCENE as Clerk B despite travel narration; trying an explicit departure to reset the scene.
- zu Zug 125 (notiert vor Zug 126): HUD now confirms active scene/location on the quarry track; quest shows 0/1 defeated.
- zu Zug 133 (notiert vor Zug 134): Quest reward shown as 80 cp on HUD vs 15 silver on the slip; will verify at turn-in.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t9 | 9 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t15 | 15 | 1 | – | ja | 1 | gewonnen, 180 XP |
| enc.t20 | 22 | 1 | – | nein | 1 | gewonnen, 102 XP |
| enc.t31 | 39 | 1 | – | nein | 1 | gewonnen, 190 XP |
| enc.t41 | 49 | 1 | – | nein | 1 | gewonnen, 128 XP |
| enc.t58r | 67 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t69 | 79 | 1 | – | nein | 1 | gewonnen, 190 XP |
| enc.t72 | 83 | 2 | – | nein | 2 | gewonnen, 254 XP |
| enc.t81 | 93 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t93 | 106 | 1 | – | nein | 1 | gewonnen, 102 XP |
| enc.t102 | 117 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t111 | 128 | 1 | – | nein | 1 | gewonnen, 152 XP |
| enc.t122 | 139 | 2 | – | nein | 2 | gewonnen, 158 XP |
| enc.t126 | 144 | 2 | – | nein | 2 | gewonnen, 78 XP |
| enc.t130 | 148 | 1 | – | nein | 1 | gewonnen, 238 XP |

## Quests

- **Cull the Ford Adder at Miller's Crossing** — active (Zug 6) → completed (Zug 10)
  - Aufgabe: Kill 1 ford adder at the stony shallows of Miller's Crossing on the Silt Road. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 ford adder killed at the stony shallows of Miller's Crossing on the Silt Road.
- **Thin the Quarry-Track Boars** — active (Zug 12) → completed (Zug 53)
  - Aufgabe: Kill 4 tusked boars at the old quarry track and its scrub verges east of Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 tusked boars killed at the old quarry track and its scrub verges east of Ashbridge.
- **Cull the Fen Serpents of the Reed Flats** — expired (Zug 63)
  - Aufgabe: Kill 6 fen serpents at the eel-weirs of the Reed Flats south of Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 6 fen serpents killed at the eel-weirs of the Reed Flats south of Ashbridge.
- **Slay the Duskreach Ridge Bear** — expired (Zug 63)
  - Aufgabe: Kill 1 great scarred ridge bear at the high crags of the northern sheepwalks above Duskreach. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 great scarred ridge bear killed at the high crags of the northern sheepwalks above Duskreach.
- **Clear Mossback Warrens, Level 1** — expired (Zug 63), Dungeon loc.mossback_warrens Ebene 1
  - Aufgabe: Clear level 1 of Mossback Warrens. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Mossback Warrens is clear.
- **Cull the Ford Adder at Miller's Crossing** — active (Zug 64) → completed (Zug 69)
  - Aufgabe: Kill 1 ford adder at the stony shallows of Miller's Crossing on the Silt Road. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 ford adder killed at the stony shallows of Miller's Crossing on the Silt Road.
- **Cull the Tusked Boar on the Old Quarry Track** — active (Zug 72) → completed (Zug 86), READY
  - Aufgabe: Kill 2 tusked boar at the old quarry track and its scrub verges east of Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 2 tusked boar killed at the old quarry track and its scrub verges east of Ashbridge.
- **Cull the Fen Serpents at the Reed Flats Eel-Weirs** — expired (Zug 88)
  - Aufgabe: Kill 3 fen serpent at the eel-weirs of the Reed Flats south of Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 fen serpent killed at the eel-weirs of the Reed Flats south of Ashbridge.
- **Cull the Great Scarred Ridge Bear of the Northern Sheepwalks** — expired (Zug 88)
  - Aufgabe: Kill 1 great scarred ridge bear at the high crags of the northern sheepwalks above Duskreach. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 great scarred ridge bear killed at the high crags of the northern sheepwalks above Duskreach.
- **Clear Mossback Warrens Level 1** — expired (Zug 88), Dungeon loc.mossback_warrens Ebene 1
  - Aufgabe: Clear level 1 of Mossback Warrens. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Mossback Warrens is clear.
- **Cull the Ford Adder at Miller's Crossing** — active (Zug 89) → completed (Zug 94)
  - Aufgabe: Kill 1 ford adder at the stony shallows of Miller's Crossing on the Silt Road. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 ford adder killed at the stony shallows of Miller's Crossing on the Silt Road.
- **Cull the Tusked Boar on the Old Quarry Track** — active (Zug 96) → completed (Zug 107)
  - Aufgabe: Kill 1 tusked boar at the old quarry track and its scrub verges east of Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 tusked boar killed at the old quarry track and its scrub verges east of Ashbridge.
- **Thin the Fen Serpents of the Reed Flats** — expired (Zug 109)
  - Aufgabe: Kill 3 fen serpent at the eel-weirs of the Reed Flats south of Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 fen serpent killed at the eel-weirs of the Reed Flats south of Ashbridge.
- **Slay the Great Scarred Ridge Bear** — expired (Zug 109)
  - Aufgabe: Kill 1 great scarred ridge bear at the high crags of the northern sheepwalks above Duskreach. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 great scarred ridge bear killed at the high crags of the northern sheepwalks above Duskreach.
- **Clear Mossback Warrens Level 1** — expired (Zug 109), Dungeon loc.mossback_warrens Ebene 1
  - Aufgabe: Clear level 1 of Mossback Warrens. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Mossback Warrens is clear.
- **Cull the Ford Adder at Miller's Crossing** — active (Zug 110) → completed (Zug 118)
  - Aufgabe: Kill 1 ford adder at the stony shallows of Miller's Crossing on the Silt Road. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 ford adder killed at the stony shallows of Miller's Crossing on the Silt Road.
- **Cull the Tusked Boar on the Old Quarry Track** — active (Zug 120) → completed (Zug 130)
  - Aufgabe: Kill 1 tusked boar at the old quarry track and its scrub verges east of Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 tusked boar killed at the old quarry track and its scrub verges east of Ashbridge.
- **Clear Mossback Warrens Level 1** — active (Zug 132) → completed (Zug 150), Dungeon loc.mossback_warrens Ebene 1
  - Aufgabe: Clear level 1 of Mossback Warrens. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Mossback Warrens is clear.

## Auffälligkeiten

- Zug 4, Nachricht 8 (extraction_repaired): the extractor's first answer needed a repair
- Zug 8, Nachricht 16 (extraction_repaired): the extractor's first answer needed a repair
- Zug 12, Nachricht 24 (extraction_repaired): the extractor's first answer needed a repair
- Zug 30, Nachricht 59 (planner_repaired): the planner's first answer needed a repair
- Zug 31, Nachricht 61 (planner_repaired): the planner's first answer needed a repair
- Zug 42, Nachricht 84 (extraction_repaired): the extractor's first answer needed a repair
- Zug 59, Nachricht 117 (planner_repaired): the planner's first answer needed a repair
- Zug 60, Nachricht 119 (planner_repaired): the planner's first answer needed a repair
- Zug 65, Nachricht 130 (extraction_repaired): the extractor's first answer needed a repair
- Zug 77, Nachricht 154 (extraction_repaired): the extractor's first answer needed a repair
- Zug 98, Nachricht 196 (extraction_failed): the extractor failed: $.deltas[4] (fact): .s: expected string, got object
- Zug 98, Nachricht 196 (extraction_repaired): the extractor's first answer needed a repair
- Zug 99, Nachricht 198 (extraction_repaired): the extractor's first answer needed a repair
- Zug 100, Nachricht 199 (planner_repaired): the planner's first answer needed a repair
- Zug 105, Nachricht 210 (extraction_repaired): the extractor's first answer needed a repair
- Zug 112, Nachricht 223 (planner_repaired): the planner's first answer needed a repair
- Zug 112, Nachricht 224 (extraction_repaired): the extractor's first answer needed a repair
- Zug 120, Nachricht 240 (extraction_repaired): the extractor's first answer needed a repair
- Zug 147, Nachricht 294 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (goblin): refused, no fight (Patch 8.4.1 guard)
- Zug 149, Nachricht 298 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (goblin spearman): refused, no fight (Patch 8.4.1 guard)
- Zug 150, Nachricht 300 (extraction_repaired): the extractor's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 21× keine gültige JSON-Entscheidung (Züge 4, 14, 24, 30, 44, 47, 54, 55, 78, 79, 87, 91, 93, 108, 110, 114, 117, 137, 144, 146, 147)

System-Panels: CLARIFY 3, NOT TAKEN 2, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: ambient 1, guild_canon 3, guild_canon_price 1, engine_owned_fact 16, attack_commitment 3, pc_inventory 4, guild_completion 2, world_rule 20, engine_recovery 3, quest_count 2, offer 1, scene_context 27, no_go 8, guild_payout 4, engine_owned_memory 1, group_unclear 1, dungeon_foe 2, quest_dependency 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 21/150 Erstantworten ungültig (14.0 %); 21 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 147 | 6 | 2.5 s | 4.2 s | 12190 | 9959 | 80 | – | stop 147 | 0 |
| board | 5 | 1 | 9.2 s | 10.0 s | 2573 | 2238 | 1005 | – | stop 5 | 0 |
| narrator | 130 | 0 | 7.6 s | 10.8 s | 11363 | 8859 | 355 | – | stop 130 | 0 |
| extract | 142 | 12 | 4.7 s | 8.5 s | 12504 | 9495 | 304 | – | stop 142 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 53:40 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 11.8 s) | 0:26 min |
| 150 Züge, Spiel (Senden bis HUD nach der Extraktion) | 44:06 min — Median 17.4 s, p90 26.0 s, max 37.2 s |
| 150 Züge, Spieler-Entscheidung | 6:17 min — Median 1.9 s, 21 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 7:13 min / 0:47 min / 17:42 min / 12:18 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 20.2 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 13:26 min, 80 Züge ≈ 26:53 min (ohne Einrichtung) |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
