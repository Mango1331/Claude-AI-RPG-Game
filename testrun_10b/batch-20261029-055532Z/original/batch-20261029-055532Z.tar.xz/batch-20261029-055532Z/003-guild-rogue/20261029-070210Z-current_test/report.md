# Avereth Live-Test 20261029-070210Z-current_test

## Kurzfassung

- **Laufprofil:** guild-rogue; Startklasse Rogue, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** abgebrochen: Limit erreicht — 150 turns
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 4. Sicherheitsgrenzen: 150 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** Level 3, 32 XP seit Levelaufstieg, 38 cp, HP 100, MP 88; Ort loc.glassmere.guild_hall. Ausrüstung und Skills stehen in evaluation.json → progression.checkpoint.
- **Charakter:** rogue (rogue.razor_cut, rogue.fan_of_blades) · Regelstand 2 (Warrior, Mage, Rogue)
- **Ziel-Dungeon:** Glimmerdeep Grotto, Ebene 1 (Vertrag quest.clear_the_crystal_beetles_of_glimmerdeep_grotto_level_1)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: pragmatic adventurer: sell surplus loot and invest in useful equipment and techniques
- **Züge:** 150 · **Dauer:** 52:25 min · **LLM-Aufrufe der Engine/des Erzählers:** 411
- **Beobachtete Abdeckung:** 23 unterschiedliche gebuchte Reiseziele · 7 Kämpfe · 1 Verkäufe (20 cp Umsatz, ohne Questzahlungen/Geschenke) · 0 Ausrüstungswechsel · 1 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 36
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.116 |
| Git | 41a17fc50ba2 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 16.3 s |
| Browser | chrome 156.0.8078.49 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261029-070210Z-current_test“, Seed 1908782374 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | Rogue | Engine (Menü/Rückfrage) | creation_complete |  | public roadside verge outside Glassmere | 90/84 | 2.3 s |
| 2 | I choose Fan of Blades and Razor Cut. | Engine (Menü/Rückfrage) | creation_complete | Select required AoE starter skill plus a cheap reliable attack | public roadside verge outside Glassmere | 90/84 | 2.1 s |
| 3 | I walk through the city gate of Glassmere and head for the Adventurers' Guild hall to look at the contract board. | Erzähler | open_run_level | Enter city and find Guild contracts | Adventurers' Guild hall, Glassmere | 90/84 | 37.8 s |
| 4 | I approach the clerk and ask to register with the Guild as a new adventurer. | Erzähler | open_run_level | Register at Guild to unlock contracts | Adventurers' Guild hall, Glassmere | 90/84 | 14.3 s |
| 5 | I pay the two silver and register: Alaric, twenty-two, can read and write. | Erzähler | open_run_level | Register with the Guild | Adventurers' Guild hall, Glassmere | 90/84 | 21.3 s |
| 6 | I ask the clerk whether the morning contracts have been sorted yet, and if so to see the board. | Erzähler | open_run_level | Get a Guild contract | Adventurers' Guild hall, Glassmere | 90/84 | 16.3 s |
| 7 | I wait for the clerk to finish sorting, then ask to see the Novice-rank contracts on the board. | Erzähler | open_run_level | Get a Guild contract from the filled board | Adventurers' Guild hall, Glassmere | 90/84 | 38.6 s |
| 8 | I take the millrace slip from the board and ask the clerk to accept the contract. | Erzähler | open_run_level | Accept the millrace contract | Adventurers' Guild hall, Glassmere | 90/84 | 13.6 s |
| 9 | I leave the Guild hall and follow the water south toward the millrace below Glassmere to hunt the grass serpent at the sluice. | Erzähler | open_run_level | Travel to the millrace contract site | the millrace sluice below Glassmere's mill | 90/84 | 18.4 s |
| 10 | I move quietly along the landing platform above the sluice gates and wait with my dagger ready for the serpent to surface near the reed clum… | Erzähler | open_run_level | Ambush the grass serpent at the sluice | the millrace sluice below Glassmere's mill | 90/84 | 15.3 s |
| 11 | I stay hidden by the sluice framing and watch the reed clump and the far edge, dagger ready, waiting for the serpent to surface before strik… | Erzähler | open_run_level | Ambush the grass serpent | the millrace sluice below Glassmere's mill | 85/84 | 16.4 s |
| 12 | I attack the serpent with Razor Cut. | Erzähler | open_run_level | Kill the grass serpent for the contract | the millrace sluice below Glassmere's mill | 85/84 | 17.2 s |
| 13 | I retrieve the serpent carcass from against the guide post and carry it back to the mill, then start up the road toward Glassmere's Guild ha… | Erzähler | open_run_level | Turn in the millrace contract at the Guild | Adventurers' Guild hall, Glassmere | 85/84 | 37.3 s |
| 14 | I ask the clerk what contracts are on the board suitable for a Novice rogue. | Erzähler | open_run_level | Choose the next Guild contract | Adventurers' Guild hall, Glassmere | 85/84 | 17.7 s |
| 15 | I take the beetle slip from the board and hand it to the clerk. "I'll take the Glimmerdeep Grotto job — clear level 1." | Erzähler | open_run_level | Accept the Crystal Beetles contract | Adventurers' Guild hall, Glassmere | 85/84 | 19.2 s |
| 16 | I take the slip and head west out of the market on the shepherd's track toward Glimmerdeep Grotto. | Erzähler | open_run_level | Travel to the Grotto for the beetle contract | Glimmerdeep Grotto | 85/84 | 19.2 s |
| 17 | I enter the Grotto and stay in the shadows at the passage mouth, waiting until the grazing beetles turn away, then ambush the nearest one wi… | Erzähler | open_run_level | Enter dungeon and ambush the beetle group | Glimmerdeep Grotto | 85/84 | 18.8 s |
| 18 | I attack the nearer beetle with Fan of Blades, keeping the burst away from the other beetle's direction so I don't pull it early. | Engine (Menü/Rückfrage) | open_run_level | Clear the beetle contract, starting with one target | Glimmerdeep Grotto | 85/84 | 5.0 s |
| 19 | I step out of the shadows and attack the nearest crystal beetle with Fan of Blades, angling the burst away from the second beetle. | Engine (Menü/Rückfrage) | open_run_level | Engage the beetles to clear the contract | Glimmerdeep Grotto | 85/84 | 4.3 s |
| 20 | I attack the crystal beetle with Basic Attack. | Engine (Menü/Rückfrage) | open_run_level | Engage the beetles to clear the contract | Glimmerdeep Grotto | 85/84 | 5.7 s |
| 21 | I walk deeper into the outer grotto to search for the crystal beetles. | Erzähler | open_run_level | Find a valid combat scene for the beetle contract | Glimmerdeep Grotto | 85/84 | 19.3 s |
| 22 | I address the beetle staring at me and declare my attack on it: "Crystal beetle, I strike you now!" then use Basic Attack on the crystal bee… | Engine (Menü/Rückfrage) | open_run_level | Trigger targetable scene by explicitly addressing the beetle | Glimmerdeep Grotto | 85/84 | 3.9 s |
| 23 | #help | System (Befehl) | open_run_level | Find correct combat/scene commands since attacks report no targetable actor | Glimmerdeep Grotto | 85/84 | 2.1 s |
| 24 | #combat | System (Befehl) | open_run_level | Inspect the encounter audit to see why no scene or target is active | Glimmerdeep Grotto | 85/84 | 2.1 s |
| 25 | I draw my dagger and commit to the fight, attacking the crystal beetle. | Engine (Menü/Rückfrage) | open_run_level | Trigger active combat scene by a hostile commitment | Glimmerdeep Grotto | 85/84 | 3.9 s |
| 26 | I walk deeper into the outer grotto, watching and listening for the crystal beetles. | Erzähler | open_run_level | Find the beetles and trigger a targetable combat scene | crystal rib chamber | 85/84 | 22.5 s |
| 27 | I attack Crystal Beetle A with my dagger, committing to the fight against the nearer beetle. | Erzähler | open_run_level | Engage the now-targetable beetles for the contract | crystal rib chamber | 85/84 | 14.7 s |
| 28 | I declare I close the distance, moving up to Crystal Beetle A, then attack it with my dagger. | Erzähler | open_run_level | Close range then engage beetle | crystal rib chamber | 85/84 | 20.4 s |
| 29 | I advance to ENGAGED range on Crystal Beetle A, moving carefully across the polished floor, and attack once I am in reach. | Erzähler | open_run_level | Close to ENGAGED range explicitly before attacking | crystal rib chamber | 85/84 | 15.4 s |
| 30 | I use Fan of Blades on both crystal beetles, since it should strike at range. | Engine (Menü/Rückfrage) | open_run_level | Attack the out-of-reach beetles with a ranged AoE skill | crystal rib chamber | 85/84 | 5.3 s |
| 31 | I use Fan of Blades targeting Crystal Beetle A and Crystal Beetle B. | Erzähler | open_run_level | Attack both beetles with named targets for the ranged AoE skill | crystal rib chamber | 85/84 | 18.5 s |
| 32 | I use Razor Cut on Crystal Beetle A. | Erzähler | open_run_level | Try the other known skill's reach against the kiting beetle | crystal rib chamber | 85/84 | 13.5 s |
| 33 | I throw my starter dagger at Crystal Beetle A. | Erzähler | open_run_level | Try a thrown ranged attack on the out-of-reach beetle | crystal rib chamber | 85/84 | 14.8 s |
| 34 | I withdraw through the exit back to Glimmerdeep Grotto, leaving the beetles' range, then re-enter the crystal rib chamber to see if they hav… | Erzähler | open_run_level | Reset the standoff by leaving and re-entering the chamber | crystal rib chamber | 85/84 | 24.4 s |
| 35 | I use Fan of Blades at MEDIUM range on Crystal Beetle A. | Erzähler | open_run_level | Test whether the ranged AoE skill can reach MEDIUM | crystal rib chamber | 85/84 | 12.3 s |
| 36 | I close to SHORT range of Crystal Beetle A and use Razor Cut on it. | Erzähler | open_run_level | Declare movement to SHORT and attack the beetle | crystal rib chamber | 85/84 | 13.5 s |
| 37 | I walk straight up to Crystal Beetle A, closing the ten paces, and stab it with my dagger using Basic Attack. | Erzähler | open_run_level | Close distance as its own move, then attack | crystal rib chamber | 85/84 | 11.1 s |
| 38 | I move to ENGAGED range of Crystal Beetle A. | Erzähler | open_run_level | Close distance as a standalone move, no attack attached | crystal rib chamber | 85/84 | 13.3 s |
| 39 | I stab Crystal Beetle A with my dagger using Basic Attack. | Erzähler | open_run_level | Attack the beetle now that I'm at ENGAGED range | crystal rib chamber | 76/84 | 17.3 s |
| 40 | I finish Crystal Beetle A with Razor Cut. | Erzähler | open_run_level | Kill the wounded beetle | crystal rib chamber | 76/84 | 12.7 s |
| 41 | I attack Crystal Beetle B at ENGAGED range with Razor Cut. | Erzähler | open_run_level | Kill the second beetle | crystal rib chamber | 76/84 | 11.9 s |
| 42 | I move to ENGAGED range of Crystal Beetle B, then stab it with Basic Attack. | Erzähler | open_run_level | Close and attack the second beetle | crystal rib chamber | 67/84 | 12.5 s |
| 43 | I finish Crystal Beetle B with Razor Cut. | Erzähler | open_run_level | Kill the wounded beetle | crystal rib chamber | 67/84 | 31.3 s |
| 44 | #assign AGI 2 PER 2 WIL 1 | System (Befehl) | open_run_level | Spend the five level-up stat points | crystal rib chamber | 67/84 | 2.1 s |
| 45 | I press on deeper into Glimmerdeep Grotto level 1, following the passage beyond the crystal rib chamber to clear the remaining threats. | Erzähler | open_run_level | Continue the beetle-clearing contract | crystal rib chamber | 67/84 | 18.7 s |
| 46 | I take the wide western water-carved break in the crystal ribs and follow the passage, staying alert. | Erzähler | open_run_level | Explore western passage to clear remaining threats | silt terrace chamber | 67/84 | 17.6 s |
| 47 | I circle the ooze at a careful distance and throw a dagger at it from range, keeping to the slick stone terraces where it can't easily reach… | Erzähler | open_run_level | Attack the quartz ooze safely from range | silt terrace chamber | 67/84 | 17.1 s |
| 48 | I close to ENGAGED range of the quartz ooze and strike it with Razor Cut. | Erzähler | open_run_level | Engage and attack the ooze | silt terrace chamber | 67/84 | 13.9 s |
| 49 | I walk up to the ooze at the chamber's center and strike it with Razor Cut. | Erzähler | open_run_level | Engage the ooze at melee range and attack | silt terrace chamber | 67/84 | 12.1 s |
| 50 | I move across the open silt floor to ENGAGED range of the quartz ooze. | Erzähler | open_run_level | Close distance to the ooze so Razor Cut can reach it next turn | silt terrace chamber | 67/84 | 15.9 s |
| 51 | I strike the quartz ooze with Razor Cut. | Erzähler | open_run_level | Attack the ooze now that it is at SHORT range | silt terrace chamber | 67/84 | 13.9 s |
| 52 | I step right up against the ooze and strike it with Razor Cut. | Erzähler | open_run_level | Close to ENGAGED and attack the ooze in one declared action | silt terrace chamber | 67/84 | 14.4 s |
| 53 | I gather the beetle leg and crystal disc from the wreckage as loot, then take the western water-carved passage onward. | Erzähler | open_run_level | Loot the chamber and continue clearing level 1 | pool chamber | 67/84 | 19.8 s |
| 54 | I examine the three-toed tracks around the pool to learn what made them and whether it is nearby. | Erzähler | open_run_level | Investigate the tracks before choosing an exit | pool chamber | 67/84 | 15.1 s |
| 55 | I take the tall northern passage, keeping alert for the three-toed creatures. | Erzähler | open_run_level | Continue clearing level 1 via the northern passage | the Glimmer Queen's vault chamber | 67/84 | 27.2 s |
| 56 | I throw Fan of Blades at the Glimmer Queen and the clustered beetles at its base. | Engine (Menü/Rückfrage) | open_run_level | Open the boss fight with AoE against the queen and her beetles | the Glimmer Queen's vault chamber | 67/84 | 5.9 s |
| 57 | I aim Fan of Blades at the clustered beetles at her base. | Engine (Menü/Rückfrage) | open_run_level | AoE the beetle cluster first, then deal with the queen | the Glimmer Queen's vault chamber | 67/84 | 5.6 s |
| 58 | I aim Fan of Blades at the Glimmer Queen. | Erzähler | open_run_level | Attack the boss with Fan of Blades | the Glimmer Queen's vault chamber | 67/84 | 18.3 s |
| 59 | I advance across the floor toward the Glimmer Queen, closing to SHORT range, keeping my dagger ready for the beetles that move to intercept … | Erzähler | open_run_level | Close distance to bring the queen into Fan of Blades range | the Glimmer Queen's vault chamber | 67/84 | 33.5 s |
| 60 | I advance again toward the Glimmer Queen, closing from MEDIUM to SHORT, and cut down the lead beetle barring my way with Razor Cut if it att… | Engine (Menü/Rückfrage) | open_run_level | Close to Fan of Blades range of the queen | the Glimmer Queen's vault chamber | 67/84 | 6.2 s |
| 61 | I advance again toward the Glimmer Queen, closing from MEDIUM to SHORT, and attack the lead beetle with my dagger if it bars my way. | Engine (Menü/Rückfrage) | open_run_level | Close to Fan of Blades range of the queen | the Glimmer Queen's vault chamber | 67/84 | 4.4 s |
| 62 | I advance again toward the Glimmer Queen, closing from MEDIUM to SHORT. | Erzähler | open_run_level | Close to SHORT range of the queen | the Glimmer Queen's vault chamber | 67/84 | 22.1 s |
| 63 | I strike the Glimmer Queen with Fan of Blades now that she is in range, stepping back from the tensed beetle if it lunges. | Erzähler | open_run_level | Attack the queen at SHORT range | the Glimmer Queen's vault chamber | 47/84 | 17.0 s |
| 64 | I hit the Glimmer Queen with Razor Cut. | Erzähler | open_run_level | Damage the queen at ENGAGED range | the Glimmer Queen's vault chamber | 27/84 | 15.8 s |
| 65 | I strike the Glimmer Queen again with Razor Cut. | Erzähler | open_run_level | Continue damaging the queen at ENGAGED range | the Glimmer Queen's vault chamber | 4/84 | 17.3 s |
| 66 | I scramble up and disengage, retreating from the Glimmer Queen and the soldier beetles toward the chamber exit. | Erzähler | open_run_level | Flee at 4 HP before the next sting kills me | the Glimmer Queen's vault chamber | 4/84 | 16.6 s |
| 67 | I keep running up the entrance passage and out of the grotto into the daylight, not stopping while the Queen's chime follows me. | Erzähler | open_run_level | Escape the grotto at 4 HP before the pursuing Queen strikes | Caelreth | 4/84 | 19.4 s |
| 68 | I keep moving downhill toward the millrace valley cottages, looking for lodging or help once I reach the settlement. | Erzähler | open_run_level | Reach the valley settlement at 4 HP to recover | Glassmere | 4/84 | 21.0 s |
| 69 | I let her tend the wound and tell her, "The grotto — a great crystal queen and her beetles. I barely got out alive. Could I buy a meal and a… | Erzähler | open_run_level | Get treatment and lodging at the cottage to recover from near-fatal HP | Glassmere | 4/84 | 29.7 s |
| 70 | I accept: "Five coppers it is." I pay her the 5 cp for the stew and the bed, eat, and sleep until morning. | Erzähler | open_run_level | Buy lodging and recover overnight at the cottage | Glassmere | 95/88 | 29.7 s |
| 71 | I go down for the promised breakfast and greet the third voice: "Morning. That grotto of yours has a crystal queen in the deep shelves — I b… | Erzähler | open_run_level | Eat breakfast and ask about Maren and the grotto situation | Glassmere | 95/88 | 28.2 s |
| 72 | "Gladly. She's the size of a plow horse, a great crystal queen with a body like cut glass, and her galleries crawl with soldier beetles — a … | Erzähler | open_run_level | Earn the free salve by describing the queen | Glassmere | 95/88 | 44.8 s |
| 73 | "A question, then: is there a Guild hall or contract board here in Glassmere, or the nearest village with one? And does anyone buy beetle ch… | Erzähler | open_run_level | Ask about Guild hall and local buyers before heading out | Glassmere | 95/88 | 16.8 s |
| 74 | I thank Halda and Tam, then head down the main road across the millrace into Glassmere, following it past the market square to the Guild hal… | Erzähler | open_run_level | Reach the Guild hall, sell loot, and find new contracts | Adventurers' Guild hall, Glassmere | 95/88 | 29.0 s |
| 75 | "I'll take the twenty coppers for the lot." I accept the sale, then nod at the board. "And I'll take the Clear Glimmerdeep Grotto Level 1 co… | Erzähler | open_run_level | Sell loot and add the grotto clearing contract | Adventurers' Guild hall, Glassmere | 95/88 | 30.8 s |
| 76 | I accept the eight coppers for the gel and core, then head out of Glassmere to Glimmerdeep Grotto to clear level 1. | Erzähler | open_run_level | Sell ooze parts and return to the grotto for the active beetle contract | Glimmerdeep Grotto | 95/88 | 30.1 s |
| 77 | I take the left fork toward the clicking, daggers ready, and scout the beetle gallery carefully before engaging. | Erzähler | open_run_level | Continue the beetle-clearing contract in the grotto | crystal rib chamber | 95/88 | 19.3 s |
| 78 | I slip between the crystal columns toward the far-side passage, staying out of the beetles' sight, and scout that eastern passage quietly be… | Erzähler |  | Scout alternate passage before engaging the beetle group | passage angling off the far side | 95/88 | 20.8 s |
| 79 | I move carefully past the wet stone lip and follow the passage as it bends left, scouting quietly. | Erzähler | open_run_level | Scout the far-side water passage | pool chamber | 95/88 | 24.5 s |
| 80 | I follow the ledge along the pool's near rim toward the drain, scouting quietly with daggers ready. | Erzähler | open_run_level | Scout the drain ledge where the drag-marks are freshest, likely leading toward the Glimmer… | ledge along the drain-gurgle beneath the far wall | 95/88 | 19.8 s |
| 81 | I back away from the drain shelf, return along the ledge, and cross the pool chamber to take the climbing passage where the draft comes from… | Erzähler | open_run_level | Take the climbing passage toward the way up, avoiding the Queen in the drain | ledge along the drain-gurgle beneath the far wall | 95/88 | 19.6 s |
| 82 | I climb the worn steps past the tight turn, scouting quietly with daggers ready. | Erzähler | open_run_level | Take the climbing passage toward the way up | moss gallery | 95/88 | 24.8 s |
| 83 | I take the level exit through the tall crack with the cold open-air wind, scouting quietly with daggers ready. | Erzähler | open_run_level | Take the wind crack toward open air | cave mouth on the hillside | 95/88 | 21.9 s |
| 84 | I head down the slope toward the smoking hut to ask the dweller about the Grotto and the beetles, and whether the Glimmerdeep has another en… | Erzähler | open_run_level | Investigate the hut for intel or a shortcut back into the Grotto | hunter's hut in the clearing | 95/88 | 25.8 s |
| 85 | I thank her for the directions and ask if she'd trade for any supplies or know a buyer in the valley, then mention I'm headed back to town t… | Erzähler | open_run_level | Wrap up the hut conversation and head toward turn-in and town | Vess's shed by the millrace | 95/88 | 28.8 s |
| 86 | "Maren sent me. I'd like to sell four crystal beetle chitin plates and a venom gland — what will you offer?" | Erzähler | open_run_level | Get a price from Vess for beetle loot | Vess's shed by the millrace | 95/88 | 15.0 s |
| 87 | I accept Vess's offer and sell her all four chitin plates and the venom gland for seventeen silver, then head across the bridge to the Guild… | Erzähler | open_run_level | Sell loot and turn in the beetle contract | Adventurers' Guild hall, Glassmere | 95/88 | 32.3 s |
| 88 | I ask the clerk to show me the contracts on the board, looking for work that pays better per hour. | Erzähler | open_run_level | Pick a new Guild contract | Adventurers' Guild hall, Glassmere | 95/88 | 18.9 s |
| 89 | I take the Millrace Serpent contract from the clerk and accept it, then head for the millrace sluice below the mill to hunt the grass serpen… | Erzähler | open_run_level | Accept the nearest achievable contract and hunt the serpent | the millrace sluice below Glassmere's mill | 95/88 | 21.2 s |
| 90 | I wade into the thigh-deep clouded water by the bank, dagger ready, to flush the grass serpent from its wallow. | Erzähler | open_run_level | Hunt the millrace serpent at its haul-out | clouded wallow by the bank | 95/88 | 18.6 s |
| 91 | I sidestep out of the serpent's strike line and slash my dagger at its head as it lunges. | Erzähler | open_run_level | Fight the grass serpent for the millrace contract | clouded wallow by the bank | 95/88 | 16.9 s |
| 92 | I head back up the track to the Guild hall and turn in the Millrace Serpent contract with the serpent skin and fangs as proof. | Erzähler | open_run_level | Turn in the completed serpent contract | Adventurers' Guild hall, Glassmere | 95/88 | 16.1 s |
| 93 | #assign AGI 3 PER 2 | System (Befehl) | open_run_level | Spend level-up stat points on AGI and PER | Adventurers' Guild hall, Glassmere | 95/88 | 2.6 s |
| 94 | I ask the clerk for a Primer of Strike and pay the 80 copper. | Erzähler | open_run_level | Learn the strike skill from the affordable Guild primer | Adventurers' Guild hall, Glassmere | 95/88 | 24.8 s |
| 95 | I sit down by the fire and read the Primer of Strike cover to cover, practicing the motions it shows. | Engine (Menü/Rückfrage) | open_run_level | Learn the strike skill from the purchased primer | Adventurers' Guild hall, Glassmere | 95/88 | 5.2 s |
| 96 | I read the Primer of Strike by the fire for two hours, practicing the motions it shows. | Erzähler | open_run_level | Learn the Strike skill from the purchased primer | Adventurers' Guild hall, Glassmere | 95/88 | 14.7 s |
| 97 | I book a room at the Guild for the night and sleep until morning. | Erzähler | open_run_level | Recover overnight before continuing the beetle grotto contract | Adventurers' Guild hall, Glassmere | 95/88 | 11.8 s |
| 98 | I take the small cell in the back for 2 copper and sleep until morning. | Erzähler | open_run_level | Book lodging and recover overnight | Adventurers' Guild hall, Glassmere | 100/88 | 14.4 s |
| 99 | I sell the clerk my two serpent skins and four serpent fangs as surplus, asking what she'll pay for them. | Erzähler | open_run_level | Sell surplus serpent loot at the Guild | Adventurers' Guild hall, Glassmere | 100/88 | 15.5 s |
| 100 | I accept her offer and sell her both serpent skins and all four fangs for 20 copper. | Erzähler | open_run_level | Sell surplus serpent loot at the agreed price | Adventurers' Guild hall, Glassmere | 100/88 | 11.9 s |
| 101 | I head back out to Glimmerdeep Grotto to finish clearing the beetles. | Erzähler | open_run_level | Continue the beetle grotto contract | Glimmerdeep Grotto | 100/88 | 17.5 s |
| 102 | I take the left passage toward the crystal glint, blades ready for whatever makes that glass-scraping sound. | Erzähler | open_run_level | Continue clearing beetles in the grotto | crystal rib chamber | 100/88 | 17.3 s |
| 103 | I attack the rattling beetle before it can call more of its kind, using Razor Cut. | Engine (Menü/Rückfrage) | open_run_level | Kill the beetle quickly to avoid a second one joining | crystal rib chamber | 100/88 | 4.8 s |
| 104 | I charge the crystal beetle and strike it with my daggers. | Engine (Menü/Rückfrage) | open_run_level | Engage the beetle to open combat and get a targetable scene | crystal rib chamber | 100/88 | 4.8 s |
| 105 | I charge the crystal beetle and strike it with my daggers, using Razor Cut. | Engine (Menü/Rückfrage) | open_run_level | Open combat on the beetle with Razor Cut | crystal rib chamber | 100/88 | 4.2 s |
| 106 | I move cautiously toward the far fork where the answering rattle came from, blades ready, to make whatever is there show itself. | Erzähler | open_run_level | Get a targetable actor by approaching the sound | crystal rib chamber | 100/88 | 17.2 s |
| 107 | I advance into the left branch of the fork toward the pale eyes, blades ready, and attack with Razor Cut the moment the creature shows itsel… | Erzähler | open_run_level | Engage the hidden creature in the left passage to make it a targetable actor | low pocket chamber | 100/88 | 26.2 s |
| 108 | I attack the crusted beetle with Razor Cut, aiming for the underside where its legs join the shell. | Engine (Menü/Rückfrage) | open_run_level | Open combat on the Glimmer Queen now that it is a present threat | low pocket chamber | 100/88 | 4.7 s |
| 109 | I attack the Glimmer Queen with Razor Cut before it can charge. | Engine (Menü/Rückfrage) | open_run_level | Open combat on the boss using its panel name as target | low pocket chamber | 100/88 | 4.2 s |
| 110 | I attack the beetle with Basic Attack. | Engine (Menü/Rückfrage) | open_run_level | Open combat using the plain skill name after named-target refusals | low pocket chamber | 100/88 | 4.5 s |
| 111 | Since the System shows no targetable actor, I back away from the rattling beetle through the narrow passage behind me and head toward the cr… | Erzähler | open_run_level | Disengage from the untargetable beetle and leave the pocket chamber | crystal rib chamber | 100/88 | 19.3 s |
| 112 | #quest Clear the Crystal Beetles of Glimmerdeep Grotto, Level 1 | System (Befehl) | open_run_level | Check exact quest requirements before re-attempting the untargetable Queen | crystal rib chamber | 100/88 | 2.7 s |
| 113 | I go back through the narrow crawl to the pocket chamber and attack the large crystal beetle with Razor Cut. | Erzähler | open_run_level | Re-engage the boss from its chamber side after the quest check | low pocket chamber | 100/88 | 20.8 s |
| 114 | I strike at the beetle blocking the chamber with Razor Cut. | Engine (Menü/Rückfrage) | open_run_level | Open combat on the boss using a minimal target phrasing after named-target refusals | low pocket chamber | 100/88 | 4.7 s |
| 115 | #audit | System (Befehl) | open_run_level | Diagnose why the boss is untargetable | low pocket chamber | 100/88 | 2.7 s |
| 116 | I leave the pocket chamber and travel back out of Glimmerdeep Grotto to the Guild hall, to turn in the beetle contract with the chitin plate… | Erzähler | open_run_level | Give up on the untargetable boss and turn in the beetle contract | Adventurers' Guild hall, Glassmere | 100/88 | 27.4 s |
| 117 | I tell the clerk to mark the beetle contract abandoned, then ask him which contracts on the board suit a Novice rogue. | Erzähler | open_run_level | Abandon the blocked contract and pick new work | Adventurers' Guild hall, Glassmere | 100/88 | 26.4 s |
| 118 | I accept the Sluice Serpent contract from the clerk. | Erzähler | open_run_level | Take the achievable Novice serpent contract | Adventurers' Guild hall, Glassmere | 100/88 | 13.8 s |
| 119 | I sell the four chitin plates and the venom gland at the materials window, then travel to the millrace sluice below the mill and look for th… | Erzähler | open_run_level | Sell loot, then hunt the serpent | the millrace sluice below Glassmere's mill | 100/88 | 28.2 s |
| 120 | I search the reed bed along the near bank for the grass serpent, watching the water for movement. | Erzähler | open_run_level | Hunt the serpent | the millrace sluice below Glassmere's mill | 100/88 | 22.5 s |
| 121 | I strike the sunning serpent with my dagger, staying clear of the boy's line. | Erzähler | open_run_level | Attack the serpent with a single-target attack | the millrace sluice below Glassmere's mill | 100/88 | 18.6 s |
| 122 | I wade quietly along the reed channel toward the serpent, closing to ENGAGED range before striking with my dagger. | Erzähler | open_run_level | Close to range and attack the serpent | the millrace sluice below Glassmere's mill | 100/88 | 19.3 s |
| 123 | I circle left along the mud flat's edge to close the last ten paces to the drowned root, and strike the serpent with my dagger once I reach … | Erzähler | open_run_level | Close to ENGAGED via declared movement, then attack | the millrace sluice below Glassmere's mill | 100/88 | 18.7 s |
| 124 | I travel back to the Guild hall in Glassmere and turn in the Cull the Sluice Serpent contract. | Erzähler | open_run_level | Turn in the completed serpent contract | Adventurers' Guild hall, Glassmere | 100/88 | 18.7 s |
| 125 | I look over the contract board for a new job suitable for a Novice rogue. | Erzähler | open_run_level | Pick next Guild contract | Adventurers' Guild hall, Glassmere | 100/88 | 12.9 s |
| 126 | I take the wolf cull contract from the board and tell the clerk: "The Charred Ridge Wolves job, please." | Erzähler | open_run_level | Accept the wolf contract | Adventurers' Guild hall, Glassmere | 100/88 | 17.7 s |
| 127 | "Yes, Guild business — the wolf cull. Where have the stripers been boldest lately?" | Erzähler | open_run_level | Ask the burners where wolves are active | Adventurers' Guild hall, Glassmere | 100/88 | 32.0 s |
| 128 | I thank the clerk and set out west along the road toward the Ashen Pines charcoal camps. | Erzähler | open_run_level | Travel to the wolf contract area before dark | the Ashen Pines charcoal camps | 100/88 | 22.6 s |
| 129 | I ask Dagg to point me to the ash-heap behind the third kiln, then move there quietly and set up watching for the wolves at dusk. | Erzähler | open_run_level | Ambush wolves at the ash-heap bait site | ash-heap behind the third kiln | 100/88 | 20.8 s |
| 130 | I take cover downwind near the spoil-bank and wait quietly for the wolves to come to the ash-heap. | Erzähler | open_run_level | Ambush the wolves at the bait site | ash-heap behind the third kiln | 100/88 | 22.1 s |
| 131 | I stay hidden and let the wolves finish feeding, watching for the moment both are distracted before I strike the closer one with Razor Cut. | Erzähler | open_run_level | Ambush the wolves from cover | ash-heap behind the third kiln | 100/88 | 21.3 s |
| 132 | I creep forward across the open ash toward the feeding wolves, closing to Engaged range while their heads stay down, then strike the nearer … | Erzähler | open_run_level | Close distance and ambush the wolves | ash-heap behind the third kiln | 100/88 | 24.7 s |
| 133 | I close the distance to the wolves, circling upwind of the smoke to mask my scent, and move to Engaged range with the nearer striped wolf. | Erzähler | open_run_level | Close to Engaged range so Razor Cut can be used | ash-heap behind the third kiln | 100/88 | 17.8 s |
| 134 | I close the last stretch from the slag ridge to the nearer striped wolf, staying downwind and low, then strike it with Razor Cut. | Erzähler | open_run_level | Close to Engaged and ambush Striped Wolf A | ash-heap behind the third kiln | 100/88 | 20.7 s |
| 135 | I creep the final twenty paces to Striped Wolf A, moving only while its head is down, until I reach Engaged range, then strike it with Razor… | Erzähler | open_run_level | Close to Engaged range and attack the wolf | ash-heap behind the third kiln | 100/88 | 19.5 s |
| 136 | I lunge the last four paces and strike Striped Wolf A with Razor Cut. | Erzähler | open_run_level | Attack Wolf A now at SHORT range | ash-heap behind the third kiln | 100/88 | 24.2 s |
| 137 | I strike Striped Wolf A with Razor Cut from SHORT range. | Erzähler | open_run_level | Attack the wolf now in range | ash-heap behind the third kiln | 100/88 | 15.8 s |
| 138 | I step the last two paces into Engaged range with Striped Wolf A and strike it with Razor Cut the moment I'm in reach. | Erzähler | open_run_level | Declare movement into ENGAGED, then attack | ash-heap behind the third kiln | 58/88 | 18.3 s |
| 139 | I finish Striped Wolf A with Razor Cut. | Erzähler | open_run_level | Kill the wounded wolf A | ash-heap behind the third kiln | 38/88 | 14.2 s |
| 140 | I strike Striped Wolf B with Razor Cut as it comes at me. | Erzähler | open_run_level | Kill the last wolf | ash-heap behind the third kiln | 17/88 | 13.9 s |
| 141 | I strike Striped Wolf B with Razor Cut. | Erzähler | open_run_level | Kill the last wolf | ash-heap behind the third kiln | 17/88 | 18.3 s |
| 142 | I accept the offered passive with #passives, then #assign VIT 3 WIL 2. | Erzähler | open_run_level | Accept Wolf-Bitten Resolve and spend the level-up stat points | ash-heap behind the third kiln | 17/88 | 15.0 s |
| 143 | #bag | System (Befehl) | open_run_level | Check supplies for a healing item before hunting the remaining two wolves | ash-heap behind the third kiln | 17/88 | 2.9 s |
| 144 | I use the clay salve pot from my bag on my wounds. | Erzähler | open_run_level | Heal before hunting the remaining two wolves | ash-heap behind the third kiln | 17/88 | 13.7 s |
| 145 | Two wolves down is enough for tonight — badly wounded, I withdraw from the ash-heaps and head back into Caelreth to find lodging and sleep u… | Erzähler | open_run_level | Recover overnight before hunting the last two wolves | the Drowsy Kettle | 17/88 | 24.4 s |
| 146 | I take the bed and the bath — six copper — then sleep until morning. | Erzähler | open_run_level | Buy lodging and bath from Halda, then sleep to recover | the Drowsy Kettle | 95/88 | 20.9 s |
| 147 | I ask Halda if anything dangerous is known to lurk in the reeds by the sluice water's edge. | Erzähler | open_run_level | Gather information on the sluice threat before heading back to the wolves | the Drowsy Kettle | 95/88 | 16.1 s |
| 148 | I buy the bread and eggs for three copper and eat before heading out. | Erzähler | open_run_level | Buy breakfast, then hunt the last two wolves | the sluice | 95/88 | 26.9 s |
| 149 | I head left along the top of the bank above the pool, moving quietly and watching the reeds and water for any sign of the wolves. | Erzähler | open_run_level | Continue hunting the remaining two wolves at the sluice | the sluice | 95/88 | 22.9 s |
| 150 | I assign my 5 free stat points: 3 into AGI, 2 into PER. | Erzähler | open_run_level | Spend free stat points before tracking the wolves | the sluice | 95/88 | 12.5 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 18 (notiert vor Zug 19): System rejected 'the nearer beetle' as not a valid target in the active scene despite narration showing two beetles.
- zu Zug 19 (notiert vor Zug 20): System says 'ACTIVE SCENE — no targetable actor' despite narration showing two beetles; trying a named target with Basic Attack instead.
- zu Zug 20 (notiert vor Zug 21): Combat commands fail with 'no targetable actor' even though narration showed beetles; likely no scene is active — moving to trigger one.
- zu Zug 22 (notiert vor Zug 23): Combat system repeatedly reports no active scene despite beetles in narration; checking available commands.
- zu Zug 24 (notiert vor Zug 25): #combat says scenes stay INACTIVE until a hostile commitment; prior attack commands were treated as target-checks, not commitments.
- zu Zug 25 (notiert vor Zug 26): Combat stays INACTIVE even after an explicit hostile commitment; 'Present: nobody besides Alaric' suggests the beetles may not exist in the scene anymore — relocating to search.
- zu Zug 26 (notiert vor Zug 27): Scene now ACTIVE with two named beetles; attacks should target Crystal Beetle A/B.
- zu Zug 28 (notiert vor Zug 29): Engine says no declared movement brings MEDIUM to ENGAGED; trying explicit range-declared advance.
- zu Zug 32 (notiert vor Zug 33): Engine refuses all movement from MEDIUM to ENGAGED in this scene; melee skills cannot close the gap.
- zu Zug 33 (notiert vor Zug 34): Engine refuses all movement from MEDIUM to ENGAGED and all attacks at MEDIUM; the beetles never close either — a possible soft-lock on the contract.
- zu Zug 34 (notiert vor Zug 35): All melee attacks and all MEDIUM-to-ENGAGED movement are refused in this chamber; beetles never close — possible soft-lock on the beetle contract.
- zu Zug 37 (notiert vor Zug 38): All attacks and combined move+attacks at MEDIUM refused; trying movement as its own declared action.
- zu Zug 38 (notiert vor Zug 39): Standalone move to ENGAGED worked; combined move+attack was refused. Beetle B at LONG clicked quicker — possible aggro.
- zu Zug 45 (notiert vor Zug 46): Level 1 shows 2 of ? threats dealt with; more threats remain despite both beetles dead.
- zu Zug 49 (notiert vor Zug 50): Engine requires movement declared as its own action before a ranged-limited skill can strike.
- zu Zug 57 (notiert vor Zug 58): Fan of Blades only targets the queen herself; the beetles are not a separate valid target.
- zu Zug 58 (notiert vor Zug 59): Fan of Blades is SHORT-range only; the queen sits at LONG with a beetle ring holding the floor.
- zu Zug 61 (notiert vor Zug 62): Only the Glimmer Queen is a valid target; the beetles are not separately targetable, so I'll just advance until she's in Fan of Blades range.
- zu Zug 62 (notiert vor Zug 63): Beetles are not valid targets; only the queen. She is now at SHORT range.
- zu Zug 65 (notiert vor Zug 66): Queen regenerates visibly; beetles are not individually targetable. Another Bite/Sting (20+ dmg) would be fatal at 4 HP.
- zu Zug 66 (notiert vor Zug 67): Engine says COMBAT END/escaped, but narration shows the Queen still pursuing to the entrance; trusting narration's threat and fleeing fully outside.
- zu Zug 67 (notiert vor Zug 68): Escaped the Glimmer Queen at the daylight boundary; quest not cleared — the Queen still lives at 66 HP.
- zu Zug 70 (notiert vor Zug 71): Fully recovered overnight (HP 95/95). Quest still not cleared — the Queen remains; 38 XP to Level 3.
- zu Zug 76 (notiert vor Zug 77): The ooze gel and core were never on the counter; sale offer of 8 cp still open — must sell explicitly at the Guild later.
- zu Zug 77 (notiert vor Zug 78): Contract still uncleared; queen remains alive, so more beetles likely needed for the count.
- zu Zug 87 (notiert vor Zug 88): Beetle contract turn-in refused: Grotto level 1 not cleared; sale of loot succeeded for 17 silver.
- zu Zug 88 (notiert vor Zug 89): Beetle contract requires clearing Grotto level 1; chitin plates and venom gland were still carried per HUD despite the sale — possible inventory contradiction to check with #bag.
- zu Zug 89 (notiert vor Zug 90): HUD still lists the four chitin plates and venom gland as carried despite Vess's confirmed 17-silver sale — inventory contradiction persists.
- zu Zug 94 (notiert vor Zug 95): HUD confirms purchase but skill list still lacks Strike; primer must be read/used. Serpent skin/fangs remain carried after turn-in — inventory contradiction persists.
- zu Zug 96 (notiert vor Zug 97): Strike learned at 20/100 LP after two hours' study; serpent skins/fangs still carried after turn-in, can sell as surplus.
- zu Zug 103 (notiert vor Zug 104): System says the beetle is present but no targetable actor yet; combat scene may need a move to open.
- zu Zug 104 (notiert vor Zug 105): System needed skill named explicitly in the same message; earlier plain-dagger charge wasn't rolled.
- zu Zug 105 (notiert vor Zug 106): Beetles are all dead per dungeon panel; remaining sound may be the Glimmer Queen or new spawn. System repeatedly refuses attacks with 'no targetable actor' — need to trigger scene first.
- zu Zug 106 (notiert vor Zug 107): Dungeon panel says 2/2 beetles and the ooze dead; remaining threat is the Glimmer Queen (met, alive). Eyes in the left branch may be it.
- zu Zug 108 (notiert vor Zug 109): Narrator calls it 'crusted beetle' but System rejects that name; dungeon panel names the boss 'The Glimmer Queen' — trying that as the target identifier.
- zu Zug 109 (notiert vor Zug 110): System rejects both 'crusted beetle' and 'Glimmer Queen' as targets though the scene shows the threat present — combat may need the generic skill name to initialize.
- zu Zug 110 (notiert vor Zug 111): System says 'no targetable actor' and 'Present: nobody besides Alaric' while narration shows a beetle braced to attack — narration and System disagree; treating the System as authoritative and withdrawing.
- zu Zug 111 (notiert vor Zug 112): Narration shows a small beetle in the chamber while the System insists 'Present: nobody besides Alaric' — same contradiction as the boss.
- zu Zug 113 (notiert vor Zug 114): Same narration/System contradiction: narrator shows the Queen braced to attack, HUD says 'Present: nobody besides Alaric' and boss 'met, alive'; three target namings have failed to trigger combat.
- zu Zug 114 (notiert vor Zug 115): Four target phrasings refused while narration shows the Queen present; HUD says 'Present: nobody besides Alaric' and 'met, alive' — checking audit for how the encounter is recorded.
- zu Zug 115 (notiert vor Zug 116): Audit shows the engine rejects the Glimmer Queen as an encounter — the boss likely cannot be fought; the contract may accept the four chitin plates already carried.
- zu Zug 117 (notiert vor Zug 118): Beetle contract officially abandoned; board confirms the serpent contract is the only level-1-appropriate solo job.
- zu Zug 119 (notiert vor Zug 120): Materials window doesn't exist in Glassmere; broker visits twice a week or sell at Tanner's Row. Chitin plates and gland still carried.
- zu Zug 127 (notiert vor Zug 128): Narrator rewrote my earlier travel to the camps as not having happened yet; contract is confirmed active at 0/4.
- zu Zug 130 (notiert vor Zug 131): Two striped wolves present (HP 55/61); more shapes hinted in the timber; contract still 0/4.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t11r | 11 | 1 | – | ja | 1 | gewonnen, 24 XP |
| enc.t31 | 39 | 2 | – | nein | 2 | gewonnen, 168 XP |
| enc.t43 | 52 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t50 | 63 | 1 | – | nein | 0 | geflohen |
| enc.t78 | 91 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t99 | 123 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t114 | 138 | 2 | – | nein | 2 | gewonnen, 380 XP |

## Quests

- **Clear the Crystal Beetles of Glimmerdeep Grotto, Level 1** — active (Zug 15) → abandoned (Zug 117), Dungeon loc.glimmerdeep_grotto Ebene 1
  - Aufgabe: Clear level 1 of Glimmerdeep Grotto. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Glimmerdeep Grotto is clear.
- **One Biter at the Millrace** — active (Zug 8) → completed (Zug 13)
  - Aufgabe: Kill 1 the grass serpent under the sluice at the millrace sluice below Glassmere's mill. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the grass serpent under the sluice killed at the millrace sluice below Glassmere's mill.
- **Thin the Striped Wolves of the Ashen Pines** — expired (Zug 74)
  - Aufgabe: Kill 4 striped wolves haunting the kiln clearings at the Ashen Pines charcoal camps. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 striped wolves haunting the kiln clearings killed at the Ashen Pines charcoal camps.
- **Break the Mire Lurker of Sallow Fen** — expired (Zug 74)
  - Aufgabe: Kill 1 the mire lurker in the boat channels at the boat channels of Sallow Fen. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the mire lurker in the boat channels killed at the boat channels of Sallow Fen.
- **Slay the Horned Marsh-King of the Drowned Orchard** — expired (Zug 74)
  - Aufgabe: Kill 1 the horned marsh-king at the Drowned Orchard by the Wetford causeway. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the horned marsh-king killed at the Drowned Orchard by the Wetford causeway.
- **Cull the Millrace Serpent** — active (Zug 89) → completed (Zug 92)
  - Aufgabe: Kill 1 grass serpent at the millrace sluice below Glassmere's mill. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 grass serpent killed at the millrace sluice below Glassmere's mill.
- **Thin the Ashen Pines Wolves** — expired (Zug 117)
  - Aufgabe: Kill 4 striped wolf at the Ashen Pines charcoal camps. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 striped wolf killed at the Ashen Pines charcoal camps.
- **Cull the Mire Lurkers of Sallow Fen** — expired (Zug 117)
  - Aufgabe: Kill 3 mire lurker at the boat channels of Sallow Fen. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 mire lurker killed at the boat channels of Sallow Fen.
- **Slay the Horned Marsh-King** — expired (Zug 117)
  - Aufgabe: Kill 1 horned marsh-king at the Drowned Orchard by the Wetford causeway. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 horned marsh-king killed at the Drowned Orchard by the Wetford causeway.
- **Clear Glimmerdeep Grotto Level 1** — expired (Zug 117), Dungeon loc.glimmerdeep_grotto Ebene 1
  - Aufgabe: Clear level 1 of Glimmerdeep Grotto. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Glimmerdeep Grotto is clear.
- **Cull the Sluice Serpent** — active (Zug 118) → completed (Zug 124), READY
  - Aufgabe: Kill 1 grass serpent at the millrace sluice below Glassmere's mill. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 grass serpent killed at the millrace sluice below Glassmere's mill.
- **Thin the Charred Ridge Wolves** — active (Zug 126)
  - Aufgabe: Kill 4 striped wolf at the Ashen Pines charcoal camps. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 striped wolf killed at the Ashen Pines charcoal camps.

## Auffälligkeiten

- Zug 3, Nachricht 5 (board_failed): the board generator failed
- Zug 13, Nachricht 26 (extraction_repaired): the extractor's first answer needed a repair
- Zug 16, Nachricht 32 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (crystal beetle): refused, no fight (Patch 8.4.1 guard)
- Zug 17, Nachricht 34 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (crystal beetle): refused, no fight (Patch 8.4.1 guard)
- Zug 17, Nachricht 34 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (crystal beetle): refused, no fight (Patch 8.4.1 guard)
- Zug 21, Nachricht 42 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (crystal beetle): refused, no fight (Patch 8.4.1 guard)
- Zug 21, Nachricht 42 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (crystal beetle): refused, no fight (Patch 8.4.1 guard)
- Zug 26, Nachricht 52 (extraction_repaired): the extractor's first answer needed a repair
- Zug 34, Nachricht 68 (extraction_repaired): the extractor's first answer needed a repair
- Zug 55, Nachricht 110 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (crystal beetle): refused, no fight (Patch 8.4.1 guard)
- Zug 58, Nachricht 116 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (crystal beetle): refused, no fight (Patch 8.4.1 guard)
- Zug 59, Nachricht 118 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (crystal beetle): refused, no fight (Patch 8.4.1 guard)
- Zug 62, Nachricht 124 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (crystal beetle): refused, no fight (Patch 8.4.1 guard)
- Zug 62, Nachricht 124 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (crystal beetle worker): refused, no fight (Patch 8.4.1 guard)
- Zug 65, Nachricht 130 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (crystal beetle soldier): refused, no fight (Patch 8.4.1 guard)
- Zug 69, Nachricht 138 (extraction_repaired): the extractor's first answer needed a repair
- Zug 70, Nachricht 139 (planner_repaired): the planner's first answer needed a repair
- Zug 70, Nachricht 140 (extraction_repaired): the extractor's first answer needed a repair
- Zug 72, Nachricht 144 (extraction_repaired): the extractor's first answer needed a repair
- Zug 77, Nachricht 154 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (crystal beetle): refused, no fight (Patch 8.4.1 guard)
- Zug 77, Nachricht 154 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (crystal beetle): refused, no fight (Patch 8.4.1 guard)
- Zug 81, Nachricht 161 (planner_repaired): the planner's first answer needed a repair
- Zug 87, Nachricht 173 (planner_repaired): the planner's first answer needed a repair
- Zug 87, Nachricht 174 (extraction_repaired): the extractor's first answer needed a repair
- Zug 89, Nachricht 177 (planner_repaired): the planner's first answer needed a repair
- Zug 94, Nachricht 188 (extraction_repaired): the extractor's first answer needed a repair
- Zug 102, Nachricht 204 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (crystal beetle): refused, no fight (Patch 8.4.1 guard)
- Zug 107, Nachricht 214 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (crystal beetle): refused, no fight (Patch 8.4.1 guard)
- Zug 111, Nachricht 222 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (crystal beetle): refused, no fight (Patch 8.4.1 guard)
- Zug 113, Nachricht 226 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (crystal beetle): refused, no fight (Patch 8.4.1 guard)
- Zug 119, Nachricht 238 (extraction_repaired): the extractor's first answer needed a repair
- Zug 120, Nachricht 240 (extraction_repaired): the extractor's first answer needed a repair
- Zug 129, Nachricht 257 (planner_repaired): the planner's first answer needed a repair
- Zug 145, Nachricht 290 (extraction_repaired): the extractor's first answer needed a repair
- Zug 148, Nachricht 295 (planner_repaired): the planner's first answer needed a repair
- Zug 150, Nachricht 299 (stat_words): the player spent Stat Points in words, not with #assign; nothing was assigned (for review: did the story tell them as done?)
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 24× keine gültige JSON-Entscheidung (Züge 5, 7, 8, 10, 15, 39, 44, 48, 69, 76, 81, 87, 88, 93, 103, 113, 116, 117, 122, 127, 130, 132, 137, 144)

System-Panels: CLARIFY 3, NOT TAKEN 3, REFUSED 2, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: guild_canon 4, engine_owned_fact 7, dungeon_foe 17, world_rule 18, group_unclear 3, group_fact 2, attack_commitment 2, entity_fact 3, no_go 5, scene_context 22, offer 4, guild_payout 1, pc_inventory 4, sale_evidence 6, ambient 5.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 24/150 Erstantworten ungültig (16.0 %); 24 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 147 | 6 | 2.3 s | 4.4 s | 12225 | 9988 | 86 | – | stop 147 | 0 |
| board | 6 | 2 | 8.5 s | 12.3 s | 2526 | 2336 | 958 | – | stop 6 | 0 |
| narrator | 123 | 0 | 7.9 s | 10.9 s | 11288 | 8658 | 396 | – | stop 123 | 0 |
| extract | 134 | 11 | 4.8 s | 8.0 s | 12363 | 9462 | 358 | – | stop 134 | 0 |
| forge | 1 | 0 | 1.4 s | 1.4 s | 363 | 0 | 57 | – | stop 1 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 52:25 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 16.3 s) | 0:30 min |
| 150 Züge, Spiel (Senden bis HUD nach der Extraktion) | 42:55 min — Median 17.3 s, p90 28.2 s, max 44.8 s |
| 150 Züge, Spieler-Entscheidung | 6:14 min — Median 2.1 s, 24 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 6:36 min / 0:54 min / 17:05 min / 12:12 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 19.7 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 13:06 min, 80 Züge ≈ 26:13 min (ohne Einrichtung) |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
