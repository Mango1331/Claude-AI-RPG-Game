# Avereth – 3 natürliche Testkampagnen

Status: **completed**. Serie abgeschlossen bedeutet, dass die Läufe beendet sind; es bedeutet nicht 3 bestandene Level-15-Abnahmen.

| Nr. | Profil | Seed | Eingaben | Level | Ende | Originalbericht |
|---|---|---:|---:|---:|---|---|
| 1 | guild-warrior | 1908782372 | 31 | 1 | defeat | [report.md](001-guild-warrior/20261029-055532Z-current_test/report.md) |
| 2 | guild-mage | 1908782373 | 150 | 8 | limit | [report.md](002-guild-mage/20261029-060825Z-current_test/report.md) |
| 3 | guild-rogue | 1908782374 | 150 | 4 | limit | [report.md](003-guild-rogue/20261029-070210Z-current_test/report.md) |

