# Avereth Live-Test 20261029-091448Z-current_test

## Kurzfassung

- **Laufprofil:** guild-warrior; Startklasse Warrior, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** abgebrochen: Limit erreicht — 150 turns
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 1. Sicherheitsgrenzen: 150 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** Level 1, 30 XP seit Levelaufstieg, 0 cp, HP 95, MP 84; Ort loc.stonebrook.stonebrook_guild_hall. Ausrüstung und Skills stehen in evaluation.json → progression.checkpoint.
- **Charakter:** warrior (warrior.guard, warrior.cleave) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: cautious adventurer: prepare and recover, weigh threats and withdraw when sensible
- **Züge:** 150 · **Dauer:** 72:30 min · **LLM-Aufrufe der Engine/des Erzählers:** 439
- **Beobachtete Abdeckung:** 20 unterschiedliche gebuchte Reiseziele · 1 Kämpfe · 0 Verkäufe (0 cp Umsatz, ohne Questzahlungen/Geschenke) · 0 Ausrüstungswechsel · 0 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 32
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.116 |
| Git | 846a7c3ce0be (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 67.4 s |
| Browser | chrome 156.0.8078.49 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261029-091448Z-current_test“, Seed 2120501929 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | Warrior | Engine (Menü/Rückfrage) | creation_complete | Choose the Warrior base class | public roadside verge outside Glassmere | 90/84 | 2.3 s |
| 2 | Cleave and Guard | Engine (Menü/Rückfrage) | creation_complete | Pick required Cleave plus Guard as starter skills | public roadside verge outside Glassmere | 95/84 | 2.1 s |
| 3 | I walk through the city gates into Glassmere and head for the Adventurers' Guild hall to look at the contract board. | Erzähler | open_run_level | Enter city and reach the Guild | Adventurers' Guild hall, Glassmere | 95/84 | 42.8 s |
| 4 | I approach the clerk and ask to register with the Guild as a novice adventurer. | Erzähler | open_run_level | Register at the Guild before taking a contract | Adventurers' Guild hall, Glassmere | 95/84 | 17.2 s |
| 5 | I pay the two silver fee and touch the measuring stone to complete my registration. | Erzähler | open_run_level | Register with the Guild | Adventurers' Guild hall, Glassmere | 95/84 | 21.6 s |
| 6 | I ask the clerk to accept the Slay the Lamb-Rending Wolf of Stonebrook contract for me. | Erzähler | open_run_level | Take the wolf contract | Adventurers' Guild hall, Glassmere | 95/84 | 25.8 s |
| 7 | I head out the east road toward Stonebrook. | Erzähler | open_run_level | Travel to Stonebrook for the wolf contract | the pastures and pens around Stonebrook | 95/84 | 20.7 s |
| 8 | I ask the villager where the near pens are and whether there's a good hiding spot to wait for the wolf at dusk. | Erzähler | open_run_level | Learn ambush details for the dusk hunt | the pastures and pens around Stonebrook | 95/84 | 21.2 s |
| 9 | I thank the villager, then settle into the old lambing byre to wait quietly for dusk. | Erzähler | open_run_level | Ambush the wolf from the byre at dusk | the pastures and pens around Stonebrook | 95/84 | 25.0 s |
| 10 | I stay hidden and quiet in the byre, watching through the window gap to see where the wolf moves. | Erzähler | open_run_level | Ambush the wolf from concealment | the pastures and pens around Stonebrook | 95/84 | 15.5 s |
| 11 | I burst from the byre and charge the wolf, swinging Cleave at it before it can reach the ewe. | Erzähler | open_run_level | Ambush the wolf with Cleave | the pastures and pens around Stonebrook | 95/84 | 18.8 s |
| 12 | I rush the wolf while it's pinned on the ewe and swing Cleave at it at close range. | Erzähler | open_run_level | Engage the wolf and strike with Cleave | the pastures and pens around Stonebrook | 95/84 | 20.2 s |
| 13 | I draw my sword, close the distance to the wolf, and strike it with Basic Attack once in reach. | Erzähler | open_run_level | Engage the wolf and attack with Basic Attack | the pastures and pens around Stonebrook | 95/84 | 20.8 s |
| 14 | I show the villager the dead wolf, then head back to Stonebrook's Guild hall to turn in the wolf contract. | Erzähler | open_run_level | Turn in the completed wolf contract at the Guild hall | the pastures and pens around Stonebrook | 95/84 | 38.4 s |
| 15 | I approach the clerk's desk and slide the contract slip onto it. "The lamb-rending wolf is dead — I've brought proof. I'd like to turn in th… | Erzähler | open_run_level | Turn in the wolf contract at the Guild hall | the pastures and pens around Stonebrook | 95/84 | 23.4 s |
| 16 | "Thanks — Millbrook it is. Anything on the board here worth a novice's time before I go, or is everything settled at the branch?" | Erzähler | open_run_level | Ask about contracts before travelling to Millbrook | the pastures and pens around Stonebrook | 95/84 | 18.5 s |
| 17 | "Understood — I'll leave at first light." I ask the clerk if the hall has a room or if there's an inn nearby where I can sleep until morning… | Erzähler | open_run_level | Find lodging for the night | the pastures and pens around Stonebrook | 95/84 | 14.3 s |
| 18 | I head to the Gilded Ewe and ask Marla for a room for the night, plus some stew if the fire's still going. | Erzähler | open_run_level | Get lodging and a meal before sleeping until morning | The Gilded Ewe | 95/84 | 22.2 s |
| 19 | "Evening — Tam sent me from the hall. I'll take stew if it's still hot, and a room for the night." | Erzähler | open_run_level | Buy lodging and a meal at the Gilded Ewe, then sleep until morning | The Gilded Ewe | 95/84 | 15.4 s |
| 20 | "I'll take the proper room and the stew — six coppers all told." I pay, then go up to the second door on the left and sleep until morning. | Erzähler | open_run_level | Buy room and stew, then sleep until morning | The Gilded Ewe | 95/84 | 16.2 s |
| 21 | I eat the stew with bread, then set out on the river road south toward Millbrook. | Erzähler | open_run_level | Travel to Millbrook to turn in the wolf contract | Millbrook | 95/84 | 22.3 s |
| 22 | I enter the Millbrook Guild branch hall and ask the clerk to turn in my contract, 'Slay the Lamb-Rending Wolf of Stonebrook' — I have the pe… | Erzähler | open_run_level | Turn in the wolf contract at the chartered branch | Millbrook Guild branch hall | 95/84 | 24.0 s |
| 23 | I leave the slip, pelt and fang with the clerk and ask for the note of deposit to settle in Stonebrook. | Erzähler | open_run_level | Deposit proof at branch post for later turn-in | Millbrook Guild branch hall | 95/84 | 31.6 s |
| 24 | "Nothing else tonight, thank you." I head to the Millstone past the bridge and ask Marla for supper and a room for the night. | Erzähler | open_run_level | Lodging and meal at the Millstone before returning north | The Millstone | 95/84 | 25.2 s |
| 25 | "Evening, Marla. I'll take supper and a room for the night — what do I owe you?" | Erzähler | open_run_level | Buy supper and lodging at the Millstone | The Millstone | 95/84 | 15.7 s |
| 26 | "The room as well — five coppers the lot." I pay Marla the five coppers, eat the supper, then go up and sleep until morning. | Erzähler | open_run_level | Buy supper and room at the agreed price, then sleep | The Millstone | 95/84 | 24.3 s |
| 27 | "My mistake, Hesta. I'll take the stew, bread and ale, and the room — five coppers the lot." I pay her the five coppers, eat, then go up and… | Erzähler | open_run_level | Buy meal and lodging from Hesta at her stated price, then sleep | The Millstone | 95/84 | 13.9 s |
| 28 | I head back to the Millbrook Guild branch and ask the clerk whether any Guild hall in Stonebrook is reachable today, or whether there is ano… | Erzähler | open_run_level | Find a place that can pay out the wolf contract turn-in | Millbrook Guild branch hall | 95/84 | 20.0 s |
| 29 | "Yes — here's the note of deposit. I'll close the wolf contract here with you, please." I hand over the slip and ask for the payout. | Erzähler | open_run_level | Turn in wolf contract at Millbrook branch | Millbrook Guild branch hall | 95/84 | 20.8 s |
| 30 | #bag | System (Befehl) | open_run_level | Check carried papers for the contract slip | Millbrook Guild branch hall | 95/84 | 2.2 s |
| 31 | #quests | System (Befehl) | open_run_level | Check quest panel for the contract slip status | Millbrook Guild branch hall | 95/84 | 2.1 s |
| 32 | "I don't have the slip — only the note of deposit. The wolf is recorded 1/1 defeated. Can you check the branch rolls or reissue a completion… | Erzähler | open_run_level | Resolve missing contract slip with the clerk | Millbrook Guild branch hall | 95/84 | 24.6 s |
| 33 | "Thank you — that closes it nicely. What contracts are on the board at the moment? I'm after something achievable nearby." | Erzähler | open_run_level | Confirm payout and pick the next Guild contract | Millbrook Guild branch hall | 95/84 | 23.7 s |
| 34 | I set out east along the road to Stonebrook and, on arriving at the Guild hall, ask the desk clerk to close out my wolf contract — the kill … | Erzähler | open_run_level | Travel to Stonebrook Guild hall, verify contract closure, and read the board | stream crossing on the east road | 95/84 | 30.1 s |
| 35 | I walk the last stretch of road into Stonebrook and head for the Guild hall — the big door with the horns carved over it, past the well — th… | Erzähler | open_run_level | Reach Stonebrook Guild hall, turn in wolf contract, read the board | Stonebrook Guild hall | 95/84 | 22.9 s |
| 36 | I go to the inn and ask for a room for the night. | Erzähler | open_run_level | Get lodging before the hall opens at first light | The Gilded Ewe | 95/84 | 26.0 s |
| 37 | "Evening. I'd like a room for the night, and a bowl of that stew if it's still hot — what do I owe you?" | Erzähler | open_run_level | Get lodging and a meal at the Gilded Ewe before the Guild hall opens at first light | The Gilded Ewe | 95/84 | 16.8 s |
| 38 | I accept Marla's prices and pay her 4 copper for the room, the stew, and an ale, then eat before going up to sleep until morning. | Erzähler | open_run_level | Buy lodging and a meal at agreed prices, then sleep | The Gilded Ewe | 95/84 | 26.6 s |
| 39 | "Marla, the four coppers are yours — book the back room for me now, please. What's left to settle?" | Erzähler | open_run_level | Get the room properly booked with Marla so I can sleep | The Gilded Ewe | 95/84 | 25.1 s |
| 40 | I take the key, climb the narrow stair to the back room, and sleep until morning. | Erzähler | open_run_level | Sleep until morning to recover | back room of the Gilded Ewe | 95/84 | 18.4 s |
| 41 | I lie down on the bed in the back room and sleep until morning. | Erzähler | open_run_level | Sleep until morning to recover | back room of the Gilded Ewe | 95/84 | 15.8 s |
| 42 | I leave the key on the table as Marla asked and head to the Guild hall to turn in the wolf contract — it shows 1/1 defeated. | Erzähler | open_run_level | Turn in the completed Stonebrook wolf contract at the Guild hall | Stonebrook Guild hall | 95/84 | 24.9 s |
| 43 | "Morning. I'm turning in the wolf contract — the Lamb-Rending Wolf of Stonebrook is slain, the slip shows READY. Here it is." | Erzähler | open_run_level | Turn in the completed wolf contract to Clerk C | Stonebrook Guild hall | 95/84 | 19.7 s |
| 44 | "Alaric Red — that's the name in your book. Here's the slip." I lay the contract slip on the counter. | Erzähler | open_run_level | Turn in wolf contract with name and slip | Stonebrook Guild hall | 95/84 | 27.0 s |
| 45 | "Hesk never started the job as far as I know — I took the slip myself and killed the wolf. Either he handed the work over and it never got w… | Erzähler | open_run_level | Explain how the slip came to me and offer to correct the ledger | Stonebrook Guild hall | 95/84 | 26.9 s |
| 46 | I take the slip and head to the Gilded Ewe to look for Hesk and ask him to confirm the contract passed to me. | Erzähler | open_run_level | Find Hesk at the Gilded Ewe to release the wolf contract payout | The Gilded Ewe | 95/84 | 35.1 s |
| 47 | "Deal, Hesk. Marla — put his breakfast and ale on my coin, whatever it costs." I pay for Hesk's breakfast and ale, then ask him to come to t… | Erzähler | open_run_level | Pay Hesk's price and get his confirmation at the Guild hall | Stonebrook Guild hall | 95/84 | 27.7 s |
| 48 | I lay the slip on the counter. "There it is, seal up. Hesk's said his piece — write it and pay out." | Erzähler | open_run_level | Complete the wolf contract turn-in with Hesk's confirmation | Stonebrook Guild hall | 95/84 | 21.7 s |
| 49 | I travel east with Hesk to Milldale and turn in the wolf contract slip at the Milldale Guild branch for the forty copper payout. | Erzähler | open_run_level | Travel to Milldale and turn in the wolf contract for payout | flooded hollow on the road east | 95/84 | 28.7 s |
| 50 | I keep my hand near my sword hilt and say, "The road's dry behind us, Wat — we both know there's no flood. Step aside and let us pass." | Erzähler | open_run_level | Refuse the false toll and warn the bandits off | flooded hollow on the road east | 95/84 | 44.0 s |
| 51 | "I'm the named taker — the wolf's mine. Hesk handed the slip over before I took the road, and Stonebrook's clerk wrote the pass-mark plain. … | Erzähler | open_run_level | Claim the wolf payout as the named taker | flooded hollow on the road east | 95/84 | 21.7 s |
| 52 | I walk on east until I reach the Milldale Guild branch; once inside at the counter, I lay the slip seal-up before the clerk and ask her to p… | Erzähler | open_run_level | Reach Milldale branch, then turn in the wolf slip | flooded hollow on the road east | 95/84 | 25.0 s |
| 53 | I pocket the slip and ask the clerk where a traveler can find a bed and a meal in Milldale tonight, then head there. | Erzähler | open_run_level | Keep the slip for a later proper-hall turn-in; find lodging for the night | the Mill House | 95/84 | 33.1 s |
| 54 | I pay Marda three coppers for a bed and supper, then eat, sleep until morning. | Erzähler | open_run_level | Lodging and overnight recovery at the Mill House | the Mill House | 95/84 | 27.2 s |
| 55 | I buy the half sausage for a copper, then go up to the room and sleep until morning. | Engine (Menü/Rückfrage) | open_run_level | Buy sausage and sleep until morning | the Mill House | 95/84 | 7.9 s |
| 56 | offer.t108.5 | Erzähler | open_run_level | Accept the sausage offer, then sleep | the Mill House | 95/84 | 15.8 s |
| 57 | I take the three-copper bed with supper, pay Marda, eat the bread, then go up and sleep until morning. | Erzähler | open_run_level | Book lodging properly, then recover overnight | the Mill House | 95/84 | 25.6 s |
| 58 | I eat the breakfast Marda serves, then set out on the road back toward Stonebrook, aiming for the full Guild hall there to turn in the wolf … | Erzähler | open_run_level | Travel to Stonebrook Guild hall for the wolf payout | Stonebrook | 95/84 | 17.3 s |
| 59 | I approach the Guild desk and turn in the wolf contract slip, asking for my payout. | Erzähler | open_run_level | Turn in wolf contract at Stonebrook Guild hall | Stonebrook Guild hall | 95/84 | 24.4 s |
| 60 | I set out down the river road toward Millhaven, hoping to reach the ferry crossing before dark. | Erzähler | open_run_level | Travel toward the Millhaven Guild branch to turn in the wolf contract | the ferry crossing | 95/84 | 22.6 s |
| 61 | I take the two-copper bunk at the Crossing House and pay, then sleep until morning to cross with the first light. | Erzähler | open_run_level | Lodge overnight, cross at dawn | the ferry crossing | 95/84 | 31.0 s |
| 62 | I disembark and follow the river road toward Millhaven, aiming for the Guild branch there. | Erzähler | open_run_level | Travel to Millhaven Guild branch | Millhaven | 95/84 | 20.0 s |
| 63 | I approach the Guild counter and present the wolf contract slip, asking for my payout. | Erzähler | open_run_level | Turn in the wolf contract at the Millhaven Guild branch | Millhaven | 95/84 | 24.7 s |
| 64 | I ask the clerk what contracts the Millhaven board has open for a Novice-ranked adventurer. | Erzähler | open_run_level | Find new local Guild work instead of walking back to Stonebrook for the wolf payout | Millhaven | 95/84 | 15.1 s |
| 65 | I take back the slip, thank the clerk, and set out north on the river road toward the ferry crossing, planning to lodge there overnight and … | Erzähler | open_run_level | Return to Stonebrook to turn in the wolf contract | the ferry crossing | 95/84 | 17.8 s |
| 66 | I take the two-copper room, pay the innkeeper, and sleep until morning. | Erzähler | open_run_level | Lodge overnight before crossing to Stonebrook | the ferry crossing | 95/84 | 22.5 s |
| 67 | I ask the innkeeper directly to book the two-copper room for tonight, and if he confirms the booking, I pay him the two copper for it. | Erzähler | open_run_level | Book the room properly before sleeping | the ferry crossing | 95/84 | 20.8 s |
| 68 | #help | System (Befehl) | open_run_level | Find the correct mechanic for booking lodging | the ferry crossing | 95/84 | 2.5 s |
| 69 | #system How do I book a room for the night at an inn? What counts as a valid canonical offer? | Erzähler | open_run_level | Learn correct lodging mechanic | the ferry crossing | 95/84 | 7.4 s |
| 70 | I ask the ferrywoman whether she keeps the rooms here at the crossing, and if she does, I ask her for the two-copper room for tonight at her… | Erzähler | open_run_level | Establish the correct present seller and book lodging | the ferry crossing | 95/84 | 16.0 s |
| 71 | I accept the ferrywoman's offer and pay her two copper for the room for the night. | Engine (Menü/Rückfrage) | open_run_level | Book lodging at the confirmed offer | the ferry crossing | 95/84 | 6.1 s |
| 72 | I buy the room for the night above the common room from the ferrywoman for 2 copper total, paying her now. | Erzähler | open_run_level | Complete the lodging purchase with explicit terms | the ferry crossing | 95/84 | 16.1 s |
| 73 | I tell Tam the room's paid and go up to sleep until morning. | Erzähler | open_run_level | Sleep to recover before turning in the wolf contract | the ferry crossing | 95/84 | 34.7 s |
| 74 | I take the ferry across and head down the river road toward the Millhaven Guild branch to turn in the wolf contract. | Erzähler | open_run_level | Travel to Millhaven to turn in the wolf contract | the ferry crossing | 95/84 | 29.3 s |
| 75 | I walk back up the valley road to Stonebrook and, on arrival, turn in the wolf contract at the Stonebrook Guild hall to collect the 40 coppe… | Erzähler | open_run_level | Turn in the READY wolf contract at the actual Guild branch in Stonebrook | Stonebrook | 95/84 | 22.3 s |
| 76 | I step inside the Stonebrook Guild hall and hand the contract slip to the clerk, turning in the wolf contract for the 40 copper payout. | Erzähler | open_run_level | Turn in the wolf contract inside the Guild hall | Stonebrook Guild hall | 95/84 | 25.5 s |
| 77 | Is something wrong with the slip? What do you need from me to pay out the 40 copper? | Erzähler | open_run_level | Resolve the clerk's hesitation and complete the turn-in | Stonebrook Guild hall | 95/84 | 19.3 s |
| 78 | I count the forty copper, pocket it, and ask the clerk what's on the board for a Novice. | Erzähler | open_run_level | Complete turn-in and pick a new contract | Stonebrook Guild hall | 95/84 | 23.8 s |
| 79 | #quests | System (Befehl) | open_run_level | Verify whether the wolf turn-in is recorded and coin updated | Stonebrook Guild hall | 95/84 | 2.5 s |
| 80 | I ask the clerk to accept the Crystal Beetles of Glimmerdeep Grotto contract from the board for me. | Erzähler | open_run_level | Accept a new Novice Guild contract | Stonebrook Guild hall | 95/84 | 18.9 s |
| 81 | I slide the wolf contract slip back across the counter and ask the clerk to formally close and pay out the Lamb-Rending Wolf contract, since… | Erzähler | open_run_level | Complete the still-active wolf turn-in before taking new work | Stonebrook Guild hall | 95/84 | 23.6 s |
| 82 | #audit | System (Befehl) | open_run_level | Check the recorded log of the wolf turn-in and payout | Stonebrook Guild hall | 95/84 | 2.5 s |
| 83 | #quests | System (Befehl) | open_run_level | Check whether the wolf contract is still recorded as active | Stonebrook Guild hall | 95/84 | 2.5 s |
| 84 | Since the hall's ledger says I'm square, I set the wolf matter aside and ask the clerk to accept the Crystal Beetles of Glimmerdeep Grotto c… | Erzähler | open_run_level | Move on to a new listed contract | Stonebrook Guild hall | 95/84 | 25.0 s |
| 85 | Yes, I mean to close it out proper — I slew the wolf and have proof. Please seal the line and pay out the forty copper. | Erzähler | open_run_level | Complete the wolf turn-in with the clerk | Stonebrook Guild hall | 95/84 | 37.9 s |
| 86 | Leave the ledger open and let the branch master sort the slip in the morning. | Erzähler | open_run_level | Let the branch master rule on the muddled wolf slip so the forty copper can be paid proper… | Stonebrook Guild hall | 95/84 | 17.8 s |
| 87 | I take the slip, thank the clerk, and head to the Gilded Ewe to ask Marla for a room and a hot meal for the night. | Erzähler | open_run_level | Lodge overnight and return at mid-morning for the branch master's ruling | The Gilded Ewe | 95/84 | 19.8 s |
| 88 | I'll take the six-copper option, Marla — room, pottage with meat, and breakfast. | Erzähler | open_run_level | Buy the 6 cp lodging package | The Gilded Ewe | 95/84 | 25.6 s |
| 89 | I eat the supper, then go up to the loft and sleep until morning. | Erzähler | open_run_level | Recover overnight at the Gilded Ewe | loft of the Gilded Ewe | 95/84 | 18.5 s |
| 90 | I come down for breakfast, then go to the Guild hall and ask the branch master Corven for his ruling on my wolf contract payout. | Erzähler | open_run_level | Get breakfast and the wolf ruling | Stonebrook Guild hall | 95/84 | 27.5 s |
| 91 | I go out to the counter and hand Tam the sealed wolf slip for turn-in, asking for the forty copper to be paid in front of witnesses as Corve… | Erzähler | open_run_level | Complete the wolf turn-in with Tam at the counter | Stonebrook Guild hall | 95/84 | 31.6 s |
| 92 | I wait at the hall for Tam's return, and while I wait I ask the clerk to show me the contract board for any new work posted this morning. | Erzähler | open_run_level | Wait for Tam's midday return and browse new contracts | Stonebrook Guild hall | 95/84 | 27.2 s |
| 93 | I hand Tam the sealed wolf slip and ask him to pay the forty copper now, witnessed by Dethmas. | Erzähler | open_run_level | Complete the wolf turn-in and receive payment | Stonebrook Guild hall | 95/84 | 24.8 s |
| 94 | I take the bench again and wait for Corven to return from the Bracken farm, keeping the sealed slip on me. | Erzähler | open_run_level | Wait for Corven's return to complete the payout | Stonebrook Guild hall | 95/84 | 29.6 s |
| 95 | I take the forty copper from the counter, thank Corven, and head to the Gilded Ewe for a room and sleep until morning. | Erzähler | open_run_level | Collect pay and recover overnight | The Gilded Ewe | 95/84 | 40.4 s |
| 96 | I take the four-copper room, pay Marla, and go up to sleep until morning. | Erzähler | open_run_level | Buy lodging and recover overnight | back room of the Gilded Ewe | 95/84 | 26.4 s |
| 97 | I get into bed and sleep until morning. | Erzähler | open_run_level | Recover overnight in the paid room | back room of the Gilded Ewe | 95/84 | 15.4 s |
| 98 | #audit | System (Befehl) | open_run_level | Check recorded coin changes to resolve the 0-copper discrepancy | back room of the Gilded Ewe | 95/84 | 2.6 s |
| 99 | I go down to the Guild hall and ask the clerk for the current contract board. | Erzähler | open_run_level | Find a new achievable Guild contract | Stonebrook Guild hall | 95/84 | 19.3 s |
| 100 | I tell the clerk I'll take the board, and ask him to read out what slips are posted. | Erzähler | open_run_level | Read the Guild contract board for a new achievable job | Stonebrook Guild hall | 95/84 | 139.6 s |
| 101 | I step fully inside the Guild hall, close the door behind me, and ask the clerk to read out the slips on the board. | Erzähler | open_run_level | Read the contract board from inside the hall | Stonebrook Guild hall | 95/84 | 57.7 s |
| 102 | I hand the wolf contract slip to the clerk and ask him to pay out the forty copper. | Erzähler | open_run_level | Turn in the READY wolf contract for the 40 cp payout | Stonebrook Guild hall | 95/84 | 34.9 s |
| 103 | I tell the clerk I may have left the slip at the Ewe, and ask whether he can close the contract from the Guild plate or my record if I fetch… | Erzähler | open_run_level | Resolve where the actual contract slip is | Stonebrook Guild hall | 95/84 | 24.3 s |
| 104 | I go to the Ewe and search my room for the wolf contract slip, checking coat pockets, under the mattress and behind the bench. | Erzähler | open_run_level | Fetch the READY slip to complete the turn-in | loft of the Gilded Ewe | 95/84 | 23.2 s |
| 105 | I search the loft room for the wolf contract slip: coat pockets on the peg, under the mattress, behind the bench and the floor cracks. | Erzähler | open_run_level | Find the READY wolf contract slip in my loft | loft of the Gilded Ewe | 95/84 | 43.3 s |
| 106 | I go downstairs and ask Marla whether a contract slip was left at the bar or seen anywhere in the common room, and whether Hesk or anyone ha… | Erzähler | open_run_level | Trace the missing READY wolf contract slip through the common room | The Gilded Ewe | 95/84 | 30.6 s |
| 107 | I thank Marla and go back out, searching the road between the Guild hall and the Ewe for the dropped wolf contract slip, starting near the w… | Erzähler | open_run_level | Search the route between hall and inn for the missing slip | Stonebrook | 95/84 | 34.4 s |
| 108 | I go into the Guild hall and ask the clerk to check my Guild plate against the wolf contract record, since the slip is lost, and pay out the… | Erzähler | open_run_level | Have the clerk close the READY wolf contract from my Guild plate record | Stonebrook Guild hall | 95/84 | 44.0 s |
| 109 | I ask the clerk when Corven is due in, and say I'll wait for him to have the roll marked lost and a new slip cut — meanwhile, is there anyth… | Erzähler | open_run_level | Escalate lost slip to Corven and pick up new work while waiting | Stonebrook Guild hall | 95/84 | 46.7 s |
| 110 | I take the Note of deposit from my pouch and examine it closely — is this the contract slip itself? | Erzähler | open_run_level | Inspect the note of deposit as a possible slip | Stonebrook Guild hall | 95/84 | 34.2 s |
| 111 | I hand the clerk the slip and ask him to strike the seal and pay out the forty copper. | Erzähler | open_run_level | Turn in the wolf contract | Stonebrook Guild hall | 95/84 | 38.0 s |
| 112 | I leave the slip in the clerk's drawer under my name and go find Hesk to offer that second pair of eyes on the east ford. | Erzähler | open_run_level | Do Hesk's ford-watching errand while waiting for Corven's midday arrival | the flooded east ford | 95/84 | 30.3 s |
| 113 | "No coin needed — breakfast suits me fine. I'll watch the water and the horse while you cross. Where's that shifting stone usually sit, and … | Erzähler | open_run_level | Help Hesk at the ford for breakfast and goodwill | the flooded east ford | 95/84 | 37.6 s |
| 114 | I keep my eyes fixed on the bulge where the stone should break the current, ready to shout 'Stone' the instant it shifts or the quiet water … | Erzähler | open_run_level | Watch the ford crossing for Hesk | the flooded east ford | 95/84 | 26.7 s |
| 115 | I walk back with Hesk to the eatery by the well, and once we're settled I ask him whether Corven's come through yet — I need my wolf contrac… | Erzähler | open_run_level | Get breakfast, settle the slip with Corven via Tam/Hesk, then turn in the wolf contract | the eatery by the well | 95/84 | 38.6 s |
| 116 | I eat the breakfast Hesk ordered and stay at the table, keeping an eye on the door in case Corven comes off the road by midday. | Erzähler | open_run_level | Wait for Corven at the eatery while eating the earned breakfast | the eatery by the well | 95/84 | 29.1 s |
| 117 | I finish my ale and head to the Guild hall to see Tam about getting my lost wolf contract slip sorted. | Erzähler | open_run_level | Resolve the lost slip with Tam at the Guild hall | Stonebrook Guild hall | 95/84 | 26.0 s |
| 118 | I tell Tam the truth: I lost the slip somewhere between the hall and the inn last night, and I've searched both without luck — the wolf's co… | Erzähler | open_run_level | Resolve the lost wolf contract slip with Tam | Stonebrook Guild hall | 95/84 | 22.6 s |
| 119 | I can't cover a silver right now — my pouch is empty until this wolf pays out. What's the slower way? And before anything else, Marla at the… | Erzähler | open_run_level | Resolve the lost slip without coin I don't have | Stonebrook Guild hall | 95/84 | 17.1 s |
| 120 | I thank Tam and head to Marla's inn to ask whether my lost wolf contract slip has been handed in behind her bar. | Erzähler | open_run_level | Search for the lost slip at Marla's inn before signing any declaration | The Gilded Ewe | 95/84 | 22.5 s |
| 121 | I tell Marla where I sat and the route I took — a bench near the hearth, then the lane past the well and Hesk's tables — and ask if Bramble'… | Erzähler | open_run_level | Search the route and midden for the lost slip | The Gilded Ewe | 95/84 | 29.6 s |
| 122 | I head back to the Guild hall and hand Tam the recovered slip, seal intact, to collect my wolf payout. | Erzähler | open_run_level | Turn in the found slip and get paid | Stonebrook Guild hall | 95/84 | 19.5 s |
| 123 | I hand Tam the recovered slip, seal intact, and ask for my forty coppers for the wolf. | Erzähler | open_run_level | Turn in the wolf slip and collect payout | Stonebrook Guild hall | 95/84 | 24.6 s |
| 124 | I walk to the Guild hall across the lane and, once at Tam's counter, hand him the recovered slip, seal intact, and ask for my forty coppers. | Erzähler | open_run_level | Turn in the wolf slip at the correct Guild hall | Stonebrook Guild hall | 95/84 | 23.8 s |
| 125 | I wait by the counter for Tam to come back from the delivery, slip lying flat where the woman set it, and hand it to him seal-up for my fort… | Erzähler | open_run_level | Wait for Tam and turn in the wolf slip | Stonebrook Guild hall | 95/84 | 21.0 s |
| 126 | #bag | System (Befehl) | open_run_level | Verify the wolf payout was recorded | Stonebrook Guild hall | 95/84 | 2.8 s |
| 127 | #quests | System (Befehl) | open_run_level | Verify whether the wolf contract turn-in and payout were actually recorded | Stonebrook Guild hall | 95/84 | 2.8 s |
| 128 | #audit | System (Befehl) | open_run_level | Check whether the wolf payout was engine-recorded | Stonebrook Guild hall | 95/84 | 2.7 s |
| 129 | I lay the slip on Tam's counter, seal up, and ask the Guild clerk to pay out the forty coppers for the Stonebrook wolf. | Erzähler | open_run_level | Turn in wolf slip to Tam at the Guild hall for payout | Stonebrook Guild hall | 95/84 | 28.7 s |
| 130 | I take the note back and hurry to the Gilded Ewe, then ask Marla whether my lost wolf contract slip came across her floor and search behind … | Erzähler | open_run_level | Recover the lost wolf contract slip at the Gilded Ewe | The Gilded Ewe | 95/84 | 21.6 s |
| 131 | Marla allows it, so I crouch behind the strongbox and shine a light into the gap, carefully fishing out the fallen things to look for the Gu… | Erzähler | open_run_level | Search behind the strongbox for the lost wolf contract slip | The Gilded Ewe | 95/84 | 29.2 s |
| 132 | I give Bramble back her three coppers and button, then hurry to the Guild hall and lay the READY-sealed wolf slip on the counter, asking the… | Erzähler | open_run_level | Turn in the recovered wolf slip for payout at the Guild hall | Stonebrook Guild hall | 95/84 | 34.2 s |
| 133 | I ask the clerk to hold the slip here under my name for the payout, then go to the Gilded Ewe and sleep in my rented room until morning. | Erzähler | open_run_level | Leave slip for payout and recover overnight | loft of the Gilded Ewe | 95/84 | 40.7 s |
| 134 | I climb into the narrow bed and sleep until morning. | Erzähler | open_run_level | Actually sleep at the Ewe to pass to morning | loft of the Gilded Ewe | 95/84 | 15.3 s |
| 135 | I walk to the Guild hall and ask the clerk to pay out the forty coppers for the wolf slip held under my name. | Erzähler | open_run_level | Collect the held wolf payout now that the box is open | Stonebrook Guild hall | 95/84 | 20.0 s |
| 136 | While I wait for Corven, I ask the clerk to show me the contract board for any new work posted this morning. | Erzähler | open_run_level | Check for new Guild contracts while waiting for the payout | Stonebrook Guild hall | 95/84 | 15.0 s |
| 137 | I sit by the stove to wait for Corven, and while I wait I ask the clerk what he knows about the Glimmerdeep Grotto work that might eventuall… | Erzähler | open_run_level | Wait for Corven's return to collect payout and hear about future work | Stonebrook Guild hall | 95/84 | 33.2 s |
| 138 | I confirm the slip is still under my name and ask Corven to mark the ledger so the clerk can pay out my forty coppers. | Erzähler | open_run_level | Get Corven's mark and collect the wolf payout | Stonebrook Guild hall | 95/84 | 26.5 s |
| 139 | I tell Corven I'll give him his hour and settle in by the stove to wait for his return. | Erzähler | open_run_level | Wait for Corven's mark before payout | Stonebrook Guild hall | 95/84 | 26.3 s |
| 140 | I take the forty coppers and ask the clerk to close out the wolf contract under my name. | Erzähler | open_run_level | Complete the wolf contract turn-in and collect pay | Stonebrook Guild hall | 95/84 | 27.1 s |
| 141 | I take the slip, tell Corven and the clerk I'll collect at Marlow Ford, and set out on the east road for the Ford branch; on arrival I prese… | Erzähler | open_run_level | Travel to Marlow Ford Guild branch and turn in the wolf contract | Marlow Ford | 95/84 | 35.6 s |
| 142 | I ask the clerk to show me the contract board for work a novice swordsman can handle, since I'll be waiting in town for the courier. | Erzähler | open_run_level | Find new Guild work while waiting for the roll copy | Marlow Ford | 95/84 | 21.7 s |
| 143 | I leave the Guild hall, go to the inn two doors down, and ask for a room for the night. | Erzähler | open_run_level | Get lodging and sleep until the courier arrives tomorrow | an inn two doors down from the Marlow Ford Guild branch | 95/84 | 19.6 s |
| 144 | "A room for the night, and whatever the frying pot is serving," I say, setting my hand on the bar. | Erzähler | open_run_level | Get lodging and a meal at the inn | an inn two doors down from the Marlow Ford Guild branch | 95/84 | 13.8 s |
| 145 | #bag | System (Befehl) | open_run_level | Check actual coin before buying | an inn two doors down from the Marlow Ford Guild branch | 95/84 | 2.9 s |
| 146 | I already hold a room key, so I thank the innkeeper, keep my coin for now, and go up to my room to sleep until morning. | Erzähler | open_run_level | Sleep using the room key I already carry | an inn two doors down from the Marlow Ford Guild branch | 95/84 | 18.9 s |
| 147 | I go next door to the Marlow Ford Guild branch, present the contract slip and the note of deposit, and ask for my 40 copper payout for the w… | Erzähler | open_run_level | Turn in the wolf contract at Marlow Ford branch and collect payment | an inn two doors down from the Marlow Ford Guild branch | 95/84 | 33.7 s |
| 148 | I ask the innkeeper which road leads back to Stonebrook, since the wolf contract must be turned in at a proper Guild hall. | Erzähler | open_run_level | Find the way back to a Guild hall to turn in the wolf contract | an inn two doors down from the Marlow Ford Guild branch | 95/84 | 32.4 s |
| 149 | I go two doors up to the Guildhall the innkeeper mentioned and, if it is open, present the contract slip and note of deposit to claim my 40 … | Erzähler | open_run_level | Turn in the wolf contract at the local Guildhall | Guild — Marlow Ford Receiving House | 95/84 | 21.6 s |
| 150 | I set out on the west road toward Stonebrook to turn in the wolf contract at its Guild hall. | Erzähler | open_run_level | Travel to Stonebrook for the payout | Stonebrook | 95/84 | 24.9 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 15 (notiert vor Zug 16): Stonebrook desk can't pay out; turn-in requires the chartered branch hall in Millbrook, a day south. Narration lagged location (still says pens) but engine confirmed hall presence.
- zu Zug 22 (notiert vor Zug 23): Millbrook branch post cannot pay out contracts; turn-in requires a proper Guild hall in Stonebrook.
- zu Zug 26 (notiert vor Zug 27): Innkeeper is Hesta, not Marla; Marla runs the Gilded Ewe in Dorren's Cross.
- zu Zug 28 (notiert vor Zug 29): Clerk confirms any branch can close any branch's contract — earlier assumption that Stonebrook was required was wrong.
- zu Zug 29 (notiert vor Zug 30): HUD lists only the note of deposit, no contract slip — checking inventory before assuming it's lost.
- zu Zug 30 (notiert vor Zug 31): Bag holds only the note of deposit, no contract slip, though the wolf is recorded 1/1 defeated.
- zu Zug 32 (notiert vor Zug 33): Wolf contract closed via branch rolls despite missing slip; reward 40 cp paid, HUD still shows 1S9C pending update.
- zu Zug 33 (notiert vor Zug 34): Engine confirmed the wolf contract closed clean at Millbrook, but the HUD and quest panel still show it active — will verify at Stonebrook.
- zu Zug 34 (notiert vor Zug 35): Narrator placed me only at the stream crossing at 18:05, not in Stonebrook — travel must be completed explicitly.
- zu Zug 36 (notiert vor Zug 37): Engine refused the room purchase with 'arrival pending' even though narration had placed me at the inn door; now confirmed present inside, so retrying with the innkeeper.
- zu Zug 38 (notiert vor Zug 39): Engine says the room is not booked despite paying 4 cp; narrator confirms coin taken but booking unsettled — HUD still shows 1S9C, possibly a pending update.
- zu Zug 43 (notiert vor Zug 44): Turn-in was refused twice as 'not at a Guild hall' despite the HUD showing the Guild hall; now the clerk asks for a name match, suggesting a speech-based flow.
- zu Zug 48 (notiert vor Zug 49): Stonebrook's Guild hall is only a posting house; payout must be collected at the Milldale branch.
- zu Zug 49 (notiert vor Zug 50): Turn-in refused again with 'not at a Guild hall' even while en route — the engine seems to require arrival at Milldale before the action message. Note the goal 'reach Milldale' must complete first.
- zu Zug 51 (notiert vor Zug 52): Engine still reports location as the flooded hollow despite narration describing arrival in Milldale — arrival must be confirmed before the turn-in registers.
- zu Zug 52 (notiert vor Zug 53): Milldale branch is a reading branch only — no pay chest; wolf payout must wait for a full Guild hall (Stonebrook or elsewhere). Location panel still says flooded hollow despite confirmed arrival narration.
- zu Zug 57 (notiert vor Zug 58): Location now confirmed as Milldale; the wolf contract shows 1/1 defeated and awaits a full-hall turn-in.
- zu Zug 63 (notiert vor Zug 64): Wolf payout is flagged to the Stonebrook desk only; Millhaven cannot close it despite the READY seal.
- zu Zug 64 (notiert vor Zug 65): Millhaven Novice board is empty until tomorrow's first bell; wolf payout remains Stonebrook-only.
- zu Zug 66 (notiert vor Zug 67): Engine refused the sleep because no canonical room offer was booked despite narration showing payment; HUD still shows 1s2c so the 2c may not have been charged.
- zu Zug 67 (notiert vor Zug 68): Innkeeper repeatedly takes 2c but engine records no booking; HUD coin unchanged at 1s2c. Ferrywoman present, not the innkeeper — maybe the innkeeper NPC isn't a canonical seller.
- zu Zug 69 (notiert vor Zug 70): Engine says no innkeeper is established as present despite narration; only the ferrywoman is listed as present.
- zu Zug 70 (notiert vor Zug 71): Valid canonical offer now established: ferrywoman, room above the common room, 2 cp.
- zu Zug 72 (notiert vor Zug 73): Lodging purchase finally confirmed via explicit terms; coin 12→10 copper.
- zu Zug 74 (notiert vor Zug 75): Contradiction: narrator walked me to Millhaven, but engine kept location at the ferry crossing and confirms Millhaven has no Guild branch; Stonebrook hall is the true turn-in node.
- zu Zug 75 (notiert vor Zug 76): Engine refused turn-in with 'not at a Guild hall' even though location reads Stonebrook; possibly need to explicitly enter the hall node first.
- zu Zug 76 (notiert vor Zug 77): Engine refuses quest.turn_in with 'not at a Guild hall' even though HUD confirms location Stonebrook Guild hall and clerk present; narrator hints payout may be tied to Millhaven branch.
- zu Zug 77 (notiert vor Zug 78): HUD still shows quest active and coin as 1 Silver despite clerk narrating payout; will verify coin via #bag before spending.
- zu Zug 80 (notiert vor Zug 81): Quest panel still lists the wolf contract as active with 1/1 defeated despite the clerk narrating a payout; beetle contract was refused as not posted at this hall.
- zu Zug 81 (notiert vor Zug 82): Engine still refuses turn-in with 'not at a Guild hall' despite HUD confirming Stonebrook Guild hall; clerk insists the contract is closed and paid. Audit may show whether the payout was actually recorded.
- zu Zug 82 (notiert vor Zug 83): Audit shows the engine rejecting narrator attempts to override quest status — the clerk's 'closed and paid' may be story-only, while the engine's turn_in refusal seems to be a location bug.
- zu Zug 83 (notiert vor Zug 84): Wolf contract remains engine-active and turn_in refuses with 'not at a Guild hall' even at the confirmed hall; clerk's payout is story-only. Treating wolf as blocked and switching contracts.
- zu Zug 85 (notiert vor Zug 86): Wolf turn-in remains engine-blocked ('not at a Guild hall') and the slip is spent per the clerk; the beetle contract is not posted here despite the quest panel listing it. Wolf payout deferred to branch master's morning ruling.
- zu Zug 91 (notiert vor Zug 92): Turn-in blocked again with 'not at a Guild hall' despite being inside the hall — likely a state quirk tied to Tam's absence; HUD clock shows Day 7, 23:30 night while narration says morning.
- zu Zug 92 (notiert vor Zug 93): HUD clock jumped oddly to Day 8, 01:30 night despite narration saying near midday; Tam is present and ready to pay.
- zu Zug 93 (notiert vor Zug 94): Narration clock (near midday Day 8) contradicts HUD clock (Day 8, 01:35 night); payout genuinely needs Corven's seal, not just Tam.
- zu Zug 94 (notiert vor Zug 95): Wolf contract closed and paid at the counter with Corven's seal; narration clock and HUD clock still disagree (near midnight vs full dark).
- zu Zug 95 (notiert vor Zug 96): HUD still shows 4 Copper despite narration of the 40 cp payout — coin discrepancy to watch; the 4 cp room would leave nothing in reserve.
- zu Zug 96 (notiert vor Zug 97): Coin shows 0 despite earlier 40 cp payout — HUD discrepancy; narration suggested bed was ready but engine still refused sleep last turn.
- zu Zug 97 (notiert vor Zug 98): HUD shows 0 copper despite the confirmed 40 cp payout; also an unrecorded 2 cp breakfast debt to Marla.
- zu Zug 98 (notiert vor Zug 99): Audit reports no problems, yet coin shows 0 despite the confirmed 40 cp payout — unresolved HUD discrepancy; also a 2 cp breakfast debt to Marla to settle once coin is confirmed.
- zu Zug 99 (notiert vor Zug 100): Wolf contract still shows active 1/1 with 0 coin in HUD despite confirmed payout — HUD may be stale; board supposedly unchanged but not yet actually read.
- zu Zug 100 (notiert vor Zug 101): Engine refused board reads while I stood half in the doorway; wolf contract shows READY with 40 cp awaiting proper turn-in despite HUD showing 0 copper.
- zu Zug 102 (notiert vor Zug 103): Clerk now claims the slip shows READY and must be handed over physically, though HUD only lists the deposit note; payout blocked pending the slip's location.
- zu Zug 106 (notiert vor Zug 107): Marla confirms I had the slip in my coat at supper; coat already searched empty, so it likely dropped on the road. Hesk, who must confirm the wolf contract, is out until midday.
- zu Zug 107 (notiert vor Zug 108): Slip confirmed absent from loft, common room and road; Hesk, the contract's confirmer, is out until midday.
- zu Zug 112 (notiert vor Zug 113): Wolf contract slip still sits with Tam pending Corven's midday arrival; HUD still shows the quest active with 0 copper.
- zu Zug 115 (notiert vor Zug 116): Corven hasn't crossed the ford; Hesk suggests he may show by midday or have gone round by the bridge.
- zu Zug 116 (notiert vor Zug 117): Corven never appeared by midday; the wolf contract shows 1/1 defeated but 0 copper in the HUD, so pay still hinges on the slip.
- zu Zug 121 (notiert vor Zug 122): Slip found by the drain, seal intact — no declaration or fee needed.
- zu Zug 123 (notiert vor Zug 124): Narrator twice placed me in the Gilded Ewe while HUD said Guild hall; now explicitly traveling to the hall.
- zu Zug 125 (notiert vor Zug 126): Narrator says Tam paid 40 coppers, but HUD still shows 0 Copper and the quest active — checking panels.
- zu Zug 126 (notiert vor Zug 127): Narrator says Tam paid 40 coppers, but #bag still shows 0 Copper and the note of deposit remains — payout may not be engine-recorded.
- zu Zug 127 (notiert vor Zug 128): Narrator says Tam paid 40 coppers, but #bag still shows 0 Copper and the quest remains active with the slip in my bag — payout may not be recorded.
- zu Zug 128 (notiert vor Zug 129): Audit confirms the narrator's payment was rejected; the engine still holds the payout, so I re-request it at the Guild hall with Tam present.
- zu Zug 129 (notiert vor Zug 130): The engine rejected turn-in as 'not at a Guild hall' despite the HUD naming the Guild hall as my location; the slip itself is lost, with leads pointing to Marla's bar or the midden bin.
- zu Zug 131 (notiert vor Zug 132): Slip recovered behind the Ewe's strongbox; quest now shows READY for turn-in.
- zu Zug 139 (notiert vor Zug 140): HUD still shows 0 Copper and the quest active despite the counted payout; the engine previously refused turn_in for not being at a Guild hall, which contradicts the confirmed location.
- zu Zug 140 (notiert vor Zug 141): The Stonebrook hall is an outpost that logs but cannot pay; payout officially due at Marlow Ford, half a day east. HUD still shows 0 Copper and quest active.
- zu Zug 144 (notiert vor Zug 145): HUD shows 0 Copper despite the wolf contract being 1/1 defeated and payout promised at Marlow Ford; cannot pay for lodging at 0 cp.
- zu Zug 145 (notiert vor Zug 146): Bag unexpectedly shows a room key already in my possession, so lodging may be secured despite 0 Copper.
- zu Zug 147 (notiert vor Zug 148): No Guild branch exists in Marlow Ford despite HUD location text saying otherwise; payout requires a recognized hall.
- zu Zug 148 (notiert vor Zug 149): Innkeeper says a Guildhall exists two doors up, opening mid-morning, though earlier engine result said no branch in this settlement.
- zu Zug 149 (notiert vor Zug 150): Receiving house confirmed unable to pay out; turn-in must happen at Stonebrook or a full branch.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t13 | 13 | 1 | – | ja | 1 | gewonnen, 30 XP |

## Quests

- **Slay the Lamb-Rending Wolf of Stonebrook** — active (Zug 6), READY
  - Aufgabe: Kill 1 the lamb-rending wolf at the pastures and pens around Stonebrook. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the lamb-rending wolf killed at the pastures and pens around Stonebrook.

## Auffälligkeiten

- Zug 6, Nachricht 12 (extraction_repaired): the extractor's first answer needed a repair
- Zug 9, Nachricht 17 (planner_repaired): the planner's first answer needed a repair
- Zug 14, Nachricht 28 (extraction_repaired): the extractor's first answer needed a repair
- Zug 21, Nachricht 42 (extraction_repaired): the extractor's first answer needed a repair
- Zug 23, Nachricht 45 (planner_repaired): the planner's first answer needed a repair
- Zug 24, Nachricht 48 (extraction_repaired): the extractor's first answer needed a repair
- Zug 26, Nachricht 51 (planner_repaired): the planner's first answer needed a repair
- Zug 29, Nachricht 58 (extraction_repaired): the extractor's first answer needed a repair
- Zug 32, Nachricht 64 (extraction_repaired): the extractor's first answer needed a repair
- Zug 38, Nachricht 75 (planner_repaired): the planner's first answer needed a repair
- Zug 39, Nachricht 77 (planner_repaired): the planner's first answer needed a repair
- Zug 39, Nachricht 78 (extraction_repaired): the extractor's first answer needed a repair
- Zug 46, Nachricht 91 (planner_repaired): the planner's first answer needed a repair
- Zug 46, Nachricht 92 (extraction_repaired): the extractor's first answer needed a repair
- Zug 50, Nachricht 100 (extraction_repaired): the extractor's first answer needed a repair
- Zug 52, Nachricht 104 (extraction_repaired): the extractor's first answer needed a repair
- Zug 53, Nachricht 106 (extraction_repaired): the extractor's first answer needed a repair
- Zug 55, Nachricht 109 (planner_repaired): the planner's first answer needed a repair
- Zug 59, Nachricht 118 (extraction_repaired): the extractor's first answer needed a repair
- Zug 61, Nachricht 122 (extraction_repaired): the extractor's first answer needed a repair
- Zug 63, Nachricht 126 (extraction_repaired): the extractor's first answer needed a repair
- Zug 66, Nachricht 132 (extraction_repaired): the extractor's first answer needed a repair
- Zug 67, Nachricht 134 (extraction_repaired): the extractor's first answer needed a repair
- Zug 71, Nachricht 141 (planner_repaired): the planner's first answer needed a repair
- Zug 72, Nachricht 143 (planner_repaired): the planner's first answer needed a repair
- Zug 72, Nachricht 144 (extraction_repaired): the extractor's first answer needed a repair
- Zug 74, Nachricht 148 (extraction_repaired): the extractor's first answer needed a repair
- Zug 84, Nachricht 167 (planner_repaired): the planner's first answer needed a repair
- Zug 111, Nachricht 222 (extraction_repaired): the extractor's first answer needed a repair
- Zug 133, Nachricht 265 (planner_repaired): the planner's first answer needed a repair
- Zug 133, Nachricht 266 (extraction_repaired): the extractor's first answer needed a repair
- Zug 141, Nachricht 282 (extraction_repaired): the extractor's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 35× keine gültige JSON-Entscheidung (Züge 8, 9, 10, 11, 13, 19, 20, 23, 32, 36, 37, 38, 43, 45, 46, 47, 49, 51, 60, 64, 74, 77, 80, 81, 104, 106, 109, 110, 118, 124, 132, 136, 139, 142, 148)

System-Panels: CLARIFY 2, NOT TAKEN 0, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: ambient 7, engine_owned_fact 30, place 2, scene_context 21, guild_canon 11, offer 3, npc_presence 4, npc_continuity 7, guild_payout 3, engine_owned_memory 8, world_rule 3, no_go 7, time_cap 6, pc_inventory 2, guild_quest_detail 2, engine_booked 2.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 35/150 Erstantworten ungültig (23.3 %); 35 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 147 | 11 | 2.6 s | 4.7 s | 11422 | 9913 | 99 | – | stop 147 | 0 |
| board | 2 | 1 | 10.0 s | 10.4 s | 2947 | 1278 | 1024 | – | stop 2 | 0 |
| narrator | 135 | 0 | 10.6 s | 18.4 s | 11496 | 8776 | 463 | – | stop 135 | 0 |
| extract | 155 | 21 | 5.8 s | 11.3 s | 11762 | 9391 | 377 | – | stop 155 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 72:30 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 67.4 s) | 1:25 min |
| 150 Züge, Spiel (Senden bis HUD nach der Extraktion) | 59:37 min — Median 23.5 s, p90 35.6 s, max 139.6 s |
| 150 Züge, Spieler-Entscheidung | 8:37 min — Median 2.8 s, 35 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 7:38 min / 0:20 min / 28:38 min / 16:47 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 27.3 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 18:12 min, 80 Züge ≈ 36:23 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spiel | 100 | – | 139.6 s | 23.5 s |
| Provider narrator | 100 | 296 | 122.1 s | 10.6 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
