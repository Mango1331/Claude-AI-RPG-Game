# Avereth Live-Test 20261029-102723Z-current_test

## Kurzfassung

- **Laufprofil:** guild-mage; Startklasse Mage, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** abgebrochen: Limit erreicht — 150 turns
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 8. Sicherheitsgrenzen: 150 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** Level 6, 390 XP seit Levelaufstieg, 1092 cp, HP 135, MP 146; Ort realm.caelreth.the_cart_road_by_the_foxfire_grove_kilns. Ausrüstung und Skills stehen in evaluation.json → progression.checkpoint.
- **Charakter:** mage (mage.arcane_bolt, mage.arcane_wave) · Regelstand 2 (Warrior, Mage, Rogue)
- **Ziel-Dungeon:** Glimmerdeep Grotto, Ebene 1 (Vertrag quest.clear_glimmerdeep_grotto_level_1)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: cautious adventurer: prepare and recover, weigh threats and withdraw when sensible
- **Züge:** 150 · **Dauer:** 61:34 min · **LLM-Aufrufe der Engine/des Erzählers:** 438
- **Beobachtete Abdeckung:** 32 unterschiedliche gebuchte Reiseziele · 17 Kämpfe · 8 Verkäufe (767 cp Umsatz, ohne Questzahlungen/Geschenke) · 0 Ausrüstungswechsel · 1 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 32
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.116 |
| Git | 846a7c3ce0be (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 15.4 s |
| Browser | chrome 156.0.8078.49 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261029-102723Z-current_test“, Seed 2120501930 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | I choose Mage. | Engine (Menü/Rückfrage) | creation_complete | Select the Mage base class | public roadside verge outside Glassmere | 90/84 | 2.3 s |
| 2 | I select Arcane Wave and Arcane Bolt as my two skills. | Engine (Menü/Rückfrage) | creation_complete | Finish character creation with required AoE skill | public roadside verge outside Glassmere | 90/96 | 2.1 s |
| 3 | I walk into Glassmere and head to the Adventurers' Guild hall to register and look at the contract board. | Erzähler | open_run_level | Enter city and reach the Guild | Adventurers' Guild hall, Glassmere | 90/96 | 27.8 s |
| 4 | I pay the two silver registration fee and sign the form. | Erzähler | open_run_level | Register with the Guild | Adventurers' Guild hall, Glassmere | 90/96 | 16.8 s |
| 5 | I take the bog strider slip from the board to the clerk and ask her to mark it active. | Erzähler | open_run_level | Accept the Reed Flats bog strider contract | Adventurers' Guild hall, Glassmere | 90/96 | 14.5 s |
| 6 | I leave the Guild hall and follow the river road east past the tanneries toward the Reed Flats. | Erzähler | open_run_level | Travel to the bog strider hunting grounds | the eel-weirs of the Reed Flats | 90/96 | 20.1 s |
| 7 | "Yes, I'm from the Guild — can you point me to where the striders have been seen?" | Erzähler | open_run_level | Ask the fisher where to find the bog striders | the eel-weirs of the Reed Flats | 90/96 | 19.0 s |
| 8 | I walk the fence line past the third trap fence, keeping to the hummocks, and look for the bog striders. | Erzähler | open_run_level | Hunt the bog striders at the braided channels | the fourth trap fence | 90/96 | 20.1 s |
| 9 | I stay on the hummocks and cast Arcane Bolt at the bog strider. | Erzähler | open_run_level | Open the hunt with a single-target spell | the fourth trap fence | 90/86 | 17.4 s |
| 10 | I head back along the fence line to the fishers at the weir line, then take the road west to the Guild hall in Caelreth to turn in the bog s… | Erzähler | open_run_level | Turn in the completed contract | Adventurers' Guild hall, Glassmere | 90/86 | 26.0 s |
| 11 | I look over the Guild board for another contract I can take. | Erzähler | open_run_level | Find the next Guild contract | Adventurers' Guild hall, Glassmere | 90/86 | 11.9 s |
| 12 | I ask the clerk: "Which of these would you say is manageable solo for a novice mage — the wolf cull at Foxfire Grove or the Glimmerdeep grot… | Erzähler | open_run_level | Ask the clerk for advice on the next contract | Adventurers' Guild hall, Glassmere | 90/86 | 16.4 s |
| 13 | "The grotto, then. Mark the Glimmerdeep clear active for me." | Erzähler | open_run_level | Accept the Glimmerdeep grotto contract | Adventurers' Guild hall, Glassmere | 90/86 | 15.4 s |
| 14 | I leave the Guild hall and follow the river road north, watching for the red-ribboned survey stakes marking the way to Glimmerdeep. | Erzähler | open_run_level | Travel to Glimmerdeep Grotto | Glimmerdeep Grotto | 90/86 | 15.6 s |
| 15 | I enter Glimmerdeep Grotto and move into the first chamber cautiously, staff ready, watching for beetles near the crystal seams. | Erzähler | open_run_level | Enter the dungeon and begin the clear | second gallery of Glimmerdeep Grotto | 90/86 | 19.6 s |
| 16 | I retreat a few steps back toward the passage to draw the beetles into a cluster, then cast Arcane Wave at the group. | Engine (Menü/Rückfrage) | open_run_level | Fight the four beetles with AoE | second gallery of Glimmerdeep Grotto | 90/86 | 5.3 s |
| 17 | I cast Arcane Wave at the four glass beetles in the gallery, targeting the group of Glass Beetles A, B, C and D. | Engine (Menü/Rückfrage) | open_run_level | AoE the clustered beetles, naming targets | second gallery of Glimmerdeep Grotto | 90/86 | 4.5 s |
| 18 | I cast Arcane Wave at Glass Beetle A, aiming the burst to catch all four clustered beetles. | Erzähler | open_run_level | AoE the beetle cluster with a named primary target | second gallery of Glimmerdeep Grotto | 53/72 | 20.5 s |
| 19 | I cast Arcane Wave at Glass Beetle A, hoping the burst finishes the wounded ones. | Erzähler | open_run_level | AoE the engaged beetles again | second gallery of Glimmerdeep Grotto | 53/58 | 19.9 s |
| 20 | #assign VIT 5 WIL 5 | System (Befehl) | open_run_level | Spend 10 free stat points to survive the dungeon | second gallery of Glimmerdeep Grotto | 53/58 | 2.1 s |
| 21 | I press on through the passage at the back of the chamber, moving deeper into level 1 cautiously, staff ready. | Erzähler | open_run_level | Continue clearing the grotto | old works chamber | 53/58 | 23.2 s |
| 22 | I check the clay jar and the dark-metal pick by the pool before choosing a way onward. | Erzähler | open_run_level | Inspect the old works chamber items | old works chamber | 53/58 | 24.5 s |
| 23 | I pocket the three copper coins and the chalk stub, then take the crevice in the side wall, moving slowly and keeping weight off my bitten l… | Erzähler | open_run_level | Take loot and the safer, quieter crevice route | crystal vein chamber | 53/58 | 18.5 s |
| 24 | I cast Arcane Wave at Mineral Slime A, hoping the burst also catches the second slime beside it. | Erzähler | open_run_level | Engage the two slimes with AoE | crystal vein chamber | 42/44 | 17.0 s |
| 25 | I finish Mineral Slime A with an Arcane Bolt, then strike Mineral Slime B with a Basic Attack if it's still standing. | Erzähler | open_run_level | Finish both wounded slimes efficiently, saving MP | crystal vein chamber | 37/34 | 14.4 s |
| 26 | I strike Mineral Slime B with a Basic Attack. | Erzähler | open_run_level | Finish the last slime with a cheap basic attack | crystal vein chamber | 37/34 | 14.5 s |
| 27 | I follow the crystal thread out through the far wall, moving cautiously deeper into level 1 with my staff ready and weight off my bad leg. | Erzähler | open_run_level | Continue clearing the grotto | queen's crystal chapel | 37/34 | 18.8 s |
| 28 | I back out of the queen's chamber slowly, staff raised, and retreat toward the grotto entrance without turning my back on her. | Erzähler | open_run_level | Withdraw to recover before facing the boss | entrance grotto | 37/34 | 24.4 s |
| 29 | I leave the grotto and walk back to Hollowbrook to rest and recover before facing the queen. | Erzähler | open_run_level | Withdraw to town, recover HP/MP | Hollowbrook | 37/34 | 19.0 s |
| 30 | I go to the village healer's door and knock, asking them to treat my badly wounded leg. | Erzähler | open_run_level | Get the leg properly treated before resting | village healer's house | 37/34 | 23.5 s |
| 31 | I accept both — the wound treatment and the pinch of poppy — and hand over nine coppers. | Erzähler | open_run_level | Pay for healing and sleep aid | village healer's house | 37/34 | 15.9 s |
| 32 | I ask the healer whether the Glimmerdeep queen's poison or rot might need more than paste before I head back down. | Erzähler | open_run_level | Get advice before re-entering the grotto | village healer's house | 37/34 | 20.9 s |
| 33 | I thank the healer, head to the inn, order some food and a bed for the night, and eat before the poppy takes hold. | Erzähler | open_run_level | Eat and secure lodging, then sleep to recover | village inn | 37/34 | 36.4 s |
| 34 | I take the stew and bread and the bed for the night from the innkeeper, pay five coppers, eat, then sleep until morning. | Erzähler | open_run_level | Buy meal and lodging, then sleep to recover | village inn | 125/140 | 18.2 s |
| 35 | I eat the porridge for a copper, hand back the tally-slate, and set out for the Glimmerdeep Grotto to finish clearing it. | Erzähler | open_run_level | Breakfast, then return to the grotto to finish the contract | Glimmerdeep Grotto | 125/140 | 26.5 s |
| 36 | I take the left passage toward the crystal columns, readying Arcane Bolt and moving carefully toward the Glimmer Queen's chamber. | Erzähler | open_run_level | Hunt the Glimmer Queen to finish clearing the contract | Glimmerdeep Grotto | 125/140 | 15.7 s |
| 37 | I take the left passage toward the crystal columns, moving carefully toward the Glimmer Queen's chamber with Arcane Bolt ready. | Erzähler | open_run_level | Hunt the Glimmer Queen to finish clearing the contract | crystal vein chamber | 125/140 | 21.0 s |
| 38 | I fire Arcane Bolt at the resting Glimmer Queen from the chamber mouth, then back away toward the crevice to keep distance. | Engine (Menü/Rückfrage) | open_run_level | Open the boss fight at range and retreat to a defensible chokepoint | crystal vein chamber | 125/140 | 4.8 s |
| 39 | I announce an attack on the Glimmer Queen and fire Arcane Bolt at her, then retreat toward the crevice. | Engine (Menü/Rückfrage) | open_run_level | Start the boss fight with a valid target declaration | crystal vein chamber | 125/140 | 5.1 s |
| 40 | I step into the crystal vein chamber and approach the vein-cluster, then fire Arcane Bolt at the Glimmer Queen. | Engine (Menü/Rückfrage) | open_run_level | Close distance so the Queen becomes a targetable actor, then attack | crystal vein chamber | 125/140 | 8.5 s |
| 41 | I check the queen's crystal chapel for a way to draw her out, listening at the exit for movement. | Erzähler | open_run_level | Find a way to make the Glimmer Queen a targetable actor | queen's crystal chapel | 125/140 | 19.6 s |
| 42 | I move from the crystal chapel into the crystal vein chamber and approach the resting queen. | Erzähler | open_run_level | Complete pending arrival so the Queen becomes targetable | crystal vein chamber | 125/140 | 26.5 s |
| 43 | I fire Arcane Bolt at the Glimmer Queen, then back toward the columns to keep my distance. | Erzähler | open_run_level | Attack the Queen now that I am in her chamber | crystal vein chamber | 125/130 | 17.4 s |
| 44 | I fire Arcane Bolt at the Glimmer Queen, then retreat further into the columns to keep her at range. | Erzähler | open_run_level | Continue ranged attack while kiting | crystal vein chamber | 125/120 | 15.3 s |
| 45 | I fire Arcane Bolt at the Glimmer Queen, then back away toward the crevice exit to keep my distance. | Erzähler | open_run_level | Finish the wounded queen at range | crystal vein chamber | 125/110 | 18.3 s |
| 46 | #assign INT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up stat points | crystal vein chamber | 125/110 | 2.2 s |
| 47 | I head back through the narrow crevice and the entrance grotto to leave the grotto, then travel to the Guild hall to turn in the Clear Glimm… | Erzähler | open_run_level | Turn in the cleared dungeon contract at the Guild | Adventurers' Guild hall, Glassmere | 125/110 | 21.2 s |
| 48 | I ask the clerk to make me an offer on my surplus loot — the beetle chitin plates, venom glands, slime gel and slime core — and then show me… | Erzähler | open_run_level | Sell surplus loot and pick a new Guild contract | Adventurers' Guild hall, Glassmere | 125/110 | 46.2 s |
| 49 | I accept the whole offer — the plates, glands, gel and the slime core — and take the coin. Then I ask the clerk to accept the Gray Wolves co… | Erzähler | open_run_level | Sell all surplus loot and take the wolf hunt contract | Adventurers' Guild hall, Glassmere | 125/110 | 22.7 s |
| 50 | I check the Guild's primer shelf and ask the clerk which primer he'd recommend for a working battle mage, then travel west toward the Foxfir… | Erzähler | open_run_level | Consider a cheap skill primer, then head out on the wolf contract | Adventurers' Guild hall, Glassmere | 125/110 | 23.3 s |
| 51 | I cast Arcane Wave at the three wolves in the dip, then fall back up the slope to keep them from closing on me together. | Erzähler | open_run_level | Open the wolf fight with AoE at range | Adventurers' Guild hall, Glassmere | 125/96 | 18.3 s |
| 52 | I walk on toward the kilns and ask the charburners where the wolves have been coming from, saying I've already taken three and need one more… | Erzähler | open_run_level | Find the fourth wolf via the charburners | the Foxfire Grove kilns | 125/96 | 25.8 s |
| 53 | I take the charburners up on the spot by their fire and wait there until dusk, ready to meet the wolves at the treeline when they come. | Erzähler | open_run_level | Wait for dusk ambush at the kiln camp | the Foxfire Grove kilns | 125/96 | 33.3 s |
| 54 | I cast Arcane Wave at the three wolves at the treeline, then step back toward the campfire. | Erzähler | open_run_level | Strike the dusk wolves at range before they flee | the Foxfire Grove kilns | 125/82 | 26.2 s |
| 55 | I cast Arcane Wave at the three wolves at SHORT, then hold my ground by the fire. | Erzähler | open_run_level | Finish all three wolves with one AoE before they can bite | the Foxfire Grove kilns | 125/68 | 23.0 s |
| 56 | I lower my staff and keep my distance, saying to Wat and Hesta: "The wave doesn't choose its targets once it leaves the staff — I'm sorry. L… | Erzähler | open_run_level | Defuse hostility, offer aid, plan to complete contract | the Foxfire Grove kilns | 125/68 | 20.3 s |
| 57 | I spend the evening skinning the three wolves by the fire, then settle near the camp lamp on watch, ready to meet the last wolf if the wind … | Erzähler | open_run_level | Skin loot and wait for the fourth wolf | the Foxfire Grove kilns | 125/68 | 26.6 s |
| 58 | I stand slowly, keeping the fire between us, and cast Arcane Bolt at the young wolf at MEDIUM. | Erzähler | open_run_level | Kill the fourth wolf at range | the Foxfire Grove kilns | 111/58 | 20.0 s |
| 59 | I strike the wolf's head with my staff to finish it, then pull free. | Erzähler | open_run_level | Finish the fourth wolf | the Foxfire Grove kilns | 111/58 | 22.5 s |
| 60 | I let Hesta sew the bite wound with the needle and waxed thread, then rest by the fire until morning before heading back to the Guild hall i… | Erzähler | open_run_level | Treat wound, recover overnight, then turn in 4/4 contract | Adventurers' Guild hall, Asterhall | 135/196 | 33.9 s |
| 61 | #assign INT 3 WIL 4 VIT 3 | System (Befehl) | open_run_level | Spend the 5 free stat points from the level-up | Adventurers' Guild hall, Asterhall | 135/196 | 2.5 s |
| 62 | I ask the clerk what contracts the board has for a Novice mage, and whether the Guild buys pelts and fangs. | Erzähler | open_run_level | Check new contracts and sell surplus loot | Adventurers' Guild hall, Asterhall | 135/196 | 31.3 s |
| 63 | I ask the clerk to accept the Thin the Striders at the Lower Weirs contract for me. | Erzähler | open_run_level | Take the strider-thinning contract | Adventurers' Guild hall, Asterhall | 135/196 | 17.1 s |
| 64 | I take the slip and carry the seven pelts and eight fangs to the materials counter to ask the buyer's offer. | Erzähler | open_run_level | Sell surplus wolf loot at the Guild materials counter | Adventurers' Guild hall, Asterhall | 135/196 | 20.1 s |
| 65 | I accept the offer and hand over all seven pelts and all eight fangs for the sixty-two copper. | Erzähler | open_run_level | Sell surplus wolf loot at the agreed Guild price | Adventurers' Guild hall, Asterhall | 135/196 | 31.4 s |
| 66 | I set out along the river road through the east gate toward the Lower Weirs, and on arrival look for Warden Ostreth's tollhouse at the first… | Erzähler | open_run_level | Travel to the Lower Weirs for the strider contract | the tollhouse at the first channel crossing | 135/196 | 30.8 s |
| 67 | "Fair trade, Warden. Pole me down to the beds below the third weir and I'll strike from the skiff — the sound plates are yours." | Erzähler | open_run_level | Accept the ferry-for-plates deal and hunt the striders from the boat | the reed beds below the lower eel-weirs of the Reed Flats | 135/196 | 31.2 s |
| 68 | I cast Arcane Bolt at the visible bog strider's carapace, keeping low in the skiff. | Erzähler | open_run_level | Start the strider hunt from the boat | the reed beds below the lower eel-weirs of the Reed Flats | 135/186 | 20.1 s |
| 69 | "Drift on quiet, Warden. I'll hold the bolt until something shows itself — point out movement and I'll strike from the skiff." | Erzähler | open_run_level | Hunt the wary striders stealthily from the boat | the reed beds below the lower eel-weirs of the Reed Flats | 135/186 | 26.0 s |
| 70 | I cast Arcane Bolt at the ambush-hunting strider left of the bow. | Erzähler | open_run_level | Defeat second strider with first strike | the reed beds below the lower eel-weirs of the Reed Flats | 135/176 | 22.5 s |
| 71 | "We drift on to the weir pools, Warden. Point out the last one and I'll strike from the skiff." | Erzähler | open_run_level | Continue the hunt to the weir pools for the third strider | the weir pools above the third weir | 135/176 | 26.5 s |
| 72 | I cast Arcane Bolt at the strider in the reed raft off the buoy, before it can turn. | Erzähler | open_run_level | Strike the third strider from the skiff | the weir pools above the third weir | 135/166 | 25.9 s |
| 73 | "Back to the station landing, Warden — the hunt's done and I'll turn these in at the Guild before dark." | Erzähler | open_run_level | Return to town to turn in the completed strider contract | the eel station landing | 135/166 | 28.3 s |
| 74 | I step off onto the landing, thank Ostreth, and check my pouch with #bag before setting off toward town. | Erzähler | open_run_level | Verify carried plates, then return to town for turn-in | the eel station landing | 135/166 | 28.3 s |
| 75 | I offer to help the carter and cast Arcane Bolt at the sunken wheel's rim, aiming to blast the mud loose and free it. | Erzähler | open_run_level | Help free the stuck cart, then continue to Glassmere | the eel station landing | 135/156 | 19.0 s |
| 76 | I grab the rail and haul alongside the family while they lever the axle free. | Erzähler | open_run_level | Help free the cart by muscle, not magic | the eel station landing | 135/156 | 21.3 s |
| 77 | I accept the two dressed chickens with thanks and walk on through the east gate to the Glassmere Guildhall to turn in the strider contract. | Erzähler | open_run_level | Take gift, reach Glassmere Guildhall for turn-in | Adventurers' Guild hall, Glassmere | 135/156 | 30.1 s |
| 78 | "Yes — what Novice contracts are on the board? And I'll sell five strider plates and seven wolf pelts afterward, so point me to the chitin b… | Erzähler | open_run_level | Ask for new contracts and chitin buyer location | Adventurers' Guild hall, Glassmere | 135/156 | 40.0 s |
| 79 | "Selling — five F-rank bog strider chitin plates. What's your price for the lot?" | Erzähler | open_run_level | Sell chitin plates at Harrow's | Adventurers' Guild hall, Glassmere | 135/156 | 21.1 s |
| 80 | "Selling — five F-rank bog strider chitin plates. What's your price for the lot?" | Erzähler | open_run_level | Sell chitin plates at Harrow's | Adventurers' Guild hall, Glassmere | 135/156 | 16.2 s |
| 81 | I walk out of the Guild hall to Harrow's shop, two doors off the square south side, horseshoe over the door. Once inside in front of Harrow,… | Erzähler | open_run_level | Reach Harrow's shop, then sell the chitin plates there | chitin buyer two doors off the square | 135/156 | 20.5 s |
| 82 | I lay the five F-rank bog strider chitin plates on the trestle before Harrow and tell him plainly: five bog strider chitin plates, F-rank — … | Erzähler | open_run_level | Sell the chitin plates to Harrow by placing them on the scale first | chitin buyer two doors off the square | 135/156 | 16.4 s |
| 83 | "Deal — sixteen silver the lot. Weigh them." I also lay my seven gray wolf pelts on the trestle and ask his price for those too. | Erzähler | open_run_level | Accept confirmed offer and offer pelts to same merchant | chitin buyer two doors off the square | 135/156 | 20.3 s |
| 84 | "Three silver each works — twenty-one the lot, sold." I also offer the eight gray wolf fangs and the bog strider venom gland for sale and as… | Erzähler | open_run_level | Sell pelts and remaining loot to Harrow | chitin buyer two doors off the square | 135/156 | 23.7 s |
| 85 | "Sold — eight silver for the fangs and two gold for the gland, sealed as-is." I hand over the venom gland and fangs to Harrow. | Erzähler | open_run_level | Sell fangs and venom gland to Harrow | chitin buyer two doors off the square | 135/156 | 16.6 s |
| 86 | "One more lot, Harrow." I lay the two crystal beetle queen chitin plates and the crystal beetle queen venom gland on the trestle and ask his… | Erzähler | open_run_level | Sell remaining beetle queen loot to Harrow | chitin buyer two doors off the square | 135/156 | 17.1 s |
| 87 | "Sixteen and a gold five — sold, sealed as-is." I hand over the two queen plates and the queen venom gland to Harrow. | Erzähler | open_run_level | Sell the queen chitin plates and venom gland at Harrow's confirmed offer | chitin buyer two doors off the square | 135/156 | 26.3 s |
| 88 | #bag | System (Befehl) | open_run_level | Verify the queen plate and gland sale actually recorded, since the HUD still lists them as… | chitin buyer two doors off the square | 135/156 | 2.7 s |
| 89 | Harrow, the coin never landed — my bag still shows the two queen plates and the gland. I set them on the trestle again and ask you to comple… | Erzähler | open_run_level | Re-complete the queen loot sale that did not record | chitin buyer two doors off the square | 135/156 | 18.7 s |
| 90 | "Sixteen and a gold five — sold, sealed as-is." I hand over the two queen plates and the venom gland to Harrow and take the coin. |  | open_run_level | Re-complete the queen loot sale at Harrow's confirmed offer | chitin buyer two doors off the square | 135/156 | 13.3 s |
| 91 | I sell Harrow 2 F-Rank Crystal Beetle Queen Chitin Plates and 1 F-Rank Crystal Beetle Queen Venom Gland for the agreed price of 16 silver an… |  | open_run_level | Complete the queen loot sale with explicit item names and price | chitin buyer two doors off the square | 135/156 | 8.9 s |
| 92 | I accept Harrow's offer and sell him my 2 queen chitin plates and 1 venom gland. | Erzähler | open_run_level | Complete the queen loot sale with accepted-offer phrasing | chitin buyer two doors off the square | 135/156 | 19.3 s |
| 93 | #bag | System (Befehl) | open_run_level | Verify whether the queen loot sale finally recorded in inventory and coin | chitin buyer two doors off the square | 135/156 | 2.6 s |
| 94 | I leave Harrow's stall and head to the Glassmere Guild hall to look at the contract board. | Erzähler | open_run_level | Give up on the unrecorded queen loot sale after three failures and seek new Guild contract… | Adventurers' Guild hall, Glassmere | 135/156 | 17.2 s |
| 95 | I take the Gray Wolves by the Foxfire Kilns contract slip to the clerk and ask to have it registered as active. | Erzähler | open_run_level | Accept the gray wolf cull contract | Adventurers' Guild hall, Glassmere | 135/156 | 21.4 s |
| 96 | I head east up the cart road toward the Foxfire Grove kilns and watch for gray wolves along the way. | Erzähler | open_run_level | Travel to the wolf cull site | old sand pit on the cart road | 135/156 | 27.5 s |
| 97 | I cast Arcane Bolt at Gray Wolf H. | Erzähler | open_run_level | Open the wolf fight at range | old sand pit on the cart road | 135/146 | 31.1 s |
| 98 | I continue up the cart road toward the Foxfire kilns, watching the treeline for the other wolves. | Erzähler | open_run_level | Travel toward the kilns and hunt the remaining wolves | the cart road by the Foxfire Grove kilns | 135/146 | 27.7 s |
| 99 | "Yes, alone. I'm here about the wolves — I've killed one so far. Have you had trouble with them near the kilns?" | Erzähler | open_run_level | Talk to the burner about the wolves for the cull contract | the cart road by the Foxfire Grove kilns | 135/146 | 24.6 s |
| 100 | I walk over to the wood pile and speak to Tam: "Your man says you'd stand me supper and a spot by the hut fire if I keep watch over the yard… | Erzähler | open_run_level | Stay at the kilns overnight to hunt wolves at dusk and rest by the fire | the cart road by the Foxfire Grove kilns | 135/146 | 26.5 s |
| 101 | I step inside the hut, greet the woman, and accept a bowl of the stew, then settle by the fire where I can watch the north slope through the… | Erzähler | open_run_level | Eat, rest by the fire, and wait for dusk wolves | inside the burner's hut | 135/146 | 27.5 s |
| 102 | I take the offered bowl and eat the stew, keeping an eye on the darkening north slope through the open flap. | Erzähler | open_run_level | Eat and watch for dusk wolves | inside the burner's hut | 135/146 | 20.5 s |
| 103 | I step quietly out of the hut into the yard, staff ready, and scan the north slope for movement. | Erzähler | open_run_level | Spot the wolf before it reaches the yard | inside the burner's hut | 135/146 | 15.7 s |
| 104 | I stay at the edge of the firelight with staff ready, keeping watch on the yard and slope, and wait for another sound or movement before goi… | Erzähler | open_run_level | Hold position and wait for the wolf to show itself | inside the burner's hut | 135/146 | 23.7 s |
| 105 | I cast Arcane Wave at the two wolves at the tree line before they can close the distance. | Erzähler | open_run_level | Hit both wolves with AoE while they are still grouped at range | inside the burner's hut | 135/132 | 18.8 s |
| 106 | #assign WIL 3 INT 2 | System (Befehl) | open_run_level | Spend level-up points, then keep watch for the remaining two wolves | inside the burner's hut | 135/132 | 2.7 s |
| 107 | I go check the two wolf bodies at the rock scar, then return to the yard's firelight edge and keep watching the slope for the remaining two … | Erzähler | open_run_level | Confirm kills, keep watch for wolves 3 and 4 | the yard's firelight edge | 135/132 | 24.3 s |
| 108 | With two wolves still out there and night deepening, I settle by the kiln fire and sleep until morning, staff within reach, then hunt the la… | Erzähler | open_run_level | Rest overnight, then finish the 2/4 wolf contract at dawn | the yard's firelight edge | 160/288 | 18.1 s |
| 109 | I climb the north slope toward the tree line with staff ready, watching the pines for the last two wolves. | Erzähler | open_run_level | Hunt the remaining two wolves at dawn | the tree line on the north slope | 160/288 | 21.4 s |
| 110 | I follow the fresh prints toward the dark fold, keeping to open ground where I can, and stop short of the gap between the outcrops to listen… | Erzähler | open_run_level | Track the last two wolves into the fold cautiously | the tree line on the north slope | 160/288 | 25.1 s |
| 111 | I stay on the open grass and cast Arcane Wave into the hollow under the overhang, then step back up the slope and keep my eyes on the gap an… | Engine (Menü/Rückfrage) | open_run_level | Draw out or kill the wolf in the hollow with AoE from range while watching for the second | the tree line on the north slope | 160/288 | 8.9 s |
| 112 | I step to the gap between the outcrops and look into the hollow under the overhang to find the wolf, then cast Arcane Wave at it. | Erzähler | open_run_level | Get a valid target and attack the wolf in the hollow | the tree line on the north slope | 160/288 | 28.2 s |
| 113 | I cast Arcane Wave at the Gray Wolf lying in the den's doorway, staying on the open grass. | Erzähler | open_run_level | Attack the visible wolf from range | the tree line on the north slope | 140/274 | 17.2 s |
| 114 | I strike the wounded wolf with my staff (Basic Attack) to finish it. | Erzähler | open_run_level | Kill the Gray Wolf at 5 HP with Basic Attack | the tree line on the north slope | 140/274 | 14.4 s |
| 115 | I check #quests to see the exact wolf count remaining. | Erzähler | open_run_level | Verify contract progress before hunting further | the tree line on the north slope | 140/274 | 13.9 s |
| 116 | I head back along the fresh trail toward the kilns road and search for the fourth wolf, staying cautious and listening as I go. | Erzähler | open_run_level | Hunt the last wolf toward the kiln road | the cart road by the Foxfire Grove kilns | 140/274 | 18.4 s |
| 117 | I follow the fresh tracks west along the road toward the kilns, keeping my distance from the brush and watching ahead. | Erzähler | open_run_level | Hunt the fourth wolf along the road | the cart road by the Foxfire Grove kilns | 140/274 | 20.8 s |
| 118 | I cast Arcane Wave at the wolf as it leaps from the wall. | Erzähler | open_run_level | Attack the fourth wolf with AoE before it closes | the cart road by the Foxfire Grove kilns | 140/260 | 23.0 s |
| 119 | I thank the workman and take a seat on the bench by the kiln shed to rest a few minutes, then start back along the road toward the Guild hal… | Erzähler | open_run_level | Rest briefly, then return to town for the turn-in | Adventurers' Guild hall, Glassmere | 140/260 | 24.3 s |
| 120 | I ask the clerk what Novice contracts are on the board today. | Erzähler | open_run_level | Pick a new Guild contract | Adventurers' Guild hall, Glassmere | 140/260 | 51.2 s |
| 121 | "I'll take the Weir Strider contract, the one for the Reed Flats eel-weirs," I tell the clerk. | Erzähler | open_run_level | Accept the Novice bog strider contract | Adventurers' Guild hall, Glassmere | 140/260 | 17.5 s |
| 122 | I buy the Primer of Ward for 80 copper, then head out the south gate and follow the downstream road toward the Reed Flats. | Erzähler | open_run_level | Buy a defensive manual, then travel for the active strider contract | the eel-weirs of the Reed Flats | 140/260 | 23.5 s |
| 123 | "I'll wait for dusk and fight from the bank, not the shallows. Which side of the weirs does it usually come from?" | Erzähler | open_run_level | Learn the strider's approach direction before dusk | the eel-weirs of the Reed Flats | 140/260 | 22.0 s |
| 124 | I cast Arcane Wave at the bog strider from my dry hummock before it notices me. | Erzähler | open_run_level | Open the strider fight with AoE from the bank | the eel-weirs of the Reed Flats | 140/246 | 19.3 s |
| 125 | Night is falling and I'm lightly wounded; I ask the eel woman if I can shelter by her fire until dawn before walking back to Glassmere. | Erzähler | open_run_level | Recover overnight before the return trip | the eel-weirs of the Reed Flats | 140/246 | 39.1 s |
| 126 | I thank Tansel, bandage my wounds with the clean linen, and sleep by the fire until dawn. | Erzähler | open_run_level | Recover overnight before returning to Glassmere | the eel-weirs of the Reed Flats | 160/288 | 17.4 s |
| 127 | I say goodbye to Tansel and take the causeway road back to Glassmere, heading for the Guild hall to turn in the Weir Strider contract. | Erzähler | open_run_level | Return to Glassmere and turn in the completed strider contract | Adventurers' Guild hall, Glassmere | 160/288 | 26.2 s |
| 128 | I ask the clerk what contracts are on the board suitable for a Novice F-rank mage. | Erzähler | open_run_level | Pick the next Guild contract | Adventurers' Guild hall, Glassmere | 160/288 | 40.6 s |
| 129 | I take the Wolves at the Kiln Road contract slip from the board and ask the clerk to accept it. | Erzähler | open_run_level | Accept the 3-wolf Guild contract | Adventurers' Guild hall, Glassmere | 160/288 | 15.0 s |
| 130 | I ask the clerk if the Guild sells any healing supplies or potions suitable for a field trip. | Erzähler | open_run_level | Check for healing supplies before the wolf hunt | Adventurers' Guild hall, Glassmere | 160/288 | 21.4 s |
| 131 | I head to Hessel's shop on Marrowgate Row and ask what he has for wound-salve and mending draughts. | Erzähler | open_run_level | Buy healing supplies before the wolf hunt | Hessel's shop on Marrowgate Row | 160/288 | 22.5 s |
| 132 | I'll take two mending draughts and one wound-salve tin, please. | Erzähler | open_run_level | Buy healing supplies for the wolf hunt | Hessel's shop on Marrowgate Row | 160/288 | 25.3 s |
| 133 | I thank Hessel and head for the Kiln Road to hunt the wolves on the north slope. | Erzähler | open_run_level | Travel to the wolf hunt site | the cart road by the Foxfire Grove kilns | 160/288 | 22.2 s |
| 134 | I tell the kiln man yes, I'm here for the wolves, and ask if he's seen anything else worth knowing before I head up the north slope. | Erzähler | open_run_level | Gather intel from the kiln worker before hunting | the cart road by the Foxfire Grove kilns | 160/288 | 30.9 s |
| 135 | I head up the north slope, circling wide so I come at the tree line from above the fold and keep the downhill wind from carrying my scent. | Erzähler | open_run_level | Approach the wolf den from upwind | the height of land above the fold | 160/288 | 22.6 s |
| 136 | I open the fight with Arcane Wave, targeting both wolves holding the high ground above the fold. | Erzähler | open_run_level | Engage the two wolves with AoE since both are present | the height of land above the fold | 160/288 | 19.4 s |
| 137 | I advance down the open slope toward the rocks until the nearer wolf is at MEDIUM range, then cast Arcane Wave at both wolves. | Erzähler | open_run_level | Close to spell range and engage with AoE | the height of land above the fold | 150/274 | 17.5 s |
| 138 | I finish the wounded wolf with a Basic Attack at Gray Wolf N. | Erzähler | open_run_level | Kill the near-death wolf before the big one closes | the height of land above the fold | 137/274 | 17.2 s |
| 139 | I Basic Attack Gray Wolf O, striking at its head while it has me pinned. | Erzähler | open_run_level | Kill the last wolf | the height of land above the fold | 124/274 | 27.0 s |
| 140 | I finish Gray Wolf O with another Basic Attack at its head. | Erzähler | open_run_level | Kill the wounded wolf | the height of land above the fold | 124/274 | 16.4 s |
| 141 | I assign my five free stat points, then make my way down the slope toward the voice calling from the fold. | Erzähler | open_run_level | Spend level-up points and investigate the caller | the height of land above the fold | 124/274 | 26.3 s |
| 142 | #assign INT 2 WIL 3 | System (Befehl) | open_run_level | Spend free stat points | the height of land above the fold | 124/274 | 2.7 s |
| 143 | I move to put myself between the wolf and the boy, then cast Arcane Wave at the wolf from ten paces. | Engine (Menü/Rückfrage) | open_run_level | Protect the boy and kill the third wolf | the height of land above the fold | 124/274 | 5.2 s |
| 144 | I step toward the wolf, staff raised, and cast Arcane Bolt at it. | Engine (Menü/Rückfrage) | open_run_level | Engage the third wolf directly | the height of land above the fold | 124/274 | 4.6 s |
| 145 | I descend the slope toward the fold, following the caller's voice, and look for the third wolf there. | Erzähler | open_run_level | Reach the fold and engage the third wolf | the height of land above the fold | 124/274 | 24.2 s |
| 146 | I call out to the wolf from the hazel edge and step into the hollow, then cast Arcane Wave at the circling wolf. | Erzähler | open_run_level | Engage the third wolf now that the scene is active | the hollow under the overhang | 124/274 | 29.1 s |
| 147 | I hold my ground and cast Arcane Wave at the wolf. | Erzähler | open_run_level | Kill the third wolf now that the scene is active | the hollow under the overhang | 124/260 | 19.6 s |
| 148 | I lower my staff and keep my distance. "Easy — I'm here about the wolves. You're hurt; let me look at that arm." | Erzähler | open_run_level | Calm the boy and check his injury | the hollow under the overhang | 124/260 | 17.7 s |
| 149 | "Yes, I'm the Guild man. All three wolves are dead — you're safe. Can you walk? I'll help you back up to Tam and the others, and we'll get t… | Erzähler | open_run_level | Reassure the boy, confirm the contract is done, and get him back to the fold for his injur… | the hollow under the overhang | 124/260 | 21.8 s |
| 150 | I help Dane the rest of the way to the fold and settle him by the fire. "All three wolves are dead — the flock and the fold are safe. Let me… | Erzähler | open_run_level | Deliver the boy to the fold, confirm the contract is complete, and prepare to turn it in | the hollow under the overhang | 124/260 | 27.9 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 2 (notiert vor Zug 3): Creation complete: Level 1 Mage with Arcane Wave and Arcane Bolt, starter gear equipped, 5 silver.
- zu Zug 4 (notiert vor Zug 5): Registration cost 2 silver as narrated; coin now 3 silver with Guild plate received.
- zu Zug 9 (notiert vor Zug 10): Ambush crit one-shot the strider; quest shows 1/1 and READY for turn-in.
- zu Zug 17 (notiert vor Zug 18): Arcane Wave requires a single named target even for the area effect; group-targeting was refused twice.
- zu Zug 22 (notiert vor Zug 23): HP 53/125 and bleeding; no healing supplies carried. Skittering threat lies through the back opening, so I avoid it.
- zu Zug 26 (notiert vor Zug 27): All 6 known level-1 threats defeated, but quest not cleared yet — possibly more threats or an objective point deeper in. HP 37/125, no healing supplies.
- zu Zug 27 (notiert vor Zug 28): Queen HP 108 vs my HP 37 and MP 34 — fighting now would be reckless; will return rested and prepared.
- zu Zug 38 (notiert vor Zug 39): System refused 'the resting Glimmer Queen' as target; HUD says she is present as a threat, so I name her directly.
- zu Zug 39 (notiert vor Zug 40): System twice refused 'Glimmer Queen' as target despite HUD listing her as a present threat; possibly she must be engaged at closer range or the scene needs an update.
- zu Zug 40 (notiert vor Zug 41): System refuses 'Glimmer Queen' as target three times while HUD lists her as a present threat; possibly she must be provoked via a different scene object or the fight requires entering the queen's crystal chapel.
- zu Zug 41 (notiert vor Zug 42): HUD shows my location as queen's crystal chapel while the Queen is in the crystal vein chamber; previous refusals were likely arrival-pending, not target-name issues.
- zu Zug 43 (notiert vor Zug 44): Ambush crit for 56 put the Queen at 52/108; she closes to MEDIUM each round, so I must keep backing off after each cast.
- zu Zug 45 (notiert vor Zug 46): Glimmer Queen defeated; quest ready for turn-in; leveled to 4.
- zu Zug 50 (notiert vor Zug 51): HUD still lists location as Guild hall while the scene is the west road; wolves present at the dip.
- zu Zug 53 (notiert vor Zug 54): Contract slip still shows 0/4 despite three earlier wolf kills — the counting may only register on turn-in.
- zu Zug 55 (notiert vor Zug 56): Friendly fire hit Hesta and Wat; quest counter now 3/4 — one more wolf needed, likely at the den in the north grove.
- zu Zug 61 (notiert vor Zug 62): Stat assignment confirmed; HP/MP not refilled by assignment, still full from recovery. Wat offered a pelt price at the kiln camp but a city sale may be simpler.
- zu Zug 68 (notiert vor Zug 69): Arcane Bolt one-shot the strider (52 dmg); count 1/3. HUD shows 3 plates carried though only 1 looted this fight — will verify with #bag before turn-in.
- zu Zug 72 (notiert vor Zug 73): HUD shows 5 chitin plates carried though 4 looted this hunt (3 striders) plus 1 earlier — will verify with #bag before turn-in and selling surplus.
- zu Zug 73 (notiert vor Zug 74): HUD shows 5 chitin plates though hunt loot was 4; checking #bag before selling surplus.
- zu Zug 74 (notiert vor Zug 75): Bag confirms 5 strider plates and slip READY — 3/3, ready for turn-in. Time anomaly: HUD says Day 4 13:40 midday though narration said half a day's walk and near sundown.
- zu Zug 79 (notiert vor Zug 80): Previous sell attempt failed because I was still in the Guildhall; now actually at Harrow's.
- zu Zug 80 (notiert vor Zug 81): Engine twice rejected the sell because I was still in the Guild hall despite narration describing me at Harrow's; HUD location is authoritative.
- zu Zug 81 (notiert vor Zug 82): Sell attempts keep failing on technicalities (location, arrival pending); engine seems to require explicit placement of goods on the trestle before pricing.
- zu Zug 87 (notiert vor Zug 88): Narrator confirms sale but no ENGINE RESULT appeared; HUD still shows queen items in Carried.
- zu Zug 88 (notiert vor Zug 89): Narrator confirmed the sale and coin count, but no ENGINE RESULT appeared and #bag still lists the queen items and the old coin total.
- zu Zug 89 (notiert vor Zug 90): Sale has now been confirmed twice by narration but neither #bag nor the HUD recorded it; will verify with #bag again.
- zu Zug 90 (notiert vor Zug 91): Engine refused the vague handover phrasing; retrying with named items and quantities.
- zu Zug 91 (notiert vor Zug 92): Engine twice refused sale phrasing despite confirmed offer; trying 'accept the offer' wording.
- zu Zug 92 (notiert vor Zug 93): HUD coin and carried items unchanged again despite third narration of the sale; checking #bag once before moving on.
- zu Zug 93 (notiert vor Zug 94): Queen loot sale narrated three times but never recorded in #bag or coin; treating it as a persistent engine blockage and moving on.
- zu Zug 94 (notiert vor Zug 95): Queen loot sale still never recorded in #bag despite three narrations; abandoning it. Harrow also mentioned paying for bog strider legs by the pair.
- zu Zug 95 (notiert vor Zug 96): Contract confirmed ACTIVE 0/4 in the quest panel. Still carrying the two dressed chickens and queen loot.
- zu Zug 97 (notiert vor Zug 98): First wolf defeated instantly by Arcane Bolt (60 dmg); other two wolves fled uphill rather than fight.
- zu Zug 100 (notiert vor Zug 101): Contract still shows 0/4 despite a narrated wolf kill on the road; watching whether the count updates on confirmed kills only.
- zu Zug 107 (notiert vor Zug 108): Engine refused 'keep watching' as arrival-pending; contract count confirmed 2/4.
- zu Zug 114 (notiert vor Zug 115): HUD goal said two wolves left but quest panel shows 3/4 defeated — one remaining, not two.
- zu Zug 115 (notiert vor Zug 116): Quest confirmed 3/4; HUD goal still says 'last two' — stale HUD text.
- zu Zug 116 (notiert vor Zug 117): HUD goal still stale ('last two', north slope); quest panel is authoritative at 3/4.
- zu Zug 118 (notiert vor Zug 119): Contract slip shows READY at 4/4; stale HUD goal text persists ('last two').
- zu Zug 119 (notiert vor Zug 120): Quest completed and paid out (12g 3s 2c); stale HUD goal still shows 'last two wolves'.
- zu Zug 120 (notiert vor Zug 121): Board repeats a wolf pack contract identical to the one just completed; will avoid re-taking it.
- zu Zug 121 (notiert vor Zug 122): HUD goal still stale ('last two wolves'); quest panel authoritative at 0/1 strider.
- zu Zug 124 (notiert vor Zug 125): HUD goals text still stale ('last two wolves'); quest panel authoritative at 1/1.
- zu Zug 132 (notiert vor Zug 133): Purchase completed despite 'no open offer' notice on the salve; both draughts and tin are in inventory, so no issue.
- zu Zug 140 (notiert vor Zug 141): Level 8 confirmed, 5 free points; quest shows 2/3 wolves defeated though I killed two this morning — possibly one was counted earlier.
- zu Zug 143 (notiert vor Zug 144): Arcane Wave refused: 'no targetable actor in active scene' — combat may not be initiated from range here; trying a direct attack to open the scene.
- zu Zug 146 (notiert vor Zug 147): Scene finally active after stepping into the hollow and shouting; wolf HP 46/46.
- zu Zug 147 (notiert vor Zug 148): Arcane Wave friendly-fire hit the boy for 47; wolf contract shows 3/3 defeated — quest complete pending turn-in.
- zu Zug 148 (notiert vor Zug 149): Friendly fire from Arcane Wave hit the boy for 47; wolf contract shows 3/3 defeated, pending turn-in at the Guild hall.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t9 | 9 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t16 | 18 | 4 | – | nein | 4 | gewonnen, 336 XP |
| enc.t21 | 24 | 2 | – | nein | 2 | gewonnen, 120 XP |
| enc.t37 | 43 | 1 | – | nein | 1 | gewonnen, 300 XP |
| enc.t44 | 51 | 3 | – | nein | 3 | gewonnen, 72 XP |
| enc.t47 | 54 | 3 | – | nein | 3 | gewonnen, 360 XP |
| enc.t51 | 58 | 1 | – | nein | 1 | gewonnen, 144 XP |
| enc.t60 | 68 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t62 | 70 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t64 | 72 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t85 | 97 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t93 | 105 | 2 | – | nein | 2 | gewonnen, 216 XP |
| enc.t99 | 113 | 1 | – | nein | 1 | gewonnen, 96 XP |
| enc.t104 | 118 | 1 | – | nein | 1 | gewonnen, 120 XP |
| enc.t110 | 124 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t123 | 137 | 2 | – | nein | 2 | gewonnen, 240 XP |
| enc.t130 | 147 | 1 | – | nein | 1 | gewonnen, 144 XP |

## Quests

- **Cull the Reed Flats Bog Striders** — active (Zug 5) → completed (Zug 10), READY
  - Aufgabe: Kill 1 bog strider at the eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 bog strider killed at the eel-weirs of the Reed Flats.
- **Thin the Foxfire Grove Wolves** — expired (Zug 48)
  - Aufgabe: Kill 4 gray wolves at the Foxfire Grove kilns. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 gray wolves killed at the Foxfire Grove kilns.
- **Slay the Old Boar of Thornhollow** — expired (Zug 48)
  - Aufgabe: Kill 1 Old Split-Bristle, a giant old boar at the Thornhollow cider orchards. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 Old Split-Bristle, a giant old boar killed at the Thornhollow cider orchards.
- **Destroy the Marsh Wyrm of the Sunken Causeway** — expired (Zug 48)
  - Aufgabe: Kill 1 the Marsh Wyrm, a huge marsh serpent at the Sunken Causeway. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the Marsh Wyrm, a huge marsh serpent killed at the Sunken Causeway.
- **Clear Glimmerdeep Grotto Level 1** — active (Zug 13) → completed (Zug 47), READY, Dungeon loc.glimmerdeep_grotto Ebene 1
  - Aufgabe: Clear level 1 of Glimmerdeep Grotto. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Glimmerdeep Grotto is clear.
- **Slay the Bog Strider at the Reed Flats Eel-Weirs** — expired (Zug 78)
  - Aufgabe: Kill 1 bog strider at the eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 bog strider killed at the eel-weirs of the Reed Flats.
- **Thin the Gray Wolves at the Foxfire Grove Kilns** — active (Zug 49) → completed (Zug 60)
  - Aufgabe: Kill 4 gray wolves at the Foxfire Grove kilns. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 gray wolves killed at the Foxfire Grove kilns.
- **Slay the Giant Boar of Thornhollow Cider Orchards** — expired (Zug 78)
  - Aufgabe: Kill 1 giant boar at the Thornhollow cider orchards. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 giant boar killed at the Thornhollow cider orchards.
- **Kill the Marsh Wyrm on the Sunken Causeway** — expired (Zug 78)
  - Aufgabe: Kill 1 marsh wyrm at the Sunken Causeway. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 marsh wyrm killed at the Sunken Causeway.
- **Clear Glimmerdeep Grotto Level 1** — expired (Zug 78), Dungeon loc.glimmerdeep_grotto Ebene 1
  - Aufgabe: Clear level 1 of Glimmerdeep Grotto. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Glimmerdeep Grotto is clear.
- **Thin the Striders at the Lower Weirs** — active (Zug 63) → completed (Zug 77)
  - Aufgabe: Kill 3 bog striders at the reed beds below the lower eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 bog striders killed at the reed beds below the lower eel-weirs of the Reed Flats.
- **Cull the Bog Striders at the Eel-Weirs** — expired (Zug 120)
  - Aufgabe: Kill 1 bog strider at the eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 bog strider killed at the eel-weirs of the Reed Flats.
- **Thin the Gray Wolves by the Foxfire Kilns** — active (Zug 95) → completed (Zug 119)
  - Aufgabe: Kill 4 gray wolf at the cart road by the Foxfire Grove kilns. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 gray wolf killed at the cart road by the Foxfire Grove kilns.
- **Bring Down the Orchard Boar of Thornhollow** — expired (Zug 120)
  - Aufgabe: Kill 1 giant boar at the Thornhollow cider orchards. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 giant boar killed at the Thornhollow cider orchards.
- **Slay the Marsh Wyrm of the Sunken Causeway** — expired (Zug 120)
  - Aufgabe: Kill 1 marsh wyrm at the Sunken Causeway. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 marsh wyrm killed at the Sunken Causeway.
- **Clear Glimmerdeep Grotto Level 1** — expired (Zug 120), Dungeon loc.glimmerdeep_grotto Ebene 1
  - Aufgabe: Clear level 1 of Glimmerdeep Grotto. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Glimmerdeep Grotto is clear.
- **Slay the Weir Strider** — active (Zug 121) → completed (Zug 127), READY
  - Aufgabe: Kill 1 bog strider at the eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 bog strider killed at the eel-weirs of the Reed Flats.
- **Thin the Foxfire Wolf Pack** — expired (Zug 128)
  - Aufgabe: Kill 4 gray wolves at the Foxfire Grove kilns. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 gray wolves killed at the Foxfire Grove kilns.
- **Take Down the Thornhollow Orchard Boar** — expired (Zug 128)
  - Aufgabe: Kill 1 giant boar at the Thornhollow cider orchards. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 giant boar killed at the Thornhollow cider orchards.
- **Slay the Marsh Wyrm of the Sunken Causeway** — expired (Zug 128)
  - Aufgabe: Kill 1 marsh wyrm at the Sunken Causeway. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 marsh wyrm killed at the Sunken Causeway.
- **Clear Glimmerdeep Grotto, Level 1** — expired (Zug 128), Dungeon loc.glimmerdeep_grotto Ebene 1
  - Aufgabe: Clear level 1 of Glimmerdeep Grotto. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Glimmerdeep Grotto is clear.
- **Wolves at the Kiln Road** — active (Zug 129)
  - Aufgabe: Kill 3 gray wolves at the cart road by the Foxfire Grove kilns. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 gray wolves killed at the cart road by the Foxfire Grove kilns.

## Auffälligkeiten

- Zug 10, Nachricht 20 (extraction_repaired): the extractor's first answer needed a repair
- Zug 22, Nachricht 44 (extraction_repaired): the extractor's first answer needed a repair
- Zug 33, Nachricht 66 (extraction_repaired): the extractor's first answer needed a repair
- Zug 35, Nachricht 69 (planner_repaired): the planner's first answer needed a repair
- Zug 40, Nachricht 79 (planner_repaired): the planner's first answer needed a repair
- Zug 41, Nachricht 82 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (Glimmer Queen): refused, no fight (Patch 8.4.1 guard)
- Zug 42, Nachricht 83 (planner_repaired): the planner's first answer needed a repair
- Zug 42, Nachricht 84 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (Glimmer Queen): refused, no fight (Patch 8.4.1 guard)
- Zug 53, Nachricht 105 (planner_repaired): the planner's first answer needed a repair
- Zug 60, Nachricht 120 (extraction_repaired): the extractor's first answer needed a repair
- Zug 65, Nachricht 129 (planner_repaired): the planner's first answer needed a repair
- Zug 74, Nachricht 148 (extraction_repaired): the extractor's first answer needed a repair
- Zug 77, Nachricht 154 (extraction_repaired): the extractor's first answer needed a repair
- Zug 78, Nachricht 156 (extraction_repaired): the extractor's first answer needed a repair
- Zug 83, Nachricht 165 (planner_repaired): the planner's first answer needed a repair
- Zug 84, Nachricht 167 (planner_repaired): the planner's first answer needed a repair
- Zug 90, Nachricht 179 (planner_failed): the planner failed: sell seq 1: ambiguous price or quantity in this quote. Copy only this item's exact price clause; min_cp is the TOTAL for the selected quantity, not a unit rate.; sell seq 2: ambiguous price or quantit
- Zug 90, Nachricht 179 (planner_repaired): the planner's first answer needed a repair
- Zug 91, Nachricht 181 (planner_failed): the planner failed: commands[0] (sell): quote "sixteen the pair" is not in the message (copy his exact words); commands[1] (sell): quote "a gold five for the sac" is not in the message (copy his exact words); sell seq 2:
- Zug 91, Nachricht 181 (planner_repaired): the planner's first answer needed a repair
- Zug 95, Nachricht 190 (extraction_repaired): the extractor's first answer needed a repair
- Zug 98, Nachricht 196 (extraction_repaired): the extractor's first answer needed a repair
- Zug 107, Nachricht 214 (extraction_repaired): the extractor's first answer needed a repair
- Zug 112, Nachricht 224 (extraction_repaired): the extractor's first answer needed a repair
- Zug 120, Nachricht 240 (extraction_repaired): the extractor's first answer needed a repair
- Zug 125, Nachricht 250 (extraction_repaired): the extractor's first answer needed a repair
- Zug 127, Nachricht 254 (extraction_repaired): the extractor's first answer needed a repair
- Zug 132, Nachricht 264 (extraction_repaired): the extractor's first answer needed a repair
- Zug 134, Nachricht 268 (extraction_repaired): the extractor's first answer needed a repair
- Zug 141, Nachricht 281 (stat_words): the player spent Stat Points in words, not with #assign; nothing was assigned (for review: did the story tell them as done?)
- Zug 146, Nachricht 292 (extraction_repaired): the extractor's first answer needed a repair
- Zug 149, Nachricht 298 (extraction_repaired): the extractor's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 23× keine gültige JSON-Entscheidung (Züge 7, 8, 12, 16, 37, 46, 53, 56, 61, 66, 67, 71, 72, 77, 97, 98, 103, 105, 110, 123, 124, 136, 145)

System-Panels: CLARIFY 0, NOT TAKEN 2, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: guild_canon 4, engine_owned_memory 4, guild_payout 1, ambient 4, group_unclear 5, world_rule 19, engine_owned_fact 20, dungeon_foe 2, quest_count 5, scene_context 33, offer 3, pc_inventory 8, engine_booked 3, sale_evidence 7, guild_completion 1, no_go 4, coin_evidence 1, npc_presence 4, npc_continuity 7, attack_commitment 1, time_cap 1, passage 3.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 23/150 Erstantworten ungültig (15.3 %); 23 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 150 | 9 | 2.8 s | 5.3 s | 12470 | 10001 | 94 | – | stop 150 | 0 |
| board | 8 | 2 | 9.8 s | 11.8 s | 2574 | 2244 | 1125 | – | stop 8 | 0 |
| narrator | 131 | 0 | 8.4 s | 12.4 s | 11532 | 8740 | 399 | – | stop 131 | 0 |
| extract | 149 | 18 | 5.8 s | 8.5 s | 12730 | 9517 | 423 | – | stop 149 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 61:34 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 15.4 s) | 0:30 min |
| 150 Züge, Spiel (Senden bis HUD nach der Extraktion) | 51:03 min — Median 20.3 s, p90 30.1 s, max 51.2 s |
| 150 Züge, Spieler-Entscheidung | 6:52 min — Median 2.2 s, 23 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 8:02 min / 1:15 min / 20:25 min / 15:01 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 23.2 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 15:26 min, 80 Züge ≈ 30:53 min (ohne Einrichtung) |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
