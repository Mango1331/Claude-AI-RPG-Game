# Avereth Live-Test 20261029-112903Z-current_test

## Kurzfassung

- **Laufprofil:** guild-rogue; Startklasse Rogue, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** Niederlage — turn 52: he died
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 1. Sicherheitsgrenzen: 150 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** noch nicht erreicht.
- **Charakter:** rogue (rogue.evasive_step, rogue.fan_of_blades) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: cautious adventurer: prepare and recover, weigh threats and withdraw when sensible
- **Züge:** 52 · **Dauer:** 21:28 min · **LLM-Aufrufe der Engine/des Erzählers:** 153
- **Beobachtete Abdeckung:** 5 unterschiedliche gebuchte Reiseziele · 1 Kämpfe · 0 Verkäufe (0 cp Umsatz, ohne Questzahlungen/Geschenke) · 0 Ausrüstungswechsel · 0 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 16 · **Niederlage** in Zug 52: he died
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.116 |
| Git | 846a7c3ce0be (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 14.7 s |
| Browser | chrome 156.0.8078.49 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261029-112903Z-current_test“, Seed 2120501931 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | Rogue | Engine (Menü/Rückfrage) | creation_complete | Choose Rogue as base class | public roadside verge outside Alderwatch | 90/84 | 2.3 s |
| 2 | I choose Fan of Blades and Evasive Step as my two skills. | Engine (Menü/Rückfrage) | creation_complete | Select the two starter skills | public roadside verge outside Alderwatch | 90/84 | 2.1 s |
| 3 | I walk through the city gate into Alderwatch and head for the Adventurers' Guild hall to look at the contract board. | Erzähler | open_run_level | Enter city and find Guild contracts | Adventurers' Guild hall, Alderwatch | 90/84 | 42.3 s |
| 4 | I approach the clerk and ask: "I'd like to register with the Guild, and I'm looking for contracts a novice could take. What's available befo… | Erzähler | open_run_level | Register with Guild and find starter contracts | Adventurers' Guild hall, Alderwatch | 90/84 | 34.3 s |
| 5 | I slide two silver across the counter and sign the registration slip. | Erzähler | open_run_level | Register with the Guild | Adventurers' Guild hall, Alderwatch | 90/84 | 19.6 s |
| 6 | I ask the clerks: "Put me down as interested in the catacombs culling — where and when does that crew muster? Meanwhile I'll wait for the no… |  | open_run_level | Get details on the catacombs culling work and wait for noon postings | Adventurers' Guild hall, Alderwatch | 90/84 | 31.6 s |
| 7 | I go to the board and read the four remaining postings, then take the one that looks most achievable for a Novice solo. | Erzähler | open_run_level | Read the noon postings and pick a contract | Adventurers' Guild hall, Alderwatch | 90/84 | 44.3 s |
| 8 | I ask the clerk: "Since the board's bare, I'll take the catacombs work — where can I get a room for the night near the west gate so I can ma… | Erzähler | open_run_level | Plan for the catacombs muster tomorrow morning | Adventurers' Guild hall, Alderwatch | 90/84 | 29.6 s |
| 9 | I head to the Crooked Bell and ask Marda for a bed for the night with supper. | Erzähler | open_run_level | Get lodging near west gate before catacombs muster | Crooked Bell | 90/84 | 19.9 s |
| 10 | I take the common floor with supper. "Eight coppers it is, Marda — and I'll want an early start, so keep some stew aside if the crews come i… | Erzähler | open_run_level | Buy lodging at the Crooked Bell | Crooked Bell | 90/84 | 20.5 s |
| 11 | #quests | System (Befehl) | open_run_level | Verify the catacombs contract is actually active before tomorrow's muster | Crooked Bell | 90/84 | 2.1 s |
| 12 | I return to the Guild hall and tell the clerk: "The catacombs culling isn't showing as active on my plate — put me down for it properly, and… | Erzähler | open_run_level | Get the catacombs contract actually registered | Adventurers' Guild hall, Alderwatch | 90/84 | 18.5 s |
| 13 | I tell the clerks: "Then I'll take the Warden's muster — I'll be at the chapel at dawn. Is there anything for a Novice to do before the next… | Erzähler | open_run_level | Sign on for the Warden's catacombs day-work and check for near-term Guild work | Adventurers' Guild hall, Alderwatch | 90/84 | 14.5 s |
| 14 | I return to the Crooked Bell and sleep in the bed I paid for until morning. | Erzähler | open_run_level | Rest overnight before the dawn muster | Crooked Bell | 90/84 | 18.7 s |
| 15 | I eat quickly, grab my gear, and head out with the crews on the muster road west to the ruined chapel. | Erzähler | open_run_level | Travel to the dawn muster at the chapel | Ruined Chapel Camp | 90/84 | 34.8 s |
| 16 | "Alaric Red — Novice plate, Guild of Valedorn. Put me down; I'll go where you put me." | Erzähler | open_run_level | Sign onto the Warden's catacombs day-work | Ruined Chapel Camp | 90/84 | 50.3 s |
| 17 | I take a shovel and basket and start loading rubble into baskets, passing them up the line as Hesta ordered. | Erzähler | open_run_level | Do the assigned day-work on the north stair second shift | Ruined Chapel Camp | 90/84 | 28.7 s |
| 18 | I find the tally guard at his slate and ask for my day-wage — it's dusk, and I'm upright. | Erzähler | open_run_level | Collect the dusk day-wage for the chapel work | Ruined Chapel Camp | 90/84 | 15.8 s |
| 19 | I stay the night at the camp by the cookfire, then claim my line on the tally slate at dawn and head down to the north stair for another shi… | Erzähler | open_run_level | Keep the day-work and stay at camp overnight | Ruined Chapel Camp | 90/84 | 26.6 s |
| 20 | I keep the rhythm — fill, lift, pass — staying alert for anything in the rubble that isn't stone. | Erzähler | open_run_level | Continue the day-work shift as assigned | Ruined Chapel Camp | 90/84 | 20.5 s |
| 21 | I keep my place in the line and wait while Hesta decides how to widen the gap — no touching the corpse, just watch it through the crack in c… | Erzähler | open_run_level | Stay cautious while the crew widens the opening, watching for danger from the corpse | Ruined Chapel Camp | 90/84 | 19.8 s |
| 22 | I keep my place at the watch, eyes on the gap, and quietly ask Hesta whether the surveyor's decision means more paid day-work for us or whet… | Erzähler | open_run_level | Stay cautious on watch and gauge whether to keep the day-work or seek a Guild contract | Ruined Chapel Camp | 90/84 | 22.2 s |
| 23 | I stay through the surveyor's word as Hesta asks, keeping eyes on the gap while the crew waits. | Erzähler | open_run_level | Wait for the surveyor's decision, keep watch on the gap | Ruined Chapel Camp | 90/84 | 27.8 s |
| 24 | I tell Hesta I'll take the afternoon chalk if she still needs hands, but first I head up to the Guild hall to catch the noon postings before… | Erzähler | open_run_level | Claim a Guild contract at the noon board, then decide on afternoon work | Adventurers' Guild hall, Alderwatch | 90/84 | 25.8 s |
| 25 | I ask the clerk whether any Guild work is still posted — even chores or look-and-tell jobs — and if not, I head back up to the dig to put in… | Erzähler | open_run_level | Check for remaining Guild work, otherwise return to the paid chalk work | Adventurers' Guild hall, Alderwatch | 90/84 | 46.6 s |
| 26 | I work the afternoon chalk shift beside the crew, quick with the basket, and ask Hesta to let me off sharp at dusk so I can make the Guild p… | Erzähler | open_run_level | Complete afternoon chalk work, then leave at dusk for the Guild postings | Adventurers' Guild hall, Alderwatch | 90/84 | 33.5 s |
| 27 | I press in near the board as the clerk posts the new slips and look over what goes up. | Erzähler | open_run_level | Read the dusk contract postings | Adventurers' Guild hall, Alderwatch | 90/84 | 26.7 s |
| 28 | I go to the desk and ask the clerk to sign me on to 'Cull the Orchard Striker' — and check whether I can also take 'Thin the Millpond Snappe… | Erzähler | open_run_level | Accept achievable Guild contracts from the dusk board | Adventurers' Guild hall, Alderwatch | 90/84 | 17.4 s |
| 29 | I tell the clerk to write me on for 'Thin the Millpond Snappers' as well, then ask where a traveler can get a cheap bed for the night. | Erzähler | open_run_level | Take second contract, then find lodging | Adventurers' Guild hall, Alderwatch | 90/84 | 17.2 s |
| 30 | I head to the Wheatsheaf by the south gate, take a cot for the night, and sleep until morning. | Erzähler | open_run_level | Get affordable lodging and recover overnight | Wheatsheaf | 90/84 | 23.3 s |
| 31 | I go up to my cot in the loft and sleep through the night until morning. | Erzähler | open_run_level | Recover overnight before contracts | Wheatsheaf | 90/84 | 19.8 s |
| 32 | I buy a bread and cold ham plate for a copper, eat, and head for the weir ponds behind the mills to hunt the snappers. | Erzähler | open_run_level | Eat then start Thin the Millpond Snappers | weir ponds of the Alderwatch mills | 90/84 | 26.9 s |
| 33 | I move along the flat stones toward the snapper sunning in the reeds and strike it with my dagger once it's in reach. | Erzähler | open_run_level | Attack snapper A with Basic Attack | weir ponds of the Alderwatch mills | 90/84 | 19.2 s |
| 34 | I watch the reed bed for the snapper's wake and, when it surfaces or comes within reach of a thrown blade, I use Fan of Blades at it. | Erzähler | open_run_level | Attack snapper A with ranged AoE from the bank | weir ponds of the Alderwatch mills | 90/84 | 17.6 s |
| 35 | I ask the mill hand whether he has a hand line, hook, and a bit of bait I could borrow or buy off him for fishing the snappers. | Erzähler | open_run_level | Get fishing gear to lure snappers into range | weir ponds of the Alderwatch mills | 90/84 | 14.7 s |
| 36 | I buy the big hook and half a smoked herring for two coppers, take the borrowed line and weight, and rig up to fish for the snappers from th… | Engine (Menü/Rückfrage) | open_run_level | Buy tackle and start fishing for snappers | weir ponds of the Alderwatch mills | 90/84 | 8.1 s |
| 37 | offer.t70.6 — I accept the mill hand's offer: the big hook and half a smoked herring for two coppers, and take the borrowed line and weight … | Engine (Menü/Rückfrage) | open_run_level | Confirm the tackle purchase and start fishing for snappers | weir ponds of the Alderwatch mills | 90/84 | 7.1 s |
| 38 | I buy from the mill hand: one big hook and half a smoked herring for 2 copper total. | Engine (Menü/Rückfrage) | open_run_level | Confirm the tackle purchase explicitly | weir ponds of the Alderwatch mills | 90/84 | 7.9 s |
| 39 | I buy the big hook and half a smoked herring from the mill hand for a total of 2 copper. | Engine (Menü/Rückfrage) | open_run_level | Complete tackle purchase | weir ponds of the Alderwatch mills | 90/84 | 8.9 s |
| 40 | offer.t70.6 | Erzähler | open_run_level | Accept the confirmed tackle offer | weir ponds of the Alderwatch mills | 90/84 | 21.9 s |
| 41 | I bait the hook with the herring chunk, cast from the bank, and wait for the line to tighten before setting the hook. | Erzähler | open_run_level | Fish for the snappers | weir ponds of the Alderwatch mills | 90/84 | 21.2 s |
| 42 | "Before you eat — what would you take for the other half of that herring? I'll pay for it." | Erzähler | open_run_level | Buy the bait half back before he eats it | weir ponds of the Alderwatch mills | 90/84 | 13.9 s |
| 43 | I accept: here's one copper for the other half of the herring and the skin strip. | Engine (Menü/Rückfrage) | open_run_level | Buy bait and fish for the snappers | weir ponds of the Alderwatch mills | 90/84 | 6.3 s |
| 44 | offer.t84.7 | Erzähler | open_run_level | Accept the confirmed herring offer | weir ponds of the Alderwatch mills | 90/84 | 18.3 s |
| 45 | I hand the mill hand one copper. | Erzähler | open_run_level | Pay for the bait bundle | weir ponds of the Alderwatch mills | 90/84 | 20.1 s |
| 46 | I hold the copper out to Tam. "One copper for the half and the skin strip, Tam — as we bargained." | Engine (Menü/Rückfrage) | open_run_level | Pay Tam for the bait bundle | weir ponds of the Alderwatch mills | 90/84 | 6.3 s |
| 47 | accept offer.t84.7 | Erzähler | open_run_level | Accept the confirmed offer to pay Tam | weir ponds of the Alderwatch mills | 90/84 | 12.6 s |
| 48 | I rig the herring bait onto the hand line and fish from the shallow reeds, letting the first snapper run before setting the hook. | Erzähler | open_run_level | Fish for the millpond snappers at the weir ponds | weir ponds of the Alderwatch mills | 90/84 | 20.7 s |
| 49 | I keep the line taut and haul the hooked snapper up onto the bank, staying clear of its beak and claws, then finish it with my dagger. | Erzähler | open_run_level | Land and kill the first snapper for the cull contract | weir ponds of the Alderwatch mills | 90/84 | 18.3 s |
| 50 | I step in quickly past its snapping neck to close with the beached snapper, then strike with my dagger at its neck, staying behind the beak. | Erzähler | open_run_level | Close to ENGAGED and kill the first snapper | weir ponds of the Alderwatch mills | 43/84 | 19.1 s |
| 51 | I strike again with my dagger at the neck wound, staying behind the beak. | Erzähler | open_run_level | Kill the snapper | weir ponds of the Alderwatch mills | 19/84 | 14.5 s |
| 52 | I strike once more at the gashed neck, staying behind the beak. | Erzähler | open_run_level | Finish the snapper | weir ponds of the Alderwatch mills | 0/84 | 15.7 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 11 (notiert vor Zug 12): #quests returned empty — lodging bought but no contract is recorded as active.
- zu Zug 12 (notiert vor Zug 13): Catacombs culling is a Warden muster at the chapel at dawn, not a Guild contract — paid day by day, no plate entry.
- zu Zug 20 (notiert vor Zug 21): Armored corpse just inside a sealed, air-flowing undercroft; Hesta has the crew widening the gap top down.
- zu Zug 30 (notiert vor Zug 31): HUD still shows Day 2, 20:10 despite narrator's morning scene; sleep must be engine-confirmed.
- zu Zug 32 (notiert vor Zug 33): Sleep was engine-confirmed only on the second attempt; recovery result showed full stats despite the first refusal.
- zu Zug 33 (notiert vor Zug 34): Snapper retreated to full cover in deep water; Basic Attack can't reach MEDIUM — trying ranged skill.
- zu Zug 36 (notiert vor Zug 37): System asked for explicit offer confirmation before spending; nothing was charged on the first attempt.
- zu Zug 38 (notiert vor Zug 39): System keeps asking for buy/sell clarification even after explicit wording; third attempt at this purchase.
- zu Zug 39 (notiert vor Zug 40): System now explicitly lists offer.t70.6 as the acceptance token — answering with that alone.
- zu Zug 41 (notiert vor Zug 42): Narrator contradicted the confirmed purchase: the herring was never handed over despite offer.t70.6 being accepted and paid; coin unchanged at 1s8c.
- zu Zug 44 (notiert vor Zug 45): Narrator asked for coin explicitly despite accepted offer.t84.7; handing it over directly.
- zu Zug 45 (notiert vor Zug 46): Engine refused because I addressed 'the mill hand' instead of the villager entity Tam; same person, different name token.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t43 | 50 | 1 | – | nein | 0 | **tot** |

## Quests

- **Cull the Orchard Striker** — active (Zug 28)
  - Aufgabe: Kill 1 striped orchard striker at Lowfield cider orchard. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 striped orchard striker killed at Lowfield cider orchard.
- **Thin the Millpond Snappers** — active (Zug 29)
  - Aufgabe: Kill 4 millpond snappers at weir ponds of the Alderwatch mills. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 millpond snappers killed at weir ponds of the Alderwatch mills.

## Auffälligkeiten

- Zug 3, Nachricht 5 (board_failed): the board generator failed
- Zug 6, Nachricht 12 (extraction_failed): the extractor failed: $.deltas[1] (quest.detail): .quest: missing required "new"; $.deltas[1] (quest.detail): .quest: unexpected property "id"
- Zug 6, Nachricht 12 (extraction_repaired): the extractor's first answer needed a repair
- Zug 7, Nachricht 13 (board_failed): the board generator failed
- Zug 8, Nachricht 16 (extraction_repaired): the extractor's first answer needed a repair
- Zug 16, Nachricht 32 (extraction_repaired): the extractor's first answer needed a repair
- Zug 19, Nachricht 38 (extraction_repaired): the extractor's first answer needed a repair
- Zug 24, Nachricht 48 (extraction_repaired): the extractor's first answer needed a repair
- Zug 25, Nachricht 50 (extraction_repaired): the extractor's first answer needed a repair
- Zug 26, Nachricht 51 (planner_repaired): the planner's first answer needed a repair
- Zug 36, Nachricht 71 (planner_repaired): the planner's first answer needed a repair
- Zug 37, Nachricht 73 (planner_repaired): the planner's first answer needed a repair
- Zug 38, Nachricht 75 (planner_repaired): the planner's first answer needed a repair
- Zug 39, Nachricht 77 (planner_repaired): the planner's first answer needed a repair
- Zug 43, Nachricht 85 (planner_repaired): the planner's first answer needed a repair
- Zug 46, Nachricht 91 (planner_repaired): the planner's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 12× keine gültige JSON-Entscheidung (Züge 2, 4, 8, 12, 16, 18, 23, 26, 41, 42, 43, 49)

System-Panels: CLARIFY 6, NOT TAKEN 0, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: ambient 6, engine_owned_fact 3, guild_canon 2, offer 2, time_cap 2, no_go 6, pc_inventory 6, scene_context 14, coin_evidence 1, world_rule 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 12/52 Erstantworten ungültig (23.1 %); 12 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 56 | 7 | 2.1 s | 4.3 s | 11829 | 9900 | 85 | – | stop 56 | 0 |
| board | 5 | 2 | 9.4 s | 13.7 s | 2454 | 2454 | 1083 | – | stop 5 | 0 |
| narrator | 43 | 0 | 8.9 s | 12.3 s | 11484 | 8782 | 446 | – | stop 43 | 0 |
| extract | 49 | 6 | 6.0 s | 10.2 s | 11659 | 9349 | 379 | – | stop 49 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 21:28 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 14.7 s) | 0:29 min |
| 52 Züge, Spiel (Senden bis HUD nach der Extraktion) | 17:56 min — Median 19.7 s, p90 34.3 s, max 50.3 s |
| 52 Züge, Spieler-Entscheidung | 2:19 min — Median 2.2 s, 12 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 2:34 min / 0:51 min / 7:01 min / 5:38 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 23.4 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 15:34 min, 80 Züge ≈ 31:09 min (ohne Einrichtung) |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
