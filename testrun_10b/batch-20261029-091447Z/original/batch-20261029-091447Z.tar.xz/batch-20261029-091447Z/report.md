# Avereth – 3 natürliche Testkampagnen

Status: **completed**. Serie abgeschlossen bedeutet, dass die Läufe beendet sind; es bedeutet nicht 3 bestandene Level-15-Abnahmen.

| Nr. | Profil | Seed | Eingaben | Level | Ende | Originalbericht |
|---|---|---:|---:|---:|---|---|
| 1 | guild-warrior | 2120501929 | 150 | 1 | limit | [report.md](001-guild-warrior/20261029-091448Z-current_test/report.md) |
| 2 | guild-mage | 2120501930 | 150 | 8 | limit | [report.md](002-guild-mage/20261029-102723Z-current_test/report.md) |
| 3 | guild-rogue | 2120501931 | 52 | 1 | defeat | [report.md](003-guild-rogue/20261029-112903Z-current_test/report.md) |

