# Avereth Live-Test 20261029-131555Z-current_test

## Kurzfassung

- **Laufprofil:** guild-warrior; Startklasse Warrior, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** abgebrochen: Limit erreicht — 150 turns
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 8. Sicherheitsgrenzen: 150 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** Level 6, 454 XP seit Levelaufstieg, 343 cp, HP 210, MP 92; Ort loc.gorse_stand_kill_site. Ausrüstung und Skills stehen in evaluation.json → progression.checkpoint.
- **Charakter:** warrior (warrior.cleave, warrior.quick_slash) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: pragmatic adventurer: sell surplus loot and invest in useful equipment and techniques
- **Züge:** 150 · **Dauer:** 62:42 min · **LLM-Aufrufe der Engine/des Erzählers:** 426
- **Beobachtete Abdeckung:** 29 unterschiedliche gebuchte Reiseziele · 12 Kämpfe · 3 Verkäufe (77 cp Umsatz, ohne Questzahlungen/Geschenke) · 0 Ausrüstungswechsel · 4 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 17
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.117 |
| Git | a9a76eb3db94 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 16.3 s |
| Browser | chrome 156.0.8078.49 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261029-131555Z-current_test“, Seed 1271046153 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | Warrior. | Engine (Menü/Rückfrage) | creation_complete | Choose Warrior class | public roadside verge outside Alderwatch | 90/84 | 2.3 s |
| 2 | I choose Cleave and Quick Slash as my two starter skills. | Engine (Menü/Rückfrage) | creation_complete | Select required Cleave plus Quick Slash | public roadside verge outside Alderwatch | 95/84 | 2.2 s |
| 3 | I walk through the city gate into Alderwatch and head for the Adventurers' Guild hall to look at the contract board. | Erzähler | open_run_level | Enter city and find Guild contracts | Adventurers' Guild hall, Alderwatch | 95/84 | 30.3 s |
| 4 | I approach the clerk and ask to register with the Guild, then request the Wolf Predation at Hollowmere Farms contract. | Erzähler | open_run_level | Register at Guild and take the wolf contract | Adventurers' Guild hall, Alderwatch | 95/84 | 15.9 s |
| 5 | I pay the two silver and sign the ledger to register with the Guild. | Erzähler | open_run_level | Register with the Guild | Adventurers' Guild hall, Alderwatch | 95/84 | 24.3 s |
| 6 | I take the rat-catch slip and ask the clerk where exactly to find Marda at the coal yard on Tanner's Row. | Erzähler | open_run_level | Take the rat-catch job and get directions | Adventurers' Guild hall, Alderwatch | 95/84 | 25.4 s |
| 7 | I head south to Tanner's Row and find Marda at the coal yard, asking if she still needs the rats dealt with and what she pays. | Erzähler | open_run_level | Take the private rat-catch job from Marda | Tanner's Row | 95/84 | 24.0 s |
| 8 | I accept the job and ask Marda to unbar the warehouse doors so I can start clearing the rats. | Erzähler | open_run_level | Take the private rat-clearing job for four silver | Tanner's Row | 95/84 | 20.1 s |
| 9 | I take the lantern off the nail and light it, then step inside and head toward the scratching behind the coal sacks, sword ready. | Erzähler | open_run_level | Start clearing the rats | Tanner's Row | 95/84 | 20.4 s |
| 10 | I draw my sword and strike at Rat A in the floorboard gap, keeping the lantern raised in my other hand. | Erzähler | open_run_level | Attack Rat A | Tanner's Row | 93/84 | 15.6 s |
| 11 | I strike Rat B with a Basic Attack. | Erzähler | open_run_level | Kill the second rat | Tanner's Row | 93/84 | 19.3 s |
| 12 | "That was the lot by the sound of it, but I'll check under the pallets before I call it done. I'll also tell you how they're getting in — th… | Erzähler | open_run_level | Finish the rat-clearing job and report the entry point to Marda | under the pallets | 93/84 | 24.0 s |
| 13 | I work the split pallet board loose with my sword's tip and pull the nest out into the open, then finish the litter quickly before reporting… | Erzähler | open_run_level | Clear the remaining rats and complete the job | under the pallets | 93/84 | 19.6 s |
| 14 | I put the sword aside, get both hands on the split board, and pry it up properly with my fingers and weight. | Erzähler | open_run_level | Remove the split pallet board to reach the nest | under the pallets | 93/84 | 17.8 s |
| 15 | I finish the three pink litter rats in the nest quickly with my sword, then report to Marda that the job is truly done now — rats and litter… | Erzähler | open_run_level | Complete the rat job and get paid | under the pallets | 90/84 | 33.6 s |
| 16 | I use Cleave to hit both rats at once, keeping clear of Marda. | Erzähler | open_run_level | Kill both adult rats with AoE | under the pallets | 90/84 | 19.8 s |
| 17 | I follow Marda into the office, wash and dress the bites with her wash and cloth, then report the job is fully done — rats, litter, and entr… | Erzähler | open_run_level | Get paid for the rat job and tend wounds | coal yard office | 90/84 | 25.9 s |
| 18 | I take the eight copper and the silver, thank Marda, accept the bread and cheese, and ask if she knows where the Guild hall is — I want to l… | Erzähler | open_run_level | Get paid and head to the Guild for contracts | coal yard office | 90/84 | 19.6 s |
| 19 | #assign STR 2 VIT 2 AGI 1 | System (Befehl) | open_run_level | Spend the 5 free stat points from the level-up | coal yard office | 90/84 | 2.2 s |
| 20 | I leave the coal yard, follow Marda's directions — left on Tanner's Row to the Weavers' Walk, past the dye houses — to the Guild hall on the… | Erzähler | open_run_level | Reach the Guild hall and view the contract board | Adventurers' Guild hall, Alderwatch | 90/84 | 24.3 s |
| 21 | I tell the clerk I'll take the East Heath wolf cull and ask him to register it for me. | Erzähler | open_run_level | Accept the wolf contract | Adventurers' Guild hall, Alderwatch | 90/84 | 15.9 s |
| 22 | I tell the clerk nothing else and head east out of Alderwatch on the Ford Road for East Heath, planning to ask at the first shepherd's hut w… | Erzähler | open_run_level | Travel to East Heath for the wolf contract | the East Heath pastures | 90/84 | 22.7 s |
| 23 | I ask the shepherd to lead me to the north fold where the carcasses are, and settle in to wait for the wolves near dusk. | Erzähler | open_run_level | Stake out the carcasses to ambush the wolves | the north fold | 90/84 | 30.2 s |
| 24 | I position myself on the flat stone on the wall with a clear view of the carcasses, and wait out the hours until dusk for the wolves to come… | Erzähler | open_run_level | Ambush wolves at the carcasses at dusk | the north fold | 90/84 | 33.4 s |
| 25 | I draw my longsword and charge the nearer wolf (A) with a Cleave, aiming to catch wolf B in the same arc if it's still close to the wall. | Erzähler | open_run_level | Open the wolf fight with Cleave on both approaching wolves | the north fold | 90/84 | 24.1 s |
| 26 | I hold my position beside the wall, sword ready, and strike with a Basic Attack the first wolf that comes within reach. | Erzähler | open_run_level | Let the wolves close and attack the first in range | the north fold | 90/84 | 29.7 s |
| 27 | I swing my longsword in a Basic Attack at the lunging scarred wolf A. | Erzähler | open_run_level | Strike the engaged wolf A | the north fold | 54/84 | 19.1 s |
| 28 | I swing a Cleave through both engaged wolves, putting the arc through wolf A first. | Erzähler | open_run_level | Finish wolf A and damage B with AoE now that both are engaged | the north fold | 45/84 | 16.0 s |
| 29 | I finish the wounded wolf with a Basic Attack at Gray Wolf B. | Erzähler | open_run_level | Kill the last wolf and complete the wolf contract | the north fold | 45/84 | 20.9 s |
| 30 | #assign STR 3 VIT 2 | System (Befehl) | open_run_level | Spend level-up points on STR and VIT | the north fold | 45/84 | 2.2 s |
| 31 | I keep to the wall and scan the dark for a third wolf, sword ready but not pushing deeper into the heath while badly wounded. | Erzähler | open_run_level | Stay safe and check contract progress before deciding to continue or withdraw | the north fold | 45/84 | 19.7 s |
| 32 | I take the Iron Ward Riposte skill, then withdraw along the wall toward Halst's hut to rest and recover before hunting the den. | Erzähler | open_run_level | Accept skill offer and retreat to recover | Halst's hut | 45/84 | 22.5 s |
| 33 | I knock on Halst's door and ask if I can shelter for the night and rest until morning. | Erzähler | open_run_level | Get lodging to recover HP before hunting the den | Halst's hut | 45/84 | 18.3 s |
| 34 | I follow the peat-smoke thread and the fold's glow to look for Halst, calling out that I'm a Guild adventurer, wounded but friendly. | Erzähler | open_run_level | Find the shepherd to get shelter for the night | the peat-fire hollow | 45/84 | 28.5 s |
| 35 | I stay by the peat fire with the flock and rest until my wounds mend, keeping watch with sword ready, rather than chase wolves into the dark… | Engine (Menü/Rückfrage) | open_run_level | Recover HP safely before hunting the den | the peat-fire hollow | 45/84 | 5.0 s |
| 36 | I rest here by the peat fire until my wounds are fully healed, keeping watch over the flock with sword ready. | Engine (Menü/Rückfrage) | open_run_level | Rest until fully recovered | the peat-fire hollow | 45/84 | 4.0 s |
| 37 | I rest here by the fire for 4 hours, keeping watch over the flock with sword ready. | Erzähler | open_run_level | Rest a named duration to recover HP | the peat-fire hollow | 99/84 | 20.4 s |
| 38 | I rest here by the peat fire for another 4 hours to recover fully, keeping watch over the flock with sword ready. | Erzähler | open_run_level | Finish recovery before hunting the den | the peat-fire hollow | 135/84 | 40.5 s |
| 39 | I head east toward the notch in the crags where the wolf den is, following Halst's tracks and the blood smell. | Erzähler | open_run_level | Hunt the remaining wolves at the den | the fold between the crags | 135/84 | 21.6 s |
| 40 | I draw my sword and advance into the notch toward the growling wolves, ready to attack the first wolf that lunges, and call out to Halst tha… | Erzähler | open_run_level | Rescue Halst and finish the wolf cull in the den | the notch den | 135/84 | 32.5 s |
| 41 | I hold my ground in the narrow gap and swing Cleave at both wolves as they lunge. | Erzähler | open_run_level | Fight the two den wolves with Cleave | the notch den | 135/84 | 24.0 s |
| 42 | I step forward to engage the torn-eared wolf and swing Cleave at both wolves. | Erzähler | open_run_level | Close to sword reach and fight both wolves | the notch den | 98/84 | 20.7 s |
| 43 | I swing Cleave at both wolves again. | Erzähler | open_run_level | Finish both wolves with AoE | the notch den | 87/84 | 16.3 s |
| 44 | I finish the young wolf with Quick Slash. | Erzähler | open_run_level | Defeat the last wolf | the notch den | 87/84 | 24.2 s |
| 45 | #assign VIT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up stat points before returning | the notch den | 87/84 | 2.1 s |
| 46 | I check Halst's wound and help him up, then walk him back toward the fold and his hut. | Erzähler | open_run_level | Rescue Halst and get him back to safety | Halst's hut | 87/84 | 29.8 s |
| 47 | I fetch the bandage chest and kettle, build up the fire, and dress Halst's wound as best I can. | Erzähler | open_run_level | Tend Halst's wound before heading back to town for the turn-in | Halst's hut | 87/84 | 24.7 s |
| 48 | I let Halst see to my torn arm and leg, then tell him I'll head back to Valedorn to report the wolf cull done — four wolves, all counted. | Erzähler | open_run_level | Get patched up, then leave for the Guild turn-in | Halst's hut | 87/84 | 63.1 s |
| 49 | I return the linen roll to the chest, leave it by the door, and set out on the river road toward Alderwatch. | Erzähler | open_run_level | Travel to Alderwatch Guild hall to turn in the wolf cull | Halst's hut | 87/84 | 20.7 s |
| 50 | I join the line at the Alderwatch gatehouse and enter the town, then head to the Guild hall to turn in the wolf cull contract. | Erzähler | open_run_level | Enter Alderwatch and turn in the wolf cull | Adventurers' Guild hall, Alderwatch | 87/84 | 21.8 s |
| 51 | I go to the board and read what contracts are posted, then ask the clerk which ones suit a Novice. | Erzähler | open_run_level | Pick a new Guild contract | Adventurers' Guild hall, Alderwatch | 87/84 | 24.2 s |
| 52 | I take the Serpent at Miller's Ford slip from the board and hand it to the clerk to accept the contract. | Erzähler | open_run_level | Accept a suitable Novice hunt | Adventurers' Guild hall, Alderwatch | 87/84 | 16.3 s |
| 53 | Before leaving, I ask around the market square for a leather or fur merchant and offer my four wolf pelts and ten wolf fangs for sale. | Erzähler | open_run_level | Sell surplus loot, then head for the ford | market square | 87/84 | 22.0 s |
| 54 | I accept Doss's offer: three silver ten copper for the four pelts and ten fangs, and hand them over. |  | open_run_level | Sell surplus loot at agreed price | market square | 87/84 | 9.8 s |
| 55 | I hand Doss the four pelts and ten fangs and say: "Done — three silver and ten copper, the lot." | Erzähler | open_run_level | Complete the fur sale at Doss's stated price | market square | 87/84 | 23.5 s |
| 56 | I leave the market and take the road to Miller's Ford to hunt the serpent. | Erzähler | open_run_level | Travel to Miller's Ford for the active serpent contract | the ford below Miller's Mill | 87/84 | 20.6 s |
| 57 | I follow the drag-mark along the bank and search the reeds for fresh sign of the serpent, staying clear of the deep water. | Erzähler | open_run_level | Track the serpent at the ford | the serpent backwater | 87/84 | 20.9 s |
| 58 | I take position at the backwater's edge with my longsword drawn and watch the duckweed for movement, ready to engage the serpent if it shows… | Erzähler | open_run_level | Ambush the serpent at its lair | the serpent backwater | 87/84 | 18.7 s |
| 59 | I hold my ground at the bank's edge and strike at the serpent's head with my longsword the moment it comes within reach. | Erzähler | open_run_level | Attack the serpent as it closes | the serpent backwater | 87/84 | 15.2 s |
| 60 | I step forward to engage the serpent and strike at its head with my longsword. | Erzähler | open_run_level | Close to ENGAGED and attack the serpent | the serpent backwater | 87/84 | 35.5 s |
| 61 | I harvest proof of the kill — the serpent's head or whatever trophy the contract needs — and take the road back to the Guild hall to turn in… | Erzähler | open_run_level | Turn in the completed serpent contract at the Guild | Adventurers' Guild hall, Alderwatch | 87/84 | 30.1 s |
| 62 | I ask the clerk to show me the Guild contract board for my rank. | Erzähler | open_run_level | Pick the next contract from the board | Adventurers' Guild hall, Alderwatch | 87/84 | 17.2 s |
| 63 | I accept the contract 'Thin the East Heath Wolf Pack (4)' from the board. | Erzähler | open_run_level | Take the wolf pack contract | Adventurers' Guild hall, Alderwatch | 87/84 | 17.9 s |
| 64 | I ask the clerk if there's an inn nearby where I can take a room for the night. | Erzähler | open_run_level | Get lodging before recovering overnight | Adventurers' Guild hall, Alderwatch | 87/84 | 14.8 s |
| 65 | I head to the Ram's Head by the market square and take a room for the night. | Erzähler | open_run_level | Get lodging to recover overnight | The Ram's Head | 87/84 | 17.6 s |
| 66 | I buy the bed for the night and the mutton supper from the innkeeper. | Erzähler | open_run_level | Pay for lodging and meal, then sleep until morning | The Ram's Head | 87/84 | 16.6 s |
| 67 | I eat the supper, then go up to my room and sleep until morning. | Erzähler | open_run_level | Recover overnight before wolf hunt | The Ram's Head | 160/92 | 22.6 s |
| 68 | I eat breakfast, then head out the east gate toward the East Heath to hunt the wolf pack. | Erzähler | open_run_level | Breakfast then travel to wolf contract area | the East Heath pastures | 160/92 | 28.5 s |
| 69 | I follow the fresh wolf tracks north along the stream, sword ready, toward the gorse thickets and wooded rise. | Erzähler | open_run_level | Track the wolf pack for the contract | the gorse thickets below the wooded rise | 160/92 | 37.0 s |
| 70 | I let the lead pair close in, then swing Cleave through the two big wolves in front of me, keeping my back to a gorse thicket so the third c… | Erzähler | open_run_level | Fight the wolf pack with Cleave | the gorse thickets below the wooded rise | 160/92 | 29.4 s |
| 71 | I step forward and strike at the wolf holding the gap ahead with my longsword. | Engine (Menü/Rückfrage) | open_run_level | Engage a wolf so Cleave becomes usable | the gorse thickets below the wooded rise | 160/92 | 6.0 s |
| 72 | I strike at Gray Wolf E, the one ahead that bunched to spring. | Erzähler | open_run_level | Engage the lead wolf with a basic attack so Cleave can follow | the gorse thickets below the wooded rise | 160/92 | 13.4 s |
| 73 | I charge at Gray Wolf E, closing the gap to engage it, and swing my longsword at it. | Erzähler | open_run_level | Close to ENGAGED range with Gray Wolf E and attack | the gorse thickets below the wooded rise | 103/92 | 19.8 s |
| 74 | I swing Cleave through all three wolves around me, aiming to cut down the wounded Gray Wolf E and hit the other two. | Erzähler | open_run_level | Use Cleave on the three engaged wolves | the gorse thickets below the wooded rise | 92/92 | 22.0 s |
| 75 | I finish Gray Wolf F with a Basic Attack before it can bite again. | Erzähler | open_run_level | Kill the last wolf | the gorse thickets below the wooded rise | 92/92 | 18.8 s |
| 76 | #assign STR 2 VIT 3 | System (Befehl) | open_run_level | Spend level-up points on damage and survivability | the gorse thickets below the wooded rise | 92/92 | 2.5 s |
| 77 | I follow the fresh wolf tracks north along the stream, longsword ready, looking for the fourth wolf of the pack. | Erzähler | open_run_level | Hunt the last wolf for the active quest | the fallen-pine hollow | 92/92 | 21.3 s |
| 78 | I swing a Basic Attack at Gray Wolf H as it closes on me. | Erzähler | open_run_level | Damage the last wolf | the fallen-pine hollow | 92/92 | 17.8 s |
| 79 | I step forward to ENGAGED range with Gray Wolf H and swing a Basic Attack at it. | Erzähler | open_run_level | Close and attack the last wolf | the fallen-pine hollow | 79/92 | 22.0 s |
| 80 | I swing a Basic Attack at Gray Wolf H to finish it. | Erzähler | open_run_level | Kill the last wolf for the quest | the fallen-pine hollow | 79/92 | 18.9 s |
| 81 | #assign STR 2 VIT 3 | System (Befehl) | open_run_level | Spend level-up points on damage and survivability | the fallen-pine hollow | 79/92 | 2.5 s |
| 82 | I turn south and walk back to the Guild hall in town, planning to turn in the wolf pack contract on arrival. | Erzähler | open_run_level | Turn in the completed wolf contract at the Guild | Adventurers' Guild hall, Alderwatch | 79/92 | 22.0 s |
| 83 | I ask the clerk what contracts are on the Guild board for a Novice. | Erzähler | open_run_level | Find the next Guild contract | Adventurers' Guild hall, Alderwatch | 79/92 | 21.3 s |
| 84 | I accept the contract 'Drive Out the Orchard Boar' from the board, then cross the street to the healer to have my bitten arm treated. | Erzähler | open_run_level | Take a new contract and heal up | healer's shop | 79/92 | 19.5 s |
| 85 | I take both: close and dress the wound for eight copper, and the mending draught for twenty. | Engine (Menü/Rückfrage) | open_run_level | Heal the wolf bite and recover stamina | healer's shop | 79/92 | 10.9 s |
| 86 | I buy the wound closing and dressing and one mending draught from the healer, 28 copper total. | Erzähler | open_run_level | Buy healing from the healer at the stated prices | healer's shop | 79/92 | 16.6 s |
| 87 | I drink the draught, then sell the healer my surplus wolf pelts and fangs if she or anyone in town will buy them — I ask her if she buys pel… | Erzähler | open_run_level | Recover and sell surplus loot before heading to the orchard | healer's shop | 79/92 | 28.9 s |
| 88 | I walk to Tanner's Row and find Ostrey's tannery, then ask what he'll pay for eight wolf pelts and eighteen wolf fangs. | Erzähler | open_run_level | Sell surplus wolf loot to the named buyer | Ostrey's tannery yard | 79/92 | 21.9 s |
| 89 | I take his hand. Four silver three for the lot, agreed. |  | open_run_level | Accept Ostrey's offer for the wolf pelts and fangs | Ostrey's tannery yard | 79/92 | 11.1 s |
| 90 | I sell Ostrey all eight wolf pelts and all eighteen wolf fangs for four silver three, as he offered. | Erzähler | open_run_level | Complete the loot sale at Ostrey's stated price | Ostrey's tannery yard | 79/92 | 19.1 s |
| 91 | #bag | System (Befehl) | open_run_level | Verify the wolf loot sale actually recorded | Ostrey's tannery yard | 79/92 | 2.6 s |
| 92 | I accept Ostrey's offer of four silver three and hand him all eight wolf pelts and all eighteen wolf fangs; please record the sale and the c… | Erzähler | open_run_level | Complete the wolf loot sale with explicit terms | Ostrey's tannery yard | 79/92 | 20.3 s |
| 93 | I hand Ostrey all eight wolf pelts and all eighteen wolf fangs and take the four silver three he just offered, cash now. | Erzähler | open_run_level | Complete the wolf loot sale at Ostrey's fresh stated price | Ostrey's tannery yard | 79/92 | 28.9 s |
| 94 | I leave the tannery and head to the nearest inn to buy a room for the night, then sleep until morning. | Erzähler | open_run_level | Recover from heavy wounds with a night's rest | the Braced Beam | 79/92 | 20.1 s |
| 95 | I pay Innkeeper B five copper for the room and the supper, then eat, go up to the room and sleep until morning. | Erzähler | open_run_level | Buy lodging and supper, then sleep to recover | room upstairs at the Braced Beam | 79/92 | 27.6 s |
| 96 | I eat the supper that was served to me, then lie down in the bed and sleep until morning. | Erzähler | open_run_level | Recover HP by eating and sleeping | room upstairs at the Braced Beam | 210/92 | 46.0 s |
| 97 | I head downstairs and out of the Braced Beam, then go to the Guild hall to check the contract board for a new job. | Erzähler | open_run_level | Find new Guild contracts after recovery | Adventurers' Guild hall, Alderwatch | 210/92 | 25.1 s |
| 98 | I tell the clerk: "I'll take Cull the East Heath Pack — the four gray wolves at East Heath. Make it active for me, please." | Erzähler | open_run_level | Accept the wolf cull contract | Adventurers' Guild hall, Alderwatch | 210/92 | 13.9 s |
| 99 | I leave the Guild hall through the east gate and follow the pasture track toward the East Heath pastures to hunt the four gray wolves. | Erzähler | open_run_level | Travel to East Heath for the active wolf cull | Adventurers' Guild hall, Alderwatch | 210/92 | 20.8 s |
| 100 | I follow the track up past the stone wall toward the gorse stand, watching for wolves as I approach the kill site. | Erzähler | open_run_level | Hunt the East Heath wolves | gorse stand kill site | 210/92 | 23.5 s |
| 101 | I draw my sword and push carefully through the pushed path into the gorse, ready to attack any wolf inside the den. | Erzähler | open_run_level | Enter the den and engage the wolves | the den in the dip beyond the gorse | 207/92 | 26.4 s |
| 102 | I swing Cleave at both wolves in the den, hitting Gray Wolf I and Gray Wolf J. | Erzähler | open_run_level | Use AoE on both engaged adult wolves | the den in the dip beyond the gorse | 207/92 | 26.2 s |
| 103 | I push through the broken gorse gap and chase the fleeing wolves down the slope. | Erzähler | open_run_level | Pursue remaining three contract targets | the bracken ravine below the slope | 207/92 | 28.4 s |
| 104 | I approach the ravine mouth slowly with my sword ready, letting the wind carry my scent, and probe the bracken at the edge for the waiting w… | Erzähler | open_run_level | Hunt remaining three contract wolves in the ravine | the ravine mouth | 207/92 | 18.8 s |
| 105 | I follow the tracks into the ravine toward the bend, sword ready for an ambush. | Erzähler | open_run_level | Hunt remaining three wolves in the ravine | the bend in the ravine | 207/92 | 21.5 s |
| 106 | I turn and swing Cleave at the leaping wolf attacking from behind. | Erzähler | open_run_level | Counter the ambush | the bend in the ravine | 207/92 | 25.5 s |
| 107 | I assign my five free stat points with #assign AGI 3 WIL 2, then level-up done, I track the fleeing pup and the last adult wolf north throug… | Erzähler | open_run_level | Spend stat points and continue hunting remaining contract wolves | the open heath | 207/92 | 33.2 s |
| 108 | I advance across the open heath toward the scarred adult wolf and swing Cleave at it when it comes at me. | Erzähler | open_run_level | Engage the last adult contract wolf | the open heath | 207/92 | 25.7 s |
| 109 | I close the last ten paces to the scarred adult wolf and swing Cleave at it as soon as I'm within reach. | Erzähler | open_run_level | Engage and attack the last adult contract wolf | the open heath | 192/92 | 23.6 s |
| 110 | I finish the dying pup with a Basic Attack. | Erzähler | open_run_level | Kill last contract wolf | the open heath | 192/92 | 16.0 s |
| 111 | I check the #quests panel to confirm the East Heath pack count, then track the fourth and last wolf toward the gorse den upwind. | Erzähler | open_run_level | Confirm contract progress and hunt the last wolf | the open heath | 192/92 | 19.7 s |
| 112 | I walk downwind toward the gorse thickets where the pack denned and search there for the fourth wolf's trail. | Erzähler | open_run_level | Hunt the last contract wolf | the open heath | 192/92 | 18.5 s |
| 113 | I set out for the gorse den itself, walking toward it as my destination. | Erzähler | open_run_level | Travel to the den to find the fourth wolf | the open heath | 192/92 | 19.6 s |
| 114 | I take the road back toward Valedorn town as my destination, walking there to sell my surplus pelts and fangs. | Erzähler | open_run_level | Leave blocked heath, return to town to sell loot | Alderwatch | 192/92 | 20.7 s |
| 115 | "I'm Guild, Novice rank, on contract work from the East Heath — here to sell pelts and turn in a hunt." | Erzähler | open_run_level | Answer the gate guard and enter town | Alderwatch | 192/92 | 22.9 s |
| 116 | "Both. I'd like to turn in the East Heath wolf cull — three of four confirmed — and sell what I'm carrying. What will the Guild buy back?" | Erzähler | open_run_level | Turn in the 3/4 wolf cull and sell pelts/fangs at the Guild counter | Alderwatch | 192/92 | 23.7 s |
| 117 | I set out for the Alderwatch Guild hall, the long low building with the green door on the north side of the square, and walk there as my des… | Erzähler | open_run_level | Reach the Guild hall to turn in the 3/4 wolf cull | Adventurers' Guild hall, Alderwatch | 192/92 | 14.7 s |
| 118 | "Turn-in. I've taken three of four on the East Heath wolf cull — I'd like to report that progress, and hear what you'll buy back from my pou… | Erzähler | open_run_level | Report 3/4 cull progress and ask buy-back prices at the Guild counter | Adventurers' Guild hall, Alderwatch | 192/92 | 38.6 s |
| 119 | I hand the clerk the slip to mark, then lay out eleven wolf pelts and twenty-five fangs and ask his price for the lot. | Erzähler | open_run_level | Mark progress and sell surplus loot | Adventurers' Guild hall, Alderwatch | 192/92 | 26.1 s |
| 120 | "Deal — fifty-two for the lot, sell all eleven pelts and all twenty-five fangs." I also lay out the marsh serpent skin and ask what he'll of… | Erzähler | open_run_level | Accept the confirmed 52 cp offer and price the serpent skin | Adventurers' Guild hall, Alderwatch | 192/92 | 19.4 s |
| 121 | "Twenty works — take the skin." I also glance at the slate and ask what he'd offer for three rat pelts and five tails. | Erzähler | open_run_level | Sell serpent skin and price rat loot | Adventurers' Guild hall, Alderwatch | 192/92 | 21.3 s |
| 122 | "Five works — sell all three pelts and five tails." I also check the board for fresh contracts I can take. | Erzähler |  | Sell rat loot and pick new Guild work | Adventurers' Guild hall, Alderwatch | 192/92 | 18.5 s |
| 123 | I tell the clerk I'll take the Serpent at the Ford contract, and ask him to mark it active for me. | Erzähler | open_run_level | Accept the serpent contract at the Guild board | Adventurers' Guild hall, Alderwatch | 192/92 | 20.3 s |
| 124 | "I'm off, thank you." I head out of the Guild hall and take the Crown road south toward Miller's Mill, then cut east at the split-oak milest… | Erzähler | open_run_level | Travel to the ford to hunt the marsh serpent | the ford below Miller's Mill | 192/92 | 26.2 s |
| 125 | I keep clear of the shallows and watch the mud bank past the willow for the serpent to surface, sword ready. | Erzähler | open_run_level | Wait for the marsh serpent to appear and engage it on land | the ford below Miller's Mill | 192/92 | 23.5 s |
| 126 | I circle wide to come at the serpent from behind, then rush in and strike its exposed flank with my longsword. | Erzähler | open_run_level | Engage the marsh serpent with a flanking strike | the ford below Miller's Mill | 192/92 | 17.4 s |
| 127 | I ask Odo whether he'll ferry me across or along the backwater in his boat, so I can step off close behind the serpent instead of wading the… | Erzähler | open_run_level | Close the distance to the serpent using Odo's boat | the ford below Miller's Mill | 192/92 | 17.4 s |
| 128 | "Done — one copper, and I'll step off quiet." I pay Odo, get in the punt, and ready my sword as he poles me to the bank behind the willow. | Erzähler | open_run_level | Accept the punt crossing to close on the serpent | the ford below Miller's Mill | 192/92 | 24.5 s |
| 129 | I step off the punt onto the firm bank edge and rush the serpent, striking its head and neck with my longsword before it can raise itself. | Erzähler | open_run_level | Engage the marsh serpent at close range | the ford below Miller's Mill | 192/92 | 21.2 s |
| 130 | I charge the last strides through the mud and swing my longsword at the serpent's raised neck as it turns toward me. | Engine (Menü/Rückfrage) | open_run_level | Close to ENGAGED and attack the serpent | the ford below Miller's Mill | 192/92 | 6.1 s |
| 131 | I charge the last strides through the mud and use Cleave on the serpent's raised neck as it turns toward me. | Erzähler | open_run_level | Engage the serpent with Cleave | the ford below Miller's Mill | 192/92 | 18.2 s |
| 132 | I take the last stride into reach and use Cleave on the serpent's raised neck. | Erzähler | open_run_level | Attack the now-ENGAGED serpent with Cleave | the ford below Miller's Mill | 192/92 | 18.5 s |
| 133 | I signal Odo that the serpent is dead, then head back to the Guild hall in Valedorn Crown to turn in Serpent at the Ford. | Erzähler | open_run_level | Turn in the serpent contract at the Guild hall | Adventurers' Guild hall, Alderwatch | 192/92 | 21.7 s |
| 134 | I ask the clerk for the Guild board's available novice contracts, then get a room for the night if the hall still lets rooms — first the boa… | Erzähler | open_run_level | Turn-in done; pick next contract for tomorrow | Adventurers' Guild hall, Alderwatch | 192/92 | 18.4 s |
| 135 | I buy the Primer of Guard from the clerk for 80 copper, then go upstairs and sleep until morning. | Erzähler | open_run_level | Learn guard skill and recover overnight | room upstairs at the Braced Beam | 192/92 | 25.8 s |
| 136 | I read the Primer of Guard to learn the skill, then sleep in the cot until morning. | Erzähler | open_run_level | Learn guard and recover overnight in the room | room upstairs at the Braced Beam | 220/92 | 18.1 s |
| 137 | #bag | System (Befehl) | open_run_level | Check whether the Primer of Guard is actually in my inventory | room upstairs at the Braced Beam | 220/92 | 2.8 s |
| 138 | I return the room key downstairs, then head out to the East Heath to hunt the last wolf of the pack. | Erzähler | open_run_level | Finish the 3/4 wolf cull | the Braced Beam | 220/92 | 19.6 s |
| 139 | I finish the key handover and head out the east road to the East Heath to hunt the last wolf of the pack. | Erzähler | open_run_level | Complete the 3/4 wolf cull | the Braced Beam | 220/92 | 21.8 s |
| 140 | I follow the fresh wolf prints along the fence line to track down the last wolf of the pack. | Erzähler | open_run_level | Hunt the final wolf for the cull contract | the East Heath pastures | 220/92 | 26.2 s |
| 141 | I attack the Gray Wolf with Cleave. | Erzähler | open_run_level | Kill the last wolf for the pack cull | the East Heath pastures | 220/92 | 16.2 s |
| 142 | I cross the stream and engage the Gray Wolf, then attack it with Cleave. | Erzähler | open_run_level | Close distance so Cleave has an engaged target | the East Heath pastures | 220/92 | 21.5 s |
| 143 | I lunge to close the gap and attack the Gray Wolf with Quick Slash. | Erzähler | open_run_level | Engage the evasive wolf with a faster strike | the East Heath pastures | 205/92 | 18.2 s |
| 144 | I finish the wounded wolf with a Basic Attack. | Erzähler | open_run_level | Kill the last wolf for the cull contract | the East Heath pastures | 205/92 | 15.7 s |
| 145 | With the pack cull at 4/4, I head back to the Guild hall in town to turn in the contract and collect the reward. | Erzähler | open_run_level | Turn in completed wolf cull contract | Adventurers' Guild hall, Alderwatch | 205/92 | 17.6 s |
| 146 | #assign STR 3 VIT 2 | System (Befehl) | open_run_level | Spend 5 of 10 free stat points on combat stats | Adventurers' Guild hall, Alderwatch | 205/92 | 2.9 s |
| 147 | I ask the clerk what contracts are on the board suitable for a Novice. | Erzähler | open_run_level | Pick next Guild contract | Adventurers' Guild hall, Alderwatch | 205/92 | 26.9 s |
| 148 | I accept the Thornbury boar contract from the board to have it marked active alongside my orchard boar job. | Erzähler | open_run_level | Take boar contract | Adventurers' Guild hall, Alderwatch | 205/92 | 14.0 s |
| 149 | I head out the south gate and travel to the Thornbury cider orchards to hunt the tusked boars. | Erzähler | open_run_level | Travel to Thornbury for the stacked boar contracts | the Thornbury cider orchards | 205/92 | 27.2 s |
| 150 | I follow the trampled tracks into the scrub beyond the hedge to find where the boars are bedded down. | Erzähler | open_run_level | Hunt the bedded-down boars in the scrub | the boar wallow hollow | 205/92 | 23.6 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 3 (notiert vor Zug 4): Novice contract row is empty; only a Proven-rank wolf contract and an off-board rat job are available. Guild rank not yet registered.
- zu Zug 4 (notiert vor Zug 5): Wolf contract slip was gone before acceptance; board refreshes tomorrow. Rat-catch job available meanwhile.
- zu Zug 7 (notiert vor Zug 8): HUD shows 3 Silver despite engine confirming 30 copper; coin discrepancy noted.
- zu Zug 11 (notiert vor Zug 12): HUD shows 3 Silver and no quest entry despite Marda's promised four silver payment; coin discrepancy persists.
- zu Zug 17 (notiert vor Zug 18): Paid 8 copper + 1 silver for rat job; HUD still shows 3 Silver before pickup, coin total will need checking after taking payment.
- zu Zug 20 (notiert vor Zug 21): Present list still shows the coal-yard rats as a sign; likely stale.
- zu Zug 21 (notiert vor Zug 22): Quest confirmed ACTIVE 0/4. Journal still shows stale rat signs; ignoring.
- zu Zug 23 (notiert vor Zug 24): Action refused earlier only because arrival was pending; now at the north fold. HP still 90/115 — lightly wounded from the rat job.
- zu Zug 25 (notiert vor Zug 26): Cleave refused because targets were not ENGAGED after my charge; closing charge gave ground away. Third large wolf joined but only two are listed as present.
- zu Zug 30 (notiert vor Zug 31): Contract shows 2/4 wolves defeated; HP 45/115 badly wounded, and a large shape lurked under the crags.
- zu Zug 36 (notiert vor Zug 37): System wants an explicit duration for rest; HP cap reads 135 on HUD while earlier note said 115.
- zu Zug 54 (notiert vor Zug 55): Planner refused the earlier phrasing as ambiguous; restating with Doss's exact named price.
- zu Zug 55 (notiert vor Zug 56): Pelt sale completed for 3s10c; coin now 1g7s8c. A private rat job at the coal yard surfaced but is unpaid Guild work — ignoring it.
- zu Zug 67 (notiert vor Zug 68): Recovery engine confirmed full HP/MP/STA despite the 'invalid scope' refusal; the rat nest sign seems stale, likely from old journal data.
- zu Zug 70 (notiert vor Zug 71): Cleave was refused because no wolf was ENGAGED yet; the pack sits out of reach and circles.
- zu Zug 83 (notiert vor Zug 84): Wolf pack contract reposted at same reward; HP badly low (79/210) after wolf fight.
- zu Zug 85 (notiert vor Zug 86): System demanded explicit purchase clarification before any transaction.
- zu Zug 89 (notiert vor Zug 90): System rejected the handshake phrasing for unclear price/quantity; restating explicitly.
- zu Zug 90 (notiert vor Zug 91): HUD still lists 8 pelts and 18 fangs as carried despite the completed sale narration; checking inventory.
- zu Zug 91 (notiert vor Zug 92): Narration said the sale completed, but #bag still shows 8 pelts, 18 fangs and coin unchanged at 348 copper — sale did not record.
- zu Zug 92 (notiert vor Zug 93): Narrator gave a new price breakdown (4 silver 3 flat); earlier sale attempts never recorded in #bag, so verifying coin after this.
- zu Zug 93 (notiert vor Zug 94): Wolf loot sale still not recorded after three attempts: bag and coin unchanged (8 pelts, 18 fangs, 348 cp). Dropping the sale as a persistent blockage; HP 79/210 badly wounded, recovery is the priority.
- zu Zug 94 (notiert vor Zug 95): Wolf pelt/fang sale still not reflected in HUD (8 pelts, 18 fangs, coin 348 cp) despite narrator completing it a fourth time — treating as a persistent recording blockage.
- zu Zug 96 (notiert vor Zug 97): HP fully recovered to 210/210 overnight. Wolf pelt/fang sale still never recorded in inventory after four attempts; treating as a persistent recording blockage.
- zu Zug 101 (notiert vor Zug 102): Two pups are present in the den; contract targets appear to be the four adults. Wind was carrying my scent toward the gorse on approach.
- zu Zug 106 (notiert vor Zug 107): Level 7 confirmed mid-contract; wolf pack count 2/4 with one adult and one pup still outstanding.
- zu Zug 108 (notiert vor Zug 109): HUD still shows Free Stat Points 5 despite the narrator confirming the #assign — possible display lag; will recheck later.
- zu Zug 110 (notiert vor Zug 111): Narrator earlier placed a scarred adult in the fight, but the engine shows only the pup (Gray Wolf Q) was engaged; pack count is 3/4, not 4/4.
- zu Zug 112 (notiert vor Zug 113): Repeated 'go: invalid local habitat scope' refusals when leaving the open heath; will try naming the den as destination, then consider returning to town with 3/4 if it persists.
- zu Zug 113 (notiert vor Zug 114): East Heath contract stuck at 3/4; engine refuses all travel toward the gorse den from the open heath ('invalid local habitat scope'). Will consider turning in or other work in town.
- zu Zug 115 (notiert vor Zug 116): Narrator calls the town Alderwatch, not Valedorn town; engine confirms location Alderwatch. Contract still 3/4, not turned in.
- zu Zug 116 (notiert vor Zug 117): Contradiction: HUD says Location Alderwatch while narrator/engine insists I'm still on the heath; travel to the Guild hall named as destination next.
- zu Zug 117 (notiert vor Zug 118): Now genuinely at the Guild hall per HUD; engine shop panel for skill primers appeared on arrival.
- zu Zug 120 (notiert vor Zug 121): Clerk earlier called rat pelts a copper each; confirming tails before selling.
- zu Zug 122 (notiert vor Zug 123): HUD shows an active 'Drive Out the Orchard Boar' contract slip already carried (0/1), separate from the Thornbury board notice.
- zu Zug 131 (notiert vor Zug 132): HUD now shows Marsh Serpent B as ENGAGED, so the earlier range refusals should be resolved.
- zu Zug 134 (notiert vor Zug 135): HUD shows two active hunts already (orchard boar 0/1, east heath pack 3/4), so the board's Boar Trouble may overlap; will check counts before taking more.
- zu Zug 135 (notiert vor Zug 136): Sleep was refused with 'arrival pending' though the HUD already shows the room; retrying now that arrival narration is done. Coin on HUD may not yet reflect the 80 cp primer purchase.
- zu Zug 136 (notiert vor Zug 137): Reading the primer was refused with 'no material' and Guard was not learned despite the purchase narration; recovery succeeded (HP/STA full).
- zu Zug 137 (notiert vor Zug 138): Bag shows no Primer of Guard despite narration of the purchase — the 80c buy was not recorded; skill not learned. Will retry purchase only if clerk still offers it.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t10 | 10 | 2 | – | nein | 2 | gewonnen, 48 XP |
| enc.t15 | 15 | 3 | – | nein | 3 | gewonnen, 72 XP |
| enc.t26 | 27 | 2 | – | nein | 2 | gewonnen, 240 XP |
| enc.t38 | 42 | 2 | – | nein | 2 | gewonnen, 264 XP |
| enc.t54 | 60 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t66 | 73 | 3 | – | nein | 3 | gewonnen, 456 XP |
| enc.t69r | 77 | 1 | – | nein | 1 | gewonnen, 204 XP |
| enc.t89r | 101 | 1 | – | nein | 1 | gewonnen, 96 XP |
| enc.t94 | 106 | 1 | – | nein | 1 | gewonnen, 144 XP |
| enc.t97 | 109 | 1 | – | nein | 1 | gewonnen, 144 XP |
| enc.t119 | 132 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t129 | 143 | 1 | – | nein | 1 | gewonnen, 144 XP |

## Quests

- **Cull the Marsh Serpent at Miller's Ford** — expired (Zug 51)
  - Aufgabe: Kill 1 marsh serpent at the ford below Miller's Mill. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 marsh serpent killed at the ford below Miller's Mill.
- **Cull the Wolves of the East Heath** — active (Zug 21) → completed (Zug 50), READY
  - Aufgabe: Kill 4 gray wolf at the East Heath pastures. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 gray wolf killed at the East Heath pastures.
- **Cull the Boars of Thornbury Orchard** — expired (Zug 51)
  - Aufgabe: Kill 3 tusked boar at the Thornbury cider orchards. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 tusked boar killed at the Thornbury cider orchards.
- **Cull the Bog Striders of the Reed Flats** — expired (Zug 51)
  - Aufgabe: Kill 6 bog strider at the eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 6 bog strider killed at the eel-weirs of the Reed Flats.
- **Clear the Old Crown Catacombs, Level 1** — expired (Zug 51), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of Old Crown Catacombs. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Old Crown Catacombs is clear.
- **Hunt the Serpent at Miller's Ford** — active (Zug 52) → completed (Zug 61)
  - Aufgabe: Kill 1 marsh serpent at the ford below Miller's Mill. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 marsh serpent killed at the ford below Miller's Mill.
- **Thin the East Heath Wolf Pack** — active (Zug 63) → completed (Zug 82)
  - Aufgabe: Kill 4 gray wolf at the East Heath pastures. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 gray wolf killed at the East Heath pastures.
- **Cull the Orchard Boar** — expired (Zug 83)
  - Aufgabe: Kill 3 tusked boar at the Thornbury cider orchards. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 tusked boar killed at the Thornbury cider orchards.
- **Clear the Reed Flats Striders** — expired (Zug 83)
  - Aufgabe: Kill 6 bog strider at the eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 6 bog strider killed at the eel-weirs of the Reed Flats.
- **Purge Old Crown Catacombs, Level 1** — expired (Zug 83), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of Old Crown Catacombs. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Old Crown Catacombs is clear.
- **Cull the Ford Serpent** — expired (Zug 97)
  - Aufgabe: Kill 1 marsh serpent at the ford below Miller's Mill. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 marsh serpent killed at the ford below Miller's Mill.
- **Thin the East Heath Wolf Pack** — expired (Zug 97)
  - Aufgabe: Kill 4 gray wolf at the East Heath pastures. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 gray wolf killed at the East Heath pastures.
- **Drive Out the Orchard Boar** — active (Zug 84)
  - Aufgabe: Kill 1 tusked boar at the Thornbury cider orchards. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 tusked boar killed at the Thornbury cider orchards.
- **Cull the Reed Flats Bog Striders** — expired (Zug 97)
  - Aufgabe: Kill 6 bog strider at the eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 6 bog strider killed at the eel-weirs of the Reed Flats.
- **Clear the Old Crown Catacombs, Level 1** — expired (Zug 97), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of Old Crown Catacombs. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Old Crown Catacombs is clear.
- **Serpent at the Ford** — active (Zug 123) → completed (Zug 133), READY
  - Aufgabe: Kill 1 marsh serpent at the ford below Miller's Mill. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 marsh serpent killed at the ford below Miller's Mill.
- **Cull the East Heath Pack** — active (Zug 98) → completed (Zug 145)
  - Aufgabe: Kill 4 gray wolf at the East Heath pastures. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 gray wolf killed at the East Heath pastures.
- **Boar Trouble at Thornbury** — expired (Zug 147)
  - Aufgabe: Kill 3 tusked boar at the Thornbury cider orchards. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 tusked boar killed at the Thornbury cider orchards.
- **Clear the Reed Flats Weirs** — expired (Zug 147)
  - Aufgabe: Kill 6 bog strider at the eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 6 bog strider killed at the eel-weirs of the Reed Flats.
- **Secure Old Crown Catacombs Level 1** — expired (Zug 147), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of Old Crown Catacombs. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Old Crown Catacombs is clear.
- **Drive Down the Tusked Boar of Thornbury** — active (Zug 148)
  - Aufgabe: Kill 3 tusked boar at the Thornbury cider orchards. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 tusked boar killed at the Thornbury cider orchards.

## Auffälligkeiten

- Zug 3, Nachricht 6 (extraction_repaired): the extractor's first answer needed a repair
- Zug 24, Nachricht 47 (planner_repaired): the planner's first answer needed a repair
- Zug 46, Nachricht 92 (extraction_repaired): the extractor's first answer needed a repair
- Zug 48, Nachricht 96 (extraction_repaired): the extractor's first answer needed a repair
- Zug 54, Nachricht 107 (planner_failed): the planner failed: sell seq 1: min_cp 30 is not what his words "three silver ten copper for the four pelts and ten fangs" say: 40 cp total for qty 4. min_cp is the TOTAL for the selected quantity; if he means several un
- Zug 54, Nachricht 107 (planner_repaired): the planner's first answer needed a repair
- Zug 55, Nachricht 109 (planner_repaired): the planner's first answer needed a repair
- Zug 61, Nachricht 122 (extraction_repaired): the extractor's first answer needed a repair
- Zug 85, Nachricht 169 (planner_repaired): the planner's first answer needed a repair
- Zug 89, Nachricht 177 (planner_failed): the planner failed: sell seq 1: min_cp 240 is not what his words "I take his hand. Four silver three for the lot, agreed." say: 43 cp total for qty 8. min_cp is the TOTAL for the selected quantity; if he means several un
- Zug 89, Nachricht 177 (planner_repaired): the planner's first answer needed a repair
- Zug 90, Nachricht 179 (planner_repaired): the planner's first answer needed a repair
- Zug 95, Nachricht 189 (planner_repaired): the planner's first answer needed a repair
- Zug 107, Nachricht 213 (stat_words): the player spent Stat Points in words, not with #assign; nothing was assigned (for review: did the story tell them as done?)
- Zug 115, Nachricht 230 (extraction_repaired): the extractor's first answer needed a repair
- Zug 128, Nachricht 256 (extraction_repaired): the extractor's first answer needed a repair
- Zug 135, Nachricht 270 (extraction_repaired): the extractor's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 15× keine gültige JSON-Entscheidung (Züge 2, 6, 10, 23, 26, 42, 51, 57, 58, 80, 108, 133, 141, 144, 150)

System-Panels: CLARIFY 5, NOT TAKEN 0, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: world_rule 24, engine_owned_fact 15, no_go 4, scene_context 19, npc_presence 1, npc_continuity 2, group_fact 1, coin_evidence 1, group_unclear 6, attack_commitment 3, engine_recovery 2, recover 1, offer 4, engine_booked 2, sale_evidence 6, guild_canon 1, quest_count 1, pc_inventory 4, guild_payout 1, guild_completion 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 15/150 Erstantworten ungültig (10.0 %); 15 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 147 | 7 | 2.8 s | 5.3 s | 12167 | 9956 | 88 | – | stop 147 | 0 |
| narrator | 133 | 0 | 9.1 s | 12.4 s | 11538 | 8773 | 409 | – | stop 133 | 0 |
| extract | 140 | 7 | 5.4 s | 9.8 s | 12631 | 9652 | 351 | – | stop 140 | 0 |
| board | 5 | 0 | 8.2 s | 9.0 s | 2528 | 2236 | 883 | – | stop 5 | 0 |
| forge | 1 | 0 | 1.6 s | 1.6 s | 395 | 0 | 64 | – | stop 1 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 62:42 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 16.3 s) | 0:35 min |
| 150 Züge, Spiel (Senden bis HUD nach der Extraktion) | 51:45 min — Median 20.7 s, p90 29.7 s, max 63.1 s |
| 150 Züge, Spieler-Entscheidung | 7:20 min — Median 2.3 s, 15 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 8:12 min / 0:41 min / 21:42 min / 14:48 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 23.6 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 15:45 min, 80 Züge ≈ 31:31 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spiel | 48 | – | 63.1 s | 20.7 s |
| Provider extract | 48 | 130 | 32.7 s | 5.4 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
