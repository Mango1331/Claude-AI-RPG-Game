# Avereth Live-Test 20261029-141843Z-current_test

## Kurzfassung

- **Laufprofil:** guild-mage; Startklasse Mage, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** abgebrochen: Limit erreicht — 150 turns
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 9. Sicherheitsgrenzen: 150 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** Level 7, 198 XP seit Levelaufstieg, 669 cp, HP 140, MP 310; Ort realm.valedorn_crown.fenn_crossing_ferry_landing. Ausrüstung und Skills stehen in evaluation.json → progression.checkpoint.
- **Charakter:** mage (mage.arcane_bolt, mage.arcane_wave) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: pragmatic adventurer: sell surplus loot and invest in useful equipment and techniques
- **Züge:** 150 · **Dauer:** 81:42 min · **LLM-Aufrufe der Engine/des Erzählers:** 432
- **Beobachtete Abdeckung:** 34 unterschiedliche gebuchte Reiseziele · 17 Kämpfe · 2 Verkäufe (188 cp Umsatz, ohne Questzahlungen/Geschenke) · 0 Ausrüstungswechsel · 0 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 28
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.117 |
| Git | a9a76eb3db94 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 15.9 s |
| Browser | chrome 156.0.8078.49 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261029-141843Z-current_test“, Seed 1271046154 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | Mage | Engine (Menü/Rückfrage) | creation_complete | Choose the Mage base class | public roadside verge outside Alderwatch | 90/84 | 2.3 s |
| 2 | I choose Arcane Wave and Arcane Bolt as my two starter skills. | Engine (Menü/Rückfrage) | creation_complete | Finish character creation with required AoE skill | public roadside verge outside Alderwatch | 90/96 | 2.1 s |
| 3 | I walk through the city gate into Alderwatch and head for the Adventurers' Guild to look at the contract board. | Erzähler | open_run_level | Enter city and find Guild contracts | Adventurers' Guild hall, Alderwatch | 90/96 | 35.3 s |
| 4 | I approach the clerk and ask to register with the Guild as a novice adventurer. | Erzähler | open_run_level | Register with the Guild before taking contracts | Adventurers' Guild hall, Alderwatch | 90/96 | 22.5 s |
| 5 | I pay the two silver and place my hand on the measuring stone to register. | Erzähler | open_run_level | Register with the Guild | Adventurers' Guild hall, Alderwatch | 90/96 | 38.2 s |
| 6 | I take the marsh wolf contract: "I'll take the Cull the Marsh Wolf Pack at the Fenn Crossing contract, please." | Erzähler | open_run_level | Accept first novice contract | Adventurers' Guild hall, Alderwatch | 90/96 | 26.2 s |
| 7 | I leave the Guild and head east along the river road toward Fenn Crossing to find the lame wolf at the ferry landing. | Erzähler | open_run_level | Travel to Fenn Crossing for the wolf contract | Fenn Crossing ferry landing | 90/96 | 32.9 s |
| 8 | I ask the boatmen to point out exactly where the wolf is lying, then circle around through the open ground on the rack side to get a clear v… | Erzähler | open_run_level | Scout the lame wolf's position before attacking | Open ground on the rack side | 90/96 | 66.7 s |
| 9 | I level my staff at the lame wolf and cast Arcane Bolt at it. | Erzähler | open_run_level | Attack the lame wolf from range | Open ground on the rack side | 90/86 | 93.8 s |
| 10 | I tell the boatmen the wolf is dead, then head back along the river road to Alderwatch to turn in the contract at the Guild hall. | Erzähler | open_run_level | Return to Guild for turn-in | Adventurers' Guild hall, Alderwatch | 90/86 | 52.5 s |
| 11 | "Just the one. What else is on the board for a Novice?" I look over the contract board for another achievable job. | Erzähler | open_run_level | Pick the next Guild contract | Adventurers' Guild hall, Alderwatch | 90/86 | 23.4 s |
| 12 | "The striders sound like my pace. I'll take Thin the Reed Flats Bog Striders, please. And where can I sell a marsh wolf pelt and fangs at th… | Erzähler | open_run_level | Accept the bog strider contract and ask about selling loot | Adventurers' Guild hall, Alderwatch | 90/86 | 44.9 s |
| 13 | I head out the Guild doors to the Marshalls' Yard by tannery row and offer my marsh wolf pelt and two fangs for sale. | Erzähler | open_run_level | Sell surplus loot at Marshalls' Yard | Marshalls' Yard | 90/86 | 96.4 s |
| 14 | "Twenty-five the lot works. I'll take it. | Erzähler | open_run_level | Accept merchant's offer | Marshalls' Yard | 90/86 | 20.7 s |
| 15 | "Just the coin, thanks. I'm off before the light goes." I pocket the coins and head for the Fenn road to find lodging for the night near the… | Erzähler | open_run_level | Finish trade, secure lodging before bog strider hunt | The Ferryhouse | 90/86 | 67.3 s |
| 16 | "Both, please — room and supper." I pay the ten copper and settle in for the night, sleeping until dawn. | Erzähler | open_run_level | Buy lodging and meal, sleep until dawn | The Ferryhouse | 90/96 | 24.7 s |
| 17 | I buy the porridge for a copper, eat, then head out the door and follow the sound of the weirs from the crossing into the reed flats. | Erzähler | open_run_level | Eat, then travel to the bog strider hunting grounds | eel-weirs of the Reed Flats | 90/96 | 73.3 s |
| 18 | I pick my way out along the stepping planks toward the second weir's platform, keeping my distance until I can target the striders clearly, … | Erzähler | open_run_level | Engage the bog striders for the contract | eel-weirs of the Reed Flats | 90/96 | 28.1 s |
| 19 | I move out along the planks toward the second weir until the striders are at MEDIUM range, then stop and cast Arcane Bolt at Bog Strider A. | Erzähler | open_run_level | Close to spell range and open the attack | eel-weirs of the Reed Flats | 90/86 | 35.0 s |
| 20 | I cast Arcane Wave, targeting both striders standing together at MEDIUM range. | Engine (Menü/Rückfrage) | open_run_level | Finish the bog strider contract with an AoE | eel-weirs of the Reed Flats | 90/86 | 5.2 s |
| 21 | I cast Arcane Wave on Bog Strider B. | Erzähler | open_run_level | Strike both striders with AoE, naming B as target | eel-weirs of the Reed Flats | 90/72 | 21.9 s |
| 22 | I cast Arcane Wave on Bog Strider B, hitting both at SHORT range. | Erzähler | open_run_level | Finish both striders with AoE | eel-weirs of the Reed Flats | 73/58 | 27.6 s |
| 23 | I hit the wounded Bog Strider B with Arcane Bolt to finish it. | Erzähler | open_run_level | Finish the last strider | eel-weirs of the Reed Flats | 73/48 | 36.9 s |
| 24 | #assign INT 5 WIL 5 | System (Befehl) | open_run_level | Spend 10 free stat points on INT and WIL | eel-weirs of the Reed Flats | 73/48 | 2.1 s |
| 25 | I search along the weir planks and reed line for the two remaining bog striders the contract requires. | Erzähler | open_run_level | Hunt the last two striders | eel-weirs of the Reed Flats | 73/48 | 59.0 s |
| 26 | I cast Arcane Wave at Bog Strider D and Bog Strider E on the hummock, timing it for when they stand close together. | Erzähler | open_run_level | Finish the contract with an AoE on the nesting pair | eel-weirs of the Reed Flats | 73/48 | 24.1 s |
| 27 | I advance onto the mud bank toward the hummock, and when Bog Strider D comes into MEDIUM range I cast Arcane Bolt at it. | Erzähler | open_run_level | Close to bolt range and snipe the striders one by one | eel-weirs of the Reed Flats | 73/38 | 33.5 s |
| 28 | I assign my 5 free stat points with #assign INT 3 WIL 2. | Erzähler | open_run_level | Spend level-up points | eel-weirs of the Reed Flats | 73/38 | 14.9 s |
| 29 | I follow the escaped strider's wake along the far channel, staying in cover, and cast Arcane Bolt at it when it comes into MEDIUM range. | Erzähler | open_run_level | Hunt the fifth and final strider | far channel bend | 73/38 | 36.7 s |
| 30 | I cast Arcane Bolt at Bog Strider F while it is still broadside in the shallows. | Erzähler | open_run_level | Finish the fifth strider for the contract | far channel bend | 73/28 | 22.7 s |
| 31 | I cast Arcane Bolt at Bog Strider F to finish it before it can lunge. | Erzähler | open_run_level | Kill the fifth strider | far channel bend | 73/18 | 31.2 s |
| 32 | I travel back to the Guild hall in the near town and turn in the completed contract, Thin the Reed Flats Bog Striders. | Erzähler | open_run_level | Turn in the finished contract | Adventurers' Guild hall, Alderwatch | 73/18 | 39.3 s |
| 33 | #assign INT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up stat points | Adventurers' Guild hall, Alderwatch | 73/18 | 2.1 s |
| 34 | #assign VIT 3 WIL 2 | System (Befehl) | open_run_level | Spend remaining free stat points | Adventurers' Guild hall, Alderwatch | 73/18 | 2.1 s |
| 35 | I ask the clerk for the Guild board's current postings suitable for a Novice mage. | Erzähler | open_run_level | Pick next Guild contract | Adventurers' Guild hall, Alderwatch | 73/18 | 41.6 s |
| 36 | I accept the Ferry Wolf contract from the board and confirm with the clerk that it is ACTIVE before heading out. | Erzähler | open_run_level | Take an achievable Novice contract | Fenn Crossing ferry landing | 73/18 | 29.7 s |
| 37 | I greet the woman at the jetty's head and ask where and when the marsh wolf shows itself, and whether I could rest here an hour first — I'm … | Erzähler | open_run_level | Gather wolf intel and recover MP | Fenn Crossing ferry landing | 73/18 | 25.8 s |
| 38 | I thank him and rest by the stove in the landing house until my spell strength is back, keeping an eye out through the window. | Engine (Menü/Rückfrage) | open_run_level | Recover MP before dusk fight | Fenn Crossing ferry landing | 73/18 | 4.8 s |
| 39 | I rest by the stove in the landing house for 2 hours, watching the far shallows through the window. | Erzähler | open_run_level | Recover MP for the dusk fight | Fenn Crossing ferry landing | 98/91 | 16.3 s |
| 40 | I ask the older boatman to point out exactly where she climbs onto the mudflat, then cross to the far bank an hour before dusk and find a co… | Erzähler | open_run_level | Position for the dusk wolf ambush | Far bank mudflat | 98/91 | 32.4 s |
| 41 | I slip behind the stand of dead brown stalks with a clear view of the mudflat's north end and wait, watching the waterline for the reeds to … | Erzähler | open_run_level | Ambush the ferry wolf at dusk | Far bank mudflat | 98/91 | 16.2 s |
| 42 | I hold still behind the dead stalks and watch the north end of the mudflat and the waterline as the light fades. | Erzähler | open_run_level | Wait for the ferry wolf's approach | Far bank mudflat | 98/91 | 40.6 s |
| 43 | I stay still until she commits, then hit her with Arcane Bolt the moment she turns toward the flat — and keep watching in case she charges. | Erzähler | open_run_level | Open the ambush with a bolt | Far bank mudflat | 98/81 | 15.9 s |
| 44 | I skin the wolf quickly for its pelt and fang, then cross back to the landing house in time for the last ferry at half past dark. | Erzähler | open_run_level | Loot the kill and catch the last ferry back | The Ferryhouse | 98/81 | 20.0 s |
| 45 | I warm up by the stove, eat, and sleep at the Ferryhouse until morning. | Erzähler | open_run_level | Recover overnight, then turn in the wolf contract | The Ferryhouse | 125/244 | 19.3 s |
| 46 | I eat a quick breakfast, then take the ferry across and head to the Guild hall to turn in the Cull the Ferry Wolf contract. | Erzähler | open_run_level | Turn in the completed wolf contract at the Guild hall | Adventurers' Guild hall, Alderwatch | 125/244 | 27.4 s |
| 47 | I ask the clerk what contracts the board has for a Novice, and whether a merchant in town buys bog strider chitin and venom glands. | Erzähler | open_run_level | Find new contracts and sell surplus loot | Adventurers' Guild hall, Alderwatch | 125/244 | 26.3 s |
| 48 | I accept the Cull the Marsh Wolf at Fenn Crossing contract, then head to Salter Hemm's shop on Cordwainer Row with the green awning and ask … | Erzähler | open_run_level | Take the achievable wolf cull and sell surplus strider loot | Cordwainer Row | 125/244 | 17.8 s |
| 49 | I lay the eleven chitin plates and three venom glands on his counter and ask what he'll pay for the lot. | Erzähler | open_run_level | Get Hemm's offer for the strider loot | Cordwainer Row | 125/244 | 15.0 s |
| 50 | I accept the offer and sell him all eleven plates and three glands for 163 copper. | Engine (Menü/Rückfrage) | open_run_level | Sell surplus strider loot at Hemm's confirmed offer | Cordwainer Row | 125/244 | 9.1 s |
| 51 | I sell Salter Hemm all eleven bog strider chitin plates and three venom glands at his offered price of 163 copper. | Erzähler | open_run_level | Complete the confirmed sale at Hemm's stated offer | Cordwainer Row | 125/244 | 15.9 s |
| 52 | I pocket the coin and head back to the Guild hall to check the board for the eel-weirs job and other Novice contracts. | Erzähler | open_run_level | Find the eel-weirs contract at the Guild board | Adventurers' Guild hall, Alderwatch | 125/244 | 22.3 s |
| 53 | I accept the Cull Bog Striders at the Eel-Weirs contract from the board. | Erzähler | open_run_level | Take the achievable eel-weirs cull contract | Adventurers' Guild hall, Alderwatch | 125/244 | 14.2 s |
| 54 | I head south down the Reed Flats road toward the eel-weirs to hunt bog striders. | Erzähler | open_run_level | Travel to the eel-weirs for the strider cull | eel-weirs of the Reed Flats | 125/244 | 19.2 s |
| 55 | I head out along the outer walkways to look for the big striders under the boards. | Erzähler | open_run_level | Hunt bog striders for the cull contract | outer walkways | 125/244 | 32.2 s |
| 56 | I cast Arcane Wave at the strider on the trap-poles, targeting it so the blast is centered away from the walkway beneath me. | Erzähler | open_run_level | Open the strider fight with AoE on the visible target | outer walkways | 125/230 | 18.6 s |
| 57 | I cast Arcane Bolt at the strider on the walkway. | Erzähler | open_run_level | Finish the wounded strider with a stronger bolt | outer walkways | 125/220 | 17.9 s |
| 58 | I keep hunting along the outer walkways for more bog striders toward the 5-kill count. | Erzähler | open_run_level | Continue the strider cull | outer walkways | 125/220 | 20.6 s |
| 59 | I cast Arcane Wave at the strider tending the eggs, aiming from where I stand so the blast is centered on it alone. | Erzähler | open_run_level | Attack strider H to advance the 5-kill cull | outer walkways | 125/206 | 26.4 s |
| 60 | I keep hunting along the outer walkways for the third bog strider toward the 5-kill count, watching the dark water where the third ripple we… | Erzähler | open_run_level | Continue strider cull | outer walkways | 125/206 | 27.7 s |
| 61 | I walk over to the old man at the head of the walkway. "Looking for more striders — seen any others about, or know where they hide?" | Erzähler | open_run_level | Ask the villager where more striders may be | outer walkways | 125/206 | 42.6 s |
| 62 | I head downstream to the collapsed weir rack and search the gap beneath it for the remaining striders. | Erzähler | open_run_level | Hunt striders at the den under the collapsed rack | collapsed weir rack | 125/206 | 26.1 s |
| 63 | I cast Arcane Bolt at the strider under the rack before it can slip out to the channel. | Erzähler | open_run_level | Attack the denning strider | collapsed weir rack | 125/196 | 19.9 s |
| 64 | I wade to the drifting strider and cut loose its chitin plates and venom glands, then search the shallows along the rack for the fifth strid… | Erzähler | open_run_level | Loot the kill and hunt the last strider | reed hollow wallow | 125/196 | 38.2 s |
| 65 | I cast Arcane Wave into the barrel-wide hole, centering the blast on whatever breathes inside. | Engine (Menü/Rückfrage) | open_run_level | Kill the fifth strider in its den with AoE | reed hollow wallow | 125/196 | 6.4 s |
| 66 | I step to the mouth of the barrel-wide hole and cast Arcane Wave into the dark at the breathing thing inside it. | Engine (Menü/Rückfrage) | open_run_level | Kill the fifth strider with a targetable AoE cast | reed hollow wallow | 125/196 | 4.2 s |
| 67 | I jab my staff into the mouth of the barrel-wide hole to drive the strider out into the open. | Engine (Menü/Rückfrage) | open_run_level | Flush the fifth strider into a targetable position | reed hollow wallow | 125/196 | 5.7 s |
| 68 | I back away from the hole and stand still in the reeds, waiting quietly to see if the strider emerges. | Erzähler | open_run_level | Make the hidden fifth strider surface as a targetable actor | reed hollow wallow | 125/196 | 19.2 s |
| 69 | I cast Arcane Bolt at Bog Strider J. | Erzähler | open_run_level | Kill the fifth strider to complete the cull | reed hollow wallow | 83/186 | 15.3 s |
| 70 | I cast Arcane Bolt at Bog Strider J. | Erzähler | open_run_level | Finish the wounded strider | reed hollow wallow | 83/176 | 17.9 s |
| 71 | #quest Cull Bog Striders at the Eel-Weirs | System (Befehl) | open_run_level | Verify the fifth strider kill registered on the cull contract | reed hollow wallow | 83/176 | 2.6 s |
| 72 | #audit | System (Befehl) | open_run_level | Check why the fifth strider kill has not registered on the cull count | reed hollow wallow | 83/176 | 2.5 s |
| 73 | I search the eel-weirs and surrounding reed beds for another bog strider to finish the cull. | Erzähler | open_run_level | Find and kill the fifth countable strider | reed hollow wallow | 83/176 | 18.4 s |
| 74 | I give up the search and head back along the Reed Flats road to the Guild hall in Valedorn Crown to report the four confirmed strider kills … | Erzähler | open_run_level | Turn in what is done and resolve the stuck count | Adventurers' Guild hall, Crownheart | 83/176 | 30.0 s |
| 75 | "I'll leave it open. Meanwhile, do you have any other Novice contracts I could take that don't need me back in the marsh? I'll handle the fi… | Erzähler | open_run_level | Keep the cull open and look for another achievable contract | Adventurers' Guild hall, Crownheart | 83/176 | 21.3 s |
| 76 | I thank the clerk and go to the broker's side counter before the eighth bell to sell the four strider chitin plates and any venom glands I'm… | Erzähler | open_run_level | Sell surplus strider loot at the broker's window | Adventurers' Guild hall, Crownheart | 83/176 | 28.2 s |
| 77 | I accept the broker's offer and hand over the nine plates and three venom glands for his named price. | Erzähler | open_run_level | Sell strider loot before the eighth bell | Adventurers' Guild hall, Crownheart | 83/176 | 31.0 s |
| 78 | I head to Healer's Row off the market square and ask the temple healer to treat my wounded arm and leg. | Erzähler | open_run_level | Get wounds treated at the temple | Healer's Row | 83/176 | 28.4 s |
| 79 | Both, please — clean and stitch the arm, and I'll take the salve as well. | Erzähler | open_run_level | Get the arm treated and buy the salve | Healer's Row | 83/176 | 21.5 s |
| 80 | #assign WIL 2 INT 2 VIT 1 | System (Befehl) | open_run_level | Spend free stat points before resting | Healer's Row | 83/176 | 2.5 s |
| 81 | I find lodging for the night near the market square and sleep until morning. | Erzähler | open_run_level | Recover overnight before finishing the strider cull | Merrow's Rest | 83/176 | 18.5 s |
| 82 | I pay the girl at the hearth four copper for the bed and supper, then eat and sleep until morning. | Erzähler | open_run_level | Buy lodging and supper, then sleep | Merrow's Rest | 83/176 | 29.2 s |
| 83 | I book the bed in the loft from the innkeeper for two copper, then pay for the supper separately. | Erzähler | open_run_level | Book lodging and meal as separate purchases | Merrow's Rest | 83/176 | 27.5 s |
| 84 | I sleep in the booked loft bed until morning. | Erzähler | open_run_level | Recover overnight with the room already booked | Merrow's Rest | 135/280 | 16.3 s |
| 85 | I eat breakfast downstairs, then head for the Eel-Weirs to hunt the last bog strider. | Erzähler | open_run_level | Finish the strider cull | Merrow's Rest | 135/280 | 24.1 s |
| 86 | I'll take the two-copper porridge breakfast, please, then head for the Eel-Weirs to hunt the last bog strider. | Erzähler | open_run_level | Buy breakfast at the stated price, then finish the strider cull | eel-weirs of the Reed Flats | 135/280 | 27.6 s |
| 87 | I ask the old pipe-man whether he's seen a fifth bog strider, and where the last one might be hiding. | Erzähler | open_run_level | Locate the last strider via the fisher | eel-weirs of the Reed Flats | 135/280 | 35.2 s |
| 88 | I thank the fishers and head carefully out along the walkways toward the third weir, keeping my weight light on the boards and watching the … | Erzähler | open_run_level | Hunt the last bog strider past the third weir | third weir | 135/280 | 30.5 s |
| 89 | I open the fight from range, casting Arcane Bolt at the big strider's head before it can close. | Erzähler | open_run_level | Engage the fifth strider at range | third weir | 135/270 | 50.6 s |
| 90 | I collect the two chitin plates and head back along the walkways toward the fishers' camp before dark. | Erzähler | open_run_level | Return with proof for the strider cull turn-in | fishers' camp | 135/270 | 29.9 s |
| 91 | I accept a bowl of the eel soup, thank the fishers for the tip about the big one, and set out for the Guild hall in Valedorn Crown to turn i… | Erzähler | open_run_level | Travel to the Guild hall for the strider cull turn-in | Adventurers' Guild hall, Alderwatch | 135/270 | 22.8 s |
| 92 | #assign INT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up stat points | Adventurers' Guild hall, Alderwatch | 135/270 | 2.5 s |
| 93 | I ask the clerk what's on the board for a Novice — anything suitable for tomorrow? | Erzähler | open_run_level | Check the Guild board for new contracts | Adventurers' Guild hall, Alderwatch | 135/270 | 25.2 s |
| 94 | I ask the clerk to recommend a cheap bed for the night, then head there and sleep until morning. | Erzähler | open_run_level | Lodging and recovery before the Fenn Crossing wolf hunt | Droner's lodging house | 135/270 | 61.7 s |
| 95 | I pay Marta for the night and sleep until morning. | Erzähler | open_run_level | Complete overnight recovery | Droner's lodging house | 140/324 | 24.0 s |
| 96 | I pay Marta two coppers for last night's bed, then head to the Guild hall to turn in the marsh wolf contract. | Erzähler | open_run_level | Settle lodging, turn in wolf contract | Adventurers' Guild hall, Alderwatch | 140/324 | 22.5 s |
| 97 | The wolf may still be walking the landing — I'll go back and do the deed properly. I head out to Fenn Crossing to hunt the marsh wolf. | Erzähler | open_run_level | Re-hunt the marsh wolf so the contract kill is recorded | Fenn Crossing ferry landing | 140/324 | 31.9 s |
| 98 | I ask the boatman where the wolf lairs, or whether waiting near the churned flat is my best chance of catching it. | Erzähler | open_run_level | Get tactical info before hunting the marsh wolf | Fenn Crossing ferry landing | 140/324 | 29.6 s |
| 99 | I take his advice and set up an ambush behind the fallen alder on the flat, watching the mudflat with the wind in my face. | Erzähler | open_run_level | Ambush the marsh wolf at the drinking spot | Fenn Crossing ferry landing | 140/324 | 20.1 s |
| 100 | I rise from behind the fallen alder and cast Arcane Wave at the wolf at fifteen paces. | Erzähler | open_run_level | Attack the marsh wolf from ambush | Fenn Crossing ferry landing | 140/310 | 21.9 s |
| 101 | I head back to the Droner's Rest Guild hall to turn in the marsh wolf contract. | Erzähler | open_run_level | Turn in the completed wolf contract | Adventurers' Guild hall, Alderwatch | 140/310 | 36.1 s |
| 102 | I ask the clerk to show me the contracts currently posted on the board. | Erzähler | open_run_level | Pick the next Guild contract | Adventurers' Guild hall, Alderwatch | 140/310 | 30.5 s |
| 103 | I take the Bog Striders contract slip to the clerk and ask to accept it, then travel to the Reed Flats eel-weirs to hunt bog striders. | Erzähler | open_run_level | Accept the Reed Flats cull contract and start it | eel-weirs of the Reed Flats | 140/310 | 25.8 s |
| 104 | I follow the three-toed prints along the platform edge toward the far fences, staff ready, watching the water for movement. | Erzähler | open_run_level | Hunt the bog striders toward the far fences | far fences | 140/310 | 27.7 s |
| 105 | I cast Arcane Wave at the near strider while the other two are still facing away. | Erzähler | open_run_level | Open the fight with AoE on the closest strider | far fences | 126/296 | 22.6 s |
| 106 | I strike the wounded strider with my staff to finish it. | Erzähler | open_run_level | Kill strider L before the others close | far fences | 126/296 | 20.6 s |
| 107 | I follow the tracks of the two withdrawn striders toward the deeper channels to the southeast, keeping low and watching the reeds. | Erzähler | open_run_level | Track the remaining striders for the cull contract | collapsed fence pool | 126/296 | 45.3 s |
| 108 | I cast Arcane Wave at the nearer strider while both are still feeding. | Erzähler | open_run_level | Open the fight with AoE against the pair at LONG range | collapsed fence pool | 126/296 | 20.2 s |
| 109 | I circle along the mud ridge toward the dead reeds, keeping to the reed cover, trying to close to MEDIUM range on the pair without being see… | Erzähler | open_run_level | Close range for Arcane Wave | collapsed fence pool | 126/296 | 23.8 s |
| 110 | I cast Arcane Wave at the nearer strider, now at MEDIUM range. | Erzähler | open_run_level | Open the fight with Arcane Wave at effective range | collapsed fence pool | 126/282 | 18.1 s |
| 111 | #assign INT 3 WIL 2 | System (Befehl) | open_run_level | Spend the level-up stat points | collapsed fence pool | 126/282 | 2.6 s |
| 112 | I collect the chitin plates and venom gland from the two defeated striders, then head back along the ridge toward Hemm's eel-weirs. | Erzähler | open_run_level | Loot and return to Hemm for the cull turn-in and sales | Hemm's eel-weirs | 126/282 | 38.0 s |
| 113 | I knock on Hemm's open door and report the six striders killed, then offer to sell him my seven chitin plates and two venom glands. | Erzähler | open_run_level | Turn in the cull count and sell loot to Hemm | Hemm's eel-weirs | 126/282 | 25.6 s |
| 114 | I walk down the lower weirs toward the swinging lantern and call out to whoever is there, looking for Hemm. | Erzähler | open_run_level | Find Hemm to turn in the cull and sell loot | lower weirs lantern spot | 126/282 | 26.2 s |
| 115 | "Six is all of them that were at the drowned fences," I say. "Let me help carry Hemm up to his hut, then I'll sell him the plates and glands… | Erzähler | open_run_level | Turn in the cull and sell loot to Hemm, help him to the hut | Hemm's hut | 126/282 | 43.3 s |
| 116 | "Done — a hundred copper for the lot," I say, accepting Hemm's offer for the seven plates and two venom glands. | Erzähler | open_run_level | Accept the confirmed loot sale offer | Hemm's hut | 126/282 | 32.3 s |
| 117 | I eat a quick bowl of Salta's stew, then set out for the Guild hall in Marsh Hollow to turn in the strider cull before the counter shuts. | Erzähler | open_run_level | Turn in the cull contract at the Marsh Hollow Guild | Marsh Hollow Guild hall | 126/282 | 25.9 s |
| 118 | "Can't wait — I'm here to turn in the strider cull, six of six at the Reed Flats," I tell the clerk, laying the Guild plate on the counter. | Erzähler | open_run_level | Turn in the cull contract before the counter shuts | Marsh Hollow Guild hall | 126/282 | 29.8 s |
| 119 | "Alaric Red," I tell the clerk. "Alaric Red, Novice." | Erzähler | open_run_level | Give my name for the roll and collect the 140 copper payout | Marsh Hollow Guild hall | 126/282 | 37.1 s |
| 120 | I thank the clerk and head to the Lamplighter to ask for a bed for the night. | Erzähler | open_run_level | Recover overnight at the inn | the Lamplighter | 126/282 | 28.2 s |
| 121 | "Evening — I'll take a bed for the night," I tell the innkeeper. | Erzähler | open_run_level | Buy lodging and sleep until morning | the Lamplighter | 126/282 | 16.8 s |
| 122 | I'll take the small room with the bolt and a bowl of the stew — nine copper, please. | Erzähler | open_run_level | Buy lodging and a meal, then sleep until morning | the Lamplighter | 126/282 | 25.6 s |
| 123 | I bolt the door and sleep until morning. | Erzähler | open_run_level | Sleep overnight to recover | the Lamplighter | 145/368 | 18.4 s |
| 124 | I head to the Guild hall and ask the clerk to turn in the Bog Strider cull — six striders done. | Erzähler | open_run_level | Turn in the completed cull contract | Marsh Hollow Guild hall | 145/368 | 19.3 s |
| 125 | I take the slip back and head to the Reed Flats to cull the remaining three Bog Striders. | Erzähler | open_run_level | Finish the strider cull (3/6) to close the contract | eel-weirs of the Reed Flats | 145/368 | 17.3 s |
| 126 | I follow the knocking out past the far weir and search the deep reed beds for the remaining three Bog Striders. | Erzähler | open_run_level | Hunt the last three striders to finish the cull | deep reed beds | 145/368 | 38.9 s |
| 127 | I cast Arcane Wave into the dense stand where the reeds swayed. | Engine (Menü/Rückfrage) | open_run_level | Engage the hiding Bog Striders with AoE | deep reed beds | 145/368 | 22.0 s |
| 128 | I wait and watch the dense stand, calling out a challenge to draw the Bog Striders into the open. | Erzähler | open_run_level | Provoke striders to appear as targetable actors | deep reed beds | 145/368 | 21.1 s |
| 129 | I cast Arcane Bolt at Bog Strider Q. | Erzähler | open_run_level | Fight the last three striders | deep reed beds | 145/358 | 49.8 s |
| 130 | I follow the knocking deeper into the dense reed stand to find the two striders that fled, keeping my staff ready. | Erzähler | open_run_level | Hunt the remaining two striders to finish the cull | strider home pool | 145/358 | 37.8 s |
| 131 | I turn and cast Arcane Bolt at Bog Strider T, the one bursting from the reeds at the pool's edge. | Engine (Menü/Rückfrage) | open_run_level | Fight the two remaining striders to finish the cull | strider home pool | 145/358 | 8.0 s |
| 132 | I turn and cast Arcane Bolt at Bog Strider U, the one bursting from the reeds at the pool's edge. | Erzähler | open_run_level | Attack the strider springing toward me | strider home pool | 145/348 | 27.9 s |
| 133 | I follow the deep knocking trail into the reeds to find the last strider and finish the cull. | Erzähler | open_run_level | Hunt the final strider for the contract | drowned thicket den | 145/348 | 23.7 s |
| 134 | I cast Arcane Bolt at Bog Strider V on the ramp. | Erzähler | open_run_level | Finish the cull by killing the last strider | drowned thicket den | 145/338 | 21.5 s |
| 135 | I head back out of the reeds toward the weirs and the Guild to turn in the completed cull contract. | Erzähler | open_run_level | Return and turn in the finished contract | Adventurers' Guild hall, Alderwatch | 145/338 | 20.6 s |
| 136 | I ask the clerk to show me the current contract board. | Erzähler | open_run_level | Check the board for new achievable contracts, ideally the eel-weirs job so Hemm buys my pl… | Adventurers' Guild hall, Alderwatch | 145/338 | 35.4 s |
| 137 | I take the fresh "Cull the Bog Striders at the Reed Flats Eel-Weirs (5)" slip from the board and ask the clerk to register me for that contr… | Erzähler | open_run_level | Accept the eel-weirs cull contract | Adventurers' Guild hall, Alderwatch | 145/338 | 21.8 s |
| 138 | I stop by Hemm's hut on the way west and sell him my four bog strider plates and the venom gland, then head to the Reed Flats eel-weirs to h… | Erzähler | open_run_level | Sell loot to Hemm, then start the new strider cull | eel-weirs of the Reed Flats | 145/338 | 57.2 s |
| 139 | I thank the old man and head south along the weir line toward the lower traps to find the new strider cohort. | Erzähler | open_run_level | Hunt the new strider cohort for the active 0/5 contract | lower traps along the weir line | 145/338 | 27.2 s |
| 140 | I ambush the striders with Arcane Wave at the nearest cluster in the shaded pool. | Erzähler | open_run_level | Start the cull with an AoE on the grouped striders | lower traps along the weir line | 145/324 | 20.8 s |
| 141 | #assign INT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up stat points | lower traps along the weir line | 145/324 | 2.8 s |
| 142 | I head back north along the weir line to Hemm's hut to sell the twelve plates and two glands, then return to the Guild hall to turn in the c… | Erzähler | open_run_level | Sell loot and turn in the finished strider cull | Adventurers' Guild hall, Alderwatch | 145/324 | 69.9 s |
| 143 | I ask the clerk what contracts are on the board for a Novice mage, and whether any can be handled tonight or first thing tomorrow. | Erzähler | open_run_level | Pick the next Guild contract from the actual board | Adventurers' Guild hall, Alderwatch | 145/324 | 27.9 s |
| 144 | I accept the Barrow Boar cull contract from the clerk and confirm it is ACTIVE, then ask where I can find cheap lodging for the night. | Erzähler | open_run_level | Take the boar contract and sleep in town before a first-light hunt | Adventurers' Guild hall, Alderwatch | 145/324 | 35.8 s |
| 145 | I head to the Wether's Rest, take a shared bunk for two copper, and sleep until morning. | Erzähler | open_run_level | Lodge overnight before the boar hunt at first light | The Wether's Rest | 145/324 | 38.9 s |
| 146 | I pay the innkeeper two copper for the shared bunk in the loft, and once it's booked I sleep until morning. | Erzähler | open_run_level | Book the bunk explicitly, then sleep | The Wether's Rest | 150/412 | 19.5 s |
| 147 | I head out the Southgate and follow the hedged lane south to Barrowfield Homestead Edge to hunt the boar. | Erzähler | open_run_level | Travel to the boar contract site at first light | Barrowfield homestead edge | 150/412 | 27.4 s |
| 148 | I follow the fresh rooting trail south from the broken fence toward the barrow mounds, tracking the boar. | Erzähler | open_run_level | Track the boar toward the mounds for the cull contract | barrow mounds | 150/412 | 25.3 s |
| 149 | I creep over the mound crest and, once I have a clear line on the boar, cast Arcane Bolt at it. | Engine (Menü/Rückfrage) | open_run_level | Ambush the barrow boar to progress the cull contract | barrow mounds | 150/412 | 5.9 s |
| 150 | I move toward the rooting sounds past the fourth mound until the boar is actually in sight, then cast Arcane Bolt at it. | Erzähler | open_run_level | Engage the boar once it is a valid target | hollow past the fourth mound | 150/412 | 55.4 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 17 (notiert vor Zug 18): Three striders grouped on one platform — Arcane Wave could hit all three if they close in; Arcane Bolt is safer for the opener at range.
- zu Zug 32 (notiert vor Zug 33): HUD says Free Stat Points 10 and payout 1s40, but engine result said +5 points and 1g4s paid; trusting the engine result.
- zu Zug 33 (notiert vor Zug 34): Payout contradiction persists: engine credited 1g4s, clerk said 1s40; coin total matches engine. HUD Free Stat Points figure was stale; System confirms 5 left.
- zu Zug 34 (notiert vor Zug 35): Stat points fully spent; MP low (18/204) and wounded — recovery needed before next fight.
- zu Zug 47 (notiert vor Zug 48): Clerk left the wolf slip untorn despite earlier turn-in result already paying and filing it; I'll re-verify status if the contract doesn't activate.
- zu Zug 52 (notiert vor Zug 53): Wolf contract still shows 0/1 despite earlier turn-in narration; will verify with #quest if it persists.
- zu Zug 53 (notiert vor Zug 54): Wolf contract slip still carried and shows 0/1 despite earlier turn-in narration; will verify at next Guild return.
- zu Zug 65 (notiert vor Zug 66): Arcane Wave refused an unnamed 'whatever breathes' target; quest panel still shows 3/5, so only the four bolt-kills plus the wave-killed denner may not all be counted — will check counts after this fight.
- zu Zug 70 (notiert vor Zug 71): Engine confirmed Bog Strider J defeated, but quest panel still shows 4/5 — checking whether the count updates.
- zu Zug 71 (notiert vor Zug 72): Engine confirmed Bog Strider J defeated (+206 XP) but the quest panel still shows 4/5 — auditing recorded changes.
- zu Zug 72 (notiert vor Zug 73): Engine confirms Bog Strider J defeated but counts only 4/5 — one earlier kill did not register as a countable population kill.
- zu Zug 82 (notiert vor Zug 83): Engine refused the combined purchase despite the girl taking coins in narration; narration and engine result conflicted.
- zu Zug 91 (notiert vor Zug 92): Turn-in paid out despite narration saying one gold forty vs engine 1g5s earlier — engine confirmed 6g6s9c total.
- zu Zug 94 (notiert vor Zug 95): HUD still shows Day 5 04:10 night despite narration of a full night's sleep at Droner's — time may not have updated; will recheck after this sleep.
- zu Zug 96 (notiert vor Zug 97): Engine counts 0/1 marsh wolf despite the READY slip; the earlier kill was never recorded against the contract. Selling pelt/fang to a broker is the fallback.
- zu Zug 114 (notiert vor Zug 115): Quest panel still shows 3/6 despite six kills reported; may need Guild turn-in.
- zu Zug 115 (notiert vor Zug 116): HUD shows 'the coin Hemm counted out' already carried — will verify sale registered via #bag after confirmation.
- zu Zug 116 (notiert vor Zug 117): Hemm's hundred copper is carried as 'the coin Hemm counted out'; sale registered. Quest panel still shows 3/6 despite six kills — Guild turn-in needed.
- zu Zug 120 (notiert vor Zug 121): Engine refused 'ask for a bed' as arrival pending; now at the counter with the innkeeper engaged.
- zu Zug 124 (notiert vor Zug 125): Clerk says the seal only recorded 3 of 6 kills; contract shows 3/6, needs 3 more.
- zu Zug 129 (notiert vor Zug 130): Combat confirmed Q defeated; contract now 4/6. R and S withdrew into the stand.
- zu Zug 131 (notiert vor Zug 132): The System labels differ from narration: the pool's-edge springer is U, the one behind is T.
- zu Zug 132 (notiert vor Zug 133): HUD says 5/6 but narration claims six down; newest System count is authoritative — one strider remains.
- zu Zug 134 (notiert vor Zug 135): Contract shows READY FOR TURN-IN at 6/6; Hemm buys plates (8 cp) and glands (25 cp) if I took the eel-weirs job — worth selling loot on return.
- zu Zug 136 (notiert vor Zug 137): HUD confirms turn-in paid: 8g 4s 5cp, XP 758/800, nearly Level 9. Board has a new 5-strider eel-weirs cull; Hemm buys plates and glands if I take it.
- zu Zug 139 (notiert vor Zug 140): HUD still lists stale 'Here' entries (den strider, marsh wolf, Hemm) despite Engine confirming the five new striders W–27; trusting the Engine panel.
- zu Zug 142 (notiert vor Zug 143): Engine confirmed contract payout and coin; HUD 'Here' entries are still stale (marsh wolf, Hemm promise) despite completed quest.
- zu Zug 145 (notiert vor Zug 146): Engine refused the combined buy+sleep; bunk must be purchased as its own confirmed action.
- zu Zug 146 (notiert vor Zug 147): HUD 'Here' entries still stale (marsh wolf, Hemm promise) despite being elsewhere; recovery confirmed full HP/MP.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t9 | 9 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t19 | 19 | 3 | – | nein | 3 | gewonnen, 504 XP |
| enc.t25 | 27 | 1 | – | nein | 1 | gewonnen, 120 XP |
| enc.t28 | 30 | 1 | – | nein | 1 | gewonnen, 168 XP |
| enc.t38 | 43 | 1 | – | ja | 1 | gewonnen, 24 XP |
| enc.t50 | 56 | 1 | – | nein | 1 | gewonnen, 168 XP |
| enc.t53 | 59 | 1 | – | nein | 1 | gewonnen, 96 XP |
| enc.t57 | 63 | 1 | – | nein | 1 | gewonnen, 146 XP |
| enc.t60 | 69 | 1 | – | nein | 1 | gewonnen, 206 XP |
| enc.t77 | 89 | 1 | – | nein | 1 | gewonnen, 120 XP |
| enc.t87 | 100 | 1 | – | nein | 1 | gewonnen, 30 XP |
| enc.t92 | 105 | 1 | – | nein | 1 | gewonnen, 168 XP |
| enc.t97 | 110 | 2 | – | nein | 2 | gewonnen, 312 XP |
| enc.t114 | 129 | 1 | – | nein | 1 | gewonnen, 168 XP |
| enc.t116 | 132 | 1 | – | nein | 1 | gewonnen, 120 XP |
| enc.t118 | 134 | 1 | – | nein | 1 | gewonnen, 146 XP |
| enc.t124 | 140 | 5 | – | nein | 5 | gewonnen, 624 XP |

## Quests

- **Cull the Marsh Wolf Pack at the Fenn Crossing** — active (Zug 6) → completed (Zug 10), READY
  - Aufgabe: Kill 1 lame marsh wolf at Fenn Crossing ferry landing. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 lame marsh wolf killed at Fenn Crossing ferry landing.
- **Thin the Reed Flats Bog Striders** — active (Zug 12) → completed (Zug 32), READY
  - Aufgabe: Kill 5 bog striders at eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 5 bog striders killed at eel-weirs of the Reed Flats.
- **Cull the Barrowfield Boar Sounder** — expired (Zug 35)
  - Aufgabe: Kill 4 Barrowfield boars at Barrowfield homestead edge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 Barrowfield boars killed at Barrowfield homestead edge.
- **Slay the Pale Stag of the Hollow Wood** — expired (Zug 35)
  - Aufgabe: Kill 1 the pale stag at Hollow Wood. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the pale stag killed at Hollow Wood.
- **Purge Old Crown Catacombs, Level 1** — expired (Zug 35), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of Old Crown Catacombs. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Old Crown Catacombs is clear.
- **Cull the Ferry Wolf at Fenn Crossing** — active (Zug 36) → completed (Zug 46)
  - Aufgabe: Kill 1 marsh wolf at Fenn Crossing ferry landing. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 marsh wolf killed at Fenn Crossing ferry landing.
- **Thin the Bog Striders at the Reed Flats** — expired (Zug 47)
  - Aufgabe: Kill 6 bog strider at eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 6 bog strider killed at eel-weirs of the Reed Flats.
- **Drive the Barrow Boars from Barrowfield** — expired (Zug 47)
  - Aufgabe: Kill 4 barrow boar at Barrowfield homestead edge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 barrow boar killed at Barrowfield homestead edge.
- **Cull the Pale Stag of Hollow Wood** — expired (Zug 47)
  - Aufgabe: Kill 1 pale stag at Hollow Wood. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 pale stag killed at Hollow Wood.
- **Clear Old Crown Catacombs Level 1** — expired (Zug 47), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of Old Crown Catacombs. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Old Crown Catacombs is clear.
- **Cull the Marsh Wolf at Fenn Crossing** — active (Zug 48) → completed (Zug 101), READY
  - Aufgabe: Kill 1 marsh wolf at Fenn Crossing ferry landing. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 marsh wolf killed at Fenn Crossing ferry landing.
- **Cull Bog Striders at the Eel-Weirs** — active (Zug 53) → completed (Zug 91), READY
  - Aufgabe: Kill 5 bog strider at eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 5 bog strider killed at eel-weirs of the Reed Flats.
- **Cull Barrow Boar on the Barrowfield Edge** — expired (Zug 93)
  - Aufgabe: Kill 3 barrow boar at Barrowfield homestead edge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 barrow boar killed at Barrowfield homestead edge.
- **Hunt the Pale Stag of Hollow Wood** — expired (Zug 93)
  - Aufgabe: Kill 1 pale stag at Hollow Wood. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 pale stag killed at Hollow Wood.
- **Clear Old Crown Catacombs Level 1** — expired (Zug 93), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of Old Crown Catacombs. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Old Crown Catacombs is clear.
- **Cull the Marsh Wolf at Fenn Crossing** — expired (Zug 102)
  - Aufgabe: Kill 1 marsh wolf at Fenn Crossing ferry landing. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 marsh wolf killed at Fenn Crossing ferry landing.
- **Cull Bog Striders at the Eel-Weirs** — expired (Zug 102)
  - Aufgabe: Kill 6 bog striders at eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 6 bog striders killed at eel-weirs of the Reed Flats.
- **Cull the Barrow Boar Sounder** — expired (Zug 102)
  - Aufgabe: Kill 4 barrow boars at Barrowfield homestead edge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 barrow boars killed at Barrowfield homestead edge.
- **Hunt the Pale Stag of Hollow Wood** — expired (Zug 102)
  - Aufgabe: Kill 1 pale stag at Hollow Wood. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 pale stag killed at Hollow Wood.
- **Clear the Upper Galleries of Old Crown Catacombs** — expired (Zug 102), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of Old Crown Catacombs. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Old Crown Catacombs is clear.
- **Cull the Ferry Wolf at Fenn Crossing** — expired (Zug 136)
  - Aufgabe: Kill 1 marsh wolf at Fenn Crossing ferry landing. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 marsh wolf killed at Fenn Crossing ferry landing.
- **Cull the Bog Striders at the Reed Flats** — active (Zug 103) → completed (Zug 135), READY
  - Aufgabe: Kill 6 bog strider at eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 6 bog strider killed at eel-weirs of the Reed Flats.
- **Cull the Barrow Boar Herd** — expired (Zug 136)
  - Aufgabe: Kill 4 barrow boar at Barrowfield homestead edge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 barrow boar killed at Barrowfield homestead edge.
- **Cull the Pale Stag of Hollow Wood** — expired (Zug 136)
  - Aufgabe: Kill 1 pale stag at Hollow Wood. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 pale stag killed at Hollow Wood.
- **Clear the Old Crown Catacombs, Level 1** — expired (Zug 136), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of Old Crown Catacombs. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Old Crown Catacombs is clear.
- **Cull the Bog Striders at the Reed Flats Eel-Weirs** — active (Zug 137) → completed (Zug 142)
  - Aufgabe: Kill 5 bog strider at eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 5 bog strider killed at eel-weirs of the Reed Flats.
- **Cull the Barrow Boar at Barrowfield Homestead Edge** — active (Zug 144)
  - Aufgabe: Kill 1 barrow boar at Barrowfield homestead edge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 barrow boar killed at Barrowfield homestead edge.

## Auffälligkeiten

- Zug 9, Nachricht 18 (extraction_repaired): the extractor's first answer needed a repair
- Zug 12, Nachricht 24 (extraction_repaired): the extractor's first answer needed a repair
- Zug 13, Nachricht 25 (planner_repaired): the planner's first answer needed a repair
- Zug 15, Nachricht 30 (extraction_repaired): the extractor's first answer needed a repair
- Zug 28, Nachricht 55 (stat_words): the player spent Stat Points in words, not with #assign; nothing was assigned (for review: did the story tell them as done?)
- Zug 36, Nachricht 71 (planner_repaired): the planner's first answer needed a repair
- Zug 40, Nachricht 80 (extraction_repaired): the extractor's first answer needed a repair
- Zug 50, Nachricht 99 (planner_repaired): the planner's first answer needed a repair
- Zug 52, Nachricht 104 (extraction_repaired): the extractor's first answer needed a repair
- Zug 57, Nachricht 114 (extraction_repaired): the extractor's first answer needed a repair
- Zug 60, Nachricht 120 (extraction_repaired): the extractor's first answer needed a repair
- Zug 61, Nachricht 121 (planner_repaired): the planner's first answer needed a repair
- Zug 61, Nachricht 122 (extraction_repaired): the extractor's first answer needed a repair
- Zug 64, Nachricht 128 (extraction_repaired): the extractor's first answer needed a repair
- Zug 74, Nachricht 148 (extraction_repaired): the extractor's first answer needed a repair
- Zug 83, Nachricht 166 (extraction_repaired): the extractor's first answer needed a repair
- Zug 96, Nachricht 192 (extraction_repaired): the extractor's first answer needed a repair
- Zug 102, Nachricht 204 (extraction_repaired): the extractor's first answer needed a repair
- Zug 103, Nachricht 205 (planner_repaired): the planner's first answer needed a repair
- Zug 107, Nachricht 214 (extraction_repaired): the extractor's first answer needed a repair
- Zug 112, Nachricht 224 (extraction_repaired): the extractor's first answer needed a repair
- Zug 113, Nachricht 225 (planner_repaired): the planner's first answer needed a repair
- Zug 116, Nachricht 231 (planner_repaired): the planner's first answer needed a repair
- Zug 130, Nachricht 260 (extraction_repaired): the extractor's first answer needed a repair
- Zug 138, Nachricht 275 (planner_repaired): the planner's first answer needed a repair
- Zug 138, Nachricht 276 (extraction_repaired): the extractor's first answer needed a repair
- Zug 142, Nachricht 283 (planner_repaired): the planner's first answer needed a repair
- Zug 142, Nachricht 284 (extraction_repaired): the extractor's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 34× keine gültige JSON-Entscheidung (Züge 2, 8, 9, 16, 24, 26, 27, 36, 37, 41, 47, 55, 58, 62, 67, 69, 75, 77, 84, 98, 100, 104, 105, 115, 118, 119, 121, 122, 126, 129, 139, 141, 143, 144)

System-Panels: CLARIFY 3, NOT TAKEN 3, REFUSED 1, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: guild_canon 1, engine_owned_fact 19, ambient 9, world_rule 10, quest_count 4, pc_inventory 16, engine_recovery 3, guild_payout 5, guild_completion 4, entity_fact 1, attack_commitment 6, no_go 2, time_cap 2, scene_context 5, group_unclear 1, npc_presence 2, npc_continuity 4, offer 2, coin_already_received 1, engine_booked 1, place 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 34/150 Erstantworten ungültig (22.7 %); 34 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 148 | 9 | 3.2 s | 9.7 s | 12396 | 9998 | 93 | – | stop 148 | 0 |
| board | 6 | 0 | 9.8 s | 18.1 s | 2522 | 2235 | 914 | – | stop 6 | 0 |
| narrator | 130 | 0 | 10.9 s | 17.6 s | 11554 | 8775 | 423 | – | stop 130 | 0 |
| extract | 148 | 18 | 6.5 s | 13.0 s | 12751 | 9709 | 401 | – | stop 148 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 81:42 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 15.9 s) | 0:30 min |
| 150 Züge, Spiel (Senden bis HUD nach der Extraktion) | 67:32 min — Median 25.5 s, p90 44.9 s, max 96.4 s |
| 150 Züge, Spieler-Entscheidung | 10:49 min — Median 2.6 s, 34 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 12:20 min / 1:06 min / 27:31 min / 20:24 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 31.3 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 20:53 min, 80 Züge ≈ 41:47 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spieler | 9 | – | 36.0 s | 2.6 s |
| Spieler | 129 | – | 33.6 s | 2.6 s |
| Spiel | 13 | – | 96.4 s | 25.5 s |
| Spiel | 9 | – | 93.8 s | 25.5 s |
| Provider plan | 9 | 20 | 57.4 s | 3.2 s |
| Provider narrator | 13 | 36 | 65.1 s | 10.9 s |
| Provider narrator | 17 | 49 | 58.5 s | 10.9 s |
| Provider narrator | 150 | 431 | 35.1 s | 10.9 s |
| Provider extract | 25 | 69 | 40.1 s | 6.5 s |
| Provider extract | 142 | 410 | 37.7 s | 6.5 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
