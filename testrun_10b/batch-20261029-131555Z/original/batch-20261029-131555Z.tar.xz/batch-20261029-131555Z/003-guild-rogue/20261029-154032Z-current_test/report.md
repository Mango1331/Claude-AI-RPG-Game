# Avereth Live-Test 20261029-154032Z-current_test

## Kurzfassung

- **Laufprofil:** guild-rogue; Startklasse Rogue, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** abgebrochen: Fehler im Runner — interrupted (Ctrl+C) in turn 117
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 6. Sicherheitsgrenzen: 150 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** Level 5, 364 XP seit Levelaufstieg, 376 cp, HP 102, MP 88; Ort realm.duskreach.thornfell_wood. Ausrüstung und Skills stehen in evaluation.json → progression.checkpoint.
- **Charakter:** rogue (rogue.razor_cut, rogue.fan_of_blades) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: curious adventurer: follow interesting opportunities without forcing dangerous encounters
- **Züge:** 117 · **Dauer:** 54:25 min · **LLM-Aufrufe der Engine/des Erzählers:** 319
- **Beobachtete Abdeckung:** 18 unterschiedliche gebuchte Reiseziele · 8 Kämpfe · 0 Verkäufe (0 cp Umsatz, ohne Questzahlungen/Geschenke) · 0 Ausrüstungswechsel · 0 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 16
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.117 |
| Git | a9a76eb3db94 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 59.5 s |
| Browser | chrome 156.0.8078.49 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261029-154032Z-current_test“, Seed 1271046155 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | I choose Rogue. | Engine (Menü/Rückfrage) | creation_complete | Select Rogue as base class | public roadside verge outside Ashbridge | 90/84 | 2.1 s |
| 2 | I select Fan of Blades and Razor Cut as my two skills. | Engine (Menü/Rückfrage) | creation_complete | Finish character creation | public roadside verge outside Ashbridge | 90/84 | 2.1 s |
| 3 | I walk through the gates into Ashbridge and head for the Adventurers' Guild hall to look at the contract board. | Erzähler | open_run_level | Enter city and find Guild contracts | Adventurers' Guild hall, Ashbridge | 90/84 | 43.2 s |
| 4 | "I'd like to take the wolf cull contract for the quarry track, and register with the Guild if that's needed first. What do I need to do?" | Erzähler | open_run_level | Accept the gaunt wolf contract via the clerk | Adventurers' Guild hall, Ashbridge | 90/84 | 14.6 s |
| 5 | "I'll register — here's two silver. Write it as Alaric Red. And then I'll take the wolf cull contract." | Erzähler | open_run_level | Register with the Guild and accept the wolf cull contract | Adventurers' Guild hall, Ashbridge | 90/84 | 15.5 s |
| 6 | I take the slip and head out the east gate, following the cart ruts toward the quarry track to hunt the gaunt wolf. | Erzähler | open_run_level | Travel to quarry track and hunt the contract wolf | quarry track east of Ashbridge | 90/84 | 22.9 s |
| 7 | I crouch by the fence line and follow the wolf prints quietly toward the far side of the pit, keeping low and watching for movement. | Erzähler | open_run_level | Track and find the gaunt wolf | far rim of the quarry pit | 90/84 | 32.5 s |
| 8 | I creep closer using the rock and gorse for cover, and if I get within striking distance unnoticed, I strike first with Razor Cut at the wol… | Erzähler | open_run_level | Ambush the gaunt wolf | far rim of the quarry pit | 90/84 | 19.5 s |
| 9 | I press the attack while it's still turning, slashing again at its flank with Razor Cut. | Erzähler | open_run_level | Continue fighting the gaunt wolf | far rim of the quarry pit | 90/84 | 19.0 s |
| 10 | I charge down the rock and close to melee range, then slash at the wolf's flank with Razor Cut. | Erzähler | open_run_level | Close distance and attack the wolf | far rim of the quarry pit | 90/84 | 21.6 s |
| 11 | I circle along the quarry rim toward the rock ledge, staying wide of the sliding scree, and keep moving until I'm close enough to engage the… | Erzähler | open_run_level | Close to ENGAGED range properly, then attack | far rim of the quarry pit | 90/84 | 17.9 s |
| 12 | I close the distance directly: I walk straight down the broken slope toward the wolf until I am within engaged range, keeping my dagger up a… | Erzähler | open_run_level | Close to ENGAGED range this turn, attack next turn | far rim of the quarry pit | 90/84 | 17.1 s |
| 13 | I strike first with Razor Cut at the wolf's flank as it bunches to spring. | Erzähler | open_run_level | Attack the wolf at engaged range | far rim of the quarry pit | 90/84 | 12.9 s |
| 14 | I check the contract slip's seal, then start back along the quarry rim toward Duskreach to turn in the cull at the Guild hall. | Erzähler | open_run_level | Turn in the completed wolf cull contract | Adventurers' Guild hall, Ashbridge | 90/84 | 39.5 s |
| 15 | "What's on the board today? I'm looking for another novice contract I can handle. | Erzähler | open_run_level | Take a new Guild contract from the board | Adventurers' Guild hall, Ashbridge | 90/84 | 21.2 s |
| 16 | I point to the Reed Flat Serpents slip. "I'll take that one — the serpent cull. I've got 7 Silver on me and I'd like to see the Primer of Gu… | Erzähler | open_run_level | Accept the serpent cull contract and ask about the Guard primer | Adventurers' Guild hall, Ashbridge | 90/84 | 31.4 s |
| 17 | "That's all, thanks." I take the slip and head to the market square to find Aldous's stall under the green awning and ask his price for the … | Erzähler | open_run_level | Buy the Guard primer from Aldous before heading to the Reed Flats | Aldous's book-stall | 90/84 | 32.1 s |
| 18 | "Deal at one silver eight." I pay Aldous 18 cp for the Primer of Guard and study it right there to learn guard. | Engine (Menü/Rückfrage) | open_run_level | Buy and use the Guard primer | Aldous's book-stall | 90/84 | 12.2 s |
| 19 | 18 cp — yes, one silver eight copper as you said. I pay Aldous 18 cp for the Primer of Guard and study it right there to learn guard. | Engine (Menü/Rückfrage) | open_run_level | Confirm the exact price and buy and learn the primer | Aldous's book-stall | 90/84 | 7.0 s |
| 20 | I agree to Aldous's price of one silver and eight copper — that is 18 cp. I pay it and study the Primer of Guard to learn guard. | Engine (Menü/Rückfrage) | open_run_level | Confirm the exact price and buy the primer | Aldous's book-stall | 90/84 | 9.5 s |
| 21 | I accept offer.t34.3 at 18 cp, pay it, and study the Primer of Guard to learn guard. | Erzähler | open_run_level | Buy and learn the Guard primer | Aldous's book-stall | 90/84 | 18.5 s |
| 22 | I find a bench nearby, sit down, and study the Primer of Guard. | Engine (Menü/Rückfrage) | open_run_level | Learn guard from the purchased primer | Aldous's book-stall | 90/84 | 4.7 s |
| 23 | I sit on a bench and study the Primer of Guard for 2 hours. | Erzähler | open_run_level | Learn guard from the primer with a stated duration | Aldous's book-stall | 90/84 | 19.8 s |
| 24 | I head south out of the city to the Reed Flats and hunt the serpents there. | Erzähler | open_run_level | Pursue the active serpent contract | eel-weirs of the Reed Flats | 90/84 | 27.8 s |
| 25 | I follow the slick trail along the weir, dagger drawn, and search the channel for the serpent. | Erzähler | open_run_level | Hunt the first Reed Flat serpent | serpent channel feeding ground | 90/84 | 29.9 s |
| 26 | I stay hidden at the reed line and wait for the serpent to surface, then strike it with Fan of Blades when it's in range. | Erzähler | open_run_level | Ambush the approaching serpent | serpent channel feeding ground | 90/84 | 26.1 s |
| 27 | I keep still in the reeds and let the serpent come to the bank, then strike it with Fan of Blades as it surfaces. | Engine (Menü/Rückfrage) | open_run_level | Ambush the approaching serpent | serpent channel feeding ground | 90/84 | 7.4 s |
| 28 | I wait for the serpent to actually emerge onto the bank before attacking. | Erzähler | open_run_level | Let the serpent surface so it becomes a valid target | serpent channel feeding ground | 90/84 | 28.1 s |
| 29 | I strike the serpent on the bank with Fan of Blades. | Erzähler | open_run_level | Attack the surfaced Marsh Serpent A | serpent channel feeding ground | 90/84 | 17.5 s |
| 30 | #assign AGI 3 PER 2 | System (Befehl) | open_run_level | Spend level-up points | serpent channel feeding ground | 90/84 | 2.2 s |
| 31 | I stay hidden in the reeds and watch the channel for the next serpent. | Erzähler | open_run_level | Hunt the second serpent for the 4-serpent contract | serpent channel feeding ground | 90/84 | 20.1 s |
| 32 | I strike the next serpent with Fan of Blades as it reaches the churned bank. | Engine (Menü/Rückfrage) | open_run_level | Attack the second approaching serpent | serpent channel feeding ground | 90/84 | 4.8 s |
| 33 | I stay hidden in the reeds, keep still, and wait for the serpent moving toward the bank to surface where I can see it. | Erzähler | open_run_level | Wait for a targetable serpent | serpent channel feeding ground | 90/84 | 13.7 s |
| 34 | I hold my position in the reeds and let the approaching serpent reach the churned bank. | Erzähler | open_run_level | Wait for the serpent to become a targetable actor | serpent channel feeding ground | 90/84 | 14.9 s |
| 35 | I move quietly along the bank toward the channel bend where I heard the heavy splash, keeping low, and look for the serpent there. | Erzähler | open_run_level | Find the remaining serpents by tracking the splash | serpent channel feeding ground | 90/84 | 14.6 s |
| 36 | I ready my dagger at the churned bank and strike the serpent the moment it surfaces from the rising bubbles. | Engine (Menü/Rückfrage) | open_run_level | Attack the approaching serpent as it surfaces | serpent channel feeding ground | 90/84 | 7.9 s |
| 37 | I give up on the serpents for tonight, take the dead serpent's skin and fang if not already collected, and head back to Duskreach to find lo… | Erzähler | open_run_level | Leave the flats at night and recover in town | Ashbridge | 90/84 | 24.6 s |
| 38 | I enter the inn and ask for a room for the night. | Erzähler | open_run_level | Get lodging and sleep until morning | Ashbridge inn | 90/84 | 21.3 s |
| 39 | I take the small room for 6 copper, pay the innkeeper, and go up to sleep until morning. | Erzähler | open_run_level | Buy lodging and sleep until morning | Ashbridge inn | 95/84 | 23.5 s |
| 40 | I eat a quick breakfast downstairs, then head to the Guild hall in Ashbridge to check the contract board for anything new. | Erzähler | open_run_level | Look for more contracts after resting | Adventurers' Guild hall, Ashbridge | 95/84 | 29.7 s |
| 41 | I ask the clerk to accept the Cull the Gaunt Wolves on the Quarry Track contract. | Erzähler | open_run_level | Take the wolf contract alongside the serpent one | Adventurers' Guild hall, Ashbridge | 95/84 | 18.1 s |
| 42 | "Yes — take it under my name, please." | Erzähler | open_run_level | Accept the gaunt wolf contract | Adventurers' Guild hall, Ashbridge | 95/84 | 16.4 s |
| 43 | I listen to the adventurer complaining about the north road and ask what trouble he's seen there. | Erzähler | open_run_level | Hear the rumor about the north road | Adventurers' Guild hall, Ashbridge | 95/84 | 22.4 s |
| 44 | I head east out of Ashbridge toward the quarry track to hunt the gaunt wolf, planning to ask the foreman Aldric Venn where they've been cros… | Erzähler | open_run_level | Work the wolf contract | quarry track east of Ashbridge | 95/84 | 25.2 s |
| 45 | I thank Venn and walk to the marshy dip past the old kiln to look for the drag marks and pick a good ambush spot before dusk. | Erzähler | open_run_level | Scout the wolf crossing before the dusk ambush | marshy dip past the old kiln | 95/84 | 19.6 s |
| 46 | I settle into the lean-to to wait through the day, keeping out of sight behind the kiln brambles until dusk when the wolves come down to dri… | Erzähler | open_run_level | Wait for the dusk ambush at the wolf crossing | marshy dip past the old kiln | 95/84 | 26.9 s |
| 47 | I strike from ambush: Fan of Blades at the two wolves nearest the brambles. | Engine (Menü/Rückfrage) | open_run_level | Dusk ambush on the wolf pack | marshy dip past the old kiln | 95/84 | 9.5 s |
| 48 | Fan of Blades at the drinking wolf at the crossing and the one at the near edge. | Engine (Menü/Rückfrage) | open_run_level | Ambush the two closest wolves | marshy dip past the old kiln | 95/84 | 5.2 s |
| 49 | Fan of Blades at Gaunt Wolf B, the drinking wolf at the crossing. | Erzähler | open_run_level | Open the ambush on the drinking wolf | marshy dip past the old kiln | 95/84 | 19.6 s |
| 50 | I creep along the brambles toward Gaunt Wolf C, the near-edge wolf, and if I come within short range I loose Fan of Blades at it. | Erzähler | open_run_level | Close to short range and ambush the near-edge wolf | marshy dip past the old kiln | 95/84 | 25.0 s |
| 51 | I loose Fan of Blades at Gaunt Wolf C, broadside at short range. | Erzähler | open_run_level | Ambush the near wolf from short range | marshy dip past the old kiln | 95/84 | 26.3 s |
| 52 | I hold still behind the reed cover, staying hidden, and wait to see whether the two remaining wolves hold their ground or come to investigat… | Erzähler | open_run_level | Avoid a long-range charge; let the wolves commit | marshy dip past the old kiln | 95/84 | 38.1 s |
| 53 | I hold my position behind the reeds and make no attack this round, letting the wolves close to short range. | Erzähler | open_run_level | Let wolves enter short range for AoE | marshy dip past the old kiln | 95/84 | 39.2 s |
| 54 | I loose Fan of Blades at both wolves, broadside at short range. | Engine (Menü/Rückfrage) | open_run_level | AoE both wolves at short range | marshy dip past the old kiln | 95/84 | 10.0 s |
| 55 | Fan of Blades on Gaunt Wolf B | Erzähler | open_run_level | AoE both wolves at short range, naming a primary target | marshy dip past the old kiln | 95/84 | 28.7 s |
| 56 | I collect the pelts and fangs, then head back along the quarry track toward the Guild hall in town to turn in the wolf cull contract. | Erzähler | open_run_level | Return to town and turn in the completed wolf cull | Adventurers' Guild hall, Ashbridge | 95/84 | 35.4 s |
| 57 | I ask the clerk what contracts are posted on the board for a Novice. | Erzähler | open_run_level | Choose the next Guild contract | Adventurers' Guild hall, Ashbridge | 95/84 | 21.7 s |
| 58 | I take the Marsh Serpents contract at the Eel-Weirs from the clerk, then spend my free points with #assign AGI 2 PER 2 WIL 1. | Erzähler | open_run_level | Accept serpent cull and assign level-up stats | Adventurers' Guild hall, Ashbridge | 95/84 | 24.8 s |
| 59 | #assign AGI 2 PER 2 WIL 1 | System (Befehl) | open_run_level | Spend the 5 free stat points | Adventurers' Guild hall, Ashbridge | 95/84 | 2.4 s |
| 60 | I ask the eel-fishers at the Reed Flats where the marsh serpents lie up at the weirs. | Erzähler | open_run_level | Hunt serpents toward the two active cull contracts | eel-weirs of the Reed Flats | 95/84 | 67.9 s |
| 61 | I head down the channel toward the third weir and the fallen willow, watching the flat stones by the middle fence for a sunning serpent on t… | Erzähler | open_run_level | Hunt serpents at the weirs | third weir and fallen willow | 95/84 | 34.6 s |
| 62 | I wait in cover near the willow root-plate with my eyes on the deep pool, ready to strike the moment the big serpent shows itself. | Erzähler | open_run_level | Ambush the big serpent at the pool | third weir and fallen willow | 95/84 | 49.4 s |
| 63 | I leap from cover and strike the big serpent on the trunk with Fan of Blades. | Engine (Menü/Rückfrage) | open_run_level | Ambush the big serpent with AoE while it is alone on the trunk | third weir and fallen willow | 95/84 | 10.9 s |
| 64 | I attack Marsh Serpent B with Fan of Blades. | Erzähler | open_run_level | Strike the big serpent using the valid target name | third weir and fallen willow | 95/84 | 42.8 s |
| 65 | I creep out along the willow trunk toward Marsh Serpent B, staying low and quiet, and attack with Fan of Blades once it is in range. | Erzähler | open_run_level | Close to SHORT range on the trunk, then strike the big serpent | third weir and fallen willow | 95/84 | 18.3 s |
| 66 | I attack Marsh Serpent B with Fan of Blades. | Erzähler | open_run_level | Strike the big serpent now that it is at SHORT range | third weir and fallen willow | 95/84 | 32.5 s |
| 67 | I check the contract slip to see whether the big Marsh Serpent counts toward Cull the Marsh Serpents at the Eel-Weirs, then decide whether t… | Erzähler | open_run_level | Verify contract progress for the big serpent kill | third weir and fallen willow | 95/84 | 18.0 s |
| 68 | I hunt the channel stretch where the sunning serpent dove, moving along the reed edge and searching for tracks or ripples while the light la… | Erzähler | open_run_level | Hunt the remaining serpents for both contracts before dusk | serpent den under the earthen bank | 95/84 | 22.1 s |
| 69 | I wait quietly at the den entrance and strike with Fan of Blades the moment the serpent's head emerges into reach. | Engine (Menü/Rückfrage) | open_run_level | Ambush the den serpent for both contracts | serpent den under the earthen bank | 95/84 | 5.3 s |
| 70 | I stay back from the entrance and wait quietly for the serpent to come out, watching the den mouth. | Erzähler | open_run_level | Lure the den serpent into the open so it becomes a valid target | serpent den under the earthen bank | 95/84 | 21.2 s |
| 71 | I attack Marsh Serpent C with Fan of Blades from my cover in the willow shadow. | Erzähler | open_run_level | Strike the emerged den serpent | serpent den under the earthen bank | 95/84 | 15.9 s |
| 72 | I close the distance quickly along the willow trunk and strike Marsh Serpent C with Fan of Blades. | Erzähler | open_run_level | Cross the gap via the willow trunk and attack | serpent den under the earthen bank | 95/84 | 22.9 s |
| 73 | I check the contract slip to confirm whether Marsh Serpent C counts toward both serpent contracts. | Erzähler | open_run_level | Verify contract counts after the kill | serpent den under the earthen bank | 95/84 | 14.9 s |
| 74 | I check #bag to see what the '+1 more' item is before deciding whether to camp by the den or head back for lodging. | Erzähler | open_run_level | Identify unconfirmed inventory item | serpent den under the earthen bank | 95/84 | 15.0 s |
| 75 | I head back along the willow trunk toward Blackgate and look for lodging for the night, since camping on the blood-smelling mudflat seems ri… | Erzähler | open_run_level | Return to town and recover overnight | Blackgate | 95/84 | 26.5 s |
| 76 | I take a bed at the boarding house for 4 cp and sleep until morning. | Erzähler | open_run_level | Recover overnight at the boarding house | Blackgate | 95/84 | 22.3 s |
| 77 | I pay the innkeeper 4 coppers for the bed for the night and take the room upstairs. | Erzähler | open_run_level | Book the boarding house bed properly | Blackgate | 95/84 | 36.1 s |
| 78 | I give the innkeeper 4 coppers and ask her to book the bed for the night. If the booking succeeds, I go up to the third door, take the room,… | Erzähler | open_run_level | Book the canonical bed offer and recover overnight | boarding house room, third door | 95/84 | 32.4 s |
| 79 | I snuff the candle, get into the bed, and sleep until morning. | Erzähler | open_run_level | Sleep in the booked room | boarding house room, third door | 100/88 | 25.6 s |
| 80 | I buy the bread and drippings for a copper, eat, then head out to Reed Flat to hunt the last serpent for my contract. | Erzähler | open_run_level | Eat and finish the serpent contract | eel-weirs of the Reed Flats | 100/88 | 22.9 s |
| 81 | I walk over to the older eel-fisher and ask where the last marsh serpent has been seen lately. | Erzähler | open_run_level | Get the serpent's location from the fisher | eel-weirs of the Reed Flats | 100/88 | 24.6 s |
| 82 | I ask the older fisher to keep his lamps burning tonight near the third weir, then say I'll wait by the willow trunk crossing until the serp… | Erzähler | open_run_level | Set up an ambush for the big serpent at the channel | eel-weirs of the Reed Flats | 100/88 | 28.2 s |
| 83 | I walk up along the bank toward the fallen willow trunk crossing past the reeds, keeping to firm ground where I can. | Erzähler | open_run_level | Move to the willow trunk crossing to set up the dusk ambush | eel-weirs of the Reed Flats | 100/88 | 22.1 s |
| 84 | I climb out along the weir fences to the third weir's end and wait there for dusk, watching the channel. | Erzähler | open_run_level | Ambush the big serpent from the third weir | eel-weirs of the Reed Flats | 100/88 | 35.7 s |
| 85 | I strike at the serpent's raised head with my dagger, attacking from the weir end while it hangs motionless. | Engine (Menü/Rückfrage) | open_run_level | Attack the last marsh serpent from the weir | eel-weirs of the Reed Flats | 100/88 | 5.1 s |
| 86 | I attack the big marsh serpent hanging at the weir end, striking at its head with my dagger. | Engine (Menü/Rückfrage) | open_run_level | Engage the last serpent as a combat target | eel-weirs of the Reed Flats | 100/88 | 4.5 s |
| 87 | I cut a strip of dried fish bait from my pack and toss it into the open water between the lamps, close to the weir end, to lure the serpent … | Erzähler | open_run_level | Lure the serpent into the active scene within reach | eel-weirs of the Reed Flats | 100/88 | 28.6 s |
| 88 | I attack Marsh Serpent D from the weir end, striking at its head with my dagger. | Erzähler | open_run_level | Engage the now-valid serpent target | eel-weirs of the Reed Flats | 100/88 | 20.0 s |
| 89 | I move onto the willow trunk crossing toward Marsh Serpent D to close into ENGAGED range, then strike at its head with my dagger. | Erzähler | open_run_level | Close to melee range with Marsh Serpent D and attack | eel-weirs of the Reed Flats | 100/88 | 14.2 s |
| 90 | I use Fan of Blades on Marsh Serpent D while it hangs at SHORT from the weir end. | Erzähler | open_run_level | Attack the serpent with a skill that may reach SHORT | eel-weirs of the Reed Flats | 84/88 | 15.5 s |
| 91 | I finish Marsh Serpent D with a Basic Attack at its head. | Erzähler | open_run_level | Kill the serpent now in ENGAGED range | eel-weirs of the Reed Flats | 84/88 | 15.2 s |
| 92 | I collect the dead serpent's skin and fang, then head back along the road toward Duskreach to turn in both contracts at the Guild hall. | Erzähler | open_run_level | Collect loot and return to Guild for turn-ins | Adventurers' Guild hall, Ashbridge | 84/88 | 26.2 s |
| 93 | #assign AGI 4 PER 3 VIT 3 | System (Befehl) | open_run_level | Spend 10 free stat points to boost agility, perception and vitality | Adventurers' Guild hall, Ashbridge | 84/88 | 2.6 s |
| 94 | I ask the clerk what contracts are on the board tonight, preferably something achievable before dark or nearby for tomorrow. | Erzähler | open_run_level | Pick a new Guild contract | Adventurers' Guild hall, Ashbridge | 84/88 | 30.3 s |
| 95 | I accept the contract to cull the great grey wolves of Thornfell and ask the clerk to mark it ACTIVE. | Erzähler | open_run_level | Take tomorrow's wolf contract | Adventurers' Guild hall, Ashbridge | 84/88 | 18.6 s |
| 96 | Before heading out, I ask the clerk about lodging for the night and whether the hunting shelter at Thornfell's edge is usable, since it's ne… | Erzähler | open_run_level | Plan overnight recovery before the half-day trek | Adventurers' Guild hall, Ashbridge | 84/88 | 21.7 s |
| 97 | I buy firewood for the shelter if the clerk or Guild can sell me a bundle, then head out on the northwest road toward the Thornfell shelter,… | Erzähler | open_run_level | Overnight at the shelter to start the wolf hunt at first light | hunting shelter at Thornfell's edge | 84/88 | 30.2 s |
| 98 | I pay the four copper for the firewood bundle, light the hearth, bar the shelter door, and sleep until first light. | Erzähler | open_run_level | Settle the wood purchase and recover overnight at the shelter before the wolf hunt | hunting shelter at Thornfell's edge | 125/88 | 25.9 s |
| 99 | I follow the fresh wolf tracks into Thornfell wood, moving quietly and keeping alert for the great greys. | Erzähler | open_run_level | Hunt the great grey wolves at dawn | hunting shelter at Thornfell's edge | 125/88 | 18.3 s |
| 100 | I follow the wolf tracks into Thornfell wood, moving quietly and scanning the trees for the great greys. | Erzähler | open_run_level | Hunt the wolves | Thornfell wood | 102/88 | 25.8 s |
| 101 | I use Fan of Blades at the two wolves — it hits both at SHORT range. | Erzähler | open_run_level | AoE both wolves before wolf B bites again | Thornfell wood | 102/88 | 19.2 s |
| 102 | I finish the wounded wolf with a Razor Cut at Great Grey Wolf B. | Erzähler | open_run_level | Kill wolf B before it bites again | Thornfell wood | 102/88 | 37.2 s |
| 103 | #assign VIT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up stat points, then continue tracking the remaining wolves north | Thornfell wood | 102/88 | 2.5 s |
| 104 | I skin the dead grey for its pelt, then follow the two wolves' tracks north up the stony slope, moving quietly and alert for an ambush. | Erzähler | open_run_level | Continue the 4-wolf cull toward the remaining three | rocky bowl with a wolf den | 102/88 | 48.0 s |
| 105 | I hold my ground at the rise and wait — two wolves guarding a den with more inside is more than I want alone. I back away slowly down the sl… | Erzähler | open_run_level | Avoid a losing fight at the den, seek the fourth wolf elsewhere | stream-side drinking place in a narrow ravine | 102/88 | 31.7 s |
| 106 | I ready my dagger and use Fan of Blades on the two wolves at SHORT range before they can charge. | Engine (Menü/Rückfrage) | open_run_level | Fight wolves C and D that the HUD shows at SHORT range despite my retreat | stream-side drinking place in a narrow ravine | 102/88 | 21.8 s |
| 107 | I use Fan of Blades on Great Grey Wolf C and Great Grey Wolf D at SHORT range. | Engine (Menü/Rückfrage) | open_run_level | AoE both wolves now at SHORT | stream-side drinking place in a narrow ravine | 102/88 | 5.6 s |
| 108 | I choose Great Grey Wolf C's band — Fan of Blades on Great Grey Wolf C. | Erzähler | open_run_level | AoE the wolves, starting with wolf C's band | stream-side drinking place in a narrow ravine | 58/88 | 24.1 s |
| 109 | I use Razor Cut on Great Grey Wolf D, the weaker one, to finish it off before it can bite again. | Erzähler | open_run_level | Kill wolf D first with Razor Cut | stream-side drinking place in a narrow ravine | 35/88 | 15.1 s |
| 110 | I drive my dagger into Great Grey Wolf C's ribs — Razor Cut, again, before it can shake me down. | Erzähler | open_run_level | Finish wolf C with Razor Cut | stream-side drinking place in a narrow ravine | 35/88 | 92.2 s |
| 111 | #passives | System (Befehl) | open_run_level | Accept Wolf-Won Grit | stream-side drinking place in a narrow ravine | 35/88 | 2.6 s |
| 112 | I accept Wolf-Won Grit into my free passive slot, then bind my shoulder wound and head back toward Duskreach, away from the root hollow. | Erzähler | open_run_level | Accept the passive and retreat to town to recover | Ashbridge | 35/88 | 32.9 s |
| 113 | I go to the Guild hall and ask where I can find a healer or lodging, then take a room and sleep until morning to recover. | Erzähler | open_run_level | Recover from wounds before finishing the 4/4 cull | Adventurers' Guild hall, Ashbridge | 35/88 | 25.6 s |
| 114 | I buy the room upstairs for a copper, then go to Mother Hale on Cooper's Row and ask her to stitch and treat my wounds. | Erzähler | open_run_level | Secure lodging and healing before turning in the cull | Mother Hale's healing house, Cooper's Row | 35/88 | 38.9 s |
| 115 | I pay for both — the stitching with salve and the brew — and ask her to treat me now. | Erzähler | open_run_level | Buy full healing treatment | Mother Hale's healing house, Cooper's Row | 35/88 | 25.4 s |
| 116 | I buy the bed here for two copper and sleep until morning. | Erzähler | open_run_level | Recover overnight at Mother Hale's | Mother Hale's healing house, Cooper's Row | 145/96 | 18.1 s |
| 117 | I eat the porridge, thank Mother Hale, and head to the Guild hall to check the board for the fourth grey wolf's whereabouts before going bac… | – | open_run_level | Recover done; finish the 4/4 cull | Mother Hale's healing house, Cooper's Row | 145/96 | 33.6 s **interrupted** |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 3 (notiert vor Zug 4): Guild Rank not registered; registration may be a prerequisite for contracts.
- zu Zug 5 (notiert vor Zug 6): Registration cost 20 copper despite 'two silver' phrasing; coin shows 3 Silver in HUD but engine recorded 50→30 copper — will trust engine results.
- zu Zug 10 (notiert vor Zug 11): Engine repeatedly refuses Razor Cut at MEDIUM range; must explicitly close distance before attacking.
- zu Zug 16 (notiert vor Zug 17): Contract accepted and ACTIVE (0/4 serpents); clerk directed primer purchase to Aldous's book-stall rather than selling it herself despite the Guild SHOP panel.
- zu Zug 18 (notiert vor Zug 19): System asked for the exact amount of 'one silver eight'; clarifying as 18 cp.
- zu Zug 20 (notiert vor Zug 21): System repeatedly loops clarification prompts on the purchase despite identical confirmations.
- zu Zug 21 (notiert vor Zug 22): Purchase succeeded (-18 cp), but studying failed with 'no material' — possibly study needs a seated/rest condition or another material.
- zu Zug 34 (notiert vor Zug 35): Serpents stopped approaching the bank after the kill; waiting passively for hours produced nothing. Contract shows 1/4, so hunting actively near the bend may work better.
- zu Zug 36 (notiert vor Zug 37): No targetable serpent after long waiting; serpents stopped approaching after the first kill. Continuing the hunt at dawn may work better.
- zu Zug 43 (notiert vor Zug 44): Wight stag/north road rumor noted; too dangerous for now.
- zu Zug 45 (notiert vor Zug 46): Engine refused 'scout/ambush' phrasing as pending; arrival at the dip is confirmed, wolves 0/1 yet.
- zu Zug 46 (notiert vor Zug 47): Three wolves present, not one; HUD time says midday but narration says dusk.
- zu Zug 49 (notiert vor Zug 50): Fan of Blades is SHORT-ranged only; wolves at MEDIUM/LONG. HUD still says midday while narration says dusk.
- zu Zug 55 (notiert vor Zug 56): Wolf cull contract shows 3/1 defeated — ready to turn in; serpent contract still 1/4.
- zu Zug 58 (notiert vor Zug 59): HUD still showed Free Stat Points 5 after the earlier assign attempt, so I repeat the #assign command alone.
- zu Zug 63 (notiert vor Zug 64): System rejected descriptive target names; must use the exact scene label 'Marsh Serpent B'.
- zu Zug 69 (notiert vor Zug 70): Fan of Blades rejected because the serpent is inside the den — no targetable actor until it emerges.
- zu Zug 76 (notiert vor Zug 77): Engine refused the sleep because no canonical offer was booked; 4 cp were narrated as paid but not recorded.
- zu Zug 77 (notiert vor Zug 78): Engine gave Room key but still says 'NOT BOUGHT — no single valid canonical offer'; two payments of 4 cp may have been taken without a booked bed.
- zu Zug 78 (notiert vor Zug 79): Engine says 'arrival pending' though HUD shows me in the room; two extra 4 cp payments may have been taken.
- zu Zug 82 (notiert vor Zug 83): Engine refused 'wait at the crossing' as an activity needing step 1; will try a plain movement action first.
- zu Zug 85 (notiert vor Zug 86): Active scene lists only the two fishers; the serpent may need to be lured or approached before it registers as a target.
- zu Zug 86 (notiert vor Zug 87): The serpent is described as present but the System scene lists only the two fishers; it may need to close distance before registering as a target.
- zu Zug 87 (notiert vor Zug 88): Bait attempt failed (no dried fish left), but the serpent now registers as Marsh Serpent D in the active scene.
- zu Zug 88 (notiert vor Zug 89): Serpent at SHORT is beyond Basic Attack range; must declare movement to engage.
- zu Zug 89 (notiert vor Zug 90): HUD scene now lists Marsh Serpent D at SHORT again; willow trunk route reached only MEDIUM.
- zu Zug 93 (notiert vor Zug 94): Both serpent contracts paid out (2g90s total); HUD location shows Ashbridge though narration says Duskreach — treating System as authoritative.
- zu Zug 98 (notiert vor Zug 99): Firewood bundle purchase failed (no open offer at the Guild); shelter hearth still workable, so no loss.
- zu Zug 104 (notiert vor Zug 105): Den may hold more than two wolves; cull counts 1/4 but I've killed two — count may only register on certain wolves.
- zu Zug 105 (notiert vor Zug 106): HUD places wolves C and D at SHORT at my location even though narration described a full retreat — engine result is authoritative, so the fight is on here.
- zu Zug 106 (notiert vor Zug 107): Wolves C and D tracked me downstream; the fourth wolf is in the root hollow upstream.
- zu Zug 111 (notiert vor Zug 112): Fourth wolf still unaccounted for on the 4/4 cull; quest panel says 3/4 defeated.
- zu Zug 113 (notiert vor Zug 114): Engine earlier refused room/sleep as 'arrival pending'; narrator now offers the key — buying explicitly to confirm.
- zu Zug 116 (notiert vor Zug 117): Fully healed overnight (HP 145/145). Cull still shows 3/4 despite four pelts carried.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t13 | 13 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t24 | 29 | 1 | – | ja | 1 | gewonnen, 120 XP |
| enc.t41 | 51 | 3 | – | nein | 3 | gewonnen, 72 XP |
| enc.t53 | 66 | 1 | – | ja | 1 | gewonnen, 144 XP |
| enc.t58 | 72 | 1 | – | nein | 1 | gewonnen, 144 XP |
| enc.t74 | 90 | 1 | – | nein | 1 | gewonnen, 168 XP |
| enc.t83r | 100 | 1 | – | ja | 1 | gewonnen, 216 XP |
| enc.t88 | 108 | 2 | – | nein | 2 | gewonnen, 456 XP |

## Quests

- **Cull the Gaunt Track Wolf** — active (Zug 5) → completed (Zug 14)
  - Aufgabe: Kill 1 gaunt wolf at quarry track east of Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 gaunt wolf killed at quarry track east of Ashbridge.
- **Thin the Reed Flat Serpents** — active (Zug 16) → completed (Zug 92)
  - Aufgabe: Kill 4 marsh serpents at eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 marsh serpents killed at eel-weirs of the Reed Flats.
- **Break the Howling Pack of Thornfell** — expired (Zug 40)
  - Aufgabe: Kill 6 great grey wolves at Thornfell wood. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 6 great grey wolves killed at Thornfell wood.
- **Slay the Barrow Wight Stag** — expired (Zug 40)
  - Aufgabe: Kill 1 antlered wight stag at barrow field by the north road. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 antlered wight stag killed at barrow field by the north road.
- **Clear Mossback Warrens, Level 1** — expired (Zug 40), Dungeon loc.mossback_warrens Ebene 1
  - Aufgabe: Clear level 1 of Mossback Warrens. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Mossback Warrens is clear.
- **Cull the Gaunt Wolves on the Quarry Track** — active (Zug 42) → completed (Zug 56)
  - Aufgabe: Kill 1 gaunt wolf at quarry track east of Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 gaunt wolf killed at quarry track east of Ashbridge.
- **Cull the Marsh Serpents at the Eel-Weirs** — active (Zug 58) → completed (Zug 92)
  - Aufgabe: Kill 3 marsh serpent at eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 marsh serpent killed at eel-weirs of the Reed Flats.
- **Cull the Great Grey Wolves of Thornfell Wood** — expired (Zug 94)
  - Aufgabe: Kill 4 great grey wolf at Thornfell wood. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 great grey wolf killed at Thornfell wood.
- **Cull the Wight Stag of the Barrow Field** — expired (Zug 94)
  - Aufgabe: Kill 1 wight stag at barrow field by the north road. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 wight stag killed at barrow field by the north road.
- **Clear Mossback Warrens Level 1** — expired (Zug 94), Dungeon loc.mossback_warrens Ebene 1
  - Aufgabe: Clear level 1 of Mossback Warrens. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Mossback Warrens is clear.
- **Cull the Quarry Track Wolves** — expired (Zug 117)
  - Aufgabe: Kill 1 gaunt wolf at quarry track east of Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 gaunt wolf killed at quarry track east of Ashbridge.
- **Thin the Marsh Serpents at the Eel-Weirs** — expired (Zug 117)
  - Aufgabe: Kill 3 marsh serpent at eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 marsh serpent killed at eel-weirs of the Reed Flats.
- **Cull the Great Grey Wolves of Thornfell** — active (Zug 95)
  - Aufgabe: Kill 4 great grey wolf at Thornfell wood. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 great grey wolf killed at Thornfell wood.
- **Put Down the Wight Stag of the Barrow Field** — expired (Zug 117)
  - Aufgabe: Kill 1 wight stag at barrow field by the north road. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 wight stag killed at barrow field by the north road.
- **Clear Mossback Warrens Level 1** — expired (Zug 117), Dungeon loc.mossback_warrens Ebene 1
  - Aufgabe: Clear level 1 of Mossback Warrens. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Mossback Warrens is clear.

## Auffälligkeiten

- Zug 117 (Runner/UI): interrupted
- Zug 18, Nachricht 35 (planner_repaired): the planner's first answer needed a repair
- Zug 19, Nachricht 37 (planner_repaired): the planner's first answer needed a repair
- Zug 20, Nachricht 39 (planner_repaired): the planner's first answer needed a repair
- Zug 46, Nachricht 91 (planner_repaired): the planner's first answer needed a repair
- Zug 58, Nachricht 115 (stat_words): the player spent Stat Points in words, not with #assign; nothing was assigned (for review: did the story tell them as done?)
- Zug 75, Nachricht 150 (extraction_repaired): the extractor's first answer needed a repair
- Zug 76, Nachricht 152 (extraction_repaired): the extractor's first answer needed a repair
- Zug 77, Nachricht 154 (extraction_repaired): the extractor's first answer needed a repair
- Zug 78, Nachricht 156 (extraction_repaired): the extractor's first answer needed a repair
- Zug 82, Nachricht 163 (planner_repaired): the planner's first answer needed a repair
- Zug 97, Nachricht 194 (extraction_repaired): the extractor's first answer needed a repair
- Zug 104, Nachricht 208 (extraction_repaired): the extractor's first answer needed a repair
- Zug 105, Nachricht 210 (extraction_repaired): the extractor's first answer needed a repair
- Zug 112, Nachricht 224 (extraction_repaired): the extractor's first answer needed a repair
- Zug 114, Nachricht 228 (extraction_repaired): the extractor's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 21× keine gültige JSON-Entscheidung (Züge 2, 5, 7, 8, 10, 13, 35, 36, 50, 59, 63, 65, 66, 69, 71, 76, 80, 81, 84, 113, 114)
- Server: Generation failed AbortError: The operation was aborted.

System-Panels: CLARIFY 7, NOT TAKEN 7, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: ambient 6, engine_owned_fact 4, engine_booked 1, group_unclear 4, world_rule 17, quest_count 3, no_go 4, scene_context 11, pc_inventory 2, guild_payout 2, guild_canon 1, engine_recovery 2, engine_owned_combat 1, time_cap 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 1 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 1 mit Erzähltext, 0 leer, 0 ohne Antwort; 1 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 21/117 Erstantworten ungültig (17.9 %); 21 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 115 | 5 | 2.9 s | 7.3 s | 12046 | 9939 | 97 | – | stop 115 | 0 |
| board | 5 | 1 | 9.6 s | 11.3 s | 2538 | 2234 | 1069 | – | stop 5 | 0 |
| narrator | 95 | 0 | 9.4 s | 18.1 s | 11312 | 8703 | 393 | – | stop 94 | 1 |
| extract | 103 | 9 | 5.8 s | 10.8 s | 12381 | 9603 | 348 | – | stop 102 | 0 |
| forge | 1 | 0 | 1.3 s | 1.3 s | 363 | 0 | 54 | – | stop 1 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 54:25 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 59.5 s) | 1:19 min |
| 117 Züge, Spiel (Senden bis HUD nach der Extraktion) | 43:31 min — Median 21.7 s, p90 36.1 s, max 92.2 s |
| 117 Züge, Spieler-Entscheidung | 7:44 min — Median 2.9 s, 21 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 7:33 min / 0:49 min / 17:55 min / 12:37 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 26.3 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 17:31 min, 80 Züge ≈ 35:03 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spiel | 110 | – | 92.2 s | 21.7 s |
| Spiel | 60 | – | 67.9 s | 21.7 s |
| Provider extract | 110 | 298 | 78.2 s | 5.8 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
