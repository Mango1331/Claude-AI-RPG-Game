# Avereth – 3 natürliche Testkampagnen

Status: **interrupted**. Serie abgeschlossen bedeutet, dass die Läufe beendet sind; es bedeutet nicht 3 bestandene Level-15-Abnahmen.

| Nr. | Profil | Seed | Eingaben | Level | Ende | Originalbericht |
|---|---|---:|---:|---:|---|---|
| 1 | guild-warrior | 1271046153 | 150 | 8 | limit | [report.md](001-guild-warrior/20261029-131555Z-current_test/report.md) |
| 2 | guild-mage | 1271046154 | 150 | 9 | limit | [report.md](002-guild-mage/20261029-141843Z-current_test/report.md) |
| 3 | guild-rogue | 1271046155 | 117 | 6 | process_error | [report.md](003-guild-rogue/20261029-154032Z-current_test/report.md) |

