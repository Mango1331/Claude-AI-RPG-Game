# Avereth Live-Test 20261029-174048Z-current_test

## Kurzfassung

- **Laufprofil:** guild-warrior; Startklasse Warrior, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** Niederlage — turn 73: he died
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 3. Sicherheitsgrenzen: 150 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** noch nicht erreicht.
- **Charakter:** warrior (warrior.cleave, warrior.quick_slash) · Regelstand 2 (Warrior, Mage, Rogue)
- **Ziel-Dungeon:** Mossback Warrens, Ebene 1 (Vertrag quest.clear_mossback_warrens_level_1)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: curious adventurer: follow interesting opportunities without forcing dangerous encounters
- **Züge:** 73 · **Dauer:** 40:33 min · **LLM-Aufrufe der Engine/des Erzählers:** 217
- **Beobachtete Abdeckung:** 17 unterschiedliche gebuchte Reiseziele · 4 Kämpfe · 1 Verkäufe (9 cp Umsatz, ohne Questzahlungen/Geschenke) · 0 Ausrüstungswechsel · 0 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 11 · **Niederlage** in Zug 73: he died
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.119 |
| Git | b09274c8c4d9 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 14.3 s |
| Browser | chrome 156.0.8078.49 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261029-174048Z-current_test“, Seed 1717914047 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | I choose Warrior. | Engine (Menü/Rückfrage) | creation_complete | Select Warrior base class | public roadside verge outside Ashbridge | 90/84 | 2.3 s |
| 2 | I select Cleave and Quick Slash as my two starter skills. | Engine (Menü/Rückfrage) | creation_complete | Finish character creation with warrior.cleave | public roadside verge outside Ashbridge | 95/84 | 2.2 s |
| 3 | I walk toward the city of Ashbridge and look for the Adventurers' Guild hall. | Erzähler | open_run_level | Enter city and find the Guild board | Adventurers' Guild hall, Ashbridge | 95/84 | 36.0 s |
| 4 | "Good morning — I'd like to register with the Guild as a new adventurer. What do I need to do?" | Erzähler | open_run_level | Register with the Guild | Adventurers' Guild hall, Ashbridge | 95/84 | 25.7 s |
| 5 | "Alaric Red. Here's the two silver — let's do it." I pay the fee and sign the ledger. | Erzähler | open_run_level | Register with the Guild | Adventurers' Guild hall, Ashbridge | 95/84 | 42.9 s |
| 6 | I go to the corkboard and look over the Novice contracts. | Erzähler | open_run_level | Find a suitable first Guild contract | Adventurers' Guild hall, Ashbridge | 95/84 | 56.8 s |
| 7 | "Anything coming before the couriers arrive? Or work I could take now — pest culls, deliveries, gathering, anything Novice-level?" | Erzähler | open_run_level | Ask the clerk about available Novice contracts | Adventurers' Guild hall, Ashbridge | 95/84 | 38.6 s |
| 8 | "I'll wait for the midday postings. Mind if I take a bench until the couriers come in?" | Erzähler | open_run_level | Wait at the Guild hall for new Novice contracts | Adventurers' Guild hall, Ashbridge | 95/84 | 46.8 s |
| 9 | I keep waiting on the bench for the courier to arrive with the new postings. | Erzähler | open_run_level | Wait for midday contract postings | Adventurers' Guild hall, Ashbridge | 95/84 | 37.0 s |
| 10 | "Then I'll try the Mossback Warrens — can you point me to the quarry track east, and where the entry ledger for the Warrens is kept?" | Erzähler | open_run_level | Take the goblin-tunnel work on my own footing | Adventurers' Guild hall, Ashbridge | 95/84 | 37.5 s |
| 11 | I sign the ledger — name Alaric Red, party of one, expected back by tomorrow evening — then head out the east gate toward the Mossback Warre… | Erzähler | open_run_level | Sign out and travel to the Mossback Warrens | Adventurers' Guild hall, Ashbridge | 95/84 | 33.8 s |
| 12 | I approach the nearest small opening cautiously, sword drawn, watching for goblin scouts. | Erzähler | open_run_level | Enter the Mossback Warrens | Adventurers' Guild hall, Ashbridge | 95/84 | 19.3 s |
| 13 | I hug the broken stone lip and peer inside, staying hidden, to see what's making the scraping sound. | Erzähler | open_run_level | Scout the warren entrance unseen | Adventurers' Guild hall, Ashbridge | 95/84 | 29.6 s |
| 14 | I draw back from the lip and circle wide toward the big palisaded entrance, staying low, to scout its gap and watch for sentries from cover. | Erzähler | open_run_level | Scout the main entrance unseen | Adventurers' Guild hall, Ashbridge | 95/84 | 32.2 s |
| 15 | Since the hall is where I apparently stand, I approach the clerk and ask whether the Mossback Warrens job can be taken as a proper Guild con… | Erzähler | open_run_level | Work with the confirmed location — get a real contract from the clerk | Adventurers' Guild hall, Ashbridge | 95/84 | 26.5 s |
| 16 | I walk to the corkboard and read the refreshed Novice postings. | Erzähler | open_run_level | Find a proper Guild contract to take | Adventurers' Guild hall, Ashbridge | 95/84 | 57.2 s |
| 17 | I take the Mossback Warrens Level 1 slip to the clerk and accept the contract. | Erzähler | open_run_level | Take the Warrens clearing contract at the desk | Adventurers' Guild hall, Ashbridge | 95/84 | 18.3 s |
| 18 | I take the slip, then head out of the Guild and east along the quarry track toward the Mossback Warrens, planning to camp or find lodging ne… | Erzähler | open_run_level | Travel to the Warrens with the contract active, prepared to overnight if needed | quarry track after dark | 95/84 | 26.2 s |
| 19 | I approach the turf shelter, call out a friendly greeting, and ask if I can share their fire for the night in exchange for a bit of coin or … | Erzähler | open_run_level | Get safe overnight lodging near the Warrens before clearing it at dawn | quarry track after dark | 95/84 | 17.5 s |
| 20 | I step inside and pay her the two coppers for the pallet and bowl. | Erzähler | open_run_level | Buy lodging and meal, then sleep until morning | quarry track after dark | 95/84 | 21.8 s |
| 21 | I settle onto the pallet and sleep until morning. | Erzähler | open_run_level | Rest overnight before clearing the Warrens | quarry track after dark | 95/84 | 22.0 s |
| 22 | I thank her, wash up, and set off east along the quarry track toward the Warrens hill. | Erzähler | open_run_level | Travel to the Warrens to clear the contract | Mossback Warrens | 95/84 | 31.0 s |
| 23 | I enter the Mossback Warrens through the south face main cut, sword drawn, watching the rim for goblin scouts. | Erzähler | open_run_level | Enter the dungeon to clear the level 1 contract | Mossback Warrens level 1, main cut tunnel | 95/84 | 39.1 s |
| 24 | I step back toward the tunnel mouth to keep them from surrounding me, then swing Cleave at the two scouts in front of me. | Erzähler | open_run_level | Fight the scouts with Cleave while denying the flanker | Mossback Warrens level 1, main cut tunnel | 95/84 | 28.9 s |
| 25 | I lunge at the nearest scout and swing Cleave across it and the scout beside it. | Erzähler | open_run_level | Engage and attack two scouts with Cleave | Mossback Warrens level 1, main cut tunnel | 72/84 | 35.7 s |
| 26 | I swing Cleave again at all three scouts around me. | Erzähler | open_run_level | Continue fighting the three engaged scouts with AoE | Mossback Warrens level 1, main cut tunnel | 53/84 | 28.0 s |
| 27 | I swing Cleave at both wounded scouts to finish them. | Erzähler | open_run_level | Finish the two remaining scouts with Cleave | Mossback Warrens level 1, main cut tunnel | 53/84 | 17.8 s |
| 28 | #assign STR 3 VIT 2 | System (Befehl) | open_run_level | Spend level-up stat points | Mossback Warrens level 1, main cut tunnel | 53/84 | 2.2 s |
| 29 | I press deeper into the main cut tunnel, sword ready, watching for the next goblins. | Erzähler | open_run_level | Continue clearing Mossback Warrens level 1 | main cut tunnel, pen chamber | 53/84 | 45.1 s |
| 30 | I take the used cut tunnel onward, sword ready, since it shows the most recent goblin traffic. | Erzähler | open_run_level | Continue clearing the warrens via the traveled tunnel | used cut tunnel onward | 53/84 | 32.9 s |
| 31 | I charge the closest pick-wielding warrior and swing Cleave across it and the warrior beside it. | Erzähler | open_run_level | Engage the three goblin warriors with AoE | used cut tunnel onward | 53/84 | 30.0 s |
| 32 | I strike the engaged shrieker with Quick Slash. | Erzähler | open_run_level | Attack the engaged goblin warrior A | used cut tunnel onward | 33/84 | 17.4 s |
| 33 | I swing Cleave across all three engaged warriors. | Erzähler | open_run_level | Finish the wounded trio with AoE now that all are ENGAGED | used cut tunnel onward | 17/84 | 45.0 s |
| 34 | I swing Cleave across the big warrior and the wounded club-carrier. | Erzähler | open_run_level | Finish both remaining goblins with AoE | used cut tunnel onward | 3/84 | 47.1 s |
| 35 | I strike the big goblin with Quick Slash. | Erzähler | open_run_level | Finish the last goblin | used cut tunnel onward | 3/84 | 34.7 s |
| 36 | I retreat back down the used cut tunnel toward the pen chamber, keeping watch for anything ahead, to get clear of the deep warrens while I'm… | Erzähler | open_run_level | Withdraw to recover after near-death fight | main cut tunnel, pen chamber | 3/84 | 18.3 s |
| 37 | I assign all five free stat points: #assign VIT 5 | Erzähler | open_run_level | Survive near-death state by boosting HP | main cut tunnel, pen chamber | 3/84 | 25.5 s |
| 38 | I climb the shaft ladder up to the surface to get out of the warrens while I'm near death. | Erzähler | open_run_level | Exit dungeon to recover | Mossback Warrens | 3/84 | 18.3 s |
| 39 | I head down the hillside toward the nearest settlement to find lodging and rest until my wounds recover. | Erzähler | open_run_level | Recover from near death by resting in town | Leaping Fish inn | 3/84 | 54.9 s |
| 40 | I pay the old man six copper for a room and a hot meal, then eat and sleep until morning. | Erzähler | open_run_level | Recover HP via lodging and meal | Leaping Fish inn | 3/84 | 27.0 s |
| 41 | I step inside the inn and ask the person behind the bar for a room and a hot meal. | Erzähler | open_run_level | Book lodging with someone actually present | Leaping Fish inn | 3/84 | 38.4 s |
| 42 | I accept the innkeeper's offer: six copper for the room and the hot meal, and I'll eat first. | Erzähler | open_run_level | Book lodging and meal at agreed price | Leaping Fish inn | 3/84 | 29.9 s |
| 43 | I climb into the bed in the end room and sleep until morning. | Erzähler | open_run_level | Recover HP by sleeping in the booked room | Leaping Fish inn | 125/84 | 27.5 s |
| 44 | I come downstairs and ask the innkeeper where I can find the Guild hall or contract board in this village. | Erzähler | open_run_level | Find the Guild to turn in the cleared warrens contract | Leaping Fish inn | 125/84 | 23.8 s |
| 45 | I buy the porridge for one copper, eat it, and set out west on the road toward Millbrook. | Erzähler | open_run_level | Eat and travel to the Millbrook Guild hall to turn in the warrens contract | Millbrook | 125/84 | 31.5 s |
| 46 | I go into the Guild hall and turn in the cleared Mossback Warrens contract at the desk. | Erzähler | open_run_level | Turn in completed contract | Adventurers' Guild hall, Ashbridge | 125/84 | 31.6 s |
| 47 | I ask the clerk to see the fresh postings on the board and pick out contracts suitable for a Novice. | Erzähler | open_run_level | Turn-in done; look for a new achievable contract | Adventurers' Guild hall, Ashbridge | 125/84 | 28.0 s |
| 48 | I take the Grey Wolves contract — say the word and make it active. | Erzähler | open_run_level | Accept the achievable Novice cull contract | Adventurers' Guild hall, Ashbridge | 125/84 | 24.9 s |
| 49 | I head east out of Ashbridge onto the quarry track and look for sign of wolves near the cart stops. | Erzähler | open_run_level | Hunt the grey wolf for the active cull contract | quarry track east of Ashbridge | 125/84 | 35.2 s |
| 50 | I thank Brann and head down past the spoil heaps toward the dead mule, keeping my eyes open and my sword loose. | Erzähler | open_run_level | Follow the tip to find the wolf | hollow below the spoil heaps | 125/84 | 43.4 s |
| 51 | I draw my longsword and advance on the grey wolf, ready to strike. | Erzähler | open_run_level | Engage the contract wolf | hollow below the spoil heaps | 124/84 | 14.3 s |
| 52 | I strike at the wolf with Quick Slash. | Erzähler | open_run_level | Attack the contract wolf | hollow below the spoil heaps | 124/84 | 14.5 s |
| 53 | With the wolf down, I spend my free stat points: #assign STR 2 VIT 2 AGI 1 | Erzähler | open_run_level | Allocate unspent stat points after combat | hollow below the spoil heaps | 124/84 | 17.0 s |
| 54 | #assign STR 2 VIT 2 AGI 1 | System (Befehl) | open_run_level | Spend the 5 free stat points again, as a standalone command | hollow below the spoil heaps | 124/84 | 2.2 s |
| 55 | With the points assigned, I check the contract slip — if it shows READY, I head back along the quarry track to Ashbridge to turn in the cull… | Erzähler | open_run_level | Turn in the completed wolf cull contract | Adventurers' Guild hall, Ashbridge | 124/84 | 35.9 s |
| 56 | I ask the clerk what contracts are on the board for a Novice F-rank, and whether she'd buy a grey wolf pelt and fang or know a merchant who … | Erzähler | open_run_level | Pick next contract, ask about selling loot | Adventurers' Guild hall, Ashbridge | 124/84 | 27.4 s |
| 57 | I head to the Hide Rack on the tannery lane and offer Tess my grey wolf pelt and fang, asking her price for both. | Erzähler | open_run_level | Sell surplus loot to Tess | the Hide Rack | 124/84 | 24.3 s |
| 58 | I ask Tess her price for the pelt and fang together, and accept if it's fair. | Erzähler | open_run_level | Sell pelt and fang to Tess | the Hide Rack | 124/84 | 14.4 s |
| 59 | I accept — nine copper for the pelt and fang, and I take the coin. | Erzähler | open_run_level | Sell pelt and fang to Tess | the Hide Rack | 124/84 | 15.9 s |
| 60 | I check the Guild board for a new F-rank contract I can take before dark. | Erzähler | open_run_level | Pick next contract | Adventurers' Guild hall, Ashbridge | 124/84 | 18.1 s |
| 61 | I take the barrow boars contract from the board and ask the clerk to mark it active — I'll camp near the barrowfields and hunt at first ligh… | Erzähler | open_run_level | Accept the boar cull contract, 300 cp for 4 boars | Adventurers' Guild hall, Ashbridge | 124/84 | 17.1 s |
| 62 | I head out the south road toward the barrowfields and look for a safe spot to camp for the night before hunting at first light. | Erzähler | open_run_level | Travel toward the boar contract and camp | old barrowfields south of Ashbridge | 124/84 | 26.1 s |
| 63 | I walk on toward the lamplit buildings a mile south and look for lodging for the night. | Erzähler | open_run_level | Find lodging near the barrowfields | roadside hamlet on the south road | 124/84 | 15.3 s |
| 64 | I push open the door of the boar's head inn and ask the keeper for a room and a meal for the night. | Erzähler | open_run_level | Get lodging and food at the hamlet inn | Boar's Head inn | 124/84 | 19.6 s |
| 65 | I'll take the stew and bread with the bed — what do I owe you? | Erzähler | open_run_level | Pay for meal and lodging, then sleep until morning | Boar's Head inn | 124/84 | 14.5 s |
| 66 | I'll take the supper and straw till morning for twelve copper — here's the coin. | Erzähler | open_run_level | Pay the confirmed 12 cp offer for meal and lodging | Boar's Head inn | 124/84 | 28.6 s |
| 67 | I take the candle, go up to the room, and sleep until morning. | Erzähler | open_run_level | Sleep at the inn to recover before the boar hunt | Boar's Head inn | 135/84 | 17.1 s |
| 68 | I finish my porridge, head out of the inn, and follow the south road into the Old Barrowfields to hunt tusked barrow boars. | Erzähler | open_run_level | Begin the boar cull contract | old barrowfields south of Ashbridge | 135/84 | 33.2 s |
| 69 | I follow the tracks toward the hollow, sword drawn, and scan the dark water for the boars before getting close. | Erzähler | open_run_level | Hunt the barrow boars | lip of the rise above the hollow | 135/84 | 40.1 s |
| 70 | I stay downwind on the rise and wait for the nearest boar, the drinker, to wander a few paces from the others, then charge and Cleave into i… | Engine (Menü/Rückfrage) | open_run_level | Open the boar fight on isolated target | lip of the rise above the hollow | 135/84 | 8.3 s |
| 71 | I charge the drinker, Tusked Barrow Boar C, and Cleave into it. | Erzähler | open_run_level | Attack the isolated drinker boar with Cleave | lip of the rise above the hollow | 135/84 | 24.6 s |
| 72 | I meet the charging drinker's tusks and Cleave into Tusked Barrow Boar D. | Erzähler | open_run_level | Cleave the engaged boar D | lip of the rise above the hollow | 48/84 | 21.0 s |
| 73 | I use Quick Slash on the wounded Tusked Barrow Boar D to finish it off. | Erzähler | open_run_level | Kill the wounded boar | lip of the rise above the hollow | 0/84 | 38.1 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 6 (notiert vor Zug 7): Board was stripped bare; new postings expected midday. Guild sells F-rank skill primers for 80 copper.
- zu Zug 9 (notiert vor Zug 10): Novice bundle failed to arrive; board still has no Novice work. Warrens offer loot-based pay, half a day east.
- zu Zug 11 (notiert vor Zug 12): HUD still shows Guild hall as location despite narration of arrival at the hill; will verify against next System result.
- zu Zug 12 (notiert vor Zug 13): HUD location still shows Guild hall despite confirmed travel narration; will keep verifying against System results.
- zu Zug 13 (notiert vor Zug 14): HUD location still shows the Guild hall despite confirmed travel; also XP 0/100 with no active quest panel for the Warrens work.
- zu Zug 14 (notiert vor Zug 15): Engine result placed me back in the Guild hall despite narrated scouting at the palisade; treating the HUD location as authoritative.
- zu Zug 38 (notiert vor Zug 39): HUD still shows 5 Free Stat Points and VIT 12 despite the assign narrating success — possible mismatch to recheck with #status.
- zu Zug 39 (notiert vor Zug 40): Assign narrated success but HUD still shows Free Stat Points 5 and VIT 12 — mismatch to recheck after recovery.
- zu Zug 42 (notiert vor Zug 43): Room and meal are confirmed bought; the 5 free stat points still show unspent in the HUD despite the earlier assign narrating success — will recheck with #status after recovery.
- zu Zug 44 (notiert vor Zug 45): Guild is in Millbrook, half a day west; village is Thorpsden. Free Stat Points 5 still unspent in HUD.
- zu Zug 46 (notiert vor Zug 47): HUD says location is Ashbridge, not Millbrook as narrated; coin shows 9 Silver despite narrated 60 copper payout on 30 copper. Will trust the System result and check #status if amounts matter later.
- zu Zug 48 (notiert vor Zug 49): HUD confirms 5 Free Stat Points still unspent; will spend once combat is settled.
- zu Zug 53 (notiert vor Zug 54): The first #assign produced no System confirmation; HUD still shows 5 Free Stat Points. Retrying as a pure command.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t25 | 25 | 3 | – | nein | 3 | gewonnen, 236 XP |
| enc.t31 | 32 | 3 | – | nein | 3 | gewonnen, 210 XP |
| enc.t50r | 51 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t69 | 72 | 4 | – | nein | 0 | **tot** |

## Quests

- **Cull the Quarry Track Wolves** — expired (Zug 47)
  - Aufgabe: Kill 1 grey wolf at quarry track east of Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 grey wolf killed at quarry track east of Ashbridge.
- **Thin the Eel-Weir Serpents** — expired (Zug 47)
  - Aufgabe: Kill 4 marsh constrictors at eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 marsh constrictors killed at eel-weirs of the Reed Flats.
- **Cull the Barrowfield Boars** — expired (Zug 47)
  - Aufgabe: Kill 3 tusked barrow boars at old barrowfields south of Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 tusked barrow boars killed at old barrowfields south of Ashbridge.
- **Slay the Duskmarsh Marsh King** — expired (Zug 47)
  - Aufgabe: Kill 1 the great horned marsh king at drowned alder stands of the Duskmarsh. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the great horned marsh king killed at drowned alder stands of the Duskmarsh.
- **Clear Mossback Warrens Level 1** — active (Zug 17) → completed (Zug 46), Dungeon loc.mossback_warrens Ebene 1
  - Aufgabe: Clear level 1 of Mossback Warrens. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Mossback Warrens is clear.
- **Cull the Grey Wolves on the Quarry Track** — active (Zug 48) → completed (Zug 55)
  - Aufgabe: Kill 1 grey wolf at quarry track east of Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 grey wolf killed at quarry track east of Ashbridge.
- **Cull the Tusked Barrow Boars of the Old Barrowfields** — active (Zug 61)
  - Aufgabe: Kill 4 tusked barrow boar at old barrowfields south of Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 tusked barrow boar killed at old barrowfields south of Ashbridge.

## Auffälligkeiten

- Zug 6, Nachricht 11 (board_failed): the board generator failed
- Zug 14, Nachricht 28 (extraction_repaired): the extractor's first answer needed a repair
- Zug 16, Nachricht 32 (extraction_repaired): the extractor's first answer needed a repair
- Zug 29, Nachricht 58 (extraction_repaired): the extractor's first answer needed a repair
- Zug 37, Nachricht 73 (stat_words): the player spent Stat Points in words, not with #assign; nothing was assigned (for review: did the story tell them as done?)
- Zug 39, Nachricht 78 (extraction_repaired): the extractor's first answer needed a repair
- Zug 42, Nachricht 84 (extraction_repaired): the extractor's first answer needed a repair
- Zug 45, Nachricht 90 (extraction_repaired): the extractor's first answer needed a repair
- Zug 53, Nachricht 105 (stat_words): the player spent Stat Points in words, not with #assign; nothing was assigned (for review: did the story tell them as done?)
- Zug 62, Nachricht 124 (extraction_repaired): the extractor's first answer needed a repair
- Zug 66, Nachricht 132 (extraction_repaired): the extractor's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 18× keine gültige JSON-Entscheidung (Züge 1, 2, 4, 6, 7, 11, 12, 13, 14, 16, 28, 32, 36, 43, 47, 51, 58, 63)

System-Panels: CLARIFY 1, NOT TAKEN 0, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: ambient 9, no_go 6, guild_canon 2, scene_context 19, engine_owned_fact 9, group_unclear 3, world_rule 7, attack_commitment 4, offer 1, entity_fact 1, time_cap 1, guild_completion 1, engine_owned_memory 1, guild_payout 2, coin_already_received 1, engine_recovery 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 18/73 Erstantworten ungültig (24.7 %); 18 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 69 | 0 | 2.7 s | 9.0 s | 11533 | 9919 | 66 | – | stop 69 | 0 |
| narrator | 68 | 0 | 12.6 s | 22.2 s | 11452 | 8666 | 419 | – | stop 68 | 0 |
| extract | 76 | 8 | 5.9 s | 13.8 s | 12088 | 9618 | 332 | – | stop 76 | 0 |
| board | 4 | 1 | 13.7 s | 24.3 s | 2512 | 2354 | 1126 | – | stop 4 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 40:33 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 14.3 s) | 0:43 min |
| 73 Züge, Spiel (Senden bis HUD nach der Extraktion) | 33:30 min — Median 27.4 s, p90 43.4 s, max 57.2 s |
| 73 Züge, Spieler-Entscheidung | 5:13 min — Median 2.9 s, 18 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 4:41 min / 1:03 min / 15:49 min / 9:10 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 31.8 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 21:13 min, 80 Züge ≈ 42:26 min (ohne Einrichtung) |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
