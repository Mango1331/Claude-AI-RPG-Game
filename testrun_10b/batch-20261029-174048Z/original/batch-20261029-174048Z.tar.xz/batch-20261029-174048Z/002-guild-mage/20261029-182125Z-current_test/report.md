# Avereth Live-Test 20261029-182125Z-current_test

## Kurzfassung

- **Laufprofil:** guild-mage; Startklasse Mage, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** abgebrochen: Limit erreicht — 150 turns
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 8. Sicherheitsgrenzen: 150 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** Level 6, 178 XP seit Levelaufstieg, 304 cp, HP 57, MP 78; Ort loc.glassmere.maren_two_needles_shop. Ausrüstung und Skills stehen in evaluation.json → progression.checkpoint.
- **Charakter:** mage (mage.arcane_bolt, mage.arcane_wave) · Regelstand 2 (Warrior, Mage, Rogue)
- **Ziel-Dungeon:** Glimmerdeep Grotto, Ebene 1 (Vertrag quest.clear_glimmerdeep_grotto_level_1)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: curious adventurer: follow interesting opportunities without forcing dangerous encounters
- **Züge:** 150 · **Dauer:** 119:00 min · **LLM-Aufrufe der Engine/des Erzählers:** 418
- **Beobachtete Abdeckung:** 38 unterschiedliche gebuchte Reiseziele · 12 Kämpfe · 2 Verkäufe (134 cp Umsatz, ohne Questzahlungen/Geschenke) · 0 Ausrüstungswechsel · 0 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 32
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.119 |
| Git | b09274c8c4d9 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 14.3 s |
| Browser | chrome 156.0.8078.49 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261029-182125Z-current_test“, Seed 1717914048 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | I choose Mage. | Engine (Menü/Rückfrage) | creation_complete | Select Mage as base class | public roadside verge outside Glassmere | 90/84 | 2.3 s |
| 2 | I select Arcane Wave and Arcane Bolt as my two starter skills. | Engine (Menü/Rückfrage) | creation_complete | Complete character creation with required AoE skill | public roadside verge outside Glassmere | 90/96 | 2.1 s |
| 3 | I walk through the city gate into Glassmere and head for the Adventurers' Guild hall. | Erzähler | open_run_level | Enter city and find the Guild board | Adventurers' Guild hall, Glassmere | 90/96 | 21.1 s |
| 4 | Registration, please — I'd like to sign up as a new adventurer. | Erzähler | open_run_level | Register at the Guild to unlock contracts | Adventurers' Guild hall, Glassmere | 90/96 | 297.0 s |
| 5 | Yes — here's the two silver. I'll sign and touch the measuring stone. | Erzähler | open_run_level | Complete Guild registration | Adventurers' Guild hall, Glassmere | 90/96 | 29.1 s |
| 6 | I walk over to the contract board and read the slips available to a Novice. | Erzähler | open_run_level | Browse the Guild board for a first contract | Adventurers' Guild hall, Glassmere | 90/96 | 50.5 s |
| 7 | I take the Cull the Ford Serpent slip from the Novice board to the counter. "I'll take this one — please mark it taken and make it active fo… | Erzähler | open_run_level | Accept the first achievable Novice contract | Adventurers' Guild hall, Glassmere | 90/96 | 18.6 s |
| 8 | I leave the Guild and take the river road south toward Miller's Crossing, asking at the south gate for the mill track. | Erzähler | open_run_level | Travel to the contract site | Miller's Crossing, the shallows below the mill wheel | 90/96 | 33.0 s |
| 9 | I approach the miller in the doorway and tell him I've taken the Guild contract to cull the mud viper at his ford, then ask where it's been … | Erzähler | open_run_level | Get information on the viper's location | Miller's Crossing, the shallows below the mill wheel | 90/96 | 20.1 s |
| 10 | I thank the miller, then move quietly to the near bank by the reeded gravel bar and stand still, waiting for the water to settle so the vipe… | Erzähler | open_run_level | Ambush the viper from the bank | the near bank by the reeded gravel bar | 90/96 | 22.5 s |
| 11 | I keep still at the water's edge, staff ready, waiting for the viper to rise in the murk — and the moment it shows itself, I cast Arcane Bol… | Engine (Menü/Rückfrage) | open_run_level | Ambush and attack the ford viper | the near bank by the reeded gravel bar | 90/96 | 5.6 s |
| 12 | I keep still and keep watching the murk, waiting until the viper actually shows itself above the surface — then I cast Arcane Bolt at it. | Erzähler | open_run_level | Ambush the ford viper once it becomes a targetable actor | the near bank by the reeded gravel bar | 90/96 | 27.5 s |
| 13 | I cast Arcane Bolt at the mud viper. | Erzähler | open_run_level | Attack the surfaced viper | the near bank by the reeded gravel bar | 90/86 | 21.1 s |
| 14 | I tell the miller the ford is clear, then take the road back north to the Guild hall in Caelreth to turn in the contract. | Erzähler | open_run_level | Return to Guild for turn-in | Adventurers' Guild hall, Glassmere | 90/86 | 44.1 s |
| 15 | I ask the clerk what novice contracts are on the board tonight. | Erzähler | open_run_level | Pick the next Guild contract | Adventurers' Guild hall, Glassmere | 90/86 | 46.8 s |
| 16 | I take the Glimmerdeep Grotto, Level 1 contract slip from the board and ask the clerk to sign it out to me. | Erzähler | open_run_level | Accept a suitable novice contract | Adventurers' Guild hall, Glassmere | 90/86 | 25.4 s |
| 17 | I head out the north road gate and walk west toward the Glimmerdeep Grotto entrance in the hills. | Erzähler | open_run_level | Travel to the grotto for the active contract | Glimmerdeep Grotto | 90/86 | 31.5 s |
| 18 | I enter the dungeon and keep to the left wall as the chalk note advises, watching for beetles or slimes in the blue-lit passage. | Erzähler | open_run_level | Enter the grotto and clear level 1 | crystal dome chamber | 90/86 | 21.1 s |
| 19 | I cast Arcane Wave to hit the clustered beetles, then fall back a step toward the passage mouth. | Engine (Menü/Rückfrage) | open_run_level | Open the beetle fight with AoE on the group | crystal dome chamber | 90/86 | 6.1 s |
| 20 | I cast Arcane Wave at Glass Beetles A and B, the two nearest, then fall back a step toward the passage mouth. | Erzähler | open_run_level | Open the beetle fight with AoE on named targets | crystal dome chamber | 90/72 | 16.5 s |
| 21 | I cast Arcane Wave at Glass Beetles A, C and D, then fall back another step toward the passage mouth. | Engine (Menü/Rückfrage) | open_run_level | Finish the wounded beetles with AoE while keeping distance | crystal dome chamber | 90/72 | 4.8 s |
| 22 | I cast Arcane Wave on Glass Beetle A. | Erzähler | open_run_level | Strike the wounded nearest beetle with the area skill | crystal dome chamber | 90/58 | 21.2 s |
| 23 | #assign INT 3 WIL 3 VIT 2 PER 2 | System (Befehl) | open_run_level | Spend 10 free stat points | crystal dome chamber | 90/58 | 2.1 s |
| 24 | I take the passage continuing down where the crystals grow brighter, watching for more threats. | Erzähler | open_run_level | Continue clearing dungeon level 1 | humming vault chamber | 90/58 | 113.4 s |
| 25 | I cast Arcane Wave across the crust plates where the slimes cluster thickest, staying near the chamber entrance. | Engine (Menü/Rückfrage) | open_run_level | Open the slime fight with AoE from range | humming vault chamber | 90/58 | 6.9 s |
| 26 | I cross the crust plates carefully toward the bright crystal seam at the chamber's middle, watching for the slimes. | Erzähler | open_run_level | Approach the seam to draw slimes into targetable positions | humming vault chamber | 90/58 | 34.4 s |
| 27 | I retreat carefully back toward the chamber entrance, avoiding the ticking plates, since the contract only covers Level 1. | Erzähler | open_run_level | Withdraw from Level 2 slimes and clear Level 1 contract instead | crystal dome chamber | 90/58 | 14.1 s |
| 28 | I head back down the low crawl to the right, since the contract needs more of Level 1 cleared and the slimes stay off the crawl's path. | Erzähler | open_run_level | Clear the remaining Level 1 threat via the low crawl | mossy stream chamber | 90/58 | 36.4 s |
| 29 | I take the dry walking passage, watching for threats as I go. | Erzähler | open_run_level | Continue clearing dungeon Level 1 via the dry passage | old workroom chamber | 90/58 | 28.4 s |
| 30 | I cast Arcane Wave at the two slimes from the passage mouth, staying out of their reach. | Erzähler | open_run_level | Open the slime fight with AoE from range | old workroom chamber | 90/44 | 33.1 s |
| 31 | I cast Arcane Bolt at Mineral Slime B to finish it. | Erzähler | open_run_level | Finish the wounded slime with a ranged spell | old workroom chamber | 90/34 | 22.4 s |
| 32 | #quest Clear Glimmerdeep Grotto, Level 1 | System (Befehl) | open_run_level | Check why the contract is not cleared after all six threats were defeated | old workroom chamber | 90/34 | 2.2 s |
| 33 | All six Level 1 threats are defeated, so I head back through the dry passage toward the grotto entrance to leave the dungeon. | Erzähler | open_run_level | Exit the dungeon to complete the Level 1 clear | wooded hollow outside Glimmerdeep Grotto | 90/34 | 183.3 s |
| 34 | I head down the path to town and go to the Guild hall, where I present the contract slip and tell the clerk I have defeated all six Level 1 … | Erzähler | open_run_level | Turn in the grotto clear contract at the Guild hall | Adventurers' Guild hall, Glassmere | 90/34 | 27.6 s |
| 35 | I ask the clerk where the nearest inn is, then head there for the night. | Erzähler | open_run_level | Rest for the night before returning to clear the rest of grotto level 1 | the Drowned Lantern | 90/34 | 15.7 s |
| 36 | I pay Marta 8 copper for the supper and the bed for the night, eat, and sleep until morning. | Erzähler | open_run_level | Rest and recover MP before returning to clear the rest of grotto level 1 | the Drowned Lantern | 110/156 | 46.0 s |
| 37 | I head back out of town to Glimmerdeep Grotto and descend into its deeper passages, aiming to clear the rest of the first floor. | Erzähler | open_run_level | Finish clearing grotto level 1 | landing where the passage splits | 110/156 | 147.4 s |
| 38 | I take the left tunnel, staff raised, following the clicking sound. | Erzähler | open_run_level | Clear the remaining threats on level 1 | rust-streaked feeding chamber | 110/156 | 67.9 s |
| 39 | I strike the rust-streaked slime with Arcane Bolt, staying clear of its scattered chips. | Engine (Menü/Rückfrage) | open_run_level | Fight the mineral slime on Level 2 | rust-streaked feeding chamber | 110/156 | 16.7 s |
| 40 | Combat hasn't started yet, so I ready my staff and call out a challenge to the rust-streaked slime to draw its attention and begin the fight… | Erzähler | open_run_level | Provoke the slime into an active encounter so it becomes a targetable actor | rust-streaked feeding chamber | 110/156 | 54.0 s |
| 41 | I step up to the rust-streaked slime and prod its flank hard with my staff, trying to rouse it into a fight. | Engine (Menü/Rückfrage) | open_run_level | Turn the feeding slime into an active combat target by direct contact | rust-streaked feeding chamber | 110/156 | 23.5 s |
| 42 | I leave the feeding slime to its meal and take the passage out the chamber's far side, angling further down. | Erzähler | open_run_level | Continue exploring since the slime is not a targetable actor | broad low hall with pale veined floor | 110/156 | 98.6 s |
| 43 | I edge along the hall with my staff raised, watching the dark and the smooth-topped pillars for any movement. | Erzähler | open_run_level | Explore the veined hall cautiously | broad low hall with pale veined floor | 110/156 | 67.5 s |
| 44 | I circle the crystal patch at a safe distance, scanning past it toward the far shimmer, and if the beetle stays motionless I leave it alone … | Erzähler | open_run_level | Explore the hall while avoiding an unprovoked fight | broad low hall with pale veined floor | 110/156 | 82.3 s |
| 45 | I search the edges of the second crystal field for a gap or a way to skirt around it toward the carved doorway. | Erzähler | open_run_level | Find a route past the crystal field to the marked door | broad low hall with pale veined floor | 110/156 | 60.8 s |
| 46 | I follow the gap along the left-hand wall past the field's thinning tail and step through the carved doorway into the dark beyond. | Erzähler | open_run_level | Reach the marked doorway and enter the deeper hall | passage angling further down | 110/156 | 67.8 s |
| 47 | I take the straight worked road down toward the scraping, staff raised and light held high. | Erzähler | open_run_level | Investigate the source of the scraping down the main gallery | broad low hall with pale veined floor | 110/156 | 61.3 s |
| 48 | I cast Arcane Bolt at the wall-eating mineral slime from thirty paces out, staying clear of its bulk. | Engine (Menü/Rückfrage) | open_run_level | Attack the large slime from range | broad low hall with pale veined floor | 110/156 | 13.5 s |
| 49 | Since the slime isn't targetable, I leave the chamber and head back up the worked road toward the grotto entrance, then travel to the Guild … | Erzähler | open_run_level | Exit the dungeon and turn in the cleared level 1 contract | Adventurers' Guild hall, Glassmere | 110/156 | 62.9 s |
| 50 | Before leaving the counter, I ask the clerk what part of the grotto counts as uncleared — is there more than the main level, side grottos or… | Erzähler | open_run_level | Learn the contract's actual clear condition | Adventurers' Guild hall, Glassmere | 110/156 | 59.8 s |
| 51 | I check the quest panel for the Glimmerdeep contract to see exactly which beasts or areas it still lists as outstanding. | Erzähler | open_run_level | Identify the uncleared part of the grotto | Adventurers' Guild hall, Glassmere | 110/156 | 58.0 s |
| 52 | I return to Glimmerdeep Grotto and take the worked road down to the lower gallery, planning to attack the big mineral slime again — this tim… | Erzähler | open_run_level | Kill the remaining slime to complete the cull | lower gallery | 110/156 | 76.8 s |
| 53 | The seal already counts the slime dead, so I head back out of the grotto and travel to the Guild hall, then present the contract slip to tur… | Erzähler | open_run_level | Turn in the cleared Level 1 contract | Adventurers' Guild hall, Glassmere | 110/156 | 79.7 s |
| 54 | I check the Guild board for a new contract suitable for a Level 3 Novice mage. | Erzähler | open_run_level | Pick the next Guild contract | Adventurers' Guild hall, Glassmere | 110/156 | 67.7 s |
| 55 | I take the Mud Viper contract slip from the board and ask the clerk to register it as my active contract. | Erzähler | open_run_level | Accept the next achievable Novice contract | Adventurers' Guild hall, Glassmere | 110/156 | 42.2 s |
| 56 | The Mud Viper contract is active. It's late in the day, so I ask the clerk where I can find affordable lodging for the night in Glassmere. | Erzähler | open_run_level | Get lodging for the night before travelling east | Adventurers' Guild hall, Glassmere | 110/156 | 163.0 s |
| 57 | I go to the Cooper's Rest and take a room for the night, paying the four coppers, then sleep until morning. | Erzähler | open_run_level | Lodging and recovery before the viper hunt | the Cooper's Rest | 110/156 | 80.5 s |
| 58 | I take the stew for one copper, eat, then go up to the third-door room and sleep until morning. | Erzähler | open_run_level | Buy supper and sleep until morning | the Cooper's Rest | 110/156 | 38.8 s |
| 59 | I pay the four coppers for the third-door room, then sleep until morning. | Erzähler | open_run_level | Buy lodging and recover overnight | the Cooper's Rest | 110/156 | 24.6 s |
| 60 | I leave the Cooper's Rest and head east through the gate toward Miller's Crossing to hunt the mud vipers. | Erzähler | open_run_level | Travel to the viper hunting ground | Miller's Crossing, the shallows below the mill wheel | 110/156 | 30.6 s |
| 61 | I approach the miller in the doorway and tell him I'm here on the Guild contract to cull mud vipers, asking if there's anything I should kno… | Erzähler | open_run_level | Talk to the miller, then hunt the viper | Miller's Crossing, the shallows below the mill wheel | 110/156 | 54.3 s |
| 62 | I thank the millers and head forty strides downstream, then stand still on a gravel bar at the shallows' edge with my staff ready, waiting f… | Erzähler | open_run_level | Hunt the mud viper using the millers' trick | the widest gravel bar | 110/156 | 43.5 s |
| 63 | I stand still on the gravel bar with my staff ready and wait quietly for the viper to come up under me. | Erzähler | open_run_level | Hunt the mud viper using the millers' trick | the widest gravel bar | 110/156 | 55.8 s |
| 64 | I cast Arcane Bolt at the viper's head as it drives onto the bar. | Erzähler | open_run_level | Attack the engaged mud viper | the widest gravel bar | 110/146 | 36.6 s |
| 65 | I take the dead viper's skin and fangs, then head back up the bank to the miller and tell him the viper's killed, before returning to the Gu… | Erzähler | open_run_level | Turn in the completed viper contract | Adventurers' Guild hall, Glassmere | 110/146 | 102.7 s |
| 66 | #assign INT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up points | Adventurers' Guild hall, Glassmere | 110/146 | 2.4 s |
| 67 | I ask the clerk what contracts are on the board today. | Erzähler | open_run_level | Pick the next Guild contract | Adventurers' Guild hall, Glassmere | 110/146 | 35.4 s |
| 68 | I take the Bog Striders contract slip and tell the clerk I'm accepting it. | Erzähler | open_run_level | Accept the bog striders cull contract | Adventurers' Guild hall, Glassmere | 110/146 | 15.8 s |
| 69 | I leave the Guild hall and head south through the gate, following the eel-road toward the Reed Flats. | Erzähler | open_run_level | Travel to the bog striders hunting ground | the eel-weirs of the Reed Flats south of Glassmere | 110/146 | 43.0 s |
| 70 | I confirm to the fishermen I'm here for the Guild job, then cast Arcane Bolt at the nearest bog strider. | Erzähler | open_run_level | Engage the striders for the cull contract | the eel-weirs of the Reed Flats south of Glassmere | 84/136 | 27.2 s |
| 71 | I cast Arcane Bolt at Bog Strider B, the larger one biting my hip. | Erzähler | open_run_level | Kill the second strider | the eel-weirs of the Reed Flats south of Glassmere | 72/126 | 20.0 s |
| 72 | I cast Arcane Bolt at Bog Strider C at point-blank range. | Erzähler | open_run_level | Kill the last strider | the eel-weirs of the Reed Flats south of Glassmere | 72/116 | 21.1 s |
| 73 | I accept the fisherman's offer and follow him to the village so his wife can treat the bites. | Erzähler | open_run_level | Get wounds cleaned, then finish the contract | stilt village on the Reed Flats | 72/116 | 34.2 s |
| 74 | #assign INT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up points | stilt village on the Reed Flats | 72/116 | 2.6 s |
| 75 | I thank Torman and the healer, then head back north along the eel-road to the Guild hall in Caelreth to turn in the strider cull contract. | Erzähler | open_run_level | Return to the Guild and turn in the contract | Adventurers' Guild hall, Glassmere | 72/116 | 47.4 s |
| 76 | I tell the clerk I'll head back out at first light to hunt the fourth strider at Weir Four, and ask if there's a bed in Glassmere for the ni… | Erzähler | open_run_level | Rest overnight, then hunt the fourth strider | Adventurers' Guild hall, Glassmere | 72/116 | 32.6 s |
| 77 | I go to my room at the Drowned Eel and sleep until morning. | Erzähler | open_run_level | Rest overnight before hunting the fourth strider at dawn | the Drowned Eel | 72/116 | 32.3 s |
| 78 | I pay Ma Gerrit the nine copper for the night, then go to the back room and sleep until morning. | Erzähler | open_run_level | Pay for lodging, then rest | back room of the Drowned Eel | 72/116 | 21.6 s |
| 79 | I eat the porridge downstairs, then set out south along the causeway toward Weir Four to hunt the fourth bog strider. | Erzähler | open_run_level | Hunt the fourth strider at dawn | the eel-weirs of the Reed Flats south of Glassmere | 72/116 | 46.8 s |
| 80 | I hold my ground on the causeway, staff ready, and wait for the wake to come within reach of Arcane Wave. | Erzähler | open_run_level | Engage the approaching creature at the causeway | the eel-weirs of the Reed Flats south of Glassmere | 72/116 | 23.2 s |
| 81 | I cast Arcane Wave at the bog strider on the causeway. | Erzähler | open_run_level | Attack the fourth strider | the eel-weirs of the Reed Flats south of Glassmere | 57/102 | 17.6 s |
| 82 | I cast Arcane Bolt at the bog strider to finish it. | Erzähler | open_run_level | Finish the fourth strider | the eel-weirs of the Reed Flats south of Glassmere | 57/92 | 21.7 s |
| 83 | I pick up the cracked chitin plate, then walk north along the causeway back toward Glassmere to turn in the contract at the Guild hall. | Erzähler | open_run_level | Loot, then return for turn-in | Glassmere | 57/92 | 22.0 s |
| 84 | I walk through the south gate and head to the Guild hall to turn in the bog strider contract at the counter. | Erzähler | open_run_level | Turn in the completed contract at the Guild hall | Adventurers' Guild hall, Glassmere | 57/92 | 39.5 s |
| 85 | #assign INT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up stat points | Adventurers' Guild hall, Glassmere | 57/92 | 2.6 s |
| 86 | I look over the posted contract slips on the Guild board for a Novice job I can take. | Erzähler | open_run_level | Pick a new Guild contract | Adventurers' Guild hall, Glassmere | 57/92 | 37.2 s |
| 87 | I take the Mud Viper contract slip from the board and accept it at the counter. | Erzähler | open_run_level | Take the achievable Novice viper cull | Adventurers' Guild hall, Glassmere | 57/92 | 17.3 s |
| 88 | Before leaving town I stop at the physicker two doors past the chandler's and ask to have my wounds treated. | Erzähler | open_run_level | Recover HP before the viper contract | physicker's shop | 57/92 | 31.5 s |
| 89 | I take the five copper treatment with the spirits wash. | Erzähler | open_run_level | Pay for the recommended healing | physicker's shop | 57/92 | 24.3 s |
| 90 | I thank her and leave, then take the road east to Miller's Crossing and head for the Mill Shallows to hunt mud vipers. | Erzähler | open_run_level | Travel to the viper contract site | the shallows below the mill wheel, Miller's Crossing | 57/92 | 31.9 s |
| 91 | I cast Arcane Wave at the three basking vipers, aiming to catch all of them in the blast. | Engine (Menü/Rückfrage) | open_run_level | Open the viper cull with AoE on the spread group | the shallows below the mill wheel, Miller's Crossing | 57/92 | 17.9 s |
| 92 | I cast Arcane Wave at Mud Viper C, the nearest and thickest one. | Erzähler | open_run_level | AoE centered on the named viper | the shallows below the mill wheel, Miller's Crossing | 57/78 | 25.3 s |
| 93 | I collect the proof of the kill — skins and fangs from the three vipers — and head back to the Guild hall in town to turn in the Mud Viper c… | Erzähler | open_run_level | Turn in the completed viper cull at the Guild hall | Adventurers' Guild hall, Glassmere | 57/78 | 43.0 s |
| 94 | I ask the clerk what contracts are on the board suitable for a Novice mage. | Erzähler | open_run_level | Pick the next Guild contract | Adventurers' Guild hall, Glassmere | 57/78 | 33.5 s |
| 95 | I take the Bog Striders contract from the board and tell the clerk I'm accepting it. | Erzähler | open_run_level | Accept the achievable level-5 cull contract | Adventurers' Guild hall, Glassmere | 57/78 | 54.5 s |
| 96 | Before heading out, I ask the clerk if the Guild sells healing or if there's a physicker nearby — I'm still wounded and want my HP restored … | Erzähler | open_run_level | Address the unhealed wounded state before the strider cull | Adventurers' Guild hall, Glassmere | 57/78 | 49.7 s |
| 97 | I go to Maren Two-Needles's shop and ask her to treat my wounds, paying whatever she charges. | Erzähler | open_run_level | Get real healing before the strider cull | Maren Two-Needles' shop | 57/78 | 62.2 s |
| 98 | I pay her two silver and four copper for the treatment as quoted. | Erzähler | open_run_level | Accept Maren's confirmed healing offer | Maren Two-Needles' shop | 57/78 | 23.1 s |
| 99 | I thank Maren and check my wounds — the treatment should have mended me, yet I still feel weak. I ask her if the stitching needs time to tak… | Erzähler | open_run_level | Verify the healing actually applied before heading to the Flats | Maren Two-Needles' shop | 57/78 | 43.7 s |
| 100 | I take a room at the nearest inn, order a hot meal, eat it, and then rest until my strength returns. | Erzähler | open_run_level | Recover HP before the Bog Strider cull | Maren Two-Needles' shop | 57/78 | 52.9 s |
| 101 | I take the day room for six copper and a bowl of the mutton stew for four, then sit by the hearth and eat before resting until my strength r… | Erzähler | open_run_level | Book room, buy meal, rest to recover HP | Maren Two-Needles' shop | 57/78 | 31.8 s |
| 102 | I take the key up to the second door, wash, and sleep in the bed until I wake rested. | Erzähler | open_run_level | Rest overnight to recover HP before the strider cull | Maren Two-Needles' shop | 57/78 | 58.3 s |
| 103 | I pay the innkeeper ten copper for the day room and the mutton stew, take the key, eat the stew, then go up to the second door and sleep unt… | Erzähler | open_run_level | Actually pay for room and meal, then rest to recover HP | day room above Maren Two-Needles' shop | 57/78 | 29.3 s |
| 104 | I pull the blanket over myself and sleep in the bed until I wake rested. | Engine (Menü/Rückfrage) | open_run_level | Sleep to recover HP before the Bog Strider cull | day room above Maren Two-Needles' shop | 57/78 | 8.9 s |
| 105 | I sleep in the bed until morning. | Erzähler | open_run_level | Sleep until morning to recover HP | day room above Maren Two-Needles' shop | 125/288 | 42.2 s |
| 106 | I check out with Maren and head for the Guild hall to sell my surplus loot and look at the contract board. | Erzähler | open_run_level | Sell loot and pick up next work after recovery | Adventurers' Guild hall, Glassmere | 125/288 | 86.3 s |
| 107 | I accept the whole lot for twelve silver and ask to see the contract board for new work. | Erzähler | open_run_level | Sell all surplus loot for 12 silver and check the board | Adventurers' Guild hall, Glassmere | 125/288 | 90.1 s |
| 108 | I ask the clerk to register me for the contract 'Thin the Bog Striders at the Reed Flats Eel-Weirs' and confirm it is active on my plate. | Erzähler | open_run_level | Resume the active bog strider cull via the board | Adventurers' Guild hall, Glassmere | 125/288 | 38.3 s |
| 109 | I leave the Guild hall and travel south to the Reed Flats eel-weirs to hunt bog striders. | Erzähler | open_run_level | Travel to the Reed Flats for the strider cull | the eel-weirs of the Reed Flats south of Glassmere | 125/288 | 50.8 s |
| 110 | I thank the fisher and follow the peat path toward the eastern stakes, keeping low and watching the reeds for the striders. | Erzähler | open_run_level | Approach the eastern weirs and engage the bog striders | the eastern stakes | 125/288 | 29.0 s |
| 111 | I back a few paces along the firm path, then cast Arcane Bolt at the reeds where the nearest hidden strider is bending the canes. | Engine (Menü/Rückfrage) | open_run_level | Attack the hidden strider first to open the cull | the eastern stakes | 125/288 | 7.7 s |
| 112 | I hold my ground and call out a challenge toward the reeds, staff raised, trying to provoke the hidden striders into showing themselves as t… | Erzähler | open_run_level | Force the hidden striders to emerge so they become valid targets | the eastern stakes | 125/288 | 158.1 s |
| 113 | I cast Arcane Wave at the three lunging striders, hitting all of them as they cross the water toward me. | Engine (Menü/Rückfrage) | open_run_level | Open the cull with an AoE on the engaged group | the eastern stakes | 125/288 | 30.0 s |
| 114 | I cast Arcane Wave at Bog Strider E, Bog Strider F and Bog Strider G, the three engaged striders. | Erzähler | open_run_level | AoE the three named striders | the eastern stakes | 111/274 | 56.7 s |
| 115 | I finish Bog Strider F with a Basic Attack while it is wounded. | Erzähler | open_run_level | Kill the last engaged strider | the eastern stakes | 111/274 | 13.6 s |
| 116 | I press east past the broken stakes into the thickening reed beds, staff ready, hunting the remaining striders the fisher counted. | Erzähler | open_run_level | Continue the cull toward 6/6 | the strider moulting ground | 111/274 | 37.5 s |
| 117 | I hold my ground on the firm path and wait for the line of reeds to part, then cast Arcane Wave at the first three striders that emerge from… | Engine (Menü/Rückfrage) | open_run_level | Open the second engagement with AoE on the emerging group | the strider moulting ground | 111/274 | 5.5 s |
| 118 | I hold my ground and keep watching the bending reeds, staff ready, and cast Arcane Wave at the first three striders as soon as they become v… | Engine (Menü/Rückfrage) | open_run_level | Wait for striders to be targetable, then AoE them | the strider moulting ground | 111/274 | 5.5 s |
| 119 | I back away toward firmer ground to let them emerge into the open, and cast Arcane Wave at the striders as soon as they become targetable. | Engine (Menü/Rückfrage) | open_run_level | Draw striders into open ground, then AoE them | the strider moulting ground | 111/274 | 7.0 s |
| 120 | I stop casting and advance toward the bending reed line to meet the striders face to face, then attack whichever one comes into view first w… | Engine (Menü/Rückfrage) | open_run_level | Force the hidden striders to become targetable by closing the distance | the strider moulting ground | 111/274 | 5.3 s |
| 121 | I walk toward the nearest stopped reed bend ten feet off the path and search the reeds there for the hidden striders. | Erzähler | open_run_level | Locate the hidden striders so they become targetable | stopped reed bend | 82/274 | 20.9 s |
| 122 | I cast Arcane Wave at Bog Strider H and Bog Strider I. | Engine (Menü/Rückfrage) | open_run_level | AoE both engaged striders | stopped reed bend | 82/274 | 9.3 s |
| 123 | I cast Arcane Wave on Bog Strider H. | Erzähler | open_run_level | AoE centered on a named target to hit both striders | stopped reed bend | 62/260 | 31.7 s |
| 124 | I cast Arcane Wave on Bog Strider I. | Erzähler | open_run_level | Finish the wounded strider with AoE | stopped reed bend | 62/246 | 17.6 s |
| 125 | #assign VIT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up points for survivability | stopped reed bend | 62/246 | 2.7 s |
| 126 | I head back west along the lane toward the stilt village's Guild hall to turn in both strider contracts. | Erzähler | open_run_level | Turn in completed cull and thin contracts | stilt village on the Reed Flats | 62/246 | 23.5 s |
| 127 | I walk to the stilt village's Guild hall and turn in both strider contracts. | Erzähler | open_run_level | Turn in the cull and thin contracts | stilt village Guild hall, stilt village on the Reed Flats | 62/246 | 26.0 s |
| 128 | I take both slips back and head east along the lane to the eel-weirs to kill one more bog strider. | Erzähler | open_run_level | Get the sixth strider kill to make both contracts READY | the eel-weirs of the Reed Flats south of Glassmere | 62/246 | 19.5 s |
| 129 | I close to a casting distance and cast Arcane Bolt at Bog Strider J. | Erzähler | open_run_level | Kill the sixth strider to finish both contracts | the eel-weirs of the Reed Flats south of Glassmere | 62/236 | 15.6 s |
| 130 | I head back west to the stilt village's Guild hall and turn in both strider contracts for payment. | Erzähler | open_run_level | Turn in both completed contracts | stilt village Guild hall, stilt village on the Reed Flats | 62/236 | 29.6 s |
| 131 | #assign VIT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up points for survivability | stilt village Guild hall, stilt village on the Reed Flats | 62/236 | 2.9 s |
| 132 | I ask the clerk what contracts are on the board for a Novice mage. | Erzähler | open_run_level | Pick the next Guild contract | stilt village Guild hall, stilt village on the Reed Flats | 62/236 | 31.1 s |
| 133 | I take the mud viper contract and ask the clerk to make it ACTIVE. | Erzähler | open_run_level | Accept an achievable contract | stilt village Guild hall, stilt village on the Reed Flats | 62/236 | 17.0 s |
| 134 | I ask the clerk whether the village has a bed I can rent for the night — I'm still hurt and want to recover before the day's walk downriver. | Erzähler | open_run_level | Recover HP before hunting the mud viper | stilt village Guild hall, stilt village on the Reed Flats | 62/236 | 29.6 s |
| 135 | I take the healer's loft for the night, pay the 5 copper, and sleep until morning. | Engine (Menü/Rückfrage) | open_run_level | Recover HP overnight before viper hunt | stilt village Guild hall, stilt village on the Reed Flats | 62/236 | 15.8 s |
| 136 | I buy the healer's loft lodging from the healer for 5 copper and sleep until morning. | Erzähler | open_run_level | Purchase lodging and recover HP overnight | stilt village Guild hall, stilt village on the Reed Flats | 165/328 | 27.1 s |
| 137 | I set out from the village along the river toward the mill wheel shallows to hunt the mud viper. | Erzähler | open_run_level | Travel to the viper hunt site | the shallows below the mill wheel, Miller's Crossing | 165/328 | 38.1 s |
| 138 | I thank the miller for the warning and head downstream into the shallows, watching the gravel bars and sedge clumps for the viper's den. | Erzähler | open_run_level | Hunt the mud viper in the shallows | gravel bars and sedge clumps downstream | 165/328 | 35.7 s |
| 139 | I cast Arcane Bolt at the viper. | Erzähler | open_run_level | Attack the mud viper with single-target spell | gravel bars and sedge clumps downstream | 165/318 | 30.6 s |
| 140 | Viper defeated — I head back to Miller's Crossing for the night, then return to the Guild hall at the stilt village tomorrow to turn in the … | Erzähler | open_run_level | Turn in the completed viper cull and recover | the drying loft | 165/318 | 70.8 s |
| 141 | I leave the drying loft and take the towpath east to the stilt village Guild hall to turn in the completed mud viper contract. | Erzähler | open_run_level | Turn in the viper cull at the Guild hall | stilt village Guild hall, stilt village on the Reed Flats | 165/318 | 37.1 s |
| 142 | "That completes the viper cull — I'll take the forty copper. What other Novice contracts are on the board?" | Erzähler | open_run_level | Confirm turn-in payment and ask for new contracts | stilt village Guild hall, stilt village on the Reed Flats | 165/318 | 31.9 s |
| 143 | "I'll come along to the eel-weirs. And while I'm here — do you buy F-Rank bog strider chitin plates? I've seven of them. | Erzähler | open_run_level | Join the eel-weir trip and try selling surplus chitin | stilt village Guild hall, stilt village on the Reed Flats | 165/318 | 36.6 s |
| 144 | I accept the offer and sell all seven intact F-Rank chitin plates for fourteen copper. | Erzähler | open_run_level | Sell surplus chitin plates | stilt village Guild hall, stilt village on the Reed Flats | 165/318 | 30.8 s |
| 145 | I follow the pair out along the plank walk to Sallow's eel-weirs, third platform past the leaning post. | Erzähler | open_run_level | Join the eel-weir trip and find pest-control work with Sallow | Sallow's weir | 165/318 | 31.7 s |
| 146 | "I'm in — two copper a head, dead ones only. I'll watch the water off the end line while Berta and Aldous cover the rail." | Erzähler | open_run_level | Accept Sallow's strider-cull work and coordinate with the two adventurers | Sallow's weir | 165/318 | 24.9 s |
| 147 | I cast Arcane Bolt at the strider climbing the end platform, aiming for its head where it hooks over the lip. | Erzähler | open_run_level | Open the cull by striking the closest strider | Sallow's weir | 162/308 | 25.0 s |
| 148 | I cast Arcane Bolt at Bog Strider L on the platform before it can close the distance again. | Erzähler | open_run_level | Finish the second strider | Sallow's weir | 162/298 | 21.2 s |
| 149 | I rinse the bite at the pump-bucket, then ask Sallow for the four copper owed for my two striders. | Erzähler | open_run_level | Collect cull pay and tend the wound | Sallow's weir | 162/298 | 19.4 s |
| 150 | I pocket the four copper, thank Sallow, and tell Berta and Aldous I'm heading back to the village — the miller's viper contract is already f… | Erzähler | open_run_level | Wrap up the cull and return toward the Guild turn-in | stilt village on the Reed Flats | 162/298 | 21.2 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 6 (notiert vor Zug 7): Narration briefly glitched with repeated garbled board text, but the ENGINE RESULT board listing was clean and authoritative.
- zu Zug 11 (notiert vor Zug 12): System refused Arcane Bolt because the viper is not yet a targetable actor in the scene — it must surface first.
- zu Zug 14 (notiert vor Zug 15): Turn-in paid out 35 copper on top of earlier 3s5c; Guild sells skill primers (80 cp) including Primer of Bolt.
- zu Zug 26 (notiert vor Zug 27): Contract only covers Level 1; Level 2 slimes are untargetable and risky at L3 with low MP.
- zu Zug 31 (notiert vor Zug 32): All 6 Level 1 threats defeated but quest still shows not cleared; possible turn-in or exit requirement.
- zu Zug 32 (notiert vor Zug 33): Quest still shows 'not cleared yet' despite all 6 threats defeated; dungeon panel says 'inside: 1/6', suggesting an exit or deeper-level condition.
- zu Zug 33 (notiert vor Zug 34): Quest still says 'not cleared yet' even after all 6 threats defeated and exiting; possibly the clerk must verify or the count is different.
- zu Zug 34 (notiert vor Zug 35): Turn-in refused because only the outer grotto was cleared, not the whole first floor; MP is low (34/156) so recovery is needed before going back.
- zu Zug 37 (notiert vor Zug 38): Dungeon panel says '2 of ? threats dealt with' and 'inside: 1/6', suggesting more threats exist than the six already counted.
- zu Zug 39 (notiert vor Zug 40): System refused Arcane Bolt: the slime is scenery, not an active-scene target — combat must be initiated first. Dungeon panel still shows Level 1 with 2 of ? threats dealt with, while I've descended to Level 2.
- zu Zug 41 (notiert vor Zug 42): Dungeon panel counts all 4 beetles and 2 slimes as defeated, yet quest 'not cleared yet' and threats '2 of ?' — the level-clear condition may need reaching an exit or something else.
- zu Zug 42 (notiert vor Zug 43): Dungeon panel still says 'inside: 1/6' though I'm clearly deep in; quest says level 1 not cleared despite all 6 counted threats dead — clear condition may need something beyond kills.
- zu Zug 43 (notiert vor Zug 44): Level 1 quest still 'not cleared yet' though all six counted threats are dead and I'm now on Level 3; clear condition may require finding something specific deeper in.
- zu Zug 45 (notiert vor Zug 46): Search confirmed a walkable lane past the crystal field; wax-sealed vessel and academy-marked slate found in a niche — left untouched.
- zu Zug 48 (notiert vor Zug 49): The slime in the deep chamber is scenery, not a targetable actor — engine refused the attack; dungeon panel already counts all 6 threats defeated though the quest still reads 'not cleared yet'.
- zu Zug 49 (notiert vor Zug 50): Quest panel oddly says 'cleared by him' while turn-in says 'not cleared yet'; clerk hints 'all of it, the outer grottos' — likely unexplored side passages remain.
- zu Zug 52 (notiert vor Zug 53): Dungeon panel now says level 1 CLEARED this cycle with both slimes defeated, contradicting the earlier 'not cleared' turn-in — likely the slime counted after all.
- zu Zug 54 (notiert vor Zug 55): Narration again contradicted the engine: it described the Glimmerdeep slip as not yet closed while the engine result had already confirmed QUEST COMPLETED and payout.
- zu Zug 72 (notiert vor Zug 73): Quest shows 3/4 defeated but combat ended with all three striders dead — count may need confirming at turn-in.
- zu Zug 74 (notiert vor Zug 75): Quest panel still shows 3/4 defeated although the engine confirmed all three striders defeated; will confirm the count at turn-in.
- zu Zug 78 (notiert vor Zug 79): Narration showed a full night's sleep but engine refused 'sleep until morning' twice as 'arrival pending'; HP/MP did not recover (72/120, 116/244).
- zu Zug 85 (notiert vor Zug 86): Turn-in paid 1G5S and gave 300 XP; level 6 confirmed, stats assigned. HP still low (57/125) and wounded — recovery or physicker visit needed before another fight.
- zu Zug 86 (notiert vor Zug 87): Wounded (57/125 HP); narrator mentions a physicker two doors past the chandler's — worth visiting before or after this low-level job.
- zu Zug 89 (notiert vor Zug 90): Physicker purchase confirmed (-5 cp); HP still shows 57/125 wounded — no healing effect listed, will check after travel.
- zu Zug 90 (notiert vor Zug 91): Physicker healing did not raise HP (still 57/125) — purchase may only prevent worsening; vipers count toward 0/1 quest.
- zu Zug 91 (notiert vor Zug 92): AoE needs a named target in the active scene; also the villager is present and within potential blast range — risk of friendly fire.
- zu Zug 93 (notiert vor Zug 94): Viper contract turned in automatically on arrival (+4 Silver, +46 XP); loot was common goods already carried, not needed as proof.
- zu Zug 94 (notiert vor Zug 95): HP still 57/125 (wounded) after yesterday's physicker visit — healing may not have applied; will consider recovery before the fight.
- zu Zug 95 (notiert vor Zug 96): Physicker purchase yesterday gave no healing effect; HP still 57/125 — need a real recovery method.
- zu Zug 98 (notiert vor Zug 99): Treatment purchased (-24 cp) but HP still 57/125 — healing effect not yet visible; will confirm before combat.
- zu Zug 102 (notiert vor Zug 103): Last turn the payment never happened despite narration showing it — the engine requires an explicit payment statement; coins confirmed 3g4c, enough.
- zu Zug 103 (notiert vor Zug 104): Purchase finally booked (-10 cp, coin 294). Narration still mislabels stew contents; HP still 57/125 pending rest.
- zu Zug 105 (notiert vor Zug 106): Rest finally booked and HP/MP fully restored after explicit duration wording was required.
- zu Zug 107 (notiert vor Zug 108): HUD shows the bog strider contract already active at 0/6, so registration may be redundant; will verify the count before travelling.
- zu Zug 108 (notiert vor Zug 109): Both strider contracts are duplicates of the same 0/6 count; odd but harmless.
- zu Zug 111 (notiert vor Zug 112): System refused targeting a hidden, not-yet-spawned creature; combat needs a targetable actor first.
- zu Zug 113 (notiert vor Zug 114): AoE requires naming targets explicitly; generic phrasing was refused.
- zu Zug 119 (notiert vor Zug 120): System refuses conditional/future-target phrasing; attacks only resolve on actors present in the active scene.
- zu Zug 120 (notiert vor Zug 121): System repeatedly refuses attacks on unseen actors; striders stay hidden despite narrated movement.
- zu Zug 122 (notiert vor Zug 123): System demands a single named target even for AoE; striders deal 9–20 damage per hit, HP 82/125.
- zu Zug 126 (notiert vor Zug 127): Quest counters still show 5/6 despite six narrated kills; turning in to confirm.
- zu Zug 127 (notiert vor Zug 128): Engine confirmed both contracts at 5/6 despite six narrated kills; one more strider at the weirs will finish both.
- zu Zug 129 (notiert vor Zug 130): Both contracts now confirm 6/6; seals should show READY.
- zu Zug 132 (notiert vor Zug 133): HP 62/165 is badly wounded; should recover before the ghoul or viper hunt.
- zu Zug 139 (notiert vor Zug 140): Combat was won in one first-strike Arcane Bolt (65 dmg vs 20 HP); quest counter now 1/1.
- zu Zug 141 (notiert vor Zug 142): Narrator said 'forty copper' but the clerk counted four copper onto the counter; HUD coin still 7G9C and quest still shows active — payment not engine-confirmed.
- zu Zug 142 (notiert vor Zug 143): HUD still lists the viper quest as active despite the clerk's confirmed closure — engine result may lag; will recheck.
- zu Zug 143 (notiert vor Zug 144): Narrator re-closed the viper contract again despite it already being filed; HUD quest panel still shows it active — likely a display lag, will recheck.
- zu Zug 144 (notiert vor Zug 145): HUD coin 7G2S3C matches the confirmed 723 copper; viper quest still shows active despite confirmed closure — display lag persists.
- zu Zug 149 (notiert vor Zug 150): Viper contract shows 1/1 defeated but still active; turn-in pending. Bite wound is shallow and rinsed.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t12 | 13 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t18 | 20 | 4 | – | nein | 4 | gewonnen, 312 XP |
| enc.t25 | 30 | 2 | – | nein | 2 | gewonnen, 144 XP |
| enc.t55 | 64 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t60 | 70 | 3 | – | nein | 3 | gewonnen, 432 XP |
| enc.t70 | 81 | 1 | – | nein | 1 | gewonnen, 168 XP |
| enc.t79 | 92 | 3 | – | nein | 3 | gewonnen, 90 XP |
| enc.t98 | 114 | 3 | – | nein | 3 | gewonnen, 408 XP |
| enc.t101r | 121 | 2 | – | nein | 2 | gewonnen, 302 XP |
| enc.t107 | 129 | 1 | – | nein | 1 | gewonnen, 120 XP |
| enc.t115 | 139 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t123 | 147 | 2 | – | nein | 2 | gewonnen, 48 XP |

## Quests

- **Cull the Ford Serpent at Miller's Crossing** — active (Zug 7) → completed (Zug 14), READY
  - Aufgabe: Kill 1 mud viper at Miller's Crossing, the shallows below the mill wheel. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 mud viper killed at Miller's Crossing, the shallows below the mill wheel.
- **Cull the Reed Flats Bog Striders** — expired (Zug 54)
  - Aufgabe: Kill 6 bog striders at the eel-weirs of the Reed Flats south of Glassmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 6 bog striders killed at the eel-weirs of the Reed Flats south of Glassmere.
- **Cull the Barrowfield Ghouls** — expired (Zug 54)
  - Aufgabe: Kill 5 barrowfield ghouls at the old Barrowfield east of the north road. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 5 barrowfield ghouls killed at the old Barrowfield east of the north road.
- **Cull the Ashveil Ridge Wyvern** — expired (Zug 54)
  - Aufgabe: Kill 1 the Ashveil Ridge wyvern at Ashveil Ridge, the high pastures above Glassmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the Ashveil Ridge wyvern killed at Ashveil Ridge, the high pastures above Glassmere.
- **Clear Glimmerdeep Grotto, Level 1** — active (Zug 16) → completed (Zug 53), Dungeon loc.glimmerdeep_grotto Ebene 1
  - Aufgabe: Clear level 1 of Glimmerdeep Grotto. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Glimmerdeep Grotto is clear.
- **Cull the Mud Viper at Miller's Crossing** — active (Zug 55) → completed (Zug 65), READY
  - Aufgabe: Kill 1 the mud viper in the shallows below the mill wheel at Miller's Crossing, the shallows below the mill wheel. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the mud viper in the shallows below the mill wheel killed at Miller's Crossing, the shallows below the mill wheel.
- **Cull Bog Striders at the Reed Flats Eel-Weirs** — expired (Zug 67)
  - Aufgabe: Kill 5 bog striders among the eel-weirs at the eel-weirs of the Reed Flats south of Glassmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 5 bog striders among the eel-weirs killed at the eel-weirs of the Reed Flats south of Glassmere.
- **Cull Barrowfield Ghouls East of the North Road** — expired (Zug 67)
  - Aufgabe: Kill 6 barrowfield ghouls among the old barrows at the old Barrowfield east of the north road. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 6 barrowfield ghouls among the old barrows killed at the old Barrowfield east of the north road.
- **Hunt the Ashveil Ridge Wyvern** — expired (Zug 67)
  - Aufgabe: Kill 1 the wyvern nesting on the ridge crags at Ashveil Ridge, the high pastures above Glassmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the wyvern nesting on the ridge crags killed at Ashveil Ridge, the high pastures above Glassmere.
- **Clear Glimmerdeep Grotto Level 1** — expired (Zug 67), Dungeon loc.glimmerdeep_grotto Ebene 1
  - Aufgabe: Clear level 1 of Glimmerdeep Grotto. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Glimmerdeep Grotto is clear.
- **Cull the Mud Viper at Miller's Crossing** — expired (Zug 86)
  - Aufgabe: Kill 1 mud viper at the shallows below the mill wheel, Miller's Crossing. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 mud viper killed at the shallows below the mill wheel, Miller's Crossing.
- **Cull the Bog Striders at the Reed Flats Eel-Weirs** — active (Zug 68) → completed (Zug 84), READY
  - Aufgabe: Kill 4 bog striders at the eel-weirs of the Reed Flats south of Glassmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 bog striders killed at the eel-weirs of the Reed Flats south of Glassmere.
- **Thin the Barrowfield Ghouls** — expired (Zug 86)
  - Aufgabe: Kill 4 barrowfield ghouls at the old Barrowfield east of the north road. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 barrowfield ghouls killed at the old Barrowfield east of the north road.
- **Cull the Ashveil Ridge Wyvern** — expired (Zug 86)
  - Aufgabe: Kill 1 Ashveil Ridge wyvern at the high pastures of Ashveil Ridge above Glassmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 Ashveil Ridge wyvern killed at the high pastures of Ashveil Ridge above Glassmere.
- **Clear Glimmerdeep Grotto, Level 1** — expired (Zug 86), Dungeon loc.glimmerdeep_grotto Ebene 1
  - Aufgabe: Clear level 1 of Glimmerdeep Grotto. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Glimmerdeep Grotto is clear.
- **Cull the Mud Viper at the Mill Shallows** — active (Zug 87) → completed (Zug 93)
  - Aufgabe: Kill 1 mud viper at the shallows below the mill wheel, Miller's Crossing. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 mud viper killed at the shallows below the mill wheel, Miller's Crossing.
- **Cull Bog Striders at the Reed Flats Eel-Weirs** — active (Zug 95) → completed (Zug 130)
  - Aufgabe: Kill 6 bog striders at the eel-weirs of the Reed Flats south of Glassmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 6 bog striders killed at the eel-weirs of the Reed Flats south of Glassmere.
- **Cull Barrowfield Ghouls on the North Road** — expired (Zug 107)
  - Aufgabe: Kill 5 barrowfield ghouls at the old Barrowfield east of the north road. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 5 barrowfield ghouls killed at the old Barrowfield east of the north road.
- **Slay the Ashveil Ridge Wyvern** — expired (Zug 107)
  - Aufgabe: Kill 1 Ashveil Ridge wyvern at the high pastures of Ashveil Ridge above Glassmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 Ashveil Ridge wyvern killed at the high pastures of Ashveil Ridge above Glassmere.
- **Clear Glimmerdeep Grotto Level 1** — expired (Zug 107), Dungeon loc.glimmerdeep_grotto Ebene 1
  - Aufgabe: Clear level 1 of Glimmerdeep Grotto. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Glimmerdeep Grotto is clear.
- **Thin the Bog Striders at the Reed Flats Eel-Weirs** — active (Zug 108) → completed (Zug 130)
  - Aufgabe: Kill 6 bog striders at the eel-weirs of the Reed Flats south of Glassmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 6 bog striders killed at the eel-weirs of the Reed Flats south of Glassmere.
- **Clear Glimmerdeep Grotto, Level 1** — taken_by_other (Zug 137), Dungeon loc.glimmerdeep_grotto Ebene 1
  - Aufgabe: Clear level 1 of Glimmerdeep Grotto. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Glimmerdeep Grotto is clear.
- **Cull the Mud Viper at the Mill Wheel Shallows** — active (Zug 133)
  - Aufgabe: Kill 1 mud viper at the shallows below the mill wheel, Miller's Crossing. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 mud viper killed at the shallows below the mill wheel, Miller's Crossing.

## Auffälligkeiten

- Zug 3, Nachricht 6 (extraction_repaired): the extractor's first answer needed a repair
- Zug 8, Nachricht 16 (extraction_repaired): the extractor's first answer needed a repair
- Zug 14, Nachricht 28 (extraction_repaired): the extractor's first answer needed a repair
- Zug 24, Nachricht 48 (extraction_repaired): the extractor's first answer needed a repair
- Zug 24, Nachricht 48 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (mineral slime): refused, no fight (Patch 8.4.1 guard)
- Zug 26, Nachricht 52 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (mineral slime): refused, no fight (Patch 8.4.1 guard)
- Zug 28, Nachricht 56 (extraction_repaired): the extractor's first answer needed a repair
- Zug 30, Nachricht 59 (group_turns): fight enc.t25:  of the group never acted on a turn of its own
- Zug 33, Nachricht 65 (planner_repaired): the planner's first answer needed a repair
- Zug 33, Nachricht 65 (planner_recovery): the planner required transport recovery
- Zug 37, Nachricht 74 (extraction_repaired): the extractor's first answer needed a repair
- Zug 38, Nachricht 76 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (rust-streaked mineral slime): refused, no fight (Patch 8.4.1 guard)
- Zug 40, Nachricht 80 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (rust-streaked mineral slime): refused, no fight (Patch 8.4.1 guard)
- Zug 42, Nachricht 84 (extraction_repaired): the extractor's first answer needed a repair
- Zug 43, Nachricht 86 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (glass beetle): refused, no fight (Patch 8.4.1 guard)
- Zug 44, Nachricht 88 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (glass beetle): refused, no fight (Patch 8.4.1 guard)
- Zug 47, Nachricht 94 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (mineral slime): refused, no fight (Patch 8.4.1 guard)
- Zug 49, Nachricht 97 (planner_repaired): the planner's first answer needed a repair
- Zug 49, Nachricht 98 (extraction_repaired): the extractor's first answer needed a repair
- Zug 52, Nachricht 104 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (big mineral slime): refused, no fight (Patch 8.4.1 guard)
- Zug 65, Nachricht 130 (extraction_repaired): the extractor's first answer needed a repair
- Zug 76, Nachricht 152 (extraction_repaired): the extractor's first answer needed a repair
- Zug 79, Nachricht 158 (extraction_repaired): the extractor's first answer needed a repair
- Zug 83, Nachricht 166 (extraction_repaired): the extractor's first answer needed a repair
- Zug 97, Nachricht 193 (planner_repaired): the planner's first answer needed a repair
- Zug 100, Nachricht 199 (planner_repaired): the planner's first answer needed a repair
- Zug 107, Nachricht 213 (planner_repaired): the planner's first answer needed a repair
- Zug 135, Nachricht 269 (planner_repaired): the planner's first answer needed a repair
- Zug 138, Nachricht 276 (extraction_repaired): the extractor's first answer needed a repair
- Zug 140, Nachricht 280 (extraction_repaired): the extractor's first answer needed a repair
- Zug 141, Nachricht 281 (planner_repaired): the planner's first answer needed a repair
- Zug 141, Nachricht 282 (extraction_repaired): the extractor's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 21× keine gültige JSON-Entscheidung (Züge 9, 10, 23, 25, 26, 29, 30, 35, 45, 46, 47, 48, 49, 56, 91, 97, 100, 102, 111, 126, 133)
- Server: Generation failed AbortError: The operation was aborted.

System-Panels: CLARIFY 2, NOT TAKEN 0, REFUSED 3, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: scene_context 8, ambient 8, pc_inventory 6, guild_payout 2, engine_owned_fact 20, engine_owned_combat 2, group_unclear 3, world_rule 15, dungeon_foe 8, engine_owned 1, engine_recovery 1, engine_owned_memory 1, attack_commitment 1, no_go 4, offer 1, quest_count 2, recover 1, guild_completion 1, guild_branch 1, guild_canon 1, coin_evidence 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 1, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 21/150 Erstantworten ungültig (14.0 %); 21 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 148 | 6 | 3.2 s | 15.4 s | 12303 | 10013 | 81 | – | stop 147 | 0 |
| narrator | 124 | 0 | 14.2 s | 35.6 s | 11607 | 8776 | 401 | – | stop 124 | 0 |
| extract | 139 | 15 | 8.1 s | 25.1 s | 13036 | 9795 | 421 | – | stop 139 | 0 |
| board | 7 | 1 | 18.4 s | 24.1 s | 2545 | 2233 | 1154 | – | stop 7 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 119:00 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 14.3 s) | 0:28 min |
| 150 Züge, Spiel (Senden bis HUD nach der Extraktion) | 96:36 min — Median 30.6 s, p90 70.8 s, max 297.0 s |
| 150 Züge, Spieler-Entscheidung | 19:05 min — Median 3.5 s, 21 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 16:12 min / 2:00 min / 45:23 min / 26:49 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 46.3 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 30:51 min, 80 Züge ≈ 61:42 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spieler | 51 | – | 158.6 s | 3.5 s |
| Spieler | 103 | – | 106.1 s | 3.5 s |
| Spieler | 102 | – | 34.8 s | 3.5 s |
| Spiel | 4 | – | 297.0 s | 30.6 s |
| Spiel | 33 | – | 183.3 s | 30.6 s |
| Spiel | 56 | – | 163.0 s | 30.6 s |
| Provider narrator | 4 | 6 | 286.6 s | 14.2 s |
| Provider narrator | 56 | 154 | 151.5 s | 14.2 s |
| Provider narrator | 112 | 317 | 116.7 s | 14.2 s |
| Provider extract | 37 | 99 | 55.6 s | 8.1 s |
| Provider extract | 24 | 62 | 43.4 s | 8.1 s |
| Provider extract | 38 | 103 | 39.9 s | 8.1 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
