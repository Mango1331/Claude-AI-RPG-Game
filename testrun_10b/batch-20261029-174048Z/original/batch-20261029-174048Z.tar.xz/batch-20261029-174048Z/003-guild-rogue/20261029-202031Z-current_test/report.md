# Avereth Live-Test 20261029-202031Z-current_test

## Kurzfassung

- **Laufprofil:** guild-rogue; Startklasse Rogue, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** Niederlage — turn 33: he died
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 2. Sicherheitsgrenzen: 150 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** noch nicht erreicht.
- **Charakter:** rogue (rogue.evasive_step, rogue.fan_of_blades) · Regelstand 2 (Warrior, Mage, Rogue)
- **Ziel-Dungeon:** Glimmerdeep Grotto, Ebene 1 (Vertrag quest.clear_the_outer_grottos_of_glimmerdeep_grotto_level_1)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: pragmatic adventurer: sell surplus loot and invest in useful equipment and techniques
- **Züge:** 33 · **Dauer:** 12:56 min · **LLM-Aufrufe der Engine/des Erzählers:** 95
- **Beobachtete Abdeckung:** 9 unterschiedliche gebuchte Reiseziele · 3 Kämpfe · 0 Verkäufe (0 cp Umsatz, ohne Questzahlungen/Geschenke) · 0 Ausrüstungswechsel · 0 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 7 · **Niederlage** in Zug 33: he died
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.119 |
| Git | b09274c8c4d9 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 60.1 s |
| Browser | chrome 156.0.8078.49 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261029-202031Z-current_test“, Seed 1717914049 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | Rogue. | Engine (Menü/Rückfrage) | creation_complete | Choose Rogue base class | public roadside verge outside Glassmere | 90/84 | 2.2 s |
| 2 | I choose Fan of Blades and Evasive Step. | Engine (Menü/Rückfrage) | creation_complete | Pick required AoE skill plus defensive utility | public roadside verge outside Glassmere | 90/84 | 2.1 s |
| 3 | I walk to Glassmere and head to the Guild hall to look at the contract board. | Erzähler | open_run_level | Enter city and find starter contracts | Adventurers' Guild hall, Glassmere | 90/84 | 39.2 s |
| 4 | I approach the clerk and ask what Novice contracts are available, and whether I need to register with the Guild first. | Erzähler | open_run_level | Ask clerk about contracts and registration | Adventurers' Guild hall, Glassmere | 90/84 | 38.3 s |
| 5 | I hand the clerk two silver and give my name as Alaric to register with the Guild. | Erzähler | open_run_level | Register with the Guild | Adventurers' Guild hall, Glassmere | 90/84 | 17.7 s |
| 6 | I tell the clerk I'll take the Marsh Adder contract at the Eel-Weirs and ask her to mark it active under my name. | Erzähler | open_run_level | Accept the Novice adder contract and verify it is ACTIVE | Adventurers' Guild hall, Glassmere | 90/84 | 18.4 s |
| 7 | I leave by the south gate and follow the mill road toward the Eel-Weirs on the Reed Flats, asking the weir-wardens there which pool the adde… | Erzähler | open_run_level | Travel to the contract site and locate the adder | the eel-weirs of the Reed Flats | 90/84 | 22.0 s |
| 8 | I head down to the third pool and wait hidden near the traps for the adder to come take the eels, dagger ready. | Erzähler | open_run_level | Stake out the adder's pool | the eel-weirs of the Reed Flats | 90/84 | 18.1 s |
| 9 | I move down to the third pool and settle into cover near its traps, dagger ready, waiting for the adder to come take the eels. | Erzähler | open_run_level | Stake out the third pool for the adder | the third pool | 90/84 | 20.0 s |
| 10 | I keep hidden in the reed cover and wait for dusk, watching the third pool's traps for the adder to return. | Erzähler | open_run_level | Stake out the third pool until the adder returns | the third pool | 90/84 | 17.2 s |
| 11 | I burst from cover and strike at the adder with my dagger before it reaches the trap. | Erzähler | open_run_level | Ambush the marsh adder | the third pool | 90/84 | 39.4 s |
| 12 | I close the three strides to the adder and drive my dagger into it as it works at the trap. | Erzähler | open_run_level | Engage the adder and attack | the third pool | 90/84 | 15.1 s |
| 13 | I head back along the mill road to the Guild hall in Caelreth to turn in the completed adder contract. | Erzähler | open_run_level | Turn in the adder contract at the Guild hall | Adventurers' Guild hall, Glassmere | 90/84 | 21.2 s |
| 14 | I ask the clerk what contracts are on the board for a Novice rank, and whether the adder skin and fangs are worth anything to the Guild. | Erzähler | open_run_level | Browse the Guild board and sell loot | Adventurers' Guild hall, Glassmere | 90/84 | 15.4 s |
| 15 | I accept the eighteen coppers for the skin and fangs, and ask the clerk to take the Glimmerdeep Grotto level 1 contract. |  | open_run_level | Sell loot and accept a Novice contract | Adventurers' Guild hall, Glassmere | 90/84 | 9.4 s |
| 16 | I accept the clerk's offer of eighteen coppers for the adder skin and two fangs. | Erzähler | open_run_level | Complete the loot sale so I can then accept the Grotto contract | Adventurers' Guild hall, Glassmere | 90/84 | 21.7 s |
| 17 | I ask the clerk to take the Glimmerdeep Grotto, level 1 clearance contract. | Erzähler | open_run_level | Accept the Novice grotto contract | Adventurers' Guild hall, Glassmere | 90/84 | 19.8 s |
| 18 | I take the slip and sign it, then ask the clerk where the road to Glimmerdeep starts and whether there's lodging in Glassmere for the night. | Erzähler | open_run_level | Accept the contract and plan travel and lodging | Adventurers' Guild hall, Glassmere | 90/84 | 20.3 s |
| 19 | I head to the Broken Barrel and take a room for the night, then sleep until morning. | Erzähler | open_run_level | Get lodging and rest before the morning walk to Glimmerdeep | the Broken Barrel | 90/84 | 22.3 s |
| 20 | I pay the copper for the bed and the copper for soup and bread. | Erzähler | open_run_level | Pay for lodging and a meal, then sleep | the Broken Barrel | 90/84 | 15.4 s |
| 21 | I head out of the north gate and follow the shepherd's road up the valley to the cleft, then show the academy post my slip and Guild plate. | Erzähler | open_run_level | Travel to Glimmerdeep and check in at the post | grotto mouth and first gallery | 90/84 | 31.0 s |
| 22 | I move carefully into the first gallery toward the clicking sound, dagger ready, and search for the source. | Erzähler | open_run_level | Hunt the crystal beetles for the grotto clearance contract | second chamber of the first gallery | 90/84 | 19.8 s |
| 23 | I close the ten paces quickly and strike the floor beetle with my dagger before it can react. | Erzähler | open_run_level | Open combat on the unaware floor beetle | second chamber of the first gallery | 71/84 | 14.6 s |
| 24 | I use Fan of Blades against both beetles at close range, then follow with my dagger on whichever survives. | Engine (Menü/Rückfrage) | open_run_level | AoE both engaged beetles, then finish | second chamber of the first gallery | 71/84 | 4.4 s |
| 25 | Fan of Blades on Glass Beetle B and Glass Beetle A, then dagger on whichever survives. | Erzähler | open_run_level | AoE both beetles, then finish | second chamber of the first gallery | 62/84 | 14.3 s |
| 26 | I finish Glass Beetle A with a basic dagger attack. | Erzähler | open_run_level | Defeat the last beetle | second chamber of the first gallery | 62/84 | 12.2 s |
| 27 | #assign AGI 2 PER 2 VIT 1 | System (Befehl) | open_run_level | Spend level-up stat points | second chamber of the first gallery | 62/84 | 2.1 s |
| 28 | I loot the beetle remains for anything useful, then continue deeper along the gallery, dagger ready. | Erzähler | open_run_level | Continue clearing the grotto contract | third chamber of the first gallery | 62/84 | 19.0 s |
| 29 | I strike Mineral Slime A with my dagger, staying out of reach of the second. | Erzähler | open_run_level | Engage the slimes one at a time in the narrow gallery | third chamber of the first gallery | 62/84 | 15.9 s |
| 30 | I step forward to close with Mineral Slime A and strike it with my dagger. | Erzähler | open_run_level | Engage slime A within reach | third chamber of the first gallery | 51/84 | 20.7 s |
| 31 | I strike Mineral Slime A again with my dagger. | Erzähler | open_run_level | Finish slime A before both close in | third chamber of the first gallery | 31/84 | 16.5 s |
| 32 | I use Evasive Step to slip back a band, out of both slimes' reach. | Erzähler | open_run_level | Reposition to avoid being worn down while slime A is nearly dead | third chamber of the first gallery | 16/84 | 14.4 s |
| 33 | I strike Mineral Slime A with my dagger to finish it off. | Erzähler | open_run_level | Kill the nearly dead slime A before both grind me down | third chamber of the first gallery | 0/84 | 12.8 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 5 (notiert vor Zug 6): Registration cost 20 copper, leaving 3 Silver (not 1 Silver as I assumed).
- zu Zug 15 (notiert vor Zug 16): Previous combined sale+contract message was rejected as unclear; splitting into separate steps.
- zu Zug 16 (notiert vor Zug 17): HUD still shows adder skin and fangs carried and no coin change despite the clerk's confirmed sale; will verify with #bag if it matters later.
- zu Zug 18 (notiert vor Zug 19): Contract is confirmed active; signing attempt was redundant.
- zu Zug 20 (notiert vor Zug 21): HUD clock still says 21:20 night though narration describes morning; narration suggests sleep already happened.
- zu Zug 32 (notiert vor Zug 33): HP down to 16/100; slimes close every round so Evasive Step only softens damage. May need to retreat and recover after this fight.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t12 | 12 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t22 | 23 | 2 | – | nein | 2 | gewonnen, 168 XP |
| enc.t27 | 30 | 2 | – | nein | 0 | **tot** |

## Quests

- **Kill the Marsh Adder at the Eel-Weirs of the Reed Flats** — active (Zug 6) → completed (Zug 13)
  - Aufgabe: Kill 1 marsh adder at the eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 marsh adder killed at the eel-weirs of the Reed Flats.
- **Clear the Outer Grottos of Glimmerdeep Grotto, Level 1** — active (Zug 17), Dungeon loc.glimmerdeep_grotto Ebene 1
  - Aufgabe: Clear level 1 of Glimmerdeep Grotto. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Glimmerdeep Grotto is clear.

## Auffälligkeiten

- Zug 3, Nachricht 5 (board_failed): the board generator failed
- Zug 5, Nachricht 10 (extraction_repaired): the extractor's first answer needed a repair
- Zug 15, Nachricht 29 (planner_failed): the planner failed: sell seq 1: min_cp 12 is not what his words "I accept the eighteen coppers for the skin and fangs" say: 18 cp total for qty 1. min_cp is the TOTAL for the selected quantity; if he means several units,
- Zug 15, Nachricht 29 (planner_repaired): the planner's first answer needed a repair
- Zug 16, Nachricht 31 (planner_repaired): the planner's first answer needed a repair
- Zug 19, Nachricht 38 (extraction_repaired): the extractor's first answer needed a repair
- Zug 21, Nachricht 42 (extraction_repaired): the extractor's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 6× keine gültige JSON-Entscheidung (Züge 8, 9, 11, 12, 13, 27)

System-Panels: CLARIFY 0, NOT TAKEN 1, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: guild_canon 3, engine_owned_fact 3, world_rule 6, engine_owned_memory 1, offer 2, pc_inventory 2, guild_payout 1, time_cap 1, ambient 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 6/33 Erstantworten ungültig (18.2 %); 6 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 32 | 2 | 2.5 s | 4.4 s | 11800 | 9910 | 105 | – | stop 32 | 0 |
| board | 4 | 2 | 9.4 s | 10.9 s | 2949 | 2498 | 1098 | – | stop 4 | 0 |
| narrator | 28 | 0 | 7.6 s | 10.7 s | 11390 | 8696 | 371 | – | stop 28 | 0 |
| extract | 31 | 3 | 4.4 s | 7.3 s | 12137 | 9648 | 264 | – | stop 31 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 12:56 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 60.1 s) | 1:16 min |
| 33 Züge, Spiel (Senden bis HUD nach der Extraktion) | 9:53 min — Median 17.7 s, p90 31.0 s, max 39.4 s |
| 33 Züge, Spieler-Entscheidung | 1:20 min — Median 2.0 s, 6 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 1:49 min / 0:36 min / 3:45 min / 2:33 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 20.4 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 13:36 min, 80 Züge ≈ 27:12 min (ohne Einrichtung) |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
