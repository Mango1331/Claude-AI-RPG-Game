# Avereth – 3 natürliche Testkampagnen

Status: **completed**. Serie abgeschlossen bedeutet, dass die Läufe beendet sind; es bedeutet nicht 3 bestandene Level-15-Abnahmen.

| Nr. | Profil | Seed | Eingaben | Level | Ende | Originalbericht |
|---|---|---:|---:|---:|---|---|
| 1 | guild-warrior | 1717914047 | 73 | 3 | defeat | [report.md](001-guild-warrior/20261029-174048Z-current_test/report.md) |
| 2 | guild-mage | 1717914048 | 150 | 8 | limit | [report.md](002-guild-mage/20261029-182125Z-current_test/report.md) |
| 3 | guild-rogue | 1717914049 | 33 | 2 | defeat | [report.md](003-guild-rogue/20261029-202031Z-current_test/report.md) |

