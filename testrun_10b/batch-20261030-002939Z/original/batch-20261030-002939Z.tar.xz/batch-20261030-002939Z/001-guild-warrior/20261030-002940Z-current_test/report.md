# Avereth Live-Test 20261030-002940Z-current_test

## Kurzfassung

- **Laufprofil:** guild-warrior; Startklasse Warrior, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** Niederlage — turn 29: he died
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 1. Sicherheitsgrenzen: 150 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** noch nicht erreicht.
- **Charakter:** warrior (warrior.cleave, warrior.quick_slash) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: pragmatic adventurer: sell surplus loot and invest in useful equipment and techniques
- **Züge:** 29 · **Dauer:** 13:12 min · **LLM-Aufrufe der Engine/des Erzählers:** 85
- **Beobachtete Abdeckung:** 5 unterschiedliche gebuchte Reiseziele · 2 Kämpfe · 1 Verkäufe (50 cp Umsatz, ohne Questzahlungen/Geschenke) · 0 Ausrüstungswechsel · 0 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 4 · **Niederlage** in Zug 29: he died
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.120 |
| Git | ca7a78f400b1 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 11.3 s |
| Browser | chrome 156.0.8078.49 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261030-002940Z-current_test“, Seed 2009264424 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | Warrior | Engine (Menü/Rückfrage) | creation_complete | Choose Warrior class | public roadside verge outside Alderwatch | 90/84 | 2.3 s |
| 2 | I choose Cleave and Quick Slash as my two skills. | Engine (Menü/Rückfrage) | creation_complete | Pick warrior.cleave plus a cheap second attack | public roadside verge outside Alderwatch | 95/84 | 2.1 s |
| 3 | I walk to Alderwatch and head for the Guild hall to look at the contract board. | Erzähler | open_run_level | Enter city and find starter contracts | Adventurers' Guild hall, Alderwatch | 95/84 | 52.1 s |
| 4 | I approach the clerk and ask what contracts are available for an unregistered newcomer, and how I register with the Guild. | Erzähler | open_run_level | Register with Guild and find starter contracts | Adventurers' Guild hall, Alderwatch | 95/84 | 39.4 s |
| 5 | I ask the clerk to register me with the Guild as a novice, and then to take the Millpond Serpent contract. | Erzähler | open_run_level | Register and accept a level-appropriate contract | Adventurers' Guild hall, Alderwatch | 95/84 | 13.7 s |
| 6 | I give the clerk my name — Alaric Red — and pay two silver to register. | Erzähler | open_run_level | Complete Guild registration so I can take the serpent contract | Adventurers' Guild hall, Alderwatch | 95/84 | 19.6 s |
| 7 | I ask the clerk to take the Millpond Serpent contract. | Erzähler | open_run_level | Accept the serpent contract now that registration is complete | Adventurers' Guild hall, Alderwatch | 95/84 | 15.9 s |
| 8 | I leave the Guild and follow the mill road downriver toward Harrow Mill. | Erzähler | open_run_level | Travel to Harrow Mill for the serpent hunt | Harrow Mill pond, two miles downriver of Alderwatch | 95/84 | 22.7 s |
| 9 | I take the boat and row out past the drowned fence toward the far reeds where the serpent lairs, keeping my longsword ready. | Erzähler | open_run_level | Hunt the serpent from the boat | far reeds past the drowned fence | 95/84 | 20.9 s |
| 10 | I hold my position in the boat, longsword ready, and wait for the serpent to come within striking distance at the boat's edge. | Erzähler | open_run_level | Fight the serpent from the boat | far reeds past the drowned fence | 95/84 | 15.8 s |
| 11 | I strike at the serpent's head with my longsword as it coils to lunge. | Engine (Menü/Rückfrage) | open_run_level | Attack the serpent | far reeds past the drowned fence | 95/84 | 4.0 s |
| 12 | Basic Attack — I strike at the serpent's head with my longsword as it coils to lunge. | Erzähler | open_run_level | Attack the serpent with Basic Attack | far reeds past the drowned fence | 95/84 | 21.7 s |
| 13 | I follow the miller up to his house, thank him for the offer, and accept the coin he gives before heading back to the Guild to turn in the c… | Erzähler | open_run_level | Collect reward, then return to Guild for turn-in | Adventurers' Guild hall, Alderwatch | 95/84 | 25.1 s |
| 14 | I sign the ledger and ask the clerk what contracts are on the board for a Novice. | Erzähler | open_run_level | Turn in done and pick next contract | Adventurers' Guild hall, Alderwatch | 95/84 | 19.4 s |
| 15 | I take the Orchard Boars contract slip to the clerk and tell her I'm accepting it. | Erzähler | open_run_level | Accept the boar cull contract | Adventurers' Guild hall, Alderwatch | 95/84 | 11.7 s |
| 16 | Before leaving town, I ask the clerk if anyone here buys serpent skin and fangs, or where I could sell them. | Erzähler | open_run_level | Sell surplus loot before heading to the orchard | Adventurers' Guild hall, Alderwatch | 95/84 | 15.4 s |
| 17 | I head to Master Corvin's apothecary on Tanner's Row and offer him two Old Water Serpent fangs, asking his price. | Erzähler | open_run_level | Sell serpent fangs to the apothecary before hunting boars | Master Corvin's apothecary | 95/84 | 18.8 s |
| 18 | I lay the two serpent fangs on the counter and ask Corvin what he'll pay for the pair. | Erzähler | open_run_level | Get a sell offer for the fangs | Master Corvin's apothecary | 95/84 | 16.4 s |
| 19 | I accept: five silver for the two fangs and the skin, and hand both over. | Erzähler | open_run_level | Sell fangs and skin to Corvin | Master Corvin's apothecary | 95/84 | 14.5 s |
| 20 | I leave the apothecary and head for the orchard outside Alderwatch to hunt the boars for my contract. | Erzähler | open_run_level | Travel to the orchard and start the boar cull | terraced orchard slopes below the Valedorn fruit roads | 95/84 | 23.3 s |
| 21 | I approach the older picker and ask where the boars have been rooting and whether the farmer will mind me hunting them here. | Erzähler | open_run_level | Get boar location and permission before hunting | terraced orchard slopes below the Valedorn fruit roads | 95/84 | 25.2 s |
| 22 | I thank the pickers and head down the terrace lanes toward the stone wall, moving quietly with the wind in my face, watching for the boars. | Erzähler | open_run_level | Hunt the orchard boars for the active contract | terraced orchard slopes below the Valedorn fruit roads | 95/84 | 39.5 s |
| 23 | I close the thirty paces quietly and use Cleave on the two thick boars side by side in the middle, striking both in one swing. | Erzähler | open_run_level | Attack the two boars with Cleave | terraced orchard slopes below the Valedorn fruit roads | 95/84 | 70.8 s |
| 24 | I draw my sword and engage the bigger boar head-on, then use Cleave on it and its neighbor. | Erzähler | open_run_level | Engage the boars and use Cleave on the paired pair | terraced orchard slopes below the Valedorn fruit roads | 95/84 | 21.7 s |
| 25 | I hold my ground and time my swing, using Cleave on the two charging boars as they reach me. | Erzähler | open_run_level | Use Cleave on both charging boars as they arrive | terraced orchard slopes below the Valedorn fruit roads | 95/84 | 34.1 s |
| 26 | I strike the big charging boar with a Basic Attack as it reaches me. | Erzähler | open_run_level | Engage the lead boar with Basic Attack | terraced orchard slopes below the Valedorn fruit roads | 95/84 | 32.3 s |
| 27 | I strike the engaged big boar with a Basic Attack. | Erzähler | open_run_level | Attack the boar now engaged | terraced orchard slopes below the Valedorn fruit roads | 56/84 | 20.4 s |
| 28 | I use Cleave on both engaged boars, A and B, in one swing. | Erzähler | open_run_level | AoE both engaged boars | terraced orchard slopes below the Valedorn fruit roads | 22/84 | 27.3 s |
| 29 | I use Cleave again on both wounded boars, A and B. | Erzähler | open_run_level | Finish both engaged boars with AoE before whatever is crashing through the willows arrives | terraced orchard slopes below the Valedorn fruit roads | 0/84 | 16.8 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 4 (notiert vor Zug 5): Board refreshed with Novice contracts; serpent hunt (rec. level 1) is the only one matching my level.
- zu Zug 13 (notiert vor Zug 14): Serpent skin and 2 fangs still carried — sell surplus later at a merchant.
- zu Zug 26 (notiert vor Zug 27): HUD shows Boar A as ENGAGED while the engine earlier refused for range; trust the newest panel and attack it.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t11 | 12 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t26 | 27 | 2 | – | nein | 0 | **tot** |

## Quests

- **Cull the Millpond Serpent** — active (Zug 7) → completed (Zug 13)
  - Aufgabe: Kill 1 old water serpent at Harrow Mill pond, two miles downriver of Alderwatch. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 old water serpent killed at Harrow Mill pond, two miles downriver of Alderwatch.
- **Thin the Orchard Boars** — active (Zug 15)
  - Aufgabe: Kill 4 tusked orchard boars at terraced orchard slopes below the Valedorn fruit roads. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 tusked orchard boars killed at terraced orchard slopes below the Valedorn fruit roads.

## Auffälligkeiten

- Zug 3, Nachricht 5 (board_failed): the board generator failed
- Zug 7, Nachricht 13 (cull_count): Cull the Millpond Serpent: its objective counts 1, its texts say 1, 2 (for review)
- Zug 13, Nachricht 26 (extraction_repaired): the extractor's first answer needed a repair
- Zug 22, Nachricht 44 (extraction_repaired): the extractor's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 8× keine gültige JSON-Entscheidung (Züge 10, 15, 21, 22, 23, 24, 25, 26)

System-Panels: CLARIFY 1, NOT TAKEN 0, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: ambient 4, engine_owned_memory 1, engine_owned_combat 1, engine_owned_fact 3, scene_context 2, guild_completion 1, guild_payout 1, coin_already_received 1, attack_commitment 2.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 8/29 Erstantworten ungültig (27.6 %); 8 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 27 | 0 | 2.2 s | 3.6 s | 11982 | 9896 | 61 | – | stop 27 | 0 |
| board | 4 | 2 | 11.3 s | 11.4 s | 3117 | 2630 | 1161 | – | stop 4 | 0 |
| narrator | 26 | 0 | 9.1 s | 18.0 s | 11315 | 8726 | 405 | – | stop 26 | 0 |
| extract | 28 | 2 | 5.1 s | 9.2 s | 12363 | 9625 | 371 | – | stop 28 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 13:12 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 11.3 s) | 0:25 min |
| 29 Züge, Spiel (Senden bis HUD nach der Extraktion) | 11:03 min — Median 20.4 s, p90 39.5 s, max 70.8 s |
| 29 Züge, Spieler-Entscheidung | 1:19 min — Median 2.5 s, 8 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 1:07 min / 0:43 min / 4:53 min / 3:00 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 25.6 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 17:04 min, 80 Züge ≈ 34:07 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spiel | 23 | – | 70.8 s | 20.4 s |
| Provider narrator | 23 | 66 | 45.5 s | 9.1 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
