# Avereth Live-Test 20261030-004256Z-current_test

## Kurzfassung

- **Laufprofil:** guild-mage; Startklasse Mage, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** abgebrochen: Limit erreicht — 150 turns
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 9. Sicherheitsgrenzen: 150 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** Level 6, 228 XP seit Levelaufstieg, 513 cp, HP 105, MP 160; Ort loc.old_crown_catacombs.round_bier_chamber. Ausrüstung und Skills stehen in evaluation.json → progression.checkpoint.
- **Charakter:** mage (mage.arcane_bolt, mage.arcane_wave) · Regelstand 2 (Warrior, Mage, Rogue)
- **Ziel-Dungeon:** Old Crown Catacombs, Ebene 1 (Vertrag quest.clear_old_crown_catacombs_level_1_2)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: pragmatic adventurer: sell surplus loot and invest in useful equipment and techniques
- **Züge:** 150 · **Dauer:** 63:40 min · **LLM-Aufrufe der Engine/des Erzählers:** 427
- **Beobachtete Abdeckung:** 30 unterschiedliche gebuchte Reiseziele · 16 Kämpfe · 3 Verkäufe (60 cp Umsatz, ohne Questzahlungen/Geschenke) · 0 Ausrüstungswechsel · 0 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 26
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.120 |
| Git | ca7a78f400b1 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 22.0 s |
| Browser | chrome 156.0.8078.49 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261030-004256Z-current_test“, Seed 2009264425 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | I choose Mage. | Engine (Menü/Rückfrage) | creation_complete | Pick Mage class | public roadside verge outside Alderwatch | 90/84 | 2.3 s |
| 2 | I select Arcane Wave and Arcane Bolt. | Engine (Menü/Rückfrage) | creation_complete | Pick required starter skills | public roadside verge outside Alderwatch | 90/96 | 2.1 s |
| 3 | I walk to the city gates of Alderwatch and enter, then head for the Adventurers' Guild hall to look at the contract board. | Erzähler | open_run_level | Enter Alderwatch and find Guild contracts | Adventurers' Guild hall, Alderwatch | 90/96 | 39.6 s |
| 4 | I approach the clerk and ask to register with the Guild, then request to take the 'Fang in the Turnip Rows' contract. | Erzähler | open_run_level | Register and take a novice contract | Adventurers' Guild hall, Alderwatch | 90/96 | 14.2 s |
| 5 | I pay the two silver registration fee. | Erzähler | open_run_level | Register with the Guild | Adventurers' Guild hall, Alderwatch | 90/96 | 16.1 s |
| 6 | Yes, I take the contract. | Erzähler | open_run_level | Accept the marten contract | Adventurers' Guild hall, Alderwatch | 90/96 | 16.9 s |
| 7 | I leave the Guild hall through the east gate and follow the Millbrook lane past the tanneries to the allotments, then look for Marla Otterwe… | Erzähler | open_run_level | Travel to the contract site and gather information | the Millbrook allotment gardens, east of Alderwatch | 90/96 | 27.5 s |
| 8 | I examine the trampled strip and bitten fence rail, then ask Marla where the marten seems to enter and whether she's seen it during the day. | Erzähler | open_run_level | Gather information and track the marten | the Millbrook allotment gardens, east of Alderwatch | 90/96 | 19.1 s |
| 9 | I accept Marla's offer, take the stool in her shed, and wait there watching the south fence for the marten to come at dusk. | Erzähler | open_run_level | Ambush the marten at the plot at nightfall | the Millbrook allotment gardens, east of Alderwatch | 90/96 | 22.0 s |
| 10 | I keep watching the south fence from the shed into the night, staff ready, waiting for the marten to show. | Erzähler | open_run_level | Continue the ambush into the night | the Millbrook allotment gardens, east of Alderwatch | 90/96 | 15.6 s |
| 11 | I search the stream bank and Doss's coop for fresh marten sign to find where it actually enters. | Erzähler | open_run_level | Track the marten's true entry point | the Millbrook allotment gardens, east of Alderwatch | 90/96 | 15.9 s |
| 12 | I knock on Marla's door and tell her the marten never came to the south fence tonight, and ask if I can continue the hunt in daylight tomorr… | Erzähler | open_run_level | Report failure to Marla and arrange to resume at daylight | the Millbrook allotment gardens, east of Alderwatch | 90/96 | 16.1 s |
| 13 | I thank Marla and accept her offer to resume the hunt at first light, then find a place to shelter and rest until dawn. | Erzähler | open_run_level | Rest until daylight, then track the marten at the gap behind Doss's run | the Millbrook allotment gardens, east of Alderwatch | 90/96 | 18.0 s |
| 14 | I meet Marla by her plot and ask her to show me the gap behind Doss's run, then examine it for fresh marten tracks in the morning light. | Erzähler | open_run_level | Track the marten at the gap behind Doss's run in daylight | the Millbrook allotment gardens, east of Alderwatch | 90/96 | 20.4 s |
| 15 | I ask Marla whether I can wait inside her shed through the coming dusk with the shed door open toward the gap behind Doss's run, hoping to c… | Erzähler | open_run_level | Set a new ambush covering the gap instead of the failed south fence | the Millbrook allotment gardens, east of Alderwatch | 90/96 | 17.2 s |
| 16 | I settle into the shed for the day, taking Marla's bread and cheese, and keep a patient watch on the gap through dusk with staff ready. | Erzähler | open_run_level | Ambush the gap through dusk | the Millbrook allotment gardens, east of Alderwatch | 90/96 | 19.6 s |
| 17 | I tell Marla the gap watch failed again and ask if I can borrow a scrap of meat or fish to bait the gap tonight, then wait at Doss's coop en… | Erzähler | open_run_level | Change ambush tactic after two empty watches: bait the gap and cover the coop side | Doss's coop end of the fence line | 90/96 | 44.7 s |
| 18 | I place the fish head near the fence corner, then stand back in the shadow of the corner with staff ready and wait quietly for the marten. | Erzähler | open_run_level | Bait the coop-end fence corner and ambush through the night | Doss's coop end of the fence line | 90/96 | 20.4 s |
| 19 | I cast Arcane Bolt at the marten while it is still fixated on the fish head. | Erzähler | open_run_level | Attack the marten from ambush | Doss's coop end of the fence line | 90/86 | 14.6 s |
| 20 | I collect the marten and head back to the Alderwatch Guild hall to turn in the Fang in the Turnip Rows contract. | Erzähler | open_run_level | Turn in the completed contract at the Guild hall | Adventurers' Guild hall, Alderwatch | 90/86 | 41.2 s |
| 21 | I ask the clerk what Novice contracts are currently posted on the board that could be done in the morning. | Erzähler | open_run_level | Ask about available contracts | Adventurers' Guild hall, Alderwatch | 90/86 | 33.5 s |
| 22 | I tell the clerk I'll take the Millbrook Garden Marten contract, and ask him to mark it active for me. | Erzähler | open_run_level | Accept the Millbrook marten cull contract | Adventurers' Guild hall, Alderwatch | 90/86 | 15.4 s |
| 23 | I take the cot for the night, pay the two copper, and sleep until morning. | Erzähler |  | Buy lodging and recover before hunting the Millbrook marten | Adventurers' Guild hall, Alderwatch | 90/96 | 16.2 s |
| 24 | I set out east from Alderwatch for the Millbrook allotment gardens to hunt the garden marten. | Erzähler | open_run_level | Travel to Millbrook for the active marten contract | the Millbrook allotment gardens, east of Alderwatch | 90/96 | 19.6 s |
| 25 | I ask Marla whether there's any fish scraps or meat trimmings I can have for bait, then head down to the stone drain by the stream to set th… | Erzähler | open_run_level | Bait and watch the drain for the marten | the stone drain by the stream | 90/96 | 36.0 s |
| 26 | I scoop a ladle of fish guts onto the beaten bank near the drain mouth, then settle into cover in the long grass to wait for the marten to s… | Erzähler | open_run_level | Bait the drain and watch for the marten | the stone drain by the stream | 90/96 | 21.6 s |
| 27 | I rise from cover and cast Arcane Bolt at the marten before it can bolt back into the drain. | Erzähler | open_run_level | Attack the marten at the bait | the stone drain by the stream | 90/86 | 22.9 s |
| 28 | I call back to Marla that the marten's done, then collect the bucket and head back up to the garden to return it to her. | Erzähler | open_run_level | Report kill, return bucket, then turn in contract at Guild | the Millbrook allotment gardens, east of Alderwatch | 90/86 | 31.2 s |
| 29 | I head back to Alderwatch and go to the Guild hall to turn in the marten contract. | Erzähler | open_run_level | Turn in the completed marten contract for the reward and level-up XP | Adventurers' Guild hall, Alderwatch | 90/86 | 25.0 s |
| 30 | #assign INT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up stat points | Adventurers' Guild hall, Alderwatch | 90/86 | 2.1 s |
| 31 | I ask the clerk what other Novice contracts are on the board. | Erzähler | open_run_level | Pick the next Guild contract | Adventurers' Guild hall, Alderwatch | 90/86 | 15.7 s |
| 32 | I ask the clerk to accept the Ridge Serpents contract for me. | Erzähler | open_run_level | Take the achievable serpent cull contract | Adventurers' Guild hall, Alderwatch | 90/86 | 15.9 s |
| 33 | I take the slip and ask the clerk where I can sell two marten pelts and some claws and fangs nearby. |  | open_run_level | Sell surplus loot before heading north | Adventurers' Guild hall, Alderwatch | 90/86 | 22.0 s |
| 34 | I head to Foundry Lane and ask Master Odo to buy two marten claws and four fangs. | Erzähler | open_run_level | Sell surplus monster parts | Odo's shop | 90/86 | 29.1 s |
| 35 | I lay two marten claws and four fangs on the counter and ask his price. | Erzähler | open_run_level | Sell monster parts to Odo | Odo's shop | 90/86 | 16.7 s |
| 36 | I accept his offer and hand over the two claws and four fangs for ten copper. | Erzähler | open_run_level | Sell monster parts to Odo | Odo's shop | 90/86 | 11.8 s |
| 37 | I head to Halvard's shop and offer him two grey-marsh marten pelts, asking his price. | Erzähler | open_run_level | Sell pelts to Halvard | Halvard's shop | 90/86 | 27.0 s |
| 38 | I pull the bell-pull for service, then offer Halvard two grey-marsh marten pelts and ask his price. | Erzähler | open_run_level | Get an offer for the pelts from Halvard | Halvard's shop | 90/86 | 20.4 s |
| 39 | I accept the offer and hand over the two marten pelts for ten copper. | Erzähler | open_run_level | Sell pelts to Halvard | Halvard's shop | 90/86 | 14.9 s |
| 40 | I head out to the Quarry Haul Road to hunt ridge serpents for my active contract, staff ready. | Erzähler | open_run_level | Continue the serpent cull contract | the Greystone Quarry haul road, north of Alderwatch | 90/86 | 19.9 s |
| 41 | I approach the stacked slabs cautiously and probe the dark gaps with a bolt of Arcane Bolt to flush out any serpent hiding there. | Erzähler | open_run_level | Hunt ridge serpents for the cull contract | the Greystone Quarry haul road, north of Alderwatch | 90/76 | 31.4 s |
| 42 | I keep my distance and cast Arcane Wave at the serpent, timing it as it strikes or charges. | Erzähler | open_run_level | Fight the ridge serpent with AoE at range | the Greystone Quarry haul road, north of Alderwatch | 58/62 | 36.8 s |
| 43 | I cast Arcane Bolt at the serpent's head, keeping my distance. | Erzähler | open_run_level | Finish the serpent with Arcane Bolt | the Greystone Quarry haul road, north of Alderwatch | 58/52 | 25.3 s |
| 44 | #assign INT 3 WIL 2 | System (Befehl) | open_run_level | Allocate level-up stat points | the Greystone Quarry haul road, north of Alderwatch | 58/52 | 2.1 s |
| 45 | I follow the drag-trail up toward the terraces, staff ready, to find the second serpent. | Erzähler | open_run_level | Continue the serpent cull (1/3) | the terrace flat by the serpent den | 58/52 | 28.5 s |
| 46 | I back off to open ground and cast Arcane Wave at the den mouth as the serpent emerges. | Engine (Menü/Rückfrage) | open_run_level | Fight the second serpent at range | the terrace flat by the serpent den | 58/52 | 4.7 s |
| 47 | I hold my ground and cast Arcane Wave at the serpent as it emerges from the bramble-curtained den. | Engine (Menü/Rückfrage) | open_run_level | Fight the second serpent as it comes out | the terrace flat by the serpent den | 58/52 | 4.8 s |
| 48 | I back away from the den and wait with staff raised, watching the bramble curtain until the serpent actually comes out. | Erzähler | open_run_level | Get the serpent to emerge so it becomes a targetable actor | the terrace flat by the serpent den | 58/52 | 21.6 s |
| 49 | I cast Arcane Wave at Ridge Serpent B, staying out of its reach. | Erzähler | open_run_level | Attack the emerged serpent at range | the terrace flat by the serpent den | 58/38 | 16.2 s |
| 50 | I cast Arcane Bolt at Ridge Serpent B to finish it. | Erzähler | open_run_level | Kill the nearly-dead serpent with a guaranteed-damage bolt | the terrace flat by the serpent den | 58/28 | 14.6 s |
| 51 | I search the bramble-curtained den for any sign of the third serpent or its lair, staff ready. | Erzähler | open_run_level | Find the third serpent | hollow under the fallen lintel | 58/28 | 19.4 s |
| 52 | I follow the third serpent's trail down the slope toward the lower cut, staff ready. | Erzähler | open_run_level | Track the third serpent toward the haul road | seep in the lower cut | 58/28 | 25.0 s |
| 53 | I cast Arcane Bolt at Ridge Serpent C on the ledge. | Erzähler | open_run_level | Open the fight with the third serpent at range | seep in the lower cut | 58/28 | 13.9 s |
| 54 | I move closer along the roadbed toward the serpent's ledge, closing into MEDIUM range with my staff ready. | Erzähler | open_run_level | Close to spell range of Ridge Serpent C | seep in the lower cut | 58/28 | 14.4 s |
| 55 | I cast Arcane Bolt at Ridge Serpent C. | Erzähler | open_run_level | Attack the serpent from MEDIUM range | seep in the lower cut | 58/18 | 19.9 s |
| 56 | I walk back down the haul road toward Alderwatch to turn in the completed serpent contract at the Guild hall. | Erzähler | open_run_level | Return to Alderwatch and turn in the 3/3 contract | Adventurers' Guild hall, Alderwatch | 58/18 | 36.9 s |
| 57 | #assign INT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up points | Adventurers' Guild hall, Alderwatch | 58/18 | 2.1 s |
| 58 | I approach Halvard and ask his price for three F-Rank Ridge Serpent Skins and five F-Rank Ridge Serpent Fangs. | Erzähler | open_run_level | Sell surplus loot to Halvard | Halvard's shop | 58/18 | 30.0 s |
| 59 | I accept Halvard's offer of forty copper for the three skins and five fangs. | Erzähler | open_run_level | Sell surplus loot | Halvard's shop | 58/18 | 20.0 s |
| 60 | I head to the Guild hall in Alderwatch to rest overnight and look for a new contract in the morning. | Erzähler | open_run_level | Recover overnight and pick up new Guild work | Adventurers' Guild hall, Alderwatch | 58/18 | 21.3 s |
| 61 | I sleep at the Guild pallet until the morning bell. | Erzähler | open_run_level | Recover HP and MP overnight before taking a new contract | Adventurers' Guild hall, Alderwatch | 105/228 | 13.7 s |
| 62 | I take the Withermere Bog Lurker slip to the counter and ask the clerk to register it as my active contract. | Erzähler | open_run_level | Accept the bog lurker cull contract | Adventurers' Guild hall, Alderwatch | 105/228 | 18.5 s |
| 63 | I take the Thornfell Great Tusked Boar slip to the counter and ask the clerk to register it as my active contract. | Erzähler | open_run_level | Accept the boar cull contract | Adventurers' Guild hall, Alderwatch | 105/228 | 13.2 s |
| 64 | I go to the board and read the fresh slips, looking for an F-Rank hunt or gathering job I can take alone. | Erzähler | open_run_level | Pick an achievable contract from the current board | Adventurers' Guild hall, Alderwatch | 105/228 | 22.1 s |
| 65 | I take the Grey-Marsh Marten slip to the counter and ask the clerk to register it as my active contract. | Erzähler | open_run_level | Accept the achievable marten cull before it's taken | Adventurers' Guild hall, Alderwatch | 105/228 | 12.6 s |
| 66 | I head out the east gate to the Millbrook allotment gardens and look for the marten's tracks and the plot-holders who filed the complaint. | Erzähler | open_run_level | Travel to the marten hunt site | the Millbrook allotment gardens, east of Alderwatch | 105/228 | 19.6 s |
| 67 | I ask Marla where the marten is likely to be hiding and whether she's seen it today, then check the stone drain by the stream for fresh sign… | Erzähler | open_run_level | Locate the marten's den for the cull | the stone drain by the stream | 105/228 | 24.1 s |
| 68 | I cast Arcane Bolt at the marten on the baited bank before it can bolt. | Engine (Menü/Rückfrage) | open_run_level | Cull the marten for the active contract | the stone drain by the stream | 105/228 | 4.6 s |
| 69 | I look into the drain mouth and search for the marten, staying ready to cast if I spot it. | Erzähler | open_run_level | Locate the marten so it becomes a valid target | the stone drain by the stream | 105/228 | 44.3 s |
| 70 | I cast Arcane Bolt at the marten in the drain. | Erzähler | open_run_level | Cull the contract marten now that it is a valid target | the stone drain by the stream | 105/218 | 19.7 s |
| 71 | I head back to Marla at the allotment plots and tell her the marten is dead, then return to the Guild hall to turn in the contract. | Erzähler | open_run_level | Complete the marten cull contract | Adventurers' Guild hall, Alderwatch | 105/218 | 27.3 s |
| 72 | I ask the clerk what contracts are on the novice board today. | Erzähler | open_run_level | Pick a new Guild contract | Adventurers' Guild hall, Alderwatch | 105/218 | 11.8 s |
| 73 | I ask the clerk to take the Ridge Serpent cull contract at Greystone Quarry and confirm it's active before I head north. | Erzähler | open_run_level | Accept the ridge serpent cull contract | Adventurers' Guild hall, Alderwatch | 105/218 | 27.0 s |
| 74 | I travel north along the Greystone Quarry haul road and search the cuttings for the ridge serpents, staff ready. | Erzähler | open_run_level | Travel to the contract site and locate the serpents | the Greystone Quarry haul road, north of Alderwatch | 105/218 | 18.3 s |
| 75 | I walk into the deep second cutting past the quarry mouth and search the banks there for the ridge serpents, staff ready. | Erzähler | open_run_level | Hunt the serpents in the narrows where the last mule was lost | the deep second cutting | 105/218 | 20.1 s |
| 76 | I climb the eastern bank where the fresh slither-mark crosses the rim, staff ready, and look for the serpent beyond it. | Erzähler | open_run_level | Track a ridge serpent from its fresh trail | hollow under the fallen lintel | 105/218 | 23.8 s |
| 77 | I cast Arcane Bolt at the serpent's raised head. | Erzähler | open_run_level | Engage the ridge serpent at range | hollow under the fallen lintel | 105/208 | 26.8 s |
| 78 | I follow the slither-marks along the cutting rim to track the next ridge serpent, staff ready. | Erzähler | open_run_level | Hunt the second serpent for the cull contract | dry pool under the fallen slab | 105/208 | 20.2 s |
| 79 | I stay behind the bank's cover and cast Arcane Bolt at the resting serpent's head. | Erzähler | open_run_level | Kill the second serpent for the cull contract | dry pool under the fallen slab | 105/198 | 16.0 s |
| 80 | #assign INT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up stat points | dry pool under the fallen slab | 105/198 | 2.5 s |
| 81 | I follow the streambed back up and hunt the third ridge serpent along the cutting rim, staff ready. | Erzähler | open_run_level | Complete the 3/3 cull contract | saddle hollow on the cutting rim | 105/198 | 42.2 s |
| 82 | I cast Arcane Wave at the serpent on the boulders before it can reach the haul road. | Erzähler | open_run_level | Engage the third serpent before it threatens the quarrymen | saddle hollow on the cutting rim | 105/184 | 16.4 s |
| 83 | I head back north along the haul road to Alderwatch to turn in the completed serpent cull at the Guild hall. | Erzähler | open_run_level | Return to Guild and turn in the 3/3 cull contract | Alderwatch | 105/184 | 19.0 s |
| 84 | I enter the Guild hall and turn in the completed serpent cull contract at the counter. | Erzähler | open_run_level | Turn in the 3/3 cull contract at the Guild hall | Adventurers' Guild hall, Alderwatch | 105/184 | 19.5 s |
| 85 | #assign INT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up stat points | Adventurers' Guild hall, Alderwatch | 105/184 | 2.5 s |
| 86 | I ask the clerk to see the current contract board. | Erzähler | open_run_level | Pick the next Guild contract | Adventurers' Guild hall, Alderwatch | 105/184 | 15.9 s |
| 87 | I take the Old Crown Catacombs Level 1 slip from the board and ask the clerk to book it for me. | Erzähler | open_run_level | Accept an achievable Novice contract | Adventurers' Guild hall, Alderwatch | 105/184 | 19.7 s |
| 88 | I take the contract slip and set out west along the road toward the ruined chapel. | Erzähler | open_run_level | Travel to the Old Crown Catacombs for the active contract | ruined chapel west of Alderwatch | 105/184 | 21.4 s |
| 89 | I cast Arcane Light isn't known—instead, I descend the spiral stair into the catacombs with my staff ready, keeping close to the wall. | Erzähler | open_run_level | Enter the Old Crown Catacombs Level 1 | ruined chapel west of Alderwatch | 105/184 | 25.0 s |
| 90 | I approach the door standing open a hand's width and peer carefully through the gap, staff raised. | Erzähler | open_run_level | Investigate the open door in the gallery | Old Crown Catacombs | 105/184 | 32.3 s |
| 91 | I enter through the open iron-banded door and advance carefully along the passage, staff raised, watching the slid coffin lid ahead. | Erzähler | open_run_level | Enter the dungeon and clear level 1 | vaulted coffin chamber | 105/184 | 31.9 s |
| 92 | I cast Arcane Wave at the three skeletons clustered near the coffin ring, hitting all of them at once. | Engine (Menü/Rückfrage) | open_run_level | AoE opener on all three skeletons | vaulted coffin chamber | 105/184 | 8.8 s |
| 93 | I cast Arcane Wave at Restless Skeleton A, B, and C — all three in range of the wave. | Erzähler | open_run_level | AoE opener on all three skeletons with named targets | vaulted coffin chamber | 105/170 | 26.1 s |
| 94 | I search the chamber around the altar and the boot prints for anything the crew left behind or loot, keeping an eye on the passage. | Erzähler | open_run_level | Loot the chamber and investigate the mystery | vaulted coffin chamber | 105/170 | 26.5 s |
| 95 | I grip the lantern as extra proof of the Guild crew's fate, then try prying the chiseled slab open with my staff, ready for whatever is belo… | Erzähler | open_run_level | Open the hatch slab and continue clearing level 1 | vaulted coffin chamber | 105/170 | 17.1 s |
| 96 | I check the slid coffin lid in the passage behind the iron-banded door for another way down, or a passage onward from this chamber toward th… | Erzähler | open_run_level | Look for another route since the slab won't budge | dust-floored passage behind the iron-banded door | 105/170 | 26.9 s |
| 97 | I descend the narrow stair behind the slid coffin lid, lantern raised, staff ready. | Erzähler | open_run_level | Continue clearing dungeon level 1 via the stair | dust-floored passage behind the iron-banded door | 105/170 | 19.8 s |
| 98 | I head back out through the iron-banded door and search the rest of Level One's galleries for remaining threats or another way past the seal… | Erzähler | open_run_level | Explore remaining Level 1 galleries | round bier chamber | 105/170 | 32.3 s |
| 99 | I approach the bier with the slid lid cautiously, staff ready, and peer through the gap to see what's scraping inside. | Erzähler | open_run_level | Investigate the scraping bier | round bier chamber | 105/170 | 19.7 s |
| 100 | I step back from the bier and cast Arcane Bolt at the rising skeleton. | Erzähler | open_run_level | Engage the gravekeeper | round bier chamber | 105/160 | 15.3 s |
| 101 | I search the round bier chamber and the wiped stone table for anything useful, then check the sealed biers' lids for another way down. | Erzähler | open_run_level | Loot the chamber and look for the route down | round bier chamber | 105/160 | 21.7 s |
| 102 | I slide the bier lid open and climb down into the passage below, lantern raised, staff ready. | Erzähler | open_run_level | Descend the second way down | round bier chamber | 105/160 | 30.4 s |
| 103 | I search the bier chamber and the galleries again for the level's keeper — the gravekeeper I defeated may not be the only one; I check behin… | Erzähler | open_run_level | Find and defeat the level 1 keeper to clear the quest | round bier chamber | 105/160 | 29.3 s |
| 104 | I descend the hidden stair quietly, staff ready, following the waymarked steps toward the scraping keeper. | Erzähler | open_run_level | Find and defeat the level 1 keeper | long warden gallery | 105/160 | 27.7 s |
| 105 | I cast Arcane Bolt at the Gallery Warden from the landing, keeping the stair at my back. | Erzähler | open_run_level | Engage the level 1 keeper | long warden gallery | 87/160 | 15.9 s |
| 106 | I cast Arcane Bolt at the Gallery Warden. | Erzähler | open_run_level | Attack the keeper now in range | long warden gallery | 67/150 | 19.8 s |
| 107 | I cast Arcane Bolt at the Gallery Warden to finish it. | Erzähler | open_run_level | Kill the wounded keeper | long warden gallery | 67/140 | 15.9 s |
| 108 | With the level cleared, I head back up through the bier chamber and out of the catacombs, then travel to the Valedorn Crown Guild hall and t… | Erzähler | open_run_level | Turn in the cleared dungeon contract at the Guild | Adventurers' Guild hall, Alderwatch | 67/140 | 36.0 s |
| 109 | I ask the clerk what novice-suitable contracts are on the board tonight. | Erzähler | open_run_level | Pick the next Guild contract | Adventurers' Guild hall, Alderwatch | 67/140 | 15.5 s |
| 110 | I'll take the Bog Lurker contract down, please — and I'll also buy the Primer of Ward for 80 copper if you have it. | Erzähler | open_run_level | Accept achievable contract and buy a useful manual | Adventurers' Guild hall, Alderwatch | 67/140 | 16.5 s |
| 111 | I read the Primer of Ward with my staff in hand to learn the ward skill, then find lodging for the night and sleep until morning. | Erzähler | open_run_level | Learn ward skill and recover overnight before the two-day trip south | Adventurers' Guild hall, Alderwatch | 67/140 | 17.7 s |
| 112 | I study the Primer of Ward for 2 hours, then find lodging in Alderwatch and sleep until morning. | Erzähler | open_run_level | Learn ward skill and recover overnight | Tin Lantern lodging house | 67/140 | 28.5 s |
| 113 | I'll take the room for 4 copper and the cold supper for 2, then go up and sleep until morning. | Engine (Menü/Rückfrage) | open_run_level | Buy lodging and meal, recover overnight | Tin Lantern lodging house | 67/140 | 7.3 s |
| 114 | I buy the room for 4 copper and the cold supper for 2 copper from you — 6 copper total — then eat and sleep until morning. | Erzähler | open_run_level | Buy lodging and meal, recover overnight | Tin Lantern lodging house | 115/316 | 24.0 s |
| 115 | I'll take a bowl of porridge for a copper, then set out south for the Withermere Ferry Shallows to hunt the Bog Lurker. | Erzähler | open_run_level | Eat, then travel to the contract target | the Withermere ferry shallows, two days south of Alderwatch | 115/316 | 22.6 s |
| 116 | I scan the wake-lines from the mudbank and look for the Bog Lurker's sign, keeping to firmer hummocks as I stalk the nearest wake-line. | Erzähler |  | Hunt the Bog Lurker | the churned hummocks | 115/316 | 29.3 s |
| 117 | I stay low among the reeds and open with an Arcane Bolt aimed at the Bog Lurker's flank while it faces away. | Erzähler | open_run_level | Ambush the Bog Lurker with a first strike | the churned hummocks | 115/316 | 19.1 s |
| 118 | I move slowly and low through the reeds and shin-deep water, closing half the gap toward the Bog Lurker and stopping at Arcane Bolt's range … | Erzähler | open_run_level | Close to spell range before attacking | the churned hummocks | 115/316 | 15.3 s |
| 119 | I loose an Arcane Bolt at the Bog Lurker's flank while it still faces away. | Erzähler | open_run_level | Ambush the Bog Lurker from spell range | the churned hummocks | 115/306 | 21.1 s |
| 120 | #assign INT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up points, then head back for the turn-in | the churned hummocks | 115/306 | 2.7 s |
| 121 | I collect the Bog Lurker's carcass proof if needed, then travel back to the Guild hall in Withermere to turn in the Cull the Bog Lurker cont… | Engine (Menü/Rückfrage) | open_run_level | Turn in the completed contract | the churned hummocks | 115/306 | 5.9 s |
| 122 | I travel to the Guild hall in Alderwatch and turn in the Cull the Bog Lurker of the Withermere Ferry Shallows contract. | Erzähler | open_run_level | Turn in the completed contract at Alderwatch Guild hall | Adventurers' Guild hall, Alderwatch | 115/306 | 23.4 s |
| 123 | #assign INT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up stat points | Adventurers' Guild hall, Alderwatch | 115/306 | 2.7 s |
| 124 | I ask the clerk what Novice-rank contracts are currently on the board. | Erzähler | open_run_level | Pick the next Guild contract | Adventurers' Guild hall, Alderwatch | 115/306 | 27.6 s |
| 125 | I take the Serpents on the Haul Road contract and ask the clerk to register it as active. | Erzähler | open_run_level | Accept the serpent cull contract | Adventurers' Guild hall, Alderwatch | 115/306 | 17.6 s |
| 126 | It's evening; I ask the clerk if lodging is available nearby, or I head out the Northgate and camp near the road, then travel to the Greysto… | Erzähler | open_run_level | Rest overnight, then hunt ridge serpents | Adventurers' Guild hall, Alderwatch | 115/306 | 46.9 s |
| 127 | I thank the overseer for the tip and walk down toward the third switchback, watching the warm bank for ridge serpents. | Erzähler | open_run_level | Hunt ridge serpents at the third switchback | Northgate | 115/306 | 23.0 s |
| 128 | I take a room at the Wayfarer's Rest, pay the copper, and sleep until dawn, then head out the Northgate toward the Greystone Quarry haul roa… | Erzähler | open_run_level | Lodge overnight, then hunt ridge serpents at the quarry | the Greystone Quarry haul road, north of Alderwatch | 115/306 | 56.9 s |
| 129 | I take cover behind the slab's scrub and cast Arcane Bolt into the den mouth to rouse the serpents, staying ready for them to emerge. | Erzähler | open_run_level | Hunt ridge serpents at the den | the Greystone Quarry haul road, north of Alderwatch | 115/296 | 22.8 s |
| 130 | I stay behind the scrub and cast Arcane Wave at the two serpents emerging from the den mouth. | Erzähler | open_run_level | Fight the two ridge serpents with AoE | the Greystone Quarry haul road, north of Alderwatch | 115/282 | 19.3 s |
| 131 | I call down to the quarryman that both serpents at the third switchback are dead, and ask whether there are more serpents about, such as the… | Erzähler | open_run_level | Report the kills and ask about the third serpent | the Greystone Quarry haul road, north of Alderwatch | 115/282 | 19.1 s |
| 132 | I thank the tally-keeper, pick up the two fresh shed skins snagged in the scrub, then head down to the deep second cutting to hunt the third… | Erzähler | open_run_level | Collect shed skins and hunt the third serpent in the deep second cutting to finish the 3/3… | the deep second cutting | 115/282 | 27.8 s |
| 133 | I step clear of the overhang's drop zone and turn to face the serpent behind me, casting Arcane Wave at it. | Erzähler | open_run_level | Fight the third ridge serpent to finish the contract | the deep second cutting | 115/268 | 21.8 s |
| 134 | I head back to the weighing shed on the top terrace to report the third serpent killed to the quarry master, then return to the Guild hall i… | Erzähler | open_run_level | Finish the 3/3 serpent contract and turn it in | Adventurers' Guild hall, Alderwatch | 115/268 | 36.1 s |
| 135 | #assign INT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up stat points | Adventurers' Guild hall, Alderwatch | 115/268 | 2.8 s |
| 136 | I ask the clerk what contracts are on the board suitable for a Novice mage. | Erzähler | open_run_level | Pick the next Guild contract | Adventurers' Guild hall, Alderwatch | 115/268 | 41.7 s |
| 137 | I take the Clear the Old Crown Catacombs Level 1 slip from the board and ask the clerk to register it as my active contract. | Erzähler | open_run_level | Accept the catacombs clearance contract | Adventurers' Guild hall, Alderwatch | 115/268 | 30.9 s |
| 138 | I head to the temple close and find the Temple Wardens at the undercroft door, showing my Guild plate to get the key to the catacombs. | Erzähler | open_run_level | Get the undercroft key and enter the Old Crown Catacombs | Temple close undercroft door | 115/268 | 35.0 s |
| 139 | I unlock the undercroft door with the bright key and enter the catacombs, staff ready, keeping light and noise low. | Erzähler | open_run_level | Enter Old Crown Catacombs level 1 to clear it | Temple close undercroft door | 115/268 | 29.3 s |
| 140 | I hold my light steady on the skeleton and cast Arcane Bolt at it as it comes along the wall. | Engine (Menü/Rückfrage) | open_run_level | Fight the first skeleton | Temple close undercroft door | 115/268 | 5.4 s |
| 141 | I cast Arcane Bolt at the restless skeleton advancing along the gallery wall. | Engine (Menü/Rückfrage) | open_run_level | Fight the first skeleton in the catacombs | Temple close undercroft door | 115/268 | 4.5 s |
| 142 | I turn back to the Temple Warden and say, "The undercroft door is unlocked — I'm ready to go down into the catacombs now. Open the way for m… | Erzähler | open_run_level | Return to the active scene with the warden to get into the catacombs properly | Temple close undercroft door | 115/268 | 23.6 s |
| 143 | I unlock the undercroft door with the bright key and step inside, heading down the stairs into the catacombs. | Erzähler | open_run_level | Actually enter the catacombs | Old Crown Catacombs | 115/268 | 24.9 s |
| 144 | I keep my light steady and cast Arcane Bolt at the skeleton coming along the wall. | Engine (Menü/Rückfrage) | open_run_level | Fight the first skeleton in the catacombs | Old Crown Catacombs | 115/268 | 5.2 s |
| 145 | I raise my staff and cast Arcane Bolt at the restless skeleton standing in the niche ahead. | Engine (Menü/Rückfrage) | open_run_level | Engage the first catacombs skeleton with a plainly named target | Old Crown Catacombs | 115/268 | 4.6 s |
| 146 | I enter the Old Crown Catacombs — I'm going in. | Erzähler | open_run_level | Engine-confirm dungeon entry so the skeleton encounter becomes a targetable scene | widened chamber of the upper gallery | 115/268 | 35.0 s |
| 147 | I cast Arcane Wave at the two skeletons in the chamber's far half, hitting both together. |  | open_run_level | Fight the two engine-confirmed skeletons with AoE | widened chamber of the upper gallery | 115/254 | 23.9 s |
| 148 | I gather the bone and grave dust, then follow the corridor sloping down past the chamber's far side, watching for more movement. | Erzähler | open_run_level | Continue clearing the catacombs toward the quest | fork beneath the rough pillar | 115/254 | 27.4 s |
| 149 | I take the left-hand passage, keeping to its swept floor and watching the pale gleam ahead. | Erzähler | open_run_level | Explore the left passage toward the quest | fork beneath the rough pillar | 115/254 | 20.7 s |
| 150 | I go back to the fork and take the right-hand sloping passage, following the cold draught down. | Erzähler | open_run_level | Explore the lower passage since the left is sealed by the marked slab | fork beneath the rough pillar | 115/254 | 18.1 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 6 (notiert vor Zug 7): Registration cost 20 copper (2 silver in narration, engine says 20 copper); coin display inconsistent (HUD shows 3 Silver, engine 30 cp).
- zu Zug 21 (notiert vor Zug 22): Primer of Strike costs 80 copper but I hold only 75 copper — cannot afford any primer yet.
- zu Zug 27 (notiert vor Zug 28): Quest shows 1/1 defeated; XP 94/100, one kill from level 2.
- zu Zug 38 (notiert vor Zug 39): Odo's rumor confirmed: Halvard claimed the tail was rubbed to push the price down.
- zu Zug 47 (notiert vor Zug 48): System says active scene has no targetable actor; the serpent is still inside the den and won't accept attacks until it appears.
- zu Zug 48 (notiert vor Zug 49): MP is low (52/184); Arcane Wave may leave me drained.
- zu Zug 62 (notiert vor Zug 63): Bog Lurker contract expired/was taken by others within minutes of opening; morning board stock is competitive.
- zu Zug 63 (notiert vor Zug 64): Board fully turns over each dawn; both yesterday's targets were gone by 08:05 despite arriving at opening bell.
- zu Zug 66 (notiert vor Zug 67): HUD signs already show the stone drain as heavy marten use and the marten at a baited bank staring at cover.
- zu Zug 68 (notiert vor Zug 69): Marten not yet targetable; must find it in the scene first.
- zu Zug 74 (notiert vor Zug 75): HUD mentions a 'terrace flat by the serpent den' exit; narrows rumor points to the second cutting.
- zu Zug 88 (notiert vor Zug 89): Contract already ACTIVE per HUD; narration implied I must carry the slip but engine says take unnecessary.
- zu Zug 121 (notiert vor Zug 122): Alderwatch appears to be the local Guild hall; earlier pelts sale pending.
- zu Zug 126 (notiert vor Zug 127): HUD still shows Day 8 20:07 at the Guild hall and 0/3 serpents despite narration of travel and dawn arrival; time/location panel seems stale.
- zu Zug 127 (notiert vor Zug 128): Engine contradicted prior travel narration: I'm back at the shut Northgate, Day 8 20:32, contract still 0/3. The quarry trip must be redone from dawn.
- zu Zug 131 (notiert vor Zug 132): HUD shows 2/3 serpents defeated; the tally-keeper says the third may be in the deep second cutting.
- zu Zug 141 (notiert vor Zug 142): Narration described entering the catacombs and a skeleton, but the System says the active scene is still 'Temple Warden · SHORT' — engine and narration are out of sync.
- zu Zug 142 (notiert vor Zug 143): Narration previously described catacomb entry and a skeleton, but the System scene stayed at Temple Warden — the earlier 'entry' was never engine-confirmed.
- zu Zug 144 (notiert vor Zug 145): System refused the skeleton as a target despite narration describing it — active scene shows no targetable actor, so the encounter may need engine-confirmed spawning first.
- zu Zug 145 (notiert vor Zug 146): Dungeon gate card says 'ENTER DUNGEON? — this card books nothing'; narration described entry but the System still shows no targetable actor, so entry likely needs an explicit declaration.
- zu Zug 147 (notiert vor Zug 148): Engine flagged WORLD NOT RECORDED on the last reply, but the combat result and HUD confirm the kills and loot; only the scene placement delta failed.
- zu Zug 149 (notiert vor Zug 150): Left passage is barred by a fitted slab with a circle-and-bar mark; engine blocked entry, so trying the right-hand route.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t19 | 19 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t27 | 27 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t41 | 42 | 1 | – | nein | 1 | gewonnen, 168 XP |
| enc.t45 | 49 | 1 | – | nein | 1 | gewonnen, 118 XP |
| enc.t51 | 55 | 1 | – | nein | 1 | gewonnen, 96 XP |
| enc.t64 | 70 | 1 | – | nein | 1 | gewonnen, 30 XP |
| enc.t71 | 77 | 1 | – | nein | 1 | gewonnen, 96 XP |
| enc.t73 | 79 | 1 | – | nein | 1 | gewonnen, 96 XP |
| enc.t75 | 82 | 1 | – | nein | 1 | gewonnen, 146 XP |
| enc.t84 | 93 | 3 | – | nein | 3 | gewonnen, 144 XP |
| enc.t91 | 100 | 1 | – | nein | 1 | gewonnen, 48 XP |
| enc.t96r | 105 | 1 | – | nein | 1 | gewonnen, 180 XP |
| enc.t109 | 119 | 1 | – | nein | 1 | gewonnen, 240 XP |
| enc.t117 | 130 | 2 | – | nein | 2 | gewonnen, 192 XP |
| enc.t120 | 133 | 1 | – | nein | 1 | gewonnen, 168 XP |
| enc.t129 | 147 | 2 | – | nein | 2 | gewonnen, 144 XP |

## Quests

- **Fang in the Turnip Rows** — active (Zug 6) → completed (Zug 20)
  - Aufgabe: Kill 1 the grey-marsh marten raiding the Millbrook allotments at the Millbrook allotment gardens, east of Alderwatch. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the grey-marsh marten raiding the Millbrook allotments killed at the Millbrook allotment gardens, east of Alderwatch.
- **Cull the Quarryside Serpent Brood** — expired (Zug 21)
  - Aufgabe: Kill 4 ridge serpents basking along the haul road at the Greystone Quarry haul road, north of Alderwatch. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 ridge serpents basking along the haul road killed at the Greystone Quarry haul road, north of Alderwatch.
- **Thin the Withermere Bog Lurkers** — expired (Zug 21)
  - Aufgabe: Kill 6 bog lurkers in the ferry shallows at the Withermere ferry shallows, two days south of Alderwatch. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 6 bog lurkers in the ferry shallows killed at the Withermere ferry shallows, two days south of Alderwatch.
- **Break the Thornfell Boar Herd** — expired (Zug 21)
  - Aufgabe: Kill 3 great tusked boars of Thornfell Wood, led by an old scarred lead boar at Thornfell Wood, a day northwest of Alderwatch. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 great tusked boars of Thornfell Wood, led by an old scarred lead boar killed at Thornfell Wood, a day northwest of Alderwatch.
- **Clear the Old Crown Catacombs, Level 1** — expired (Zug 21), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of Old Crown Catacombs. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Old Crown Catacombs is clear.
- **Cull the Millbrook Garden Marten** — active (Zug 22) → completed (Zug 29)
  - Aufgabe: Kill 1 grey-marsh marten at the Millbrook allotment gardens, east of Alderwatch. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 grey-marsh marten killed at the Millbrook allotment gardens, east of Alderwatch.
- **Cull Ridge Serpents on the Quarry Haul Road** — active (Zug 32) → completed (Zug 56)
  - Aufgabe: Kill 3 ridge serpent at the Greystone Quarry haul road, north of Alderwatch. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 ridge serpent killed at the Greystone Quarry haul road, north of Alderwatch.
- **Cull the Withermere Bog Lurker** — taken_by_other (Zug 62)
  - Aufgabe: Kill 1 bog lurker at the Withermere ferry shallows, two days south of Alderwatch. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 bog lurker killed at the Withermere ferry shallows, two days south of Alderwatch.
- **Cull the Great Tusked Boar of Thornfell** — expired (Zug 64)
  - Aufgabe: Kill 1 great tusked boar at Thornfell Wood, a day northwest of Alderwatch. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 great tusked boar killed at Thornfell Wood, a day northwest of Alderwatch.
- **Clear Old Crown Catacombs Level 1** — expired (Zug 64), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of Old Crown Catacombs. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Old Crown Catacombs is clear.
- **Cull the Grey-Marsh Marten at the Millbrook Allotments** — active (Zug 65) → completed (Zug 71)
  - Aufgabe: Kill 1 grey-marsh marten at the Millbrook allotment gardens, east of Alderwatch. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 grey-marsh marten killed at the Millbrook allotment gardens, east of Alderwatch.
- **Cull Ridge Serpents on the Greystone Quarry Haul Road** — active (Zug 73) → completed (Zug 84)
  - Aufgabe: Kill 3 ridge serpents at the Greystone Quarry haul road, north of Alderwatch. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 ridge serpents killed at the Greystone Quarry haul road, north of Alderwatch.
- **Cull the Bog Lurker of the Withermere Ferry Shallows** — active (Zug 110) → completed (Zug 122), READY
  - Aufgabe: Kill 1 bog lurker at the Withermere ferry shallows, two days south of Alderwatch. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 bog lurker killed at the Withermere ferry shallows, two days south of Alderwatch.
- **Cull the Great Tusked Boar of Thornfell Wood** — expired (Zug 124)
  - Aufgabe: Kill 1 great tusked boar at Thornfell Wood, a day northwest of Alderwatch. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 great tusked boar killed at Thornfell Wood, a day northwest of Alderwatch.
- **Clear Old Crown Catacombs Level 1** — active (Zug 87) → completed (Zug 108), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of Old Crown Catacombs. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Old Crown Catacombs is clear.
- **Marten in the Pea Rows** — expired (Zug 136)
  - Aufgabe: Kill 1 grey-marsh marten at the Millbrook allotment gardens, east of Alderwatch. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 grey-marsh marten killed at the Millbrook allotment gardens, east of Alderwatch.
- **Serpents on the Haul Road** — active (Zug 125) → completed (Zug 134)
  - Aufgabe: Kill 3 ridge serpent at the Greystone Quarry haul road, north of Alderwatch. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 ridge serpent killed at the Greystone Quarry haul road, north of Alderwatch.
- **Lurker at the Withermere Crossing** — expired (Zug 136)
  - Aufgabe: Kill 1 bog lurker at the Withermere ferry shallows, two days south of Alderwatch. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 bog lurker killed at the Withermere ferry shallows, two days south of Alderwatch.
- **The Old Boar of Thornfell** — expired (Zug 136)
  - Aufgabe: Kill 1 great tusked boar at Thornfell Wood, a day northwest of Alderwatch. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 great tusked boar killed at Thornfell Wood, a day northwest of Alderwatch.
- **Clear the Old Crown Catacombs, Level 1** — expired (Zug 136), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of Old Crown Catacombs. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Old Crown Catacombs is clear.
- **Clear the Old Crown Catacombs Level 1** — active (Zug 137), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of Old Crown Catacombs. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Old Crown Catacombs is clear.

## Auffälligkeiten

- Zug 9, Nachricht 17 (planner_repaired): the planner's first answer needed a repair
- Zug 17, Nachricht 34 (extraction_repaired): the extractor's first answer needed a repair
- Zug 25, Nachricht 50 (extraction_repaired): the extractor's first answer needed a repair
- Zug 33, Nachricht 66 (extraction_failed): the extractor failed: $.deltas[0] (place.reported): : missing required "how"; $.deltas[0] (place.reported): .place: matches none of anyOf; Place reference at deltas[0].place: use a known place id or {"new":{"name":"exact n
- Zug 33, Nachricht 66 (extraction_repaired): the extractor's first answer needed a repair
- Zug 59, Nachricht 118 (extraction_repaired): the extractor's first answer needed a repair
- Zug 64, Nachricht 127 (planner_repaired): the planner's first answer needed a repair
- Zug 67, Nachricht 134 (extraction_repaired): the extractor's first answer needed a repair
- Zug 69, Nachricht 138 (extraction_repaired): the extractor's first answer needed a repair
- Zug 71, Nachricht 142 (extraction_repaired): the extractor's first answer needed a repair
- Zug 73, Nachricht 146 (extraction_repaired): the extractor's first answer needed a repair
- Zug 90, Nachricht 180 (extraction_repaired): the extractor's first answer needed a repair
- Zug 94, Nachricht 188 (extraction_repaired): the extractor's first answer needed a repair
- Zug 98, Nachricht 196 (extraction_repaired): the extractor's first answer needed a repair
- Zug 98, Nachricht 196 (extractor_recovery): the extractor required transport recovery (status applied)
- Zug 102, Nachricht 204 (extraction_repaired): the extractor's first answer needed a repair
- Zug 110, Nachricht 219 (cull_count): Cull the Bog Lurker of the Withermere Ferry Shallows: its objective counts 1, its texts say 1, 2 (for review)
- Zug 112, Nachricht 224 (extraction_repaired): the extractor's first answer needed a repair
- Zug 113, Nachricht 225 (planner_repaired): the planner's first answer needed a repair
- Zug 116, Nachricht 232 (extraction_repaired): the extractor's first answer needed a repair
- Zug 126, Nachricht 252 (extraction_repaired): the extractor's first answer needed a repair
- Zug 128, Nachricht 256 (extraction_repaired): the extractor's first answer needed a repair
- Zug 134, Nachricht 268 (extraction_repaired): the extractor's first answer needed a repair
- Zug 143, Nachricht 286 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (restless skeleton): refused, no fight (Patch 8.4.1 guard)
- Zug 147, Nachricht 294 (extraction_failed): the extractor failed: $.deltas[0] (passage): .to: matches none of anyOf; Place reference at deltas[0].to: use a known place id or {"new":{"name":"exact name","kind":"interior","parent":"known parent id"}}; a new parent use
- Zug 147, Nachricht 294 (extraction_repaired): the extractor's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 24× keine gültige JSON-Entscheidung (Züge 4, 9, 10, 11, 12, 22, 27, 29, 30, 44, 52, 54, 58, 67, 82, 98, 105, 117, 119, 129, 131, 137, 141, 150)
- Server: Chat completion request error:  Internal Server Error {"error":{"message":"An unexpected error has occurred.","type":"server_error","code":"internal_server_error","param":null}}

System-Panels: CLARIFY 2, NOT TAKEN 1, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: ambient 4, scene_context 26, engine_owned_fact 13, pc_inventory 3, engine_owned_combat 1, object 1, guild_canon 5, world_rule 4, quest_count 3, engine_booked 1, guild_completion 2, guild_payout 3, no_go 8, coin_already_received 1, time_cap 2, npc_presence 1, npc_continuity 1, passage 3, attack_commitment 3, offer 1, group_unclear 2, quest_dependency 1, dungeon_foe 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 1, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 24/150 Erstantworten ungültig (16.0 %); 24 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 143 | 3 | 2.6 s | 4.3 s | 12433 | 9951 | 80 | – | stop 143 | 0 |
| board | 5 | 0 | 11.2 s | 16.3 s | 2634 | 2305 | 978 | – | stop 5 | 0 |
| narrator | 130 | 0 | 8.7 s | 13.9 s | 11622 | 8840 | 418 | – | stop 130 | 0 |
| extract | 149 | 19 | 5.5 s | 10.7 s | 13140 | 9783 | 370 | – | stop 148 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 63:40 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 22.0 s) | 0:36 min |
| 150 Züge, Spiel (Senden bis HUD nach der Extraktion) | 52:14 min — Median 19.9 s, p90 35.0 s, max 56.9 s |
| 150 Züge, Spieler-Entscheidung | 8:00 min — Median 2.2 s, 24 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 7:49 min / 1:00 min / 21:33 min / 15:51 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 24.1 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 16:04 min, 80 Züge ≈ 32:07 min (ohne Einrichtung) |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
