# Avereth Live-Test 20261030-014642Z-current_test

## Kurzfassung

- **Laufprofil:** guild-rogue; Startklasse Rogue, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** abgebrochen: Limit erreicht — 150 turns
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 8. Sicherheitsgrenzen: 150 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** Level 7, 76 XP seit Levelaufstieg, 496 cp, HP 119, MP 84; Ort realm.caelreth.the_gravel_bars_of_the_weir_crossing_shallows_on_the_glassmere_stream. Ausrüstung und Skills stehen in evaluation.json → progression.checkpoint.
- **Charakter:** rogue (rogue.razor_cut, rogue.fan_of_blades) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: curious adventurer: follow interesting opportunities without forcing dangerous encounters
- **Züge:** 150 · **Dauer:** 60:53 min · **LLM-Aufrufe der Engine/des Erzählers:** 423
- **Beobachtete Abdeckung:** 18 unterschiedliche gebuchte Reiseziele · 13 Kämpfe · 0 Verkäufe (0 cp Umsatz, ohne Questzahlungen/Geschenke) · 0 Ausrüstungswechsel · 1 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 14
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.120 |
| Git | ca7a78f400b1 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 14.3 s |
| Browser | chrome 156.0.8078.49 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261030-014642Z-current_test“, Seed 2009264426 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | I choose Rogue. | Engine (Menü/Rückfrage) | creation_complete | Select Rogue base class | public roadside verge outside Glassmere | 90/84 | 2.3 s |
| 2 | I select Fan of Blades and Razor Cut as my two skills. | Engine (Menü/Rückfrage) | creation_complete | Finish Rogue character creation | public roadside verge outside Glassmere | 90/84 | 2.2 s |
| 3 | I walk through the gates into Glassmere and head straight for the Adventurers' Guild to look at the contract board. | Erzähler | creation_complete | Enter city and find Guild contracts | Adventurers' Guild hall, Glassmere | 90/84 | 30.9 s |
| 4 | I ask the clerk to register me with the Guild and take the 'Thin the Stranglewillow Sprouts' contract. | Erzähler | open_run_level | Register and accept first novice contract | Adventurers' Guild hall, Glassmere | 90/84 | 13.5 s |
| 5 | I pay the two silver registration fee and take the reading. | Erzähler | open_run_level | Register with the Guild | Adventurers' Guild hall, Glassmere | 90/84 | 28.3 s |
| 6 | I confirm I'll take the 'Thin the Stranglewillow Sprouts' contract now that I'm registered. | Erzähler | open_run_level | Accept first Guild contract | Adventurers' Guild hall, Glassmere | 90/84 | 25.3 s |
| 7 | I head down to the outflow ditch below Tanners' Row to hunt the stranglewillow sprout. | Erzähler | open_run_level | Travel to contract site and fight the sprout | the tanner's outflow ditch below Tanners' Row, Glassmere | 90/84 | 19.8 s |
| 8 | I draw my dagger and creep toward the flattened reeds, ready to strike the sprout the moment it shows itself. | Erzähler | open_run_level | Engage the stranglewillow sprout for the contract | the tanner's outflow ditch below Tanners' Row, Glassmere | 90/84 | 27.5 s |
| 9 | I burst from the reeds and strike the sprout from behind with Razor Cut while it's still feeding. | Erzähler | open_run_level | Ambush the sprout for the contract kill | the tanner's outflow ditch below Tanners' Row, Glassmere | 90/84 | 19.8 s |
| 10 | I charge across the open mud and strike the sprout with Razor Cut as soon as I'm in reach. | Erzähler | open_run_level | Close to melee range and attack the sprout | the tanner's outflow ditch below Tanners' Row, Glassmere | 90/84 | 15.6 s |
| 11 | I head back up to the Guild hall in Glassmere and turn in the chitin plate for the 'Thin the Stranglewillow Sprouts' contract. | Erzähler | open_run_level | Turn in the completed contract | Adventurers' Guild hall, Glassmere | 90/84 | 19.4 s |
| 12 | I look over the freshly posted board for another Novice contract I can take. | Erzähler | open_run_level | Pick next Guild contract from the board | Adventurers' Guild hall, Glassmere | 90/84 | 11.9 s |
| 13 | I'll take the 'Cull the Gravel-Bar Otterhounds' contract, please. | Erzähler | open_run_level | Accept the otterhound cull contract | Adventurers' Guild hall, Glassmere | 90/84 | 13.6 s |
| 14 | I head upstream past the fullers' racks to the Weir Crossing landing and ask the ferrymen to point me toward the gravel bars where the otter… | Erzähler | open_run_level | Travel to the otterhound hunting grounds | Weir Crossing landing | 90/84 | 23.9 s |
| 15 | I move along the dry upper bank toward the second gravel bar, keeping off the wet stones and watching for the hounds' slides. | Erzähler | open_run_level | Stalk the otterhound den sites | the gravel bars of the Weir Crossing shallows on the Glassmere stream | 90/84 | 38.0 s |
| 16 | I stay downwind and creep onto the bar, then strike the resting hound with Razor Cut from behind before it can react. | Erzähler | open_run_level | Ambush the resting otterhound with Razor Cut | the gravel bars of the Weir Crossing shallows on the Glassmere stream | 90/84 | 19.2 s |
| 17 | I strike the sleeping hound with Razor Cut from behind. | Erzähler | open_run_level | Attack the resting otterhound | the gravel bars of the Weir Crossing shallows on the Glassmere stream | 90/84 | 15.9 s |
| 18 | I close the last ten paces across the gravel and, if I reach the hound, strike it with Razor Cut from behind. | Erzähler | open_run_level | Close to ENGAGED and ambush the sleeping otterhound | the gravel bars of the Weir Crossing shallows on the Glassmere stream | 73/84 | 13.0 s |
| 19 | I finish it with Razor Cut to the throat. | Erzähler | open_run_level | Kill the badly wounded otterhound | the gravel bars of the Weir Crossing shallows on the Glassmere stream | 73/84 | 17.5 s |
| 20 | #assign STR 2 AGI 2 VIT 1 | System (Befehl) | open_run_level | Spend level-up points, then continue the hunt | the gravel bars of the Weir Crossing shallows on the Glassmere stream | 73/84 | 2.2 s |
| 21 | I bind my bitten forearm, then move up to the willows over the next slide, staying downwind and watching for another resting hound. | Erzähler | open_run_level | Continue the cull toward the second hound | the gravel bars of the Weir Crossing shallows on the Glassmere stream | 73/84 | 15.6 s |
| 22 | I move up to the willows over the next slide, staying downwind and watching for another resting hound. | Erzähler | open_run_level | Continue the cull toward the second hound | the willows over the next slide | 73/84 | 20.7 s |
| 23 | I creep to the water's edge behind the dozing hound and strike its exposed throat with Razor Cut. | Erzähler | open_run_level | Ambush the second otterhound | the willows over the next slide | 73/84 | 16.7 s |
| 24 | I strike first while it hesitates—Razor Cut at its neck as it gathers to charge. | Erzähler | open_run_level | Attack the alerted otterhound before it charges | the willows over the next slide | 73/84 | 15.2 s |
| 25 | I step in to meet its charge and Razor Cut its neck as it comes. | Erzähler | open_run_level | Close to ENGAGED and attack the charging otterhound | the willows over the next slide | 58/84 | 27.1 s |
| 26 | I finish it—Razor Cut through its throat while it sets itself. | Erzähler | open_run_level | Kill the wounded otterhound | the willows over the next slide | 58/84 | 25.9 s |
| 27 | #assign AGI 2 PER 2 VIT 1 | System (Befehl) | open_run_level | Spend level-up points, then continue the cull toward the third otterhound | the willows over the next slide | 58/84 | 2.1 s |
| 28 | I skin nothing and rest a few minutes by the stream, then move on to look for the third otterhound's tracks along the gravel bars. | Erzähler | open_run_level | Continue the cull toward the third otterhound | the willows over the next slide | 58/84 | 31.8 s |
| 29 | I rest for half an hour by the stream, then follow the tracks upstream along the open gravel bar toward the crossing, staying alert. | Erzähler | open_run_level | Rest to recover a little, then track the third otterhound | the willows over the next slide | 63/84 | 24.9 s |
| 30 | I close the distance fast across the bar and, once within range, loose Fan of Blades to hit both hounds at once. | Erzähler | open_run_level | Engage both otterhounds with AoE | the willows over the next slide | 49/84 | 20.1 s |
| 31 | I finish the wounded one first—Razor Cut through Otterhound D's throat. | Erzähler | open_run_level | Kill Otterhound D before facing the fresh one | the willows over the next slide | 38/84 | 15.1 s |
| 32 | I finish the last hound—Razor Cut through Otterhound C's throat. | Erzähler | open_run_level | Kill the final otterhound to complete the cull | the willows over the next slide | 38/84 | 14.3 s |
| 33 | #assign AGI 2 PER 2 VIT 1 | System (Befehl) | open_run_level | Spend level-up points, then return to the Guild to turn in the completed cull | the willows over the next slide | 38/84 | 2.2 s |
| 34 | I head back toward the Guild hall in town to turn in the completed otterhound cull. | Erzähler | open_run_level | Return and turn in the finished cull | Adventurers' Guild hall, Glassmere | 38/84 | 20.1 s |
| 35 | I ask the clerk what contracts are on the board suitable for a Novice—preferably nothing that needs a full day in the field before I've heal… | Erzähler | open_run_level | Browse new contracts | Adventurers' Guild hall, Glassmere | 38/84 | 26.8 s |
| 36 | I buy the Primer of Mend for 80 copper and read it to learn the skill. | Erzähler | open_run_level | Learn mend skill before healing up | Adventurers' Guild hall, Glassmere | 38/84 | 21.5 s |
| 37 | I ask the clerk how the primer is actually used—reading alone didn't teach me the skill. | Erzähler | open_run_level | Learn how to use the Mend primer | Adventurers' Guild hall, Glassmere | 38/84 | 17.8 s |
| 38 | I answer honestly: 'Barely a trickle, if anything. Maybe this one wasn't for me.' I ask whether the Guild buys back primers, or buys otterho… | Erzähler | open_run_level | Handle the primer question, sell surplus, arrange lodging | Adventurers' Guild hall, Glassmere | 38/84 | 37.3 s |
| 39 | I sell her the lot—four pelts and nine fangs—at the desk price. | Erzähler | open_run_level | Sell surplus loot, then lodging | Adventurers' Guild hall, Glassmere | 38/84 | 15.4 s |
| 40 | "Done," I say, and take the seventeen copper. Then I head to the Ferryman's Rest on Dock Lane, pay for a bed, and sleep until morning. | Erzähler | open_run_level | Confirm sale, then rest overnight to heal | Ferryman's Rest | 38/84 | 31.9 s |
| 41 | I pay the woman a copper for the bed, then go upstairs and sleep until morning. | Erzähler | open_run_level | Actually book the bed and sleep to recover | Ferryman's Rest | 38/84 | 23.3 s |
| 42 | I lie down on the straw tick and sleep until morning. | Erzähler | open_run_level | Actually sleep to recover HP | Ferryman's Rest | 120/84 | 13.6 s |
| 43 | I head to the Guild hall and ask to see the current contract board. | Erzähler | open_run_level | Pick a new Guild contract after resting | Adventurers' Guild hall, Glassmere | 120/84 | 36.8 s |
| 44 | I tell the clerk I'll take the Stranglewillow Sprout contract, and ask him to make it active. | Erzähler | open_run_level | Accept the achievable novice kill contract | Adventurers' Guild hall, Glassmere | 120/84 | 12.1 s |
| 45 | I head out of the Guild and travel to the tanner's outflow ditch below Tanners' Row to hunt the stranglewillow sprout. | Erzähler | open_run_level | Travel to the contract site | the tanner's outflow ditch below Tanners' Row, Glassmere | 120/84 | 18.9 s |
| 46 | I draw my dagger and close on the stranglewillow sprout at the water's edge, minding the mud, and attack it. | Engine (Menü/Rückfrage) | open_run_level | Fight the contract target | the tanner's outflow ditch below Tanners' Row, Glassmere | 120/84 | 7.7 s |
| 47 | I cross the slick mud toward the pale root-thing at the water's edge and strike it with my dagger. | Engine (Menü/Rückfrage) | open_run_level | Engage the sprout as a valid target | the tanner's outflow ditch below Tanners' Row, Glassmere | 120/84 | 5.6 s |
| 48 | I ask the tanner to wash the hides now, hoping the sprout rises for it, and wait watchfully by the willow stump. | Erzähler | open_run_level | Lure the sprout into a valid target state | the tanner's outflow ditch below Tanners' Row, Glassmere | 120/84 | 21.0 s |
| 49 | I strike the sprout with Razor Cut while it is still drinking at the bank's edge. | Erzähler | open_run_level | Attack the now-surfaced contract target | the tanner's outflow ditch below Tanners' Row, Glassmere | 120/84 | 16.0 s |
| 50 | I move across the slick mud to close within arm's reach of the sprout, and strike it with Razor Cut as soon as I'm engaged. | Erzähler | open_run_level | Close to ENGAGED range and attack the contract target | the tanner's outflow ditch below Tanners' Row, Glassmere | 120/84 | 18.0 s |
| 51 | I take the offered hook and rope and drag the dead sprout up off the bank before the next wash comes down. | Erzähler | open_run_level | Clear the channel, then return to the Guild for turn-in | the tanner's outflow ditch below Tanners' Row, Glassmere | 120/84 | 19.8 s |
| 52 | I return the hook and rope to the tanners and head to the Guild hall to turn in the sprout contract. | Erzähler | open_run_level | Turn in the READY quest | Adventurers' Guild hall, Glassmere | 120/84 | 27.9 s |
| 53 | I ask the clerk what novice contracts are open on the board today. | Erzähler | open_run_level | Pick the next Guild contract | Adventurers' Guild hall, Glassmere | 120/84 | 16.8 s |
| 54 | I ask the clerk to accept the Weir Crossing otterhound contract and mark it active for me. | Erzähler | open_run_level | Accept the otterhound hunt | Adventurers' Guild hall, Glassmere | 120/84 | 13.4 s |
| 55 | I take the slip and travel down the stream road to the Weir Crossing shallows. | Erzähler | open_run_level | Travel to the otterhound hunt site | the gravel bars of the Weir Crossing shallows on the Glassmere stream | 120/84 | 19.4 s |
| 56 | I ready my dagger and watch the otterhound wading onto the shallows, keeping my distance until it closes to engaging range, then strike it w… | Engine (Menü/Rückfrage) | open_run_level | Engage the first otterhound at close range | the gravel bars of the Weir Crossing shallows on the Glassmere stream | 120/84 | 7.0 s |
| 57 | I walk out onto the gravel bar toward the otterhound wading onto the shallows, closing the distance until it engages me. | Erzähler | open_run_level | Engage the otterhound at close range so Razor Cut has a valid target | the gravel bars of the Weir Crossing shallows on the Glassmere stream | 120/84 | 20.4 s |
| 58 | "I'm after the big brute on the far bars—where does it usually come down to fish?" I keep watching the channels for it. | Erzähler | open_run_level | Locate the otterhound via the fishers | the gravel bars of the Weir Crossing shallows on the Glassmere stream | 120/84 | 14.9 s |
| 59 | I back off the bar and hide downwind among the bank willows, watching the far channel for the otterhound. | Erzähler | open_run_level | Stake out the otterhound's approach | the gravel bars of the Weir Crossing shallows on the Glassmere stream | 120/84 | 16.7 s |
| 60 | I stay hidden and wait for the otterhound to wade closer to my side of the bar, then strike it with Razor Cut when it's in range. | Erzähler | open_run_level | Ambush the otterhound from concealment | the gravel bars of the Weir Crossing shallows on the Glassmere stream | 120/84 | 20.3 s |
| 61 | I lunge from the willows and strike the otterhound with Razor Cut as it stands in the shallows at twenty paces. | Erzähler | open_run_level | Attack the otterhound at close range | the gravel bars of the Weir Crossing shallows on the Glassmere stream | 120/84 | 17.8 s |
| 62 | #assign AGI 3 PER 2 | System (Befehl) | open_run_level | Spend level-up stat points | the gravel bars of the Weir Crossing shallows on the Glassmere stream | 120/84 | 2.2 s |
| 63 | I wipe my dagger and tell the fishers the otterhound is dead, then head back to Weir Crossing to turn in the contract at the Guild hall. | Erzähler | open_run_level | Turn in the otterhound contract | Adventurers' Guild hall, Glassmere | 120/84 | 29.1 s |
| 64 | I ask the clerk what contracts are on the board suitable for a Novice rogue. | Erzähler | open_run_level | Pick the next Guild contract | Adventurers' Guild hall, Glassmere | 120/84 | 26.1 s |
| 65 | I set the contract slip back on the counter. "The engine says it's paid and filed—please close it out properly and show me the ledger entry.… | Erzähler | open_run_level | Re-turn in the otterhound contract the clerk claims is still open | Adventurers' Guild hall, Glassmere | 120/84 | 21.0 s |
| 66 | I accept the boar contract: Cull the Ridgeback Boars in the Gorse Breaks (3). | Erzähler | open_run_level | Take the achievable Novice hunt contract | Adventurers' Guild hall, Glassmere | 120/84 | 16.8 s |
| 67 | I head west out of the Northgate along the Coldwell road toward the Gorse Breaks, and on arrival ask at the nearest farmstead where the boar… | Erzähler | open_run_level | Travel to the Gorse Breaks and locate the boars | vineyard farmstead at the Coldwell road | 120/84 | 25.5 s |
| 68 | I confirm I'm hunting them today and ask whether anyone can walk me up toward the pushed-over wall near the ridge before dusk, since that's … | Erzähler | open_run_level | Locate the boars at dusk with local guidance | vineyard farmstead at the Coldwell road | 120/84 | 36.8 s |
| 69 | I thank the farmer and settle in behind the broken wall to wait for dusk, blades ready for when the boars come down their track. | Erzähler | open_run_level | Ambush the boars at dusk behind the broken wall | vineyard farmstead at the Coldwell road | 120/84 | 32.9 s |
| 70 | I strike the lead boar from behind cover with a dagger attack to its flank. | Erzähler | open_run_level | Open the ambush on the lead boar | vineyard farmstead at the Coldwell road | 120/84 | 20.0 s |
| 71 | I step out from behind the wall and charge the lead boar, closing the distance, then strike it with Razor Cut. | Erzähler | open_run_level | Engage the lead boar and attack | vineyard farmstead at the Coldwell road | 120/84 | 16.8 s |
| 72 | I hold my ground behind the broken wall and let the lead boar come to me, staying behind cover until it closes to ENGAGED range, then I stri… | Erzähler | open_run_level | Let the charging boar close the distance, then attack | vineyard farmstead at the Coldwell road | 120/84 | 20.1 s |
| 73 | I strike the charging lead boar with Razor Cut as it reaches me at ENGAGED range. | Erzähler | open_run_level | Attack the boar now at ENGAGED range | vineyard farmstead at the Coldwell road | 101/84 | 25.2 s |
| 74 | I strike the wounded boar again with Razor Cut before it can recover. | Erzähler | open_run_level | Finish the lead boar while it is ENGAGED and hurt | vineyard farmstead at the Coldwell road | 82/84 | 23.8 s |
| 75 | I finish the boar with a basic attack before the other two can close in. | Erzähler | open_run_level | Kill the nearly dead lead boar | vineyard farmstead at the Coldwell road | 82/84 | 16.9 s |
| 76 | #assign AGI 2 PER 2 VIT 1 | System (Befehl) | open_run_level | Allocate level-up stat points | vineyard farmstead at the Coldwell road | 82/84 | 2.5 s |
| 77 | I field-dress the dead boar and take anything useful, then head back toward Coldwell for the night, keeping an eye on the road. | Erzähler | open_run_level | Loot and return before full dark | Coldwell | 82/84 | 26.9 s |
| 78 | I go into the inn and get a room for the night, then eat and sleep until morning. | Erzähler | open_run_level | Lodging and overnight recovery | Coldwell inn | 82/84 | 23.4 s |
| 79 | "That's the pig. I'll take the mutton and the room." | Erzähler | open_run_level | Buy food and lodging | Coldwell inn | 82/84 | 22.7 s |
| 80 | I take the room I paid for and sleep in the bed until morning. | Erzähler | open_run_level | Actually perform overnight recovery | Coldwell inn | 135/84 | 16.3 s |
| 81 | I go downstairs and ask the innkeeper where I can find the Guild board or contract post in Coldwell. | Erzähler | open_run_level | Find the Guild hall to take new contracts | Coldwell inn | 135/84 | 16.0 s |
| 82 | I head to the Guild hall at the far corner of the square and look over the contract board. | Erzähler | open_run_level | Check Guild board for achievable contracts | Coldwell Guild hall, Coldwell | 135/84 | 32.9 s |
| 83 | "Morning, Maren. I'm heading back up to the gorse breaks to finish the boar cull — two more to go." I leave the hall and travel up past the … | Erzähler | open_run_level | Continue boar cull contract | the gorse breaks above the Coldwell Terraces vineyards | 135/84 | 25.6 s |
| 84 | I circle downwind to close the distance quietly, then strike first with Fan of Blades before the boar notices me. | Erzähler | open_run_level | Ambush the boar with AoE | the gorse breaks above the Coldwell Terraces vineyards | 135/84 | 16.6 s |
| 85 | I strike now with Fan of Blades at the boar broadside in the open. | Erzähler | open_run_level | Ambush the boar with AoE from stealth | the gorse breaks above the Coldwell Terraces vineyards | 135/84 | 20.4 s |
| 86 | I meet the charge and strike with Razor Cut at the wounded boar. | Erzähler | open_run_level | Finish the wounded boar | the gorse breaks above the Coldwell Terraces vineyards | 135/84 | 31.9 s |
| 87 | I strike with Razor Cut at the boar at arm's length. | Erzähler | open_run_level | Finish the wounded boar with Razor Cut at engaged range | the gorse breaks above the Coldwell Terraces vineyards | 135/84 | 24.8 s |
| 88 | I step in to close the last half-gap and strike with Razor Cut at the boar. | Erzähler | open_run_level | Close to ENGAGED and finish the boar | the gorse breaks above the Coldwell Terraces vineyards | 135/84 | 18.9 s |
| 89 | I skin what I can from the carcass quickly, then follow the second set of fresh prints deeper into the gorse to track down the third boar. | Erzähler | open_run_level | Harvest loot and hunt the third boar | boar den hollow in the gorse breaks | 135/84 | 34.4 s |
| 90 | I back off a few paces from the den mouth, then hurl a Fan of Blades into the entrance as the boar comes charging out. | Engine (Menü/Rückfrage) | open_run_level | Ambush the third boar at the den mouth with AoE | boar den hollow in the gorse breaks | 135/84 | 4.9 s |
| 91 | I hurl a stone into the den mouth and shout to drive the boar out, then attack it with Fan of Blades the moment it emerges. | Engine (Menü/Rückfrage) | open_run_level | Flush the third boar from the den, then hit it with AoE | boar den hollow in the gorse breaks | 135/84 | 5.0 s |
| 92 | I stand ready beside the den mouth and strike with Razor Cut at the boar inside the den entrance. | Engine (Menü/Rückfrage) | open_run_level | Attack the third boar now that it is located at the den mouth | boar den hollow in the gorse breaks | 135/84 | 4.4 s |
| 93 | I wait quietly at the den mouth, dagger ready, and give the boar time to come out on its own. | Erzähler | open_run_level | Wait for the boar to emerge so it becomes a targetable actor | boar den hollow in the gorse breaks | 135/84 | 15.9 s |
| 94 | I throw a Fan of Blades at the fleeing boar as it crosses the open hollow. | Erzähler | open_run_level | Hit the targetable boar with AoE during its escape | boar den hollow in the gorse breaks | 119/84 | 24.1 s |
| 95 | I strike with Razor Cut at the wounded boar. | Erzähler | open_run_level | Finish the boar with Razor Cut | boar den hollow in the gorse breaks | 119/84 | 20.8 s |
| 96 | I head back down to the Coldwell Terraces and, on reaching the Guildhall, turn in the completed boar cull contract for my reward. | Erzähler | open_run_level | Turn in the READY boar contract at the Guildhall | Coldwell Guild hall, Coldwell | 119/84 | 22.2 s |
| 97 | #assign AGI 3 PER 2 | System (Befehl) | open_run_level | Spend level-up stat points | Coldwell Guild hall, Coldwell | 119/84 | 2.5 s |
| 98 | I check the Guild board for available Novice contracts. | Erzähler | open_run_level | Pick the next contract from the board | Coldwell Guild hall, Coldwell | 119/84 | 38.3 s |
| 99 | I take the otterhound contract slip from the board and ask the clerk to register it for me. | Erzähler | open_run_level | Accept the otterhound thinning contract | Coldwell Guild hall, Coldwell | 119/84 | 15.9 s |
| 100 | I set out east along the terrace road to the mill fork and take the stream path toward Weir Crossing's gravel bars. | Erzähler | open_run_level | Travel to the otterhound hunting grounds | the gravel bars of the Weir Crossing shallows on the Glassmere stream | 119/84 | 21.1 s |
| 101 | I draw my dagger and close to striking range of the otterhound on the shallows, then attack it with Razor Cut. | Engine (Menü/Rückfrage) | open_run_level | Engage the nearer otterhound | the gravel bars of the Weir Crossing shallows on the Glassmere stream | 119/84 | 8.4 s |
| 102 | I lower my dagger, apologise to the fishers for the mistake, and hide near the far channel under the willows to ambush the otterhound when i… | Erzähler | open_run_level | Stop targeting the fishers and set up an ambush on the otterhound's route | the gravel bars of the Weir Crossing shallows on the Glassmere stream | 119/84 | 39.3 s |
| 103 | I move quietly into the willow thicket by the far channel and settle in to wait hidden for the otterhound. | Erzähler | open_run_level | Actually perform the hide/ambush action the engine marked NOT TAKEN | the gravel bars of the Weir Crossing shallows on the Glassmere stream | 119/84 | 19.2 s |
| 104 | I stay hidden in the willow thicket and wait for midday, watching the far channel for the otterhound. | Erzähler | open_run_level | Wait hidden for the otterhound's midday fishing run | the gravel bars of the Weir Crossing shallows on the Glassmere stream | 119/84 | 21.0 s |
| 105 | I stay hidden in the willows and keep watching, waiting for the fishers to leave so the otterhound comes down the channel. | Erzähler | open_run_level | Wait for fishers to depart, then ambush otterhound | the gravel bars of the Weir Crossing shallows on the Glassmere stream | 119/84 | 27.9 s |
| 106 | I burst from the willows and close on the drinking otterhound, striking with Razor Cut. | Erzähler | open_run_level | Ambush attack the otterhound | the gravel bars of the Weir Crossing shallows on the Glassmere stream | 119/84 | 23.8 s |
| 107 | I sprint across the thirty paces of open gravel toward the otterhound and attack it with Razor Cut the moment I reach it. | Erzähler | open_run_level | Close to ENGAGED range, then attack | the gravel bars of the Weir Crossing shallows on the Glassmere stream | 119/84 | 23.3 s |
| 108 | I throw Fan of Blades at the otterhound holding its ground in the shallows. | Erzähler | open_run_level | Use ranged AoE skill on the otterhound at LONG range | the gravel bars of the Weir Crossing shallows on the Glassmere stream | 119/84 | 17.8 s |
| 109 | I wade into the shallows toward the otterhound until I am at ENGAGED range, then strike it with Razor Cut. | Erzähler | open_run_level | Close into ENGAGED range and attack the otterhound | the gravel bars of the Weir Crossing shallows on the Glassmere stream | 119/84 | 31.6 s |
| 110 | I climb out of the water, withdraw to the willows, and hide again to wait for the otterhound to come back onto the gravel bar to fish. | Erzähler | open_run_level | Reset the failed wading approach and re-hide at the willows for another ambush chance | the gravel bars of the Weir Crossing shallows on the Glassmere stream | 119/84 | 29.1 s |
| 111 | I stay low and hold still, letting the otterhound come to me, and strike it with Razor Cut the moment it reaches ENGAGED range. | Erzähler | open_run_level | Let the advancing otterhound close into ENGAGED range, then attack | the gravel bars of the Weir Crossing shallows on the Glassmere stream | 119/84 | 35.1 s |
| 112 | I throw Fan of Blades at the otterhound standing thirty paces off on the far shallows. | Erzähler | open_run_level | Attack the otterhound at LONG range with the ranged skill | the gravel bars of the Weir Crossing shallows on the Glassmere stream | 119/84 | 19.2 s |
| 113 | I back out of the shallows and withdraw from the riverbank, giving up this standoff, then move along the stream to look for other otterhound… | Erzähler | open_run_level | Disengage from unreachable otterhound and find another target | dry turf shelf above the Weir Crossing stream | 119/84 | 28.2 s |
| 114 | I strike the otterhound at SHORT range with Razor Cut. | Erzähler | open_run_level | Attack the otterhound now within SHORT range | dry turf shelf above the Weir Crossing stream | 119/84 | 27.5 s |
| 115 | I close the last few paces into ENGAGED range and strike the otterhound with Razor Cut. | Erzähler | open_run_level | Close to ENGAGED on dry land and attack | dry turf shelf above the Weir Crossing stream | 119/84 | 20.0 s |
| 116 | I skin nothing further and instead move toward the thorn stand, staying alert for the heavy thing behind it, and engage the next otterhound … | Erzähler | open_run_level | Continue the otterhound contract toward 3 kills | the thorn stand and its den tunnel | 119/84 | 28.1 s |
| 117 | I strike Otterhound G with Razor Cut. | Erzähler | open_run_level | Attack the engaged otterhound | the thorn stand and its den tunnel | 119/84 | 14.6 s |
| 118 | I walk back to the Guild hall in Asterhall and turn in the otterhound contract at the counter. | Erzähler | open_run_level | Turn in the otterhound contract | Adventurers' Guild hall, Asterhall | 119/84 | 18.0 s |
| 119 | I take the slip back and head out of Asterhall toward Weir Crossing at first light, planning to hunt a third otterhound to complete the coun… | Erzähler | open_run_level | Hunt a third otterhound to fill the contract count | Adventurers' Guild hall, Asterhall | 119/84 | 24.5 s |
| 120 | I search the gravel bars and reed banks downstream of the weir for a third otterhound, staying alert. | Erzähler | open_run_level | Hunt the third otterhound to complete the contract count | the gravel bars of the Weir Crossing shallows on the Glassmere stream | 119/84 | 38.7 s |
| 121 | I follow the worn paw trail up the slope toward the thorn-stand lair, staying alert for the otterhound inside. | Erzähler | open_run_level | Find and kill the third otterhound at its lair | the gravel bars of the Weir Crossing shallows on the Glassmere stream | 119/84 | 17.7 s |
| 122 | I settle in downwind among the reeds by the gravel bars and wait for the third otterhound to return to the water. | Erzähler | open_run_level | Stake out the shallows for the third hound | the gravel bars of the Weir Crossing shallows on the Glassmere stream | 119/84 | 21.5 s |
| 123 | I strike the drinking otterhound with Razor Cut from the reeds. | Erzähler | open_run_level | Attack the third otterhound to complete the contract count | the gravel bars of the Weir Crossing shallows on the Glassmere stream | 119/84 | 16.3 s |
| 124 | I rise from the reeds and charge the otterhound to close into blade range, then strike it with Razor Cut. | Erzähler | open_run_level | Close to ENGAGED and attack the third otterhound | the gravel bars of the Weir Crossing shallows on the Glassmere stream | 119/84 | 14.6 s |
| 125 | I head back along the cart road to Weir Crossing, planning to sleep until morning and turn the contract in at the Guild hall once the count … | Erzähler | open_run_level | Return to Weir Crossing, rest, then turn in the completed otterhound contract | upstairs room at the crossing inn | 119/84 | 29.5 s |
| 126 | I sleep until morning in the inn room. | Erzähler | open_run_level | Recover overnight, then turn in the contract | upstairs room at the crossing inn | 140/84 | 14.0 s |
| 127 | I go down to the Guild hall and turn in the completed contract, Thin the Otterhounds at Weir Crossing. | Erzähler | open_run_level | Turn in the READY otterhound contract | Coldwell Guild hall, Coldwell | 140/84 | 19.3 s |
| 128 | #assign AGI 3 PER 2 | System (Befehl) | open_run_level | Spend the 5 free stat points from the level-up | Coldwell Guild hall, Coldwell | 140/84 | 2.7 s |
| 129 | I ask the clerk what contracts are on the fresh board. | Erzähler | open_run_level | Pick a new Guild contract from the board | Coldwell Guild hall, Coldwell | 140/84 | 23.5 s |
| 130 | I take the Ridgeback Boars in the Gorse Breaks contract from the board and ask the clerk to register it. | Erzähler | open_run_level | Accept the boar contract (recommended level 6, achievable) | Coldwell Guild hall, Coldwell | 140/84 | 14.3 s |
| 131 | I ask the clerk where the Coldwell Terraces watch huts are, then head north out of town toward the gorse breaks above the vineyards. | Erzähler | open_run_level | Travel to the boar hunting ground | the gorse breaks above the Coldwell Terraces vineyards | 140/84 | 21.6 s |
| 132 | I follow the churned mud trail uphill into the gorse, moving quietly and staying alert for the boar. | Erzähler | open_run_level | Hunt the first ridgeback boar | boar-torn clearing in the gorse | 140/84 | 20.5 s |
| 133 | I open with Fan of Blades on the two sows in the root pit, then fall back toward the gorse groove to avoid fighting all three at once. | Erzähler | open_run_level | Engage the boars with AoE from a safe angle | boar-torn clearing in the gorse | 140/84 | 18.5 s |
| 134 | I retreat two strides back into the gorse groove's mouth, then circle quietly along its edge to close to SHORT range on the nearest sow befo… | Erzähler | open_run_level | Close distance and engage with AoE from cover | boar-torn clearing in the gorse | 140/84 | 22.4 s |
| 135 | I step out of the groove and walk straight toward the nearest sow, closing the distance to SHORT range. | Erzähler | open_run_level | Declare movement to close into Fan of Blades range | boar-torn clearing in the gorse | 140/84 | 16.1 s |
| 136 | I cast Fan of Blades at the two sows in front of me. | Erzähler | open_run_level | Engage the two sows at SHORT range with AoE | boar-torn clearing in the gorse | 110/84 | 17.9 s |
| 137 | I use Razor Cut on Ridgeback Boar F to finish the badly wounded sow. | Erzähler | open_run_level | Kill the weakest boar first | boar-torn clearing in the gorse | 76/84 | 16.9 s |
| 138 | I use Razor Cut on Ridgeback Boar G to finish the rib-wounded sow. | Erzähler | open_run_level | Kill the weakest boar next to reduce incoming damage | boar-torn clearing in the gorse | 58/84 | 15.4 s |
| 139 | I use Razor Cut on Ridgeback Boar H, aiming for its head as it charges. | Erzähler | open_run_level | Finish the last boar | boar-torn clearing in the gorse | 43/84 | 14.4 s |
| 140 | I use Razor Cut on Ridgeback Boar H to finish her. | Erzähler | open_run_level | Kill the last boar | boar-torn clearing in the gorse | 43/84 | 16.5 s |
| 141 | I head back toward Coldwell, keeping an eye out for the unseen big boar's trail but not hunting it in my wounded state. | Erzähler | open_run_level | Return to town to heal and turn in the 3/4 boar contract | Coldwell | 43/84 | 25.5 s |
| 142 | I go to the Guild post and turn in the Ridgeback Boars contract. | Erzähler | open_run_level | Turn in the boar contract at the Guild post | Coldwell Guild hall, Coldwell | 43/84 | 17.7 s |
| 143 | I go to the inn, take a room and a meal, and ask the innkeeper what the carters said about the big boar in the gorse breaks. | Erzähler | open_run_level | Recover overnight and gather info on the fourth boar | Coldwell inn | 43/84 | 22.7 s |
| 144 | I sit on the bench by the fire and tell the innkeeper what I need: a room for the night, a hot meal, and whatever the carters know about the… | Erzähler | open_run_level | Secure room, meal, and boar info at the inn | Coldwell inn | 43/84 | 27.2 s |
| 145 | I accept the room and meal for twenty copper and pay the innkeeper. | Erzähler | open_run_level | Buy lodging and meal at the confirmed offer | Coldwell inn | 43/84 | 18.0 s |
| 146 | I eat the stew, then go to the end room, lock the door and sleep until morning. | Erzähler | open_run_level | Recover overnight | Coldwell inn | 145/84 | 42.2 s |
| 147 | I head out of the inn and follow Doss's line northeast into the gorse breaks to hunt the fourth big boar. | Erzähler | open_run_level | Hunt the fourth boar | the gorse breaks above the Coldwell Terraces vineyards | 145/84 | 22.2 s |
| 148 | I stalk quietly uphill toward the wallow, keeping downwind, and get in position to strike the big boar from behind with Fan of Blades. | Erzähler | open_run_level | Ambush the fourth boar at the wallow | the gorse breaks above the Coldwell Terraces vineyards | 145/84 | 24.2 s |
| 149 | I throw my dagger at the boar in the wallow, aiming for the base of the skull, then close in with Fan of Blades if it rises. | Engine (Menü/Rückfrage) | open_run_level | Ambush attack the fourth boar | the gorse breaks above the Coldwell Terraces vineyards | 145/84 | 4.9 s |
| 150 | I use Fan of Blades on the boar in the wallow, aiming for the base of the skull. | Engine (Menü/Rückfrage) | open_run_level | Attack the fourth big boar with Fan of Blades | the gorse breaks above the Coldwell Terraces vineyards | 145/84 | 4.3 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 2 (notiert vor Zug 3): Creation complete: Level 1 Rogue with Fan of Blades and Razor Cut, starter gear equipped, 5 silver.
- zu Zug 35 (notiert vor Zug 36): HP 38/120 badly wounded; clerk advised treatment and no contracts tonight. Also carrying 4 pelts and 9 fangs as potential surplus loot to sell.
- zu Zug 36 (notiert vor Zug 37): Purchase completed but reading gave 'no material'; skill not learned despite owning the primer.
- zu Zug 40 (notiert vor Zug 41): Engine refused the earlier sleep as 'arrival pending'; narration described sleep but HUD still shows HP 38/120, so recovery unconfirmed.
- zu Zug 41 (notiert vor Zug 42): Narration has described sleeping twice but HUD still shows HP 38/120 and time 19:25 — engine sleep not yet confirmed.
- zu Zug 42 (notiert vor Zug 43): Sleep finally confirmed via RECOVERY result (HP 120/120). Narration had described sleep twice before the engine accepted it.
- zu Zug 46 (notiert vor Zug 47): Basic Attack refused 'the stranglewillow sprout' as invalid target even though the HUD sign describes it standing at the water's edge — likely it must fully surface or be named differently.
- zu Zug 47 (notiert vor Zug 48): Two attacks refused because the sprout is still submerged; the tanner said it surfaces evenings when hides are washed.
- zu Zug 49 (notiert vor Zug 50): Combat range matters: Razor Cut refused at SHORT without declared movement; must explicitly close the ten feet of mud.
- zu Zug 50 (notiert vor Zug 51): Ambush opening gave an instant crit kill on the surfaced sprout; quest now READY for turn-in.
- zu Zug 55 (notiert vor Zug 56): Two otterhounds present though contract needs 1; range SHORT, thirty paces of open gravel.
- zu Zug 64 (notiert vor Zug 65): Contradiction: ENGINE RESULT already paid 150 cp and filed the slip, but the clerk now claims the contract is unclosed; trying to reconcile before taking a new job.
- zu Zug 65 (notiert vor Zug 66): Otterhound contract now confirmed closed in the ledger; clerk's earlier 'open' claim was her error.
- zu Zug 79 (notiert vor Zug 80): Narration described sleeping until dawn, but HUD still shows Day 2, 23:03 with HP 82/135 — treating the System as authoritative and repeating the sleep explicitly.
- zu Zug 81 (notiert vor Zug 82): Boar cull shows 1/3 on the quest tracker despite the kill last night—may need confirmation or the count wasn't recorded.
- zu Zug 86 (notiert vor Zug 87): Razor Cut was refused at SHORT last turn; boar's charge has now closed it to ENGAGED, so the same attack is valid.
- zu Zug 87 (notiert vor Zug 88): Engine treats arm's-length as SHORT; Razor Cut needs an explicitly declared move to ENGAGED.
- zu Zug 90 (notiert vor Zug 91): Fan of Blades was refused because the boar was still inside the den and not a targetable actor; nothing was spent.
- zu Zug 91 (notiert vor Zug 92): Fan of Blades refused twice because the boar was not yet a targetable actor; narration confirms breathing inside the den.
- zu Zug 92 (notiert vor Zug 93): Three attack attempts refused: the third boar is never a targetable actor even when narration says it's charging out; scene seems to lack the actor entirely.
- zu Zug 97 (notiert vor Zug 98): Level 7 confirmed; gear check pending with 4g9s6c on hand.
- zu Zug 101 (notiert vor Zug 102): The 'otterhound on the shallows' I attacked was actually a fisher — no otterhounds currently present; signs say they come down the far channel at midday or at dusk and avoid the bar while people are present.
- zu Zug 102 (notiert vor Zug 103): Stealth check succeeded but the hide action itself was not resolved; time is already 14:21, past the midday window.
- zu Zug 107 (notiert vor Zug 108): Movement declarations in sprint didn't register as closing to ENGAGED; ranged skill needed for LONG.
- zu Zug 108 (notiert vor Zug 109): Movement must be a separate declared closing action; ranged skills both failed at LONG range.
- zu Zug 109 (notiert vor Zug 110): Otterhound holds the deep channel where wading cannot close to ENGAGED; two failed closing attempts so far.
- zu Zug 110 (notiert vor Zug 111): Stealth check failed because hiding and moving were combined in one message; engine resolves one action type per message.
- zu Zug 111 (notiert vor Zug 112): Ranged skills previously failed at LONG range; trying Fan of Blades again now the hound is stationary on the bar.
- zu Zug 112 (notiert vor Zug 113): Fan of Blades confirmed SHORT range only; deep channel makes ENGAGED closing impossible, so this hound is a persistent blocker.
- zu Zug 113 (notiert vor Zug 114): HUD now lists Otterhound F as SHORT present on the turf shelf, contradicting the withdrawn standoff.
- zu Zug 114 (notiert vor Zug 115): Prior wading closure failed in water; on turf the hound is SHORT, so a declared closing action may finally bridge to ENGAGED.
- zu Zug 116 (notiert vor Zug 117): Contract shows 1/3 defeated; need two more kills.
- zu Zug 117 (notiert vor Zug 118): Engine shows 2/3 defeated despite three hounds killed (river hound, F, G) — will check at turn-in.
- zu Zug 118 (notiert vor Zug 119): Engine counts only 2/3 despite three kills seen; the first river hound may not have registered. Will confirm count on next kill.
- zu Zug 120 (notiert vor Zug 121): Search action was refused as 'arrival pending' at night; the lair sign behind the thorn stand points to the third hound.
- zu Zug 121 (notiert vor Zug 122): Search was refused earlier only for 'arrival pending'; arrival is now confirmed at the gravel bars. The lair lies on the slope outside the contract's habitat scope, so I hunt within the shallows instead.
- zu Zug 124 (notiert vor Zug 125): Third kill registered: contract now 3/3 and READY for turn-in. Engine counted the ambush kill but earlier narration of a first hound apparently never counted.
- zu Zug 133 (notiert vor Zug 134): Fan of Blades failed: SHORT range only, boars at LONG; engine requires declared movement to close range.
- zu Zug 134 (notiert vor Zug 135): Engine enforces one move per turn; movement must be declared alone before attacking.
- zu Zug 138 (notiert vor Zug 139): HP down to 58; boar H is fresh and hits hard—recovery needed after this fight.
- zu Zug 143 (notiert vor Zug 144): Arrival-pending refused buys; retry now that I'm inside the inn.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t10 | 10 | 1 | – | ja | 1 | gewonnen, 24 XP |
| enc.t18 | 18 | 1 | – | ja | 1 | gewonnen, 144 XP |
| enc.t24 | 25 | 1 | – | nein | 1 | gewonnen, 168 XP |
| enc.t28 | 30 | 2 | – | nein | 2 | gewonnen, 240 XP |
| enc.t45 | 50 | 1 | – | nein | 1 | gewonnen, 24 XP |
| enc.t55 | 61 | 1 | – | ja | 1 | gewonnen, 96 XP |
| enc.t66 | 73 | 1 | – | nein | 1 | gewonnen, 152 XP |
| enc.t77 | 85 | 1 | – | ja | 1 | gewonnen, 152 XP |
| enc.t83 | 94 | 1 | – | nein | 1 | gewonnen, 124 XP |
| enc.t102 | 115 | 1 | – | nein | 1 | gewonnen, 120 XP |
| enc.t104 | 117 | 1 | – | nein | 1 | gewonnen, 116 XP |
| enc.t111 | 124 | 1 | – | nein | 1 | gewonnen, 120 XP |
| enc.t122 | 136 | 3 | – | nein | 3 | gewonnen, 350 XP |

## Quests

- **Thin the Stranglewillow Sprouts** — active (Zug 6) → completed (Zug 11)
  - Aufgabe: Kill 1 stranglewillow sprout at the tanner's outflow ditch below Tanners' Row, Glassmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 stranglewillow sprout killed at the tanner's outflow ditch below Tanners' Row, Glassmere.
- **Cull the Gravel-Bar Otterhounds** — active (Zug 13) → completed (Zug 34)
  - Aufgabe: Kill 4 otterhounds at the gravel bars of the Weir Crossing shallows on the Glassmere stream. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 otterhounds killed at the gravel bars of the Weir Crossing shallows on the Glassmere stream.
- **Cull the Ridgeback Boars** — expired (Zug 43)
  - Aufgabe: Kill 5 ridgeback boars at the gorse breaks above the Coldwell Terraces vineyards. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 5 ridgeback boars killed at the gorse breaks above the Coldwell Terraces vineyards.
- **Cull the Hollowfen Marsh Cats** — expired (Zug 43)
  - Aufgabe: Kill 3 marsh cats at the deep reed beds of Hollowfen, south of Glassmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 marsh cats killed at the deep reed beds of Hollowfen, south of Glassmere.
- **Clear Glimmerdeep Grotto Level 1** — expired (Zug 43), Dungeon loc.glimmerdeep_grotto Ebene 1
  - Aufgabe: Clear level 1 of Glimmerdeep Grotto. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Glimmerdeep Grotto is clear.
- **Pull the Stranglewillow Sprout from the Tanner's Ditch** — active (Zug 44) → completed (Zug 52), READY
  - Aufgabe: Kill 1 stranglewillow sprout at the tanner's outflow ditch below Tanners' Row, Glassmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 stranglewillow sprout killed at the tanner's outflow ditch below Tanners' Row, Glassmere.
- **Rid the Weir Crossing of the Otterhound** — active (Zug 54) → completed (Zug 63)
  - Aufgabe: Kill 1 otterhound at the gravel bars of the Weir Crossing shallows on the Glassmere stream. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 otterhound killed at the gravel bars of the Weir Crossing shallows on the Glassmere stream.
- **Cull the Ridgeback Boars in the Gorse Breaks** — active (Zug 66) → completed (Zug 96)
  - Aufgabe: Kill 3 ridgeback boar at the gorse breaks above the Coldwell Terraces vineyards. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 ridgeback boar killed at the gorse breaks above the Coldwell Terraces vineyards.
- **Cull the Stranglewillow Sprout in the Tanner's Outflow Ditch** — expired (Zug 129)
  - Aufgabe: Kill 1 stranglewillow sprout at the tanner's outflow ditch below Tanners' Row. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 stranglewillow sprout killed at the tanner's outflow ditch below Tanners' Row.
- **Thin the Otterhounds at Weir Crossing** — active (Zug 99) → completed (Zug 127), READY
  - Aufgabe: Kill 3 otterhound at the gravel bars of the Weir Crossing shallows on the Glassmere stream. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 otterhound killed at the gravel bars of the Weir Crossing shallows on the Glassmere stream.
- **Cull the Ridgeback Boars Above the Terraces** — expired (Zug 129)
  - Aufgabe: Kill 4 ridgeback boar at the gorse breaks above the Coldwell Terraces vineyards. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 ridgeback boar killed at the gorse breaks above the Coldwell Terraces vineyards.
- **Hunt the Marsh Cat of Hollowfen** — expired (Zug 129)
  - Aufgabe: Kill 1 marsh cat at the deep reed beds of Hollowfen, south of Glassmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 marsh cat killed at the deep reed beds of Hollowfen, south of Glassmere.
- **Slay the Pale Stag of the Burnt Pines** — expired (Zug 129)
  - Aufgabe: Kill 1 pale stag at the burnt pines north of Coldwell. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 pale stag killed at the burnt pines north of Coldwell.
- **Ridgeback Boars in the Gorse Breaks** — active (Zug 130)
  - Aufgabe: Kill 4 ridgeback boar at the gorse breaks above the Coldwell Terraces vineyards. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 ridgeback boar killed at the gorse breaks above the Coldwell Terraces vineyards.

## Auffälligkeiten

- Zug 6, Nachricht 12 (extraction_repaired): the extractor's first answer needed a repair
- Zug 40, Nachricht 79 (planner_repaired): the planner's first answer needed a repair
- Zug 46, Nachricht 91 (planner_repaired): the planner's first answer needed a repair
- Zug 52, Nachricht 104 (extraction_repaired): the extractor's first answer needed a repair
- Zug 57, Nachricht 113 (planner_repaired): the planner's first answer needed a repair
- Zug 68, Nachricht 136 (extraction_repaired): the extractor's first answer needed a repair
- Zug 69, Nachricht 137 (planner_repaired): the planner's first answer needed a repair
- Zug 77, Nachricht 154 (extraction_repaired): the extractor's first answer needed a repair
- Zug 89, Nachricht 178 (extraction_repaired): the extractor's first answer needed a repair
- Zug 101, Nachricht 201 (planner_repaired): the planner's first answer needed a repair
- Zug 107, Nachricht 214 (extraction_repaired): the extractor's first answer needed a repair
- Zug 125, Nachricht 250 (extraction_repaired): the extractor's first answer needed a repair
- Zug 131, Nachricht 262 (extraction_repaired): the extractor's first answer needed a repair
- Zug 141, Nachricht 282 (extraction_repaired): the extractor's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 39× keine gültige JSON-Entscheidung (Züge 1, 2, 9, 10, 15, 16, 18, 25, 27, 30, 36, 38, 43, 46, 49, 57, 59, 60, 62, 70, 76, 83, 84, 85, 86, 90, 99, 105, 109, 110, 113, 116, 118, 120, 123, 124, 132, 133, 134)

System-Panels: CLARIFY 1, NOT TAKEN 9, REFUSED 2, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: engine_owned_fact 13, guild_canon 2, attack_commitment 4, world_rule 15, guild_completion 1, offer 2, time_cap 4, recover 2, sale_evidence 2, engine_recovery 2, ambient 9, guild_payout 3, no_go 9, scene_context 16, engine_owned_memory 2, quest_count 3, group_unclear 2.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 39/150 Erstantworten ungültig (26.0 %); 39 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 146 | 5 | 2.4 s | 4.7 s | 12309 | 9963 | 78 | – | stop 146 | 0 |
| board | 4 | 0 | 13.4 s | 17.2 s | 2507 | 2291 | 1057 | – | stop 4 | 0 |
| narrator | 132 | 0 | 7.9 s | 14.4 s | 11346 | 8764 | 367 | – | stop 132 | 0 |
| extract | 141 | 9 | 5.4 s | 10.8 s | 12756 | 9734 | 318 | – | stop 141 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 60:53 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 14.3 s) | 0:28 min |
| 150 Züge, Spiel (Senden bis HUD nach der Extraktion) | 49:49 min — Median 19.8 s, p90 31.8 s, max 42.2 s |
| 150 Züge, Spieler-Entscheidung | 7:55 min — Median 2.5 s, 39 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 7:07 min / 0:53 min / 20:49 min / 14:51 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 23.1 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 15:24 min, 80 Züge ≈ 30:47 min (ohne Einrichtung) |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
