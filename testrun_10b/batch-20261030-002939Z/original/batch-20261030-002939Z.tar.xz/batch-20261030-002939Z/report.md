# Avereth – 3 natürliche Testkampagnen

Status: **completed**. Serie abgeschlossen bedeutet, dass die Läufe beendet sind; es bedeutet nicht 3 bestandene Level-15-Abnahmen.

| Nr. | Profil | Seed | Eingaben | Level | Ende | Originalbericht |
|---|---|---:|---:|---:|---|---|
| 1 | guild-warrior | 2009264424 | 29 | 1 | defeat | [report.md](001-guild-warrior/20261030-002940Z-current_test/report.md) |
| 2 | guild-mage | 2009264425 | 150 | 9 | limit | [report.md](002-guild-mage/20261030-004256Z-current_test/report.md) |
| 3 | guild-rogue | 2009264426 | 150 | 8 | limit | [report.md](003-guild-rogue/20261030-014642Z-current_test/report.md) |

