# Avereth Live-Test 20261030-040259Z-current_test

## Kurzfassung

- **Laufprofil:** guild-warrior; Startklasse Warrior, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** abgeschlossen: alle Pflicht-Etappen erreicht
- **Etappen:** 2/2 Pflicht erreicht
- **Progressionsziel:** Level 15; tatsächlich Level 15. Sicherheitsgrenzen: 200 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** Level 9, 65 XP seit Levelaufstieg, 132 cp, HP 245, MP 84; Ort realm.valedorn_crown.the_timber_wharves_of_crownheart. Ausrüstung und Skills stehen in evaluation.json → progression.checkpoint.
- **Charakter:** warrior (warrior.guard, warrior.cleave) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: cautious adventurer: prepare and recover, weigh threats and withdraw when sensible
- **Züge:** 168 · **Dauer:** 63:27 min · **LLM-Aufrufe der Engine/des Erzählers:** 471
- **Beobachtete Abdeckung:** 28 unterschiedliche gebuchte Reiseziele · 15 Kämpfe · 1 Verkäufe (68 cp Umsatz, ohne Questzahlungen/Geschenke) · 2 Ausrüstungswechsel · 0 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 28
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.122 |
| Git | 013e0dca9e7b (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 13.8 s |
| Browser | chrome 156.0.8078.49 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261030-040259Z-current_test“, Seed 1040509681 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | ✔ | 168 | 336 |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | I choose Warrior. | Engine (Menü/Rückfrage) | creation_complete | Select base class | public roadside verge outside Alderwatch | 90/84 | 2.3 s |
| 2 | I select Cleave and Guard as my two skills. | Engine (Menü/Rückfrage) | creation_complete | Complete Warrior creation with mandatory Cleave plus Guard | public roadside verge outside Alderwatch | 95/84 | 2.2 s |
| 3 | I walk to Alderwatch's city gate and enter the city, looking for the Adventurers' Guild hall. | Erzähler | open_run_level | Enter city and find Guild board for first contract | Adventurers' Guild hall, Alderwatch | 95/84 | 18.0 s |
| 4 | I approach the clerk and ask to register with the Guild as a new adventurer. | Erzähler | open_run_level | Register at Guild so contracts can be accepted | Adventurers' Guild hall, Alderwatch | 95/84 | 13.8 s |
| 5 | I pay the two silver, sign the ledger, and place my hand on the stone to have my Power read. | Erzähler | open_run_level | Register with the Guild and get Power read | Adventurers' Guild hall, Alderwatch | 95/84 | 18.8 s |
| 6 | I go to the contract board and read the Novice contracts. | Erzähler | open_run_level | Find a first achievable contract | Adventurers' Guild hall, Alderwatch | 95/84 | 35.2 s |
| 7 | I approach the two men with the map and ask if they're hiring an extra pair of hands. | Erzähler | open_run_level | Find private work since Novice board is empty | Adventurers' Guild hall, Alderwatch | 95/84 | 26.7 s |
| 8 | "Yes, I'll take the job. I'll be at the east cartyard before first light tomorrow." | Erzähler | open_run_level | Accept the freight run as fifth set of eyes | Adventurers' Guild hall, Alderwatch | 95/84 | 19.6 s |
| 9 | Before he leaves, I ask Ellwin for the half payment he offered up front. | Erzähler | open_run_level | Take the offered half advance | Adventurers' Guild hall, Alderwatch | 95/84 | 16.1 s |
| 10 | I leave the Guild hall and look for a blacksmith or armourer's shop in Alderwatch. | Erzähler | open_run_level | Warrior gear check before tomorrow's freight run | Forge with the horseshoe-and-hammer sign | 95/84 | 20.0 s |
| 11 | I ask the armourer woman for her prices on the heavier breastplates and a better longsword, and what she'd offer for comparing them against … | Erzähler | open_run_level | Get concrete weapon and armour upgrade offers at the forge | Forge with the horseshoe-and-hammer sign | 95/84 | 17.4 s |
| 12 | I tell her I can't afford any of it today, but I'll remember her prices, and I leave the forge. | Erzähler | open_run_level | Note offers checked, resume seeking work | Alderwatch | 95/84 | 16.7 s |
| 13 | I return to the Guild hall and check the Novice contract board for any new postings. | Erzähler | open_run_level | Check the Guild board again for contracts | Adventurers' Guild hall, Alderwatch | 95/84 | 33.0 s |
| 14 | I take the Thin the Barrowfield Wolves notice to the clerk and ask her to book it for me. | Erzähler | open_run_level | Accept the five-wolf contract for 150 copper | Adventurers' Guild hall, Alderwatch | 95/84 | 15.3 s |
| 15 | I head out the west road toward the Barrowfield bramble, following the sheep tracks west. | Erzähler | open_run_level | Travel to the wolf hunt grounds | the Barrowfield bramble | 95/84 | 27.3 s |
| 16 | I draw my longsword and follow the wolf tunnel into the bramble, moving cautiously. | Erzähler | open_run_level | Hunt the wolves in the bramble | wolf tunnel in the bramble | 95/84 | 19.5 s |
| 17 | I set my stance and swing Cleave at the near wolf as it springs, cutting through both if they close together. | Erzähler | open_run_level | Fight the wolves with Cleave | wolf tunnel in the bramble | 95/84 | 14.6 s |
| 18 | I strike at the near wolf at my right with my longsword. | Erzähler | open_run_level | Attack the engaged wolf | wolf tunnel in the bramble | 74/84 | 17.6 s |
| 19 | I swing my longsword again at the wounded grey wolf, finishing it if I can. | Erzähler | open_run_level | Kill the engaged Wolf A | wolf tunnel in the bramble | 74/84 | 15.3 s |
| 20 | #assign STR 3 VIT 2 | System (Befehl) | open_run_level | Spend level-up stat points | wolf tunnel in the bramble | 74/84 | 2.1 s |
| 21 | I press deeper into the bramble toward where the claw-clicks came from, sword ready, hunting more wolves. | Erzähler | open_run_level | Continue wolf hunt toward the 5-wolf contract | wolf tunnel in the bramble | 74/84 | 16.7 s |
| 22 | I turn to face the shape in the green to my left and swing Cleave as it springs, catching both wolves if they are in reach. | Engine (Menü/Rückfrage) | open_run_level | Fight the den ambush with Cleave | wolf tunnel in the bramble | 74/84 | 5.1 s |
| 23 | I hold my ground, sword raised, watching the green to my left and listening for the wolves' next move. | Erzähler | open_run_level | Wait for wolves to become targetable | wolf tunnel in the bramble | 74/84 | 16.5 s |
| 24 | I swing Cleave at the springing Wolf C, catching Wolf D too if it is in reach. | Erzähler | open_run_level | Attack both ambush wolves with Cleave | wolf tunnel in the bramble | 32/84 | 16.5 s |
| 25 | I swing Cleave at both wolves, hoping to finish the wounded Wolf C and wound Wolf D. | Erzähler | open_run_level | Finish Wolf C and damage Wolf D with Cleave | wolf tunnel in the bramble | 21/84 | 19.4 s |
| 26 | I swing Cleave at the wounded Wolf D to finish it. | Erzähler | open_run_level | Defeat Wolf D with Cleave | wolf tunnel in the bramble | 21/84 | 17.2 s |
| 27 | #passives | System (Befehl) | open_run_level | Accept Wolfbitten Resolve passive | wolf tunnel in the bramble | 21/84 | 2.1 s |
| 28 | #passives | System (Befehl) | open_run_level | Accept Wolfbitten Resolve | wolf tunnel in the bramble | 21/84 | 2.2 s |
| 29 | I accept Wolfbitten Resolve into a free passive slot. | Erzähler | open_run_level | Accept offered passive | wolf tunnel in the bramble | 21/84 | 12.5 s |
| 30 | #assign VIT 5 STR 5 | System (Befehl) | open_run_level | Spend free stat points before recovering | wolf tunnel in the bramble | 21/84 | 2.2 s |
| 31 | I sheathe my sword and head back out of the bramble toward Valedorn to rest and recover before hunting the remaining wolves. | Erzähler | open_run_level | Return to town to recover from badly wounded state | gate queue before the walls of Valedorn | 21/84 | 24.4 s |
| 32 | I approach the gate guard and enter the city, then find an inn to rest until I recover. | Erzähler | open_run_level | Enter Valedorn and sleep to recover HP | The Wethered Ewe | 21/84 | 29.9 s |
| 33 | I accept the room, bath and supper and pay the innkeeper's price, then take the bath and rest for the evening. | Erzähler | open_run_level | Pay for lodging and recover | The Wethered Ewe | 21/84 | 21.3 s |
| 34 | I take the bath, eat supper and then sleep through the night in my room. | Erzähler | open_run_level | Book and use the paid room to recover HP | The Wethered Ewe | 21/84 | 17.2 s |
| 35 | I accept Marta's prices: a bath for 2 copper and a clean towel for 1 copper, and pay her the 3 copper, then take the bath. | Engine (Menü/Rückfrage) | open_run_level | Buy and take the bath at the confirmed price | The Wethered Ewe | 21/84 | 11.4 s |
| 36 | I accept bath and towel together for 3 cp, and pay Marta the 3 copper. | Engine (Menü/Rückfrage) | open_run_level | Buy bath and towel at confirmed offer | The Wethered Ewe | 21/84 | 7.8 s |
| 37 | Book them as two lines totalling 3 cp, and pay Marta the 3 copper. | Engine (Menü/Rückfrage) | open_run_level | Buy bath and towel as two lines | The Wethered Ewe | 21/84 | 6.9 s |
| 38 | Bath + clean towel. | Erzähler | open_run_level | Confirm the two purchase lines and pay | The Wethered Ewe | 21/84 | 18.3 s |
| 39 | I buy a supper plate for 3 copper and eat it. | Erzähler | open_run_level | Recover HP via meal, then see the healer | The Wethered Ewe | 21/84 | 19.7 s |
| 40 | I ask Marta if I can take a room for the night and what it costs. | Erzähler | open_run_level | Book lodging to sleep and recover HP | The Wethered Ewe | 21/84 | 23.5 s |
| 41 | I pay Marta 4 copper for the room for the night and go up to sleep until morning. | Erzähler | open_run_level | Book lodging and sleep to recover HP | The Wethered Ewe | 160/84 | 17.8 s |
| 42 | I buy the breakfast for 1 copper and eat it. | Erzähler | open_run_level | Recover/stock up, then find a smith for gear check | The Wethered Ewe | 160/84 | 16.2 s |
| 43 | I eat the breakfast Marta set down. | Erzähler | open_run_level | Eat purchased breakfast | The Wethered Ewe | 160/84 | 14.7 s |
| 44 | I leave the inn and head back to the Barrowfield to hunt the two wolves I still need for the contract. | Erzähler | open_run_level | Finish wolf contract 3/5 | the Barrowfield bramble | 160/84 | 16.3 s |
| 45 | I take the main track toward the near mounds and search the thorn hedges for wolves. | Erzähler | open_run_level | Hunt the two remaining wolves for the contract | the near mounds | 160/84 | 15.4 s |
| 46 | I draw my sword and move carefully toward the bramble tunnel to the right, watching for the wolves I heard. | Erzähler | open_run_level | Engage the remaining wolves for the contract | bramble tunnel to the right | 160/84 | 18.9 s |
| 47 | I follow the climbing arm toward the rooting sound, sword ready, keeping my eyes open for a second wolf. | Erzähler | open_run_level | Engage the remaining wolves for the contract | saddle bowl between the near mounds | 160/84 | 19.1 s |
| 48 | I use Cleave on the feeding wolf before it can turn on me fully. | Erzähler | open_run_level | Strike first on Wolf E for the contract | saddle bowl between the near mounds | 160/84 | 13.9 s |
| 49 | I close the distance to engage Wolf E and attack it with my sword. | Erzähler | open_run_level | Engage and strike Wolf E | saddle bowl between the near mounds | 150/84 | 14.3 s |
| 50 | I finish Wolf E with a Basic Attack. | Erzähler | open_run_level | Kill Wolf E for the contract | saddle bowl between the near mounds | 150/84 | 16.7 s |
| 51 | #assign STR 3 VIT 2 | System (Befehl) | open_run_level | Spend level-up points | saddle bowl between the near mounds | 150/84 | 2.2 s |
| 52 | I follow the rooting sound along the climbing arm toward the gap, sword ready for the fifth wolf. | Erzähler | open_run_level | Track and engage the fifth wolf | gap where the climbing arm crests the saddle | 150/84 | 19.9 s |
| 53 | I strike the unaware Wolf F with a Cleave from behind. | Erzähler | open_run_level | Open the fight on Wolf F with Cleave | gap where the climbing arm crests the saddle | 150/84 | 15.2 s |
| 54 | I creep the last ten feet and strike Wolf F with Cleave the moment it is in reach. | Erzähler | open_run_level | Close to melee range, then Cleave the unaware wolf | gap where the climbing arm crests the saddle | 150/84 | 18.4 s |
| 55 | I step the final stride into reach and strike Wolf F with Cleave. | Erzähler | open_run_level | Close into melee range and Cleave the now-engaged wolf | gap where the climbing arm crests the saddle | 150/84 | 14.5 s |
| 56 | #assign STR 3 VIT 2 | System (Befehl) | open_run_level | Spend level-up points | gap where the climbing arm crests the saddle | 150/84 | 2.2 s |
| 57 | I head back down the bramble arm toward town to turn in the wolf contract at the Guild hall. | Erzähler | open_run_level | Return to Guild for turn-in | Adventurers' Guild hall, Alderwatch | 150/84 | 17.0 s |
| 58 | #assign STR 3 VIT 2 | System (Befehl) | open_run_level | Spend the new level-up points | Adventurers' Guild hall, Alderwatch | 150/84 | 2.2 s |
| 59 | I head to the blacksmith's shop in Alderwatch and ask the smith for weapon and armour upgrade offers to compare against my starter gear. | Erzähler | open_run_level | Warrior gear trial at the smith | Forge with the horseshoe-and-hammer sign | 150/84 | 19.1 s |
| 60 | I'll take the Superior Longsword and the Fine Plate Armor. I pay the 9 silver and put on the armor and new sword before leaving. |  | open_run_level | Buy and equip weapon and armour upgrades | Forge with the horseshoe-and-hammer sign | 150/84 | 7.5 s |
| 61 | I buy the Superior Longsword for 6 silver from the smith and pay the armourer 3 silver for the Fine Plate Armor, then equip both. | Erzähler | open_run_level | Complete gear purchase after planner failure | Forge with the horseshoe-and-hammer sign | 150/84 | 22.6 s |
| 62 | I head to the Guild hall and turn in the wolf contract, presenting the pelts and fangs. | Erzähler | open_run_level | Turn in the completed wolf contract | Adventurers' Guild hall, Alderwatch | 150/84 | 19.6 s |
| 63 | I sell the surplus pelts and fangs to the clerk at the brokerage price. | Erzähler | open_run_level | Sell surplus loot at Guild counter | Adventurers' Guild hall, Alderwatch | 150/84 | 12.3 s |
| 64 | I accept the offer and sell the whole lot for four silver. | Engine (Menü/Rückfrage) | open_run_level | Complete brokerage sale | Adventurers' Guild hall, Alderwatch | 150/84 | 11.0 s |
| 65 | I sell to the Guild clerk: five F-Rank Wolf Pelts and nine F-Rank Wolf Fangs at her brokerage price of four silver total. |  | open_run_level | Clarify and complete the brokerage sale | Adventurers' Guild hall, Alderwatch | 150/84 | 7.9 s |
| 66 | I sell five F-Rank Wolf Pelts and nine F-Rank Wolf Fangs to the Guild clerk for 40 copper total. | Erzähler | open_run_level | Complete brokerage sale with simple wording | Adventurers' Guild hall, Alderwatch | 150/84 | 27.1 s |
| 67 | I take five F-Rank Wolf Pelts and nine F-Rank Wolf Fangs from my pack, lay them on the counter, and ask the clerk to buy them at two copper … | Erzähler | open_run_level | Place loot on counter and complete brokerage sale | Adventurers' Guild hall, Alderwatch | 150/84 | 20.6 s |
| 68 | I ask the clerk about the Guild contract board — what F-Rank contracts are open today? | Erzähler | open_run_level | Pick a new Guild contract | Adventurers' Guild hall, Alderwatch | 150/84 | 28.1 s |
| 69 | I accept the Marsh Adder contract at the Reed Flats eel-weirs and ask the clerk to register it as active. | Erzähler | open_run_level | Accept achievable Novice contract | Adventurers' Guild hall, Alderwatch | 150/84 | 20.2 s |
| 70 | I ask the clerk where the nearest working smithy is — I need my blade and armor checked before I head south. | Erzähler | open_run_level | Find a smith for the required gear check | Adventurers' Guild hall, Alderwatch | 150/84 | 15.1 s |
| 71 | I head to Forge Row and enter the Ferro smithy, asking the smith for concrete upgrade offers on both a weapon and armor for a Novice warrior… | Erzähler | open_run_level | Do the required gear check at the smith | The Ferro place | 150/84 | 21.7 s |
| 72 | I'll take the edge true'd and straps tightened on my own gear for 8 copper, and pass on the longsword and harness for now. | Erzähler | open_run_level | Buy affordable maintenance; decline unaffordable upgrades | The Ferro place | 150/84 | 20.0 s |
| 73 | I leave the smithy and return to the Guild hall, where I offer the clerk my five wolf pelts and nine wolf fangs for sale at two copper each. | Erzähler | open_run_level | Sell surplus loot, then head for the Marsh Adder contract | Adventurers' Guild hall, Alderwatch | 150/84 | 20.0 s |
| 74 | I'm back from the smithy, not from the Flats — the Marsh Adder is still 0/1. Before I head south again, could you buy these wolf pelts and f… | Erzähler | open_run_level | Sell surplus loot to the clerk, then continue the Marsh Adder contract | Adventurers' Guild hall, Alderwatch | 150/84 | 17.9 s |
| 75 | Nothing to sell, then — I leave the Guild hall and head out the south gate toward the Reed Flats eel-weirs to hunt the Marsh Adder. | Erzähler | open_run_level | Travel to the Marsh Adder contract area | the eel-weirs of the Reed Flats | 150/84 | 16.9 s |
| 76 | I walk the planks between the weirs and search the deep channels around the widest pool for signs of the Marsh Adder, staying ready with my … | Erzähler | open_run_level | Hunt the Marsh Adder at the eel-weirs | the eel-weirs of the Reed Flats | 150/84 | 19.1 s |
| 77 | I strike at the Marsh Adder with my longsword from the planks, keeping my footing away from the waterline. | Erzähler | open_run_level | Attack the Marsh Adder from secure footing | the eel-weirs of the Reed Flats | 150/84 | 14.2 s |
| 78 | I step forward along the planks toward the hut, closing into ENGAGED range of the Marsh Adder, then strike at its head with my longsword. | Erzähler | open_run_level | Close the range and attack the Marsh Adder | the eel-weirs of the Reed Flats | 150/84 | 18.1 s |
| 79 | I head back along the causeway to the Crownheart Guild hall and turn in the completed Marsh Adder contract to the clerk. | Erzähler | open_run_level | Turn in the Marsh Adder contract, then choose the next Guild job | Adventurers' Guild hall, Crownheart | 150/84 | 19.6 s |
| 80 | I ask the clerk what Novice contracts are on the board, and look over the slips for something achievable before nightfall. | Erzähler | open_run_level | Choose next Guild contract | Adventurers' Guild hall, Crownheart | 150/84 | 27.3 s |
| 81 | I take the Wharf-Wasp contract slip from the board, ask the clerk to accept it, and check the quest is ACTIVE before I leave for the timber … | Erzähler | open_run_level | Accept the wasp cull contract | the timber wharves of Crownheart | 150/84 | 22.9 s |
| 82 | "Pimm, stay back by the post." I draw my longsword and use Cleave on the two wasps sunning on the timber. | Erzähler | open_run_level | Engage both wasps with Cleave | the timber wharves of Crownheart | 150/84 | 18.4 s |
| 83 | I close the distance to the nearest wasp on the log booms, then strike it with my longsword once in reach. | Erzähler | open_run_level | Engage the wasps in melee before using Cleave | the timber wharves of Crownheart | 150/84 | 15.1 s |
| 84 | I climb out along the nearest log boom toward the wasps, and once one is within reach I strike at it with my longsword. | Erzähler | open_run_level | Close to ENGAGED range on the boom and attack | the timber wharves of Crownheart | 150/84 | 44.2 s |
| 85 | I close on Reed Wharf-Wasp B and attack it with my longsword. | Erzähler | open_run_level | Engage and kill the second wasp | the timber wharves of Crownheart | 150/84 | 15.5 s |
| 86 | I call Pimm over to help collect the chitin plates and venom gland, then say, "That's two of six. I'll finish the rest before dark — stay by… | Erzähler | open_run_level | Continue wasp cull toward 6/6 | the timber wharves of Crownheart | 150/84 | 20.1 s |
| 87 | #assign VIT 3 AGI 2 | System (Befehl) | open_run_level | Spend level-up stat points before pressing on toward the nest | the timber wharves of Crownheart | 150/84 | 2.5 s |
| 88 | I tell Pimm, "Watch from shore — if the nest swarms, I'm falling back to you." Then I creep out along the booms toward the hollow log and sc… | Erzähler | open_run_level | Scout the nest log cautiously before engaging | the hollow boom log | 150/84 | 19.2 s |
| 89 | I wait a few paces off and strike the nearest wasp emerging from the holes with my longsword, ready to step back if more swarm out. | Engine (Menü/Rückfrage) | open_run_level | Engage nest wasps one at a time | the hollow boom log | 150/84 | 5.5 s |
| 90 | I hold my ground and wait for a wasp to actually crawl out of the holes, then attack it with my longsword. | Erzähler | open_run_level | Engage a nest wasp once it emerges and is targetable | the hollow boom log | 150/84 | 20.1 s |
| 91 | I strike the emerged Reed Wharf-Wasp C with my longsword before it can free its wings. | Erzähler | open_run_level | Attack the engaged wasp while it's still half in the hole | the hollow boom log | 150/84 | 17.7 s |
| 92 | I call out to Pimm that it's getting too dark, and say, "Three down, three owed — I'll rest and finish the rest at first light. Keep an eye … | Erzähler | open_run_level | Withdraw at dusk to recover, resume cull tomorrow | Crossed Oar and Tankard lodging house | 150/84 | 29.1 s |
| 93 | I take the bed and breakfast for 40 copper and the supper for 2 copper, paying 42 copper, then sleep until morning. | Engine (Menü/Rückfrage) | open_run_level | Buy lodging and supper, then rest overnight | Crossed Oar and Tankard lodging house | 150/84 | 8.8 s |
| 94 | Both together, please — bed and breakfast plus supper, 42 copper total. Then I eat, go up, and sleep until morning. | Erzähler | open_run_level | Confirm combined purchase and rest | lodging room upstairs | 150/84 | 28.1 s |
| 95 | I sleep until morning. | Erzähler | open_run_level | Recover overnight | lodging room upstairs | 245/84 | 22.8 s |
| 96 | I eat the breakfast, then head to the timber yards wharf to finish the wasp cull — three more wasps owed. | Erzähler | open_run_level | Finish wasp cull contract | the timber wharves of Crownheart | 245/84 | 35.4 s |
| 97 | I ask the clerk and Pimm what they want done — go in after the holed-up wasps, or smoke them out? | Erzähler | open_run_level | Clarify how to finish the wasp cull | the timber wharves of Crownheart | 245/84 | 20.4 s |
| 98 | I walk out on the boom-walk and press my hand to the far face of the log, low near the waterline, to find which holes are still warm. | Erzähler | open_run_level | Locate the live wasp holes before attacking | the timber wharves of Crownheart | 245/84 | 19.3 s |
| 99 | "Three warm holes, all low on the far face. Stand ready with the wedges and a net if you have one — I'll take them as they come out." I take… | Erzähler | open_run_level | Set up an ambush at the warm holes and fight the wasps as they emerge | the timber wharves of Crownheart | 245/84 | 25.3 s |
| 100 | I strike the wasp's head as it emerges from the hole. | Erzähler | open_run_level | Kill the emerging wasp | the timber wharves of Crownheart | 245/84 | 20.3 s |
| 101 | #assign STR 2 VIT 2 AGI 1 | System (Befehl) | open_run_level | Spend level-up points | the timber wharves of Crownheart | 245/84 | 2.6 s |
| 102 | I move up to the next warm hole and take position with my sword ready, waiting for the second wasp to emerge. | Erzähler | open_run_level | Kill the remaining wasps to finish the cull | the second warm hole | 245/84 | 25.9 s |
| 103 | I strike the wasp as it eases out of the hole, aiming for its head. | Erzähler | open_run_level | Kill wasp E at the middle hole | the second warm hole | 245/84 | 29.7 s |
| 104 | I ask Pimm whether the yard keeps a smoke fire or smudge pots for smoking the last hole. | Erzähler | open_run_level | Get the wasp smoked out or killed without waiting days | the second warm hole | 245/84 | 21.3 s |
| 105 | "The pail and rags, Pimm — a proper smudge at the hole mouth. Fetch it and I'll stand ready for it when it comes up." | Erzähler | open_run_level | Smoke the last wasp out and kill it | the second warm hole | 245/84 | 22.5 s |
| 106 | I strike the smoke-choked wasp as it clears the rim, aiming for its head. | Erzähler | open_run_level | Kill the last wasp F | the second warm hole | 245/84 | 20.7 s |
| 107 | I thank Pimm and the clerk, then head back to the Guild hall with my marked slip to turn in the wasp cull. | Erzähler | open_run_level | Turn in the completed contract at the Guild hall | Adventurers' Guild hall, Crownheart | 245/84 | 22.7 s |
| 108 | #assign STR 3 VIT 2 | System (Befehl) | open_run_level | Spend level-up stat points | Adventurers' Guild hall, Crownheart | 245/84 | 2.6 s |
| 109 | I ask the desk clerk what contracts are on the board suitable for a Novice-rank swordsman. | Erzähler | open_run_level | Pick the next Guild contract | Adventurers' Guild hall, Crownheart | 245/84 | 27.6 s |
| 110 | I take the Boar Hunt at Thornhollow contract at the counter. | Erzähler | open_run_level | Accept the boar hunt contract | Adventurers' Guild hall, Crownheart | 245/84 | 14.8 s |
| 111 | I set out from the Guild hall and enter a smith's shop in Crownheart. "I'm in the market for a better sword or sturdier plate — what can you… | Erzähler | open_run_level | Do the required gear check at a smith before the boar hunt | smithy on the smiths' row | 245/84 | 19.9 s |
| 112 | "Good work, but more than my purse holds today. I'll keep the hunt in mind — thank you." I leave the smithy and set out south and west along… | Erzähler | open_run_level | Gear check done; prices unaffordable, proceed to boar hunt | charcoal-burners' camps | 245/84 | 24.5 s |
| 113 | "The bramble gap, please — and I'll take that stew while I wait for dusk." | Erzähler | open_run_level | Scout the boars' entry point and recover before the dusk hunt | bramble gap on the east side | 245/84 | 30.7 s |
| 114 | I walk back down to the camp with Ossler and take a bowl of stew, then wait there for dusk. | Erzähler | open_run_level | Recover with stew and wait for the boars' dusk approach | charcoal-burners' camps | 245/84 | 27.8 s |
| 115 | I draw my longsword and move to meet the boars at the bramble gap, keeping the camp behind me, and use Cleave on the first boar to come thro… | Erzähler | open_run_level | Fight the boars as they emerge from the gap | bramble gap on the east side | 245/84 | 19.3 s |
| 116 | I sidestep the charging boar A and swing Cleave into it as it passes, staying clear of Boar B behind it. | Erzähler | open_run_level | Fight the boars with Cleave | bramble gap on the east side | 245/84 | 18.0 s |
| 117 | I step in and engage the nearest boar (A), then swing Cleave at it. | Erzähler | open_run_level | Engage a boar properly so Cleave can resolve | bramble gap on the east side | 232/84 | 14.9 s |
| 118 | I swing Cleave into the wounded Boar A, keeping Boar B out of the arc if I can. | Erzähler | open_run_level | Finish off the wounded boar with Cleave | bramble gap on the east side | 232/84 | 19.9 s |
| 119 | I watch the second boar leave, then drag the dead boar's hide and tusk free and start back toward the camp. | Erzähler |  | Collect loot and return to Ossler's camp after the boar kill | charcoal-burners' camps | 232/84 | 25.4 s |
| 120 | "One of the great tusked boars came through the bramble gap — I killed it, the other fled back into the wood. You're safe; I'll deal with th… | Erzähler | open_run_level | Report the kill to Ossler and recover at the camp | charcoal-burners' camps | 232/84 | 22.9 s |
| 121 | I sleep in the drying shed until morning. | Erzähler | open_run_level | Recover overnight at Ossler's camp | charcoal-burners' camps | 295/84 | 15.6 s |
| 122 | I head up the valley toward the bramble gap, engage the second boar, and swing Cleave at it. | Erzähler | open_run_level | Hunt and kill the second boar to complete the contract | bramble gap on the east side | 295/84 | 28.2 s |
| 123 | I swing Cleave at the boar in the bramble gap. | Erzähler | open_run_level | Kill the second boar to complete the contract | bramble gap on the east side | 295/84 | 21.0 s |
| 124 | I hold my ground at the gap and swing Cleave at the boar as soon as it charges into engagement. | Erzähler | open_run_level | Engage the charging boar and attack with Cleave | bramble gap on the east side | 295/84 | 18.6 s |
| 125 | I push through the narrow gap toward the boar to close into engagement, and swing Cleave at it as soon as we are engaged. | Erzähler | open_run_level | Force engagement by moving through the gap, then Cleave | bramble gap on the east side | 278/84 | 17.9 s |
| 126 | I swing Cleave at the wounded boar. | Erzähler | open_run_level | Finish the boar with Cleave | bramble gap on the east side | 278/84 | 17.9 s |
| 127 | Both boars are down. I head back along the low road to the Guild hall in Valedorn and turn in the Boar Hunt at Thornhollow contract. | Erzähler | open_run_level | Turn in the completed boar contract at the Guild hall | Adventurers' Guild hall, Alderwatch | 278/84 | 21.6 s |
| 128 | #assign STR 5 VIT 5 AGI 5 | System (Befehl) | open_run_level | Spend level-up stat points | Adventurers' Guild hall, Alderwatch | 278/84 | 2.8 s |
| 129 | I ask around the Guild hall for the best smith in Alderwatch, then head to their shop to compare weapon and armour upgrade offers. | Erzähler | open_run_level | Warrior gear check at a smith | Smithy off the market square | 278/84 | 31.3 s |
| 130 | I'll take the Exceptional Longsword and the Exceptional Plate Armor — 6 Gold 20 Silver for both. If that's more than my coin, I'll buy the E… | Engine (Menü/Rückfrage) | open_run_level | Buy and equip affordable upgrades at the smith | Smithy off the market square | 278/84 | 15.0 s |
| 131 | Since I can't afford any of it, I buy nothing, thank the smith, and return to the Guild hall to pick a new contract from the board. | Erzähler | open_run_level | Gear check done without purchase; return to contract work | Adventurers' Guild hall, Alderwatch | 278/84 | 25.2 s |
| 132 | I take the Bramble Wolves contract slip from the board and ask the clerk to register it. | Erzähler | open_run_level | Accept the bramble wolves hunt contract | Adventurers' Guild hall, Alderwatch | 278/84 | 16.3 s |
| 133 | I take a room at the Wethered Ewe, eat a hot meal, and sleep until dawn, then set out west for the Barrowfield bramble at first light. | Erzähler | open_run_level | Rest overnight, then hunt bramble wolves at dawn as the clerk suggested | Adventurers' Guild hall, Alderwatch | 278/84 | 20.0 s |
| 134 | I'll take the smaller back room for one silver ten, please — here's the coin. Then I'll sleep there until dawn. |  | open_run_level | Book the cheap room and rest until morning | Adventurers' Guild hall, Alderwatch | 278/84 | 8.7 s |
| 135 | I pay the innkeeper one silver and ten copper for the smaller back room, then go up and sleep in it until dawn. | Erzähler | open_run_level | Book the room with explicit price and sleep until morning | smaller back room under the eaves | 278/84 | 35.7 s |
| 136 | I get up, eat the breaking-fast, and set out west for the Barrowfield bramble to hunt the wolves. | Erzähler | open_run_level | Travel to the bramble wolves hunting ground | the Barrowfield bramble | 278/84 | 18.9 s |
| 137 | I follow the freshest game trail into the bramble, keeping my longsword ready and watching for wolves ahead and behind. | Erzähler | open_run_level | Hunt the bramble wolves | hollow with the wolf den under the fallen slab | 278/84 | 32.4 s |
| 138 | I turn to the wolf on the trail behind me and swing my longsword in a Cleave through it and the one in the grass to my left. | Erzähler | open_run_level | Fight the flanking wolves with Cleave | hollow with the wolf den under the fallen slab | 278/84 | 16.0 s |
| 139 | I set my feet and strike the charging trail wolf with a Basic Attack as it reaches me. | Erzähler | open_run_level | Engage and attack the nearest wolf | hollow with the wolf den under the fallen slab | 274/84 | 17.5 s |
| 140 | I swing my longsword in a Cleave through both wolves hanging on my legs. | Erzähler | open_run_level | Kill both engaged wolves with AoE | hollow with the wolf den under the fallen slab | 274/84 | 25.0 s |
| 141 | #assign STR 3 VIT 2 | System (Befehl) | open_run_level | Spend the five level-up points | hollow with the wolf den under the fallen slab | 274/84 | 2.8 s |
| 142 | I skin nothing and keep moving — I search the frost around the hollow for the fourth wolf's tracks and follow them carefully. | Erzähler | open_run_level | Hunt the fourth wolf for the contract | clearing under the rise | 274/84 | 31.9 s |
| 143 | I charge the fourth wolf and swing my longsword in a Basic Attack at it as I close the twenty feet. | Erzähler | open_run_level | Kill the fourth wolf to finish the contract | clearing under the rise | 274/84 | 17.0 s |
| 144 | I close the twenty feet and swing my longsword in a Basic Attack at the fourth wolf. | Erzähler | open_run_level | Close to ENGAGED and attack the fourth wolf | clearing under the rise | 274/84 | 15.8 s |
| 145 | I rush straight at the wolf to close to ENGAGED range, then swing my longsword in a Basic Attack the moment I reach it. | Erzähler | open_run_level | Close to ENGAGED and attack the fourth wolf | clearing under the rise | 274/84 | 27.0 s |
| 146 | I head back down the track toward the road and Valedorn to turn in the wolf contract and sell the pelts. | Erzähler | open_run_level | Return to town with contract READY | Alderwatch | 274/84 | 25.8 s |
| 147 | I go to the inn and ask for a room for the night, then sleep until morning. | Erzähler | open_run_level | Recover at the inn until the Guild hall opens | The Wethered Ewe | 274/84 | 24.2 s |
| 148 | I go to the Guild hall and turn in the wolf contract, then look at the board for a new contract. | Erzähler | open_run_level | Turn in the READY contract and pick new work | Adventurers' Guild hall, Alderwatch | 274/84 | 35.4 s |
| 149 | I accept the Marsh Adder contract at the eel-weirs, then head to the local smithy to compare weapon and armour upgrade offers. | Engine (Menü/Rückfrage) | open_run_level | Take achievable contract and do the required gear check | Adventurers' Guild hall, Alderwatch | 274/84 | 7.0 s |
| 150 | I accept the Marsh Adder contract at the eel-weirs, then head to Halloran's Smithy on Forge Row to ask the smith for weapon and armour upgra… | Erzähler | open_run_level | Accept contract and do required gear check at Halloran's | Halloran's smithy | 274/84 | 24.6 s |
| 151 | I set my Fine Plate Armor on the bench and ask Halloran to inspect it: what's wrong with it, and what would an upgrade cost and give me? | Erzähler | open_run_level | Get the required armour assessment from the smith | Halloran's smithy | 274/84 | 21.4 s |
| 152 | I tell Halloran the superior plate is beyond my purse for now, thank him, and set out south along the river road toward the eel-weirs to hun… | Erzähler | open_run_level | Decline unaffordable upgrade, head to active contract | the eel-weirs of the Reed Flats | 274/84 | 20.2 s |
| 153 | I thank the worker and head down the walkway past the smoke house to the third weir, staying alert for the big adder in the reed beds. | Erzähler | open_run_level | Travel to the third weir to hunt the Marsh Adder | the third weir | 274/84 | 21.2 s |
| 154 | I draw my superior longsword and attack the adder as it comes onto the mud, keeping my footing on the walkway so it can't circle behind me. | Erzähler | open_run_level | Fight the Marsh Adder from the walkway | the third weir | 274/84 | 19.9 s |
| 155 | I move off the walkway toward the adder to close into range, then attack it with my longsword. | Erzähler | open_run_level | Close distance and engage the Marsh Adder | the third weir | 274/84 | 22.1 s |
| 156 | I pull back onto the walkway and ask the eel-man: does the big adder come back to raid the pens? I'll wait for it here on the boards rather … | Erzähler | open_run_level | Disengage from the adder's element and set up an ambush on firm ground | the third weir | 274/84 | 30.6 s |
| 157 | I wait until the adder is fully up on the mud and committed toward the broken pen, then attack it from behind with my longsword, positioning… | Engine (Menü/Rückfrage) | open_run_level | Ambush the adder on land where it is slower | the third weir | 274/84 | 5.5 s |
| 158 | I use Basic Attack: I strike the adder from behind as it commits toward the broken pen, cutting off its retreat to the channel. | Erzähler | open_run_level | Attack the committed adder from behind with Basic Attack | the third weir | 274/84 | 17.4 s |
| 159 | I move quickly across the drag-path to close the thirty feet and cut the adder off from the channel, then strike it from behind with Basic A… | Erzähler | open_run_level | Close to ENGAGED and attack the committed adder | the third weir | 274/84 | 24.5 s |
| 160 | I declare movement to ENGAGED with Marsh Adder B, advancing along the drag-path, then attack it with Basic Attack once in range. | Erzähler | open_run_level | Explicitly close to ENGAGED and attack the adder | the third weir | 274/84 | 20.7 s |
| 161 | I withdraw back onto the walkway boards and wait there with my longsword ready, watching the pen until the adder comes up to raid it again. | Erzähler | open_run_level | Set ambush on the boards and let the adder come to the pen | the third weir | 274/84 | 31.3 s |
| 162 | I stay on the boards beside the broken pen and wait for the adder to haul its body up onto the drag-path toward the eels, then strike it wit… | Erzähler | open_run_level | Ambush the adder as it commits to raiding the pen | the third weir | 274/84 | 20.3 s |
| 163 | I move away from the pens and hide out of sight behind the windlass, watching, so the adder thinks the boards are clear — then I ambush it w… | Erzähler | open_run_level | Break the stalemate by hiding so the adder commits to raiding | the third weir | 274/84 | 25.4 s |
| 164 | I burst from the windlass shadow and use Cleave on the adder's committed forequarters. | Erzähler | open_run_level | Ambush the adder with Cleave now that it is fully on the drag-path | the third weir | 274/84 | 28.2 s |
| 165 | I strike the adder's raised head with Basic Attack at SHORT range. | Erzähler | open_run_level | Attack the adder now that it is at SHORT range | the third weir | 274/84 | 14.1 s |
| 166 | I step forward to ENGAGED with the adder and strike its raised head with Basic Attack. | Erzähler | open_run_level | Close the stride and attack | the third weir | 274/84 | 19.5 s |
| 167 | I tell the eel-man the adder is dead and ask whether there were more of the big ones troubling his pens, or if that was the last. | Erzähler | open_run_level | Confirm the cull is complete before returning to the Guild for the turn-in | the third weir | 274/84 | 22.7 s |
| 168 | I tell the eel-man I'll report the cull to the Guild, then set out from the third weir back to the Guild hall in Valedorn Crown to turn in t… | Erzähler | open_run_level | Travel to the Guild and turn in the finished adder cull | Adventurers' Guild hall, Alderwatch | 274/84 | 27.9 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 9 (notiert vor Zug 10): Narration said five silver total but HUD shows 3 Silver — trusting the HUD.
- zu Zug 11 (notiert vor Zug 12): Gear check done: best affordable upgrade needs 14 silver; I hold only 3. No affordable offer available — resuming adventuring.
- zu Zug 22 (notiert vor Zug 23): Cleave was refused with no valid target despite the ambush narration; need wolves to enter the scene before attacking.
- zu Zug 36 (notiert vor Zug 37): Engine demanded exact booking wording; purchases still pending.
- zu Zug 42 (notiert vor Zug 43): Coin is 19 copper, below the 100 cp smith-check threshold; wolf contract stands at 3/5.
- zu Zug 60 (notiert vor Zug 61): Combined purchase message failed the planner; retrying as explicit separate payments.
- zu Zug 62 (notiert vor Zug 63): Wolf contract was already turned in this morning; narration now offers brokerage for the extra pelts and fangs.
- zu Zug 66 (notiert vor Zug 67): HUD confirms pelts and fangs still carried; narrator claimed counter empty — mismatch between HUD and narration.
- zu Zug 71 (notiert vor Zug 72): Longsword (140 cp) would leave only 7 cp, under the 20 cp reserve; superior harness needs two days' fitting, so both declined per rules.
- zu Zug 74 (notiert vor Zug 75): Wolf pelts and fangs vanished from inventory without a recorded loss — noted as an oddity; I no longer claim them.
- zu Zug 83 (notiert vor Zug 84): Both wasps are now alerted; booms lie over water, so melee requires stepping onto the timber.
- zu Zug 85 (notiert vor Zug 86): Level 8 confirmed with 5 free stat points; quest shows 2/6 defeated. HP wounded (150/230) — should watch recovery.
- zu Zug 89 (notiert vor Zug 90): System refused the vague target 'nearest wasp emerging' — wasps not yet targetable; must wait for an emerged, named actor.
- zu Zug 100 (notiert vor Zug 101): Quest counter reads 4/6 though narration implies six dead; two warm holes still hold live wasps, so keep fighting until the counter confirms.
- zu Zug 111 (notiert vor Zug 112): Smith's upgrades (480/360/800 cp) all exceed my 292 cp; gear check complete, resuming after income grows.
- zu Zug 130 (notiert vor Zug 131): Smith offers all exceed my 592 cp; gear trial completed with offers compared, no affordable upgrade available.
- zu Zug 136 (notiert vor Zug 137): Narrator says I slept and traveled, but HUD shows Day 5, 01:35 night and HP 278/340 — arrival only, rest may not have registered.
- zu Zug 144 (notiert vor Zug 145): Engine rejected Basic Attack at SHORT twice; must explicitly declare movement to ENGAGED first.
- zu Zug 150 (notiert vor Zug 151): Engine rejected the combined message once for an unnamed smithy; naming Halloran's worked and the gear check is now possible.
- zu Zug 151 (notiert vor Zug 152): Gear check done: superior plate offered at 12 gold, unaffordable with 7g 3s 2c; sword already superior.
- zu Zug 155 (notiert vor Zug 156): The adder kites at LONG/MEDIUM range whenever I close; direct pursuit seems futile. Villager Tam flagged as a threat — he may attack the adder himself.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t18 | 18 | 1 | – | nein | 1 | gewonnen, 290 XP |
| enc.t22 | 24 | 2 | – | nein | 2 | gewonnen, 650 XP |
| enc.t41 | 49 | 1 | – | nein | 1 | gewonnen, 240 XP |
| enc.t46 | 55 | 1 | – | nein | 1 | gewonnen, 420 XP |
| enc.t64 | 78 | 1 | – | nein | 1 | gewonnen, 60 XP |
| enc.t70 | 84 | 2 | – | nein | 2 | gewonnen, 660 XP |
| enc.t75 | 91 | 1 | – | nein | 1 | gewonnen, 240 XP |
| enc.t83 | 100 | 1 | – | nein | 1 | gewonnen, 240 XP |
| enc.t85 | 103 | 1 | – | nein | 1 | gewonnen, 360 XP |
| enc.t88 | 106 | 1 | – | nein | 1 | gewonnen, 240 XP |
| enc.t98 | 117 | 1 | – | nein | 1 | gewonnen, 580 XP |
| enc.t106 | 125 | 1 | – | nein | 1 | gewonnen, 630 XP |
| enc.t117 | 139 | 3 | – | nein | 3 | gewonnen, 960 XP |
| enc.t122 | 145 | 1 | – | nein | 1 | gewonnen, 290 XP |
| enc.t141 | 166 | 1 | – | ja | 1 | gewonnen, 75 XP |

## Quests

- **Kill the Marsh Adder at the Eel-Weirs** — expired (Zug 68)
  - Aufgabe: Kill 1 marsh adder at the eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 marsh adder killed at the eel-weirs of the Reed Flats.
- **Thin the Barrowfield Wolves** — active (Zug 14) → completed (Zug 57)
  - Aufgabe: Kill 5 wolf at the Barrowfield bramble. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 5 wolf killed at the Barrowfield bramble.
- **Break the Thornhollow Boar Sounder** — expired (Zug 68)
  - Aufgabe: Kill 4 great tusked boar at Thornhollow. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 great tusked boar killed at Thornhollow.
- **Slay the Pale Stag of Hollowmere** — expired (Zug 68)
  - Aufgabe: Kill 1 Pale Stag of Hollowmere at the reed shore of Hollowmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 Pale Stag of Hollowmere killed at the reed shore of Hollowmere.
- **Clear the Old Crown Catacombs, Level 1** — expired (Zug 68), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of Old Crown Catacombs. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Old Crown Catacombs is clear.
- **Cull the Marsh Adder at the Reed Flats Eel-Weirs** — active (Zug 69) → completed (Zug 79), READY
  - Aufgabe: Kill 1 marsh adder at the eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 marsh adder killed at the eel-weirs of the Reed Flats.
- **Cull the Barrowfield Bramble Wolves** — expired (Zug 131)
  - Aufgabe: Kill 4 wolf at the Barrowfield bramble. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 wolf killed at the Barrowfield bramble.
- **Thin the Thornhollow Great Tusked Boars** — expired (Zug 131)
  - Aufgabe: Kill 2 great tusked boar at Thornhollow. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 2 great tusked boar killed at Thornhollow.
- **The Pale Stag of Hollowmere** — expired (Zug 131)
  - Aufgabe: Kill 1 Pale Stag of Hollowmere at the reed shore of Hollowmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 Pale Stag of Hollowmere killed at the reed shore of Hollowmere.
- **Clear Old Crown Catacombs Level 1** — expired (Zug 131), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of Old Crown Catacombs. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Old Crown Catacombs is clear.
- **Cull the Marsh Adder at the Eel-Weirs** — expired (Zug 109)
  - Aufgabe: Kill 1 marsh adder at the eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 marsh adder killed at the eel-weirs of the Reed Flats.
- **Thin the Barrowfield Wolf Pack** — expired (Zug 109)
  - Aufgabe: Kill 5 Barrowfield wolf at the Barrowfield bramble. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 5 Barrowfield wolf killed at the Barrowfield bramble.
- **Wharf-Wasp Cull at the Timber Yards** — active (Zug 81) → completed (Zug 107)
  - Aufgabe: Kill 6 reed wharf-wasp at the timber wharves of Crownheart. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 6 reed wharf-wasp killed at the timber wharves of Crownheart.
- **Cull the Thornhollow Tusked Boar** — expired (Zug 109)
  - Aufgabe: Kill 3 great tusked boar at Thornhollow. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 great tusked boar killed at Thornhollow.
- **Cull the Pale Stag of Hollowmere** — expired (Zug 109)
  - Aufgabe: Kill 1 Pale Stag of Hollowmere at the reed shore of Hollowmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 Pale Stag of Hollowmere killed at the reed shore of Hollowmere.
- **Boar Hunt at Thornhollow** — active (Zug 110) → completed (Zug 127)
  - Aufgabe: Kill 2 great tusked boars at Thornhollow. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 2 great tusked boars killed at Thornhollow.
- **Cull the Marsh Adder at the Eel-Weirs** — expired (Zug 148)
  - Aufgabe: Kill 1 marsh adder at the eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 marsh adder killed at the eel-weirs of the Reed Flats.
- **Thin the Barrowfield Bramble Wolves** — active (Zug 132) → completed (Zug 148)
  - Aufgabe: Kill 4 Barrowfield bramble wolves at the Barrowfield bramble. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 Barrowfield bramble wolves killed at the Barrowfield bramble.
- **Put Down the Thornhollow Great Tusked Boar** — expired (Zug 148)
  - Aufgabe: Kill 1 great tusked boar of Thornhollow at Thornhollow. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 great tusked boar of Thornhollow killed at Thornhollow.
- **The Pale Stag of Hollowmere** — expired (Zug 148)
  - Aufgabe: Kill 1 the Pale Stag of Hollowmere at the reed shore of Hollowmere. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the Pale Stag of Hollowmere killed at the reed shore of Hollowmere.
- **Clear the Old Crown Catacombs, Level 1** — expired (Zug 148), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of Old Crown Catacombs. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Old Crown Catacombs is clear.
- **Cull the Marsh Adder at the Eel-Weirs** — active (Zug 150) → completed (Zug 168)
  - Aufgabe: Kill 1 marsh adder at the eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 marsh adder killed at the eel-weirs of the Reed Flats.

## Auffälligkeiten

- Zug 6, Nachricht 11 (board_failed): the board generator failed
- Zug 12, Nachricht 23 (planner_repaired): the planner's first answer needed a repair
- Zug 15, Nachricht 30 (extraction_repaired): the extractor's first answer needed a repair
- Zug 32, Nachricht 64 (extraction_repaired): the extractor's first answer needed a repair
- Zug 35, Nachricht 69 (planner_repaired): the planner's first answer needed a repair
- Zug 36, Nachricht 71 (planner_repaired): the planner's first answer needed a repair
- Zug 37, Nachricht 73 (planner_repaired): the planner's first answer needed a repair
- Zug 60, Nachricht 119 (planner_failed): the planner failed: $.commands[1] (equip): .object: matches none of anyOf; $.commands[2] (equip): .object: matches none of anyOf
- Zug 60, Nachricht 119 (planner_repaired): the planner's first answer needed a repair
- Zug 64, Nachricht 127 (planner_repaired): the planner's first answer needed a repair
- Zug 65, Nachricht 129 (planner_failed): the planner failed: sell seq 2: min_cp 18 is not what his words "nine F-Rank Wolf Fangs at her brokerage price of four silver" say: 40 cp total for qty 9. min_cp is the TOTAL for the selected quantity; if he means severa
- Zug 65, Nachricht 129 (planner_repaired): the planner's first answer needed a repair
- Zug 92, Nachricht 184 (extraction_repaired): the extractor's first answer needed a repair
- Zug 93, Nachricht 185 (planner_repaired): the planner's first answer needed a repair
- Zug 96, Nachricht 192 (extraction_repaired): the extractor's first answer needed a repair
- Zug 102, Nachricht 204 (extraction_repaired): the extractor's first answer needed a repair
- Zug 113, Nachricht 225 (planner_repaired): the planner's first answer needed a repair
- Zug 119, Nachricht 238 (extraction_repaired): the extractor's first answer needed a repair
- Zug 122, Nachricht 244 (extraction_repaired): the extractor's first answer needed a repair
- Zug 129, Nachricht 258 (extraction_repaired): the extractor's first answer needed a repair
- Zug 130, Nachricht 259 (planner_repaired): the planner's first answer needed a repair
- Zug 134, Nachricht 267 (planner_failed): the planner failed: buy seq 1: ambiguous price or quantity in this quote. Copy only this item's exact price clause; max_cp is the TOTAL for the selected quantity, not a unit rate.
- Zug 134, Nachricht 267 (planner_repaired): the planner's first answer needed a repair
- Zug 135, Nachricht 269 (planner_repaired): the planner's first answer needed a repair
- Zug 137, Nachricht 274 (extraction_repaired): the extractor's first answer needed a repair
- Zug 142, Nachricht 284 (extraction_repaired): the extractor's first answer needed a repair
- Zug 164, Nachricht 328 (extraction_repaired): the extractor's first answer needed a repair
- Zug 168, Nachricht 336 (extraction_repaired): the extractor's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 41× keine gültige JSON-Entscheidung (Züge 5, 7, 8, 9, 13, 17, 18, 20, 24, 31, 32, 44, 45, 49, 59, 73, 76, 77, 80, 82, 97, 98, 102, 108, 110, 113, 114, 115, 118, 119, 120, 122, 123, 126, 130, 138, 139, 153, 154, 155, 157)

System-Panels: CLARIFY 8, NOT TAKEN 1, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: ambient 7, coin_evidence 1, world_rule 7, offer 3, scene_context 11, no_go 2, attack_commitment 4, engine_recovery 1, quest_count 5, engine_owned_memory 3, engine_owned_fact 16, guild_completion 1, guild_payout 2, entity_fact 2, pc_inventory 4, gear_offer 1, npc_presence 1, time_cap 1, recover 1, group_unclear 2.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 41/168 Erstantworten ungültig (24.4 %); 41 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 166 | 12 | 2.5 s | 4.4 s | 12345 | 10020 | 89 | – | stop 166 | 0 |
| narrator | 141 | 0 | 8.3 s | 11.2 s | 11440 | 8789 | 406 | – | stop 141 | 0 |
| extract | 153 | 12 | 5.5 s | 8.7 s | 12894 | 9787 | 393 | – | stop 153 | 0 |
| board | 10 | 3 | 9.0 s | 13.6 s | 2623 | 2317 | 1132 | – | stop 10 | 0 |
| forge | 1 | 0 | 2.5 s | 2.5 s | 359 | 0 | 59 | – | stop 1 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 63:27 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 13.8 s) | 0:27 min |
| 168 Züge, Spiel (Senden bis HUD nach der Extraktion) | 52:17 min — Median 19.1 s, p90 28.2 s, max 44.2 s |
| 168 Züge, Spieler-Entscheidung | 7:28 min — Median 2.1 s, 41 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 8:09 min / 1:33 min / 20:39 min / 14:56 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 21.3 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 14:13 min, 80 Züge ≈ 28:27 min (ohne Einrichtung) |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
