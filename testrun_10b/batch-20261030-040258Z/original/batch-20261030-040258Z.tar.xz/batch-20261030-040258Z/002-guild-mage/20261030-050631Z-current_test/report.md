# Avereth Live-Test 20261030-050631Z-current_test

## Kurzfassung

- **Laufprofil:** guild-mage; Startklasse Mage, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** abgeschlossen: alle Pflicht-Etappen erreicht
- **Etappen:** 2/2 Pflicht erreicht
- **Progressionsziel:** Level 15; tatsächlich Level 15. Sicherheitsgrenzen: 200 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** Level 13, 795 XP seit Levelaufstieg, 452 cp, HP 74, MP 516; Ort loc.ashbridge. Ausrüstung und Skills stehen in evaluation.json → progression.checkpoint.
- **Charakter:** mage (mage.arcane_bolt, mage.arcane_wave) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: cautious adventurer: prepare and recover, weigh threats and withdraw when sensible
- **Züge:** 106 · **Dauer:** 38:19 min · **LLM-Aufrufe der Engine/des Erzählers:** 284
- **Beobachtete Abdeckung:** 19 unterschiedliche gebuchte Reiseziele · 15 Kämpfe · 1 Verkäufe (65 cp Umsatz, ohne Questzahlungen/Geschenke) · 0 Ausrüstungswechsel · 0 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 8
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.122 |
| Git | 013e0dca9e7b (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 14.3 s |
| Browser | chrome 156.0.8078.49 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261030-050631Z-current_test“, Seed 1040509682 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | ✔ | 106 | 212 |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | I choose Mage. | Engine (Menü/Rückfrage) | creation_complete | Select base class | public roadside verge outside Ashbridge | 90/84 | 2.3 s |
| 2 | I select Arcane Wave and Arcane Bolt as my two skills. | Engine (Menü/Rückfrage) | creation_complete | Pick starter skills including required Arcane Wave | public roadside verge outside Ashbridge | 90/96 | 2.2 s |
| 3 | I walk to Ashbridge and head to the Adventurers' Guild hall to register and look at the contract board. | Erzähler | open_run_level | Enter city and find Guild work | Adventurers' Guild hall, Ashbridge | 90/96 | 43.5 s |
| 4 | I sign the sheet, press a drop of blood on the seal line, and pay the clerk two silver to register with the Guild. | Erzähler | open_run_level | Register at the Guild | Adventurers' Guild hall, Ashbridge | 90/96 | 16.5 s |
| 5 | I take the wolf notice from the board to the clerk and ask her to book it active for me. | Erzähler | open_run_level | Accept the wolf contract | Adventurers' Guild hall, Ashbridge | 90/96 | 15.3 s |
| 6 | I leave the Guild hall and travel southwest to the Lowfields crofts to look for the wolf on the field edges. | Erzähler | open_run_level | Travel to the wolf contract site | Lowfields crofts southwest of Ashbridge | 90/96 | 19.3 s |
| 7 | I examine the dragged patch by the turnip rows and the hedge bottom for fresh tracks, then follow the trail slowly along the field edge. | Erzähler | open_run_level | Track the yearling wolf | Hedge bend by the narrow wood | 90/96 | 27.5 s |
| 8 | I ready my staff and cast Arcane Bolt at the wolf in the treeline. | Erzähler | open_run_level | Fight the yearling wolf for the contract | Hedge bend by the narrow wood | 90/86 | 19.3 s |
| 9 | I travel back to Ashbridge and go to the Guild hall to turn in the wolf contract and collect the reward. | Erzähler | open_run_level | Turn in completed wolf contract at the Guild | Adventurers' Guild hall, Ashbridge | 90/86 | 24.8 s |
| 10 | #assign INT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up stat points | Adventurers' Guild hall, Ashbridge | 90/86 | 2.2 s |
| 11 | I look over the fresh postings on the board for a contract I can take. | Erzähler | open_run_level | Pick a new Guild contract | Adventurers' Guild hall, Ashbridge | 90/86 | 14.3 s |
| 12 | I ask the clerk to register me for the fen adder contract at the Eel-Weirs. | Erzähler | open_run_level | Accept achievable Novice contract | Adventurers' Guild hall, Ashbridge | 90/86 | 16.7 s |
| 13 | I travel south from Ashbridge to the reed banks of the Eel-Weirs and search the shallows for fen adders. | Erzähler | open_run_level | Hunt fen adders for the active contract | reed banks of the Eel-Weirs south of Ashbridge | 90/86 | 22.5 s |
| 14 | I wade carefully along the near reed bank, watching the shallows for fen adders. | Erzähler | open_run_level | Hunt fen adders for the active contract | reed banks of the Eel-Weirs south of Ashbridge | 90/86 | 30.5 s |
| 15 | I stay behind the reed screen and cast Arcane Bolt at the adder's raised head. | Erzähler | open_run_level | Attack first fen adder from ambush range | reed banks of the Eel-Weirs south of Ashbridge | 90/76 | 18.5 s |
| 16 | #assign INT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up stat points | reed banks of the Eel-Weirs south of Ashbridge | 90/76 | 2.2 s |
| 17 | I continue hunting along the reed banks, searching the shallows for the next fen adder. | Erzähler | open_run_level | Continue fen adder contract hunt | reed banks of the Eel-Weirs south of Ashbridge | 90/76 | 17.7 s |
| 18 | I stay hidden behind the reeds and cast Arcane Bolt at the resting adder's head. | Erzähler | open_run_level | Ambush second fen adder from range | reed banks of the Eel-Weirs south of Ashbridge | 90/76 | 17.0 s |
| 19 | I fire Arcane Bolt at the basking adder's head. | Erzähler | open_run_level | Kill second fen adder | reed banks of the Eel-Weirs south of Ashbridge | 90/66 | 18.0 s |
| 20 | #assign INT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up stat points | reed banks of the Eel-Weirs south of Ashbridge | 90/66 | 2.2 s |
| 21 | I follow the fresh adder traces along the near bank, keeping low and watching for the next basking adder. | Erzähler | open_run_level | Continue contract hunt toward 5 adders | mud spit on the near bank | 90/66 | 20.1 s |
| 22 | I stay low at the reed margin and cast Arcane Bolt at the basking adder's head. | Erzähler | open_run_level | Ambush Fen Adder C from range | mud spit on the near bank | 90/56 | 19.1 s |
| 23 | #assign INT 3 WIL 2 | System (Befehl) | open_run_level | Spend level 5 stat points | mud spit on the near bank | 90/56 | 2.2 s |
| 24 | I keep low along the reed margin and follow the drag-marks north, watching for the fifth basking adder. | Erzähler | open_run_level | Hunt the fifth adder | basking hollow at the end of the adder run | 90/56 | 22.5 s |
| 25 | I stay behind the hummock and cast Arcane Bolt at the big adder's head. | Erzähler | open_run_level | Ambush Fen Adder D from range | basking hollow at the end of the adder run | 90/46 | 18.8 s |
| 26 | I collect the skin, fangs and venom sac from the big adder, then start back south toward Ashbridge before the light fails. | Erzähler | open_run_level | Loot the fifth adder and return for turn-in | Ashbridge | 90/46 | 24.1 s |
| 27 | I walk up through the gate to the Guild hall and present my contract slip and the five adder skins for turn-in. | Erzähler | open_run_level | Turn in the adder contract | Adventurers' Guild hall, Ashbridge | 90/46 | 21.2 s |
| 28 | I take the clerk's offer of the bunk room downstairs and sleep until dawn. | Erzähler | open_run_level | Recover overnight, then hunt the fifth adder at first light | Adventurers' Guild hall, Ashbridge | 110/272 | 14.9 s |
| 29 | I head back out the south gate to the Eel-Weirs and hunt one more fen adder among the reeds. | Erzähler | open_run_level | Get the fifth adder for the contract | reed banks of the Eel-Weirs south of Ashbridge | 110/272 | 16.4 s |
| 30 | I move along the near bank toward the fresh basking wallow and scan the reeds for an adder. | Erzähler | open_run_level | Find the fifth fen adder | fresh basking wallow | 110/272 | 15.4 s |
| 31 | I follow the drag-marks into the reeds at the flat's far side, staff ready, watching for the adder. | Erzähler | open_run_level | Track the adder into the reeds and attack it | adder holt in the reeds | 110/272 | 17.5 s |
| 32 | I cast Arcane Bolt at the adder's head as it rises. | Erzähler | open_run_level | Attack the fifth fen adder | adder holt in the reeds | 110/262 | 18.6 s |
| 33 | #assign INT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up stat points | adder holt in the reeds | 110/262 | 2.2 s |
| 34 | I head back north to the Ashbridge Guild hall and turn in the adder contract at the clerk's desk. | Erzähler | open_run_level | Turn in the completed contract | Adventurers' Guild hall, Ashbridge | 110/262 | 22.1 s |
| 35 | #assign INT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up stat points | Adventurers' Guild hall, Ashbridge | 110/262 | 2.2 s |
| 36 | I walk to the contract board and look over the fresh notices for a Novice-rank job I can take. | Erzähler | open_run_level | Pick a new Guild contract | Adventurers' Guild hall, Ashbridge | 110/262 | 28.1 s |
| 37 | I take the Starved Yearling contract at the Lowfields Crofts from the board and ask the clerk to accept it. | Erzähler | open_run_level | Accept a new achievable Guild contract | Adventurers' Guild hall, Ashbridge | 110/262 | 15.5 s |
| 38 | I set out southwest along the lanes to the Lowfields crofts and search for the half-starved yearling wolf. | Erzähler | open_run_level | Travel to the contract site and hunt the yearling | Lowfields crofts southwest of Ashbridge | 110/262 | 22.1 s |
| 39 | I head east past the last croft toward the old turf-cut and drain-ditch, watching for the yearling wolf. | Erzähler | open_run_level | Hunt the yearling at its daytime lay-up | old turf-cut and drain-ditch | 110/262 | 23.8 s |
| 40 | I cast Arcane Bolt at the yearling wolf. | Erzähler | open_run_level | Attack the contract target at range before it closes | old turf-cut and drain-ditch | 110/252 | 13.0 s |
| 41 | I return to the Lowfields crofts and tell the woman the wolf is dead, then head back to the Guild hall in Duskreach to turn in the Starved Y… | Erzähler | open_run_level | Complete the contract and turn it in | Adventurers' Guild hall, Ashbridge | 110/252 | 26.8 s |
| 42 | I ask the clerk what contracts are still posted on the board for a Novice. | Erzähler | open_run_level | Find the next Guild contract | Adventurers' Guild hall, Ashbridge | 110/252 | 11.7 s |
| 43 | I take the Clear the Fen Adders from the Eel-Weirs (5) contract from the board and ask the clerk to accept it. | Erzähler | open_run_level | Accept the achievable adder cull contract | Adventurers' Guild hall, Ashbridge | 110/252 | 16.4 s |
| 44 | I head to Ashbridge's market and ask a merchant what he'll pay for five fen adder skins, nine adder fangs, two wolf pelts and three wolf fan… | Erzähler | open_run_level | Sell surplus loot before hunting the adders | Ashbridge market square | 110/252 | 16.7 s |
| 45 | I accept the offer and sell the lot for sixty-five copper, then buy a wheel of hard cheese if I don't already carry one, and set off south t… | Erzähler | open_run_level | Sell surplus loot, then hunt the adders | reed banks of the Eel-Weirs south of Ashbridge | 110/252 | 20.2 s |
| 46 | I walk the flat stones along the nearest channel and search the reed edges for basking adders, staff ready. | Erzähler | open_run_level | Hunt the fen adders on the reed banks | low mud bank along the channel | 110/252 | 21.7 s |
| 47 | I cast Arcane Wave at the adder on the stone. | Erzähler | open_run_level | Attack the fen adder | low mud bank along the channel | 110/238 | 14.9 s |
| 48 | #assign INT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up stat points | low mud bank along the channel | 110/238 | 2.2 s |
| 49 | I follow the flattened drag-trail through the reeds toward the holt, staff ready, watching for more adders. | Erzähler | open_run_level | Continue hunting the remaining four adders | low mud bank along the channel | 110/238 | 18.5 s |
| 50 | I walk the flat stones downstream and search the sunlit banks for more basking adders, staff ready. | Erzähler | open_run_level | Hunt the remaining four adders along the dry stones | eel-fisher's weir | 110/238 | 19.9 s |
| 51 | I keep my distance from the heron and cross the weir stakes toward the eel-fisher's hut. | Erzähler | open_run_level | Find the fisher or signs of more adders at the hut | eel-fisher's hut | 110/238 | 20.7 s |
| 52 | I read the birch bark note nailed to the hut door. | Erzähler | open_run_level | Read the fisher's note for clues on the adders | eel-fisher's hut | 110/238 | 18.3 s |
| 53 | I walk the stake walk at dusk with staff ready, looking for the big adder said to lie there in the warm. | Erzähler | open_run_level | Hunt the big adder on the stake walk | stake walk toward the far bank | 110/238 | 21.6 s |
| 54 | I cast Arcane Bolt at the adder's head from where I stand. | Erzähler | open_run_level | Open the fight with a single-target spell at range | stake walk toward the far bank | 110/228 | 14.1 s |
| 55 | It is fully dark and the count stands at 2/5, so I withdraw from the stake walk, make a safe camp near the eel-fisher's hut, and sleep until… | Erzähler | open_run_level | Recover overnight, then resume the adder hunt at dawn | stake walk toward the far bank | 125/404 | 39.7 s |
| 56 | I walk the stake walk over to the far bank in the morning light and search there for the remaining three adders, staff ready. | Erzähler | open_run_level | Hunt the remaining adders from the far bank side | far bank of the Eel-Weirs | 125/404 | 19.4 s |
| 57 | I search the tussock grass and reed line near the willow for the remaining three adders, checking warm basking spots. | Erzähler | open_run_level | Hunt remaining adders on the far bank | far bank of the Eel-Weirs | 125/404 | 15.2 s |
| 58 | I search south along the reed line, following the water's edge away from the willow and checking the next warm stretch of bank for the adder… | Erzähler | open_run_level | Hunt the remaining three adders along the southern reed line | far bank of the Eel-Weirs | 125/404 | 15.2 s |
| 59 | I cross back over the stake walk and search the brush heaps and lashed joints along it for the remaining adders. | Erzähler | open_run_level | Search the stake walk brush heaps for adders | far bank of the Eel-Weirs | 125/404 | 18.0 s |
| 60 | I head back to the eel-fisher's hut and ask him where the remaining adders tend to bask this time of day, since the banks and stake walk hav… | Erzähler | open_run_level | Get a lead on the remaining three adders from the local fisher | eel-fisher's hut | 125/404 | 21.6 s |
| 61 | I head half a mile south to the osier beds where the channel forks and search the rotting willow stools for pale droppings on the rim and ad… | Erzähler | open_run_level | Hunt the remaining three adders at the osier beds | osier beds at the channel fork | 125/404 | 14.0 s |
| 62 | I walk into the osier beds and examine the nearest split, rotting willow stools for pale droppings on the rim, keeping clear of the hollows … | Erzähler | open_run_level | Search the osier stools for adder signs | osier beds at the channel fork | 125/404 | 20.0 s |
| 63 | I cast Arcane Bolt at the adder's head in the hollow, aiming to kill it outright before it can slip down the stool's core. | Erzähler | open_run_level | Kill the third adder in its hollow | osier beds at the channel fork | 125/394 | 16.4 s |
| 64 | #assign INT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up stat points | osier beds at the channel fork | 125/394 | 2.2 s |
| 65 | I search the remaining osier stools for the fourth adder. | Erzähler | open_run_level | Hunt the fourth adder in the osier beds | osier beds at the channel fork | 125/394 | 18.7 s |
| 66 | I cast Arcane Bolt at the raised head of the large adder before it can strike. | Erzähler | open_run_level | Kill the fourth adder with a first strike | osier beds at the channel fork | 125/384 | 18.4 s |
| 67 | I search the remaining willow stools along the channel for a fifth adder. | Erzähler | open_run_level | Find and kill the fifth adder for the contract | osier beds at the channel fork | 125/384 | 15.7 s |
| 68 | I cast Arcane Bolt at the basking adder's head before it can slip into the hollow's core. | Erzähler | open_run_level | Kill the fifth adder to complete the contract | osier beds at the channel fork | 125/374 | 13.2 s |
| 69 | With the slip READY at 5/5, I head south along the channel road back to the Ashbridge Guild hall to turn in the adder contract. | Erzähler | open_run_level | Return to the Guild hall and turn in the completed contract | Adventurers' Guild hall, Ashbridge | 125/374 | 20.0 s |
| 70 | #assign INT 3 WIL 2 | System (Befehl) | open_run_level | Spend the five new level-up stat points | Adventurers' Guild hall, Ashbridge | 125/374 | 2.4 s |
| 71 | I ask the clerk what contracts are on the board for a Novice mage. | Erzähler | open_run_level | Pick the next Guild contract | Adventurers' Guild hall, Ashbridge | 125/374 | 26.1 s |
| 72 | I take the Quarry Gnolls notice to the clerk and ask to accept the contract. | Erzähler | open_run_level | Accept the gnoll cull contract | Adventurers' Guild hall, Ashbridge | 125/374 | 12.0 s |
| 73 | Contract accepted. I head east out of Ashbridge on the quarry track past tanner's row toward the old quarry cut. | Erzähler | open_run_level | Travel to the quarry to hunt gnolls | old quarry cut on the quarry track east of Ashbridge | 125/374 | 16.2 s |
| 74 | I stay back from the ramp edge and cast Arcane Bolt toward the spot where the rock clicked, keeping the quarry rim between me and the lower … | Engine (Menü/Rückfrage) | open_run_level | Engage the gnoll lookout from range without entering the pit | old quarry cut on the quarry track east of Ashbridge | 125/374 | 4.6 s |
| 75 | I creep to the quarry rim for a view of the lower terraces, staying low behind cover, and cast Arcane Bolt at the gnoll lookout if it comes … | Erzähler | open_run_level | Spot and attack the gnoll lookout from range | old quarry cut on the quarry track east of Ashbridge | 125/374 | 32.7 s |
| 76 | I cast Arcane Bolt at the lone lookout on the first terrace, staying behind the granite slab. | Erzähler | open_run_level | Open the gnoll hunt by sniping the lookout from cover | old quarry cut on the quarry track east of Ashbridge | 125/374 | 15.6 s |
| 77 | I move down the rubble spill onto the first terrace, keeping cover between me and the lookout, and cast Arcane Bolt at it once I'm within ra… | Erzähler | open_run_level | Close to MEDIUM range and snipe the lookout | old quarry cut on the quarry track east of Ashbridge | 125/364 | 23.5 s |
| 78 | #assign INT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up stat points | old quarry cut on the quarry track east of Ashbridge | 125/364 | 2.5 s |
| 79 | I stay behind cover and cast Arcane Bolt at the nearest gnoll on the second terrace, the one holding the pick. | Engine (Menü/Rückfrage) | open_run_level | Continue the gnoll cull from range | old quarry cut on the quarry track east of Ashbridge | 125/364 | 6.4 s |
| 80 | I stay behind cover and cast Arcane Bolt at Quarry Gnoll B, the one at MEDIUM range. | Erzähler | open_run_level | Continue the gnoll cull from range | old quarry cut on the quarry track east of Ashbridge | 102/354 | 24.9 s |
| 81 | I step back out of Gnoll B's reach and cast Arcane Bolt at it to finish it off. | Erzähler | open_run_level | Kill the wounded gnoll before the others close | old quarry cut on the quarry track east of Ashbridge | 102/344 | 16.1 s |
| 82 | I cast Arcane Wave at the two gnolls at SHORT range, hitting both. | Erzähler | open_run_level | AoE on both adjacent gnolls | old quarry cut on the quarry track east of Ashbridge | 49/330 | 21.1 s |
| 83 | I step back to MEDIUM range from both gnolls and cast Arcane Bolt at Quarry Gnoll C, the more wounded one. | Erzähler | open_run_level | Finish Gnoll C and regain range | old quarry cut on the quarry track east of Ashbridge | 23/320 | 17.0 s |
| 84 | I cast Arcane Bolt at Quarry Gnoll D at point-blank range. | Erzähler | open_run_level | Finish the last gnoll | old quarry cut on the quarry track east of Ashbridge | 23/310 | 15.0 s |
| 85 | #assign WIL 3 VIT 2 | System (Befehl) | open_run_level | Spend level-up points into WIL and VIT for survivability | old quarry cut on the quarry track east of Ashbridge | 23/310 | 2.5 s |
| 86 | I search the quarry cut and nearby track for the last two gnolls, staff ready, keeping to open ground where I can retreat. | Erzähler | open_run_level | Find the remaining two gnolls for the cull contract | old quarry cut on the quarry track east of Ashbridge | 23/310 | 27.7 s |
| 87 | I slip back the way I came before they mark me, and make for Ashbridge to recover — I'm too hurt to fight two more. | Erzähler | open_run_level | Withdraw at near-death HP and recover before finishing the cull | Ashbridge | 23/310 | 23.6 s |
| 88 | I accept the guard's help and sit, asking where I can be treated and rest for the night. | Erzähler | open_run_level | Get medical treatment and lodging to recover | Ashbridge | 23/310 | 27.5 s |
| 89 | I show the healer my bleeding side and let him treat it, paying the few coppers he asks. | Erzähler | open_run_level | Get treated, then lodge at the Drowned Ox | Ashbridge | 23/310 | 21.8 s |
| 90 | I hand the boy four coppers and thank him, then head for the Drowned Ox to take a bed for the night. | Erzähler | open_run_level | Pay healer and get lodging | The Drowned Ox | 23/310 | 20.1 s |
| 91 | I put two silver on the counter and take the bed with supper, then eat and go up to sleep until morning. | Erzähler | open_run_level | Pay for lodging and sleep to recover | The Drowned Ox | 155/560 | 18.5 s |
| 92 | I head back to the Old Quarry Cut and hunt down the last two gnolls, keeping to open ground and ready to retreat. | Erzähler | open_run_level | Finish the gnoll cull contract at full health | old quarry cut on the quarry track east of Ashbridge | 155/560 | 19.6 s |
| 93 | I take a covered position on the quarry lip overlooking the deep working and watch for movement before advancing. | Erzähler | open_run_level | Scout the deep working from cover before engaging the last two gnolls | old quarry cut on the quarry track east of Ashbridge | 155/560 | 28.4 s |
| 94 | I step out from cover and cast Arcane Wave at the two gnolls by the block pile, then keep open ground between us and retreat toward the quar… | Erzähler | open_run_level | Open the fight on the last two gnolls with AoE at range | old quarry cut on the quarry track east of Ashbridge | 155/560 | 23.3 s |
| 95 | I advance down the open quarry floor toward the two gnolls, and as soon as they come within spell range I cast Arcane Wave at both of them. | Erzähler | open_run_level | Close to MEDIUM range and open the fight with AoE | old quarry cut on the quarry track east of Ashbridge | 128/546 | 22.1 s |
| 96 | I cast Arcane Bolt at the wounded Quarry Gnoll G at ENGAGED range to finish it off. | Erzähler | open_run_level | Kill the wounded gnoll first | old quarry cut on the quarry track east of Ashbridge | 101/536 | 24.7 s |
| 97 | I cast Arcane Bolt at Quarry Gnoll H at ENGAGED range. | Erzähler | open_run_level | Finish the last gnoll with a strong bolt | old quarry cut on the quarry track east of Ashbridge | 74/526 | 14.7 s |
| 98 | I cast Arcane Bolt at Quarry Gnoll H to finish it. | Erzähler | open_run_level | Kill the last gnoll | old quarry cut on the quarry track east of Ashbridge | 74/516 | 16.3 s |
| 99 | #assign INT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up stat points | old quarry cut on the quarry track east of Ashbridge | 74/516 | 2.6 s |
| 100 | I collect the knife and coins, then head back along the quarry track to Ashbridge to turn in the completed gnoll cull contract at the Guild … | Erzähler | open_run_level | Turn in the finished contract and recover in town | Ashbridge | 74/516 | 29.7 s |
| 101 | I turn in the completed gnoll cull contract at the counter and collect the reward. | Erzähler | open_run_level | Turn in finished contract | Ashbridge | 74/516 | 20.2 s |
| 102 | I take a seat on the bench and wait until the closings counter reopens after midday. | Erzähler | open_run_level | Wait for Master Verill to reopen payouts, then turn in | Ashbridge | 74/516 | 22.0 s |
| 103 | I bring the contract slip to Master Verill's counter and ask him to close it out and pay the reward. | Erzähler | open_run_level | Turn in gnoll cull contract to Master Verill | Ashbridge | 74/516 | 19.6 s |
| 104 | I ask Master Verill what question is marked against the gnoll cull slip. | Erzähler | open_run_level | Resolve the ledger query before payout | Ashbridge | 74/516 | 21.7 s |
| 105 | "I killed six gnolls at the cut. The lower east dens still looked lived-in — fresh sign and half-eaten kills there — so the pack may run lar… | Erzähler | open_run_level | Answer Verill's question honestly to clear the ledger query and secure payout | Ashbridge | 74/516 | 26.2 s |
| 106 | I take the slip and the chit and walk to the Guild hall proper on the market square, then present both to the paymaster and ask for the thre… | Erzähler | open_run_level | Turn in gnoll cull contract at the Guild hall paymaster | Adventurers' Guild hall, Ashbridge | 74/516 | 22.2 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 20 (notiert vor Zug 21): Quest panel still shows 2/5 despite two adders defeated this hunt; narrator said three total including one earlier.
- zu Zug 25 (notiert vor Zug 26): Quest panel still shows 4/5 despite five adders defeated; will verify at Guild turn-in.
- zu Zug 27 (notiert vor Zug 28): Engine counts 4/5 adders despite five kills recorded in combat results; the big adder may not register as a fen adder. Will hunt one more in the morning.
- zu Zug 36 (notiert vor Zug 37): Carrying yearling pelt and fang from a prior unrecorded kill; contract demands engine-recorded kills of this population, so the loot may not count.
- zu Zug 40 (notiert vor Zug 41): Contract shows 1/1 defeated, so the engine recorded the kill; prior unrecorded loot is surplus.
- zu Zug 41 (notiert vor Zug 42): Level 7, surplus pelts/fangs and adder parts accumulating; gear check and loot sale due soon.
- zu Zug 44 (notiert vor Zug 45): HUD already lists a cheese wheel; buy is conditional to avoid duplication.
- zu Zug 45 (notiert vor Zug 46): HUD coin shows 3 Gold 2 Silver while the engine recorded 320 copper — same value, no conflict.
- zu Zug 49 (notiert vor Zug 50): The flooded drag-trail cannot be followed on foot (invalid habitat scope); hunting continues along the stone channel instead.
- zu Zug 52 (notiert vor Zug 53): Fisher's note names the stake walk at dusk as the big adder's spot and the south bank trail as their crossing.
- zu Zug 54 (notiert vor Zug 55): Ambush crit defeated Fen Adder G instantly (+515 XP, 790/800, nearly level 9). Count shows 2/5 defeated.
- zu Zug 58 (notiert vor Zug 59): Two failed searches on the far bank; adders may still be on the stake walk structures.
- zu Zug 59 (notiert vor Zug 60): Three consecutive search failures despite good conditions; adders may respawn on a timer or favor a spot not yet identified.
- zu Zug 66 (notiert vor Zug 67): Narration says five adders taken and slip READY, but the quest panel still shows 4/5 defeated.
- zu Zug 67 (notiert vor Zug 68): A fifth adder is confirmed present and engaged, yet the quest counter still reads 4/5 after five kills — the count may only update on turn-in.
- zu Zug 68 (notiert vor Zug 69): Quest counter now confirms 5/5 defeated; loot may include extra skins and fangs beyond what the pouch narration mentioned.
- zu Zug 70 (notiert vor Zug 71): Contract turned in: +1g4s, +750 XP, Level 10; stats assigned. Guild now sells skill primers (strike, bolt, guard, ward, mend) at 80 cp.
- zu Zug 82 (notiert vor Zug 83): HP down to 49/140 after two engaged strikes; should consider recovery after this fight.
- zu Zug 83 (notiert vor Zug 84): HP critical at 23/140; need recovery after this fight.
- zu Zug 86 (notiert vor Zug 87): Contract at 4/6; last two gnolls E and F at LONG with partial cover, unaware. HP 23/155 too low to risk.
- zu Zug 92 (notiert vor Zug 93): Something dragged a gnoll corpse toward the deep working; fresh gnoll prints suggest the last two may be there.
- zu Zug 100 (notiert vor Zug 101): Turn-in previously refused because I wasn't at the Guild hall; now at the counter with Clerk B present.
- zu Zug 101 (notiert vor Zug 102): Turn-in blocked by timing: closings handled by Master Verill, unavailable until half a bell past midday; slip still READY.
- zu Zug 105 (notiert vor Zug 106): Records annex cannot process payouts; query answered and chit issued. Wounded (74/160 HP) — physicker nearby before next job.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t8 | 8 | 1 | – | nein | 1 | gewonnen, 60 XP |
| enc.t14 | 15 | 1 | – | nein | 1 | gewonnen, 300 XP |
| enc.t17 | 19 | 1 | – | ja | 1 | gewonnen, 240 XP |
| enc.t19 | 22 | 1 | – | nein | 1 | gewonnen, 360 XP |
| enc.t21 | 25 | 1 | – | nein | 1 | gewonnen, 295 XP |
| enc.t28 | 32 | 1 | – | nein | 1 | gewonnen, 360 XP |
| enc.t34 | 40 | 1 | – | nein | 1 | gewonnen, 60 XP |
| enc.t41 | 47 | 1 | – | nein | 1 | gewonnen, 420 XP |
| enc.t47 | 54 | 1 | – | nein | 1 | gewonnen, 515 XP |
| enc.t56 | 63 | 1 | – | nein | 1 | gewonnen, 240 XP |
| enc.t58 | 66 | 1 | – | nein | 1 | gewonnen, 240 XP |
| enc.t60 | 68 | 1 | – | nein | 1 | gewonnen, 240 XP |
| enc.t67 | 77 | 1 | – | ja | 1 | gewonnen, 595 XP |
| enc.t68 | 80 | 3 | – | ja | 3 | gewonnen, 1675 XP |
| enc.t82 | 95 | 2 | – | nein | 2 | gewonnen, 1265 XP |

## Quests

- **A Wolf at the Turnip Rows** — active (Zug 5) → completed (Zug 9)
  - Aufgabe: Kill 1 half-starved yearling wolf at Lowfields crofts southwest of Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 half-starved yearling wolf killed at Lowfields crofts southwest of Ashbridge.
- **Thin the Fen Adders at the Eel-Weirs** — active (Zug 12) → completed (Zug 34)
  - Aufgabe: Kill 5 fen adders at reed banks of the Eel-Weirs south of Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 5 fen adders killed at reed banks of the Eel-Weirs south of Ashbridge.
- **Break the Quarry Track Gnoll Pack** — expired (Zug 36)
  - Aufgabe: Kill 6 quarry gnolls at old quarry cut on the quarry track east of Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 6 quarry gnolls killed at old quarry cut on the quarry track east of Ashbridge.
- **Slay the Pale Stag of Hollowmere** — expired (Zug 36)
  - Aufgabe: Kill 1 pale stag of Hollowmere at Hollowmere fen north of Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 pale stag of Hollowmere killed at Hollowmere fen north of Ashbridge.
- **Clear Mossback Warrens Level 1** — expired (Zug 36), Dungeon loc.mossback_warrens Ebene 1
  - Aufgabe: Clear level 1 of Mossback Warrens. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Mossback Warrens is clear.
- **Take the Starved Yearling at the Lowfields Crofts** — active (Zug 37) → completed (Zug 41)
  - Aufgabe: Kill 1 half-starved yearling wolf at Lowfields crofts southwest of Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 half-starved yearling wolf killed at Lowfields crofts southwest of Ashbridge.
- **Clear the Fen Adders from the Eel-Weirs** — active (Zug 43) → completed (Zug 69)
  - Aufgabe: Kill 5 fen adder at reed banks of the Eel-Weirs south of Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 5 fen adder killed at reed banks of the Eel-Weirs south of Ashbridge.
- **Drive Down the Quarry Gnolls of the Old Quarry Cut** — expired (Zug 71)
  - Aufgabe: Kill 6 quarry gnoll at old quarry cut on the quarry track east of Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 6 quarry gnoll killed at old quarry cut on the quarry track east of Ashbridge.
- **Slay the Pale Stag of Hollowmere** — expired (Zug 71)
  - Aufgabe: Kill 1 pale stag at Hollowmere fen north of Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 pale stag killed at Hollowmere fen north of Ashbridge.
- **Clear Mossback Warrens Level 1** — expired (Zug 71), Dungeon loc.mossback_warrens Ebene 1
  - Aufgabe: Clear level 1 of Mossback Warrens. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Mossback Warrens is clear.
- **Cull Quarry Gnolls in the Old Quarry Cut** — active (Zug 72) → completed (Zug 106)
  - Aufgabe: Kill 6 quarry gnoll at old quarry cut on the quarry track east of Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 6 quarry gnoll killed at old quarry cut on the quarry track east of Ashbridge.

## Auffälligkeiten

- Zug 7, Nachricht 14 (extraction_repaired): the extractor's first answer needed a repair
- Zug 14, Nachricht 28 (extraction_repaired): the extractor's first answer needed a repair
- Zug 17, Nachricht 34 (extraction_repaired): the extractor's first answer needed a repair
- Zug 41, Nachricht 82 (extraction_repaired): the extractor's first answer needed a repair
- Zug 62, Nachricht 124 (extraction_repaired): the extractor's first answer needed a repair
- Zug 86, Nachricht 172 (extraction_repaired): the extractor's first answer needed a repair
- Zug 87, Nachricht 174 (extraction_repaired): the extractor's first answer needed a repair
- Zug 89, Nachricht 178 (extraction_repaired): the extractor's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 26× keine gültige JSON-Entscheidung (Züge 7, 8, 16, 18, 22, 26, 28, 30, 33, 40, 44, 47, 48, 51, 52, 55, 58, 63, 75, 78, 79, 85, 93, 95, 105, 106)

System-Panels: CLARIFY 1, NOT TAKEN 1, REFUSED 1, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: guild_canon 5, guild_canon_price 1, engine_owned_fact 10, ambient 2, quest_count 2, engine_booked 1, pc_inventory 1, entity_fact 1, no_go 1, guild_completion 2, group_unclear 1, world_rule 11, offer 1, engine_recovery 1, scene_context 11, guild_payout 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 26/106 Erstantworten ungültig (24.5 %); 26 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 92 | 0 | 2.4 s | 3.8 s | 12308 | 9971 | 77 | – | stop 92 | 0 |
| board | 4 | 1 | 9.2 s | 10.6 s | 2637 | 2304 | 1141 | – | stop 4 | 0 |
| narrator | 90 | 0 | 8.4 s | 12.0 s | 11375 | 8790 | 393 | – | stop 90 | 0 |
| extract | 98 | 8 | 4.6 s | 8.5 s | 12806 | 9783 | 321 | – | stop 98 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 38:19 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 14.3 s) | 0:29 min |
| 106 Züge, Spiel (Senden bis HUD nach der Extraktion) | 31:14 min — Median 18.5 s, p90 26.8 s, max 43.5 s |
| 106 Züge, Spieler-Entscheidung | 4:52 min — Median 2.2 s, 26 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 4:26 min / 0:38 min / 13:21 min / 8:37 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 20.4 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 13:38 min, 80 Züge ≈ 27:15 min (ohne Einrichtung) |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
