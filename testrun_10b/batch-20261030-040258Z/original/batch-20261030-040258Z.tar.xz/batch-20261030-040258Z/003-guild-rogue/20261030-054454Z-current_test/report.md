# Avereth Live-Test 20261030-054454Z-current_test

## Kurzfassung

- **Laufprofil:** guild-rogue; Startklasse Rogue, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** abgebrochen: Fehler im Runner — interrupted (Ctrl+C) in turn 141
- **Etappen:** 1/2 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 13. Sicherheitsgrenzen: 200 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** Level 11, 690 XP seit Levelaufstieg, 521 cp, HP 190, MP 104; Ort loc.glimmerdeep_grotto.queens_basin_chamber. Ausrüstung und Skills stehen in evaluation.json → progression.checkpoint.
- **Charakter:** rogue (rogue.razor_cut, rogue.fan_of_blades) · Regelstand 2 (Warrior, Mage, Rogue)
- **Ziel-Dungeon:** Glimmerdeep Grotto, Ebene 1 (Vertrag quest.clear_glimmerdeep_grotto_level_1_2)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 to 15“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: curious adventurer: follow interesting opportunities without forcing dangerous encounters
- **Züge:** 141 · **Dauer:** 51:26 min · **LLM-Aufrufe der Engine/des Erzählers:** 386
- **Beobachtete Abdeckung:** 24 unterschiedliche gebuchte Reiseziele · 18 Kämpfe · 4 Verkäufe (323 cp Umsatz, ohne Questzahlungen/Geschenke) · 0 Ausrüstungswechsel · 1 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 15
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.122 |
| Git | 013e0dca9e7b (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 14.2 s |
| Browser | chrome 156.0.8078.49 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261030-054454Z-current_test“, Seed 1040509683 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | I choose the Rogue class. | Engine (Menü/Rückfrage) | creation_complete | Select base class | public roadside verge outside Glassmere | 90/84 | 2.3 s |
| 2 | I select Fan of Blades and Razor Cut as my two skills. | Engine (Menü/Rückfrage) | creation_complete | Finish character creation with required AoE skill | public roadside verge outside Glassmere | 90/84 | 2.1 s |
| 3 | I walk through the gates into Glassmere and head for the Adventurers' Guild to look at the contract board. | Erzähler | open_run_level | Enter city and find Guild contracts | Adventurers' Guild hall, Glassmere | 90/84 | 33.1 s |
| 4 | I take the Garden Serpent contract slip from the Novice board and hand it to the clerk. "I'll take this one." | Erzähler | open_run_level | Accept an easy novice contract | Adventurers' Guild hall, Glassmere | 90/84 | 14.7 s |
| 5 | "Deal." I put two silver on the counter and give her my name—Alaric Red—then touch the measuring stone to register. | Erzähler | open_run_level | Register with the Guild for 2 silver | Adventurers' Guild hall, Glassmere | 90/84 | 18.8 s |
| 6 | "I want it active—mark it for me, please." | Erzähler | open_run_level | Activate the Garden Serpent contract | Adventurers' Guild hall, Glassmere | 90/84 | 11.6 s |
| 7 | I head down the main street toward the river, turn past the tannery onto Millrace Lane, and ask the washerwomen at the washing stones where … | Erzähler | open_run_level | Travel to Millrace Lane and locate the Garden Serpent | the washing stones on Millrace Lane | 90/84 | 24.3 s |
| 8 | I circle wide through the reeds to get behind the snake's rock, cutting off its escape to the water, then strike with Fan of Blades. | Erzähler | open_run_level | Attack the snake while blocking its retreat | the washing stones on Millrace Lane | 90/84 | 21.1 s |
| 9 | I keep my distance and raise my empty hand. "I'm sorry—that was careless of me. My blade strayed past the snake. I'll wait here for Denna an… | Erzähler | open_run_level | De-escalate friendly fire incident, cooperate | the washing stones on Millrace Lane | 90/84 | 23.3 s |
| 10 | I take out my coin pouch. "She's hurt by my hand, so I'll answer for it. I have three silver—I'll give two to Bree for the days she can't wo… | Erzähler | open_run_level | Offer fair compensation for the friendly fire | the washing stones on Millrace Lane | 90/84 | 27.7 s |
| 11 | I skin the snake at the flat rock, take the hide and fang, and head back to the Guild hall to turn in the Garden Serpent contract. | Erzähler | open_run_level | Skin the kill and turn in the contract at the Guild hall | Adventurers' Guild hall, Glassmere | 90/84 | 23.3 s |
| 12 | #assign AGI 2 PER 2 WIL 1 | System (Befehl) | open_run_level | Spend level-up points | Adventurers' Guild hall, Glassmere | 90/84 | 2.2 s |
| 13 | I ask the clerk to point me to the brokerage desk, then have them price the snake skin and fang for sale. | Erzähler | open_run_level | Sell loot at the brokerage desk | brokerage desk | 90/84 | 20.4 s |
| 14 | "I'll take eighteen copper for the pair, Marta—cash now." | Erzähler | open_run_level | Accept Marta's offer of 18 copper for the hide and fang | brokerage desk | 90/84 | 14.3 s |
| 15 | I walk to the contract board and look for a new Novice-level contract I can take on. | Erzähler | open_run_level | Pick up the next Guild contract | brokerage desk | 90/84 | 14.8 s |
| 16 | I take the Reed Flat Striders contract slip to the clerk and ask to accept it. | Erzähler | open_run_level | Accept the achievable Novice hunt contract | brokerage desk | 90/84 | 39.4 s |
| 17 | I head east out of Glassmere toward the Reed Flats and find the eel-weir fishers to point me to where the bog striders are. | Erzähler | open_run_level | Travel to the contract site | brokerage desk | 90/84 | 19.6 s |
| 18 | I walk out along the plank walkway toward the nearest eel-weirs, watching the water for bog striders. | Erzähler | open_run_level | Hunt bog striders for the active contract | the eel-weirs of the Reed Flats | 90/84 | 22.0 s |
| 19 | I keep my eyes on the still water and strike first: I use Fan of Blades on Bog Strider A in the shallows beside the walkway. | Erzähler | open_run_level | Open the hunt with an AoE opener on the nearer strider | the eel-weirs of the Reed Flats | 77/84 | 15.1 s |
| 20 | I finish Bog Strider A with a Razor Cut. | Erzähler | open_run_level | Kill the engaged strider before B arrives | the eel-weirs of the Reed Flats | 77/84 | 19.4 s |
| 21 | #assign AGI 3 PER 2 | System (Befehl) | open_run_level | Spend level-up stat points on my core rogue stats | the eel-weirs of the Reed Flats | 77/84 | 2.1 s |
| 22 | I move to engage Bog Strider B before more are drawn by the blood, opening with Fan of Blades. | Erzähler | open_run_level | Continue the strider cull toward 5/5 | the eel-weirs of the Reed Flats | 65/84 | 18.3 s |
| 23 | I finish Bog Strider B with a Razor Cut before it strikes again. | Erzähler | open_run_level | Kill strider B toward the 5/5 contract | the eel-weirs of the Reed Flats | 65/84 | 19.4 s |
| 24 | #assign AGI 3 VIT 2 | System (Befehl) | open_run_level | Spend level-up points on AGI and survivability | the eel-weirs of the Reed Flats | 65/84 | 2.2 s |
| 25 | I call back to the fisher that I'm after all five, then move carefully along the stakes toward the deep weirs to look for the next strider. | Erzähler | open_run_level | Continue the cull toward 5/5 | the deep weirs | 65/84 | 23.3 s |
| 26 | I open with Fan of Blades as both striders close in, targeting the pair across the pool. | Erzähler | open_run_level | Fight striders C and D with AoE since both are in range | the deep weirs | 65/84 | 16.7 s |
| 27 | I hold my ground on the planks and wait for the striders to close to SHORT range, dagger ready, letting them come to me rather than stepping… | Erzähler | open_run_level | Bait the striders into Fan of Blades range | the deep weirs | 65/84 | 17.3 s |
| 28 | I strike the smaller strider with Razor Cut as it reaches the planks, then step back along the walkway to keep the big one from flanking me. | Erzähler | open_run_level | Fight strider D on the planks at close range | the deep weirs | 50/84 | 17.5 s |
| 29 | I finish the wounded strider with a Basic Attack before it can bite again. | Erzähler | open_run_level | Kill strider D at ENGAGED range | the deep weirs | 50/84 | 17.0 s |
| 30 | I spend my five points with #assign AGI 3 VIT 2, then ready my dagger against the big strider at the mud-line, watching for its charge. | Erzähler | open_run_level | Assign stats and fight strider C | the deep weirs | 50/84 | 36.8 s |
| 31 | I let the big strider come to the planks and hold my ground, dagger ready, planning to hit it with Razor Cut the moment it engages. | Erzähler | open_run_level | Bait strider C into close range and strike | the deep weirs | 50/84 | 15.2 s |
| 32 | I advance onto the planks and strike the big strider with Razor Cut while it holds at the mud-line, closing the distance myself. | Erzähler | open_run_level | Break the stalemate and engage strider C | the deep weirs | 38/84 | 16.7 s |
| 33 | I finish the strider with a Basic Attack before it can lunge. | Erzähler | open_run_level | Kill Bog Strider C at 2 HP | the deep weirs | 38/84 | 18.9 s |
| 34 | I press on along the walkway toward the far weirs, dagger ready, looking for the fifth and last strider. | Erzähler | open_run_level | Find and kill the fifth strider to complete the contract | the far weirs | 38/84 | 18.6 s |
| 35 | I search along the far weir's walkway in both directions for any sign of the fifth strider. | Erzähler | open_run_level | Find and kill the fifth strider to complete the contract | the far weirs | 38/84 | 17.5 s |
| 36 | The search finds nothing and I'm badly wounded with dusk falling, so I head back along the walkway toward the fisher's camp and town, keepin… | Erzähler | open_run_level | Withdraw to recover and return for the fifth strider later | the fisher's camp | 38/84 | 25.7 s |
| 37 | "Evening. I've cleared four of the five striders off the reed flats — the last one's still out there somewhere. Mind if I rest by your fire?… | Engine (Menü/Rückfrage) | open_run_level | Greet the fisher woman and seek rest at the camp | the fisher's camp | 38/84 | 4.0 s |
| 38 | "Mind if I sleep by your fire until morning? I took some knocks out there. | Erzähler | open_run_level | Book rest until morning at the fisher's camp | the fisher's camp | 38/84 | 20.7 s |
| 39 | I sit by the fire, keep the blade sheathed, and buy a bowl of the eel and leek soup for 1 copper. | Erzähler | open_run_level | Eat and rest at camp | the fisher's camp | 38/84 | 21.2 s |
| 40 | #assign VIT 3 WIL 2 | System (Befehl) | open_run_level | Spend free stat points before resting | the fisher's camp | 38/84 | 2.2 s |
| 41 | I finish the soup, then sleep by the fire until morning. | Erzähler | open_run_level | Recover overnight at the camp | the fisher's camp | 135/96 | 18.2 s |
| 42 | I thank the woman for the fire and soup, then head back out onto the reed flats to hunt down the fifth strider, keeping an eye out for the b… | Erzähler | open_run_level | Finish the 4/5 strider cull contract | the eel-weirs of the Reed Flats | 126/96 | 29.7 s |
| 43 | I strike with Razor Cut at the strider before it can spring. | Erzähler | open_run_level | Kill the fifth strider | the eel-weirs of the Reed Flats | 126/96 | 16.3 s |
| 44 | #assign VIT 3 WIL 2 | System (Befehl) | open_run_level | Spend the 5 free stat points from the level-up | the eel-weirs of the Reed Flats | 126/96 | 2.2 s |
| 45 | With the fifth strider down, I head back toward the fisher's camp at the weirs to report the cull complete and check on the silent fisher. | Erzähler | open_run_level | Return from completed cull, investigate the silent fisher | the fisher's camp | 126/96 | 23.6 s |
| 46 | "That makes five," I tell her. "I'm heading back to the Guild to report the cull. Anything strange been happening out past the reeds? That f… | Erzähler | open_run_level | Report the completed cull and ask about the silent fisher | Adventurers' Guild hall, Glassmere | 126/96 | 26.6 s |
| 47 | I report the five striders, and mention the big one's been prowling the fence line — if the Guild puts a bounty on it, I'd take the contract… | Erzähler | open_run_level | Report and ask about a bounty on the big one | Adventurers' Guild hall, Glassmere | 126/96 | 19.8 s |
| 48 | #assign AGI 3 PER 2 | System (Befehl) | open_run_level | Spend the 5 free stat points from the level-up | Adventurers' Guild hall, Glassmere | 126/96 | 2.1 s |
| 49 | I check the Novice board for any new contracts worth taking. | Erzähler | open_run_level | Find the next Guild contract | Adventurers' Guild hall, Glassmere | 126/96 | 26.7 s |
| 50 | I take the Snake at the Washing Stones slip to the counter and ask the woman to register it as active. | Erzähler | open_run_level | Accept an achievable Novice contract | Adventurers' Guild hall, Glassmere | 126/96 | 16.8 s |
| 51 | I head up Millrace Lane to the washing stones and look for the banded water snake. | Erzähler | open_run_level | Travel to the contract site and hunt the snake | the washing stones on Millrace Lane | 126/96 | 16.3 s |
| 52 | I greet the broad washerwoman and say I've taken the Guild contract to kill the banded water snake — any idea where it lairs along the stone… | Erzähler | open_run_level | Ask the washerwomen where the snake hides | the washing stones on Millrace Lane | 126/96 | 15.8 s |
| 53 | I take a spot on the dry bank bench near the third flat and wait for midday, watching the flat rock where the snake likes to sun itself. | Erzähler | open_run_level | Wait for the snake to emerge at midday | the washing stones on Millrace Lane | 126/96 | 20.9 s |
| 54 | I draw my dagger and close the twenty paces to strike the sunning snake with Razor Cut. | Erzähler | open_run_level | Attack the banded water snake | the washing stones on Millrace Lane | 126/96 | 28.9 s |
| 55 | I move across the wet stones to close into range, then strike the snake with Razor Cut. | Erzähler | open_run_level | Close distance and attack the snake | the washing stones on Millrace Lane | 126/96 | 17.6 s |
| 56 | I dash the last few paces into the shallows and strike the snake with Razor Cut before it can reach the willow hole. | Erzähler | open_run_level | Close to ENGAGED and attack the fleeing snake | the washing stones on Millrace Lane | 126/96 | 15.0 s |
| 57 | I wade right up to the willow roots until I'm at arm's reach of the hole, and strike into it with Razor Cut at the snake. | Erzähler | open_run_level | Close to ENGAGED at the willow hole and attack the snake | the washing stones on Millrace Lane | 126/96 | 16.8 s |
| 58 | Contract says 1/1 defeated — I retrieve the snake carcass proof if the washerwomen will allow it, then head back to the Caelreth Guild hall … | Erzähler | open_run_level | Turn in the completed snake contract at the Guild | Adventurers' Guild hall, Glassmere | 126/96 | 31.8 s |
| 59 | "What novice contracts are on the board today? I'm looking for the next job." | Erzähler | open_run_level | Pick up a new Guild contract | Adventurers' Guild hall, Glassmere | 126/96 | 12.4 s |
| 60 | I take the Bog Striders slip from the board and bring it to the counter. "I'll take this one. | Erzähler | open_run_level | Accept the bog strider cull contract | Adventurers' Guild hall, Glassmere | 126/96 | 16.8 s |
| 61 | I pocket the stamped slip, then head out the west gate and take the river road toward the Reed Flats eel-weirs. | Erzähler | open_run_level | Travel to the bog strider contract site | the eel-weirs of the Reed Flats | 126/96 | 21.1 s |
| 62 | I sneak low along the reed edge toward the moving spot, then strike the hidden strider with Fan of Blades once it's in sight. | Erzähler | open_run_level | Ambush the strider in the flattened reeds | the eel-weirs of the Reed Flats | 126/96 | 20.5 s |
| 63 | I stay low in the reed cover and strike the strider's exposed flank with Fan of Blades before it can turn. | Erzähler | open_run_level | Ambush the bog strider with Fan of Blades | the eel-weirs of the Reed Flats | 126/96 | 19.2 s |
| 64 | #assign AGI 3 PER 2 | System (Befehl) | open_run_level | Spend level-up points | the eel-weirs of the Reed Flats | 126/96 | 2.4 s |
| 65 | I step out of the reeds and greet the fisher. "That's the first of six. You said there are more tracks past the third weir? I'll head up the… | Erzähler | open_run_level | Continue the bog strider cull contract | the far channel past the third weir | 126/96 | 28.4 s |
| 66 | I circle wide downwind through the hummocks toward the trampled hollow, then sneak close and peer inside for the striders. | Erzähler | open_run_level | Ambush the striders at the den | the trampled hollow | 126/96 | 25.6 s |
| 67 | I strike the awake smaller strider H with Fan of Blades, angled so the spread stays inside the tunnel on those two and away from the tunnel … | Erzähler | open_run_level | Ambush both striders with AoE in the den chamber | the trampled hollow | 114/96 | 17.4 s |
| 68 | I finish the wounded big strider with Razor Cut before it can strike again. | Erzähler | open_run_level | Kill strider G and complete the cull count | the trampled hollow | 114/96 | 16.1 s |
| 69 | I gather the spilled copper coins from the den hoard, then #assign AGI 3 PER 2. | Erzähler | open_run_level | Collect den hoard coins and spend level-up points | the trampled hollow | 114/96 | 17.0 s |
| 70 | I follow the fresh tracks leading toward the torn weirs, where the flattened reeds shift, keeping low and downwind. | Erzähler | open_run_level | Hunt the fourth bog strider near the weirs | the torn weirs | 114/96 | 21.4 s |
| 71 | I sneak along the reed line to close the distance on the two striders by the water's edge, then strike them both with Fan of Blades, keeping… | Erzähler | open_run_level | Ambush the two smaller striders with AoE | the torn weirs | 114/96 | 18.2 s |
| 72 | I strike the two striders by the water's edge with Fan of Blades from my crouch, angling the spread to hit both and keep it off the big one … | Erzähler | open_run_level | Ambush both small striders with AoE | the torn weirs | 114/96 | 13.7 s |
| 73 | I stay low behind the brush hump and move across the open mud to close to SHORT range on the two striders at the water's edge, keeping the b… | Erzähler | open_run_level | Close into Fan of Blades range for the ambush | the torn weirs | 114/96 | 18.1 s |
| 74 | I strike both striders at the water's edge with Fan of Blades from my crouch, keeping the spread off the big one on the weir. | Erzähler | open_run_level | Ambush striders J and K at SHORT range with Fan of Blades | the torn weirs | 114/96 | 18.5 s |
| 75 | I stay hidden among the broken stakes near the carcasses and wait for the big strider to come down to feed, keeping downwind and ready to am… | Erzähler | open_run_level | Set up an ambush on the last bog strider | the torn weirs | 114/96 | 20.7 s |
| 76 | I strike the feeding big strider at SHORT range with Fan of Blades from my crouch, aiming to catch it before it lifts its head. | Erzähler | open_run_level | Ambush the last strider to finish the cull contract | the torn weirs | 114/96 | 17.2 s |
| 77 | #assign VIT 3 AGI 2 | System (Befehl) | open_run_level | Spend level-up stat points | the torn weirs | 114/96 | 2.5 s |
| 78 | I head back through the trampled hollow to the Guild hall in town and turn in the completed cull contract, 'Cull the Bog Striders at the Eel… | Erzähler | open_run_level | Turn in the completed cull contract at the Guild | Adventurers' Guild hall, Glassmere | 114/96 | 23.8 s |
| 79 | I ask the clerk what cull or retrieval contracts are on the board suitable for a Novice, and whether anyone in town buys chitin plates and v… | Erzähler | open_run_level | Check board and surplus buyers before lodging | Adventurers' Guild hall, Glassmere | 114/96 | 23.1 s |
| 80 | I take the Glimmerdeep Grotto level 1 contract slip from the board and ask the clerk to log it as active. | Erzähler | open_run_level | Accept the achievable Novice dungeon contract | Adventurers' Guild hall, Glassmere | 114/96 | 20.3 s |
| 81 | I head to Doss's broker shed by the south grain steps and ask his price for 27 bog strider chitin plates. | Erzähler | open_run_level | Sell surplus chitin plates to Doss | Doss's broker shed | 114/96 | 17.7 s |
| 82 | I accept Doss's offer of sixty-five copper for the twenty-seven plates and hand them over. | Erzähler | open_run_level | Sell chitin plates | Doss's broker shed | 114/96 | 15.1 s |
| 83 | I offer Doss the four bog strider venom glands and ask his price for them. | Erzähler | open_run_level | Sell remaining surplus loot before lodging | Doss's broker shed | 114/96 | 15.3 s |
| 84 | I accept Doss's offer of eight silver for the four venom glands and hand them over. | Erzähler | open_run_level | Sell venom glands, then lodge for the night | Doss's broker shed | 114/96 | 16.5 s |
| 85 | I head to the nearest inn and ask for a room for the night. | Erzähler | open_run_level | Lodge and recover before the Grotto contract | the Eel & Pitcher | 114/96 | 20.3 s |
| 86 | I buy the bed for the night and supper from the innkeeper, then go up to sleep until morning. | Erzähler | open_run_level | Lodge and recover | the Eel & Pitcher | 190/104 | 15.9 s |
| 87 | I assign my 5 free stat points: #assign AGI 3 PER 2 | Erzähler | open_run_level | Spend free stat points before heading to the Grotto | the Eel & Pitcher | 190/104 | 13.6 s |
| 88 | I leave the inn and head to Glimmerdeep Grotto to clear it, as my contract requires. | Erzähler | open_run_level | Travel to the Grotto for the active contract | Glimmerdeep Grotto | 190/104 | 19.8 s |
| 89 | I enter Glimmerdeep Grotto and proceed carefully into level 1. | Erzähler | open_run_level | Enter the dungeon to clear level 1 for the contract | Crystal-grazing chamber, Glimmerdeep level 1 | 190/104 | 21.4 s |
| 90 | I strike the nearest grazing beetle from behind with Razor Cut, staying out of reach of the other two for now. | Erzähler | open_run_level | Open the fight with a stealth-style single-target attack | Crystal-grazing chamber, Glimmerdeep level 1 | 190/104 | 15.0 s |
| 91 | I close the distance quietly to the nearest beetle and strike it from behind with Razor Cut. | Erzähler | open_run_level | Close range first, then attack | Crystal-grazing chamber, Glimmerdeep level 1 | 190/104 | 19.4 s |
| 92 | I use Fan of Blades on both beetles at SHORT range. | Engine (Menü/Rückfrage) | open_run_level | AoE both remaining beetles | Crystal-grazing chamber, Glimmerdeep level 1 | 190/104 | 5.9 s |
| 93 | I use Fan of Blades on Glass Beetle B and Glass Beetle C at SHORT range. | Engine (Menü/Rückfrage) | open_run_level | AoE both beetles, naming targets | Crystal-grazing chamber, Glimmerdeep level 1 | 190/104 | 4.7 s |
| 94 | I use Fan of Blades on Glass Beetle B, striking both beetles at SHORT range. | Erzähler | open_run_level | AoE both beetles with B as named target | Crystal-grazing chamber, Glimmerdeep level 1 | 190/104 | 13.4 s |
| 95 | #assign AGI 3 PER 2 | System (Befehl) | open_run_level | Spend level-up stat points | Crystal-grazing chamber, Glimmerdeep level 1 | 190/104 | 2.6 s |
| 96 | I continue down the sloping passage toward the slurping sound, moving quietly with my dagger ready. | Erzähler | open_run_level | Explore deeper into the grotto | Basin chamber | 190/104 | 26.0 s |
| 97 | I carefully fish the leather pouch out of the hardened film with my dagger and examine it. | Erzähler | open_run_level | Retrieve the lost pouch | Basin chamber | 190/104 | 23.3 s |
| 98 | I pocket the pouch and its contents, then take the taller cleft onward into the dark. | Erzähler | open_run_level | Continue clearing the grotto via the tall cleft | Dripping gallery | 190/104 | 18.7 s |
| 99 | I use Fan of Blades on Mineral Slime A, striking both slimes at SHORT range. | Erzähler | open_run_level | Clear the two slimes blocking the quest | Dripping gallery | 190/104 | 13.5 s |
| 100 | I continue past the dead slimes down the narrowing gallery into the dark, moving quietly with my dagger ready. | Erzähler | open_run_level | Keep clearing the grotto level toward the quest | Queen's basin chamber | 190/104 | 21.5 s |
| 101 | I ambush the Glimmer Queen with Fan of Blades from the passage mouth, staying at MEDIUM range. | Erzähler | open_run_level | Kill the boss with an ambush opening | Queen's basin chamber | 190/104 | 20.2 s |
| 102 | I move quietly along the wall toward the basin rim, circling wide of the beetle ranks, and once I reach SHORT range of the queen I strike he… | Erzähler | open_run_level | Close to SHORT range and attack the Glimmer Queen | Queen's basin chamber | 190/104 | 17.3 s |
| 103 | I move quickly across the open floor to the basin rim, closing to SHORT range of the Glimmer Queen, and strike her with Razor Cut. | Erzähler | open_run_level | Close to SHORT range and attack the boss | Queen's basin chamber | 190/104 | 18.2 s |
| 104 | I wade the two strides through the shallow pool to ENGAGED range of the Glimmer Queen and strike her with Razor Cut. | Erzähler | open_run_level | Close into the pool and attack the boss | Queen's basin chamber | 190/104 | 25.7 s |
| 105 | I strike the Glimmer Queen with Razor Cut at SHORT range. | Erzähler | open_run_level | Attack the boss now that she is in reach | Queen's basin chamber | 190/104 | 13.2 s |
| 106 | I throw Fan of Blades at the Glimmer Queen from the water's edge, targeting her alone. | Erzähler | open_run_level | Use ranged AoE skill to reach the boss across the deep water | Queen's basin chamber | 190/104 | 16.1 s |
| 107 | I throw Fan of Blades at the Glimmer Queen again from the water's edge, targeting her alone. | Erzähler | open_run_level | Finish the boss with the only skill that reaches her across the deep water | Queen's basin chamber | 190/104 | 16.5 s |
| 108 | #assign AGI 3 PER 2 | System (Befehl) | open_run_level | Spend the 10 free stat points | Queen's basin chamber | 190/104 | 2.7 s |
| 109 | I head back through the dripping gallery, leave the grotto, and travel to the Guild hall in Caelreth to turn in the Clear Glimmerdeep Grotto… | Erzähler | open_run_level | Turn in the cleared dungeon contract at the Guild hall | Adventurers' Guild hall, Glassmere | 190/104 | 30.3 s |
| 110 | I ask the clerk what contracts are posted on the board suitable for a Novice, and mention I have beetle chitin plates and snake parts to sel… | Erzähler | open_run_level | Find a new Guild contract and sell surplus loot | Adventurers' Guild hall, Glassmere | 190/104 | 29.3 s |
| 111 | I take the Bog Striders contract from the board and ask the clerk to accept it, then head to Marta's desk at the brokerage window to sell my… | Erzähler | open_run_level | Accept the standing cull contract and sell loot | brokerage desk | 190/104 | 16.9 s |
| 112 | I put the six glass beetle chitin plates and two venom glands on Marta's pan and ask what she'll pay for the lot. | Erzähler | open_run_level | Get a sell offer from Marta | brokerage desk | 190/104 | 16.0 s |
| 113 | I accept the offer and take the sixteen silver for the lot. | Erzähler | open_run_level | Sell loot to Marta | brokerage desk | 190/104 | 16.9 s |
| 114 | I sell Marta the banded water snake skin and fang too, then leave for the eel-weirs south of the walls past the mill leat to hunt bog stride… | Erzähler | open_run_level | Sell remaining loot and start the bog strider cull | brokerage desk | 190/104 | 20.2 s |
| 115 | I accept the eight silver for the skin and fang, then head out of the city to the eel-weirs south past the mill leat to hunt bog striders. | Erzähler | open_run_level | Sell remaining loot and start the bog strider cull | the eel-weirs of the Reed Flats | 190/104 | 40.7 s |
| 116 | I follow the fisher's warning and pick my way along the firm ground past the third weir toward the middle reed beds, keeping low and watchin… | Erzähler | open_run_level | Hunt bog striders for the cull contract | the eel-weirs of the Reed Flats | 190/104 | 18.0 s |
| 117 | I creep toward the flattened reeds where something big shifted and attack the bog strider there with Razor Cut. | Engine (Menü/Rückfrage) | open_run_level | Hunt bog striders for the cull contract | the eel-weirs of the Reed Flats | 190/104 | 6.4 s |
| 118 | I leave the fisher's camp and make my way south past the third weir to the middle reed beds where the bog striders were seen. | Erzähler | open_run_level | Move into the reed beds scene to engage the striders | the middle reed beds past the third weir | 190/104 | 21.5 s |
| 119 | I ready my dagger and attack the bog strider shifting in the flattened reeds with Razor Cut. | Engine (Menü/Rückfrage) | open_run_level | Engage the bog strider for the cull contract | the middle reed beds past the third weir | 190/104 | 5.1 s |
| 120 | I follow the flattened track toward the spot where the reeds shift, and call out a challenge to draw the bog strider out into the open. | Erzähler | open_run_level | Provoke the hidden bog strider into becoming a targetable actor | the shifting reeds | 190/104 | 21.6 s |
| 121 | I attack the bog strider with Razor Cut as it charges. | Erzähler | open_run_level | Fight the large bog strider for the cull contract | the shifting reeds | 190/104 | 16.0 s |
| 122 | I advance on the Bog Strider L to close into dagger range, and attack it with Razor Cut. | Erzähler | open_run_level | Close to ENGAGED and strike the strider | the shifting reeds | 190/104 | 14.2 s |
| 123 | I follow the flattened track back north to the fisher's camp and look for a place to sleep until morning. | Erzähler | open_run_level | Recover overnight after the fight | the fisher's camp | 190/104 | 25.1 s |
| 124 | I accept the fisherwoman's offer, eat an eel over the coals, and sleep in the smokehouse until morning. | Erzähler | open_run_level | Eat and sleep to recover | the fisher's camp | 200/104 | 19.1 s |
| 125 | I take the offered bread from the box and eat it, then follow the flattened track south into the standing reeds to hunt more bog striders fo… | Erzähler | open_run_level | Eat breakfast and continue the bog strider cull | the fisher's camp | 200/104 | 28.3 s |
| 126 | I follow the fresh eastern trail toward the stand of tall reeds, moving quietly, and search for the strider making the tapping sound. | Erzähler | open_run_level | Hunt another bog strider for the cull contract | the fisher's camp | 200/104 | 24.4 s |
| 127 | I take the fisher's advice and move quickly along the eastern trail toward the tall reed stand, not creeping, to reach the strider before it… | Erzähler | open_run_level | Approach the strider fast as the fisher advised | the tall reed stand | 200/104 | 20.2 s |
| 128 | I attack the Bog Strider M with Fan of Blades, staying clear of the reeds to the south so the second strider can't flank me. | Erzähler | open_run_level | Kill the strider quickly before its companion arrives | the tall reed stand | 200/104 | 15.2 s |
| 129 | I move into SHORT range of the Bog Strider M across the open pool, then attack it with Fan of Blades. | Erzähler | open_run_level | Close to weapon range, then use AoE on the strider | the tall reed stand | 200/104 | 14.8 s |
| 130 | #assign AGI 5 PER 5 | System (Befehl) | open_run_level | Spend level-up stat points | the tall reed stand | 200/104 | 2.7 s |
| 131 | I follow the sour fishy smell and tapping east into the taller reeds, searching for another bog strider to cull. | Erzähler | open_run_level | Continue the bog strider cull (2/5) | the drowned mound clearing | 200/104 | 19.0 s |
| 132 | I close to SHORT range on the Bog Strider N and attack it with Fan of Blades before it can call in another. | Erzähler | open_run_level | Kill strider 3 of 5 quickly | the drowned mound clearing | 200/104 | 14.2 s |
| 133 | I search the two quiet mounds for striders or loot, staying ready to strike with Fan of Blades if one rises. | Erzähler | open_run_level | Check the quiet mounds for the fifth strider | the drowned mound clearing | 200/104 | 19.5 s |
| 134 | I follow the answer call south through the reed-walls, hunting the fifth strider. | Erzähler | open_run_level | Find and kill strider 5 of 5 | the long drowned weir | 200/104 | 21.2 s |
| 135 | I stay in SHORT range and strike the Bog Strider O with Fan of Blades from behind while it tends the weir. | Erzähler | open_run_level | Kill the fifth strider to finish the cull | the long drowned weir | 200/104 | 15.2 s |
| 136 | With the fifth strider down, I head back through the reed-walls to the Guild hall in Caelreth to turn in the completed cull contract. | Erzähler | open_run_level | Return and turn in the bog strider cull | Adventurers' Guild hall, Glassmere | 200/104 | 17.5 s |
| 137 | I ask the clerk to re-check the roll against the contract slip, since the seal itself shows READY and all five striders were defeated at the… | Erzähler | open_run_level | Appeal the short count with the confirmed fifth kill | Adventurers' Guild hall, Glassmere | 200/104 | 22.9 s |
| 138 | I head back to the fisher's camp and ask the old man to come correct his count — the fifth strider fell at the south weir while he watched t… | Erzähler | open_run_level | Get the fisher to amend his report so the turn-in can complete | the fisher's camp | 200/104 | 27.8 s |
| 139 | I tell him the clerk just wants his statement plain and witnessed — I'll walk back with him to the Guild hall in Glassmere so he can say it … | Erzähler | open_run_level | Bring the fisher to the clerk to correct the count | the fisher's camp | 200/104 | 21.9 s |
| 140 | I head back out to the south weir and search the water's edge for the big strider's carcass — or the thing itself, if it's still alive. | Erzähler | open_run_level | Verify the fifth kill at the south weir so the count can close | the south weir | 200/104 | 19.5 s |
| 141 | I follow the drag-trail into the tall sedge toward the grating sound, dagger ready, looking for the wounded fifth strider. | – | open_run_level | Find and kill the wounded fifth strider | the south weir | 200/104 | 0.1 s **interrupted** |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 16 (notiert vor Zug 17): Contract confirmed ACTIVE (0/5). Board also offers a Grotto clear at recommended level 1 as a backup option.
- zu Zug 29 (notiert vor Zug 30): Narrator described strider D as the 'big one' and C as 'smaller', but the engine had D wounded and C still at SHORT; the engine panel is authoritative.
- zu Zug 33 (notiert vor Zug 34): XP 495/500 — one kill from level 6. HP 38/120 is badly wounded; will need recovery soon.
- zu Zug 35 (notiert vor Zug 36): Search for the fifth strider failed; 4/5 contract progress stands. HP 38/120 badly wounded, dusk approaching — recovery takes priority.
- zu Zug 38 (notiert vor Zug 39): Camp shop offers soup for 1 cp; free stat points 5 unspent.
- zu Zug 44 (notiert vor Zug 45): 5/5 striders defeated; contract ready for turn-in at the Guild.
- zu Zug 46 (notiert vor Zug 47): Payout and XP arrived at the camp already; Guild desk confirmed the filed slip. Level 7, 5 stat points to spend.
- zu Zug 47 (notiert vor Zug 48): Turn-in was already auto-completed at payout; contract slip filed, no manual turn-in needed.
- zu Zug 48 (notiert vor Zug 49): Turn-in was auto-completed; bounty on the big strider needs fishers to fund it first. Carrying 12 chitin plates and 2 venom glands — could sell surplus.
- zu Zug 52 (notiert vor Zug 53): It's 11:55, so midday is nearly here. The washerwoman sent someone to fetch Denna while staring Alaric down — possible threat to watch.
- zu Zug 56 (notiert vor Zug 57): Engine repeatedly refuses combat for lack of declared movement even when narration says I'm closing; must explicitly state closing to ENGAGED range.
- zu Zug 58 (notiert vor Zug 59): Contract paid 40 copper as promised; snake skin/fang retained as loot to sell. XP 620/700, close to level 8.
- zu Zug 69 (notiert vor Zug 70): Narrator said five chitin plates gained but HUD shows 18 total; #assign result not echoed separately but HUD confirms stats applied and 5 free points remain unspent.
- zu Zug 77 (notiert vor Zug 78): Cull confirmed 6/6 defeated; 27 chitin plates to sell as surplus in town.
- zu Zug 97 (notiert vor Zug 98): Pouch yielded a few coins and a worn name disc; no other trace of its owner. Dungeon panel says 1 of ? threats dealt with, so more remain on this level.
- zu Zug 103 (notiert vor Zug 104): HUD now shows the queen at MEDIUM, so closing brought her into reach; wading in should finish it.
- zu Zug 104 (notiert vor Zug 105): HUD now shows the queen at SHORT, so wading closed the gap despite the deep-water narration.
- zu Zug 105 (notiert vor Zug 106): Wading and Razor Cut cannot reach her; deep water blocks melee. Trying the ranged skill Fan of Blades instead — beetle ranks are already dead, so no friendly fire risk.
- zu Zug 107 (notiert vor Zug 108): HUD showed Free Stat Points 10 though the level-up granted 5; assigning per the HUD.
- zu Zug 115 (notiert vor Zug 116): Sell of snake skin/fang was already recorded and paid despite the NOT POSSIBLE lines; purse reflects it (7g4s1c).
- zu Zug 117 (notiert vor Zug 118): Attack failed because only Fisher A is in the active scene; must travel to the reed beds as a scene change first.
- zu Zug 126 (notiert vor Zug 127): Stealth roll failed because the fisher detected me; engine resolves only one action type per message, so multi-part commands get truncated.
- zu Zug 129 (notiert vor Zug 130): HUD shows 10 free points though engine message said +5; assigning 10 per HUD.
- zu Zug 135 (notiert vor Zug 136): Engine quest panel still shows 4/5 despite the defeat of Bog Strider O; will verify the count at turn-in.
- zu Zug 139 (notiert vor Zug 140): HUD shows 4/5 despite Strider O's defeat — the engine may not have recorded it; the carcass may not exist.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t8 | 8 | 1 | – | nein | 1 | gewonnen, 60 XP |
| enc.t18 | 19 | 1 | – | nein | 1 | gewonnen, 300 XP |
| enc.t20 | 22 | 1 | – | nein | 1 | gewonnen, 300 XP |
| enc.t25 | 28 | 1 | – | nein | 1 | gewonnen, 420 XP |
| enc.t29 | 32 | 1 | – | nein | 1 | gewonnen, 300 XP |
| enc.t37r | 42 | 1 | – | nein | 1 | gewonnen, 300 XP |
| enc.t50 | 57 | 1 | – | nein | 1 | gewonnen, 60 XP |
| enc.t56 | 63 | 1 | – | nein | 1 | gewonnen, 420 XP |
| enc.t59 | 67 | 2 | – | nein | 2 | gewonnen, 605 XP |
| enc.t66 | 74 | 2 | – | ja | 2 | gewonnen, 480 XP |
| enc.t68 | 76 | 1 | – | ja | 1 | gewonnen, 435 XP |
| enc.t82 | 91 | 3 | – | nein | 3 | gewonnen, 480 XP |
| enc.t87 | 99 | 2 | – | nein | 2 | gewonnen, 300 XP |
| enc.t94 | 106 | 1 | – | nein | 1 | gewonnen, 1050 XP |
| enc.t107 | 122 | 1 | – | nein | 1 | gewonnen, 300 XP |
| enc.t114 | 129 | 1 | – | nein | 1 | gewonnen, 365 XP |
| enc.t116 | 132 | 1 | – | nein | 1 | gewonnen, 240 XP |
| enc.t119 | 135 | 1 | – | nein | 1 | gewonnen, 435 XP |

## Quests

- **Cull the Reed Flat Striders** — active (Zug 16) → completed (Zug 46)
  - Aufgabe: Kill 5 bog striders at the eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 5 bog striders killed at the eel-weirs of the Reed Flats.
- **Take the Old Boar of Bramble Orchard** — expired (Zug 49)
  - Aufgabe: Kill 1 the old tusked boar of Bramble Orchard at the press yard at Bramble Orchard. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the old tusked boar of Bramble Orchard killed at the press yard at Bramble Orchard.
- **Thin the Howlers of Coldwell Pines** — expired (Zug 49)
  - Aufgabe: Kill 6 pine howlers at the kiln clearings of the Coldwell Pines. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 6 pine howlers killed at the kiln clearings of the Coldwell Pines.
- **Take the Garden Serpent of Millrace Lane** — active (Zug 6) → completed (Zug 11)
  - Aufgabe: Kill 1 banded water snake at the washing stones on Millrace Lane. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 banded water snake killed at the washing stones on Millrace Lane.
- **Clear Glimmerdeep Grotto Level 1** — expired (Zug 49), Dungeon loc.glimmerdeep_grotto Ebene 1
  - Aufgabe: Clear level 1 of Glimmerdeep Grotto. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Glimmerdeep Grotto is clear.
- **Snake at the Washing Stones** — active (Zug 50) → completed (Zug 58)
  - Aufgabe: Kill 1 banded water snake at the washing stones on Millrace Lane. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 banded water snake killed at the washing stones on Millrace Lane.
- **Cull the Bog Striders at the Eel-Weirs** — active (Zug 60) → completed (Zug 78)
  - Aufgabe: Kill 6 bog striders at the eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 6 bog striders killed at the eel-weirs of the Reed Flats.
- **The Old Tusker of Bramble Orchard** — expired (Zug 110)
  - Aufgabe: Kill 1 old tusked boar at the press yard at Bramble Orchard. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 old tusked boar killed at the press yard at Bramble Orchard.
- **Thin the Pine Howlers of Coldwell** — expired (Zug 110)
  - Aufgabe: Kill 4 pine howlers at the kiln clearings of the Coldwell Pines. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 pine howlers killed at the kiln clearings of the Coldwell Pines.
- **Clear Glimmerdeep Grotto Level 1** — active (Zug 80) → completed (Zug 109), READY, Dungeon loc.glimmerdeep_grotto Ebene 1
  - Aufgabe: Clear level 1 of Glimmerdeep Grotto. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Glimmerdeep Grotto is clear.
- **Cull the Bog Striders at the Eel-Weirs** — active (Zug 111)
  - Aufgabe: Kill 5 bog strider at the eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 5 bog strider killed at the eel-weirs of the Reed Flats.

## Auffälligkeiten

- Zug 141 (Runner/UI): interrupted
- Zug 10, Nachricht 19 (planner_repaired): the planner's first answer needed a repair
- Zug 42, Nachricht 84 (extraction_repaired): the extractor's first answer needed a repair
- Zug 46, Nachricht 92 (extraction_repaired): the extractor's first answer needed a repair
- Zug 53, Nachricht 105 (planner_repaired): the planner's first answer needed a repair
- Zug 53, Nachricht 106 (extraction_repaired): the extractor's first answer needed a repair
- Zug 65, Nachricht 130 (extraction_repaired): the extractor's first answer needed a repair
- Zug 87, Nachricht 173 (stat_words): the player spent Stat Points in words, not with #assign; nothing was assigned (for review: did the story tell them as done?)
- Zug 96, Nachricht 192 (extraction_repaired): the extractor's first answer needed a repair
- Zug 99, Nachricht 197 (group_turns): fight enc.t87:  of the group never acted on a turn of its own
- Zug 100, Nachricht 200 (dungeon_foe_refused): the narrator brought a foe the Dungeon's engine did not (glass beetle): refused, no fight (Patch 8.4.1 guard)
- Zug 110, Nachricht 220 (extraction_repaired): the extractor's first answer needed a repair
- Zug 113, Nachricht 225 (planner_repaired): the planner's first answer needed a repair
- Zug 115, Nachricht 229 (planner_repaired): the planner's first answer needed a repair
- Zug 138, Nachricht 275 (planner_repaired): the planner's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 29× keine gültige JSON-Entscheidung (Züge 2, 7, 8, 14, 18, 26, 38, 44, 48, 52, 54, 62, 66, 69, 71, 72, 73, 75, 77, 95, 96, 99, 109, 117, 119, 123, 137, 138, 141)
- Server: Generation failed AbortError: The operation was aborted.

System-Panels: CLARIFY 1, NOT TAKEN 3, REFUSED 1, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: guild_canon_price 1, engine_owned_fact 18, ambient 3, guild_payout 1, world_rule 6, attack_commitment 4, engine_owned_combat 1, no_go 2, scene_context 4, entity_fact 4, coin_evidence 1, quest_count 3, coin_already_received 2, group_unclear 2, dungeon_foe 1, guild_completion 1, engine_owned_memory 1, npc_presence 1, offer 1, time_cap 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 29/141 Erstantworten ungültig (20.6 %); 29 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 133 | 5 | 2.3 s | 3.7 s | 12247 | 9973 | 79 | – | stop 132 | 0 |
| board | 3 | 0 | 9.1 s | 10.5 s | 2611 | 2302 | 1145 | – | stop 3 | 0 |
| narrator | 122 | 0 | 8.1 s | 10.8 s | 11234 | 8681 | 390 | – | stop 122 | 0 |
| extract | 128 | 6 | 5.0 s | 8.7 s | 12697 | 9738 | 330 | – | stop 128 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 51:26 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 14.2 s) | 0:28 min |
| 141 Züge, Spiel (Senden bis HUD nach der Extraktion) | 41:51 min — Median 18.2 s, p90 26.6 s, max 40.7 s |
| 141 Züge, Spieler-Entscheidung | 6:39 min — Median 2.3 s, 29 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 6:21 min / 0:29 min / 17:20 min / 12:00 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 20.6 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 13:45 min, 80 Züge ≈ 27:31 min (ohne Einrichtung) |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
