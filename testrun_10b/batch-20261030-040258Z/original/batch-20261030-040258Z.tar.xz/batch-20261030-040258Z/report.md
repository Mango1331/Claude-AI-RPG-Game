# Avereth – 3 natürliche Testkampagnen

Status: **interrupted**. Serie abgeschlossen bedeutet, dass die Läufe beendet sind; es bedeutet nicht 3 bestandene Level-15-Abnahmen.

| Nr. | Profil | Seed | Eingaben | Level | Ende | Originalbericht |
|---|---|---:|---:|---:|---|---|
| 1 | guild-warrior | 1040509681 | 168 | 15 | done | [report.md](001-guild-warrior/20261030-040259Z-current_test/report.md) |
| 2 | guild-mage | 1040509682 | 106 | 15 | done | [report.md](002-guild-mage/20261030-050631Z-current_test/report.md) |
| 3 | guild-rogue | 1040509683 | 141 | 13 | process_error | [report.md](003-guild-rogue/20261030-054454Z-current_test/report.md) |

