# Avereth Live-Test 20261030-082423Z-current_test

## Kurzfassung

- **Laufprofil:** guild-warrior; Startklasse Warrior, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** abgebrochen: Limit erreicht — 200 turns
- **Etappen:** 1/3 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht) · class_accepted (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 11. Sicherheitsgrenzen: 200 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** Level 7, 265 XP seit Levelaufstieg, 104 cp, HP 220, MP 104; Ort loc.boar_wallow_hollow. Ausrüstung und Skills stehen in evaluation.json → progression.checkpoint.
- **Charakter:** warrior (warrior.cleave, warrior.quick_slash) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 through E class evolution“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: pragmatic adventurer: sell surplus loot and invest in useful equipment and techniques
- **Züge:** 200 · **Dauer:** 79:03 min · **LLM-Aufrufe der Engine/des Erzählers:** 549
- **Beobachtete Abdeckung:** 21 unterschiedliche gebuchte Reiseziele · 12 Kämpfe · 5 Verkäufe (345 cp Umsatz, ohne Questzahlungen/Geschenke) · 5 Ausrüstungswechsel · 4 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 17
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.123 |
| Git | c300f3d77262 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 15.3 s |
| Browser | chrome 156.0.8078.49 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261030-082423Z-current_test“, Seed 685958792 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |
| class_accepted | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | I choose Warrior. | Engine (Menü/Rückfrage) | creation_complete | Select base class | public roadside verge outside Alderwatch | 90/84 | 2.2 s |
| 2 | I select Cleave and Quick Slash as my two starting skills. | Engine (Menü/Rückfrage) | creation_complete | Complete character creation | public roadside verge outside Alderwatch | 95/84 | 2.1 s |
| 3 | I walk through the city gate into Alderwatch and head for the Adventurers' Guild to register and look at the contract board. | Erzähler | open_run_level | Enter town and find Guild contracts | Adventurers' Guild hall, Alderwatch | 95/84 | 47.5 s |
| 4 | I pay the two silver and sign the register to complete my Guild registration. | Erzähler | open_run_level | Register with the Guild, then pick a Novice contract | Adventurers' Guild hall, Alderwatch | 95/84 | 20.0 s |
| 5 | I take the serpent slip to the clerk and ask her to make 'A Serpent at the Millrace' active for me. | Erzähler | open_run_level | Accept the novice serpent contract | Adventurers' Guild hall, Alderwatch | 95/84 | 14.8 s |
| 6 | I leave the Guild and head east along the river to the Millrace grist mill to hunt the banded water serpent. | Erzähler | open_run_level | Travel to the mill and hunt the serpent for the active contract | the Millrace grist mill sluice, a short walk east of Alderwatch | 95/84 | 19.7 s |
| 7 | I move along the near bank toward the mudflat, keeping out of the water, and watch the reeds and flat for the serpent. | Erzähler | open_run_level | Approach and hunt the banded water serpent for the active contract | the mudflat along the near bank | 95/84 | 18.8 s |
| 8 | I draw my longsword and advance onto the mudflat toward the serpent, ready to strike the moment it moves at me. | Erzähler | open_run_level | Engage the serpent for the contract | the mudflat along the near bank | 95/84 | 16.7 s |
| 9 | I rush in and use Cleave on the serpent as it bunches to strike. | Erzähler | open_run_level | Engage the serpent with Cleave | the mudflat along the near bank | 95/84 | 17.8 s |
| 10 | I close the remaining distance and engage the serpent, then swing Cleave at it once in range. | Erzähler | open_run_level | Engage the serpent and attack with Cleave | the mudflat along the near bank | 95/84 | 22.4 s |
| 11 | I back off the mudflat and wade into the channel's shallows along the near bank, circling through the firmer water to get within reach of th… | Erzähler | open_run_level | Flank the serpent through the channel shallows where the mud won't slow me | the mudflat along the near bank | 95/84 | 18.7 s |
| 12 | I close the fifteen paces through the shallows and engage the serpent, swinging Cleave the moment I'm in reach. | Erzähler | open_run_level | Engage the serpent at MEDIUM range and attack with Cleave | the mudflat along the near bank | 95/84 | 16.6 s |
| 13 | I meet the strike head-on and swing my longsword at the serpent's neck as it reaches me. | Erzähler | open_run_level | Engage and attack the striking serpent with Basic Attack | the mudflat along the near bank | 95/84 | 19.8 s |
| 14 | I wade back to the bank, skin the serpent for its hide, then head up to the millhouse to greet Maren. | Erzähler | open_run_level | Loot the kill and meet the miller | the millhouse yard | 95/84 | 26.8 s |
| 15 | I shake Maren's hand and accept: "A meal and a dry fire would be welcome — the serpent cost me little more than a wet boots and a good swing… | Erzähler | open_run_level | Accept Maren's hospitality and report on the fight | the millhouse yard | 95/84 | 20.4 s |
| 16 | "Nearer five than ten — big, but no whale of a garter snake," I tell Maren, finish the meal, then take the lane back to Alderwatch and head … | Erzähler | open_run_level | Report to Maren, then turn in the contract at the Alderwatch Guild hall | Adventurers' Guild hall, Alderwatch | 95/84 | 22.3 s |
| 17 | #assign STR 2 VIT 2 WIL 1 | System (Befehl) | open_run_level | Spend Level 2 free stat points | Adventurers' Guild hall, Alderwatch | 95/84 | 2.2 s |
| 18 | I ask the clerk where to find a good smith in Alderwatch, then head over to check both weapons and armour. | Erzähler | open_run_level | Find a smith and shop for gear upgrades | Harl Bexley's smithy | 95/84 | 18.8 s |
| 19 | "Sword and armor, both," I say. "Show me what you have on the wall for a Novice-rank longsword and heavy armor, with prices — and what would… | Erzähler | open_run_level | Shop for weapon and armour upgrades, ask about selling serpent fangs | Harl Bexley's smithy | 95/84 | 19.1 s |
| 20 | "The common heavy plate, then," I say, handing over 64 copper, "and here are the two fangs for your two silver." Once the deal is struck, I … | Erzähler | open_run_level | Buy common heavy plate for 64 cp and sell the serpent fangs for 2 silver, then equip the a… | Harl Bexley's smithy | 95/84 | 19.7 s |
| 21 | "Would you take my old starter heavy armor and the serpent skin off my hands too? Name me a price for both." | Erzähler | open_run_level | Sell surplus gear to Bexley | Harl Bexley's smithy | 95/84 | 18.5 s |
| 22 | "Ten silver the pair, done," I say, handing over the starter armor and serpent skin. | Erzähler | open_run_level | Sell surplus gear for 10 silver | Harl Bexley's smithy | 95/84 | 37.3 s |
| 23 | I lay the starter heavy armor on the counter. "There's the suit — four silver, as agreed." | Erzähler | open_run_level | Complete the agreed 10 silver sale of armor and serpent skin | Harl Bexley's smithy | 95/84 | 19.6 s |
| 24 | #audit | System (Befehl) | open_run_level | Verify the 10 silver sale was recorded, since HUD shows only 3s1c | Harl Bexley's smithy | 95/84 | 2.2 s |
| 25 | #bag | System (Befehl) | open_run_level | Check inventory and coin before redoing the sale that the audit rejected | Harl Bexley's smithy | 95/84 | 2.2 s |
| 26 | I hold up the starter armor and the serpent skin. "Before I go — what will you actually pay me for these two, here and now?" | Erzähler | open_run_level | Get a confirmed System-recognized buy offer before selling | Harl Bexley's smithy | 95/84 | 15.6 s |
| 27 | "Ten the pair, done," I say, handing over the starter armor and the serpent skin. | Erzähler | open_run_level | Complete the confirmed 10 silver sale with Bexley | Harl Bexley's smithy | 95/84 | 34.2 s |
| 28 | #audit | System (Befehl) | open_run_level | Verify whether the 10 silver sale registered, since HUD still shows 3 Silver 1 Copper | Harl Bexley's smithy | 95/84 | 2.2 s |
| 29 | #bag | System (Befehl) | open_run_level | Confirm actual inventory and coin after the audit rejection | Harl Bexley's smithy | 95/84 | 2.1 s |
| 30 | I give up on the coin discrepancy and leave the smithy, heading to the Guild hall to look for a new contract from the board. | Erzähler | open_run_level | Continue to Guild contracts despite the unresolved coin desync | Adventurers' Guild hall, Alderwatch | 95/84 | 15.4 s |
| 31 | "The quarry boars, please — book Thin the Quarry Boars out for me." | Erzähler | open_run_level | Accept a Novice contract from the board | Adventurers' Guild hall, Alderwatch | 95/84 | 19.7 s |
| 32 | I head out the Northgate and follow the quarry road toward the woods, looking for the tusked quarry boars. | Erzähler | open_run_level | Travel to the contract site and hunt the boars | the woods along the Greyvein quarry forest road | 95/84 | 21.0 s |
| 33 | I step clear of the track and hold my ground, watching to see what emerges from the ferns behind the fleeing boar. | Erzähler | open_run_level | Let the fleeing boar pass and identify the unseen pursuer before committing to a fight | the woods along the Greyvein quarry forest road | 95/84 | 20.2 s |
| 34 | I strike the predator with Quick Slash as it reaches me. | Erzähler | open_run_level | Attack the predator with Quick Slash | the woods along the Greyvein quarry forest road | 95/84 | 18.5 s |
| 35 | I step in to engage and strike it with Quick Slash. | Erzähler | open_run_level | Close to ENGAGED and attack the predator | the woods along the Greyvein quarry forest road | 95/84 | 23.1 s |
| 36 | I advance on the tusked quarry boar and strike it with Cleave. | Erzähler | open_run_level | Continue the boar-thinning contract by engaging the remaining quarry boar | the woods along the Greyvein quarry forest road | 95/84 | 17.5 s |
| 37 | I keep advancing on the tusked quarry boar, and as soon as I can reach it, I strike it with Cleave. | Erzähler | open_run_level | Close distance and engage the boar to continue the contract hunt | the woods along the Greyvein quarry forest road | 95/84 | 22.8 s |
| 38 | I advance the last few paces on the boar standing its ground and strike it with Cleave the moment I can reach it. | Erzähler | open_run_level | Close to ENGAGED and attack the boar | the woods along the Greyvein quarry forest road | 83/84 | 19.9 s |
| 39 | I strike the wounded boar with Cleave again while it stands in the arc. | Erzähler | open_run_level | Finish the quarry boar with Cleave | the woods along the Greyvein quarry forest road | 69/84 | 17.0 s |
| 40 | I finish the crippled boar with a Basic Attack. | Erzähler | open_run_level | Kill the quarry boar to complete the contract hunt | the woods along the Greyvein quarry forest road | 69/84 | 15.1 s |
| 41 | #assign VIT 3 AGI 2 | System (Befehl) | open_run_level | Spend level-up stat points on survivability and initiative | the woods along the Greyvein quarry forest road | 69/84 | 2.2 s |
| 42 | I follow the sound uphill and search the deeper timber for the second tusked quarry boar. | Erzähler | open_run_level | Continue the boar-thinning contract toward 4 kills | boar shelf in the older timber | 69/84 | 20.2 s |
| 43 | I approach the rooting boar quietly from downwind and strike it with Cleave as soon as I can reach it. | Erzähler | open_run_level | Engage the second boar | boar shelf in the older timber | 69/84 | 21.0 s |
| 44 | I close the remaining distance to the boar and engage it, striking with Cleave once it is ENGAGED. | Erzähler | open_run_level | Close to ENGAGED and attack boar B | boar shelf in the older timber | 69/84 | 18.9 s |
| 45 | I charge straight at the boar and strike it with Basic Attack as soon as I reach melee range. | Erzähler | open_run_level | Close to ENGAGED and attack boar B | boar shelf in the older timber | 69/84 | 14.4 s |
| 46 | I walk steadily toward the boar across the shelf until it is ENGAGED, keeping my sword ready for its charge. | Erzähler | open_run_level | Close to ENGAGED with boar B as its own confirmed step | boar shelf in the older timber | 69/84 | 18.6 s |
| 47 | I keep walking toward the boar until it is ENGAGED, then strike it with Cleave. | Erzähler | open_run_level | Close to ENGAGED with boar B and attack | boar shelf in the older timber | 69/84 | 18.1 s |
| 48 | I advance the last ten paces straight at the boar until it is ENGAGED. | Erzähler | open_run_level | Close to ENGAGED with boar B | boar shelf in the older timber | 58/84 | 15.7 s |
| 49 | I strike the boar with Cleave. | Erzähler | open_run_level | Attack ENGAGED boar B | boar shelf in the older timber | 58/84 | 17.8 s |
| 50 | I strike the boar again with Cleave. | Erzähler | open_run_level | Finish the ENGAGED boar with Cleave | boar shelf in the older timber | 46/84 | 13.8 s |
| 51 | I finish the boar with Quick Slash. | Erzähler | open_run_level | Kill ENGAGED boar B at 21 HP | boar shelf in the older timber | 46/84 | 16.0 s |
| 52 | #assign VIT 3 STR 2 | System (Befehl) | open_run_level | Spend level-up stat points on VIT and STR | boar shelf in the older timber | 46/84 | 2.2 s |
| 53 | I collect the boar's hide and tusk, then start down the quarry road toward the millhouse where Maren offered a meal and dry fire, and on the… | Erzähler | open_run_level | Loot, then head toward settlement to recover and sell | the Millrace millhouse | 46/84 | 31.0 s |
| 54 | I greet Maren from the gate, keep clear of the dog, and accept her offer of a meal and dry fire. | Erzähler | open_run_level | Recover at the millhouse | the Millrace millhouse | 46/84 | 20.5 s |
| 55 | I eat the stew by the fire and accept Maren's offer to tend my wounds with her thread and salve. | Erzähler | open_run_level | Recover HP before returning to the hunt | the Millrace millhouse | 46/84 | 26.8 s |
| 56 | I thank Maren and sleep by the fire until morning. | Erzähler | open_run_level | Recover HP overnight | the Millrace millhouse | 165/88 | 19.9 s |
| 57 | I eat the porridge and thank Maren, then head back up the quarry road to finish the last two boars. | Erzähler | open_run_level | Complete the boar contract | the woods along the Greyvein quarry forest road | 165/88 | 23.6 s |
| 58 | I back against the oak so neither boar can get behind me, then meet the closer one with Cleave as it charges. | Erzähler | open_run_level | Fight the last two boars defensively | the woods along the Greyvein quarry forest road | 165/88 | 16.2 s |
| 59 | I hold my ground at the oak and strike the sow with Basic Attack as she charges. | Erzähler | open_run_level | Engage the nearer boar and attack | the woods along the Greyvein quarry forest road | 165/88 | 18.3 s |
| 60 | I push off the oak and charge the sow, closing to her flank, then swing my longsword at her as I come into range. | Erzähler | open_run_level | Close to ENGAGED with boar C and attack | the woods along the Greyvein quarry forest road | 165/88 | 19.0 s |
| 61 | I sprint straight at the sow, close the distance until we are engaged, then swing my longsword at her. | Erzähler | open_run_level | Close to ENGAGED with boar C and attack | the woods along the Greyvein quarry forest road | 165/88 | 17.4 s |
| 62 | I turn back toward the oak and face the closer boar D, keeping my back protected, then swing my longsword at it once it is in range. | Erzähler | open_run_level | Engage boar D at SHORT range and attack | the woods along the Greyvein quarry forest road | 165/88 | 19.4 s |
| 63 | I step in toward boar D, closing the ten paces until we are engaged, then swing my longsword at it. | Erzähler | open_run_level | Close to ENGAGED with boar D and attack | the woods along the Greyvein quarry forest road | 150/88 | 17.0 s |
| 64 | I press the attack and swing my longsword at the wounded boar with Basic Attack. | Erzähler | open_run_level | Kill boar D while engaged | the woods along the Greyvein quarry forest road | 134/88 | 20.7 s |
| 65 | I finish the wounded boar with Quick Slash. | Erzähler | open_run_level | Kill boar D while engaged | the woods along the Greyvein quarry forest road | 119/88 | 18.2 s |
| 66 | I strike the dying boar again with Basic Attack to finish it. | Erzähler | open_run_level | Kill boar D | the woods along the Greyvein quarry forest road | 119/88 | 22.9 s |
| 67 | I level my sword at the sow and advance across the clearing toward her, ready to meet her charge. | Erzähler | open_run_level | Close with the sow to finish the fourth boar | the woods along the Greyvein quarry forest road | 119/88 | 13.3 s |
| 68 | I assign my five free stat points: three to AGI and two to WIL. | Erzähler | open_run_level | Spend pending stat points, then finish the sow | the woods along the Greyvein quarry forest road | 119/88 | 14.1 s |
| 69 | #assign AGI 3 WIL 2 | System (Befehl) | open_run_level | Spend free stat points via the command, then fight the sow | the woods along the Greyvein quarry forest road | 119/88 | 2.5 s |
| 70 | I hold my ground and swing my longsword at the sow with Cleave as she charges. | Erzähler | open_run_level | Finish the fourth boar to complete the contract | the woods along the Greyvein quarry forest road | 119/88 | 13.6 s |
| 71 | I step forward to meet her charge and strike with Basic Attack the moment she closes. | Erzähler | open_run_level | Engage the sow and finish the fourth boar | the woods along the Greyvein quarry forest road | 119/88 | 15.7 s |
| 72 | I rush the remaining distance and strike the sow with Basic Attack as soon as she is engaged. | Erzähler | open_run_level | Close to ENGAGED range and finish the fourth boar | the woods along the Greyvein quarry forest road | 119/88 | 13.2 s |
| 73 | I strike the sow with Basic Attack now that she is within reach. | Erzähler | open_run_level | Finish the fourth boar at SHORT range | the woods along the Greyvein quarry forest road | 119/88 | 17.6 s |
| 74 | I close the remaining distance and engage the sow, then strike her with Basic Attack the moment I am in range. | Erzähler | open_run_level | Finish the fourth boar | the woods along the Greyvein quarry forest road | 119/88 | 35.5 s |
| 75 | I strike the charging sow with Basic Attack now that she is engaged and inside my reach. | Erzähler | open_run_level | Finish the fourth boar at ENGAGED range | the woods along the Greyvein quarry forest road | 109/88 | 25.8 s |
| 76 | I finish her with Quick Slash. | Erzähler | open_run_level | Kill the fourth boar to complete the contract | the woods along the Greyvein quarry forest road | 99/88 | 15.7 s |
| 77 | I finish her with Basic Attack. | Erzähler | open_run_level | Kill the fourth boar to complete the contract | the woods along the Greyvein quarry forest road | 99/88 | 18.2 s |
| 78 | #assign VIT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up points, then head back to turn in the contract | the woods along the Greyvein quarry forest road | 99/88 | 2.5 s |
| 79 | I head back along the quarry road toward the Guild hall to turn in the completed contract, selling my surplus hides and tusks on the way if … | Erzähler | open_run_level | Turn in Thin the Quarry Boars and sell surplus loot | Adventurers' Guild hall, Alderwatch | 99/88 | 37.1 s |
| 80 | I bring out four boar hides, five boar tusks, the predator pelt and two fangs and ask him to count the total. | Erzähler | open_run_level | Sell surplus loot at quoted prices | Adventurers' Guild hall, Alderwatch | 99/88 | 17.6 s |
| 81 | I accept the offer and sell him all of it for eighty-five copper. | Erzähler | open_run_level | Sell surplus loot at the quoted price | Adventurers' Guild hall, Alderwatch | 99/88 | 20.5 s |
| 82 | I walk back to the part-buyer's awning on the market street and lay out the four boar hides, five tusks, predator pelt and two fangs for him… | Erzähler | open_run_level | Sell surplus loot at the merchant's awning | part-buyer's awning | 99/88 | 21.8 s |
| 83 | I accept his offer and sell him the whole lot for eighty-five copper. | Erzähler | open_run_level | Sell surplus loot at the merchant's open offer | part-buyer's awning | 99/88 | 23.5 s |
| 84 | "Done — eighty-five the lot," I say, and push the four boar hides, five tusks, predator pelt and two fangs across the counter to him, asking… | Erzähler | open_run_level | Close the loot sale with explicit acceptance | part-buyer's awning | 99/88 | 15.6 s |
| 85 | I answer the buyer that I skinned it myself, then head for Bexley's smithy to see what weapon and armour upgrades he has in stock and at wha… | Erzähler | open_run_level | Gear check at smithy after loot sale | Harl Bexley's smithy | 99/88 | 19.1 s |
| 86 | "The fine longsword and the fine plate armor, Bexley — two gold and two silver the pair?" I say, and count out the coin if he accepts. | Erzähler | open_run_level | Buy weapon and armour upgrades | Harl Bexley's smithy | 99/88 | 18.7 s |
| 87 | I accept the confirmed offer and buy the fine longsword and fine plate armor pair for seventy-two copper, then equip both. | Erzähler | open_run_level | Buy and equip confirmed gear upgrades | Harl Bexley's smithy | 99/88 | 22.4 s |
| 88 | "Then fit me proper now, Bexley — I'll pay for the padding too. Fit the new plate and strap the fine longsword at my hip so I leave wearing … | Erzähler | open_run_level | Get fitted and actually equip the purchased gear | Harl Bexley's smithy | 99/88 | 20.7 s |
| 89 | I take the made-up gambeson at eight silver, pay Bexley, and have him fit it under the plate so I leave wearing the full set with the fine l… | Erzähler | open_run_level | Buy the gambeson and complete the fitting | Harl Bexley's smithy | 99/88 | 28.0 s |
| 90 | I leave the old plate with Bexley as used stock and head for Maren's millhouse to take him up on the stew and a dry spot to rest until my wo… | Erzähler | open_run_level | Recover HP at the millhouse before the next contract | Maren's millhouse | 99/88 | 29.7 s |
| 91 | I accept Maren's offer, sit by the fire, eat the stew, and rest at the millhouse until my wounds mend. | Engine (Menü/Rückfrage) | open_run_level | Eat, rest, and recover HP at the millhouse | Maren's millhouse | 99/88 | 9.7 s |
| 92 | I rest here at the millhouse until evening, eating the stew and letting my wounds mend by the fire. | Erzähler | open_run_level | Book a named rest duration and recover HP | Maren's millhouse | 210/104 | 25.1 s |
| 93 | #assign STR 2 VIT 2 AGI 1 | System (Befehl) | open_run_level | Spend the five free stat points before the next contract | Maren's millhouse | 210/104 | 2.6 s |
| 94 | I tell Maren the serpent story over supper — the reeds, the strike, and what it cost me — then ask whether he knows anyone in Alderwatch pay… | Erzähler | open_run_level | Share the story and scout the next contract lead | Maren's millhouse | 210/104 | 24.1 s |
| 95 | I thank Maren for the supper and bed down by the millhouse fire, sleeping until morning. | Erzähler | open_run_level | Sleep overnight at the millhouse to finish recovery | Maren's millhouse | 220/104 | 20.5 s |
| 96 | I set out on the millrace road back to Alderwatch and head for the Guild hall to look over the contract board. | Erzähler | open_run_level | Return to Alderwatch and pick a new Guild contract | Adventurers' Guild hall, Alderwatch | 220/104 | 22.8 s |
| 97 | I take the Boars on the Quarry Road contract and ask the clerk to mark it active. | Erzähler | open_run_level | Accept the 140 cp boar contract | Adventurers' Guild hall, Alderwatch | 220/104 | 18.5 s |
| 98 | I head out the north gate and walk the Greyvein quarry road toward the boar woods. | Erzähler | open_run_level | Travel to the boar hunt area | the woods along the Greyvein quarry forest road | 220/104 | 17.7 s |
| 99 | I follow the game trail in toward the rooting sign, sword drawn, and move toward the crack-crack sound cautiously. | Erzähler | open_run_level | Hunt the quarry boars | boar wallow hollow | 220/104 | 30.5 s |
| 100 | I back away slowly off the trail toward the ditch, sword up, keeping the birch tangle between me and the sow — I only need four kills, not a… | Erzähler | open_run_level | Disengage from the whole sounder and hunt boars one at a time | boar wallow hollow | 220/104 | 19.1 s |
| 101 | I move along the ditch to the second trail toward the quarry terraces and follow the thinner sign to find a boar alone. | Erzähler | open_run_level | Hunt an isolated boar instead of the whole sounder | boar bed at the quarry edge | 220/104 | 21.7 s |
| 102 | I creep up on the sleeping boar and strike at its neck with my sword before it can rise. | Erzähler | open_run_level | Ambush the isolated boar for the contract kill | boar bed at the quarry edge | 220/104 | 20.1 s |
| 103 | I set my feet and meet the wounded boar's charge, swinging my sword at its neck with Quick Slash. | Erzähler | open_run_level | Fight the wounded boar for the contract kill | boar bed at the quarry edge | 220/104 | 13.9 s |
| 104 | I brace and step in to meet its charge, swinging my sword at its neck as it closes the last stride. | Engine (Menü/Rückfrage) | open_run_level | Close into ENGAGED and strike the wounded boar | boar bed at the quarry edge | 220/104 | 6.1 s |
| 105 | I step in to meet its charge, swinging my sword at its neck with Quick Slash as it closes the last stride. | Erzähler | open_run_level | Answer skill clarification and strike the wounded boar | boar bed at the quarry edge | 220/104 | 15.6 s |
| 106 | I close the final stride to ENGAGED with the boar and swing my sword at its neck with a Basic Attack as it drives in. | Erzähler | open_run_level | Close to ENGAGED and strike the wounded boar | boar bed at the quarry edge | 205/104 | 22.9 s |
| 107 | I twist the blade free and finish the dying sow with a Quick Slash to the throat, then immediately back away up the rocks toward the quarry … | Erzähler | open_run_level | Kill the wounded boar and disengage from the approaching sounder | boar bed at the quarry edge | 191/104 | 22.2 s |
| 108 | I strike again at the dying sow with Quick Slash, then break away up the rocks toward the thick gorse on the terraces to put distance betwee… | Erzähler | open_run_level | Finish the boar and disengage uphill | boar bed at the quarry edge | 191/104 | 33.3 s |
| 109 | #assign VIT 5 | System (Befehl) | open_run_level | Spend level-up points | boar bed at the quarry edge | 191/104 | 2.6 s |
| 110 | I keep my sword up and back away slowly up the rocks toward the thick gorse on the terraces, watching the sounder, not turning my back on th… | Erzähler | open_run_level | Disengage from the sounder after the kill | gorse terraces above the boar bed | 191/104 | 23.8 s |
| 111 | I head back along the quarry track toward Bexley's smithy in town to turn in the boar contract and check his gear. | Erzähler | open_run_level | Return to town, turn in contract, gear check | Adventurers' Guild hall, Alderwatch | 191/104 | 43.4 s |
| 112 | I approach the clerk and ask whether I can turn in partial progress on the Boars on the Quarry Road contract, or whether I need all four boa… | Erzähler | open_run_level | Turn in boar contract progress at the Guild counter | Adventurers' Guild hall, Alderwatch | 191/104 | 17.0 s |
| 113 | Thanking the clerk, I head to the healer's bench two doors past the temple wardens' house to have my leg wounds treated. | Erzähler | open_run_level | Recover HP before hunting the remaining boars | healer's bench past the temple wardens' house | 191/104 | 21.8 s |
| 114 | I pay the healer his six copper and thank him for the stitching. | Erzähler | open_run_level | Pay for treatment, then gear check at Bexley's | healer's bench past the temple wardens' house | 191/104 | 17.6 s |
| 115 | I head across the square to Bexley's smithy to have my gear looked at before hunting the remaining boars. | Erzähler | open_run_level | Gear check at the smithy per gear priority | Harl Bexley's smithy | 191/104 | 16.9 s |
| 116 | I show him the starter longsword and my Guild plate and gambeson, and ask what he'd offer for the sword as trade-in and whether he has armou… | Erzähler | open_run_level | Gear check: weapon and armour at Bexley's | Harl Bexley's smithy | 191/104 | 36.6 s |
| 117 | I'll take the eight copper for the starter sword and buy the round shield for 56 copper — equip the shield. | Erzähler | open_run_level | Sell starter sword, buy and equip round shield | Harl Bexley's smithy | 191/104 | 22.8 s |
| 118 | I thank Bexley and head to the Guild hall to check the contract board for safer work I can do while my leg heals. | Erzähler | open_run_level | Find safer work during recovery | Adventurers' Guild hall, Alderwatch | 191/104 | 16.1 s |
| 119 | I tell the clerk I'll take the Serpent at the Sluice contract and ask her to record it as accepted. | Erzähler | open_run_level | Accept a safer one-target contract while the leg heals | Adventurers' Guild hall, Alderwatch | 191/104 | 16.9 s |
| 120 | I ask the clerk the best way to the Millrace grist mill and head east out of Alderwatch toward the sluice, keeping off the water's edge whil… | Erzähler | open_run_level | Travel to the serpent contract site | the Millrace grist mill sluice, east of Alderwatch | 191/104 | 22.9 s |
| 121 | I ask Hollis to show me the best vantage on the plank walkway and take position by the sluice gate, watching the eddies below for movement. | Erzähler | open_run_level | Hunt the banded water serpent at the sluice | the Millrace grist mill sluice, east of Alderwatch | 191/104 | 19.5 s |
| 122 | I keep watch a while longer as dusk settles, then use the poking pole to prod the backwater under the left post where Hollis said it sat las… | Erzähler | open_run_level | Provoke or locate the serpent at the sluice | the Millrace grist mill sluice, east of Alderwatch | 191/104 | 26.5 s |
| 123 | I follow the reed edge downstream a short way with sword drawn, tracking where the serpent pushed through — staying near the mill lamp and n… | Erzähler | open_run_level | Track the serpent downstream before full dark | serpent den under the willow root | 191/104 | 23.3 s |
| 124 | I level my sword at the hollow's dark mouth and prod the root tangle with the poking pole to flush the serpent out into the lamplight. | Erzähler | open_run_level | Engage the serpent at its den | serpent den under the willow root | 191/104 | 18.8 s |
| 125 | I meet its strike by bracing behind the shield and swinging my longsword at its head as it closes. | Erzähler | open_run_level | Fight the banded water serpent | serpent den under the willow root | 191/104 | 16.8 s |
| 126 | I take the serpent hide and fang and head back to Alderwatch to turn in the Serpent at the Sluice contract at the Guild hall. | Erzähler | open_run_level | Turn in serpent contract | Alderwatch | 191/104 | 22.1 s |
| 127 | I enter the Guild hall and turn in the Serpent at the Sluice contract at the counter. | Erzähler | open_run_level | Turn in serpent contract at the Guild hall | Adventurers' Guild hall, Alderwatch | 191/104 | 17.4 s |
| 128 | I take the serpent hide and fang over to Bexley's smithy and ask what he'll pay for the fresh banded serpent skin. | Erzähler | open_run_level | Sell serpent loot to Bexley | Harl Bexley's smithy | 191/104 | 17.7 s |
| 129 | I accept: "Done — ten copper for the skin and fang." While he pays, I ask if he has any armor worth selling, since I'm still in traveler's c… | Erzähler | open_run_level | Sell serpent loot and check armour stock | Harl Bexley's smithy | 191/104 | 26.6 s |
| 130 | I thank Bexley and pass on the harness — it's thinner than what I've got. I head to the nearest inn, take a room for the night if I can affo… | Erzähler | open_run_level | Rest overnight to recover before continuing the boar contract | the Tapped Barrel | 191/104 | 27.7 s |
| 131 | I head back out to the quarry road and hunt the remaining tusked boars for the contract. | Erzähler | open_run_level | Continue boar contract hunt | the woods along the Greyvein quarry forest road | 191/104 | 22.3 s |
| 132 | I charge the boar in the ferns and attack with my longsword, shield ready. | Engine (Menü/Rückfrage) | open_run_level | Fight the contract boar | the woods along the Greyvein quarry forest road | 191/104 | 4.8 s |
| 133 | I charge the boar and use Quick Slash on it with my longsword, shield up. | Erzähler | open_run_level | Attack the contract boar with Quick Slash | the woods along the Greyvein quarry forest road | 191/104 | 46.7 s |
| 134 | I close the twenty paces to the boar in the ferns and engage it, shield up, then strike with Quick Slash. | Erzähler | open_run_level | Close to ENGAGED and attack | the woods along the Greyvein quarry forest road | 191/104 | 31.5 s |
| 135 | I brace behind my shield and take the charge, then strike with Quick Slash as it closes. | Erzähler | open_run_level | Receive the boar's charge and counterattack | the woods along the Greyvein quarry forest road | 191/104 | 24.3 s |
| 136 | I hold my ground behind the shield and strike with Quick Slash the moment the boar reaches me. | Erzähler | open_run_level | Wait for ENGAGED range, then counterattack | the woods along the Greyvein quarry forest road | 191/104 | 15.4 s |
| 137 | I step forward to close into ENGAGED range with boar N and strike it with Quick Slash as it arrives. | Erzähler | open_run_level | Close to ENGAGED and attack boar N | the woods along the Greyvein quarry forest road | 187/104 | 24.0 s |
| 138 | I strike boar N again with Quick Slash. | Erzähler | open_run_level | Finish the wounded boar | the woods along the Greyvein quarry forest road | 183/104 | 15.9 s |
| 139 | I finish boar N with a Basic Attack. | Erzähler | open_run_level | Kill the wounded boar before boar O commits | the woods along the Greyvein quarry forest road | 183/104 | 21.7 s |
| 140 | I wash and bind the thigh wound, then walk down to the quarry road and head back toward town to turn in the contract. | Erzähler | open_run_level | Treat the wound, return to town for the turn-in | Adventurers' Guild hall, Alderwatch | 183/104 | 21.2 s |
| 141 | I tell the clerk I've taken two boars so far and will finish the remaining two on the quarry road before turning in. I head back out to the … | Erzähler | open_run_level | Continue the boar contract (2/4) | the woods along the Greyvein quarry forest road | 183/104 | 24.8 s |
| 142 | I move quietly along the ridge above the fold and peer down through the ferns to count the sounder before committing. | Erzähler | open_run_level | Scout the remaining boars from concealment | the woods along the Greyvein quarry forest road | 183/104 | 22.9 s |
| 143 | I charge downslope to ENGAGED range with the nearest rooting boar and open with Cleave to catch two of the ordinary boars in one swing, leav… | Erzähler | open_run_level | Kill two more boars to finish the 4-count contract | the woods along the Greyvein quarry forest road | 183/104 | 38.1 s |
| 144 | I charge downslope at the nearest rooting boar and attack it with a Basic Attack, leaving the giant alone. | Engine (Menü/Rückfrage) | open_run_level | Engage one boar at a time and finish the 4-count contract | the woods along the Greyvein quarry forest road | 183/104 | 15.4 s |
| 145 | I charge downslope at Tusked Quarry Boar Q and attack it with a Basic Attack, leaving the giant alone. | Erzähler | open_run_level | Engage the nearest boar to finish the 4-count contract | the woods along the Greyvein quarry forest road | 183/104 | 16.8 s |
| 146 | I move quietly down through the ferns to close the distance to the streambed until I am ENGAGED with Tusked Quarry Boar Q, then attack it wi… | Erzähler | open_run_level | Close to ENGAGED range and finish the 4-count boar contract | the woods along the Greyvein quarry forest road | 183/104 | 23.6 s |
| 147 | I attack Tusked Quarry Boar Q with a Basic Attack. | Erzähler | open_run_level | Kill boar Q to reach 3/4 on the contract | the woods along the Greyvein quarry forest road | 183/104 | 20.8 s |
| 148 | I finish off Tusked Quarry Boar Q with a Basic Attack. | Erzähler | open_run_level | Kill boar Q to reach 4/4 on the contract | the woods along the Greyvein quarry forest road | 183/104 | 16.5 s |
| 149 | I hit Tusked Quarry Boar O with a Basic Attack as it closes in. | Erzähler | open_run_level | Fight off the two charging boars | the woods along the Greyvein quarry forest road | 183/104 | 14.9 s |
| 150 | I move to engage Tusked Quarry Boar O and attack it with a Basic Attack. | Erzähler | open_run_level | Close to ENGAGED range and kill boar O | the woods along the Greyvein quarry forest road | 183/104 | 13.2 s |
| 151 | I move forward to close into ENGAGED range with Tusked Quarry Boar O and attack it with a Basic Attack. | Erzähler | open_run_level | Close the distance and kill boar O | the woods along the Greyvein quarry forest road | 183/104 | 12.8 s |
| 152 | I advance toward Tusked Quarry Boar O to close the distance. | Erzähler | open_run_level | Close to ENGAGED range with a simple advance action | the woods along the Greyvein quarry forest road | 181/104 | 13.5 s |
| 153 | I attack Tusked Quarry Boar O with a Quick Slash. | Erzähler | open_run_level | Kill boar O at ENGAGED range | the woods along the Greyvein quarry forest road | 177/104 | 13.2 s |
| 154 | I use Cleave on Tusked Quarry Boar O and Tusked Quarry Boar R. | Erzähler | open_run_level | Kill both engaged boars with AoE | the woods along the Greyvein quarry forest road | 175/104 | 17.7 s |
| 155 | I attack Tusked Quarry Boar R with a Basic Attack. | Erzähler | open_run_level | Finish boar R | the woods along the Greyvein quarry forest road | 175/104 | 16.1 s |
| 156 | #assign STR 3 VIT 2 | System (Befehl) | open_run_level | Spend 5 free stat points from Level 9 | the woods along the Greyvein quarry forest road | 175/104 | 2.9 s |
| 157 | I travel back along the quarry road to town and, on arrival at the Guild hall, turn in the completed contract 'Boars on the Quarry Road' wit… | Erzähler | open_run_level | Turn in the boar contract at the Guild hall | Adventurers' Guild hall, Alderwatch | 175/104 | 22.9 s |
| 158 | I spend my stat points, then take my boar hides and tusks to Bexley's smithy to sell them and check his stock for weapon or armour upgrades. | Erzähler |  | Sell surplus loot and compare gear | Harl Bexley's smithy | 175/104 | 43.8 s |
| 159 | I accept Bexley's offer of twenty silver for the five hides and five tusks. Once he pays, I'll take the superior longsword for 260 copper an… | Erzähler | open_run_level | Sell surplus loot, then buy and equip weapon and armour upgrades | Harl Bexley's smithy | 175/104 | 23.5 s |
| 160 | I equip the superior longsword and the fine plate armor, replacing the fine longsword and fine plate I already wear. | Erzähler | open_run_level | Equip confirmed purchases | Harl Bexley's smithy | 175/104 | 22.6 s |
| 161 | I accept Bexley's offer and sell the old fine longsword and fine plate armor for five silver total. | Engine (Menü/Rückfrage) | open_run_level | Sell surplus old gear | Harl Bexley's smithy | 175/104 | 12.9 s |
| 162 | I accept the bid at 30 copper. | Erzähler | open_run_level | Sell old fine longsword and fine plate at Bexley's standing bid | Harl Bexley's smithy | 175/104 | 21.6 s |
| 163 | I check the Guild board for a new contract I can take. | Erzähler | open_run_level | Pick next Guild contract | Adventurers' Guild hall, Alderwatch | 175/104 | 27.8 s |
| 164 | I take the Cull the Tusked Quarry Boars contract and ask the clerk to mark it active. | Erzähler | open_run_level | Accept a new Guild contract | Adventurers' Guild hall, Alderwatch | 175/104 | 27.2 s |
| 165 | #assign VIT 2 STR 2 AGI 1 | System (Befehl) | open_run_level | Spend free stat points, then head out the east gate toward Greyvein | Adventurers' Guild hall, Alderwatch | 175/104 | 2.9 s |
| 166 | I head out the east gate and follow the quarry road toward Greyvein, watching the woods alongside for boar. | Erzähler | open_run_level | Travel to the boar hunting grounds for the active contract | the woods along the Greyvein quarry forest road | 175/104 | 28.1 s |
| 167 | I stalk the sounder from downwind, staying in the ferns, and wait for a moment when the three ordinary boars are bunched before opening with… | Erzähler | open_run_level | Ambush the boar sounder with Cleave | the woods along the Greyvein quarry forest road | 175/104 | 24.5 s |
| 168 | I wait until the three ordinary boars are tightly bunched, then strike with Cleave at the group. | Engine (Menü/Rückfrage) | open_run_level | Attack the bunched boars with Cleave | the woods along the Greyvein quarry forest road | 175/104 | 5.3 s |
| 169 | I target the closest ordinary boar in the hollow and strike it with Cleave, aiming the arc through the other two. | Engine (Menü/Rückfrage) | open_run_level | Open the boar fight with Cleave on a named target | the woods along the Greyvein quarry forest road | 175/104 | 6.4 s |
| 170 | I step out of the ferns and charge the closest ordinary boar, swinging Cleave into it and through the other two to start the fight. | Engine (Menü/Rückfrage) | open_run_level | Initiate combat on the boar sounder with a named target | the woods along the Greyvein quarry forest road | 175/104 | 4.7 s |
| 171 | I close the distance into the streambed and swing a Basic Attack at the nearest ordinary boar. | Engine (Menü/Rückfrage) | open_run_level | Initiate combat with a plain attack instead of Cleave | the woods along the Greyvein quarry forest road | 175/104 | 5.5 s |
| 172 | I draw my longsword and attack the Tusked Quarry Boar rooting in the streambed, the closest one, to start the fight. | Erzähler | open_run_level | Initiate combat using the contract's exact creature name | the woods along the Greyvein quarry forest road | 175/104 | 26.6 s |
| 173 | I swing Cleave at Tusked Quarry Boar P, the closest one, arcing through the other two. | Erzähler | open_run_level | Open the boar fight with Cleave on the named target | the woods along the Greyvein quarry forest road | 175/104 | 19.1 s |
| 174 | I hold my ground and swing Cleave at the big sow, Tusked Quarry Boar S, as it closes on me. | Erzähler | open_run_level | Engage the charging big boar with Cleave | the woods along the Greyvein quarry forest road | 175/104 | 18.1 s |
| 175 | I brace behind my shield as the sow reaches me and strike it with Cleave. | Erzähler | open_run_level | Engage the charging sow at melee range and Cleave it | the woods along the Greyvein quarry forest road | 175/104 | 19.1 s |
| 176 | I meet the sow's charge, turning my shield into its impact and swinging Cleave through it at point-blank range. | Erzähler | open_run_level | Strike the now-ENGAGED sow at the moment of contact | the woods along the Greyvein quarry forest road | 164/104 | 27.5 s |
| 177 | I finish the wounded sow with a Basic Attack. | Erzähler | open_run_level | Kill the engaged sow efficiently, conserving stamina | the woods along the Greyvein quarry forest road | 164/104 | 18.9 s |
| 178 | Combat is still open and my turn stands. I end my turn, take no further action, and hold my ground to let the fight close — the remaining bo… | Erzähler | open_run_level | Close the fight without chasing the fleeing boar | the woods along the Greyvein quarry forest road | 164/104 | 21.8 s |
| 179 | #assign STR 3 AGI 2 | System (Befehl) | open_run_level | Spend the 5 free stat points from the Level 11 level-up | the woods along the Greyvein quarry forest road | 164/104 | 3.0 s |
| 180 | I follow the fresh boar sign deeper toward the oaks, moving quietly with my shield ready, and stalk the second tusked quarry boar I heard up… | Erzähler | open_run_level | Continue the boar cull toward the second kill despite low stamina, using careful stalking … | oak fold wallow below the biggest oak | 164/104 | 28.6 s |
| 181 | Using the forked branch between the hollies as cover, I stalk quietly to within striking distance of the rooting boar behind the rise, then … | Engine (Menü/Rückfrage) | open_run_level | Ambush the second quarry boar with a stamina-cheap Basic Attack | oak fold wallow below the biggest oak | 164/104 | 5.5 s |
| 182 | I creep up the bramble-choked rise toward the rooting sound, keeping the forked branch between me and it, and get my first clear look at the… | Erzähler | open_run_level | Get the second boar into an active scene before attacking | oak fold wallow below the biggest oak | 164/104 | 19.1 s |
| 183 | I creep up the bramble-choked rise toward the rooting sound, keeping low behind the bracken. | Erzähler | open_run_level | Open the boar as a targetable actor by closing the distance | oak fold wallow below the biggest oak | 164/104 | 22.8 s |
| 184 | I rush from the bracken and attack the boar with a Basic Attack. | Erzähler | open_run_level | Charge the second quarry boar while it is unaware | oak fold wallow below the biggest oak | 164/104 | 22.9 s |
| 185 | I close the last ten paces and swing at the boar with a Basic Attack. | Erzähler | open_run_level | Close to ENGAGED range and strike the second quarry boar | oak fold wallow below the biggest oak | 164/104 | 27.4 s |
| 186 | I step in that final pace and swing my longsword at the boar's neck with a Basic Attack. | Erzähler | open_run_level | Land a Basic Attack now that the boar is ENGAGED | oak fold wallow below the biggest oak | 160/104 | 23.6 s |
| 187 | I finish it with a Basic Attack to the boar's neck. | Erzähler | open_run_level | Kill the wounded quarry boar with a Basic Attack | oak fold wallow below the biggest oak | 160/104 | 17.9 s |
| 188 | I bind the wound on my thigh with linen strips from my gambeson padding, then check the contract slip for how many boars remain. | Erzähler | open_run_level | Recover and check contract progress | oak fold wallow below the biggest oak | 160/104 | 14.7 s |
| 189 | I stalk toward the rooting sound beyond the bramble rise, keeping low with the wind still in my face. | Erzähler | open_run_level | Hunt the third quarry boar while it stays unaware | bramble rise above the oak fold | 160/104 | 25.6 s |
| 190 | I wait for the younger boar to drop its head back to digging, then charge the sow and strike with a Basic Attack. | Erzähler | open_run_level | Ambush the sow for a charge opening on boar three | bramble rise above the oak fold | 160/104 | 15.1 s |
| 191 | I charge down the slope across the open spill toward the sow, closing to ENGAGED, and strike her with a Basic Attack. | Erzähler | open_run_level | Close the forty paces and attack the sow | bramble rise above the oak fold | 160/104 | 18.2 s |
| 192 | I take the bow and arrows from the magic pouch, nock an arrow, and shoot at the sow. | Erzähler | open_run_level | Use ranged attack to close the LONG range gap | bramble rise above the oak fold | 160/104 | 19.1 s |
| 193 | I back away from the bramble rise and withdraw toward the oak fold's edge, keeping the wind in my face, to rest and recover before trying th… | Erzähler | open_run_level | Withdraw and recover; STA and HP too low to charge two boars | oak fold's edge | 160/104 | 18.3 s |
| 194 | I settle into the shelter of the low stony bank among the oak roots, shield across my knees, and rest until my stamina and wounds recover. | Engine (Menü/Rückfrage) | open_run_level | Rest and recover STA and HP before finishing the last two boars | oak fold's edge | 160/104 | 5.3 s |
| 195 | I rest here at the stony bank for two hours, shield across my knees, until my stamina and wounds recover. | Erzähler | open_run_level | Recover STA and HP with a named duration | oak fold's edge | 221/104 | 30.8 s |
| 196 | I rest here another two hours until my wounds heal fully, then move quietly toward the rooting sounds beyond the bramble rise. | Erzähler | open_run_level | Finish recovery, then hunt the last two boars in the dark | bramble rise above the oak fold | 282/104 | 26.6 s |
| 197 | I charge down the flank across the open ground toward the younger boar Z, closing to ENGAGED, and strike it with a Basic Attack. | Erzähler | open_run_level | Close the distance and attack boar Z first | bramble rise above the oak fold | 282/104 | 17.4 s |
| 198 | I charge down the open ground at boar Z, closing from LONG to ENGAGED, and only then strike with a Basic Attack. | Erzähler | open_run_level | Close to melee range first, then attack | bramble rise above the oak fold | 282/104 | 17.4 s |
| 199 | I move to ENGAGED with the sow Y and strike her with a Basic Attack. | Erzähler | open_run_level | Close with the sow first since she blocks the path | bramble rise above the oak fold | 282/104 | 19.8 s |
| 200 | I hold my ground behind the shield and let the sow come to me; the moment she reaches ENGAGED, I strike with a Basic Attack. | Erzähler | open_run_level | Let the approaching sow close to melee range, then attack | bramble rise above the oak fold | 282/104 | 17.1 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 10 (notiert vor Zug 11): The serpent keeps exactly twenty paces of mud between us; charging across the flat is futile. Channel water may be the only passable approach.
- zu Zug 12 (notiert vor Zug 13): Serpent now ENGAGED per HUD; earlier Cleave refusals were range-timing issues.
- zu Zug 19 (notiert vor Zug 20): System corrected the narrated prices: common longsword 80 cp, common heavy plate 64 cp. Fine longsword (140 cp) unaffordable with 75 cp on hand.
- zu Zug 23 (notiert vor Zug 24): HUD shows 3 Silver 1 Copper despite narrated 10 silver sale — checking whether the transaction registered.
- zu Zug 24 (notiert vor Zug 25): Audit rejected the narrated 10 silver sale: no accepted matching bid registered; HUD still shows 3s1c and starter armor carried. Need an explicit System-confirmed offer and acceptance.
- zu Zug 27 (notiert vor Zug 28): Narrator confirmed Bexley paid ten silver, but HUD coin and bag still show 3s1c and both items carried.
- zu Zug 28 (notiert vor Zug 29): Audit rejected the narrated 10s sale again, saying proceeds are already in purse, yet HUD coin shows 3s1c — possible engine desync on this transaction. Third check; if bag confirms 3s1c I'll drop the sale and move on to the Guild board.
- zu Zug 29 (notiert vor Zug 30): Audit claims the 10 silver is in purse, but #bag still shows 3 Silver 1 Copper — engine desync on this sale, third check; noting and moving on. Bag no longer lists starter armor or serpent skin, so the sale did register inventory-wise.
- zu Zug 39 (notiert vor Zug 40): Boar nearly dead at 16 HP; I've taken 46 damage — recovery and a smith visit needed after turn-in.
- zu Zug 42 (notiert vor Zug 43): Stat assignment reflected: HP max now 140 but current HP unchanged at 69/140 — wounded, needs rest after this fight.
- zu Zug 44 (notiert vor Zug 45): Cleave refused twice because boar B is still LONG; closing distance must be its own confirmed step before any swing.
- zu Zug 48 (notiert vor Zug 49): Boar B finally ENGAGED and my turn first; HP down to 58/140.
- zu Zug 52 (notiert vor Zug 53): Level 4 confirmed, stats assigned (VIT 19, STR 15), quest at 2/4 boars, HP 46/150 still low.
- zu Zug 54 (notiert vor Zug 55): Stew was granted as an inventory item rather than instant healing; will check HP after eating and resting.
- zu Zug 58 (notiert vor Zug 59): Cleave refused again because no target is ENGAGED yet; opening with Basic Attack to engage first.
- zu Zug 61 (notiert vor Zug 62): Sow C refuses to close; she kites at LONG while boar D circles closer. Pivot to the nearer target.
- zu Zug 66 (notiert vor Zug 67): Level 5, +5 free stat points pending; contract 3/4.
- zu Zug 69 (notiert vor Zug 70): Stat points assigned via #assign (AGI 12, WIL 10).
- zu Zug 70 (notiert vor Zug 71): Cleave requires the target to be ENGAGED first; the sow was still out of reach.
- zu Zug 72 (notiert vor Zug 73): HUD now lists Boar C as SHORT, so Basic Attack should connect.
- zu Zug 81 (notiert vor Zug 82): Engine refused the sale because Alaric was still in the Guild hall, not at the merchant's stall; prices were quoted there earlier.
- zu Zug 84 (notiert vor Zug 85): Sale confirmed: +85 copper, now 256 cp total. HP still low (99/210) — recovery needed before next hunt.
- zu Zug 85 (notiert vor Zug 86): Engine-corrected prices: longsword 140, plate 72, shields 56. Coin 256 cp; buying both leaves 44 cp.
- zu Zug 86 (notiert vor Zug 87): Engine-confirmed pair price is 72 cp, far below narrated prices; treating the System result as authoritative.
- zu Zug 87 (notiert vor Zug 88): Engine refused equipping with 'he does not hold it' even though the purchase completed and the HUD lists the pair as carried; likely needs a proper fitting/padding step before equip.
- zu Zug 89 (notiert vor Zug 90): Gear goal met: fine longsword and plate equipped over gambeson; 104 cp on hand. HUD still shows Starter Longsword equipped alongside the pair despite the trade — will verify DEF/ATK on next status check.
- zu Zug 90 (notiert vor Zug 91): HUD still lists Starter Longsword as equipped even though Bexley took it as trade stock; watching for the engine to settle it.
- zu Zug 92 (notiert vor Zug 93): Gear priority met; recovery complete. HUD still lists Starter Longsword equipped alongside the fine pair — unresolved contradiction.
- zu Zug 98 (notiert vor Zug 99): HUD still lists Starter Longsword equipped alongside the fine pair — unresolved contradiction, possibly display-only.
- zu Zug 99 (notiert vor Zug 100): Nine boars present at once; contract only needs four — avoiding a full-sounder brawl.
- zu Zug 103 (notiert vor Zug 104): Nine boars all listed at SHORT; sounder may have heard the scream — may need to disengage after this kill.
- zu Zug 105 (notiert vor Zug 106): Quick Slash repeatedly refused at SHORT; must explicitly declare movement into ENGAGED range before striking.
- zu Zug 106 (notiert vor Zug 107): Sounder of eight at SHORT, none charging yet; may need to evade or climb rather than fight.
- zu Zug 114 (notiert vor Zug 115): Healer says no boar hunting for a few days; contract stays credited, so I can pick safer work meanwhile. Equipped line oddly lists both starter gear and the fine pair.
- zu Zug 116 (notiert vor Zug 117): HUD shows the fine longsword and fine plate are already equipped, so weapon/armour upgrades are done; only a shield was missing.
- zu Zug 118 (notiert vor Zug 119): Boars contract still owed 3/4 but healer advised rest; serpent job is a single-kill alternative. Shield purchase confirmed.
- zu Zug 128 (notiert vor Zug 129): HUD lists 'fine longsword and fine plate armor, the pair' as equipped but combat stats show ATK 10 / DEF 19 matching starter gear — possible stat/equipment contradiction worth watching.
- zu Zug 129 (notiert vor Zug 130): Bexley's plate harness confirmed at 48 cp but stats are a downgrade vs equipped; fine sword (140 cp) unaffordable at 92 cp. HUD equipped list still contradicts combat stats.
- zu Zug 134 (notiert vor Zug 135): Engine says boar N is at LONG despite narrator closing; wait for it to reach SHORT before striking.
- zu Zug 136 (notiert vor Zug 137): Engine repeatedly refuses Quick Slash at SHORT; must explicitly declare movement to ENGAGED before striking.
- zu Zug 140 (notiert vor Zug 141): Contract requires 4 boars, only 2/4 recorded; turn-in refused until complete. Fine longsword and plate already equipped, so gear priority is satisfied.
- zu Zug 150 (notiert vor Zug 151): Engine rejects 'move to engage' phrasing twice at MEDIUM; trying explicit closing movement this round.
- zu Zug 151 (notiert vor Zug 152): Engine rejected three 'move to engage + attack' phrasings; trying a plain advance verb, then attack next round if it lands.
- zu Zug 158 (notiert vor Zug 159): HUD lists fine longsword and fine plate as already equipped though no purchase was engine-confirmed; treating engine price confirmations as authoritative and buying the superior longsword plus fine plate.
- zu Zug 159 (notiert vor Zug 160): Engine confirmed the sale and both purchases (332 cp paid), but the HUD still lists old gear equipped; narrated prices keep contradicting confirmed ones.
- zu Zug 161 (notiert vor Zug 162): System asked to clarify which price I accept; taking the confirmed 30 cp bid.
- zu Zug 163 (notiert vor Zug 164): HUD still shows 5 free stat points and lists old gear names despite confirmed sales/purchases; assigning points now.
- zu Zug 164 (notiert vor Zug 165): Carried list shows only 3 boar tusks though the new contract is 0/4; old tusks may count from the previous job.
- zu Zug 165 (notiert vor Zug 166): Contract confirmed active 0/4; stats assigned, free points now 0. HP still wounded (175/285) — may need recovery before fighting.
- zu Zug 169 (notiert vor Zug 170): System twice says no targetable actor despite boars present — combat may need explicit initiation rather than an ambush strike.
- zu Zug 170 (notiert vor Zug 171): Three attempts with Cleave all returned 'no targetable actor' despite boars clearly present — combat may need a different initiation verb.
- zu Zug 171 (notiert vor Zug 172): Three attack attempts rejected as 'no targetable actor' despite boars listed present — trying the official contract name as target.
- zu Zug 177 (notiert vor Zug 178): Engine kept combat open into Round 3 with only the fleeing boar at LONG range; HUD offers only ENGAGED attacks, so I end my turn rather than force an invalid target.
- zu Zug 179 (notiert vor Zug 180): HUD HP denominator shifted 305→295 after stat assignment; STA very low (32/100), so conserving stamina with Basic Attacks.
- zu Zug 181 (notiert vor Zug 182): Attack refused because the boar is not a targetable actor yet — the scene must open via narration first; HP denominator discrepancy 305 vs 295 persists.
- zu Zug 182 (notiert vor Zug 183): Prototype resolves one action kind per message; the earlier combined stalk+attack was split, movement must be its own turn.
- zu Zug 188 (notiert vor Zug 189): STA is low (24/100) and HP wounded; may need rest after the third boar.
- zu Zug 192 (notiert vor Zug 193): No bow or arrows exist in the pouch despite the earlier plan — ranged option unavailable. Sounder threat noted from the sow's scream.
- zu Zug 193 (notiert vor Zug 194): No bow or arrows exist in inventory; ranged option is permanently unavailable. Engine refused 'withdraw to rest' phrasing as arrival pending, so recovery must be performed as an explicit action.
- zu Zug 195 (notiert vor Zug 196): Recovery only reached 221/305 after two hours; STA still not full. Hunting boars in full dark may need care.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t13 | 13 | 1 | – | nein | 1 | gewonnen, 60 XP |
| enc.t28r | 33 | 1 | – | nein | 1 | gewonnen, 60 XP |
| enc.t33 | 38 | 1 | – | nein | 1 | gewonnen, 310 XP |
| enc.t42r | 48 | 1 | – | nein | 1 | gewonnen, 310 XP |
| enc.t56 | 63 | 1 | – | nein | 1 | gewonnen, 450 XP |
| enc.t67 | 75 | 1 | – | nein | 1 | gewonnen, 310 XP |
| enc.t94 | 106 | 1 | – | nein | 1 | gewonnen, 475 XP |
| enc.t112 | 125 | 1 | – | nein | 1 | gewonnen, 60 XP |
| enc.t123 | 137 | 1 | – | nein | 1 | gewonnen, 380 XP |
| enc.t132 | 147 | 3 | – | ja | 3 | gewonnen, 875 XP |
| enc.t154 | 176 | 2 | – | ja | 1 | gewonnen, 560 XP |
| enc.t162 | 186 | 1 | – | ja | 1 | gewonnen, 385 XP |

## Quests

- **A Serpent at the Millrace** — active (Zug 5) → completed (Zug 16), READY
  - Aufgabe: Kill 1 banded water serpent at the Millrace grist mill sluice, a short walk east of Alderwatch. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 banded water serpent killed at the Millrace grist mill sluice, a short walk east of Alderwatch.
- **Thin the Quarry Boars** — active (Zug 31) → completed (Zug 79), READY
  - Aufgabe: Kill 4 tusked quarry boars at the woods along the Greyvein quarry forest road. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 tusked quarry boars killed at the woods along the Greyvein quarry forest road.
- **Clear the Gibbet Fen Reeds** — expired (Zug 96)
  - Aufgabe: Kill 6 bog ghouls at the reed beds of Gibbet Fen, south of the causeway. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 6 bog ghouls killed at the reed beds of Gibbet Fen, south of the causeway.
- **Break the Ashfang Pack** — expired (Zug 96)
  - Aufgabe: Kill 5 great ashfang wolves at the Northgate pine barrens. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 5 great ashfang wolves killed at the Northgate pine barrens.
- **Secure the Old Crown Catacombs, Level 1** — expired (Zug 96), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of Old Crown Catacombs. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Old Crown Catacombs is clear.
- **Serpent at the Sluice** — active (Zug 119) → completed (Zug 127)
  - Aufgabe: Kill 1 banded water serpent at the Millrace grist mill sluice, east of Alderwatch. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 banded water serpent killed at the Millrace grist mill sluice, east of Alderwatch.
- **Boars on the Quarry Road** — active (Zug 97) → completed (Zug 157)
  - Aufgabe: Kill 4 tusked quarry boar at the woods along the Greyvein quarry forest road. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 tusked quarry boar killed at the woods along the Greyvein quarry forest road.
- **Ghouls of Gibbet Fen** — expired (Zug 163)
  - Aufgabe: Kill 5 bog ghoul at the reed beds of Gibbet Fen, south of the causeway. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 5 bog ghoul killed at the reed beds of Gibbet Fen, south of the causeway.
- **The Ashfang Pack-Mother** — expired (Zug 163)
  - Aufgabe: Kill 1 great ashfang wolf at the Northgate pine barrens. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 great ashfang wolf killed at the Northgate pine barrens.
- **Clear the Old Crown Catacombs, Level 1** — expired (Zug 163), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of Old Crown Catacombs. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Old Crown Catacombs is clear.
- **Cull the Tusked Quarry Boars** — active (Zug 164)
  - Aufgabe: Kill 4 tusked quarry boar at the woods along the Greyvein quarry forest road. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 tusked quarry boar killed at the woods along the Greyvein quarry forest road.

## Auffälligkeiten

- Zug 22, Nachricht 43 (planner_repaired): the planner's first answer needed a repair
- Zug 27, Nachricht 53 (planner_repaired): the planner's first answer needed a repair
- Zug 27, Nachricht 54 (extraction_repaired): the extractor's first answer needed a repair
- Zug 32, Nachricht 64 (extraction_repaired): the extractor's first answer needed a repair
- Zug 53, Nachricht 105 (planner_repaired): the planner's first answer needed a repair
- Zug 53, Nachricht 106 (extraction_repaired): the extractor's first answer needed a repair
- Zug 68, Nachricht 135 (stat_words): the player spent Stat Points in words, not with #assign; nothing was assigned (for review: did the story tell them as done?)
- Zug 79, Nachricht 158 (extraction_repaired): the extractor's first answer needed a repair
- Zug 81, Nachricht 161 (planner_repaired): the planner's first answer needed a repair
- Zug 82, Nachricht 164 (extraction_repaired): the extractor's first answer needed a repair
- Zug 83, Nachricht 165 (planner_repaired): the planner's first answer needed a repair
- Zug 90, Nachricht 179 (planner_repaired): the planner's first answer needed a repair
- Zug 90, Nachricht 180 (extraction_repaired): the extractor's first answer needed a repair
- Zug 111, Nachricht 222 (extraction_repaired): the extractor's first answer needed a repair
- Zug 158, Nachricht 315 (stat_words): the player spent Stat Points in words, not with #assign; nothing was assigned (for review: did the story tell them as done?)
- Zug 161, Nachricht 321 (planner_repaired): the planner's first answer needed a repair
- Zug 166, Nachricht 332 (extraction_repaired): the extractor's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 61× keine gültige JSON-Entscheidung (Züge 1, 2, 4, 6, 7, 9, 10, 11, 12, 13, 16, 17, 18, 19, 20, 21, 22, 23, 26, 28, 33, 34, 35, 41, 57, 58, 62, 72, 80, 95, 100, 101, 102, 103, 112, 113, 116, 121, 122, 123, 124, 125, 126, 127, 128, 131, 132, 138, 148, 150, 153, 157, 161, 164, 173, 174, 175, 181, 184, 190, 200)

System-Panels: CLARIFY 6, NOT TAKEN 5, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: guild_canon 1, guild_canon_price 1, engine_owned_fact 9, attack_commitment 9, no_go 2, scene_context 16, pc_inventory 3, offer 10, coin_evidence 1, sale_evidence 2, engine_booked 1, world_rule 28, engine_owned 1, recover 1, quest_count 1, coin_already_received 3, object 1, npc_identity 1, ambient 8, npc_continuity 2, engine_recovery 2, group_unclear 2, engine_owned_combat 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 61/200 Erstantworten ungültig (30.5 %); 61 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 191 | 7 | 2.5 s | 4.6 s | 12083 | 9968 | 80 | – | stop 191 | 0 |
| board | 3 | 0 | 9.7 s | 9.8 s | 2632 | 2307 | 1121 | – | stop 3 | 0 |
| narrator | 173 | 0 | 8.5 s | 12.4 s | 11351 | 8817 | 391 | – | stop 173 | 0 |
| extract | 181 | 8 | 4.8 s | 9.2 s | 12782 | 9744 | 283 | – | stop 181 | 0 |
| forge | 1 | 0 | 1.6 s | 1.6 s | 395 | 0 | 68 | – | stop 1 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 79:03 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 15.3 s) | 0:30 min |
| 200 Züge, Spiel (Senden bis HUD nach der Extraktion) | 63:42 min — Median 19.1 s, p90 27.8 s, max 47.5 s |
| 200 Züge, Spieler-Entscheidung | 10:48 min — Median 2.8 s, 61 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 9:33 min / 0:27 min / 27:29 min / 17:37 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 22.3 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 14:54 min, 80 Züge ≈ 29:48 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Provider extract | 133 | 370 | 33.8 s | 4.8 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
