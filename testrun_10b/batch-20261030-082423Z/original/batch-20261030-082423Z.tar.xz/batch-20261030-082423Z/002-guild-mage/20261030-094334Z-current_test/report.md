# Avereth Live-Test 20261030-094334Z-current_test

## Kurzfassung

- **Laufprofil:** guild-mage; Startklasse Mage, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** Niederlage — turn 22: he died
- **Etappen:** 1/3 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht) · class_accepted (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 3. Sicherheitsgrenzen: 200 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** noch nicht erreicht.
- **Charakter:** mage (mage.arcane_bolt, mage.arcane_wave) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 through E class evolution“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: pragmatic adventurer: sell surplus loot and invest in useful equipment and techniques
- **Züge:** 22 · **Dauer:** 9:02 min · **LLM-Aufrufe der Engine/des Erzählers:** 56
- **Beobachtete Abdeckung:** 5 unterschiedliche gebuchte Reiseziele · 3 Kämpfe · 0 Verkäufe (0 cp Umsatz, ohne Questzahlungen/Geschenke) · 0 Ausrüstungswechsel · 0 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 3 · **Niederlage** in Zug 22: he died
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.123 |
| Git | c300f3d77262 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 58.9 s |
| Browser | chrome 156.0.8078.49 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261030-094334Z-current_test“, Seed 685958793 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |
| class_accepted | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | I choose Mage. | Engine (Menü/Rückfrage) | creation_complete | Select Mage base class | public roadside verge outside Ashbridge | 90/84 | 2.3 s |
| 2 | I choose Arcane Wave and Arcane Bolt as my two skills. | Engine (Menü/Rückfrage) | creation_complete | Pick required starter skills | public roadside verge outside Ashbridge | 90/96 | 2.2 s |
| 3 | I walk toward the Ashbridge city gate and look for the Guild hall to check the contract board. | Erzähler | open_run_level | Enter city and find Guild contracts | Adventurers' Guild hall, Ashbridge | 90/96 | 20.9 s |
| 4 | I approach the clerk and ask: "I'd like to register with the Guild, and I'd like to see what contracts are available for a new member." | Erzähler | open_run_level | Register with the Guild and view novice contracts | Adventurers' Guild hall, Ashbridge | 90/96 | 40.5 s |
| 5 | I pay the two silver registration fee and give my name as Alaric, then ask to accept the Quarry Track Adder contract. | Erzähler | open_run_level | Register with the Guild and take a novice contract | Adventurers' Guild hall, Ashbridge | 90/96 | 17.2 s |
| 6 | I take the contract slip and head out the Guild hall, following the millstream east along the old quarry track toward the culvert. |  | open_run_level | Travel to the adder contract site | Adventurers' Guild hall, Ashbridge | 90/96 | 23.0 s |
| 7 | I cast Arcane Bolt at the adder sunning on the culvert stone. | Engine (Menü/Rückfrage) | open_run_level | Attack the contract target from range before it notices me | Adventurers' Guild hall, Ashbridge | 90/96 | 5.6 s |
| 8 | I say goodbye to the clerk and leave the Guild hall, walking east along the quarry track until I reach the culvert. | Erzähler | open_run_level | Change scene from Guild hall to the culvert | culvert on the old quarry track east of Ashbridge | 90/96 | 15.3 s |
| 9 | I cast Arcane Bolt at the grey adder coiled on the culvert stone. | Erzähler | open_run_level | Attack the contract adder from range | culvert on the old quarry track east of Ashbridge | 90/86 | 16.9 s |
| 10 | I pick up the adder's remains and walk back along the quarry track to Ashbridge, then return to the Guild hall and ask the clerk to turn in … | Erzähler | open_run_level | Turn in the adder contract and collect the reward | Adventurers' Guild hall, Ashbridge | 90/86 | 35.9 s |
| 11 | #assign INT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up stat points | Adventurers' Guild hall, Ashbridge | 90/86 | 2.2 s |
| 12 | I walk to the contract board and look over the available contracts. | Erzähler | open_run_level | Pick a new achievable Guild contract | Adventurers' Guild hall, Ashbridge | 90/86 | 22.7 s |
| 13 | I take the Millpond Mire Pike slip from the board and ask the clerk to accept the contract. | Erzähler | open_run_level | Accept the pike hunt contract | Adventurers' Guild hall, Ashbridge | 90/86 | 21.3 s |
| 14 | I tell the clerk nothing else is needed and leave the Guild hall, walking to the Ashbridge millpond reed shallows. | Erzähler | open_run_level | Travel to the millpond for the pike contract | reed shallows of Ashbridge millpond | 90/86 | 15.9 s |
| 15 | I walk carefully along the wooden walkway to the end and scan the reed line for any sign of mire pike. | Erzähler | open_run_level | Find mire pike at the shallows | end of the wooden walkway | 90/86 | 17.4 s |
| 16 | I ready my staff and wait at the walkway's end, watching the water near the fence stub for the creature to come within clear reach. | Erzähler | open_run_level | Ambush the approaching mire pike | end of the wooden walkway | 74/86 | 30.8 s |
| 17 | I cast Arcane Bolt at the mire pike. | Erzähler | open_run_level | Attack the engaged pike | end of the wooden walkway | 59/76 | 20.6 s |
| 18 | I cast Arcane Bolt at the mire pike to finish it. | Erzähler | open_run_level | Kill the pike with another Arcane Bolt | end of the wooden walkway | 59/66 | 15.7 s |
| 19 | #assign INT 3 WIL 2 | System (Befehl) | open_run_level | Spend level-up points | end of the wooden walkway | 59/66 | 2.2 s |
| 20 | I keep my staff raised and watch the reed line near the fence stub, waiting to see what emerges before attacking. | Erzähler | open_run_level | Identify the hidden creature before engaging | end of the wooden walkway | 59/66 | 23.8 s |
| 21 | I cast Arcane Bolt at the big mire pike. | Erzähler | open_run_level | Attack Mire Pike B | end of the wooden walkway | 3/56 | 14.6 s |
| 22 | I grab my staff and cast Arcane Bolt at Mire Pike B. | Erzähler | open_run_level | Kill the pike before it strikes again | end of the wooden walkway | 0/46 | 18.0 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 7 (notiert vor Zug 8): Travel last turn wasn't recorded; scene still Clerk/ENGAGED, so the adder wasn't a valid target.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t8 | 9 | 1 | – | nein | 1 | gewonnen, 60 XP |
| enc.t14r | 16 | 1 | – | nein | 1 | gewonnen, 240 XP |
| enc.t18 | 21 | 1 | – | nein | 0 | **tot** |

## Quests

- **Cull the Quarry Track Adder** — active (Zug 5) → completed (Zug 10), READY
  - Aufgabe: Kill 1 grey adder at culvert on the old quarry track east of Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 grey adder killed at culvert on the old quarry track east of Ashbridge.
- **Thin the Millpond Mire Pike** — active (Zug 13)
  - Aufgabe: Kill 4 mire pike at reed shallows of Ashbridge millpond. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 mire pike killed at reed shallows of Ashbridge millpond.

## Auffälligkeiten

- Zug 6, Nachricht 12 (extraction_failed): the extractor failed: $.deltas[1] (place.reported): : missing required "how"; $.deltas[1] (place.reported): .place: matches none of anyOf; Place reference at deltas[1].place: use a known place id or {"new":{"name":"exact n
- Zug 6, Nachricht 12 (extraction_repaired): the extractor's first answer needed a repair
- Zug 20, Nachricht 40 (extraction_repaired): the extractor's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 7× keine gültige JSON-Entscheidung (Züge 7, 9, 11, 13, 16, 20, 21)

System-Panels: CLARIFY 0, NOT TAKEN 0, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: guild_canon 2, pc_inventory 1, engine_owned_fact 1, engine_owned_memory 1, board_first_display 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 7/22 Erstantworten ungültig (31.8 %); 7 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 18 | 0 | 2.4 s | 4.3 s | 11759 | 9880 | 70 | – | stop 18 | 0 |
| narrator | 17 | 0 | 8.4 s | 13.8 s | 11557 | 0 | 412 | – | stop 17 | 0 |
| extract | 19 | 2 | 4.6 s | 12.2 s | 12150 | 9591 | 270 | – | stop 19 | 0 |
| board | 2 | 1 | 10.7 s | 11.8 s | 3040 | 2469 | 983 | – | stop 2 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 9:02 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 58.9 s) | 1:14 min |
| 22 Züge, Spiel (Senden bis HUD nach der Extraktion) | 6:25 min — Median 17.3 s, p90 30.8 s, max 40.5 s |
| 22 Züge, Spieler-Entscheidung | 1:05 min — Median 2.9 s, 7 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 0:49 min / 0:22 min / 2:40 min / 1:45 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 20.5 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 13:39 min, 80 Züge ≈ 27:17 min (ohne Einrichtung) |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
