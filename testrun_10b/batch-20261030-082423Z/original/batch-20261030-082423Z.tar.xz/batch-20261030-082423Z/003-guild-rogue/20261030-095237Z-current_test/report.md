# Avereth Live-Test 20261030-095237Z-current_test

## Kurzfassung

- **Laufprofil:** guild-rogue; Startklasse Rogue, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** abgebrochen: Limit erreicht — 200 turns
- **Etappen:** 1/3 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht) · class_accepted (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 6. Sicherheitsgrenzen: 200 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** Level 5, 100 XP seit Levelaufstieg, 12 cp, HP 75, MP 88; Ort loc.gristbeck.the_smithy_behind_the_market_square. Ausrüstung und Skills stehen in evaluation.json → progression.checkpoint.
- **Charakter:** rogue (rogue.piercing_thrust, rogue.fan_of_blades) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 through E class evolution“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: pragmatic adventurer: sell surplus loot and invest in useful equipment and techniques
- **Züge:** 200 · **Dauer:** 79:55 min · **LLM-Aufrufe der Engine/des Erzählers:** 582
- **Beobachtete Abdeckung:** 24 unterschiedliche gebuchte Reiseziele · 19 Kämpfe · 1 Verkäufe (30 cp Umsatz, ohne Questzahlungen/Geschenke) · 1 Ausrüstungswechsel · 2 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 33
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.123 |
| Git | c300f3d77262 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 9.7 s |
| Browser | chrome 156.0.8078.49 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261030-095237Z-current_test“, Seed 685958794 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |
| class_accepted | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | Rogue | Engine (Menü/Rückfrage) | creation_complete | Choose Rogue as base class | public roadside verge outside Alderwatch | 90/84 | 2.3 s |
| 2 | I choose Fan of Blades and Piercing Thrust as my two skills. | Engine (Menü/Rückfrage) | creation_complete | Select required AoE skill plus a single-target attack | public roadside verge outside Alderwatch | 90/84 | 2.2 s |
| 3 | I walk through the city gate into Alderwatch and head for the Adventurers' Guild hall to look at the contract board. | Erzähler | open_run_level | Enter city and find Guild contracts | Adventurers' Guild hall, Alderwatch | 90/84 | 38.9 s |
| 4 | I tell the clerk: "I'd like to take the Orchard Prowler contract — the gray wolf at the cider orchard. Can you register it for me?" | Erzähler | open_run_level | Accept a novice Guild contract via the clerk | Adventurers' Guild hall, Alderwatch | 90/84 | 16.3 s |
| 5 | "Yes, I'll register — here's the two silver." I place the coins on the desk and sign the book. | Erzähler | open_run_level | Register with the Guild | Adventurers' Guild hall, Alderwatch | 90/84 | 20.7 s |
| 6 | "Yes, book the Orchard Prowler for me." | Erzähler | open_run_level | Accept the wolf contract now that I'm registered | Adventurers' Guild hall, Alderwatch | 90/84 | 14.3 s |
| 7 | I thank the clerk and head out the south gate toward the cider orchard to hunt the gray wolf. | Erzähler | open_run_level | Travel to the contract target | the cider orchard rows south of Alderwatch | 90/84 | 22.5 s |
| 8 | I ask the old man where the wolf's tracks are freshest and follow the trail toward the far fence, staying alert for movement in the trees. | Erzähler | open_run_level | Track the gray wolf toward the wood | the alder wood beyond the far fence | 90/84 | 34.9 s |
| 9 | I move quietly along the cattle path toward where the branch snapped, dagger drawn, watching the undergrowth for the gray wolf. | Erzähler | open_run_level | Stalk the wolf into the wood | the alder wood beyond the far fence | 90/84 | 16.2 s |
| 10 | I circle quietly upslope to the right, using the bracken for cover, dagger ready, trying to get behind the sound. | Erzähler | open_run_level | Stalk the wolf from behind | the alder wood beyond the far fence | 90/84 | 20.9 s |
| 11 | I strike now from behind, driving my dagger into the wolf's flank while its head is still turning away. | Erzähler | open_run_level | Ambush the wolf with a backstab before it detects me | the alder wood beyond the far fence | 90/84 | 17.8 s |
| 12 | I charge the last paces and attack the wolf with Piercing Thrust, closing to ENGAGED range. | Erzähler | open_run_level | Close to engaged and strike the wolf | the alder wood beyond the far fence | 90/84 | 17.5 s |
| 13 | I take the cattle path back to Alderwatch and turn in Cull the Orchard Prowler at the Guild hall. | Erzähler | open_run_level | Turn in the wolf contract | Adventurers' Guild hall, Alderwatch | 90/84 | 16.9 s |
| 14 | #assign AGI 2 PER 2 VIT 1 | System (Befehl) | open_run_level | Spend level-up stat points | Adventurers' Guild hall, Alderwatch | 90/84 | 2.1 s |
| 15 | I ask the clerk if there are any other novice contracts on the board, and check the board for wolf or beast hunts. | Erzähler | open_run_level | Pick a next Guild contract | Adventurers' Guild hall, Alderwatch | 90/84 | 12.7 s |
| 16 | I take the Millpond Snapping Turtles contract from the board and ask the clerk to register it as active. | Erzähler | open_run_level | Accept a suitable novice hunt | Adventurers' Guild hall, Alderwatch | 90/84 | 12.4 s |
| 17 | Before heading out, I ask the clerk where a smith or weapons merchant can be found in Alderwatch. | Erzähler | open_run_level | Find gear shops to upgrade weapons and armour before the hunt | Adventurers' Guild hall, Alderwatch | 90/84 | 12.5 s |
| 18 | I head to Cobb's Row and enter Halloran's forge to look at light weapons and light armour. | Erzähler | open_run_level | Shop for gear upgrades before the turtle hunt | Halloran's forge | 90/84 | 19.3 s |
| 19 | I'll take the leather-and-cloth jack for 48 copper and wear it now. | Erzähler | open_run_level | Buy affordable light armour upgrade, keep 22 cp | Halloran's forge | 90/84 | 16.0 s |
| 20 | I thank Halloran and head out of the forge toward the Millpond to start the snapping turtles contract. | Erzähler | open_run_level | Travel to Millpond for the turtle hunt | the millpond at Gristbeck, upstream of the millrace gates | 90/84 | 16.6 s |
| 21 | I move quietly along the upstream bank toward the fallen willow, staying low in the reeds, and keep watch for the turtles. | Erzähler | open_run_level | Hunt snapping turtles for the active contract | the millpond at Gristbeck, upstream of the millrace gates | 90/84 | 20.2 s |
| 22 | I burst from the reeds and strike the nearer turtle with Piercing Thrust before it can alarm the second one. | Erzähler | open_run_level | Ambush the spotted turtle | the millpond at Gristbeck, upstream of the millrace gates | 90/84 | 16.7 s |
| 23 | I wade into the shallows and close with the nearer turtle, striking it with Piercing Thrust. | Erzähler | open_run_level | Engage the turtle at close range | the millpond at Gristbeck, upstream of the millrace gates | 83/84 | 16.8 s |
| 24 | I twist the dagger free and strike again with Piercing Thrust at the wounded turtle. | Erzähler | open_run_level | Finish turtle B before turtle A arrives | the millpond at Gristbeck, upstream of the millrace gates | 83/84 | 15.4 s |
| 25 | I check the contract slip to see whether the defeated turtle counts toward the 0/4 tally, then watch the water where the second turtle subme… | Erzähler | open_run_level | Confirm contract progress after first turtle kill | the millpond at Gristbeck, upstream of the millrace gates | 83/84 | 16.5 s |
| 26 | I back toward the bank, ready my dagger, and hurl a stone at the spreading ripples by the willow to provoke the hidden turtle into surfacing… | Erzähler | open_run_level | Lure the submerged turtle A into attack range | the millpond at Gristbeck, upstream of the millrace gates | 83/84 | 24.9 s |
| 27 | I hold my ground at the bank's edge and strike turtle A with Piercing Thrust the moment it comes within reach. | Erzähler | open_run_level | Engage approaching turtle A at close range | the millpond at Gristbeck, upstream of the millrace gates | 83/84 | 14.1 s |
| 28 | I hold my position at the bank's edge and wait until turtle A reaches the shallows, then strike with Piercing Thrust as soon as it is ENGAGE… | Erzähler | open_run_level | Wait for turtle A to close into ENGAGED range, then attack | the millpond at Gristbeck, upstream of the millrace gates | 83/84 | 16.5 s |
| 29 | I wade into the shallows toward turtle A and strike it with Piercing Thrust as soon as I reach it. | Erzähler | open_run_level | Close from SHORT to ENGAGED and attack | the millpond at Gristbeck, upstream of the millrace gates | 76/84 | 17.6 s |
| 30 | I strike turtle A again with Piercing Thrust. | Erzähler | open_run_level | Finish wounded turtle A | the millpond at Gristbeck, upstream of the millrace gates | 69/84 | 13.3 s |
| 31 | I finish turtle A with a basic attack. | Erzähler | open_run_level | Kill the 1-HP turtle | the millpond at Gristbeck, upstream of the millrace gates | 69/84 | 15.4 s |
| 32 | #assign AGI 2 PER 2 WIL 1 | System (Befehl) | open_run_level | Spend level-up points | the millpond at Gristbeck, upstream of the millrace gates | 69/84 | 2.2 s |
| 33 | I search the darkening pond for the next snapping turtle and engage it when found. | Erzähler | open_run_level | Continue the cull contract | the millpond at Gristbeck, upstream of the millrace gates | 69/84 | 17.5 s |
| 34 | I strike turtle C with Piercing Thrust as it charges. | Erzähler | open_run_level | Attack engaged turtle C | the millpond at Gristbeck, upstream of the millrace gates | 62/84 | 18.5 s |
| 35 | I strike turtle C again with Piercing Thrust to finish it. | Erzähler | open_run_level | Kill wounded turtle C | the millpond at Gristbeck, upstream of the millrace gates | 62/84 | 15.4 s |
| 36 | I search the shallows for the fourth snapping turtle and engage it when found. | Erzähler | open_run_level | Find and fight the last turtle for the cull | the millpond at Gristbeck, upstream of the millrace gates | 62/84 | 16.8 s |
| 37 | I step back toward the shallows and ready my blade, trying to bait the turtle into following me onto the mud shelf. | Erzähler | open_run_level | Bait turtle D into shallow water where I can fight it safely | the millpond at Gristbeck, upstream of the millrace gates | 62/84 | 14.1 s |
| 38 | I step to the channel edge and strike turtle D with Piercing Thrust as soon as it comes within reach. | Erzähler | open_run_level | Engage the wary turtle D at the deep-water line | the millpond at Gristbeck, upstream of the millrace gates | 62/84 | 14.4 s |
| 39 | I wade into the deep channel toward turtle D and strike it with Piercing Thrust as soon as it comes within reach. | Erzähler | open_run_level | Close to MEDIUM range and attack the wary turtle D | the millpond at Gristbeck, upstream of the millrace gates | 62/84 | 17.2 s |
| 40 | I close the distance to turtle D until we are ENGAGED, then strike it with Piercing Thrust. | Erzähler | open_run_level | Close to ENGAGED range and attack turtle D | the millpond at Gristbeck, upstream of the millrace gates | 62/84 | 14.7 s |
| 41 | I throw a Fan of Blades at turtle D across the water. | Erzähler | open_run_level | Use ranged AoE skill to hit the turtle holding MEDIUM range | the millpond at Gristbeck, upstream of the millrace gates | 62/84 | 12.3 s |
| 42 | I give up on turtle D for tonight and wade back to shore, then head to Gristbeck to find lodging for the night. | Erzähler | open_run_level | Disengage from the unwinnable standoff, recover, and return fresh | Gristbeck | 62/84 | 23.3 s |
| 43 | I open the inn door and ask the innkeep for a room for the night. | Erzähler | open_run_level | Get lodging and sleep until morning | Gristbeck inn common room | 62/84 | 19.5 s |
| 44 | I walk to the counter and say to the innkeeper, "I'd like a room for the night. What's the price?" | Erzähler | open_run_level | Buy lodging and sleep until morning | Gristbeck inn common room | 62/84 | 28.0 s |
| 45 | I pay the innkeeper two copper for the small room, then go up and sleep until morning. | Erzähler | open_run_level | Buy lodging and sleep until morning | Gristbeck inn common room | 105/88 | 18.9 s |
| 46 | I go downstairs and ask the innkeeper where I can find a smith or weapons merchant in Gristbeck. | Erzähler | open_run_level | Find a smith to check gear before resuming the turtle cull | Gristbeck inn common room | 105/88 | 22.4 s |
| 47 | I follow the mill lane to Tam Weldon's forge and ask whether he has a light blade or leather gear that would suit a rogue. | Erzähler | open_run_level | Check gear at the village smith | Tam Weldon's forge | 105/88 | 29.8 s |
| 48 | "Hone it, please." I hand over a copper and wait while he works the dagger. | Erzähler | open_run_level | Accept the confirmed hone offer and pay | Tam Weldon's forge | 105/88 | 17.6 s |
| 49 | "That's all, thank you." I head back up the mill lane to the millpond to hunt the snapping turtles. | Erzähler | open_run_level | Resume the turtle cull contract | the millpond at Gristbeck, upstream of the millrace gates | 105/88 | 16.1 s |
| 50 | I follow the tracks south along the open shore, keeping low and watching the waterline for turtles. | Erzähler | open_run_level | Hunt snapping turtles for the cull contract | the warm mudflat south along the shore | 105/88 | 21.7 s |
| 51 | I wade quietly toward the nearer turtle, then strike at its neck with Piercing Thrust. | Erzähler | open_run_level | Attack turtle E with Piercing Thrust | the warm mudflat south along the shore | 98/88 | 15.7 s |
| 52 | I twist the dagger free and strike again with Piercing Thrust at the turtle's neck. | Erzähler | open_run_level | Finish turtle F with Piercing Thrust | the warm mudflat south along the shore | 98/88 | 14.9 s |
| 53 | I stand my ground in the shallows and strike the big turtle's extended neck with Piercing Thrust as it comes within reach. | Erzähler | open_run_level | Attack turtle E with Piercing Thrust | the warm mudflat south along the shore | 98/88 | 14.3 s |
| 54 | I push through the shallows to close the distance to the big turtle, then strike its neck with Piercing Thrust. | Erzähler | open_run_level | Move to ENGAGED with turtle E and attack | the warm mudflat south along the shore | 98/88 | 15.0 s |
| 55 | I hold perfectly still in the shallows, dagger low, waiting to see if the big turtle closes the distance on its own. | Erzähler | open_run_level | Let the turtle come into ENGAGED range before striking | the warm mudflat south along the shore | 98/88 | 17.7 s |
| 56 | I strike down at the bulge moving under the water toward my legs with Piercing Thrust. | Erzähler | open_run_level | Attack the approaching turtle now at ENGAGED range | the warm mudflat south along the shore | 91/88 | 20.2 s |
| 57 | I strike again at the turtle's wounded neck with Piercing Thrust. | Erzähler | open_run_level | Finish turtle E while it is in reach | the warm mudflat south along the shore | 91/88 | 15.0 s |
| 58 | #assign AGI 2 PER 2 VIT 1 | System (Befehl) | open_run_level | Spend the 5 free stat points from the level-up | the warm mudflat south along the shore | 91/88 | 2.4 s |
| 59 | I wade closer to the dark hump on the deadfall and strike it with Piercing Thrust if it proves to be a turtle, not a log. | Engine (Menü/Rückfrage) | open_run_level | Check the possible basking turtle and attack if it is one | the warm mudflat south along the shore | 91/88 | 4.8 s |
| 60 | I check the turtle-cull contract count, then wade back to shore and start skinning none — instead I collect any usable parts from the three … | Erzähler | open_run_level | Check quest progress and head to turn-in | the mill at Gristbeck | 91/88 | 34.0 s |
| 61 | 'Five turtles taken this morning — three big ones and two smaller,' I tell the miller, 'though the Guild slip shows the count not registered… | Erzähler | open_run_level | Report the cull to the miller and address the 0/4 count contradiction | the mill at Gristbeck | 91/88 | 22.5 s |
| 62 | I accept the miller's wife's salve for the bite, thank them both, and set off for the Guildhall to report the cull. | Erzähler | open_run_level | Treat the wound, then turn in the turtle contract at the Guild | Gristbeck Guildhall | 91/88 | 22.3 s |
| 63 | I report the cull to the clerk: five turtles dead, and I lay the scale plates and claws on the counter as proof and hand over the contract s… | Erzähler | open_run_level | Turn in the turtle contract at the Guildhall | Gristbeck Guildhall | 91/88 | 27.8 s |
| 64 | I'll take the road to Dunmarrow's Ford myself and set out east with the cold slip, aiming to turn it in at the registry hall there. | Erzähler | open_run_level | Travel to Dunmarrow's Ford to turn in the cold slip | Dunmarrow's Ford | 91/88 | 25.3 s |
| 65 | I cross the bridge into the Dunmarrow's Ford Guildhall and ask for the registry desk to set right my cold turtle-cull slip. | Erzähler | open_run_level | Turn in the cold slip at the registry hall | Dunmarrow's Ford Guildhall | 91/88 | 25.8 s |
| 66 | "I'll pay the copper six," I tell Master Hult, and hand over the fee for the slip correction. | Erzähler | open_run_level | Pay amendment fee to fix the cold slip | Dunmarrow's Ford Guildhall | 91/88 | 23.1 s |
| 67 | I hand the glowing slip to the counter clerk and ask to be paid out on the turtle cull. | Erzähler | open_run_level | Turn in the corrected turtle contract for the 110 copper reward | Dunmarrow's Ford Guildhall | 91/88 | 19.1 s |
| 68 | "Then I'll cull the four under the live seal," I tell the clerk. "Point me to the right pond — which one does the seal watch now?" | Erzähler | open_run_level | Redo the turtle cull at the correct pond under the lit seal | Dunmarrow's Ford Guildhall | 91/88 | 24.5 s |
| 69 | I take the miller's hayloft for a copper and sleep until morning. | Erzähler | open_run_level | Lodging and recovery before dawn turtle cull | Dunmarrow's Ford Guildhall | 115/88 | 19.1 s |
| 70 | I follow the cart track upstream past the mill to the upper pond and look for turtles basking on the mud. | Erzähler | open_run_level | Cull four turtles under the live seal at the upper pond | the millpond at Gristbeck, upstream of the millrace gates | 115/88 | 17.9 s |
| 71 | I draw my dagger and close on the nearest basking turtle, then strike with Piercing Thrust at Turtle H. | Erzähler | open_run_level | Begin the turtle cull — attack Turtle H | the millpond at Gristbeck, upstream of the millrace gates | 115/88 | 20.8 s |
| 72 | I close the last ten paces of mud to engage Turtle H, then strike with Piercing Thrust. | Erzähler | open_run_level | Engage and attack Turtle H at close range | the millpond at Gristbeck, upstream of the millrace gates | 101/88 | 21.8 s |
| 73 | I finish Turtle H with Piercing Thrust. | Erzähler | open_run_level | Kill the wounded turtle to reduce pressure | the millpond at Gristbeck, upstream of the millrace gates | 87/88 | 18.2 s |
| 74 | I strike Turtle I with Piercing Thrust. | Erzähler | open_run_level | Continue the turtle cull — finish Turtle I | the millpond at Gristbeck, upstream of the millrace gates | 74/88 | 13.5 s |
| 75 | I finish Turtle I with Piercing Thrust. | Erzähler | open_run_level | Kill wounded Turtle I before turning on Turtle J | the millpond at Gristbeck, upstream of the millrace gates | 67/88 | 15.2 s |
| 76 | I strike Turtle J with Piercing Thrust. | Erzähler | open_run_level | Kill the last contracted turtle | the millpond at Gristbeck, upstream of the millrace gates | 61/88 | 11.6 s |
| 77 | I finish Turtle J with Piercing Thrust. | Erzähler | open_run_level | Kill the last contracted turtle | the millpond at Gristbeck, upstream of the millrace gates | 61/88 | 16.4 s |
| 78 | I wade toward Turtle G and strike it with Piercing Thrust to complete the cull of four. | Erzähler | open_run_level | Kill the fourth turtle to finish the contract | the millpond at Gristbeck, upstream of the millrace gates | 52/88 | 15.9 s |
| 79 | I strike Turtle G again with Piercing Thrust. | Erzähler | open_run_level | Kill the fourth turtle to complete the contract | the millpond at Gristbeck, upstream of the millrace gates | 52/88 | 15.3 s |
| 80 | #assign AGI 3 VIT 2 | System (Befehl) | open_run_level | Spend level-up points on AGI and VIT | the millpond at Gristbeck, upstream of the millrace gates | 52/88 | 2.5 s |
| 81 | I collect the turtle proof and head to the Dunmarrow's Ford Guildhall to turn in the turtle cull contract. | Erzähler | open_run_level | Turn in completed contract | Dunmarrow's Ford Guildhall | 52/88 | 29.2 s |
| 82 | I hand the clerk the contract slip and the turtle proof to turn in the cull contract. | Erzähler | open_run_level | Turn in the turtle cull contract at the Guildhall | Dunmarrow's Ford Guildhall | 52/88 | 26.0 s |
| 83 | #quest Cull the Millpond Snapping Turtles | System (Befehl) | open_run_level | Inspect the quest panel to see why the seal has not gone READY | Dunmarrow's Ford Guildhall | 52/88 | 2.5 s |
| 84 | I ask the clerk where to find the registry desk and Master Hult, then go to Hult and ask him to write the correction so the seal watches the… | Erzähler | open_run_level | Get Hult's amendment to fix the seal's anchor | records room of the Dunmarrow's Ford Guildhall | 52/88 | 24.6 s |
| 85 | I take back the plates and travel to the upper millpond at Gristbeck, upstream of the millrace gates, to hunt four snapping turtles under th… | Erzähler | open_run_level | Redo the cull at the correct pond | the millpond at Gristbeck, upstream of the millrace gates | 52/88 | 90.4 s |
| 86 | I use the clay pot of healing salve to treat my wounds, then watch the water near the drowned trunk for the turtle to surface before engagin… | Erzähler | open_run_level | Recover HP before the cull fight | the millpond at Gristbeck, upstream of the millrace gates | 82/88 | 28.7 s |
| 87 | I wait for the turtle to swim closer to the reed line, then strike with Piercing Thrust when it comes within reach. | Erzähler | open_run_level | Engage the first turtle as it approaches | the millpond at Gristbeck, upstream of the millrace gates | 82/88 | 16.1 s |
| 88 | I wade into the shallows toward the drowned trunk, closing the distance to engage the turtle. | Erzähler | open_run_level | Move to MEDIUM→ENGAGED with the turtle | the millpond at Gristbeck, upstream of the millrace gates | 82/88 | 19.3 s |
| 89 | I strike with Piercing Thrust at the turtle's head as it gathers to lunge. | Erzähler | open_run_level | Attack the turtle now in range | the millpond at Gristbeck, upstream of the millrace gates | 82/88 | 33.9 s |
| 90 | I strike with Piercing Thrust at the turtle's beaked head, now within reach. | Erzähler | open_run_level | Attack the ENGAGED turtle | the millpond at Gristbeck, upstream of the millrace gates | 75/88 | 15.6 s |
| 91 | I strike with Piercing Thrust at the turtle's ruined head to finish it. | Erzähler | open_run_level | Kill the first turtle | the millpond at Gristbeck, upstream of the millrace gates | 75/88 | 15.6 s |
| 92 | I check the quest panel to see the turtle cull count. | Erzähler | open_run_level | Verify 4/4 cull progress before turning in | the millpond at Gristbeck, upstream of the millrace gates | 75/88 | 18.6 s |
| 93 | I cut one turtle's head loose as proof of the cull, then travel back to the Gristbeck Guild branch and ask the clerk to verify the four kill… | Erzähler | open_run_level | Turn in the completed cull despite the inert seal | Gristbeck Guildhall | 75/88 | 24.4 s |
| 94 | I unwrap the turtle head on the counter and show the contract slip. "Four turtles culled at the millpond, but the seal never registered a co… | Erzähler | open_run_level | Turn in the millpond cull to the clerk with proof | Gristbeck Guildhall | 75/88 | 18.2 s |
| 95 | I pick the head back up and ask the clerk where the leatherworker's shop is, then go there and offer my 23 turtle scale plates for sale. | Erzähler | open_run_level | Sell surplus loot at the leatherworker | Tam Breech's leatherworker shop | 75/88 | 26.6 s |
| 96 | I step inside and lay my 23 turtle scale plates out plain on his bench. "What will you give me for these plates?" | Erzähler | open_run_level | Get an offer for the turtle plates | Tam Breech's leatherworker shop | 75/88 | 19.1 s |
| 97 | "Deal on the plates—23 at six copper. Add the 15 claws at a copper each and I'll take the lot." |  | open_run_level | Accept confirmed offer for plates and sell claws too | Tam Breech's leatherworker shop | 75/88 | 13.6 s |
| 98 | "Twenty-three plates at six copper each, and fifteen claws at one copper each. I'll sell you the lot for one silver, fifty-three copper." | Erzähler | open_run_level | Accept Tam's confirmed offer for plates and claws | Tam Breech's leatherworker shop | 75/88 | 20.6 s |
| 99 | I dump the turtle head at the midden past the water gate, then look for a smith or weapons merchant in Gristbeck to compare daggers and ligh… | Erzähler | open_run_level | Dispose of the head and pursue the gear priority | the smithy behind the market square | 75/88 | 27.6 s |
| 100 | I look over the long knives and the studded jack on her wall. "What are you asking for the long knife, and for the studded jack?" | Erzähler | open_run_level | Compare weapon and armour prices at the smith | the smithy behind the market square | 75/88 | 15.7 s |
| 101 | I leave the long knife on the counter. "Same attack as the blade I carry, and the jack won't count as armor—no deal today. I head for the mi… | Erzähler | open_run_level | Decline non-upgrades and resume the active turtle cull contract | the millpond at Gristbeck, upstream of the millrace gates | 75/88 | 28.2 s |
| 102 | I move along the gravel margin to within reach of the sunning turtle K and attack it with Piercing Thrust. | Erzähler | open_run_level | Start the turtle cull, first target turtle K | the millpond at Gristbeck, upstream of the millrace gates | 75/88 | 17.1 s |
| 103 | I wade into the shallows toward the sunning turtle K, keeping my eyes on the reedbed, and attack it with Piercing Thrust once in reach. | Erzähler | open_run_level | Close to MEDIUM turtle and engage | the millpond at Gristbeck, upstream of the millrace gates | 68/88 | 19.3 s |
| 104 | I finish it with Piercing Thrust. | Erzähler | open_run_level | Kill turtle K | the millpond at Gristbeck, upstream of the millrace gates | 68/88 | 17.1 s |
| 105 | I check whether the contract counter recorded this kill, then look for the next turtle. | Erzähler | open_run_level | Track cull progress and continue | the millpond at Gristbeck, upstream of the millrace gates | 68/88 | 18.9 s |
| 106 | I retreat onto the gravel bank out of reach and rest until my stamina recovers, watching the two turtles. | Erzähler | open_run_level | Recover STA before engaging the next turtle | the gravel margin of the millpond | 68/88 | 23.7 s |
| 107 | I sit down on the dry gravel bank out of the turtles' reach and rest until my stamina recovers. | Engine (Menü/Rückfrage) | open_run_level | Recover STA before engaging turtle M or L | the gravel margin of the millpond | 68/88 | 5.0 s |
| 108 | I rest on the dry gravel bank for two hours, out of the turtles' reach. | Erzähler | open_run_level | Recover STA with named duration | the gravel margin of the millpond | 94/88 | 18.5 s |
| 109 | I cross the forty paces to the sleeping turtles on the sand and attack the nearer one with Piercing Thrust before it can react. | Erzähler | open_run_level | Engage a resting turtle while STA permits | the gravel margin of the millpond | 94/88 | 13.0 s |
| 110 | I wade across the shallows to the nearer sleeping turtle and attack it with Piercing Thrust once in range. | Erzähler | open_run_level | Close to engaged range and strike turtle M | the gravel margin of the millpond | 94/88 | 15.9 s |
| 111 | I move to ENGAGED range with the nearer sleeping turtle, then attack it with Piercing Thrust. | Erzähler | open_run_level | Close distance and strike turtle M | the gravel margin of the millpond | 94/88 | 14.7 s |
| 112 | I wade across the shallows toward the nearer sleeping turtle, closing to ENGAGED range. | Erzähler | open_run_level | Declare movement alone, then attack next turn | the gravel margin of the millpond | 94/88 | 16.8 s |
| 113 | I close the last stride to ENGAGED range with the nearer turtle and attack it with Piercing Thrust. | Erzähler | open_run_level | Strike turtle M once in range | the gravel margin of the millpond | 94/88 | 20.6 s |
| 114 | I move to ENGAGED range with the nearer turtle. | Erzähler | open_run_level | Close the final distance to turtle M before striking | the gravel margin of the millpond | 94/88 | 30.9 s |
| 115 | I move to ENGAGED range with the nearer turtle. | Erzähler | open_run_level | Close the final range step to turtle M | the gravel margin of the millpond | 94/88 | 19.2 s |
| 116 | I attack the sleeping turtle with Piercing Thrust, aiming for the bare join of its neck. | Erzähler | open_run_level | Strike turtle M now that it is ENGAGED | the gravel margin of the millpond | 94/88 | 17.3 s |
| 117 | I move toward the larger sleeping turtle, closing from LONG range. |  | open_run_level | Close on turtle L for the next ambush kill | the gravel margin of the millpond | 94/88 | 7.1 s |
| 118 | I wade toward the larger sleeping turtle at LONG range, closing to SHORT range. | Erzähler | open_run_level | Close on turtle L for the next ambush kill | the gravel margin of the millpond | 94/88 | 14.2 s |
| 119 | I move to ENGAGED range with the larger sleeping turtle. | Erzähler | open_run_level | Close the next range step to turtle L for an ambush kill | the gravel margin of the millpond | 94/88 | 14.7 s |
| 120 | I attack the sleeping turtle L with Piercing Thrust, striking the bare join of its neck. | Erzähler | open_run_level | Ambush-kill turtle L now that it is ENGAGED at SHORT range | the gravel margin of the millpond | 94/88 | 14.9 s |
| 121 | I step to ENGAGED range with turtle L and attack its bare neck with Piercing Thrust. | Erzähler | open_run_level | Close the final range step and strike turtle L | the gravel margin of the millpond | 94/88 | 14.8 s |
| 122 | I search the millpond margin for another snapping turtle, staying wary of the reedbed where the surface bulged earlier. | Erzähler | open_run_level | Continue the cull quest toward 4 turtles | the gravel margin of the millpond | 94/88 | 24.1 s |
| 123 | I check #quests to see whether the two defeated turtles have registered before I hunt the remaining two. | Erzähler | open_run_level | Verify quest counter before continuing the cull | the gravel margin of the millpond | 94/88 | 15.1 s |
| 124 | I watch the stirred silt in the cut below me, dagger ready, and strike at any turtle that surfaces there. | Erzähler | open_run_level | Ambush a turtle possibly hiding in the cut | the gravel margin of the millpond | 94/88 | 19.2 s |
| 125 | I strike the stretched neck of turtle N with Piercing Thrust the moment its head breaks the surface. | Erzähler | open_run_level | Ambush-kill turtle N in the cut | the gravel margin of the millpond | 87/88 | 17.3 s |
| 126 | I finish turtle N with a Basic Attack to the wounded neck. | Erzähler | open_run_level | Kill turtle N for the cull quest | the gravel margin of the millpond | 87/88 | 15.4 s |
| 127 | I return to the Valedorn Crown Guild hall with proof of the four defeated turtles and ask to have the cull quest counted and turned in. | Engine (Menü/Rückfrage) | open_run_level | Turn in the turtle cull quest | the gravel margin of the millpond | 87/88 | 5.8 s |
| 128 | I head for the Alderwatch Guild hall with proof of the four defeated turtles and ask to have the cull quest counted and turned in. | Erzähler | open_run_level | Turn in the turtle cull quest at Alderwatch | Adventurers' Guild hall, Alderwatch | 87/88 | 22.2 s |
| 129 | I ask the clerk to send someone out to the millpond to verify the four defeated turtles, since the seal won't show. | Erzähler | open_run_level | Resolve stuck quest count via clerk's verification offer | Adventurers' Guild hall, Alderwatch | 87/88 | 21.2 s |
| 130 | I look for a merchant still open tonight and offer my 30 turtle scale plates and 17 claws for sale, asking his price. | Erzähler | open_run_level | Sell surplus loot before lodging | Harlow's hide shop | 87/88 | 24.6 s |
| 131 | I accept Harlow's offer and sell him all 30 plates and 17 claws for two silver and ten copper. | Erzähler | open_run_level | Sell surplus loot to Harlow | Harlow's hide shop | 87/88 | 17.9 s |
| 132 | I ask Harlow if he stocks light weapons and light armour, since I have coin to spend on better gear. | Erzähler | open_run_level | Check gear options with Harlow before hunting again | Harlow's hide shop | 87/88 | 17.6 s |
| 133 | I tell Harlow the 56 copper leathers are beyond my purse tonight, thank him, and ask where I can find a cheap bed for the night. | Erzähler | open_run_level | Decline unaffordable armor, seek lodging | Harlow's hide shop | 87/88 | 19.7 s |
| 134 | I head to Marrow's on Fishery Row and pay one copper for a hammock in the drying loft, then sleep until morning. | Erzähler | open_run_level | Recover overnight cheaply | Marrow's smokehouse | 87/88 | 25.4 s |
| 135 | I head to the Guild hall and ask the clerk to send the verifier out to the millpond to confirm the four snapping turtles I defeated, since m… | Erzähler | open_run_level | Resolve stuck turtle quest count via clerk verification | Adventurers' Guild hall, Alderwatch | 87/88 | 21.5 s |
| 136 | I take the contract slip and head out to the Gristbeck millpond to hunt four snapping turtles under the live seal. | Erzähler | open_run_level | Redo the turtle cull so the Guild seal records the kills | the millpond at Gristbeck, upstream of the millrace gates | 87/88 | 19.5 s |
| 137 | I move to the shallows and attack the turtle with Piercing Thrust, drawing it out of the water where I can fight it on the bank. | Erzähler | open_run_level | Fight the first turtle under the live seal | the millpond at Gristbeck, upstream of the millrace gates | 87/88 | 22.6 s |
| 138 | I wade into the shallows up to my knees and hold my ground, dagger ready, waiting for the turtle to come within reach before I strike with P… | Erzähler | open_run_level | Engage the turtle at MEDIUM range by luring it into ENGAGED | the millpond at Gristbeck, upstream of the millrace gates | 87/88 | 16.3 s |
| 139 | I wade out through the shallows toward the turtle, closing the distance to ENGAGED range. | Erzähler | open_run_level | Close range so Piercing Thrust can reach the turtle | the millpond at Gristbeck, upstream of the millrace gates | 87/88 | 15.9 s |
| 140 | I strike the turtle with Piercing Thrust, aiming for its exposed neck. | Erzähler | open_run_level | Attack the engaged turtle | the millpond at Gristbeck, upstream of the millrace gates | 81/88 | 17.5 s |
| 141 | I finish it with a Basic Attack, keeping my footing on the sunken wood. | Erzähler | open_run_level | Kill the turtle | the millpond at Gristbeck, upstream of the millrace gates | 81/88 | 18.5 s |
| 142 | #assign AGI 2 VIT 2 WIL 1 | System (Befehl) | open_run_level | Spend level-up points | the millpond at Gristbeck, upstream of the millrace gates | 81/88 | 2.8 s |
| 143 | I climb out onto the bank at a safe distance from the dead turtle and rest until my stamina recovers before going after the next turtle. | Erzähler | open_run_level | Recover STA before continuing the cull | the millpond at Gristbeck, upstream of the millrace gates | 81/88 | 17.1 s |
| 144 | I rest for two hours, then get up ready to hunt the next turtle. | Erzähler | open_run_level | Recover stamina | the millpond at Gristbeck, upstream of the millrace gates | 110/92 | 17.5 s |
| 145 | I search the cut below the gravel margin for the next turtle. | Erzähler | open_run_level | Continue the turtle cull | the millpond at Gristbeck, upstream of the millrace gates | 110/92 | 16.6 s |
| 146 | I search the reed beds for the next turtle. | Erzähler | open_run_level | Continue the turtle cull | the millpond at Gristbeck, upstream of the millrace gates | 110/92 | 17.4 s |
| 147 | I close the ten paces quickly and drive a Piercing Thrust into the turtle's exposed neck before it can react. | Erzähler | open_run_level | Attack turtle P with Piercing Thrust | the millpond at Gristbeck, upstream of the millrace gates | 110/92 | 17.4 s |
| 148 | I drag the second turtle's carcass into the open calm beside the first, then search the dark water beyond the race gates for the next turtle… | Erzähler | open_run_level | Continue the turtle cull | the millpond at Gristbeck, upstream of the millrace gates | 110/92 | 20.4 s |
| 149 | I take a breath and dive down onto the turtle from directly above, driving a Piercing Thrust into its neck as an ambush strike, then surface… | Erzähler | open_run_level | Ambush turtle Q from above in the deep water | the millpond at Gristbeck, upstream of the millrace gates | 110/92 | 14.8 s |
| 150 | I dive down and swim the last body-length to close with the turtle, then drive a Piercing Thrust into its folded neck. | Erzähler | open_run_level | Close to ENGAGED, then ambush-strike turtle Q | the millpond at Gristbeck, upstream of the millrace gates | 110/92 | 15.0 s |
| 151 | I dive down and swim the last body-length to close with the turtle. | Erzähler | open_run_level | Close to ENGAGED with turtle Q | the millpond at Gristbeck, upstream of the millrace gates | 110/92 | 13.9 s |
| 152 | I drive a Piercing Thrust into the turtle's folded neck. | Erzähler | open_run_level | Attack turtle Q at ENGAGED range | the millpond at Gristbeck, upstream of the millrace gates | 110/92 | 23.0 s |
| 153 | I surface and catch my breath, then look for the fourth and last turtle in the pond. | Erzähler | open_run_level | Finish the cull's final turtle | the millpond at Gristbeck, upstream of the millrace gates | 110/92 | 20.5 s |
| 154 | I swim along the near bank, out of the main current, and work my way around toward the turtle wedged at the gate bars. | Erzähler | open_run_level | Close on turtle R via the bank to avoid the current | the millrace gate bars | 110/92 | 18.1 s |
| 155 | I wait for the turtle to keep feeding, then swim the shallow edge toward the stone and drive a Piercing Thrust into its neck as an ambush st… | Erzähler | open_run_level | Ambush-strike turtle R at the gate | the millrace gate bars | 110/92 | 40.6 s |
| 156 | All four turtles are dead, so I head back through the reeds and along the bank toward the mill, then on to the Guild hall in Valedorn Crown … | Erzähler | open_run_level | Return to the Guild hall and turn in the completed cull contract | Adventurers' Guild hall, Alderwatch | 110/92 | 24.9 s |
| 157 | #quest Cull the Millpond Snapping Turtles | System (Befehl) | open_run_level | Inspect the contract's tracked conditions | Adventurers' Guild hall, Alderwatch | 110/92 | 2.9 s |
| 158 | I take a room at the nearest inn and sleep until morning. | Erzähler | open_run_level | Recover overnight; turn in at the Guild after the runner's first-light verification | Timbered inn with the painted bush | 110/92 | 22.0 s |
| 159 | I go down to the common room, eat the cold bread, and ask the innkeeper's wife whether the Guild runner has already left for the millpond th… | Erzähler | open_run_level | Check on the verification runner at first light | Timbered inn with the painted bush | 110/92 | 18.0 s |
| 160 | I eat some bread and thank her, then head to the Guild hall to meet the runner as it leaves at opening. | Erzähler | open_run_level | Reach the Guild hall at opening for the first-light verification ride | Adventurers' Guild hall, Alderwatch | 110/92 | 18.8 s |
| 161 | I tell the clerk I've culled four turtles at Gristbeck millpond and ask if the runner heading out this morning can verify the carcasses so I… | Erzähler | open_run_level | Arrange first-light verification of the turtle kills | Adventurers' Guild hall, Alderwatch | 110/92 | 18.0 s |
| 162 | I show the runner the two giant snapping turtle scale plates I carried back and ask him to look for the carcasses at the pond; I leave the s… | Erzähler | open_run_level | Arrange verification of the turtle kills | Adventurers' Guild hall, Alderwatch | 110/92 | 17.9 s |
| 163 | I look around the Guild hall for a loot trader or broker and offer the gray wolf pelt, wolf fang, two turtle scale plates, and turtle claws … | Erzähler | open_run_level | Sell surplus loot to fund gear shopping | Adventurers' Guild hall, Alderwatch | 110/92 | 21.1 s |
| 164 | I wait for sunrise, then go to Harlow's hide shop in Copperlane and ask his prices for my gray wolf pelt, wolf fang, two turtle scale plates… | Erzähler | open_run_level | Sell surplus loot at Harlow's once it opens | Harlow's hide shop | 110/92 | 22.7 s |
| 165 | I accept — "26 copper for the lot, deal." I take the coins, then head to Halloran's forge to compare prices on a better light blade and ligh… | Engine (Menü/Rückfrage) | open_run_level | Sell loot, then shop for gear upgrades | Harlow's hide shop | 110/92 | 14.7 s |
| 166 | I sell the gray wolf pelt, gray wolf fang, two turtle scale plates, and two turtle claws to Harlow for 26 copper total. | Erzähler | open_run_level | Complete the confirmed sale, then shop for gear | Harlow's hide shop | 110/92 | 26.8 s |
| 167 | I lay the gray wolf pelt, gray wolf fang, two turtle scale plates, and two turtle claws on Harlow's counter and hand them over at the agreed… | Erzähler | open_run_level | Complete the sale Harlow already priced | Harlow's hide shop | 110/92 | 32.3 s |
| 168 | I take the 26 copper, then sell Harlow my remaining turtle plates and claws at his quoted rates — five copper per plate, one per claw. |  | open_run_level | Complete the sale and sell surplus turtle loot | Harlow's hide shop | 110/92 | 12.3 s |
| 169 | I count the 26 copper and take it, then ask Harlow to weigh the remaining turtle plates and claws in my pouch — I have two scale plates and … | Erzähler | open_run_level | Collect payment and sell remaining turtle loot at clear prices | Harlow's hide shop | 110/92 | 39.2 s |
| 170 | I place the two Giant Snapping Turtle Scale Plates and the two Giant Snapping Turtle Claws on Harlow's counter one at a time and hand them o… | Erzähler | open_run_level | Complete the turtle loot sale at Harlow's quoted rates | Harlow's hide shop | 110/92 | 32.4 s |
| 171 | I tip the whole pouch out on Harlow's counter and sort out exactly two Giant Snapping Turtle Scale Plates and two Giant Snapping Turtle Claw… |  | open_run_level | Sell the sorted turtle loot at Harlow's standing rates | Harlow's hide shop | 110/92 | 14.8 s |
| 172 | I sell Harlow two Giant Snapping Turtle Scale Plates at five copper each and two Giant Snapping Turtle Claws at one copper each — total twel… | Erzähler | open_run_level | Complete the turtle loot sale with explicit per-item prices | Harlow's hide shop | 110/92 | 28.2 s |
| 173 | #bag | System (Befehl) | open_run_level | Inspect actual inventory to sort the pouch problem | Harlow's hide shop | 110/92 | 2.8 s |
| 174 | I sell Harlow all five Giant Snapping Turtle Scale Plates at five copper each and all five Giant Snapping Turtle Claws at one copper each — … | Erzähler | open_run_level | Sell the full turtle lot in one transaction | Harlow's hide shop | 110/92 | 33.3 s |
| 175 | I lay one Giant Snapping Turtle Scale Plate on Harlow's counter and sell it to him for five copper. | Erzähler | open_run_level | Sell turtle plates one at a time to work around the pouch problem | Harlow's hide shop | 110/92 | 26.9 s |
| 176 | I sell Harlow the F-Rank Gray Wolf Pelt from my bag — what's your price for it? | Erzähler | open_run_level | Sell the retrievable pelt instead of the unreachable turtle pieces | Harlow's hide shop | 110/92 | 21.4 s |
| 177 | "Go ahead, Harlow — take a look." I set the pouch on the counter and step back so he can examine it. | Erzähler | open_run_level | Let Harlow inspect the malfunctioning pouch | Harlow's hide shop | 110/92 | 30.5 s |
| 178 | "It's the pouch I started with — issued to me when I signed on as a rogue. I never bought it from anyone. If something's wrong with it, it c… | Erzähler | open_run_level | Answer Harlow's question about the pouch's origin | Harlow's hide shop | 110/92 | 30.7 s |
| 179 | I take the pouch back and head to the Guild hall to ask them to examine the issued pouch that's holding back my goods. | Erzähler | open_run_level | Take Harlow's advice to the Guild | Adventurers' Guild hall, Alderwatch | 110/92 | 22.9 s |
| 180 | "Since day one — it was issued to me when I registered. It's held back pelts and turtle plates and claws, never coin. I noticed it when Harl… | Erzähler | open_run_level | Answer the clerk's questions about the pouch while waiting for Vessa | Adventurers' Guild hall, Alderwatch | 110/92 | 24.8 s |
| 181 | "I reached in for the wolf pelt to sell it. My fingers found fur, but it slid off sideways, deeper than the bag's depth — like it was a full… | Erzähler | open_run_level | Answer Vessa's question about what my hand found in the pouch | Adventurers' Guild hall, Alderwatch | 110/92 | 19.9 s |
| 182 | "No — nothing I didn't put in has ever come out of it. It only holds things back, never adds anything." | Erzähler | open_run_level | Answer Vessa's question honestly | Adventurers' Guild hall, Alderwatch | 110/92 | 23.2 s |
| 183 | "Then I'll wait for Tam. Is there any Guild work I could take on in the meantime, or shall I just sit and have some of that bread?" | Erzähler | open_run_level | Wait for Tam, ask about interim work | Adventurers' Guild hall, Alderwatch | 110/92 | 27.7 s |
| 184 | I hand Tam my hand as asked and let him test what the pouch is anchored to. |  | open_run_level | Cooperate with Tam's anchor test | Adventurers' Guild hall, Alderwatch | 110/92 | 31.8 s |
| 185 | "Think back to who held this hand long — the night I registered, the clerk took my hand to press the seal, and the healer who bound my arm a… | Erzähler | open_run_level | Ask Tam to read the enchantment's signature before unravelling | Adventurers' Guild hall, Alderwatch | 110/92 | 31.1 s |
| 186 | Go ahead and unravel it, Tam — keep the thread whole. The healer was at the Guild's field tent after the wolf hunt two nights back; a hedge-… | Erzähler | open_run_level | Have Tam unravel the storage thread while preserving it as evidence | Adventurers' Guild hall, Alderwatch | 110/92 | 25.4 s |
| 187 | I take the tube and thank Tam, then go to the front desk and ask the clerk to check the field tent's roll for the gray hedge-healer who boun… | Erzähler | open_run_level | Report the healer and check the field tent roll | Adventurers' Guild hall, Alderwatch | 110/92 | 23.4 s |
| 188 | "Send for Odo, please. And log this as an inquiry, not a complaint yet — I had a hidden enchantment thread found in my pouch, and Tam's kept… | Erzähler | open_run_level | Have the clerk send for Odo with the field tent roll and state the reason as an inquiry | Adventurers' Guild hall, Alderwatch | 110/92 | 34.0 s |
| 189 | I hand Odo the wrapped tube and tell him plainly: Tam found a hidden storage thread grown into the lining of my pouch, woven under a numbing… | Erzähler | open_run_level | Show Odo the preserved thread as evidence | Adventurers' Guild hall, Alderwatch | 110/92 | 31.8 s |
| 190 | All three, please — log the tube as evidence, send word to the other branches, and flag the desk to send for me if she shows her face here. | Erzähler | open_run_level | Close the inquiry properly and return to the turtle cull | Adventurers' Guild hall, Alderwatch | 110/92 | 18.8 s |
| 191 | I head to the millpond and begin hunting snapping turtles under the live seal. | Erzähler | open_run_level | Resume the active turtle cull contract | the millpond at Gristbeck, upstream of the millrace gates | 110/92 | 22.8 s |
| 192 | I move to the cut below the gravel margin and peer into the stirred silt, dagger ready, keeping out of the reeds. | Erzähler | open_run_level | Hunt the turtle likely in the cut | the cut below the gravel margin | 110/92 | 25.2 s |
| 193 | I lunge from the bank and drive Piercing Thrust down at the turtle's head and neck. | Erzähler | open_run_level | Attack the spotted turtle | the cut below the gravel margin | 110/92 | 19.0 s |
| 194 | I follow along the shore to the north end past the sunken punt where the turtle went to sun, and approach it to close into dagger range befo… | Erzähler | open_run_level | Close range with the retreating turtle at its sunning spot | the cut below the gravel margin | 110/92 | 18.2 s |
| 195 | I walk along the open grass shore north past the drovers' watering spot toward the sunken punt, closing the distance to the turtle. | Erzähler | open_run_level | Move to ENGAGED range with the turtle at the north end | the sunken punt | 110/92 | 21.0 s |
| 196 | I stride through the shallows to ENGAGED range and drive Piercing Thrust into the turtle's stretched-out neck. | Erzähler | open_run_level | Close and attack the turtle now at SHORT | the sunken punt | 110/92 | 20.5 s |
| 197 | I wade back to the bank and move quietly along the reed line toward the cut, watching the water for the next turtle. | Erzähler | open_run_level | Continue the turtle cull | the cut below the gravel margin | 110/92 | 15.9 s |
| 198 | I crouch at the gravel margin and skim the cut's surface with Fan of Blades, angling the spread onto the water where a turtle would surface. | Engine (Menü/Rückfrage) | open_run_level | Probe the murky cut with AoE | the cut below the gravel margin | 110/92 | 7.2 s |
| 199 | I stay crouched at the gravel margin and watch the cut's surface for ripples or a rising snout, dagger ready for Piercing Thrust if a turtle… | Erzähler | open_run_level | Ambush a turtle surfacing in the cut | the cut below the gravel margin | 110/92 | 17.7 s |
| 200 | I strike with Piercing Thrust at the turtle's exposed head where it hangs at the drop-off. | Erzähler | open_run_level | Attack the engaged turtle with Piercing Thrust | the cut below the gravel margin | 104/92 | 20.7 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 6 (notiert vor Zug 7): HUD shows 3 Silver despite 50→30 copper registration deduction; likely 3 silver = 30 copper, consistent.
- zu Zug 12 (notiert vor Zug 13): Threat note still shows the wolf alive though engine confirms defeated; HUD shows 3 Silver consistent with 30 copper.
- zu Zug 21 (notiert vor Zug 22): Turtles 70 HP each, contract 0/4 — may need more turtles elsewhere or a second visit.
- zu Zug 23 (notiert vor Zug 24): Piercing Thrust deals 32-39; turtle B at 33 HP, second turtle closing.
- zu Zug 25 (notiert vor Zug 26): Contract slip tally shows 0/4 even after a confirmed kill; tally may only update on Guild turn-in or later.
- zu Zug 31 (notiert vor Zug 32): Tally still 0/4 despite two confirmed kills; may only count at turn-in.
- zu Zug 37 (notiert vor Zug 38): Tally still shows 0/4 despite three confirmed kills; likely counts only at turn-in.
- zu Zug 39 (notiert vor Zug 40): Turtle D retreats whenever I advance; previous attempts failed because movement wasn't declared as part of the attack.
- zu Zug 41 (notiert vor Zug 42): Turtle D holds MEDIUM where neither Piercing Thrust nor Fan of Blades reaches; it never closes. STA at 34 and cold water make pushing on risky.
- zu Zug 43 (notiert vor Zug 44): Engine flagged the earlier request as 'arrival pending' since I was still at the door; now inside and at SHORT range with the innkeeper.
- zu Zug 45 (notiert vor Zug 46): Rest fully recovered; quest still 0/4 turtles. Coin 2 silver meets the gear-check threshold.
- zu Zug 47 (notiert vor Zug 48): Smith offers no blades or armor; tanner Aldous two doors up sells only raw stock — proper gear likely requires Thistlemoor.
- zu Zug 53 (notiert vor Zug 54): Piercing Thrust was refused at MEDIUM range; must declare movement first.
- zu Zug 54 (notiert vor Zug 55): Movement declarations seem not to close range against a retreating turtle; it may only approach on its own.
- zu Zug 60 (notiert vor Zug 61): Quest panel still shows 0/4 defeated despite five turtles killed and the slip showing no READY glow — the engine may not have registered the kills.
- zu Zug 61 (notiert vor Zug 62): Quest still shows 0/4 despite five kills; turn-in at the Guildhall is the next test of whether the engine registered them.
- zu Zug 66 (notiert vor Zug 67): Slip seal now lit after the 6 cp amendment; quest panel still shows 0/4 — payout will confirm whether the engine honors the corrected count.
- zu Zug 67 (notiert vor Zug 68): Slip correction fixed the anchor but recorded 0 kills; must kill 4 more turtles at the right millpond for payout.
- zu Zug 74 (notiert vor Zug 75): A fourth turtle (G) is listed as ENGAGED but not yet fighting — possible incoming reinforcement.
- zu Zug 75 (notiert vor Zug 76): Turtle G still listed ENGAGED but 'not in the fight yet' — watch for it joining after J falls.
- zu Zug 82 (notiert vor Zug 83): Engine shows the cull at 0/4 defeated despite killing turtles; the seal never registered the kills.
- zu Zug 84 (notiert vor Zug 85): Hult's correction is filed but seal still 0/4; must kill four turtles anew at the upstream pond.
- zu Zug 89 (notiert vor Zug 90): Piercing Thrust reach is ENGAGED max; had to close from SHORT first.
- zu Zug 91 (notiert vor Zug 92): HUD says 0/4 defeated but narrator says four of four; quest panel needs checking.
- zu Zug 92 (notiert vor Zug 93): Contract slip shows no kill tally even though narrator confirmed four of four dead — quest panel reads 0/4. Kills may need to happen under a 'live seal' state that expired, or the counter is bugged.
- zu Zug 98 (notiert vor Zug 99): HUD still shows 1s2c despite Tam's confirmed payment of 1s53c; watch the next panel for the corrected coin total. Contract still 0/4 under live seal.
- zu Zug 99 (notiert vor Zug 100): HUD still shows 1s2c although Tam counted out 1s53c — treat live panels as authoritative.
- zu Zug 100 (notiert vor Zug 101): HUD still shows 1s2c despite Tam's counted payment of 1s53c; treating live panels as authoritative. Long knife is ATK 10, same as equipped, so no useful affordable gear here.
- zu Zug 101 (notiert vor Zug 102): HUD still lists the 23 plates and 15 claws as carried despite Tam's confirmed purchase—watch next panels for corrected inventory.
- zu Zug 102 (notiert vor Zug 103): Gear priority already checked this visit: long knife offers no ATK upgrade and the jack isn't supported equipment; continuing.
- zu Zug 105 (notiert vor Zug 106): Quest panel still shows 0/4 defeated despite turtle K's kill; slip seal showed nothing—watch for count updates.
- zu Zug 108 (notiert vor Zug 109): Cull counter still 0/4 despite a confirmed kill — may only count at turn-in.
- zu Zug 110 (notiert vor Zug 111): Prototype resolves one action type per message; must declare movement separately from attack.
- zu Zug 111 (notiert vor Zug 112): Engine requires movement and attack as separate messages; three combined attempts refused.
- zu Zug 113 (notiert vor Zug 114): Movement resolves one range step per message: LONG→MEDIUM, next should reach ENGAGED; terrain cut blocked the combined stride.
- zu Zug 115 (notiert vor Zug 116): Movement resolved one range step per message; turtle M is now ENGAGED.
- zu Zug 116 (notiert vor Zug 117): Quest panel still shows 0/4 defeated despite the confirmed M kill — possible counting lag or the ambush kill not registering; will recheck after turn-in.
- zu Zug 121 (notiert vor Zug 122): Quest counter still shows 0/4 despite two confirmed DEFEATED kills — will recheck before turn-in.
- zu Zug 122 (notiert vor Zug 123): Quest panel showed 0/4 despite two confirmed DEFEATED kills; counter may only update on certain kills or turn-in.
- zu Zug 123 (notiert vor Zug 124): Quest counter still 0/4 after two confirmed kills; may only register at turn-in or need whole count.
- zu Zug 126 (notiert vor Zug 127): HUD still shows 0/4 despite four confirmed DEFEATED kills; turn-in may be required for the count.
- zu Zug 127 (notiert vor Zug 128): Quest panel still shows 0/4 despite four confirmed DEFEATED kills; turn-in pending. Gear check still owed at a safe settlement.
- zu Zug 128 (notiert vor Zug 129): Quest panel shows 0/4 despite four engine-confirmed DEFEATED kills; also carrying 30 plates and 17 claws — surplus loot to sell.
- zu Zug 131 (notiert vor Zug 132): HUD shows 4s2cp despite ENGINE RESULT saying 12→42 copper; coin discrepancy noted. Quest still 0/4 pending tomorrow's verification.
- zu Zug 132 (notiert vor Zug 133): Coin discrepancy persists: HUD shows 4s2cp but ENGINE RESULT said 42 copper after the sale.
- zu Zug 134 (notiert vor Zug 135): HP/STA not fully restored after the night; coin discrepancy with earlier engine result still unexplained.
- zu Zug 135 (notiert vor Zug 136): Engine counts 0/4 despite earlier narrated turtle kills; quest must be redone under the live seal.
- zu Zug 138 (notiert vor Zug 139): Range conflict: HUD shows MEDIUM but engine resolved LONG; engine is authoritative. Engine resolves one action type per message.
- zu Zug 141 (notiert vor Zug 142): STA is very low (12/100) after the fight; may need recovery before continuing the cull.
- zu Zug 148 (notiert vor Zug 149): Quest still shows 0/4 defeated despite two confirmed kills.
- zu Zug 152 (notiert vor Zug 153): Quest panel still shows 0/4 defeated despite three confirmed kills and the narrator's 'the kill counted'.
- zu Zug 153 (notiert vor Zug 154): Quest still shows 0/4 defeated despite three engine-confirmed kills — counter may only update at turn-in.
- zu Zug 155 (notiert vor Zug 156): Quest panel still shows 0/4 defeated after four engine-confirmed kills; counter presumably updates at turn-in.
- zu Zug 156 (notiert vor Zug 157): Turn-in refused: engine counts 0/4 despite four confirmed kills; checking quest details for a hidden condition.
- zu Zug 157 (notiert vor Zug 158): Engine counts 0/4 despite four confirmed kills; quest panel says a runner verifies the carcasses at first light, so turn-in must wait until after that.
- zu Zug 159 (notiert vor Zug 160): Innkeeper's wife says no Guild runner has left yet; it's only 04:04, Guild opens at sunrise.
- zu Zug 161 (notiert vor Zug 162): Quest counter still 0/4 despite four engine-confirmed kills; verification runner offered.
- zu Zug 162 (notiert vor Zug 163): Journal reveals the cull goal reads 'four more turtles' — contract may require four kills beyond earlier ones; counter still 0/4 pending the runner.
- zu Zug 165 (notiert vor Zug 166): System demanded explicit clarification of the sale before it processed; restating the confirmed offer.
- zu Zug 166 (notiert vor Zug 167): Narration claims the priced goods vanished from the counter while the HUD still lists them as carried; engine also said 'nobody to sell to' though Harlow is present. Retrying with explicit handover.
- zu Zug 167 (notiert vor Zug 168): Narration and engine conflicted earlier on the sale; items now confirmed handed over and 26 copper on the counter.
- zu Zug 170 (notiert vor Zug 171): The pouch repeatedly refuses to yield a named lot; emptying and sorting on the counter as Harlow suggested.
- zu Zug 172 (notiert vor Zug 173): Repeated failed attempts selling turtle lots: engine says 'nobody to sell to' or 'does not hold it' though Harlow is present and HUD lists the items; trying inventory inspection before another sale.
- zu Zug 173 (notiert vor Zug 174): Bag actually holds 5 plates and 5 claws, not the 2+2 assumed earlier; earlier refusals likely came from wrong quantities.
- zu Zug 175 (notiert vor Zug 176): Turtle loot is unreachable in the pouch despite #bag listing it; Harlow will buy at standing rates once items can be produced. Wolf pelt seems graspable.
- zu Zug 177 (notiert vor Zug 178): Pouch anomaly confirmed by a second party: contents feel reachable but slide away, deeper than the bag. Sales blocked until this is resolved.
- zu Zug 184 (notiert vor Zug 185): Engine recorded the previous turn as WORLD NOT RECORDED, though the scene continued; Tam confirmed the anchor is a thread tied to my hand, not the bag.
- zu Zug 186 (notiert vor Zug 187): Tam confirmed the unraveling succeeded: the bag is now just a bag; the whole thread is preserved in a waxed tube.
- zu Zug 189 (notiert vor Zug 190): Present list shows Vessa the enchanter went still when the numbing under-thread was named — possible lead later.
- zu Zug 190 (notiert vor Zug 191): Inquiry no. nine closed out properly; Vessa still at the hall is a lead for later. STA 38/100 — may need recovery before or after the cull.
- zu Zug 191 (notiert vor Zug 192): Arrival confirmed only after travel message; STA 38/100, HP not full — recovery may be needed after the cull.
- zu Zug 193 (notiert vor Zug 194): Range rules confirmed: Piercing Thrust needs ENGAGED; the turtle escaped to the north end.
- zu Zug 196 (notiert vor Zug 197): Quest still shows 0/4 defeated despite the kill — may only update on turn-in. STA 30/100, three turtles left.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t12 | 12 | 1 | – | ja | 1 | gewonnen, 60 XP |
| enc.t22 | 23 | 1 | – | nein | 1 | gewonnen, 90 XP |
| enc.t28 | 29 | 1 | – | nein | 1 | gewonnen, 90 XP |
| enc.t32 | 34 | 1 | – | nein | 1 | gewonnen, 90 XP |
| enc.t49 | 51 | 1 | – | nein | 1 | gewonnen, 90 XP |
| enc.t54 | 56 | 1 | – | nein | 1 | gewonnen, 90 XP |
| enc.t68 | 72 | 3 | – | nein | 3 | gewonnen, 270 XP |
| enc.t74 | 78 | 1 | – | nein | 1 | gewonnen, 115 XP |
| enc.t84 | 90 | 1 | – | nein | 1 | gewonnen, 90 XP |
| enc.t96 | 103 | 1 | – | nein | 1 | gewonnen, 90 XP |
| enc.t108 | 116 | 1 | – | nein | 1 | gewonnen, 90 XP |
| enc.t112 | 121 | 1 | – | nein | 1 | gewonnen, 90 XP |
| enc.t116 | 125 | 1 | – | nein | 1 | gewonnen, 90 XP |
| enc.t130 | 140 | 1 | – | nein | 1 | gewonnen, 90 XP |
| enc.t136 | 147 | 1 | – | nein | 1 | gewonnen, 115 XP |
| enc.t141 | 152 | 1 | – | nein | 1 | gewonnen, 90 XP |
| enc.t144 | 155 | 1 | – | nein | 1 | gewonnen, 90 XP |
| enc.t180 | 196 | 1 | – | nein | 1 | gewonnen, 90 XP |
| enc.t183 | 200 | 1 | – | nein | – | offen |

## Quests

- **Cull the Millpond Snapping Turtles** — active (Zug 16)
  - Aufgabe: Kill 4 snapping turtles at the millpond at Gristbeck, upstream of the millrace gates. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 snapping turtles killed at the millpond at Gristbeck, upstream of the millrace gates.
- **Cull the Orchard Prowler** — active (Zug 6) → completed (Zug 13), READY
  - Aufgabe: Kill 1 the lone gray wolf at the cider orchard rows south of Alderwatch. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the lone gray wolf killed at the cider orchard rows south of Alderwatch.

## Auffälligkeiten

- Zug 5, Nachricht 10 (extraction_repaired): the extractor's first answer needed a repair
- Zug 8, Nachricht 16 (extraction_repaired): the extractor's first answer needed a repair
- Zug 26, Nachricht 52 (extraction_repaired): the extractor's first answer needed a repair
- Zug 42, Nachricht 84 (extraction_repaired): the extractor's first answer needed a repair
- Zug 46, Nachricht 92 (extraction_repaired): the extractor's first answer needed a repair
- Zug 60, Nachricht 120 (extraction_repaired): the extractor's first answer needed a repair
- Zug 64, Nachricht 128 (extraction_repaired): the extractor's first answer needed a repair
- Zug 71, Nachricht 142 (extraction_repaired): the extractor's first answer needed a repair
- Zug 81, Nachricht 162 (extraction_repaired): the extractor's first answer needed a repair
- Zug 88, Nachricht 176 (extraction_repaired): the extractor's first answer needed a repair
- Zug 95, Nachricht 190 (extraction_repaired): the extractor's first answer needed a repair
- Zug 97, Nachricht 193 (planner_failed): the planner failed: sell seq 1: min_cp 138 is not what his words "Deal on the plates—23 at six copper" say: 6 cp total for qty 23. min_cp is the TOTAL for the selected quantity; if he means several units, set qty to that
- Zug 97, Nachricht 193 (planner_repaired): the planner's first answer needed a repair
- Zug 98, Nachricht 195 (planner_repaired): the planner's first answer needed a repair
- Zug 99, Nachricht 198 (extraction_repaired): the extractor's first answer needed a repair
- Zug 110, Nachricht 219 (planner_repaired): the planner's first answer needed a repair
- Zug 114, Nachricht 228 (extraction_repaired): the extractor's first answer needed a repair
- Zug 117, Nachricht 233 (planner_failed): the planner failed: commands[0] (move): target must be an id from OPPONENTS or PRESENT, or null
- Zug 117, Nachricht 233 (planner_repaired): the planner's first answer needed a repair
- Zug 119, Nachricht 238 (extraction_repaired): the extractor's first answer needed a repair
- Zug 130, Nachricht 260 (extraction_repaired): the extractor's first answer needed a repair
- Zug 165, Nachricht 329 (planner_repaired): the planner's first answer needed a repair
- Zug 166, Nachricht 331 (planner_repaired): the planner's first answer needed a repair
- Zug 168, Nachricht 335 (planner_failed): the planner failed: sell seq 2: min_cp 5 is not what his words "sell Harlow my remaining turtle plates and claws at his quot" say: 25 cp total for qty 5. min_cp is the TOTAL for the selected quantity; if he means several
- Zug 168, Nachricht 335 (planner_repaired): the planner's first answer needed a repair
- Zug 169, Nachricht 337 (planner_repaired): the planner's first answer needed a repair
- Zug 170, Nachricht 339 (planner_repaired): the planner's first answer needed a repair
- Zug 171, Nachricht 341 (planner_failed): the planner failed: sell seq 2: min_cp 2 is not what his words "two Giant Snapping Turtle Claws into one pile, then hand him" say: 12 cp total for qty 2. min_cp is the TOTAL for the selected quantity; if he means several
- Zug 171, Nachricht 341 (planner_repaired): the planner's first answer needed a repair
- Zug 172, Nachricht 343 (planner_repaired): the planner's first answer needed a repair
- Zug 174, Nachricht 347 (planner_repaired): the planner's first answer needed a repair
- Zug 184, Nachricht 368 (extraction_failed): the extractor failed: $.deltas[4] (quest.detail): .quest: matches none of anyOf
- Zug 184, Nachricht 368 (extraction_repaired): the extractor's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 70× keine gültige JSON-Entscheidung (Züge 2, 4, 6, 9, 10, 11, 20, 23, 27, 28, 33, 34, 36, 37, 38, 39, 52, 55, 58, 59, 60, 63, 64, 65, 66, 68, 69, 70, 71, 72, 74, 78, 84, 87, 93, 95, 96, 100, 106, 113, 116, 120, 127, 129, 132, 133, 137, 138, 145, 146, 147, 148, 151, 152, 154, 155, 158, 161, 164, 168, 175, 177, 178, 181, 183, 184, 186, 187, 189, 190)

System-Panels: CLARIFY 3, NOT TAKEN 8, REFUSED 3, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: guild_canon 3, guild_canon_price 1, ambient 9, engine_owned_fact 17, world_rule 9, group_unclear 1, attack_commitment 2, scene_context 9, no_go 4, quest_count 7, offer 9, entity_fact 1, coin_evidence 3, sale_evidence 2, object 1, gear_offer 3, engine_owned 1, recover 1, engine_recovery 1, engine_booked 2, pc_inventory 6.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 70/200 Erstantworten ungültig (35.0 %); 70 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 202 | 12 | 2.3 s | 4.5 s | 11982 | 9936 | 83 | – | stop 202 | 0 |
| board | 2 | 1 | 8.6 s | 9.6 s | 3012 | 2459 | 981 | – | stop 2 | 0 |
| narrator | 181 | 0 | 8.1 s | 11.7 s | 11187 | 8688 | 397 | – | stop 181 | 0 |
| extract | 197 | 16 | 5.0 s | 8.7 s | 12285 | 9660 | 329 | – | stop 197 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 79:55 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 9.7 s) | 0:23 min |
| 200 Züge, Spiel (Senden bis HUD nach der Extraktion) | 64:49 min — Median 18.2 s, p90 28.7 s, max 90.4 s |
| 200 Züge, Spieler-Entscheidung | 10:32 min — Median 2.7 s, 70 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 9:40 min / 0:17 min / 27:50 min / 18:24 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 22.6 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 15:04 min, 80 Züge ≈ 30:09 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spieler | 163 | – | 60.1 s | 2.7 s |
| Spiel | 85 | – | 90.4 s | 18.2 s |
| Provider narrator | 85 | 242 | 42.3 s | 8.1 s |
| Provider extract | 85 | 243 | 41.4 s | 5.0 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
