# Avereth – 3 natürliche Testkampagnen

Status: **completed**. Serie abgeschlossen bedeutet, dass die Läufe beendet sind; es bedeutet nicht 3 bestandene Level-15-Abnahmen.

| Nr. | Profil | Seed | Eingaben | Level | Ende | Originalbericht |
|---|---|---:|---:|---:|---|---|
| 1 | guild-warrior | 685958792 | 200 | 11 | limit | [report.md](001-guild-warrior/20261030-082423Z-current_test/report.md) |
| 2 | guild-mage | 685958793 | 22 | 3 | defeat | [report.md](002-guild-mage/20261030-094334Z-current_test/report.md) |
| 3 | guild-rogue | 685958794 | 200 | 6 | limit | [report.md](003-guild-rogue/20261030-095237Z-current_test/report.md) |

