# Avereth Live-Test 20261030-133348Z-current_test

## Kurzfassung

- **Laufprofil:** guild-warrior; Startklasse Warrior, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** abgebrochen: Limit erreicht — 200 turns
- **Etappen:** 1/3 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht) · class_accepted (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 12. Sicherheitsgrenzen: 200 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** Level 8, 375 XP seit Levelaufstieg, 175 cp, HP 218, MP 104; Ort loc.the_orchard_house_at_thornhollow. Ausrüstung und Skills stehen in evaluation.json → progression.checkpoint.
- **Charakter:** warrior (warrior.guard, warrior.cleave) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 through E class evolution“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: cautious adventurer: prepare and recover, weigh threats and withdraw when sensible
- **Züge:** 200 · **Dauer:** 88:55 min · **LLM-Aufrufe der Engine/des Erzählers:** 556
- **Beobachtete Abdeckung:** 38 unterschiedliche gebuchte Reiseziele · 15 Kämpfe · 5 Verkäufe (489 cp Umsatz, ohne Questzahlungen/Geschenke) · 2 Ausrüstungswechsel · 2 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 25
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.125 |
| Git | e779fee3eadd (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 55.8 s |
| Browser | chrome 156.0.8078.49 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261030-133348Z-current_test“, Seed 406300236 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |
| class_accepted | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | Warrior | Engine (Menü/Rückfrage) | creation_complete | Choose base class Warrior | public roadside verge outside Alderwatch | 90/84 | 2.1 s |
| 2 | I choose Cleave and Guard as my two skills. | Engine (Menü/Rückfrage) | creation_complete | Pick mandatory Cleave plus Guard | public roadside verge outside Alderwatch | 95/84 | 2.1 s |
| 3 | I walk through the city gate into Alderwatch and head for the Adventurers' Guild hall to look at the contract board. | Erzähler | open_run_level | Enter city, reach Guild, view contracts | Adventurers' Guild hall, Alderwatch | 95/84 | 74.0 s |
| 4 | I read the F-rank contracts on the board, then register with the clerk for two silver. | Erzähler | open_run_level | View contracts and register with the Guild | Adventurers' Guild hall, Alderwatch | 95/84 | 61.8 s |
| 5 | I put my name on the slip, press my thumb to the stone, and drop two silver into the dish. | Erzähler | open_run_level | Register with the Guild | Adventurers' Guild hall, Alderwatch | 95/84 | 24.1 s |
| 6 | I take the Millpond Marsh Harrier contract — number one on the Novice board. | Erzähler | open_run_level | Accept the achievable F-rank harrier hunt | Adventurers' Guild hall, Alderwatch | 95/84 | 27.5 s |
| 7 | I head west past the tanneries along the millrace to the millpond reed banks and look for the marsh harrier. | Erzähler | open_run_level | Travel to the harrier hunt site | the reed banks of the Alderwatch millpond | 95/84 | 30.1 s |
| 8 | I move slowly along the bank toward the sluice, watching the reeds for the harrier and keeping an eye on the heavy prints. | Erzähler | open_run_level | Search the reed banks for the marsh harrier | the sluice of the Alderwatch millpond | 95/84 | 30.3 s |
| 9 | I press close against the reed wall and stay still, letting the sluice noise mask me until the harrier glides low within reach, then swing m… | Erzähler | open_run_level | Ambush the harrier as it passes | the sluice of the Alderwatch millpond | 95/84 | 19.7 s |
| 10 | I step out onto the open bank and ready my longsword, waiting for the harrier's next low pass over the reed line to swing at it. | Erzähler | open_run_level | Fight the harrier openly after stealth failed | the sluice of the Alderwatch millpond | 95/84 | 28.2 s |
| 11 | I move to the moss-grown plank walk beside the sluice and crouch low beneath its edge, waiting for the harrier to make its next low run alon… | Erzähler | open_run_level | Ambush the harrier from the plank walk | the moss-grown plank walk beside the sluice | 95/84 | 40.5 s |
| 12 | I hold still beneath the plank walk's edge, sword ready, and swing at the harrier as it makes its low run along the reed line toward the slu… | Erzähler | open_run_level | Ambush the harrier from cover and strike | the moss-grown plank walk beside the sluice | 95/84 | 21.5 s |
| 13 | I move to the shallows where the harrier has been diving and wait with sword ready for it to drop at prey again. | Erzähler | open_run_level | Lure the harrier into sword range at its feeding spot | the western shallows of the Alderwatch millpond | 95/84 | 21.5 s |
| 14 | I catch one of the small fish in the shallows, lay it on the open gravel as bait, then hide in the sparse reeds nearby and wait for the harr… | Erzähler | open_run_level | Bait the harrier into striking range and ambush it | the western shallows of the Alderwatch millpond | 95/84 | 24.4 s |
| 15 | I wade to the edge of the gravel shelf and try to catch one of the small fish in the shallows with my hands. | Erzähler | open_run_level | Catch bait fish first, one action per turn | the western shallows of the Alderwatch millpond | 95/84 | 20.0 s |
| 16 | I lay the dace on the open gravel, then slip back into the sparse reeds and wait hidden for the harrier to dive at the bait. | Erzähler | open_run_level | Bait the harrier into striking range and ambush it | the western shallows of the Alderwatch millpond | 95/84 | 16.1 s |
| 17 | I wade out to the gravel shelf and lay the dace on the open gravel, then hold still. | Erzähler | open_run_level | Place the bait fish where the harrier can see it | the western shallows of the Alderwatch millpond | 95/84 | 21.3 s |
| 18 | I burst up from the reeds and swing my longsword at the harrier standing on the gravel. | Erzähler | open_run_level | Ambush the harrier at close range | the western shallows of the Alderwatch millpond | 95/84 | 14.0 s |
| 19 | I walk back to Alderwatch and hand in the harrier contract at the Guild hall. | Erzähler | open_run_level | Turn in the completed harrier hunt for the 40 copper reward | Adventurers' Guild hall, Alderwatch | 95/84 | 17.2 s |
| 20 | #assign STR 3 VIT 2 | System (Befehl) | open_run_level | Spend level-up stat points | Adventurers' Guild hall, Alderwatch | 95/84 | 2.1 s |
| 21 | I ask the clerk what contracts are on the board tonight. | Erzähler | open_run_level | Look for the next achievable contract | Adventurers' Guild hall, Alderwatch | 95/84 | 13.5 s |
| 22 | I'll take the Thornhollow boar contract — please register it as active for me. | Erzähler | open_run_level | Accept the achievable boar hunt from the Guild board | Adventurers' Guild hall, Alderwatch | 95/84 | 15.0 s |
| 23 | Before heading out at this hour I check a smithy in Alderwatch for a better longsword or armor I can afford, keeping at least 20 copper. | Erzähler | open_run_level | Gear check before the boar hunt | smithy off the market square | 95/84 | 25.3 s |
| 24 | Nothing here I can afford without dropping below 20 copper, so I thank the smith and set out along the millpond road toward the Thornhollow … | Erzähler | open_run_level | Skip unaffordable gear, head to the boar hunt | the orchard terraces and brush slopes of Thornhollow | 95/84 | 19.6 s |
| 25 | I greet the farmer and ask whether the boar are still coming through the brush slope, and where he'd look for them at this hour. | Erzähler | open_run_level | Gather local boar information before hunting | the orchard terraces and brush slopes of Thornhollow | 95/84 | 16.1 s |
| 26 | I tell him yes, I'm hunting them tonight, and take the keeper's track at the second wall, moving slowly with the wind in my face toward the … | Erzähler | open_run_level | Hunt the boar sounder at dusk | the brush slope by the keeper's track at the second wall | 95/84 | 23.1 s |
| 27 | I creep across the open torn ground toward the nearest rooting boar and strike it with my longsword, aiming to bring it down before the soun… | Engine (Menü/Rückfrage) | open_run_level | Attack the boar sounder | the brush slope by the keeper's track at the second wall | 95/84 | 4.5 s |
| 28 | I creep down into the fold and scan the bramble for the nearest boar, trying to spot one clearly so I can attack it. | Erzähler | open_run_level | Get a valid target for the boar hunt | the brush slope by the keeper's track at the second wall | 95/84 | 18.5 s |
| 29 | I move slowly along the bramble edge after the rooting sound, keeping downwind, and search again for a boar I can target clearly. | Erzähler | open_run_level | Retry spotting a boar for a valid attack target | the bramble hummock in the fold | 95/84 | 18.4 s |
| 30 | I lunge from the hummock's edge and strike Wild Boar A with my longsword before it can turn. | Engine (Menü/Rückfrage) | open_run_level | Attack the now-targetable boar | the bramble hummock in the fold | 95/84 | 4.7 s |
| 31 | Basic Attack | Erzähler | open_run_level | Answer the System's skill clarification by attacking Wild Boar A with Basic Attack | the bramble hummock in the fold | 95/84 | 13.0 s |
| 32 | I charge the last ten paces across the torn earth and strike Wild Boar A with my longsword, closing to ENGAGED range. | Erzähler | open_run_level | Close to ENGAGED and attack the boar | the bramble hummock in the fold | 95/84 | 20.9 s |
| 33 | I use Cleave, catching Wild Boar A and any other boar that charges in from the bramble. | Erzähler | open_run_level | Use AoE as the sounder closes in | the bramble hummock in the fold | 76/84 | 13.9 s |
| 34 | I finish it with another Basic Attack on Wild Boar A while it readies its second charge. | Erzähler | open_run_level | Kill the wounded boar before it gores again | the bramble hummock in the fold | 59/84 | 14.4 s |
| 35 | I strike Wild Boar A again with my Basic Attack to finish it. | Erzähler | open_run_level | Kill the wounded boar | the bramble hummock in the fold | 59/84 | 17.5 s |
| 36 | #assign STR 3 VIT 4 WIL 3 | System (Befehl) | open_run_level | Spend the 10 free stat points from the two level-ups | the bramble hummock in the fold | 59/84 | 2.1 s |
| 37 | I head back toward Thornhollow village; once there, I look for lodging for the night. | Erzähler | open_run_level | Return to settlement, rest and recover | Thornhollow | 59/84 | 22.6 s |
| 38 | I enter the boarding house and ask for a bed for the night. | Erzähler | open_run_level | Lodging and rest to recover HP | a boarding house | 59/84 | 17.8 s |
| 39 | I step inside and greet the old woman. "I need a bed for the night — and hot water for this leg, if you have it." | Erzähler | open_run_level | Arrive at the boarding house and get lodging | a boarding house | 59/84 | 45.5 s |
| 40 | I accept the old woman's offer and pay her 3 copper for the bed, hot water, and bandages. | Erzähler | open_run_level | Buy lodging and bandages | a boarding house | 59/84 | 23.1 s |
| 41 | I lie down and sleep until morning. | Erzähler | open_run_level | Recover HP overnight | a boarding house | 155/96 | 15.8 s |
| 42 | I head to the village blacksmith's forge to compare weapon and armour upgrades. | Erzähler | open_run_level | Gear check at the smith before hunting | the village forge | 155/96 | 19.2 s |
| 43 | "I'd like to see what you have in blades and armor that would suit a warrior like me — and what each piece costs. | Erzähler | open_run_level | Ask the smith for weapon and armor options with prices | the village forge | 155/96 | 22.2 s |
| 44 | I thank the smith and step back out — nothing here I can afford yet, so I'll keep the coin and head to the Guild hall to turn in what I have… | Erzähler | open_run_level | Gear check done; pursue contract progress | Adventurers' Guild hall, Alderwatch | 155/96 | 19.6 s |
| 45 | I hand the clerk my contract slip and report: I've thinned the Thornhollow boar sounder so far, one down and three to go — I'd like to turn … | Erzähler | open_run_level | Turn in progress and check for purchasable loot and new work | Adventurers' Guild hall, Alderwatch | 155/96 | 27.6 s |
| 46 | I accept the clerk's offer and sell the four harrier feathers and two talons for 5 copper, then head back out the east road toward Thornholl… | Erzähler | open_run_level | Sell loot and continue boar contract | the orchard terraces and brush slopes of Thornhollow | 155/96 | 19.9 s |
| 47 | I climb carefully toward the third wall where the windfall apples are, watching the tall brush for boars. | Erzähler | open_run_level | Hunt the remaining boars at the windfall apples | the third wall and windfall apples | 155/96 | 17.0 s |
| 48 | I draw my sword and quietly circle toward the edge of the bramble, trying to spot one boar in the brush before it spots me. | Erzähler | open_run_level | Locate and stalk a boar for the contract | the third wall and windfall apples | 155/96 | 21.1 s |
| 49 | I attack the rooting sow from behind with Cleave, angling the swing away from the bedded boar in the shade. | Erzähler | open_run_level | Ambush the unaware sow with Cleave, avoiding friendly-fire risk on the second boar | the third wall and windfall apples | 155/96 | 13.7 s |
| 50 | I close the distance quietly and step up to the sow's flank, then swing Cleave into her side. | Erzähler | open_run_level | Engage and attack the sow with Cleave at melee range | the third wall and windfall apples | 155/96 | 18.9 s |
| 51 | I swing Cleave into the charging sow again, keeping the bedded boar out of the arc. | Erzähler | open_run_level | Finish the sow with Cleave | the third wall and windfall apples | 155/96 | 17.0 s |
| 52 | #assign STR 2 VIT 3 | System (Befehl) | open_run_level | Spend level-up points on STR and VIT | the third wall and windfall apples | 155/96 | 2.1 s |
| 53 | I keep my sword up and slowly back away from the wary boar, retreating toward the wall without turning my back on it. | Erzähler | open_run_level | Disengage from the wary boar and withdraw | the third wall and windfall apples | 155/96 | 14.7 s |
| 54 | I keep backing away until the boar no longer reacts, then leave the orchard wall and head for town to sell the hides and tusks. | Erzähler | open_run_level | Disengage fully and return to town to sell loot and check gear | Thornhollow | 155/96 | 25.5 s |
| 55 | I accept — thirty-four copper for both hides and both tusks. | Erzähler | open_run_level | Sell the boar loot at the confirmed price | Thornhollow | 155/96 | 13.6 s |
| 56 | I leave the merchant and head for the smithy, the one where the hammer is sounding, to look at weapons and armor. | Erzähler | open_run_level | Visit blacksmith for gear check per gear priority | the village forge | 155/96 | 18.6 s |
| 57 | I'll take the finer longsword of your own folding at eighty copper, and equip it in place of my starter blade. | Erzähler | open_run_level | Buy and equip the finer longsword upgrade | the village forge | 155/96 | 21.0 s |
| 58 | I thank the smith and head back toward the terraces to finish the boar contract — I still need two more, starting with the wary boar by the … | Erzähler | open_run_level | Resume the boar hunt for the remaining two kills | the orchard terraces and brush slopes of Thornhollow | 155/96 | 21.2 s |
| 59 | I climb to the top of the wall and approach the west corner along the wall itself, coming from above so the uphill wind keeps my scent from … | Erzähler | open_run_level | Stalk the wary boar from downwind along the wall top | the west corner of the wall | 155/96 | 18.0 s |
| 60 | I drop down from the wall onto the boar's flank and strike at its shoulder with my longsword. | Erzähler | open_run_level | Ambush the wary boar from above with a first strike | the west corner of the wall | 135/96 | 14.4 s |
| 61 | I attack again, driving my longsword into the wounded shoulder as the boar coils to charge. | Engine (Menü/Rückfrage) | open_run_level | Finish the wounded boar with basic attacks | the west corner of the wall | 135/96 | 5.1 s |
| 62 | Basic Attack — I drive the longsword into the wounded shoulder again. | Erzähler | open_run_level | Answer clarify and finish the boar | the west corner of the wall | 116/96 | 14.4 s |
| 63 | Basic Attack — I finish it as it gathers for the last rush, driving the longsword through the wounded shoulder once more. | Erzähler | open_run_level | Finish the boar with a basic attack | the west corner of the wall | 116/96 | 15.3 s |
| 64 | I assign my five free stat points: three into VIT and two into WIL. | Erzähler | open_run_level | Spend level-up points | the west corner of the wall | 116/96 | 11.8 s |
| 65 | #assign VIT 3 WIL 2 | System (Befehl) | open_run_level | Spend the five free stat points via the assign command | the west corner of the wall | 116/96 | 2.4 s |
| 66 | I search the brush slope above the second wall for the fourth, wary boar, moving slowly and keeping my longsword ready. | Erzähler | open_run_level | Find and finish the last contract boar | the brush slope by the keeper's track at the second wall | 116/96 | 25.6 s |
| 67 | I follow the boar trail uphill toward the dense broom stand, moving slowly and listening for the hidden boar before it notices me. | Erzähler | open_run_level | Find and finish the fourth contract boar | the dense broom stand hollow | 116/96 | 20.9 s |
| 68 | I rush into the tangle and drive my longsword into the bedded boar with a Basic Attack before it can rise. | Engine (Menü/Rückfrage) | open_run_level | Attack the fourth boar while it is unaware | the dense broom stand hollow | 116/96 | 4.9 s |
| 69 | I move quietly to the tangle's edge and peer into the broom, trying to spot the boar before it notices me. | Erzähler | open_run_level | Get a valid target on the fourth boar | the dense broom stand hollow | 116/96 | 27.9 s |
| 70 | I strike at the rousing sow with Cleave before she can charge. | Erzähler | open_run_level | Attack the fourth boar with Cleave | the dense broom stand hollow | 116/96 | 17.0 s |
| 71 | I charge the last few paces and strike the sow with Cleave before she can charge me. | Erzähler | open_run_level | Engage and attack the fourth boar at melee range | the dense broom stand hollow | 116/96 | 15.7 s |
| 72 | I brace myself and strike the sow with a Basic Attack the moment she reaches me. | Erzähler | open_run_level | Meet the charging boar at melee and attack when engaged | the dense broom stand hollow | 116/96 | 15.1 s |
| 73 | I swing my longsword at the sow now that she is engaged. | Erzähler | open_run_level | Basic Attack on engaged sow | the dense broom stand hollow | 82/96 | 17.5 s |
| 74 | I strike the sow with Cleave while we are engaged at close quarters. | Erzähler | open_run_level | Attack the wounded boar with Cleave now that it is ENGAGED | the dense broom stand hollow | 68/96 | 18.3 s |
| 75 | I finish her with Cleave before she can recover. | Erzähler | open_run_level | Kill the fourth boar | the dense broom stand hollow | 68/96 | 17.2 s |
| 76 | I accept the Iron Guard Riposte skill. | Erzähler | open_run_level | Accept the offered skill | the dense broom stand hollow | 68/96 | 16.5 s |
| 77 | I head downhill to Thornhollow to rest and recover, then turn in the boar contract at the Guild hall. | Erzähler | open_run_level | Travel to Thornhollow, recover, then turn in the completed 4/4 boar contract | Thornhollow | 68/96 | 29.7 s |
| 78 | I arrive at Thornhollow and go to Bram's wife to have my wounds stitched and treated. | Erzähler | open_run_level | Get wounds treated on arrival | Bram and Hessa's house | 68/96 | 23.9 s |
| 79 | I pay Hessa the three coppers, then head to the Guild hall and turn in the completed boar contract. | Erzähler | open_run_level | Pay for treatment and turn in the 4/4 boar contract | Adventurers' Guild hall, Alderwatch | 68/96 | 20.0 s |
| 80 | #assign STR 2 VIT 3 | System (Befehl) | open_run_level | Spend level-up stat points | Adventurers' Guild hall, Alderwatch | 68/96 | 2.5 s |
| 81 | I take a room at the inn and sleep until morning. | Erzähler | open_run_level | Recover overnight before gear shopping and next contract | the Waymeet inn | 68/96 | 24.4 s |
| 82 | I take the room for six coppers and the bath for two, then sleep until morning. | Engine (Menü/Rückfrage) | open_run_level | Buy lodging and bath, then recover overnight | the Waymeet inn | 68/96 | 9.8 s |
| 83 | I buy the room with breakfast for six coppers and the bath for two coppers from the innkeeper, then sleep until morning. | Erzähler | open_run_level | Purchase lodging and bath, then recover overnight | the Waymeet inn | 230/104 | 16.0 s |
| 84 | I ask the innkeeper where I can sell boar hides and tusks nearby, then go to that merchant and offer my two hides and two tusks for sale. | Erzähler | open_run_level | Sell surplus loot and locate a merchant | Dorn Fell's tanner yard | 230/104 | 30.7 s |
| 85 | I accept: twenty coppers for both hides and both tusks, and hand the goods over. | Erzähler | open_run_level | Sell surplus loot to Dorn Fell | Dorn Fell's tanner yard | 230/104 | 13.9 s |
| 86 | I head to the Guild hall in Alderwatch and look over the contract board for a suitable job. | Erzähler | open_run_level | Find next contract at Guild hall | Adventurers' Guild hall, Alderwatch | 230/104 | 22.0 s |
| 87 | I tell the clerk: "I'll take the Thornhollow boar cull — three wild boar," and accept the contract. | Erzähler | open_run_level | Accept the boar cull contract | Adventurers' Guild hall, Alderwatch | 230/104 | 16.6 s |
| 88 | I leave by the south gate and travel to Thornhollow, then ask for Hedwin at the orchard house to see where the boar cross. | Erzähler | open_run_level | Travel to Thornhollow and start the boar cull | the orchard house at Thornhollow | 230/104 | 27.2 s |
| 89 | I ask Hedwin to point me up the trail past the second terrace where the rooting was seen, then follow it into the brush to stalk the bedded … | Erzähler | open_run_level | Hunt boar in daylight from Hedwin's directions | the dry bed hollow under the leaning hazel | 230/104 | 24.6 s |
| 90 | I stalk the bedded boar in the broom stand, closing quietly to ten paces, then strike with Cleave aimed at it. | Engine (Menü/Rückfrage) | open_run_level | Ambush the unaware bedded boar with Cleave | the dry bed hollow under the leaning hazel | 230/104 | 7.5 s |
| 91 | I close on the breathing in the broom stand and strike the bedded boar there with Cleave. | Engine (Menü/Rückfrage) | open_run_level | Ambush the bedded boar with Cleave | the dry bed hollow under the leaning hazel | 230/104 | 4.7 s |
| 92 | I stalk the bedded boar in the broom stand downhill of the bed hollow, closing quietly to ten paces, then attack it with Basic Attack. | Engine (Menü/Rückfrage) | open_run_level | Engage the bedded boar in the active scene | the dry bed hollow under the leaning hazel | 230/104 | 5.1 s |
| 93 | I push into the broom stand toward the breathing and flush the bedded boar out of cover. | Erzähler | open_run_level | Force the hidden boar to become a targetable actor | the damp dell with the boar wallow | 230/104 | 22.2 s |
| 94 | I strike the big sow with Cleave as she stands broadside, aiming the arc to catch the smaller rooter beside her. | Erzähler | open_run_level | Engage the sounder with Cleave on clustered boars | the damp dell with the boar wallow | 230/104 | 42.8 s |
| 95 | I charge the big sow and strike her with Cleave once I'm in reach. | Erzähler | open_run_level | Close to melee and engage the sow | the damp dell with the boar wallow | 218/104 | 18.6 s |
| 96 | I finish her with another Cleave. | Erzähler | open_run_level | Engaged melee on the wounded sow | the damp dell with the boar wallow | 218/104 | 15.9 s |
| 97 | #assign AGI 3 PER 2 | System (Befehl) | open_run_level | Spend level-up points | the damp dell with the boar wallow | 218/104 | 2.6 s |
| 98 | I follow the trail uphill toward where the boar crashed off through the ferns, moving quietly and watching for it. | Erzähler | open_run_level | Hunt the third boar for the cull contract | the churned patch under the leaning pear tree | 218/104 | 25.2 s |
| 99 | I follow the flattened swath through the long grass toward the broken west corner wall, moving slowly and scanning the scrub ahead. | Erzähler | open_run_level | Track the two young boar toward the wall for the cull contract | the churned patch under the leaning pear tree | 218/104 | 19.6 s |
| 100 | I leave the trail and head down toward the orchard house to get my leg wound stitched, then plan to return to the broken wall at dusk. | Erzähler | open_run_level | Recover from wound, return at dusk for remaining boar | the orchard house at Thornhollow | 218/104 | 24.2 s |
| 101 | I thank Lessa and tell the apple man I'll rest here a few days until the stitches settle, then deal with the remaining boar. I ask whether t… | Erzähler | open_run_level | Recover from wound before resuming the cull contract | the orchard house at Thornhollow | 218/104 | 20.6 s |
| 102 | I accept the hearth room at one and a half silver with apple sorting, and hand over the coin. | Engine (Menü/Rückfrage) | open_run_level | Take discounted lodging for recovery days | the orchard house at Thornhollow | 218/104 | 9.4 s |
| 103 | I accept the hearth room at 15 cp with apple sorting, and hand over the coin. | Engine (Menü/Rückfrage) | open_run_level | Book the discounted lodging | the orchard house at Thornhollow | 218/104 | 10.0 s |
| 104 | I buy the hearth room, bed and supper, from Hedwin at the orchard house for 20 copper, and hand over the coin. | Erzähler | open_run_level | Book lodging at the listed price | the orchard house at Thornhollow | 218/104 | 17.4 s |
| 105 | I settle into the hearth room, stow my gear on the hook, and rest until supper at dusk. | Erzähler | open_run_level | Rest and recover at the booked lodging | the orchard house at Thornhollow | 240/104 | 24.1 s |
| 106 | I take the corner seat by the fire, thank Bram, and ask whether he knows the paths along the broken west wall where the two boar cut back — … | Erzähler | open_run_level | Recover done; gather local info before finishing the boar cull | the orchard house at Thornhollow | 240/104 | 25.9 s |
| 107 | I finish supper, take a cup of cider, and head up to sit inside the broken west corner wall at last light, waiting quietly for the two remai… | Erzähler | open_run_level | Ambush the two remaining boar at the west wall gap | the west corner of the wall | 240/104 | 22.6 s |
| 108 | I strike the yearling with Cleave while it roots heedlessly at the windfall. | Erzähler | open_run_level | Kill the yearling boar | the west corner of the wall | 240/104 | 14.1 s |
| 109 | I stay still behind the wall and let the yearling keep feeding until it roots within reach of my blade. | Erzähler | open_run_level | Ambush patiently until the yearling is in reach | the west corner of the wall | 240/104 | 22.4 s |
| 110 | I strike the yearling with Cleave while it roots against the stones within reach. | Erzähler | open_run_level | Kill the yearling boar | the west corner of the wall | 240/104 | 19.6 s |
| 111 | I keep the wall at my back, raise my longsword, and wait for the sow to charge rather than closing the distance myself. | Erzähler | open_run_level | Fight the remaining sow defensively from behind the wall | the west corner of the wall | 240/104 | 17.7 s |
| 112 | I meet the sow's charge with Cleave as she closes the last stride, stepping aside so her momentum carries her past. | Erzähler | open_run_level | Kill the sow defensively | the west corner of the wall | 240/104 | 17.8 s |
| 113 | I swing Cleave at the sow now that she is within reach, cutting across her charge. | Erzähler | open_run_level | Kill the engaged sow with Cleave | the west corner of the wall | 239/104 | 15.2 s |
| 114 | I finish the wounded sow with a basic attack before she can charge again. | Erzähler | open_run_level | Kill the engaged sow | the west corner of the wall | 239/104 | 21.0 s |
| 115 | I follow the heavier footfall trail toward the river flats while there is still light, sword ready. | Erzähler | open_run_level | Hunt the third boar for the cull contract | the river flats below Thornhollow | 239/104 | 34.3 s |
| 116 | I creep toward the reed beds along the near channel, keeping low and quiet, and pause at the edge to pick out a single isolated boar before … | Erzähler | open_run_level | Hunt the second of three boar for the cull contract | the reed beds along the near channel | 239/104 | 24.4 s |
| 117 | I rush the lone yearling from the willow cover and strike it down with a basic attack before the sows can react. | Erzähler | open_run_level | Kill the isolated yearling quickly for the cull count | the reed beds along the near channel | 239/104 | 42.4 s |
| 118 | I shout and wave to goad the yearling into charging across the open mud toward me, sword ready to meet it. | Erzähler | open_run_level | Draw the yearling into ENGAGED range | the reed beds along the near channel | 239/104 | 18.5 s |
| 119 | I meet the yearling's charge with a basic attack, striking it down as it reaches me. | Erzähler | open_run_level | Kill the yearling at ENGAGED range | the reed beds along the near channel | 239/104 | 16.5 s |
| 120 | I withdraw from the reed line in the dark, leaving the two sows alone, and head back toward the village. | Erzähler | open_run_level | Withdraw at nightfall and check the cull count | Thornhollow | 239/104 | 17.1 s |
| 121 | #quest Cull the Thornhollow Boar Sounder | System (Befehl) | open_run_level | Recheck the cull count before turning in | Thornhollow | 239/104 | 2.6 s |
| 122 | I take a room at the Waymeet inn and sleep until morning. | Erzähler | open_run_level | Rest overnight before hunting the last counted boar | the Waymeet hearth room | 239/104 | 28.5 s |
| 123 | I take the room upstairs for twelve copper. | Engine (Menü/Rückfrage) | open_run_level | Buy lodging, then sleep until morning | the Waymeet hearth room | 239/104 | 7.7 s |
| 124 | I buy the room upstairs from the innkeeper for twelve copper, then go up and sleep until morning. | Erzähler | open_run_level | Buy lodging and rest until morning | the Waymeet room upstairs | 239/104 | 16.9 s |
| 125 | I go up to the room, get into bed, and sleep until morning. | Erzähler | open_run_level | Sleep until morning to recover | the Waymeet room upstairs | 240/104 | 19.2 s |
| 126 | I head downstairs and out of the inn, then walk to the Guild hall to check the boar cull contract details. | Erzähler | open_run_level | Recheck cull count and plan the remaining boar hunt | the Guild hall, Thornhollow | 240/104 | 21.7 s |
| 127 | I ask the clerk about the boar cull contract — the count still shows one of three, and I want to confirm where the remaining boar are counte… | Erzähler | open_run_level | Clarify boar cull count with the clerk | the Guild hall, Thornhollow | 240/104 | 15.2 s |
| 128 | I thank the clerk and head for the orchard terraces south of the village, walking the terrace edge and looking for fresh rooting near the up… | Erzähler | open_run_level | Hunt the remaining boar on the terraces | the orchard terraces and brush slopes of Thornhollow | 240/104 | 15.9 s |
| 129 | I walk slowly along the terrace edge toward the upper walls, scanning the grass for fresh rooting and turned earth. | Erzähler | open_run_level | Hunt the remaining boar for the cull contract | the upper walls of Thornhollow | 240/104 | 24.4 s |
| 130 | I move quietly along the wall-top toward the broom hollow and attack the bedded boar with my longsword before it can rouse. | Engine (Menü/Rückfrage) | open_run_level | Ambush the bedded boar for the cull contract | the upper walls of Thornhollow | 240/104 | 10.5 s |
| 131 | I creep the last ten paces toward the broom hollow and try to strike the boar inside the bramble with my longsword before it rouses. | Erzähler | open_run_level | Close to the bedded boar and ambush it | the upper walls of Thornhollow | 240/104 | 26.3 s |
| 132 | I climb back over the upper wall by the leaning pear tree and settle in to wait there until evening, longsword ready, watching the rooting b… | Erzähler | open_run_level | Wait at the pear tree wall for the returning boar | the churned patch under the leaning pear tree | 240/104 | 20.0 s |
| 133 | I return to the broom hollow and creep toward the fresh wallow where heavy breathing comes from the bramble, striking the bedded boar with m… | Erzähler | open_run_level | Ambush the bedded boar at the fresh wallow for the cull contract | the churned patch under the leaning pear tree | 240/104 | 18.4 s |
| 134 | I walk back to the broom hollow and carefully part the bramble to look inside at the wallow and whatever lies in it. | Erzähler | open_run_level | Verify the bedded boar sign before striking | the dense broom stand hollow | 240/104 | 25.7 s |
| 135 | I follow the pressed lane down-slope toward the orchard terraces, longsword ready, watching for the boar that made this track. | Erzähler | open_run_level | Track the fresh boar sign toward the orchard | the rubble ramp breach in the old wall | 240/104 | 25.3 s |
| 136 | I use the apple rows for cover and move quietly down toward the crunching on the third terrace, closing to strike the boar with my longsword… | Erzähler | open_run_level | Ambush the feeding boar for the cull contract | the third wall and windfall apples | 240/104 | 22.2 s |
| 137 | I burst from the row's cover and strike the sow's flank with my longsword, aiming for her hind leg to hamper her charge. | Engine (Menü/Rückfrage) | open_run_level | Ambush the sow for the cull contract | the third wall and windfall apples | 240/104 | 5.3 s |
| 138 | I burst from the row's cover and strike the sow's flank with a Basic Attack, aiming for her hind leg to hamper her charge. | Erzähler | open_run_level | Ambush the sow using Basic Attack | the third wall and windfall apples | 240/104 | 15.7 s |
| 139 | I charge the remaining ten feet and strike the sow's flank with a Basic Attack, aiming for her hind leg to hamper her charge. | Erzähler | open_run_level | Close to ENGAGED and attack the sow | the third wall and windfall apples | 240/104 | 18.4 s |
| 140 | I advance the ten feet to ENGAGED range and strike the sow's flank with a Basic Attack, aiming for her hind leg. | Erzähler | open_run_level | Close to ENGAGED and attack the sow | the third wall and windfall apples | 239/104 | 18.8 s |
| 141 | I finish her with a Basic Attack to the neck. | Erzähler | open_run_level | Kill the wounded sow | the third wall and windfall apples | 239/104 | 20.1 s |
| 142 | I move quietly down toward the crunching on the third terrace, use the apple rows for cover, and close to ENGAGED to strike that boar with a… | Engine (Menü/Rückfrage) | open_run_level | Hunt the second boar for the cull contract | the third wall and windfall apples | 239/104 | 9.0 s |
| 143 | I move quietly down to the third terrace toward the crunching among the apple rows. If I find that boar there, I close to ENGAGED and strike… | Erzähler | open_run_level | Reach the third terrace and attack the unseen boar | the windfall apple rows on the third terrace | 239/104 | 40.2 s |
| 144 | I strike the boar again with a Basic Attack as it comes at my knee. | Erzähler | open_run_level | Attack Wild Boar L | the windfall apple rows on the third terrace | 231/104 | 20.0 s |
| 145 | I finish it with a Basic Attack as it braces for another rush. | Erzähler | open_run_level | Kill Wild Boar L | the windfall apple rows on the third terrace | 231/104 | 22.2 s |
| 146 | #assign VIT 3 AGI 2 | System (Befehl) | open_run_level | Spend level-up points, then hunt the third boar | the windfall apple rows on the third terrace | 231/104 | 2.7 s |
| 147 | I climb toward the top of the orchard where the big grunt came from, staying among the rows for cover. | Erzähler | open_run_level | Hunt the third boar | the windfall apple rows on the third terrace | 231/104 | 34.9 s |
| 148 | I brace behind the thickest trunk and strike the big boar with Cleave as it charges. | Engine (Menü/Rückfrage) | open_run_level | Engage the third boar with Cleave | the windfall apple rows on the third terrace | 231/104 | 6.2 s |
| 149 | I step out of cover and move toward the huge boar, calling out and banging my sword on a trunk to draw it into a charge. | Erzähler | open_run_level | Provoke the master boar into an active engagement so it becomes a targetable actor | the windfall apple rows on the third terrace | 231/104 | 28.6 s |
| 150 | I brace low and swing Cleave into the charging boar's shoulder as it closes. | Erzähler | open_run_level | Fight the targetable master boar | the windfall apple rows on the third terrace | 231/104 | 21.6 s |
| 151 | I plant my feet in its path and raise my Guard, holding my ground until the boar is fully engaged with me. | Erzähler | open_run_level | Get properly engaged before attacking | the windfall apple rows on the third terrace | 231/104 | 22.3 s |
| 152 | I swing Cleave into the boar's shoulder as it crashes into my guard. | Erzähler | open_run_level | Attack the engaged master boar with Cleave | the windfall apple rows on the third terrace | 218/104 | 22.1 s |
| 153 | I swing Cleave into the wounded boar as it gathers for its rush. | Erzähler | open_run_level | Finish the master boar with Cleave | the windfall apple rows on the third terrace | 205/104 | 15.6 s |
| 154 | I finish it with a basic attack to the throat as it sways. | Erzähler | open_run_level | Kill the master boar at minimal stamina cost | the windfall apple rows on the third terrace | 205/104 | 17.2 s |
| 155 | I field-dress what's usable from the big boar and head back down toward Thornhollow to turn in the contract at the Guild hall. | Erzähler | open_run_level | Return to Guild with 3/3 boars for turn-in | the Guild hall, Thornhollow | 205/104 | 33.3 s |
| 156 | #assign STR 3 VIT 2 | System (Befehl) | open_run_level | Spend the 5 free stat points | the Guild hall, Thornhollow | 205/104 | 2.8 s |
| 157 | I ask the clerk where I can get this hip wound stitched before the evening's out. | Erzähler | open_run_level | Get the hip wound treated | the Guild hall, Thornhollow | 205/104 | 30.5 s |
| 158 | I sit by the fire and lower my trousers off the hip so Maren can wash and stitch the wound. | Erzähler | open_run_level | Get the hip wound stitched by Maren Foss | the Guild hall, Thornhollow | 205/104 | 46.9 s |
| 159 | I pay Maren the two copper, thank her, and ask about the boar rumor Bram's been hearing — the fourth attack this season. | Erzähler | open_run_level | Pay for stitching and hear the rumor | the Guild hall, Thornhollow | 205/104 | 61.7 s |
| 160 | I head to Thornhollow's blacksmith to sell the surplus boar hides and tusks, and ask what he has in the way of a sturdier sword and armor. | Erzähler | open_run_level | Sell loot and shop for gear upgrades | the village forge | 205/104 | 50.8 s |
| 161 | I accept the twenty-three silver for all the hides and tusks, and if that sale goes through, I'll buy the Superior Longsword for eighteen si… | Engine (Menü/Rückfrage) | open_run_level | Sell loot and buy weapon upgrade | the village forge | 205/104 | 21.1 s |
| 162 | Yes, buy the Superior Longsword for 260 cp — and first accept the twenty-three silver for all the hides and tusks. | Erzähler | open_run_level | Confirm sale at 23 silver and buy Superior Longsword at corrected 26 silver | the village forge | 205/104 | 45.7 s |
| 163 | I strap on the Superior Longsword in place of the old one and hand the smith my worn starter blade to take off my hands. | Erzähler | open_run_level | Equip the new sword | the village forge | 205/104 | 87.9 s |
| 164 | I thank the smith and head to the inn for a room, then sleep until morning. | Erzähler | open_run_level | Recover overnight at the inn | the Sow and Stickle | 205/104 | 64.8 s |
| 165 | I take the private room for eight copper and pay the landlady, then head up and sleep until morning. | Erzähler | open_run_level | Buy lodging and sleep until morning | the Sow and Stickle | 285/104 | 77.1 s |
| 166 | I grab breakfast and head to the smith before midday to look over the promised armor set. | Erzähler | open_run_level | Buy armor upgrade at the smith | the Sow and Stickle | 285/104 | 41.9 s |
| 167 | I'll take the porridge and bread with dripping for four copper, then head to the smith to look over the armor set he promised. | Erzähler | open_run_level | Buy breakfast, then shop for armor | the village forge | 285/104 | 60.5 s |
| 168 | Sixty silver is beyond my purse right now — I'll pass on the set for today. On my way out, I ask the smith if he'll buy the spare boar hides… | Erzähler | open_run_level | Decline the unaffordable armor set and sell surplus loot | the village forge | 285/104 | 17.2 s |
| 169 | #bag | System (Befehl) | open_run_level | Verify whether the duplicate boar hides and tusks are real or ghost entries | the village forge | 285/104 | 2.9 s |
| 170 | The bag shows two full sets of boar parts — these must be from the second pair of boars. I explain that to the smith and offer to sell him t… | Erzähler | open_run_level | Resolve the duplicate-entry contradiction and sell the second set of boar parts | the village forge | 285/104 | 55.0 s |
| 171 | I accept the offer: one gold ten silver for both hides and all four tusks, and I hand the lot over. | Engine (Menü/Rückfrage) | open_run_level | Sell the second set of boar parts at the smith's offered price | the village forge | 285/104 | 10.4 s |
| 172 | I accept the smith's bid: sell both hides and all four tusks for 200 copper (offer.t340.27). | Erzähler | open_run_level | Accept the standing 200 cp bid for the boar lot | the village forge | 285/104 | 16.2 s |
| 173 | Since the 60-silver set is still beyond my purse and my superior sword already matches my ATK, I ask the smith whether he has any cheaper ar… | Erzähler | open_run_level | Look for an affordable armor upgrade at the forge | the village forge | 285/104 | 25.7 s |
| 174 | I'll take that boiled-leather jerkin for 30 copper, please. | Erzähler | open_run_level | Buy the affordable jerkin, then try the clothier for armor | the village forge | 285/104 | 14.5 s |
| 175 | I head to the market square and look for the clothier, to ask about a padded robe or other affordable armor. | Erzähler | open_run_level | Find affordable armor at the clothier | the clothier's shop | 285/104 | 20.1 s |
| 176 | I thank the clothier but leave the robe — it wouldn't improve my armor — and head to the Guild hall to look at the contract board. | Erzähler | open_run_level | Skip downgrade armor, seek next Guild contract | the Guild hall, Thornhollow | 285/104 | 24.7 s |
| 177 | I take the Boar Trouble contract from the board and ask the clerk to accept it for me. | Erzähler | open_run_level | Accept the 3-boar Guild contract and verify it is ACTIVE | the Guild hall, Thornhollow | 285/104 | 15.0 s |
| 178 | I leave the Guild hall and head for the orchard terraces to hunt the three boar. | Erzähler | open_run_level | Travel to the boar hunting grounds | the orchard terraces and brush slopes of Thornhollow | 285/104 | 17.6 s |
| 179 | I draw my longsword and approach the brush slope slowly, keeping the terrace row at my back, looking for a single boar I can engage apart fr… | Erzähler | open_run_level | Hunt the boar for the active contract | the brush slope thicket | 285/104 | 26.4 s |
| 180 | I move to cut off the old notched boar drifting uphill, staying quiet past the twig, and attack him from the brush side before he can close … | Erzähler | open_run_level | Engage the solitary boar apart from the pair | the brush slope thicket | 285/104 | 19.1 s |
| 181 | I push out of the thicket and move straight across the open upper terrace toward the notched boar, closing the distance with my longsword re… | Erzähler | open_run_level | Close to ENGAGED range with Wild Boar N | the brush slope thicket | 277/104 | 18.4 s |
| 182 | I attack Wild Boar N with a Basic Attack. | Erzähler | open_run_level | Damage the engaged boar | the brush slope thicket | 277/104 | 18.3 s |
| 183 | I finish Wild Boar N with a Basic Attack. | Erzähler | open_run_level | Kill the engaged boar | the brush slope thicket | 277/104 | 17.9 s |
| 184 | I search the upper terrace near the scratching post and the old orchard rows, moving carefully after the big boar I just heard. | Erzähler | open_run_level | Continue the boar contract toward 3/3 | the brush slope thicket | 277/104 | 27.2 s |
| 185 | I move up the orchard rows toward the old gnarled trees, longsword ready, and attack the big boar there with a Basic Attack. | Erzähler | open_run_level | Engage the big boar for boar 2/3 | the old gnarled trees | 277/104 | 23.2 s |
| 186 | I move down into the shaded hollow along the run, longsword ready, and search for the sounder among the hazel thickets. | Erzähler | open_run_level | Track the remaining boar toward 3/3 | the shaded hollow along the run | 277/104 | 20.0 s |
| 187 | I follow the fresh trail deeper into the hazel toward the seep, longsword ready, and search for the sounder. | Erzähler | open_run_level | Track the sounder for boar 2/3 | the seep's source under the leaning thorn tree | 277/104 | 25.2 s |
| 188 | I push forty paces north into the sedge brush toward the grunting, longsword ready, and attack the first boar I come upon with a Basic Attac… | Erzähler | open_run_level | Engage the sounder for boar 2/3 | the sedgy flat where the seep spreads over flat stones | 277/104 | 25.4 s |
| 189 | I attack the nearest pig, the yearling, with Cleave to catch the sow beside it in the same sweep. | Erzähler | open_run_level | Fight the sounder with an AoE on clustered pigs | the sedgy flat where the seep spreads over flat stones | 277/104 | 25.2 s |
| 190 | I stand my ground as the big boar advances and attack it with a Basic Attack the moment it comes within reach of my longsword. | Erzähler | open_run_level | Engage the big boar for boar 2/3 | the sedgy flat where the seep spreads over flat stones | 277/104 | 18.0 s |
| 191 | I close the last two strides toward the big boar and attack it with a Basic Attack as I come into reach. | Erzähler | open_run_level | Engage the big boar to close from SHORT to ENGAGED and strike | the sedgy flat where the seep spreads over flat stones | 259/104 | 19.7 s |
| 192 | I attack the wounded big boar with a Basic Attack while it stands engaged. | Erzähler | open_run_level | Finish the big boar for boar 2/3 | the sedgy flat where the seep spreads over flat stones | 259/104 | 20.9 s |
| 193 | #assign STR 3 VIT 2 | System (Befehl) | open_run_level | Spend level-up points | the sedgy flat where the seep spreads over flat stones | 259/104 | 3.1 s |
| 194 | I follow the sounder's trail north into the hazel toward the shaded hollow, longsword ready, looking for the third pig. | Erzähler | open_run_level | Hunt the third boar to complete the contract | the sedgy flat where the seep spreads over flat stones | 259/104 | 23.0 s |
| 195 | I approach Wild Boar S and attack it with a Basic Attack. | Erzähler | open_run_level | Kill the third boar for the contract | the sedgy flat where the seep spreads over flat stones | 257/104 | 24.5 s |
| 196 | I finish the wounded Wild Boar S with a Basic Attack before the second one reaches me. | Erzähler | open_run_level | Kill boar S for contract 3/3 | the sedgy flat where the seep spreads over flat stones | 257/104 | 22.9 s |
| 197 | I attack Wild Boar R with a Basic Attack before it charges. | Erzähler | open_run_level | Kill the last hostile boar | the sedgy flat where the seep spreads over flat stones | 257/104 | 15.1 s |
| 198 | I step in to ENGAGED with Wild Boar R and attack it with a Basic Attack as it charges. | Erzähler | open_run_level | Close range and kill the final boar for the contract | the sedgy flat where the seep spreads over flat stones | 252/104 | 16.8 s |
| 199 | I finish the badly wounded Wild Boar R with a Basic Attack. | Erzähler | open_run_level | Kill the final boar for contract completion | the sedgy flat where the seep spreads over flat stones | 252/104 | 15.7 s |
| 200 | I claim the boar tusks and hides from all three carcasses, then head back to the Guild hall to turn in the completed Boar Trouble contract. | Erzähler | open_run_level | Loot the kills and return for the contract turn-in | the Guild hall, Thornhollow | 252/104 | 28.7 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 7 (notiert vor Zug 8): Engine refused combined travel+search last turn; now arrived, so searching separately.
- zu Zug 9 (notiert vor Zug 10): Stealth failed; harrier spotted me but circles overhead without fleeing. One main action per turn — the swing was refused last turn.
- zu Zug 12 (notiert vor Zug 13): Harrier stays five strides high, out of melee reach; needs a way to force a low pass.
- zu Zug 14 (notiert vor Zug 15): Engine resolves only one kind of action per message; the fish was never caught, so the bait ambush could not proceed.
- zu Zug 23 (notiert vor Zug 24): Only 7 silver; both longswords and even the 64 cp cuirass would leave under 20 cp, so no purchase is possible. Gear goal kept for the next visit with more income.
- zu Zug 24 (notiert vor Zug 25): Smith prices were corrected by the engine (cuirass 64 cp); with 70 cp total, buying would leave under 20 cp, so skipping remains correct.
- zu Zug 27 (notiert vor Zug 28): System refused my attack because no targetable actor was registered in the scene despite narration describing the boar.
- zu Zug 31 (notiert vor Zug 32): Combat requires declared movement to close from SHORT to ENGAGED; Basic Attack alone was refused.
- zu Zug 38 (notiert vor Zug 39): Previous 'ask for a bed' was refused as arrival pending; must complete arrival with the landlady first.
- zu Zug 41 (notiert vor Zug 42): Fully recovered overnight (HP 155/155); coin 107 cp exceeds gear-check threshold.
- zu Zug 43 (notiert vor Zug 44): All affordable upgrades are +0 or negligible for 64+ cp; with only 67 cp and a 20 cp reserve, no useful purchase is possible. Boar quest at 1/4.
- zu Zug 53 (notiert vor Zug 54): Contract at 2/4; boar B was left alive deliberately — can return for the last two later.
- zu Zug 56 (notiert vor Zug 57): No supported armour upgrade offered (jack of plate not equipment); weapon-only upgrade taken. 26 copper remains.
- zu Zug 71 (notiert vor Zug 72): Cleave repeatedly refused at range; the engine seems to require the target already ENGAGED before declaring the attack.
- zu Zug 80 (notiert vor Zug 81): Turn-in happened at Alderwatch, not Thornhollow as assumed; wound healing likely still pending rest.
- zu Zug 94 (notiert vor Zug 95): Cleave refused at range; must be adjacent before swinging.
- zu Zug 96 (notiert vor Zug 97): Level 8, sow defeated 1/3; two young boar fled, another sign uphill.
- zu Zug 100 (notiert vor Zug 101): Lessa said no slope-climbing tonight; plan is to wait for healing rather than return at dusk.
- zu Zug 114 (notiert vor Zug 115): HUD says 1/3 defeated though both yearling and sow were defeated — count may need recheck later.
- zu Zug 117 (notiert vor Zug 118): Engine refused the rush: yearling at MEDIUM, Basic Attack reaches ENGAGED at most; will goad a charge instead.
- zu Zug 119 (notiert vor Zug 120): HUD still shows 1/3 defeated despite three boar defeated — count needs recheck via #quest.
- zu Zug 121 (notiert vor Zug 122): Quest still shows 1/3 despite three boar defeated — likely only kills on the terraces/brush slopes count; the flats kills didn't register.
- zu Zug 128 (notiert vor Zug 129): Arrival to the terraces is confirmed; a bedded boar in the broom hollow is noted as a sign but not yet engaged.
- zu Zug 130 (notiert vor Zug 131): The boar was a sign, not a targetable actor; must close distance before attacking.
- zu Zug 131 (notiert vor Zug 132): The broom hollow boar was long gone; the sign list still mentions it, but narration confirmed only an abandoned nest.
- zu Zug 133 (notiert vor Zug 134): Sign list still claims fresh wallow and heavy breathing in the hollow, but two visits found only abandoned bedding; contradiction persists.
- zu Zug 142 (notiert vor Zug 143): System refused the attack: the crunching boar was not a targetable actor in the active scene, so travel must be its own step.
- zu Zug 147 (notiert vor Zug 148): HP max shown 265 vs earlier 240; thigh wound persists.
- zu Zug 148 (notiert vor Zug 149): System again refused: the big boar is scenery, not a targetable actor, until the scene engages it.
- zu Zug 149 (notiert vor Zug 150): Boar L is marked dead and Boar M SHORT is now the targetable actor; contract still 2/3.
- zu Zug 155 (notiert vor Zug 156): Contract turn-in confirmed at Guild, level 10 with 5 free points; hip wound needs stitching.
- zu Zug 161 (notiert vor Zug 162): System corrected the smith's narrated price: Superior Longsword is 260 cp, not 180.
- zu Zug 162 (notiert vor Zug 163): HUD still lists Starter Longsword equipped and duplicate boar hide/tusk entries in Carried after the sale; will recheck after equipping.
- zu Zug 163 (notiert vor Zug 164): HUD still shows duplicate hide/tusk entries in Carried and Starter Heavy Armor equipped; will recheck after sleeping. Armor set promised for tomorrow before midday.
- zu Zug 165 (notiert vor Zug 166): Carried still lists duplicate boar hides/tusks and 255 cp despite the recorded 23 silver sale and coin drop 263→255; will recheck at next #bag. Coin math suggests sale may not be reflected in HUD.
- zu Zug 167 (notiert vor Zug 168): Coin is 2g5s1c (~251 cp), so the 60 silver armor set is unaffordable; engine still refuses an armor shop entry, citing no equipment slot. HUD still shows duplicate hide/tusk entries despite the recorded sale.
- zu Zug 168 (notiert vor Zug 169): Smith insists he already paid for the boar parts; HUD still shows duplicate hide/tusk entries — checking bag to resolve the contradiction.
- zu Zug 169 (notiert vor Zug 170): #bag confirms the duplicates are real inventory, not ghost entries; the smith's claim of buying 'the boar parts' referred only to the first set.
- zu Zug 170 (notiert vor Zug 171): Engine result echoed duplicate sword shop offers instead of a sale; will verify coin in bag after payment.
- zu Zug 171 (notiert vor Zug 172): Smith's spoken offer was 1g10s but System books it as 200 cp — taking the higher engine-confirmed bid.
- zu Zug 173 (notiert vor Zug 174): Smith confirms no affordable real armor at the forge; suggests a padded robe from the market-square clothier. Gear priority partly satisfied for weapon (superior sword already matches ATK); armor still pending.
- zu Zug 175 (notiert vor Zug 176): Padded robe (DEF 3) is worse than currently equipped DEF 6 component; no affordable armor upgrade exists here. Gear priority satisfied: weapon superior, no useful armor available.
- zu Zug 180 (notiert vor Zug 181): Engine refused attack because target was at LONG; movement must be declared separately. Sow and yearling remain unaware downhill.
- zu Zug 185 (notiert vor Zug 186): Quest panel still shows 1/3 defeated despite the notched tusker kill; may need turn-in to update count.
- zu Zug 186 (notiert vor Zug 187): Search refused earlier as 'arrival pending'; now arrived in the hollow, so the search should be valid.
- zu Zug 188 (notiert vor Zug 189): Quest count still 1/3; five pigs present including the big boar Q (108 HP) — risky at Level 10, may need to withdraw after killing two.
- zu Zug 191 (notiert vor Zug 192): Combat panel lists only one hostile in the fight; other pigs fled or watch from range.
- zu Zug 193 (notiert vor Zug 194): Level 11 confirmed, points spent; quest count 2/3.
- zu Zug 194 (notiert vor Zug 195): HUD shows two live boars present (R LONG, S SHORT) despite narration saying the sounder fled north; targeting S at SHORT.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t18 | 18 | 1 | – | ja | 1 | gewonnen, 60 XP |
| enc.t29 | 32 | 1 | – | nein | 1 | gewonnen, 450 XP |
| enc.t46 | 50 | 1 | – | nein | 1 | gewonnen, 380 XP |
| enc.t55 | 60 | 1 | – | nein | 1 | gewonnen, 560 XP |
| enc.t65 | 73 | 1 | – | nein | 1 | gewonnen, 475 XP |
| enc.t82 | 95 | 1 | – | nein | 1 | gewonnen, 385 XP |
| enc.t94 | 110 | 1 | – | nein | 1 | gewonnen, 60 XP |
| enc.t97 | 113 | 1 | – | nein | 1 | gewonnen, 75 XP |
| enc.t103 | 119 | 1 | – | nein | 1 | gewonnen, 60 XP |
| enc.t120 | 140 | 1 | – | nein | 1 | gewonnen, 75 XP |
| enc.t123 | 144 | 1 | – | nein | 1 | gewonnen, 310 XP |
| enc.t129 | 152 | 1 | – | nein | 1 | gewonnen, 475 XP |
| enc.t154r | 181 | 1 | – | nein | 1 | gewonnen, 380 XP |
| enc.t164 | 191 | 1 | – | nein | 1 | gewonnen, 560 XP |
| enc.t167 | 195 | 2 | – | nein | 2 | gewonnen, 565 XP |

## Quests

- **Hunt the Millpond Marsh Harrier** — active (Zug 6) → completed (Zug 19)
  - Aufgabe: Kill 1 millpond marsh harrier at the reed banks of the Alderwatch millpond. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 millpond marsh harrier killed at the reed banks of the Alderwatch millpond.
- **Thin the Thornhollow Boar Sounder** — active (Zug 22) → completed (Zug 79)
  - Aufgabe: Kill 4 Thornhollow boar at the orchard terraces and brush slopes of Thornhollow. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 4 Thornhollow boar killed at the orchard terraces and brush slopes of Thornhollow.
- **Hunt the Ford Serpent of Weeping Bridge** — expired (Zug 86)
  - Aufgabe: Kill 1 the Weeping Bridge river serpent at the ford beneath Weeping Bridge on the west road. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the Weeping Bridge river serpent killed at the ford beneath Weeping Bridge on the west road.
- **Cull the Barrow Fen Rotwolves** — expired (Zug 86)
  - Aufgabe: Kill 6 Barrow Fen rotwolves at the peat cuttings and drowned woods of Barrow Fen. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 6 Barrow Fen rotwolves killed at the peat cuttings and drowned woods of Barrow Fen.
- **Clear Old Crown Catacombs, Level 1** — expired (Zug 86), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of Old Crown Catacombs. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Old Crown Catacombs is clear.
- **Cull the Thornhollow Boar Sounder** — active (Zug 87) → completed (Zug 155)
  - Aufgabe: Kill 3 wild boar at the orchard terraces and brush slopes of Thornhollow. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 wild boar killed at the orchard terraces and brush slopes of Thornhollow.
- **Boar Trouble on the Orchard Terraces** — active (Zug 177) → completed (Zug 200)
  - Aufgabe: Kill 3 wild boar at the orchard terraces and brush slopes of Thornhollow. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 3 wild boar killed at the orchard terraces and brush slopes of Thornhollow.

## Auffälligkeiten

- Zug 4, Nachricht 7 (planner_repaired): the planner's first answer needed a repair
- Zug 32, Nachricht 63 (planner_repaired): the planner's first answer needed a repair
- Zug 40, Nachricht 80 (extraction_repaired): the extractor's first answer needed a repair
- Zug 54, Nachricht 108 (extraction_repaired): the extractor's first answer needed a repair
- Zug 64, Nachricht 127 (stat_words): the player spent Stat Points in words, not with #assign; nothing was assigned (for review: did the story tell them as done?)
- Zug 82, Nachricht 163 (planner_repaired): the planner's first answer needed a repair
- Zug 84, Nachricht 167 (planner_repaired): the planner's first answer needed a repair
- Zug 88, Nachricht 176 (extraction_repaired): the extractor's first answer needed a repair
- Zug 90, Nachricht 179 (planner_repaired): the planner's first answer needed a repair
- Zug 102, Nachricht 203 (planner_repaired): the planner's first answer needed a repair
- Zug 103, Nachricht 205 (planner_repaired): the planner's first answer needed a repair
- Zug 105, Nachricht 209 (planner_repaired): the planner's first answer needed a repair
- Zug 109, Nachricht 218 (extraction_repaired): the extractor's first answer needed a repair
- Zug 115, Nachricht 230 (extraction_repaired): the extractor's first answer needed a repair
- Zug 123, Nachricht 245 (planner_repaired): the planner's first answer needed a repair
- Zug 126, Nachricht 252 (extraction_repaired): the extractor's first answer needed a repair
- Zug 129, Nachricht 258 (extraction_repaired): the extractor's first answer needed a repair
- Zug 142, Nachricht 283 (planner_repaired): the planner's first answer needed a repair
- Zug 149, Nachricht 297 (planner_repaired): the planner's first answer needed a repair
- Zug 155, Nachricht 310 (extraction_repaired): the extractor's first answer needed a repair
- Zug 157, Nachricht 314 (extraction_repaired): the extractor's first answer needed a repair
- Zug 158, Nachricht 316 (extraction_repaired): the extractor's first answer needed a repair
- Zug 161, Nachricht 321 (planner_repaired): the planner's first answer needed a repair
- Zug 163, Nachricht 326 (extraction_repaired): the extractor's first answer needed a repair
- Zug 171, Nachricht 341 (planner_repaired): the planner's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 57× keine gültige JSON-Entscheidung (Züge 8, 9, 13, 16, 26, 27, 28, 29, 37, 40, 46, 47, 48, 49, 50, 60, 64, 67, 68, 70, 79, 80, 87, 89, 90, 91, 93, 94, 100, 101, 107, 108, 110, 111, 112, 116, 120, 129, 130, 132, 133, 134, 137, 142, 148, 150, 152, 157, 158, 161, 173, 175, 179, 180, 190, 194, 198)

System-Panels: CLARIFY 9, NOT TAKEN 4, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: guild_canon 4, engine_owned_fact 10, pc_inventory 3, guild_payout 3, world_rule 13, engine_owned_combat 1, no_go 6, offer 2, ambient 5, coin_already_received 3, gear_offer 3, quest_count 3, attack_commitment 7, group_unclear 1, scene_context 24, engine_recovery 2.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 57/200 Erstantworten ungültig (28.5 %); 57 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 200 | 13 | 2.6 s | 5.2 s | 12054 | 9943 | 84 | – | stop 200 | 0 |
| narrator | 170 | 0 | 8.8 s | 15.1 s | 11377 | 8734 | 400 | – | stop 170 | 0 |
| extract | 181 | 11 | 5.4 s | 9.9 s | 13124 | 10016 | 320 | – | stop 181 | 0 |
| board | 4 | 1 | 12.6 s | 27.6 s | 2579 | 1152 | 1143 | – | stop 4 | 0 |
| forge | 1 | 0 | 1.4 s | 1.4 s | 395 | 0 | 67 | – | stop 1 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 88:55 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 55.8 s) | 1:12 min |
| 200 Züge, Spiel (Senden bis HUD nach der Extraktion) | 70:56 min — Median 19.6 s, p90 33.3 s, max 87.9 s |
| 200 Züge, Spieler-Entscheidung | 12:41 min — Median 2.9 s, 57 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 11:49 min / 1:02 min / 30:00 min / 19:34 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 25.1 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 16:43 min, 80 Züge ≈ 33:27 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spiel | 163 | – | 87.9 s | 19.6 s |
| Spiel | 165 | – | 77.1 s | 19.6 s |
| Spiel | 3 | – | 74.0 s | 19.6 s |
| Provider narrator | 3 | 2 | 63.2 s | 8.8 s |
| Provider extract | 165 | 457 | 44.8 s | 5.4 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
