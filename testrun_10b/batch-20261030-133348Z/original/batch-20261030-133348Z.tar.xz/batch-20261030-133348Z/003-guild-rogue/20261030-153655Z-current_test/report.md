# Avereth Live-Test 20261030-153655Z-current_test

## Kurzfassung

- **Laufprofil:** guild-rogue; Startklasse Rogue, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** Niederlage — turn 32: he died
- **Etappen:** 1/3 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht) · class_accepted (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 2. Sicherheitsgrenzen: 200 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** noch nicht erreicht.
- **Charakter:** rogue (rogue.evasive_step, rogue.fan_of_blades) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 through E class evolution“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: curious adventurer: follow interesting opportunities without forcing dangerous encounters
- **Züge:** 32 · **Dauer:** 11:36 min · **LLM-Aufrufe der Engine/des Erzählers:** 90
- **Beobachtete Abdeckung:** 6 unterschiedliche gebuchte Reiseziele · 2 Kämpfe · 1 Verkäufe (11 cp Umsatz, ohne Questzahlungen/Geschenke) · 3 Ausrüstungswechsel · 0 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 1 · **Niederlage** in Zug 32: he died
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.125 |
| Git | e779fee3eadd (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 16.2 s |
| Browser | chrome 156.0.8078.49 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261030-153655Z-current_test“, Seed 406300238 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |
| class_accepted | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | Rogue. | Engine (Menü/Rückfrage) | creation_complete | Choose Rogue as base class | public roadside verge outside Ashbridge | 90/84 | 2.3 s |
| 2 | I choose Fan of Blades and Evasive Step as my two skills. | Engine (Menü/Rückfrage) | creation_complete | Finish character creation | public roadside verge outside Ashbridge | 90/84 | 2.1 s |
| 3 | I walk toward Ashbridge's gate and enter the city. | Erzähler | open_run_level | Enter Ashbridge to find the Guild board | Ashbridge | 90/84 | 23.6 s |
| 4 | I head up toward the stone building with the green banner and swords carved over its door, looking to register with the Guild. | Erzähler | open_run_level | Reach the Guild hall and register | Adventurers' Guild hall, Ashbridge | 90/84 | 20.0 s |
| 5 | I register with the Guild and give my name: Alaric Red. | Erzähler | open_run_level | Register with the Guild | Adventurers' Guild hall, Ashbridge | 90/84 | 14.3 s |
| 6 | I pay the two silver and ask her to put me on the rolls. | Erzähler | open_run_level | Pay registration fee | Adventurers' Guild hall, Ashbridge | 90/84 | 17.3 s |
| 7 | I walk to the board and read the Novice-grade contracts. | Erzähler | open_run_level | Find a first achievable contract | Adventurers' Guild hall, Ashbridge | 90/84 | 32.8 s |
| 8 | I tear the stub off the Quarry Track Ambusher notice and take it to the desk to accept the contract. | Erzähler | open_run_level | Accept the lynx hunt as a first achievable contract | Adventurers' Guild hall, Ashbridge | 90/84 | 17.7 s |
| 9 | I head out the east gate and follow the old quarry track ruts, watching for the lynx. | Erzähler | open_run_level | Travel to the lynx hunt | old quarry track east of Ashbridge | 90/84 | 20.5 s |
| 10 | I move quietly toward the gorse thickets and the shade of the pines, dagger ready, scanning for the grey lynx. | Erzähler | open_run_level | Hunt the lynx at the quarry track | old quarry track east of Ashbridge | 90/84 | 33.9 s |
| 11 | I back out of the gorse run and put a boulder at my back, dagger ready, watching the ferns where the lynx is circling. | Erzähler | open_run_level | Set up defensively before the lynx attacks | old quarry track east of Ashbridge | 90/84 | 19.2 s |
| 12 | I hold still against the boulder, eyes tracking the fern line and gorse, dagger ready for the cat's pounce. | Erzähler | open_run_level | Wait defensively for the lynx's ambush | old quarry track east of Ashbridge | 90/84 | 14.6 s |
| 13 | I strike with my dagger at the lynx at SHORT range. | Erzähler | open_run_level | Attack the lynx | old quarry track east of Ashbridge | 90/84 | 15.1 s |
| 14 | I use Fan of Blades at the lynx at SHORT range. | Erzähler | open_run_level | Attack the lynx with the AoE skill at its range | old quarry track east of Ashbridge | 82/84 | 13.1 s |
| 15 | I finish the lynx with a dagger strike at ENGAGED range. | Erzähler | open_run_level | Kill the wounded lynx | old quarry track east of Ashbridge | 82/84 | 16.4 s |
| 16 | I travel back to the Guild hall in Ashbridge and turn in the completed contract 'Kill the Quarry Track Ambusher'. | Erzähler | open_run_level | Turn in the lynx contract at the Guild hall | Adventurers' Guild hall, Ashbridge | 82/84 | 24.3 s |
| 17 | #assign AGI 2 PER 2 VIT 1 | System (Befehl) | open_run_level | Spend level-up stat points | Adventurers' Guild hall, Ashbridge | 82/84 | 2.2 s |
| 18 | I look at the Guild board for a new Novice contract I can take. | Erzähler | open_run_level | Pick next contract | Adventurers' Guild hall, Ashbridge | 82/84 | 16.8 s |
| 19 | I tell the clerk I'll decide shortly, and head out to find a smith or weapons merchant in Ashbridge to compare light weapons and light armou… | Erzähler | open_run_level | Gear check before next hunt | Harrow's forge | 82/84 | 27.2 s |
| 20 | I'll take the Quilted Fighting Robes for 48 copper, please. | Erzähler | open_run_level | Buy affordable armour upgrade | Harrow's forge | 82/84 | 18.6 s |
| 21 | I thank Harrow and change into the Quilted Fighting Robes behind the curtain, leaving the old kit on the stool. | Erzähler | open_run_level | Equip the purchased armour upgrade | Harrow's forge | 82/84 | 13.2 s |
| 22 | "Going. What will you give me for the old kit — and do you take lynx pelts and claws off Guild hands?" | Erzähler | open_run_level | Sell old kit and surplus loot to Harrow | Harrow's forge | 82/84 | 15.9 s |
| 23 | "Two coppers, sold — keep the kit." I pocket the coins and head to the Iron Scale near the market to find the buyer who takes Guild monster … | Erzähler | open_run_level | Sell loot to monster-parts buyer | Iron Scale | 82/84 | 20.7 s |
| 24 | I lay the grey lynx pelt and three claws on the counter and show my Guild plate front side. "What will you pay for these?" | Erzähler | open_run_level | Sell monster loot to the Iron Scale buyer | Iron Scale | 82/84 | 14.4 s |
| 25 | "Eleven coppers — sold." I push the pelt and claws across the counter and take the coins. | Erzähler | open_run_level | Accept the confirmed offer for the lynx loot | Iron Scale | 82/84 | 14.3 s |
| 26 | I head to the Adventurers' Guild hall and look over the contract board for a hunt or task a Level-2 Rogue can handle. | Erzähler | open_run_level | Find a Guild contract for income toward the shortsword | Adventurers' Guild hall, Ashbridge | 82/84 | 17.3 s |
| 27 | "The heron cull — Thin the Reedmire Herons, 140 copper." I slide my Guild plate across the counter to accept it. | Erzähler | open_run_level | Accept the heron hunt contract | Adventurers' Guild hall, Ashbridge | 82/84 | 18.4 s |
| 28 | I take the slip and head east along the river road, following the eel-barrel carts toward the Reed Flats eel-weirs. | Erzähler | open_run_level | Travel to the heron hunting grounds | eel-weirs of the Reed Flats | 82/84 | 22.8 s |
| 29 | I show the worker my contract slip and ask which birds have been troubling the weirs, keeping clear of the cracked third walkway. | Erzähler | open_run_level | Talk to the weir worker, then hunt herons | eel-weirs of the Reed Flats | 82/84 | 19.5 s |
| 30 | I move onto the second walkway and use Fan of Blades against the three herons in the reed bank beside it, watching my footing. | Erzähler | open_run_level | Fight the sitting herons with AoE from the walkway | eel-weirs of the Reed Flats | 63/84 | 17.9 s |
| 31 | I strike the wounded heron again with a basic attack. | Erzähler | open_run_level | Finish heron A before the others close | eel-weirs of the Reed Flats | 8/84 | 15.5 s |
| 32 | I take Evasive Step, backing off one band down the walkway to keep the herons from surrounding me. | Erzähler | open_run_level | Survive the fight at 8 HP by reducing incoming damage | eel-weirs of the Reed Flats | 0/84 | 16.5 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 8 (notiert vor Zug 9): Contract confirmed active in HUD; only 3 silver, so gear shopping must wait for the 40 cp reward.
- zu Zug 20 (notiert vor Zug 21): Only 22 copper left; shortsword (80 cp) unaffordable until more income — gear goal partially done, weapon pending.
- zu Zug 22 (notiert vor Zug 23): Harrow confirmed robes equipped; shortsword (80 cp) still unaffordable at 22 copper.
- zu Zug 25 (notiert vor Zug 26): Loot sale confirmed: 33 copper total; shortsword still out of reach, need contract income.
- zu Zug 27 (notiert vor Zug 28): Contract confirmed ACTIVE, 0/5; coin is 3s3c so the 80 cp shortsword is now affordable, but I'll gear up in town after the hunt per the gear plan.
- zu Zug 31 (notiert vor Zug 32): Dangerous opening: Fan of Blades first strike only hit one heron (26 of 72), and three herons closing dropped me from 82 to 8 HP in two rounds. After this fight I need serious armour and recovery before any further hunts.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t12r | 12 | 1 | – | nein | 1 | gewonnen, 75 XP |
| enc.t29 | 30 | 3 | – | nein | 0 | **tot** |

## Quests

- **Kill the Quarry Track Ambusher** — active (Zug 8) → completed (Zug 16)
  - Aufgabe: Kill 1 grey lynx at old quarry track east of Ashbridge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 grey lynx killed at old quarry track east of Ashbridge.
- **Thin the Reedmire Herons** — active (Zug 27)
  - Aufgabe: Kill 5 marsh pike-herons at eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 5 marsh pike-herons killed at eel-weirs of the Reed Flats.

## Auffälligkeiten

- Zug 19, Nachricht 38 (extraction_repaired): the extractor's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 9× keine gültige JSON-Entscheidung (Züge 2, 10, 11, 12, 13, 14, 22, 24, 29)

System-Panels: CLARIFY 0, NOT TAKEN 0, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: ambient 2, guild_canon_price 1, guild_canon 2, world_rule 6, engine_owned_fact 2, offer 2, group_unclear 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 9/32 Erstantworten ungültig (28.1 %); 9 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 29 | 0 | 2.0 s | 5.8 s | 11478 | 9861 | 63 | – | stop 29 | 0 |
| narrator | 29 | 0 | 7.0 s | 12.2 s | 11351 | 8823 | 350 | – | stop 29 | 0 |
| extract | 30 | 1 | 4.7 s | 8.1 s | 12039 | 9832 | 322 | – | stop 30 | 0 |
| board | 2 | 1 | 9.1 s | 10.3 s | 3110 | 2651 | 1103 | – | stop 2 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 11:36 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 16.2 s) | 0:30 min |
| 32 Züge, Spiel (Senden bis HUD nach der Extraktion) | 9:19 min — Median 17.3 s, p90 24.3 s, max 33.9 s |
| 32 Züge, Spieler-Entscheidung | 1:22 min — Median 2.6 s, 9 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 1:17 min / 0:18 min / 4:01 min / 2:33 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 20.0 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 13:20 min, 80 Züge ≈ 26:41 min (ohne Einrichtung) |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
