# Avereth – 3 natürliche Testkampagnen

Status: **completed**. Serie abgeschlossen bedeutet, dass die Läufe beendet sind; es bedeutet nicht 3 bestandene Level-15-Abnahmen.

| Nr. | Profil | Seed | Eingaben | Level | Ende | Originalbericht |
|---|---|---:|---:|---:|---|---|
| 1 | guild-warrior | 406300236 | 200 | 12 | limit | [report.md](001-guild-warrior/20261030-133348Z-current_test/report.md) |
| 2 | guild-mage | 406300237 | 94 | 7 | defeat | [report.md](002-guild-mage/20261030-150251Z-current_test/report.md) |
| 3 | guild-rogue | 406300238 | 32 | 2 | defeat | [report.md](003-guild-rogue/20261030-153655Z-current_test/report.md) |

