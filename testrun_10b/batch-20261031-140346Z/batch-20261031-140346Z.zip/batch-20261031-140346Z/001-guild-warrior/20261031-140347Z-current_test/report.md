# Avereth Live-Test 20261031-140347Z-current_test

## Kurzfassung

- **Laufprofil:** guild-warrior; Startklasse Warrior, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** abgebrochen: Limit erreicht — 260 turns
- **Etappen:** 1/3 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht) · class_accepted (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 12. Sicherheitsgrenzen: 260 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** Level 6, 40 XP seit Levelaufstieg, 27 cp, HP 145, MP 96; Ort loc.asterford.cordwainer_row.mardas_cellar. Ausrüstung und Skills stehen in evaluation.json → progression.checkpoint.
- **Charakter:** warrior (warrior.cleave, warrior.quick_slash) · Regelstand 2 (Warrior, Mage, Rogue)
- **Ziel-Dungeon:** Glimmerdeep Grotto, Ebene 1 (ohne Dungeon-Vertrag: der erste betretene)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 through E class evolution“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: pragmatic adventurer: sell surplus loot and invest in useful equipment and techniques
- **Züge:** 260 · **Dauer:** 103:31 min · **LLM-Aufrufe der Engine/des Erzählers:** 735
- **Beobachtete Abdeckung:** 55 unterschiedliche gebuchte Reiseziele · 24 Kämpfe · 3 Verkäufe (120 cp Umsatz, ohne Questzahlungen/Geschenke) · 3 Ausrüstungswechsel · 1 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 62
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.137 |
| Git | 512437369242 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 15.3 s |
| Browser | chrome 156.0.8078.49 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261031-140347Z-current_test“, Seed 679216483 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |
| class_accepted | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | Warrior | Engine (Menü/Rückfrage) | creation_complete | Choose Warrior class | public roadside verge outside Glassmere | 90/84 | 2.2 s |
| 2 | I choose Cleave and Quick Slash as my two skills. | Engine (Menü/Rückfrage) | creation_complete | Finish character creation with mandatory Cleave | public roadside verge outside Glassmere | 95/84 | 2.1 s |
| 3 | I walk to the city gates of Glassmere and look for the Adventurers' Guild hall. | Erzähler | creation_complete | Enter town and find the Guild to take contracts | Adventurers' Guild hall, Glassmere | 95/84 | 25.6 s |
| 4 | "Registering. What do you need from me, and what's on the board for a fresh F-rank?" | Erzähler | creation_complete | Register with the Guild and see available contracts | Adventurers' Guild hall, Glassmere | 95/84 | 18.8 s |
| 5 | I pay the two silver, sign the sheet, and ask the clerk what Novice contracts are available now. | Erzähler | open_run_level | Register with the Guild and view Novice contracts | Adventurers' Guild hall, Glassmere | 95/84 | 19.8 s |
| 6 | I ask Doran where the Glimmerdeep cleft and its porter are, and how the academy pays—per clear or per beetle. | Erzähler | open_run_level | Get directions and pay terms for the Glimmerdeep cull work | Adventurers' Guild hall, Glassmere | 95/84 | 20.1 s |
| 7 | I head out the north gate, follow the stream up to Glimmerdeep, and show Hesk my Guild plate to sign in for the outer grottos. | Erzähler | open_run_level | Travel to Glimmerdeep and register with the porter | Glimmerdeep Grotto | 95/84 | 23.0 s |
| 8 | I pay the 10 copper gate fee and enter, heading into the west gallery to work the slimes. | Erzähler | open_run_level | Enter dungeon and cull slimes | West Gallery | 95/84 | 17.8 s |
| 9 | I draw my longsword and charge the nearest beetle, cleaving at it and any that crowd in. | Erzähler | open_run_level | Fight the beetles with Cleave | West Gallery | 84/84 | 17.0 s |
| 10 | I finish the wounded one with a Quick Slash at Crystal Beetle A. | Erzähler | open_run_level | Kill the wounded beetle | West Gallery | 78/84 | 14.8 s |
| 11 | I use Cleave to hit both remaining beetles at once. | Erzähler | open_run_level | AoE on two engaged foes | West Gallery | 72/84 | 12.0 s |
| 12 | I finish Beetle C with a Quick Slash. | Erzähler | open_run_level | Kill the nearly dead beetle | West Gallery | 68/84 | 14.6 s |
| 13 | I finish the last beetle with a Basic Attack. | Erzähler | open_run_level | Kill the last beetle | West Gallery | 68/84 | 14.9 s |
| 14 | #assign STR 3 VIT 3 AGI 2 WIL 2 | System (Befehl) | open_run_level | Spend 10 free stat points | West Gallery | 68/84 | 2.1 s |
| 15 | I continue down the West Gallery, staying alert for more threats. | Erzähler | open_run_level | Explore deeper into the grotto | Crystal Chamber | 68/84 | 13.5 s |
| 16 | I attack the Quartz Ooze with Cleave, then step back out of its reach. | Erzähler | open_run_level | Engage the ooze cautiously with AoE-free single-target Cleave | Crystal Chamber | 68/84 | 15.9 s |
| 17 | I step up to the Quartz Ooze and attack it with Cleave, staying engaged. | Erzähler | open_run_level | Engage the ooze in melee and attack | Crystal Chamber | 68/84 | 13.6 s |
| 18 | I finish the wounded ooze with a Quick Slash. | Erzähler | open_run_level | Kill the ooze before it counterattacks | Crystal Chamber | 68/84 | 12.7 s |
| 19 | #assign STR 2 VIT 2 WIL 1 | System (Befehl) | open_run_level | Spend the 5 new free stat points | Crystal Chamber | 68/84 | 2.1 s |
| 20 | I take a chunk of free crystal from the chamber wall and continue down the far passage deeper into the grotto. | Erzähler | open_run_level | Loot free crystal and explore deeper | Moss Basin Cavern | 68/84 | 25.4 s |
| 21 | I refill my waterskin at the basin and examine the many-toed tracks closely. | Erzähler | open_run_level | Investigate the tracks before choosing an exit | Moss Basin Cavern | 68/84 | 16.4 s |
| 22 | I head back through the Crystal Chamber and make my way out of the Glimmerdeep Grotto toward the academy's cleft, wounded as I am. | Erzähler | open_run_level | Return to town to recover and sell loot | Glimmerdeep Grotto | 68/84 | 37.6 s |
| 23 | I sit and accept the broth, then ask Hesk whether anyone at the academy cleft buys chitin, ooze parts or crystal. | Erzähler | open_run_level | Rest briefly and learn where to sell loot | Glimmerdeep Grotto | 68/84 | 48.7 s |
| 24 | I thank Hesk, climb up to the academy cleft, and ask for steward Doss's hall to sell my crystal, chitin and ooze parts. | Erzähler | open_run_level | Reach the academy cleft and find Doss to sell loot | academy cleft | 68/84 | 29.9 s |
| 25 | I lay out six chitin plates, the venom gland, the ooze gel, the ooze core and the fist-sized crystal shard, and ask what you'll offer for ea… | Erzähler | open_run_level | Get a sell offer from Doss | academy cleft | 68/84 | 39.4 s |
| 26 | I'll take your offer on everything except the core — keep that overnight and put it to the enchanters' bench in the morning; I'll be back wh… | Erzähler | open_run_level | Sell everything but the core now, return for the core tomorrow | academy cleft | 68/84 | 41.5 s |
| 27 | Yes to the plates, the gland and the gel — thirty-four copper for those three; the core stays for the morning bench offer. | Erzähler | open_run_level | Accept the confirmed offer on plates, gland and gel | academy cleft | 68/84 | 19.9 s |
| 28 | Yes, we have it — thirty-four copper for the three, and the core stays under the counter until morning. | Erzähler | open_run_level | Confirm the sale of plates, gland and gel for 34 copper | academy cleft | 68/84 | 23.3 s |
| 29 | Alaric Red, for your book. And Doss — the shard: you said it was done at ten silver, but I don't see the coins settled. Let's finish that li… | Erzähler | open_run_level | Sign the ledger and reconcile the shard sale discrepancy | academy cleft | 68/84 | 17.2 s |
| 30 | #audit | System (Befehl) | open_run_level | Verify coin total and shard removal after Doss's ten-silver payment | academy cleft | 68/84 | 2.1 s |
| 31 | #bag | System (Befehl) | open_run_level | Verify coins and whether the shard is actually gone | academy cleft | 68/84 | 2.1 s |
| 32 | Then let's settle it properly — I accept ten silver for the shard. Take it, count me the coins. | Erzähler | open_run_level | Explicitly accept Doss's ten-silver offer so the engine settles the sale | academy cleft | 68/84 | 17.2 s |
| 33 | #bag | System (Befehl) | open_run_level | Verify whether the ten-silver shard sale is now engine-settled | academy cleft | 68/84 | 2.1 s |
| 34 | I pocket the coins and leave Doss's shop, heading down the hill toward the Broken Antler to eat and rest. | Erzähler | open_run_level | Give up on the unsettled shard sale and continue the run | Broken Antler | 68/84 | 18.3 s |
| 35 | I'll take the stew and bread, and a bed for the night — ten copper, and I'll sleep until morning. | Erzähler | open_run_level | Buy meal and lodging, then recover overnight | Broken Antler | 150/96 | 15.9 s |
| 36 | I'll take a bowl of porridge, then head to the porter's hall when the bell rings to look for a Guild contract. | Erzähler | open_run_level | Eat, then pick up a Guild contract at the hall | porter's hall | 150/96 | 26.8 s |
| 37 | I walk to the contract board and read the Novice rows, looking for a pest or delivery job I can take. | Erzähler | open_run_level | Pick a Guild contract from the board | porter's hall | 150/96 | 24.2 s |
| 38 | I ask the grey-clad clerk what odd work she has available off the books. | Erzähler | open_run_level | Ask about off-the-books work in the cleft | porter's hall | 150/96 | 19.5 s |
| 39 | I accept Tam's job: fifty copper to clear the crystal beetle nest behind the drying shed. Where are the workings exactly, and can I buy or b… | Erzähler | open_run_level | Accept off-the-books beetle nest job | porter's hall | 150/96 | 19.1 s |
| 40 | I shake Tam's hand to seal the deal, then follow the haul road up to his drying shed — third building with the wide doors — to pick up the l… | Erzähler | open_run_level | Accept the beetle nest job and collect the borrowed lamp | Tam's drying shed | 150/96 | 21.4 s |
| 41 | I take the hooded lantern, wick and oil flask from the shelf, light it, and head for the left tunnel mouth behind the shed. | Erzähler | open_run_level | Collect the borrowed lamp and enter the beetle tunnel | the old shallow workings | 150/96 | 23.9 s |
| 42 | I swing my longsword in a Cleave at the three beetles working the seep. | Erzähler | open_run_level | Fight the beetle nest with Cleave | the old shallow workings | 150/96 | 13.2 s |
| 43 | I raise the lantern and press deeper down the left tunnel, sword ready, to finish clearing the nest. | Erzähler | open_run_level | Clear the rest of the beetle nest for Tam's job | crystal beetle chamber | 150/96 | 19.0 s |
| 44 | I swing my longsword in a Cleave at the nearest group of beetles between the pillars. | Erzähler | open_run_level | Clear the beetle chamber with AoE | crystal beetle chamber | 150/96 | 16.5 s |
| 45 | I advance on the nearest beetle, and once it is engaged I swing my longsword in a Cleave at it. | Erzähler | open_run_level | Engage the nearest beetle in reach and use Cleave | crystal beetle chamber | 148/96 | 21.3 s |
| 46 | I swing my longsword in a Cleave at the two beetles engaged with me. | Erzähler | open_run_level | Continue clearing the beetle nest with AoE on engaged targets | crystal beetle chamber | 145/96 | 22.3 s |
| 47 | I swing my longsword in a Cleave at the three beetles engaged with me. | Erzähler | open_run_level | Finish the beetle nest with AoE | crystal beetle chamber | 145/96 | 14.7 s |
| 48 | I head back out of the tunnel with the lantern and find Tam to tell him the beetle nest is cleared. | Erzähler | open_run_level | Turn in Tam's beetle nest job | Tam's drying shed | 145/96 | 26.6 s |
| 49 | #assign STR 2 VIT 3 | System (Befehl) | open_run_level | Spend level-up stat points on STR and VIT | Tam's drying shed | 145/96 | 2.4 s |
| 50 | "Nest's cleared to the last shell — I'll take that fifty copper now, and you're welcome to the shells my brother's boys can sweep." | Erzähler | open_run_level | Collect Tam's promised payment for clearing the beetle nest | Tam's drying shed | 145/96 | 24.3 s |
| 51 | I accept the forty-three copper and Tam's promise of the rest this evening, and I head down toward the cleft to find a smith before any othe… | Erzähler | open_run_level | Take partial payment, pursue gear upgrade | smithy | 145/96 | 37.3 s |
| 52 | "Looking to replace my starter gear if you've got it — what have you got in longswords and heavy armor, and at what price?" | Erzähler | open_run_level | Ask the smith about affordable weapon and armour upgrades | smithy | 145/96 | 22.2 s |
| 53 | I offer the smith my beetle chitin plates and ask what he'd pay for them, and whether that could go toward the fine breastplate. | Erzähler | open_run_level | Sell surplus chitin, apply to gear purchase | smithy | 145/96 | 20.0 s |
| 54 | I take your offer — the twenty-one plates at four copper each, credited toward the fine breastplate, and I pay the five silver and eight cop… | Engine (Menü/Rückfrage) | open_run_level | Sell chitin and buy the fine breastplate | smithy | 145/96 | 10.8 s |
| 55 | I buy the fine F-Rank breastplate from the smith for a total of 72 copper, selling him 21 beetle chitin plates at 4 copper each (84 copper c… | Erzähler | open_run_level | Complete clarified sale of chitin and purchase of fine breastplate | smithy | 145/96 | 23.3 s |
| 56 | I sell the smith the seven crystal beetle plates at four copper each for twenty-eight copper, and leave the breastplate on hold until I have… |  | open_run_level | Sell held surplus loot, defer armor purchase | smithy | 145/96 | 9.0 s |
| 57 | I sell you the seven crystal beetle plates, four copper each, and take the twenty-eight copper. | Engine (Menü/Rückfrage) | open_run_level | Sell plates for coin | smithy | 145/96 | 9.1 s |
| 58 | I sell the seven plates from the earlier haul, the enc_t37 ones, at four copper each. | Erzähler | open_run_level | Sell surplus chitin for coin | smithy | 145/96 | 19.9 s |
| 59 | I sell you the fourteen newer crystal beetle plates, the enc_t40 ones, at four copper each, and put the fifty-six copper credit toward the f… | Engine (Menü/Rückfrage) | open_run_level | Sell remaining chitin, credit toward breastplate | smithy | 145/96 | 17.6 s |
| 60 | I sell the smith my fourteen crystal beetle plates, the enc_t40 ones, at four copper each — fifty-six copper credit — and buy the fine F-Ran… | Engine (Menü/Rückfrage) | open_run_level | Sell remaining chitin and buy the breastplate | smithy | 145/96 | 12.1 s |
| 61 | I sell fourteen crystal beetle plates to the smith at four copper each, fifty-six copper in total. | Engine (Menü/Rückfrage) | open_run_level | Complete the chitin sale as one clear transaction, then buy the breastplate separately | smithy | 145/96 | 7.1 s |
| 62 | I accept the smith's standing bid: four copper per plate, fifty-six copper for all fourteen plates. (offer.t116.7) | Engine (Menü/Rückfrage) | open_run_level | Accept the confirmed offer to sell the chitin | smithy | 145/96 | 6.4 s |
| 63 | I sell the smith fourteen crystal beetle plates. He pays me fifty-six copper total. | Engine (Menü/Rückfrage) | open_run_level | Complete the plate sale | smithy | 145/96 | 7.9 s |
| 64 | Sell: I sell the goods crystal beetle plates, fourteen of them, to the smith here, at his bid of four copper each, total price fifty-six cop… | Engine (Menü/Rückfrage) | open_run_level | Complete the chitin sale with all four clarified fields | smithy | 145/96 | 7.1 s |
| 65 | I sell the fourteen plates the smith bid on, the 56 cp option. | Engine (Menü/Rückfrage) | open_run_level | Resolve the clarify loop by picking the offered option | smithy | 145/96 | 7.6 s |
| 66 | I sell the fourteen crystal beetle plates from the beetle chamber to the smith, at his bid of four copper each, fifty-six copper total. | Engine (Menü/Rückfrage) | open_run_level | Break the clarify loop with the chamber-specific wording | smithy | 145/96 | 5.8 s |
| 67 | Sell 14 crystal beetle plates to the smith for 56 copper total. | Engine (Menü/Rückfrage) | open_run_level | Break the trade clarify loop with terse four-field format | smithy | 145/96 | 5.8 s |
| 68 | I ask the smith here: "Do you buy crystal beetle plates, and at what price?" | Erzähler | open_run_level | Get a fresh confirmed offer to break the clarify loop | smithy | 145/96 | 23.7 s |
| 69 | Sell. Goods: 14 crystal beetle plates. Buyer: the smith here. Total: 56 copper to me. | Engine (Menü/Rückfrage) | open_run_level | Complete the plate sale with labeled fields | smithy | 145/96 | 6.9 s |
| 70 | I sell fourteen crystal beetle plates to the smith in the academy cleft smithy, and he pays me fifty-six copper total. | Engine (Menü/Rückfrage) | open_run_level | Complete the chitin sale in plain sentence form | smithy | 145/96 | 6.9 s |
| 71 | #bag | System (Befehl) | open_run_level | Check whether the plates are actually recorded in inventory | smithy | 145/96 | 2.4 s |
| 72 | I sell the stack of fourteen F-Rank Crystal Beetle Chitin Plates to the Smith here in the smithy; he gives me 56 copper total. | Engine (Menü/Rückfrage) | open_run_level | Complete the plate sale with exact stack name | smithy | 145/96 | 6.7 s |
| 73 | I sell. Goods: F-Rank Crystal Beetle Chitin Plate ×14. Buyer: the Smith present here. Total price: 56 copper paid to me. | Engine (Menü/Rückfrage) | open_run_level | Break the clarify loop by answering the four fields directly as a clarification | smithy | 145/96 | 8.7 s |
| 74 | I sell. Direction: I sell to the Mostly A Shoeing-And-Hinges Smith. Goods: F-Rank Crystal Beetle Chitin Plate ×14. Total price: 56 copper pa… | Engine (Menü/Rückfrage) | open_run_level | Sell the plate stack to the named smith | smithy | 145/96 | 6.9 s |
| 75 | I ask the Mostly A Shoeing-And-Hinges Smith what price he offers for fourteen F-Rank Crystal Beetle Chitin Plates. | Erzähler | open_run_level | Obtain an explicit merchant offer to break the clarify loop | smithy | 145/96 | 13.6 s |
| 76 | I empty the fourteen plates onto the rail and sell them to you at four copper each, for fifty-six copper. | Engine (Menü/Rückfrage) | open_run_level | Accept the smith's stated offer and complete the plate sale | smithy | 145/96 | 6.6 s |
| 77 | I accept 4 copper each, 56 copper total for the fourteen plates. | Engine (Menü/Rückfrage) | open_run_level | Resolve the CLARIFY by confirming the smith's per-plate offer | smithy | 145/96 | 6.6 s |
| 78 | I counter at 56 copper total, four per plate, and hand over the fourteen plates if he agrees. | Erzähler | open_run_level | Resolve the price CLARIFY by countering at 56 cp | smithy | 145/96 | 17.3 s |
| 79 | I accept his bid: 4 copper total for the fourteen plates, and hand the plates over. | Engine (Menü/Rückfrage) | open_run_level | Sell the plate stack at the engine-recorded offer price of 4 cp total | smithy | 145/96 | 6.4 s |
| 80 | I accept the 56 copper bid and hand over the fourteen plates. | Erzähler | open_run_level | Complete the plate sale at the smith's 56 cp offer | smithy | 145/96 | 15.7 s |
| 81 | I buy the fine F-Rank breastplate for 72 copper and have it equipped. | Erzähler | open_run_level | Buy armour upgrade | smithy | 145/96 | 17.1 s |
| 82 | I ask the smith what he has for a better F-Rank longsword and what it would cost. | Erzähler | open_run_level | Check weapon upgrade options | smithy | 145/96 | 19.3 s |
| 83 | I leave the smithy and head to the Guild hall to look at the contract board. | Erzähler | open_run_level | Find a new Guild contract to earn coin for the fine longsword | Adventurers' Guild hall, Glassmere | 145/96 | 19.3 s |
| 84 | I ask the clerk what private work he knows of, since the board is bare. | Erzähler | open_run_level | Find paid work while the contract board is empty | Adventurers' Guild hall, Glassmere | 145/96 | 39.1 s |
| 85 | I ask the clerk to register me for The Adder by the Goose Pens contract and confirm it's active. | Erzähler | open_run_level | Accept the achievable level-1 adder contract for coin toward the fine longsword | Adventurers' Guild hall, Glassmere | 145/96 | 14.1 s |
| 86 | I tell Doran I'll walk with him as far as the Millpond fork, and head out with him toward the goose pens. | Erzähler | open_run_level | Travel with Doran toward the adder contract site | the Millpond goose pens | 145/96 | 26.3 s |
| 87 | I tell the keeper the Guild sent me about the adder, and ask where the flock won't graze. | Erzähler | open_run_level | Confirm the adder's location with Ansel | the Millpond goose pens | 145/96 | 15.1 s |
| 88 | I lift the latch, come through the gate, and close it behind me, then move carefully toward the flat stones by the water trough with my long… | Erzähler | open_run_level | Enter the pens and approach the adder's basking spot | the flat stones by the water trough | 145/96 | 22.2 s |
| 89 | I strike at the adder with my longsword as it draws back to strike. | Erzähler | open_run_level | Attack the adder for the contract | the flat stones by the water trough | 145/96 | 14.9 s |
| 90 | I step into ENGAGED range and slash at the adder with my longsword as it strikes at me. | Erzähler | open_run_level | Close to range and attack the adder | the flat stones by the water trough | 145/96 | 19.1 s |
| 91 | I tell Wat I'll come along and see Ansel now, showing him the adder skin and fangs as proof. | Erzähler | open_run_level | Deliver adder proof to Ansel for the contract reward | the flat stones by the water trough | 145/96 | 20.9 s |
| 92 | I thank Ansel and head back to the Guild office in Asterford to turn in the adder contract. | Erzähler | open_run_level | Return to Guild hall to turn in the adder contract | Guild office in Asterford | 145/96 | 23.1 s |
| 93 | I take the thirty-five copper and leave the slip, then go over to the board to look at the available contracts. | Erzähler | open_run_level | Collect reward and check the board | Guild office in Asterford, Asterford | 145/96 | 19.2 s |
| 94 | I ask the clerk about the widow's cellar rats — where she lives and what she's paying. | Erzähler | open_run_level | Take the private rat-clearing work while in town | Guild office in Asterford, Asterford | 145/96 | 17.5 s |
| 95 | I head to Cordwainer Row, find the blue door third past the well, and knock, telling Marda the Guild office sent me about her rats. | Erzähler | open_run_level | Take the widow's rat job | Cordwainer Row | 145/96 | 19.6 s |
| 96 | I accept the job and head down into the cellar with my lantern lit, sword ready, watching for rats near the stores. | Erzähler | open_run_level | Clear Marda's cellar rats | Marda's cellar | 145/96 | 20.9 s |
| 97 | I move toward the cask where the scratching came from and swing my sword at the rat behind it, keeping my swings low and away from the sacks… | Engine (Menü/Rückfrage) | open_run_level | Kill the cellar rats | Marda's cellar | 145/96 | 6.7 s |
| 98 | I crouch by the chewed sacks and scatter a handful of spilled grain into the open floor, then step back with my sword ready to see what come… | Erzähler | open_run_level | Draw the rats into the open so they become targetable | Marda's cellar | 145/96 | 17.1 s |
| 99 | I step in and use Cleave on the cluster of rats feeding at the grain, keeping my swings low and away from the sacks. | Erzähler | open_run_level | AoE on the five grouped rats | Marda's cellar | 145/96 | 16.1 s |
| 100 | I swing my sword at Brown Rat A, the biggest one behind the cask, keeping my swing low. | Erzähler | open_run_level | Engage and kill the rats one at a time with Basic Attack | Marda's cellar | 145/96 | 18.1 s |
| 101 | #assign STR 2 VIT 3 | System (Befehl) | open_run_level | Spend level-up points before continuing the cellar job | Marda's cellar | 145/96 | 2.6 s |
| 102 | I call up to Marda that the big one is dead, then take my lantern toward the drain-grate where the others fled and look for signs of the rem… | Erzähler | open_run_level | Continue the cellar rat job | Marda's cellar | 145/96 | 23.8 s |
| 103 | I climb out of the cellar and go around to the alley behind Marda's, then search along the drain channel and sill hole for the remaining rat… | Erzähler | open_run_level | Track the fled rats from outside | alley behind Marda's | 145/96 | 20.5 s |
| 104 | I crouch by the sill hole and peer into the drain channel with the lantern, looking for the remaining rats. | Erzähler | open_run_level | Search the drain route now that arrival is complete | alley behind Marda's | 145/96 | 24.2 s |
| 105 | I call back to Marda that I've found two rats in the board heap, then step up and swing my sword at Alley Rat A. | Erzähler | open_run_level | Engage the alley rats one at a time | alley behind Marda's | 145/96 | 18.9 s |
| 106 | I stride up to the board heap to engage Alley Rat A, then swing my sword at it. | Erzähler | open_run_level | Close to SHORT range and attack Alley Rat A | alley behind Marda's | 144/96 | 16.8 s |
| 107 | I kick the rat off my boot and swing my sword at Alley Rat B. | Erzähler | open_run_level | Finish the last visible alley rat | alley behind Marda's | 144/96 | 20.8 s |
| 108 | I tell Marda both alley rats are dead and ask whether the job's count is done or if she still hears rats under her floor. | Erzähler | open_run_level | Confirm the rat job is complete and turn in | alley behind Marda's | 144/96 | 17.4 s |
| 109 | I follow Marda inside, wipe my boots, and ask for my payment for the rat job. | Erzähler | open_run_level | Collect rat job payment from Marda | Marda's cellar | 144/96 | 20.1 s |
| 110 | I thank Marda, finish the bread, and head two lanes over to the widow Gell's house to offer clearing the rats in her walls. | Erzähler | open_run_level | Follow the rat-work lead to the widow Gell | widow Gell's house | 144/96 | 21.3 s |
| 111 | I step inside and put my ear to the kitchen wall to listen for the scratching and smell she mentioned. | Erzähler | open_run_level | Investigate the widow Gell's rat problem | widow Gell's house | 144/96 | 20.8 s |
| 112 | I tell the widow I'll return after dark to listen, and head to the Guild hall to turn in The Adder by the Goose Pens. | Erzähler | open_run_level | Turn in completed Guild contract, then wait for dark | Guild office in Asterford, Asterford | 144/96 | 22.6 s |
| 113 | I tell the clerk that's all for now, and head to a blacksmith or armourer in Asterford to compare weapon and armour upgrades. | Erzähler | open_run_level | Gear check at a smith before evening rat work | smithy in Asterford | 144/96 | 22.6 s |
| 114 | I tell the smith I can't afford any of those today and leave. I return to the widow Gell's house as the sun goes down to listen for the scra… | Erzähler | open_run_level | Skip unaffordable gear, do the evening rat job | widow Gell's house | 144/96 | 19.9 s |
| 115 | I ask the widow for permission to open a hole in the kitchen wall at the corner where the scratching moved, so I can get at the nest directl… | Erzähler | open_run_level | Get at the rat nest in the wall | widow Gell's house | 144/96 | 18.0 s |
| 116 | I warn the widow to move the crockery, then strike a careful hole in the plaster low in the corner, clear of the beam, to open up the nest. | Erzähler | open_run_level | Open the wall and get at the rat nest | widow Gell's house | 144/96 | 20.4 s |
| 117 | I draw my sword and strike at the adder through the hole in the wall. | Erzähler | open_run_level | Attack the adder emerging from the nest | widow Gell's house | 144/96 | 18.6 s |
| 118 | I tell the widow the adder was the worst of it, but two rats fled deeper into the house—I'll hunt them down before they settle in again. I l… | Erzähler | open_run_level | Finish the rat job by tracking the two fleeing rats | widow Gell's pantry | 144/96 | 22.6 s |
| 119 | I ask the widow to step back, then strike a hole in the pantry wall where the dimple moves, and attack the rat behind it as it breaks cover. | Engine (Menü/Rückfrage) | open_run_level | Hunt the rats in the pantry wall | widow Gell's pantry | 144/96 | 7.4 s |
| 120 | I strike a hole in the pantry wall where the dimple moves, then attack Rat A as it breaks cover. | Erzähler | open_run_level | Break the rats' cover and attack Rat A | widow Gell's pantry | 144/96 | 20.0 s |
| 121 | I strike at Rat A, cornered between the crock and the wall at the shelf's end. | Erzähler | open_run_level | Kill Rat A while it is cornered | widow Gell's pantry | 143/96 | 18.2 s |
| 122 | I finish the job with a Basic Attack on Rat B at my feet. | Erzähler | open_run_level | Kill the last rat | widow Gell's pantry | 143/96 | 17.8 s |
| 123 | I let the widow look at the bite, then ask when I can collect the pay for clearing the rats and the adder. | Erzähler | open_run_level | Wrap up the rat job and payment | widow Gell's pantry | 143/96 | 21.4 s |
| 124 | I thank the widow, pocket the coins, and head for the Guild hall in Asterford to see the contract board for my next job. | Erzähler | open_run_level | Leave the rat job done and pick a new Guild contract | Guild office in Asterford, Asterford | 143/96 | 31.2 s |
| 125 | I take the Marsh Cat at the Granary Row slip to the clerk and ask her to register it for me. | Erzähler | open_run_level | Accept a new Guild contract | Guild office in Asterford, Asterford | 143/96 | 15.8 s |
| 126 | I head south to granary row and hunt the marsh cat there. | Erzähler | open_run_level | Travel to granary row and kill the marsh cat | the granary row of Asterford | 143/96 | 20.7 s |
| 127 | I push through the half-off side door of the second shed and go in after the marsh cat with my longsword ready. | Erzähler | open_run_level | Hunt the marsh cat inside the shed | inside the second granary shed | 142/96 | 19.4 s |
| 128 | I strike the marsh cat with a Basic Attack. | Erzähler | open_run_level | Kill the marsh cat for the contract | inside the second granary shed | 142/96 | 15.2 s |
| 129 | I head back to the Guild hall in Caelreth and turn in the Marsh Cat at the Granary Row contract for my 35 coppers. | Erzähler | open_run_level | Turn in the completed marsh cat contract | Guild office in Asterford, Asterford | 142/96 | 18.3 s |
| 130 | #assign STR 2 VIT 2 AGI 1 | System (Befehl) | open_run_level | Spend 5 free stat points from Level 7 | Guild office in Asterford, Asterford | 142/96 | 2.7 s |
| 131 | I ask the widow if there's a smith in Asterford still open at this hour, or where I should go first thing in the morning. | Erzähler | open_run_level | Find a smith for gear upgrade | Guild office in Asterford, Asterford | 142/96 | 16.7 s |
| 132 | I thank her and head to the tavern to ask for a room for the night and someone to bind my arm. | Erzähler | open_run_level | Get lodging and recover overnight | the tavern | 142/96 | 37.8 s |
| 133 | I pay the 8 copper for the room and 2 copper for supper. | Erzähler | open_run_level | Buy lodging and supper | the tavern | 142/96 | 25.3 s |
| 134 | I go up to the room, bind my arm with the clean linen, and sleep until morning. | Erzähler | open_run_level | Recover overnight | common room, morning | 142/96 | 27.4 s |
| 135 | I head to Bram's forge to check what weapons and armour he has for sale. | Erzähler | open_run_level | Gear check at the smith | smithy in Asterford | 142/96 | 22.4 s |
| 136 | I thank Bram and tell him I'll hold off for now—nothing beats my current gear for the coin I'm carrying—then head to the Guild hall to sell … | Erzähler | open_run_level | Skip unaffordable gear, sell loot, find work | Guild office in Asterford, Asterford | 142/96 | 29.5 s |
| 137 | I offer the Quartz Ooze Core for sale at the desk, then ask to accept the 'Thin the Bog Striders at the Weirs' contract. | Erzähler | open_run_level | Sell core and take a Guild contract | Guild office in Asterford, Asterford | 142/96 | 24.6 s |
| 138 | Yes, I accept three silver for the core. With the deal done, I set off south and west along the Millpond road toward the Reed Flats eel-weir… | Erzähler | open_run_level | Sell core, travel to strider hunt | causeway across the Reed Flats | 142/96 | 28.6 s |
| 139 | I draw my longsword and charge the bog strider, aiming a Basic Attack at its forelimb joint before it can fully unfold. | Erzähler | open_run_level | Engage the first bog strider with a single-target attack | causeway across the Reed Flats | 142/96 | 18.7 s |
| 140 | I keep charging, closing the gap to ENGAGED range, then swing a Basic Attack at the nearest leg joint. | Erzähler | open_run_level | Close distance and attack with declared movement | causeway across the Reed Flats | 142/96 | 18.0 s |
| 141 | I close the last of the gap and swing a Basic Attack at the nearest forelimb joint. | Erzähler | open_run_level | Engage the bog strider at close range | causeway across the Reed Flats | 142/96 | 20.9 s |
| 142 | I retreat back down the causeway toward the Millpond road, keeping my sword up, trying to draw the strider away from the reeds before more c… | Erzähler | open_run_level | Disengage to avoid being surrounded by the answering striders | causeway across the Reed Flats | 142/96 | 22.4 s |
| 143 | I back away up the slope onto the Millpond road, leaving the strider behind, then sit down on the bank to eat my porridge portion and rest u… | Erzähler | open_run_level | Break off the fight and recover STA before deciding next steps | Millpond road | 142/96 | 26.3 s |
| 144 | I walk north along the Millpond road into Millpond and look for a blacksmith to check weapon and armour upgrades. | Erzähler | open_run_level | Gear check in settlement | Millpond | 142/96 | 29.2 s |
| 145 | I approach the smith at his anvil and ask what he has in the way of a better longsword and armour for a warrior. | Erzähler | open_run_level | Check weapon and armour upgrades at the smithy | Millpond smithy | 142/96 | 21.5 s |
| 146 | "That's beyond my purse today, Osric. Instead—would you buy these F-Rank crystal beetle chitin plates off me? I've seven of them." | Erzähler | open_run_level | Sell surplus loot to fund gear | Millpond smithy | 142/96 | 20.2 s |
| 147 | "All seven are clean and whole. Deal at fifty-six copper the lot. I'll take the fourteen-silver longsword too, if the sale covers it." | Erzähler | open_run_level | Accept the confirmed offer for the chitin plates and buy the affordable longsword upgrade | Millpond smithy | 142/96 | 31.7 s |
| 148 | I take the new longsword from Osric and pay him fourteen silver for it, confirming the sale and purchase are both booked. | Erzähler | open_run_level | Complete the chitin sale and longsword purchase despite the engine refusal | Millpond smithy | 142/96 | 22.9 s |
| 149 | I wait at the smithy counter for Osric to return, keeping the coins ready to complete the sale and the sword purchase the moment he's back. | Erzähler | open_run_level | Wait for the smith to return and complete the sale and purchase | Millpond smithy | 142/96 | 24.2 s |
| 150 | Osric, the bargain stands: here are fourteen silver for the Harrow longsword — I hand you the coins and take the blade now. And book the sev… | Erzähler | open_run_level | Re-perform the sale and sword purchase with Osric explicitly present | Millpond smithy | 142/96 | 19.2 s |
| 151 | Osric is away again, so I leave the smithy and walk to Marda's house for the bread and drippings she offered, and to collect my payment for … | Erzähler | open_run_level | Stop looping on the absent smith; collect rat-job payment and recover at Marda's | Marda's house | 142/96 | 24.2 s |
| 152 | I step inside, take the three coppers from Marda's hand, and accept the bread and drippings she set aside for me. |  | open_run_level | Collect rat-job payment and food from Marda | Marda's house | 142/96 | 8.5 s |
| 153 | I take the three copper coins Marda holds out and thank her for the bread and drippings. | Erzähler | open_run_level | Collect rat-job payment and food from Marda | Marda's house | 142/96 | 18.1 s |
| 154 | "Aye, Guild-signed, Novice rank with the Hall at Asterford," I say, settling on the stool. "The mail came from beetle chitin and hard walkin… | Erzähler | open_run_level | Talk with Marda and gather local info | Marda's house | 142/96 | 21.4 s |
| 155 | I accept the butter and eat some of the warm bread, then thank Marda and head for Dagny's corner house by the rope-walk to ask where the str… | Erzähler | open_run_level | Gather intel from Dagny, then head to the weirs | corner house by the rope-walk | 142/96 | 24.4 s |
| 156 | I step inside with Dagny and ask her where the bog striders are thick. | Erzähler | open_run_level | Get strider location intel from Dagny | corner house by the rope-walk | 142/96 | 25.1 s |
| 157 | I thank Dagny for the guidance, eat my porridge portion to get my strength back, then set out along the gravel path from the drying sheds to… | Erzähler | open_run_level | Recover STA with food, then travel to the third weir to meet Tam | corner house by the rope-walk | 142/96 | 32.4 s |
| 158 | I draw my longsword and advance on the strider in the shallows, keeping to the open gravel where Dagny said it can't run me down, and strike… | Engine (Menü/Rückfrage) | open_run_level | Engage the first bog strider on open ground | corner house by the rope-walk | 142/96 | 9.2 s |
| 159 | The path can wait until I've slept — I ask Dagny if I can bed down by her fire until morning, since I'm worn and wounded and mean to hunt st… | Erzähler | open_run_level | Recover HP/STA overnight before the weir hunt | corner house by the rope-walk | 142/96 | 25.4 s |
| 160 | I settle onto the pull-out settle and sleep through until dawn. | Erzähler | open_run_level | Recover HP and STA overnight | corner house by the rope-walk | 220/96 | 16.5 s |
| 161 | I eat the porridge, thank Dagny, and set out for the third weir, calling out well before I reach the planks so Tam knows it's a friend comin… | Erzähler | open_run_level | Travel to the third weir and meet Tam without getting speared | the eel-weirs of the Reed Flats | 220/96 | 33.5 s |
| 162 | I keep my hands out where Tam can see them and say, "Dagny said you'd have work worth coin — I'm here to hunt the bog striders plaguing your… | Erzähler | open_run_level | Confirm the strider hunt with Tam and get his guidance on where they are | the eel-weirs of the Reed Flats | 220/96 | 44.9 s |
| 163 | I accept Tam's offer — a silver a head, five if I can manage them — and ask him to point out where the big dark-legged one went into the sou… | Erzähler | open_run_level | Confirm the bounty and start the strider hunt | south reeds run | 220/96 | 25.4 s |
| 164 | I draw my longsword and follow the fresh tracks into the reed run, watching for the big dark-legged strider. | Erzähler | open_run_level | Hunt the old strider in its reed run | strider run and black pool | 210/96 | 27.1 s |
| 165 | I strike with Quick Slash at the strider as it comes at me. | Erzähler | open_run_level | Attack the bog strider with Quick Slash | strider run and black pool | 210/96 | 14.8 s |
| 166 | I finish it with a Basic Attack at the wounded strider. | Erzähler | open_run_level | Kill the bog strider | strider run and black pool | 210/96 | 15.2 s |
| 167 | I cut loose what's usable from the strider, then follow the gravel bank south toward the fourth weir to hunt the next strider. | Erzähler | open_run_level | Continue the strider hunt toward the fourth weir | the fourth weir | 210/96 | 30.8 s |
| 168 | I circle along the bankside willows, staying downwind, and strike the feeding strider on the walkway with Quick Slash. | Erzähler | open_run_level | Ambush the feeding strider at the fourth weir | the fourth weir | 210/96 | 21.1 s |
| 169 | I strike the feeding strider on the walkway with Quick Slash, ready to back off fast if the big one under the planks surges up at me. | Erzähler | open_run_level | Ambush the feeding strider, wary of the mother | the fourth weir | 210/96 | 19.8 s |
| 170 | I wade the ten paces of shallow channel toward the strider on the walkway, sword up, keeping my eyes on the water near the planks' near end … | Erzähler | open_run_level | Close into ENGAGED range with Bog Strider C | the fourth weir | 209/96 | 20.5 s |
| 171 | I strike Bog Strider C with Quick Slash while it's lunging at me. | Erzähler | open_run_level | Kill the strider before the mother joins | the fourth weir | 209/96 | 26.1 s |
| 172 | #assign STR 2 VIT 3 | System (Befehl) | open_run_level | Spend level-up points on STR and VIT | the fourth weir | 209/96 | 3.1 s |
| 173 | I collect the three chitin plates and the venom gland from the shallows, then back away from the walkway without threatening the mother, and… | Erzähler | open_run_level | Loot the kill, avoid the mother, continue the 5-strider contract | the fifth weir and the tussock hummock | 209/96 | 25.2 s |
| 174 | I approach the hummock cautiously, sword ready, and strike the first strider that emerges with Quick Slash. | Erzähler | open_run_level | Continue the 5-strider hunt at the den | the tussock hummock | 208/96 | 23.6 s |
| 175 | I strike Bog Strider E again with Quick Slash before it can recover from the lunge. | Erzähler | open_run_level | Kill the young strider, then handle the bigger one | the tussock hummock | 208/96 | 20.1 s |
| 176 | I follow the beaten swath of tracks past the hummock toward the wider channel, looking for more striders. | Erzähler | open_run_level | Continue the 5-strider hunt | the wider channel weir | 208/96 | 22.8 s |
| 177 | I strike the lone strider in the shallows with Quick Slash from the spoil bank, picking the isolated one so no others are in reach of the bl… | Engine (Menü/Rückfrage) | open_run_level | Continue the strider hunt on a solo target | the wider channel weir | 208/96 | 5.4 s |
| 178 | I strike Bog Strider D with Quick Slash before it can raise the alarm. | Erzähler | open_run_level | Attack the confirmed active target | the wider channel weir | 208/96 | 18.0 s |
| 179 | I cross the dozen paces of open sandbar toward Bog Strider D, moving low and quick to reach it before it lifts its head, then strike with Qu… | Erzähler | open_run_level | Close to ENGAGED range on the isolated strider and attack | the wider channel weir | 208/96 | 16.8 s |
| 180 | I strike Bog Strider D with Quick Slash while it is still unaware. | Erzähler | open_run_level | Kill the engaged strider | the wider channel weir | 208/96 | 18.5 s |
| 181 | I creep along the sandbar toward the nearest feeding worker strider, staying low, and strike with Quick Slash once in reach. | Erzähler | open_run_level | Ambush a fifth strider to finish the contract count | the wider channel weir | 208/96 | 31.4 s |
| 182 | I finish the wounded worker first: strike Bog Strider G with Quick Slash, keeping my footing so the big one on the timber run can't flank me… | Erzähler | open_run_level | Defeat engaged strider G, then close the contract count | the wider channel weir | 208/96 | 28.9 s |
| 183 | I meet the nearer approaching worker, Bog Strider F, and strike it with Quick Slash, keeping my back to the water so the old one can't flank… | Engine (Menü/Rückfrage) | open_run_level | Kill the fifth strider to complete the contract count | the wider channel weir | 208/96 | 6.2 s |
| 184 | I close to SHORT range on Bog Strider F and strike it with Quick Slash. | Erzähler | open_run_level | Kill the fifth strider to complete the contract count | the wider channel weir | 202/96 | 18.9 s |
| 185 | I strike Bog Strider F again with Quick Slash to finish it. | Erzähler | open_run_level | Kill the fifth strider to complete the contract count | the wider channel weir | 202/96 | 17.3 s |
| 186 | #assign STR 3 VIT 2 | System (Befehl) | open_run_level | Spend level-up points on offensive stats | the wider channel weir | 202/96 | 3.1 s |
| 187 | With the contract count at 5/5, I back away from the mother strider without provoking her and head back toward town to turn in the contract … |  | open_run_level | Turn in completed strider contract | the wider channel weir | 202/96 | 9.5 s |
| 188 | I walk back along the channel toward Caelreth, keeping clear of the mother strider on the walkway. | Erzähler | open_run_level | Return to town to turn in the strider contract | Adventurers' Guild hall, Glassmere | 202/96 | 25.3 s |
| 189 | "All five bog striders at the weirs are dead. I'd like to turn in the contract — Thin the Bog Striders." | Erzähler | open_run_level | Turn in the completed strider contract at the Guild desk | Adventurers' Guild hall, Glassmere | 202/96 | 18.4 s |
| 190 | I take my strider plates to the brokerage counter and ask what they'll pay for the lot. | Erzähler | open_run_level | Sell surplus loot before checking gear | Adventurers' Guild hall, Glassmere | 202/96 | 23.8 s |
| 191 | I accept — sell all fifteen plates and four venom glands for the 150 copper. | Erzähler | open_run_level | Sell surplus loot at confirmed offer | Adventurers' Guild hall, Glassmere | 202/96 | 31.1 s |
| 192 | I ask the broker if she has any manuals or gear worth my coin, since the primers on the board are 80 copper each. | Erzähler | open_run_level | Check broker's shop before gear visit | Adventurers' Guild hall, Glassmere | 202/96 | 42.3 s |
| 193 | I ask the clerk where the smith or armourer can be found, then head over there to check weapon and armour prices. | Erzähler | open_run_level | Visit a smith for gear upgrade | Halloran's Forgework | 202/96 | 35.6 s |
| 194 | I'll take the fine longsword for 140 copper — that's 1 gold 4 silver. | Engine (Menü/Rückfrage) | open_run_level | Buy weapon upgrade at confirmed price | Halloran's Forgework | 202/96 | 8.3 s |
| 195 | The listed price, 140 copper, as shown. | Erzähler | open_run_level | Confirm the fine longsword purchase at the listed 140 cp | Halloran's Forgework | 202/96 | 18.9 s |
| 196 | I'll take the scabbard fitting for 20 copper, and I equip the fine longsword. | Erzähler | open_run_level | Buy scabbard and equip new weapon | Halloran's Forgework | 202/96 | 18.9 s |
| 197 | I head to the Guild hall and check the contract board for work suited to my rank. | Erzähler | open_run_level | Find a new Guild contract after gear upgrade | Adventurers' Guild hall, Glassmere | 202/96 | 16.9 s |
| 198 | I tell the clerk I'll take the Bog Striders contract at the Reed Flats eel-weirs, and ask her to record it as active. | Erzähler | open_run_level | Accept the 140 cp bog strider hunt | Adventurers' Guild hall, Glassmere | 202/96 | 15.6 s |
| 199 | I leave the Guild hall and travel along the marsh road to the Reed Flats eel-weirs. | Erzähler | open_run_level | Travel to the active bog strider contract site | the eel-weirs of the Reed Flats | 202/96 | 20.6 s |
| 200 | I draw my fine longsword and advance along the weir fence toward the shallows where the jointed leg showed, watching for the strider. | Erzähler | open_run_level | Hunt the bog striders at the weirs | the shallows by the weir fence | 202/96 | 21.9 s |
| 201 | I step in along the weir fence and swing Cleave at the bog strider. | Erzähler | open_run_level | Fight the bog strider for the contract | the shallows by the weir fence | 202/96 | 16.4 s |
| 202 | I keep advancing along the weir fence until I'm engaged with the bog strider, then swing Cleave at it. | Erzähler | open_run_level | Close distance and attack the strider | the shallows by the weir fence | 202/96 | 14.2 s |
| 203 | I leave the fence and wade through the shallows straight at the strider to close the gap, then swing Cleave once I'm beside it. | Erzähler | open_run_level | Engage the strider by wading off the fence | the shallows by the weir fence | 202/96 | 15.6 s |
| 204 | I wade back to the weir fence and scan the shallows for the next bog strider. | Erzähler | open_run_level | Continue the 1/6 bog strider count | the shallows by the weir fence | 202/96 | 17.8 s |
| 205 | I move quietly along the fence toward the feeding strider, staying downwind, and swing Cleave as soon as I'm engaged with it. | Erzähler | open_run_level | Ambush the second bog strider while it feeds | the shallows by the weir fence | 202/96 | 19.5 s |
| 206 | I swing Cleave at the strider's thin foreleg joint. | Erzähler | open_run_level | Attack the engaged feeding strider | the shallows by the weir fence | 202/96 | 16.8 s |
| 207 | I scan the shallows along the weir for the next bog strider. | Erzähler | open_run_level | Continue the 2/6 bog strider count | the shallows by the weir fence | 202/96 | 18.1 s |
| 208 | I move along the fence upstream toward the sluice gap, using the rushing water to cover my approach, and swing Cleave at the strider's thin … | Erzähler | open_run_level | Ambush the third strider at the sluice gap | the shallows by the weir fence | 202/96 | 16.4 s |
| 209 | I leave the sluice strider on its stonework and work back along the fence, scanning the reed flats for another strider feeding in open shall… | Erzähler | open_run_level | Find an engageable strider instead of fighting one on the slick weir stones | the last weir baskets and stake platform | 202/96 | 20.0 s |
| 210 | I step out onto the stake platform and look down the length of the weir from higher up for another strider feeding in open shallows. | Erzähler | open_run_level | Use the platform vantage to find an engageable strider | the stake platform | 202/96 | 24.3 s |
| 211 | I step down from the platform and wade quietly toward the shallows where the jointed leg broke the water among the weir brush, closing to en… | Engine (Menü/Rückfrage) | open_run_level | Engage the lurking strider in the weir brush shallows | the stake platform | 202/96 | 8.6 s |
| 212 | I wade to the spot in the weir brush where the jointed leg broke the water and jab my sword into the reeds to drive the lurking creature out… | Engine (Menü/Rückfrage) | open_run_level | Provoke the lurking strider into an engageable fight | the stake platform | 202/96 | 6.8 s |
| 213 | I return to the walkway and attack the mother bog strider standing over the torn basket, swinging Cleave at her legs. | Erzähler | open_run_level | Engage the present mother strider instead of the untargetable lurking sign | the walkway | 202/96 | 24.0 s |
| 214 | I swing Cleave at the mother strider's forelegs as her scythes come into range. | Erzähler | open_run_level | Fight the engaged mother bog strider on the walkway | the walkway | 202/96 | 18.2 s |
| 215 | #assign STR 3 VIT 2 | System (Befehl) | open_run_level | Spend level-up stat points | the walkway | 202/96 | 3.3 s |
| 216 | I follow the bend of the weir toward the sluice where the third strider is fishing its gap, and engage it with Cleave once it's in reach. | Erzähler | open_run_level | Hunt the third strider to finish the 6-count contract | the sluice | 202/96 | 22.1 s |
| 217 | I press the attack, swinging Cleave at the young strider as it turns on the slick stones. | Erzähler | open_run_level | Defeat Bog Strider L for the 6-count contract | the sluice | 202/96 | 17.3 s |
| 218 | I return along the weir toward the reed flats and attack the fifth bog strider I find there with Cleave. | Erzähler | open_run_level | Continue the 6-count strider contract | the eel-weirs of the Reed Flats | 202/96 | 30.0 s |
| 219 | I slip back along the walkway out of their sightline and leave the flats for the village — I'm too spent to fight two more now. Once there, … | Erzähler | open_run_level | Disengage safely, sell loot, recover overnight | Millpond | 202/96 | 34.4 s |
| 220 | I have seven sound chitin plates and one venom gland — I'll take your two copper a plate and three silver for the gland. |  | open_run_level | Sell chitin plates and venom gland to the buyer | Millpond | 202/96 | 8.2 s |
| 221 | I sell seven sound chitin plates at two copper each and one venom gland at three silver. | Erzähler | open_run_level | Sell chitin plates and venom gland to the buyer | Millpond | 202/96 | 35.3 s |
| 222 | I head out into the morning street and look for a blacksmith or armourer in Millpond to compare gear against my longsword and breastplate. | Erzähler | open_run_level | Check gear at a smith before returning to the strider contract | Millpond smithy | 202/96 | 21.1 s |
| 223 | I'll take both repairs — dress the edge and fit the new strap and rivet. | Erzähler | open_run_level | Pay 6 copper for sword dressing and breastplate strap repair | Millpond smithy | 202/96 | 18.3 s |
| 224 | I hand Osric six copper for the edge dressing and the new strap and rivet, as he quoted. | Erzähler | open_run_level | Re-book the repairs as an explicit purchase at the stated price | Millpond smithy | 202/96 | 18.2 s |
| 225 | I wait by the workbench for Osric to return, then pay him six copper for the edge dressing and the new strap and rivet. | Erzähler | open_run_level | Complete the smith repairs once Osric is present | Millpond smithy | 202/96 | 19.4 s |
| 226 | I hand Osric six copper for the edge dressing and the new strap and rivet, settling for the work as he asked. | Erzähler | open_run_level | Pay Osric for the completed repairs | Millpond smithy | 202/96 | 16.5 s |
| 227 | #assign VIT 3 STR 2 | System (Befehl) | open_run_level | Spend free stat points before resting | Millpond smithy | 202/96 | 3.4 s |
| 228 | I leave the smithy and head back toward the Reed Flats eel-weirs to finish the bog strider contract. | Erzähler | open_run_level | Return to the strider hunt | the eel-weirs of the Reed Flats | 202/96 | 20.6 s |
| 229 | I take the boardwalk left toward the second weir, sword drawn, lantern held low, and engage the bog strider there. | Erzähler | open_run_level | Hunt bog striders to finish the 3/6 contract | the second weir | 202/96 | 24.0 s |
| 230 | I strike at the bog strider with my longsword. | Erzähler | open_run_level | Kill bog strider O toward the 6-count contract | the second weir | 202/96 | 14.6 s |
| 231 | I close to ENGAGED range and strike the bog strider with my longsword. | Erzähler | open_run_level | Close distance and attack the strider | the second weir | 202/96 | 15.9 s |
| 232 | I press on toward the third weir along the long reach, sword ready, hunting the fifth bog strider. | Erzähler | open_run_level | Continue the strider hunt (5/6) | the third weir | 202/96 | 22.0 s |
| 233 | I ready my stance and strike the approaching bog strider with my longsword. | Erzähler | open_run_level | Fight the fifth strider at ENGAGED range | the third weir | 202/96 | 15.9 s |
| 234 | I hold my ground at ENGAGED reach and strike Bog Strider P the moment it steps in. | Erzähler | open_run_level | Attack the strider once it is in range | the third weir | 202/96 | 12.7 s |
| 235 | I step forward into ENGAGED range and strike Bog Strider P with my longsword. | Erzähler | open_run_level | Close to range and attack the strider | the third weir | 202/96 | 17.1 s |
| 236 | I press on toward the dark reed hut past the third weir, sword ready, hunting the sixth and final bog strider. | Erzähler | open_run_level | Hunt the sixth strider toward the 6-count contract | the dark reed hut past the third weir | 202/96 | 32.4 s |
| 237 | I step into ENGAGED range and strike Bog Strider Q as it comes through the breach. | Erzähler | open_run_level | Fight the sixth and final strider | the dark reed hut past the third weir | 202/96 | 22.8 s |
| 238 | #assign STR 3 VIT 2 | System (Befehl) | open_run_level | Spend level-up stat points | the dark reed hut past the third weir | 202/96 | 3.3 s |
| 239 | I head back along the walkway toward Asterhall to turn in the completed strider contract at the Guild hall. | Erzähler | open_run_level | Turn in the 6/6 contract and recover | Adventurers' Guild hall, Asterhall | 202/96 | 24.9 s |
| 240 | "Just the bed for now. Is there lodging nearby I can reach at this hour?" | Erzähler | open_run_level | Recover overnight, then check a smith at dawn | Adventurers' Guild hall, Asterhall | 202/96 | 22.4 s |
| 241 | I drop two copper in the coin-box, take the cot, and sleep until morning. | Erzähler | open_run_level | Sleep overnight to recover HP and STA | Adventurers' Guild hall, Asterhall | 315/96 | 16.6 s |
| 242 | I return the brass key and reclaim my gear from stall four, then ask the clerk which smiths in Asterhall are open this morning. | Erzähler | open_run_level | Recover gear and find a smith for the pending gear check | Adventurers' Guild hall, Asterhall | 315/96 | 20.2 s |
| 243 | "Buying. I'll try Harlun's Forge on Anvil Row for armour first." I head to Harlun's Forge and, on arrival, ask what armour upgrades he has f… | Erzähler | open_run_level | Gear check: armour at Harlun's Forge | Harlun's Forge | 315/96 | 28.8 s |
| 244 | "I'll take the superior heavy armor for 88 copper, as confirmed — I have 2 gold 3 silver 6 copper, that's within my limit." | Erzähler | open_run_level | Buy superior F-Rank heavy armor at Harlun's Forge | Harlun's Forge | 315/96 | 16.6 s |
| 245 | I sit on the fitting stool, put on the new heavy armor, and let Harlun adjust the straps. Once it's fitted, I equip it and offer him my seve… | Erzähler | open_run_level | Fit and equip the new armor, then sell surplus chitin | Harlun's Forge | 315/96 | 22.9 s |
| 246 | "Credit them toward a better longsword, then — something heavier than the fine blade I'm carrying. What are the seven plates worth against t… | Erzähler | open_run_level | Price chitin as trade credit toward a weapon upgrade | Harlun's Forge | 315/96 | 28.8 s |
| 247 | I shake my head. "The commission's beyond my coin this morning, and even the superior at the confirmed 260 copper is more than I'm carrying.… | Erzähler | open_run_level | Decline unaffordable weapon upgrade and collect rat-job payment from Marda | the Saddle and Cart | 315/96 | 27.6 s |
| 248 | "Is Marda around? I was told she'd have payment ready here for a rat job I did for her." | Erzähler | open_run_level | Ask the innkeeper about Marda's rat-job payment | the Saddle and Cart | 315/96 | 20.5 s |
| 249 | I take the bench by the window and wait for Corvin to come down; when he arrives, I ask whether Marda left coin or word for me about a rat j… | Erzähler | open_run_level | Wait for Corvin and ask about Marda's payment | the Saddle and Cart | 315/96 | 20.8 s |
| 250 | I thank Corvin and head up past the well to find Marda's lodging near the chandler's blue door; if I find the house, I knock and ask her abo… | Erzähler | open_run_level | Track down Marda for the rumored rat-job payment | Marda's lodging past the well | 315/96 | 36.6 s |
| 251 | "No debt and no side jobs — I'll take my pay in coin when you have it, Marda. For now I'm off to the Guild to find proper work." | Erzähler | open_run_level | Settle the Marda lead and return to Guild contracts | Adventurers' Guild hall, Asterhall | 315/96 | 22.9 s |
| 252 | I walk to the noticeboard and read the posted contracts. | Erzähler | open_run_level | Find a Guild contract | Adventurers' Guild hall, Asterhall | 315/96 | 22.1 s |
| 253 | I take the Marsh Adder and Marsh Cat papers to the clerk. "I'll accept both of these, please — the adder at the Millpond goose pens and the … | Erzähler | open_run_level | Accept two achievable Novice contracts | Adventurers' Guild hall, Asterhall | 315/96 | 20.2 s |
| 254 | I head out of the Guild hall toward Granary Row in the low town to hunt the marsh cat first, since it's in Asterford itself. | Erzähler | open_run_level | Hunt the marsh cat on Granary Row | the granary row of Asterford | 315/96 | 23.0 s |
| 255 | I ask the scoop-man to point me to the second shed, then slip in through the half-off side door quietly with my longsword ready to hunt the … | Erzähler | open_run_level | Hunt the marsh cat in the second granary shed | the granary row of Asterford | 315/96 | 18.9 s |
| 256 | I move slowly down the lane between the grain stacks toward the musky rear corner, sword ready, and peer into the darkness behind the torn s… | Erzähler | open_run_level | Hunt the marsh cat in its den | musky rear corner | 315/96 | 22.6 s |
| 257 | I swing my longsword at the marsh cat crouched behind the torn sack. | Erzähler | open_run_level | Attack the marsh cat | musky rear corner | 315/96 | 19.2 s |
| 258 | I step forward to close the distance and swing my longsword at the marsh cat, spilling grain be damned. | Erzähler | open_run_level | Close to ENGAGED and attack the marsh cat | musky rear corner | 315/96 | 20.0 s |
| 259 | With the cat down, I head back to the Guild hall to turn in the Marsh Cat on Granary Row contract. | Erzähler | open_run_level | Turn in the completed marsh cat contract | Guild office in Asterford, Asterford | 315/96 | 20.4 s |
| 260 | I leave the Guild office and head to the goose pens to hunt the marsh adder. | Erzähler | open_run_level | Hunt the marsh adder for the active contract | the Millpond goose pens | 315/96 | 20.3 s |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 6 (notiert vor Zug 7): No sealed Novice contracts at the Guild yet; academy cull work at Glimmerdeep is the available opportunity.
- zu Zug 26 (notiert vor Zug 27): Narrator says the shard sale is done but HUD still shows the shard and 2 Silver; will verify coins/inventory after this sale.
- zu Zug 28 (notiert vor Zug 29): Engine paid 34 copper but HUD shows 5S4C and still lists the crystal shard; time says 14:47 while narration implied midnight.
- zu Zug 29 (notiert vor Zug 30): Narrator paid 10 silver for the shard, but HUD still shows 5S4C and lists the shard as carried.
- zu Zug 30 (notiert vor Zug 31): Audit rejected world reports on inventory and coin evidence; the ten-silver shard payment may not be engine-settled despite the narration.
- zu Zug 31 (notiert vor Zug 32): Audit rejects sale summaries without an accepted matching bid; the ten-silver payment was never engine-settled despite narration.
- zu Zug 32 (notiert vor Zug 33): Narrator claims payment again but HUD may still show shard and 5S4C; checking once, then moving on if unsettled.
- zu Zug 33 (notiert vor Zug 34): Shard still in bag and coins still 5S4C after a third explicit acceptance — engine never settled the ten-silver sale; noting it and moving on.
- zu Zug 35 (notiert vor Zug 36): Recovery confirmed: full HP/MP/STA after the night. Still holding the unsellable crystal shard.
- zu Zug 44 (notiert vor Zug 45): Cleave refused: no valid engaged target after declared movement; must close the gap first.
- zu Zug 50 (notiert vor Zug 51): Tam short 7 copper, will pay full 50 this evening; culvert clearing job and Doss/core lead noted.
- zu Zug 55 (notiert vor Zug 56): I only had 7 plates, not 21 — the rest were never in my inventory; breastplate costs 140 copper, far beyond reach today.
- zu Zug 60 (notiert vor Zug 61): Clarify prompt repeated despite a full buy/sell statement; splitting into one clear sale per message.
- zu Zug 62 (notiert vor Zug 63): Clarify loop persists even after accepting offer.t116.7; simplifying wording.
- zu Zug 63 (notiert vor Zug 64): Clarify loop persists despite naming buyer, goods, and total; trying explicit Sell/Buy field format.
- zu Zug 65 (notiert vor Zug 66): Clarify loop repeated even after picking the offered 56 cp option; possibly the older 7 plates are being confused with the bid plates.
- zu Zug 66 (notiert vor Zug 67): Clarify loop persists across six differently worded sale attempts; system keeps asking the same four fields even when all are named.
- zu Zug 70 (notiert vor Zug 71): Trade clarify loop persists across seven differently worded sale attempts; suspecting the plates may not be recorded in the pouch at all.
- zu Zug 71 (notiert vor Zug 72): Bag confirms both plate stacks (7 and 14); the sale itself remains unrecorded.
- zu Zug 73 (notiert vor Zug 74): Ninth sale attempt; this time naming the specific present smith instead of the generic 'Smith'.
- zu Zug 74 (notiert vor Zug 75): Ten sale attempts all bounce off CLARIFY even with all four fields labeled; trying to obtain an offer first instead of asserting a sale.
- zu Zug 75 (notiert vor Zug 76): The smith has now made an explicit offer: 4 cp per plate, 56 total; the CLARIFY loop may have been triggered by the literal 'I sell.' prefix.
- zu Zug 76 (notiert vor Zug 77): CLARIFY now parses my sale and only disputes the price wording; the smith's 'four the plate' means 4 each, 56 total.
- zu Zug 78 (notiert vor Zug 79): Engine treats the smith's offer as 4 cp TOTAL despite the narrator's 'four the plate' wording; narrator and System contradict on price.
- zu Zug 79 (notiert vor Zug 80): CLARIFY flipped: it now states the bid is 56 cp, contradicting its earlier claim of 4 cp total; System and narrator agree on 56 this time.
- zu Zug 81 (notiert vor Zug 82): Armour purchase confirmed and equipped; DEF likely to rise on HUD refresh. Coin at 27 cp, below the 100 cp gear-check threshold for further spending.
- zu Zug 82 (notiert vor Zug 83): Armour purchase confirmed and equipped, but HUD still shows DEF 12 — may refresh later. Fine sword at 140 cp unaffordable at 27 cp; noted as pending future income.
- zu Zug 83 (notiert vor Zug 84): Board is bare; clerk says new postings may be two days out. Doran hints at private work.
- zu Zug 93 (notiert vor Zug 94): Asterford office has no contract board; nearest is Glassmere, half a day west. Still owe a smith visit for gear.
- zu Zug 99 (notiert vor Zug 100): Rats only ENGAGE when approached individually; Cleave requires an engaged target, so Basic Attack first.
- zu Zug 101 (notiert vor Zug 102): Level 6 confirmed, points assigned. Rats fled toward the drain-grate; job count still unclear.
- zu Zug 105 (notiert vor Zug 106): Engine requires declared movement to reach ENGAGED range before a Basic Attack.
- zu Zug 109 (notiert vor Zug 110): Gear priority pending: with only 3 silver and no confirmed smith visit value, will check a smith once I have more coin or on next safe visit.
- zu Zug 113 (notiert vor Zug 114): With 65 cp I can't afford even the superior plate (88 cp) or fine longsword (140 cp); gear purchase deferred until more coin.
- zu Zug 114 (notiert vor Zug 115): Coin recount: 6 silver 5 copper = 65 cp, still short of the 88 cp plate; gear purchase remains deferred.
- zu Zug 119 (notiert vor Zug 120): System named the rats as valid targets (Rat A, Rat B) — target them by name.
- zu Zug 135 (notiert vor Zug 136): No affordable armour or weapon improves on my current ATK 10/DEF 13; fine chainmail is DEF +0 for 72 cp. HUD shows 9 Silver 4 Copper despite earlier 104→94 copper ledger.
- zu Zug 136 (notiert vor Zug 137): Narrator prices at Bram's shop conflicted with binding System prices (e.g. common longsword 80 cp, not 10 cp); my earlier hold-off decision stands since nothing affordable improves ATK 10/DEF 13.
- zu Zug 141 (notiert vor Zug 142): Strider keeps exactly one body-length beyond sword reach and more are converging from the reeds; STA is only 15/100, so a long chase may not be viable.
- zu Zug 142 (notiert vor Zug 143): Bog striders outrun Basic Attack reach; without a ranged or gap-closing option this hunt may be impractical at STA 15. Strider won't pursue beyond the weir stones.
- zu Zug 143 (notiert vor Zug 144): Striders unreachable with Basic Attack; strider hunt may be impractical without gap-closing skill. Engine refused eat/rest actions but narrator showed recovery anyway.
- zu Zug 145 (notiert vor Zug 146): Coin 1g2s4cp = 124cp; superior longsword 18s is affordable actually (1 gold = 10 silver?), but 1g2s may not cover 18s + 20s armour. Need sale income first.
- zu Zug 147 (notiert vor Zug 148): Narrator showed sale and purchase completed, but ENGINE RESULT refused both and HUD still shows Starter Longsword and 1g2s4cp — must re-perform explicitly.
- zu Zug 148 (notiert vor Zug 149): Narrator and engine disagree: narrator showed the sale and longsword purchase completed, but the engine refused them and the HUD still shows Starter Longsword, 7 chitin plates and 1g2s4cp.
- zu Zug 149 (notiert vor Zug 150): Narrator has now twice shown the sale/purchase completed, but the engine refuses and HUD still shows Starter Longsword and 1g2s4cp — persistent engine/narrator contradiction.
- zu Zug 150 (notiert vor Zug 151): Engine repeatedly reports the smithy empty and no seller present, even when the narrator shows Osric completing the sale — sale/purchase never booked; will retry only with a new confirmed offer.
- zu Zug 153 (notiert vor Zug 154): Payment and food items now engine-confirmed; the Osric chitin sale/longsword purchase remains unbooked (three refusals) — will retry at a smith with new income.
- zu Zug 154 (notiert vor Zug 155): STA is only 15/100 — should recover before the strider hunt; will consider resting or food first.
- zu Zug 155 (notiert vor Zug 156): STA still 15/100 — should rest or eat before the weir hunt.
- zu Zug 157 (notiert vor Zug 158): STA still 15/100 despite eating porridge — food did not restore stamina; HP also only 142/220 (wounded). Risky to fight, but open-ground engagement is favorable.
- zu Zug 158 (notiert vor Zug 159): System refused the strider attack: active scene was still Dagny's house — the travel narration was not engine-confirmed; STA 15/100 and HP 142/220 make fighting reckless anyway.
- zu Zug 167 (notiert vor Zug 168): Something big lurks under the walkway — possible second threat after the kill.
- zu Zug 170 (notiert vor Zug 171): Mother has climbed onto the walkway; may join combat next round.
- zu Zug 172 (notiert vor Zug 173): Mother strider is defensive, not aggressive — she only guards the basket. Kill count may still show 2/5; will verify.
- zu Zug 173 (notiert vor Zug 174): Kill count still shows 2/5; loot pickup was confirmed by narration despite the take refusals.
- zu Zug 175 (notiert vor Zug 176): Quest still shows 2/5 despite two kills here; the bigger strider D fled into the burrow and may count later.
- zu Zug 176 (notiert vor Zug 177): HUD 'Here' block still describes the fourth weir despite location showing the wider channel — likely stale panel text.
- zu Zug 178 (notiert vor Zug 179): Stale 'Here' block still describes the fourth weir mother while location shows the wider channel.
- zu Zug 180 (notiert vor Zug 181): Narration said 'fourth of the contract's five' but the quest panel counts 3/5 — trust the panel; one more worker plus one remains.
- zu Zug 181 (notiert vor Zug 182): Quest panel counts 3/5 despite narrator calling kills the fourth — trusting the panel; two more striders still needed.
- zu Zug 182 (notiert vor Zug 183): Quest panel now counts 4/5, matching narrator; one kill remains.
- zu Zug 183 (notiert vor Zug 184): System refused my attack because the strider wasn't yet engaged; must close to SHORT/ENGAGED first.
- zu Zug 193 (notiert vor Zug 194): HUD shows I already wear a fine F-Rank breastplate, so armour is covered; only the weapon needs upgrading.
- zu Zug 194 (notiert vor Zug 195): System asked to clarify the price before spending; nothing bought yet.
- zu Zug 196 (notiert vor Zug 197): Gear priority met: fine longsword and breastplate both equipped; 104 copper on hand.
- zu Zug 202 (notiert vor Zug 203): The strider keeps deliberately out of reach behind the brush pile; two fence-approach attempts failed to engage.
- zu Zug 211 (notiert vor Zug 212): Two 'arrival pending' refusals then a no-valid-target: the lurking strider sign may not be an actual present actor; may need to leave the weir.
- zu Zug 214 (notiert vor Zug 215): Level 11 confirmed; 10 free points noted in HUD but level-up message said +5 — will verify after assign.
- zu Zug 216 (notiert vor Zug 217): HUD shows 5 free points remaining after assign; level-up said +5 but earlier HUD noted 10 — minor discrepancy, watch it.
- zu Zug 217 (notiert vor Zug 218): Bog Strider L defeated in one strike; contract panel still shows 3/6 though four are dead — count discrepancy to watch.
- zu Zug 218 (notiert vor Zug 219): Contract still 3/6 despite four kills; count discrepancy persists. STA 26 with two LONG striders present — withdrawing to recover.
- zu Zug 222 (notiert vor Zug 223): HUD says Day 4 20:30 evening though narrator described morning; time discrepancy. Contract still shows 3/6 despite four kills.
- zu Zug 223 (notiert vor Zug 224): ENGINE refused the repair as 'no valid canonical offer' even though Osric quoted six copper and narration showed the work done; HUD time says Day 4 20:40 evening while narration described morning.
- zu Zug 227 (notiert vor Zug 228): Stats assigned (VIT 41, STR 39). Superior sword upgrade at 260 cp unaffordable at 98 cp; gear already repaired and fine-tier.
- zu Zug 229 (notiert vor Zug 230): STA is low (26/100) before this fight; a second strider ticks near the hut.
- zu Zug 233 (notiert vor Zug 234): STA only 21/100; contract shows 4/6 though five striders seem defeated.
- zu Zug 234 (notiert vor Zug 235): Strider P refuses to enter ENGAGED range; STA at 21/100, contract still shows 4/6 despite five apparent kills.
- zu Zug 235 (notiert vor Zug 236): Contract now shows 5/6 after Strider P; STA very low at 16/100 and something large may be moving in the reed-beds.
- zu Zug 239 (notiert vor Zug 240): Contract turned in: +750 XP, 14 silver, Level 12 confirmed. Gear check still pending before next hunt.
- zu Zug 243 (notiert vor Zug 244): Engine prices (88 cp) are far below Harlun's spoken prices; engine result is binding.
- zu Zug 244 (notiert vor Zug 245): HUD still shows old breastplate equipped; engine prices far below Harlun's spoken ones, engine binding.
- zu Zug 245 (notiert vor Zug 246): HUD now shows superior heavy armor equipped; armor check done, weapon upgrade is next.
- zu Zug 246 (notiert vor Zug 247): Engine price for superior longsword (260 cp) exceeds my 148 cp; commission has no engine price, so not purchasable. Weapon upgrade deferred with reason; armour gear check already complete.
- zu Zug 247 (notiert vor Zug 248): The rat-job payment exists only as a rumor; Widow Gell's four coppers were already collected. Marda is not present at the Saddle and Cart.
- zu Zug 249 (notiert vor Zug 250): Marda's payment confirmed to exist only as a rumor; Corvin had nothing. Third visit on this lead; if she can't be found, I'll drop it and return to Guild contracts.
- zu Zug 250 (notiert vor Zug 251): Marda spent the rat-job coin on a kettle; payment exists only as informal debt or a non-Guild side job. Lead dropped after three attempts.
- zu Zug 259 (notiert vor Zug 260): Marsh cat contract paid out 45 cp; adder quest still active at 0/1.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t9 | 9 | 3 | – | nein | 3 | gewonnen, 540 XP |
| enc.t16 | 17 | 1 | – | nein | 1 | gewonnen, 240 XP |
| enc.t37 | 42 | 3 | – | nein | 3 | gewonnen, 180 XP |
| enc.t40 | 45 | 6 | – | nein | 6 | gewonnen, 450 XP |
| enc.t63 | 90 | 1 | – | nein | 1 | gewonnen, 60 XP |
| enc.t72 | 100 | 1 | – | nein | 1 | gewonnen, 70 XP |
| enc.t77 | 106 | 2 | – | nein | 2 | gewonnen, 120 XP |
| enc.t88 | 117 | 1 | – | nein | 1 | gewonnen, 75 XP |
| enc.t91 | 121 | 2 | – | nein | 2 | gewonnen, 120 XP |
| enc.t97r | 127 | 1 | – | nein | 1 | gewonnen, 60 XP |
| enc.t131r | 164 | 1 | – | nein | 1 | gewonnen, 515 XP |
| enc.t137r | 170 | 1 | – | nein | 1 | gewonnen, 240 XP |
| enc.t140r | 174 | 1 | – | nein | 1 | gewonnen, 60 XP |
| enc.t145 | 180 | 1 | – | ja | 1 | gewonnen, 240 XP |
| enc.t147 | 182 | 1 | – | ja | 1 | gewonnen, 240 XP |
| enc.t148 | 184 | 1 | – | ja | 1 | gewonnen, 435 XP |
| enc.t164 | 203 | 1 | – | nein | 1 | gewonnen, 360 XP |
| enc.t167 | 206 | 1 | – | ja | 1 | gewonnen, 240 XP |
| enc.t173 | 214 | 1 | – | nein | 1 | gewonnen, 300 XP |
| enc.t175 | 217 | 1 | – | nein | 1 | gewonnen, 60 XP |
| enc.t187 | 231 | 1 | – | nein | 1 | gewonnen, 300 XP |
| enc.t191 | 235 | 1 | – | nein | 1 | gewonnen, 420 XP |
| enc.t193 | 237 | 1 | – | nein | 1 | gewonnen, 360 XP |
| enc.t213 | 258 | 1 | – | nein | 1 | gewonnen, 60 XP |

## Quests

- **Cull the Reed Flats Bog Striders** — expired (Zug 192)
  - Aufgabe: Kill 5 bog striders at the eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 5 bog striders killed at the eel-weirs of the Reed Flats.
- **The Adder by the Goose Pens** — active (Zug 85) → completed (Zug 112)
  - Aufgabe: Kill 1 grey marsh adder at the Millpond goose pens. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 grey marsh adder killed at the Millpond goose pens.
- **Thin the Howling Pack of Wolfmere Down** — expired (Zug 192)
  - Aufgabe: Kill 8 grey wolves at the standing stones of Wolfmere Down. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 8 grey wolves killed at the standing stones of Wolfmere Down.
- **The Pale Stag of the Mirefen** — expired (Zug 192)
  - Aufgabe: Kill 1 pale antlered stag at the deep channels of the Mirefen. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 pale antlered stag killed at the deep channels of the Mirefen.
- **Clear Glimmerdeep Grotto Level 1** — expired (Zug 192), Dungeon loc.glimmerdeep_grotto Ebene 1
  - Aufgabe: Clear level 1 of Glimmerdeep Grotto. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Glimmerdeep Grotto is clear.
- **Adder in the Goose Pens** — expired (Zug 136)
  - Aufgabe: Kill 1 grey marsh adder at the Millpond goose pens. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 grey marsh adder killed at the Millpond goose pens.
- **Marsh Cat at the Granary Row** — active (Zug 125) → completed (Zug 129)
  - Aufgabe: Kill 1 marsh cat at the granary row of Asterford. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 marsh cat killed at the granary row of Asterford.
- **Thin the Bog Striders at the Weirs** — expired (Zug 136)
  - Aufgabe: Kill 6 bog striders at the eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 6 bog striders killed at the eel-weirs of the Reed Flats.
- **Wolves of Wolfmere Down** — expired (Zug 136)
  - Aufgabe: Kill 5 grey wolves at the standing stones of Wolfmere Down. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 5 grey wolves killed at the standing stones of Wolfmere Down.
- **The Pale Stag of the Mirefen** — expired (Zug 136)
  - Aufgabe: Kill 1 pale stag at the deep channels of the Mirefen. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 pale stag killed at the deep channels of the Mirefen.
- **Thin the Bog Striders at the Weirs** — active (Zug 137) → completed (Zug 189)
  - Aufgabe: Kill 5 bog striders at the eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 5 bog striders killed at the eel-weirs of the Reed Flats.
- **Thin the Bog Striders at the Reed Flats Eel-Weirs** — active (Zug 198) → completed (Zug 239), READY
  - Aufgabe: Kill 6 bog strider at the eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 6 bog strider killed at the eel-weirs of the Reed Flats.
- **Marsh Adder in the Goose Pens** — active (Zug 253)
  - Aufgabe: Kill 1 grey marsh adder at the Millpond goose pens. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 grey marsh adder killed at the Millpond goose pens.
- **Marsh Cat on Granary Row** — active (Zug 253) → completed (Zug 259)
  - Aufgabe: Kill 1 marsh cat at the granary row of Asterford. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 marsh cat killed at the granary row of Asterford.

## Auffälligkeiten

- Zug 4, Nachricht 7 (planner_repaired): the planner's first answer needed a repair
- Zug 20, Nachricht 40 (extraction_repaired): the extractor's first answer needed a repair
- Zug 24, Nachricht 48 (extraction_repaired): the extractor's first answer needed a repair
- Zug 26, Nachricht 51 (planner_repaired): the planner's first answer needed a repair
- Zug 26, Nachricht 52 (extraction_repaired): the extractor's first answer needed a repair
- Zug 28, Nachricht 55 (planner_repaired): the planner's first answer needed a repair
- Zug 36, Nachricht 72 (extraction_repaired): the extractor's first answer needed a repair
- Zug 37, Nachricht 74 (extraction_repaired): the extractor's first answer needed a repair
- Zug 48, Nachricht 96 (extraction_repaired): the extractor's first answer needed a repair
- Zug 51, Nachricht 102 (extraction_repaired): the extractor's first answer needed a repair
- Zug 54, Nachricht 107 (planner_repaired): the planner's first answer needed a repair
- Zug 55, Nachricht 109 (planner_repaired): the planner's first answer needed a repair
- Zug 56, Nachricht 111 (planner_failed): the planner failed: commands[0] (sell): quote "I'll still take the seven at four copper each" is not in the message (copy his exact words)
- Zug 56, Nachricht 111 (planner_repaired): the planner's first answer needed a repair
- Zug 57, Nachricht 113 (planner_repaired): the planner's first answer needed a repair
- Zug 59, Nachricht 117 (planner_repaired): the planner's first answer needed a repair
- Zug 60, Nachricht 119 (planner_repaired): the planner's first answer needed a repair
- Zug 61, Nachricht 121 (planner_repaired): the planner's first answer needed a repair
- Zug 62, Nachricht 123 (planner_repaired): the planner's first answer needed a repair
- Zug 63, Nachricht 125 (planner_repaired): the planner's first answer needed a repair
- Zug 64, Nachricht 127 (planner_repaired): the planner's first answer needed a repair
- Zug 65, Nachricht 129 (planner_repaired): the planner's first answer needed a repair
- Zug 66, Nachricht 131 (planner_repaired): the planner's first answer needed a repair
- Zug 67, Nachricht 133 (planner_repaired): the planner's first answer needed a repair
- Zug 69, Nachricht 137 (planner_repaired): the planner's first answer needed a repair
- Zug 70, Nachricht 139 (planner_repaired): the planner's first answer needed a repair
- Zug 72, Nachricht 143 (planner_repaired): the planner's first answer needed a repair
- Zug 73, Nachricht 145 (planner_repaired): the planner's first answer needed a repair
- Zug 74, Nachricht 147 (planner_repaired): the planner's first answer needed a repair
- Zug 76, Nachricht 151 (planner_repaired): the planner's first answer needed a repair
- Zug 77, Nachricht 153 (planner_repaired): the planner's first answer needed a repair
- Zug 97, Nachricht 193 (planner_repaired): the planner's first answer needed a repair
- Zug 104, Nachricht 208 (extraction_repaired): the extractor's first answer needed a repair
- Zug 132, Nachricht 264 (extraction_repaired): the extractor's first answer needed a repair
- Zug 134, Nachricht 268 (extraction_repaired): the extractor's first answer needed a repair
- Zug 137, Nachricht 274 (extraction_repaired): the extractor's first answer needed a repair
- Zug 144, Nachricht 288 (extraction_repaired): the extractor's first answer needed a repair
- Zug 146, Nachricht 292 (extraction_repaired): the extractor's first answer needed a repair
- Zug 147, Nachricht 293 (planner_repaired): the planner's first answer needed a repair
- Zug 152, Nachricht 303 (planner_failed): the planner failed: $.commands[1] (take): .object: matches none of anyOf
- Zug 152, Nachricht 303 (planner_repaired): the planner's first answer needed a repair
- Zug 158, Nachricht 315 (planner_repaired): the planner's first answer needed a repair
- Zug 161, Nachricht 322 (extraction_repaired): the extractor's first answer needed a repair
- Zug 162, Nachricht 324 (extraction_repaired): the extractor's first answer needed a repair
- Zug 167, Nachricht 334 (extraction_repaired): the extractor's first answer needed a repair
- Zug 182, Nachricht 364 (extraction_repaired): the extractor's first answer needed a repair
- Zug 187, Nachricht 373 (planner_failed): the planner failed: $.commands[1] (go): .to: matches none of anyOf
- Zug 187, Nachricht 373 (planner_repaired): the planner's first answer needed a repair
- Zug 190, Nachricht 380 (extraction_repaired): the extractor's first answer needed a repair
- Zug 191, Nachricht 381 (planner_repaired): the planner's first answer needed a repair
- Zug 193, Nachricht 386 (extraction_repaired): the extractor's first answer needed a repair
- Zug 194, Nachricht 387 (planner_repaired): the planner's first answer needed a repair
- Zug 195, Nachricht 390 (extraction_repaired): the extractor's first answer needed a repair
- Zug 211, Nachricht 421 (planner_repaired): the planner's first answer needed a repair
- Zug 218, Nachricht 435 (planner_repaired): the planner's first answer needed a repair
- Zug 219, Nachricht 438 (extraction_repaired): the extractor's first answer needed a repair
- Zug 220, Nachricht 439 (planner_failed): the planner failed: commands[1] (sell): quote "and one venom gland — I'll take your three silver for the gl" is not in the message (copy his exact words)
- Zug 220, Nachricht 439 (planner_repaired): the planner's first answer needed a repair
- Zug 221, Nachricht 442 (extraction_repaired): the extractor's first answer needed a repair
- Zug 245, Nachricht 489 (planner_repaired): the planner's first answer needed a repair
- Zug 246, Nachricht 492 (extraction_repaired): the extractor's first answer needed a repair
- Zug 250, Nachricht 500 (extraction_repaired): the extractor's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 96× keine gültige JSON-Entscheidung (Züge 2, 5, 6, 7, 9, 10, 16, 17, 20, 21, 22, 28, 38, 39, 40, 41, 42, 44, 53, 59, 62, 68, 81, 83, 84, 87, 88, 89, 90, 91, 98, 103, 105, 110, 111, 112, 113, 114, 116, 119, 121, 125, 126, 127, 131, 133, 134, 135, 137, 141, 142, 143, 144, 145, 146, 149, 152, 153, 156, 163, 164, 165, 166, 167, 168, 174, 178, 180, 189, 191, 193, 196, 198, 200, 201, 202, 204, 209, 211, 217, 218, 222, 225, 226, 229, 231, 232, 236, 237, 238, 241, 244, 245, 249, 250, 252)

System-Panels: CLARIFY 20, NOT TAKEN 5, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: ambient 9, guild_branch 2, guild_canon 2, group_unclear 6, world_rule 12, engine_owned_combat 1, offer 10, engine_booked 3, sale_evidence 8, pc_inventory 6, coin_already_received 4, coin_evidence 3, quest 1, engine_owned_fact 11, npc_presence 7, attack_commitment 6, engine_owned_detail 1, no_go 3, scene_context 17, npc_continuity 14, guild_completion 1, object 1, npc_identity 1, time_cap 2, recover 1, creature_continuity 2, engine_owned 2, quest_count 2, gear_offer 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 96/260 Erstantworten ungültig (36.9 %); 96 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 278 | 34 | 2.5 s | 4.5 s | 12426 | 10151 | 91 | – | stop 278 | 0 |
| narrator | 213 | 0 | 8.1 s | 11.1 s | 11422 | 8739 | 401 | – | stop 213 | 0 |
| extract | 237 | 24 | 5.5 s | 8.9 s | 14001 | 10549 | 422 | – | stop 237 | 0 |
| board | 7 | 2 | 8.7 s | 14.9 s | 2602 | 0 | 1160 | – | stop 7 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 103:31 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 15.3 s) | 0:29 min |
| 260 Züge, Spiel (Senden bis HUD nach der Extraktion) | 82:19 min — Median 19.3 s, p90 28.9 s, max 48.7 s |
| 260 Züge, Spieler-Entscheidung | 13:55 min — Median 2.7 s, 96 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 13:58 min / 1:09 min / 31:25 min / 23:36 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 22.2 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 14:48 min, 80 Züge ≈ 29:37 min (ohne Einrichtung) |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
