# Avereth Live-Test 20261031-154730Z-current_test

## Kurzfassung

- **Laufprofil:** guild-mage; Startklasse Mage, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** abgebrochen: Fehler im Runner — interrupted (Ctrl+C) in turn 9
- **Etappen:** 1/3 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht) · class_accepted (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 1. Sicherheitsgrenzen: 260 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** noch nicht erreicht.
- **Charakter:** mage (mage.arcane_bolt, mage.arcane_wave) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 through E class evolution“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: curious adventurer: follow interesting opportunities without forcing dangerous encounters
- **Züge:** 9 · **Dauer:** 3:32 min · **LLM-Aufrufe der Engine/des Erzählers:** 20
- **Beobachtete Abdeckung:** 3 unterschiedliche gebuchte Reiseziele · 0 Kämpfe · 0 Verkäufe (0 cp Umsatz, ohne Questzahlungen/Geschenke) · 0 Ausrüstungswechsel · 0 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 1
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.137 |
| Git | 512437369242 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 31.0 s |
| Browser | chrome 156.0.8078.49 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261031-154730Z-current_test“, Seed 679216484 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |
| class_accepted | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | I choose Mage. | Engine (Menü/Rückfrage) | creation_complete | Select base class | public roadside verge outside Glassmere | 90/84 | 2.3 s |
| 2 | I select Arcane Wave and Arcane Bolt as my two skills. | Engine (Menü/Rückfrage) | creation_complete | Finish character creation | public roadside verge outside Glassmere | 90/96 | 2.1 s |
| 3 | I walk to Glassmere's city gate and enter the city, then look for the Adventurers' Guild hall. | Erzähler | open_run_level | Enter Glassmere and find the Guild to register and pick a first contract | Adventurers' Guild hall, Glassmere | 90/96 | 20.3 s |
| 4 | Registration, please. What do I need to sign up? | Erzähler | open_run_level | Register with the Guild | Adventurers' Guild hall, Glassmere | 90/96 | 12.0 s |
| 5 | Yes, I'm paying. I hand over two silver and sign the register as Alaric. | Erzähler | open_run_level | Register with the Guild | Adventurers' Guild hall, Glassmere | 90/96 | 18.2 s |
| 6 | I turn to the contract board and read the posted slips, looking for work a novice mage can handle. | Erzähler | open_run_level | Pick a first Guild contract | Adventurers' Guild hall, Glassmere | 90/96 | 25.6 s |
| 7 | I bring the eel-weir serpent slip to the clerk and ask her to make it active. | Erzähler | open_run_level | Accept the first Novice contract | Adventurers' Guild hall, Glassmere | 90/96 | 16.6 s |
| 8 | I head out through the Marsh Gate and follow the road south toward the Reed Flats, asking the eel-fishers there to point me to the weirs wit… | Erzähler | open_run_level | Travel to the Reed Flats and find the serpent | the eel-weirs of the Reed Flats | 90/96 | 20.8 s |
| 9 | I thank the fisher and move quietly along the board path toward the third weir, keeping low and watching the water for the serpent. | – | open_run_level | Approach the serpent's weir stealthily | the eel-weirs of the Reed Flats | 90/96 | 0.0 s **interrupted** |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 2 (notiert vor Zug 3): Character creation complete: Level 1 Mage with Arcane Bolt and Arcane Wave; starter staff and robes equipped; 5 silver on hand.

## Kämpfe

Kein Kampf.

## Quests

- **Thin the Reed Flat Eel-Weir Serpents** — active (Zug 7)
  - Aufgabe: Kill 1 marsh serpent at the eel-weirs of the Reed Flats. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 marsh serpent killed at the eel-weirs of the Reed Flats.

## Auffälligkeiten

- Zug 9 (Runner/UI): interrupted
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 4× keine gültige JSON-Entscheidung (Züge 2, 6, 7, 9)
- Server: Generation failed AbortError: The operation was aborted.

System-Panels: CLARIFY 0, NOT TAKEN 0, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: guild_canon 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 0, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 4/9 Erstantworten ungültig (44.4 %); 4 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 7 | 0 | 2.0 s | 2.6 s | 11192 | 9916 | 61 | – | stop 6 | 0 |
| narrator | 6 | 0 | 8.3 s | 11.9 s | 11539 | 4634 | 363 | – | stop 6 | 0 |
| extract | 6 | 0 | 4.1 s | 6.6 s | 12727 | 10192 | 273 | – | stop 6 | 0 |
| board | 1 | 0 | 10.7 s | 10.7 s | 2602 | 2357 | 964 | – | stop 1 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 3:32 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 31.0 s) | 0:45 min |
| 9 Züge, Spiel (Senden bis HUD nach der Extraktion) | 1:58 min — Median 16.6 s, p90 25.6 s, max 25.6 s |
| 9 Züge, Spieler-Entscheidung | 0:42 min — Median 2.6 s, 4 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 0:12 min / 0:11 min / 0:51 min / 0:27 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 17.8 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 11:52 min, 80 Züge ≈ 23:45 min (ohne Einrichtung) |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
