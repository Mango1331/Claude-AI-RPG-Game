# Avereth – 3 natürliche Testkampagnen

Status: **interrupted**. Serie abgeschlossen bedeutet, dass die Läufe beendet sind; es bedeutet nicht 3 bestandene Level-15-Abnahmen.

| Nr. | Profil | Seed | Eingaben | Level | Ende | Originalbericht |
|---|---|---:|---:|---:|---|---|
| 1 | guild-warrior | 679216483 | 260 | 12 | limit | [report.md](001-guild-warrior/20261031-140347Z-current_test/report.md) |
| 2 | guild-mage | 679216484 | 9 | 1 | process_error | [report.md](002-guild-mage/20261031-154730Z-current_test/report.md) |
| 3 | guild-rogue | 679216485 | – | – | pending | – |

