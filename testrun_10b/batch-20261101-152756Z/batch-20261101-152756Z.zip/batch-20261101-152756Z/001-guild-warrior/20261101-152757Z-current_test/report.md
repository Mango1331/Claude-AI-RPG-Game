# Avereth Live-Test 20261101-152757Z-current_test

## Kurzfassung

- **Laufprofil:** guild-warrior; Startklasse Warrior, Schwerpunkt guild. Freie Entscheidungen innerhalb des Schwerpunkts, keine Fixture.
- **Ergebnis:** abgebrochen: Fehler im Runner — interrupted (Ctrl+C) in turn 63
- **Etappen:** 1/3 Pflicht erreicht
- **Offen:** open_run_level (nicht erreicht) · class_accepted (nicht erreicht)
- **Progressionsziel:** Level 15; tatsächlich Level 3. Sicherheitsgrenzen: 1000 Eingaben / 1440 Minuten. Ein Limitabbruch erfüllt das Ziel nicht.
- **Vergleich nach 100 Eingaben:** noch nicht erreicht.
- **Charakter:** warrior (warrior.guard, warrior.cleave) · Regelstand 2 (Warrior, Mage, Rogue)
- **Leitfaden:** current_test („Open-world progression — natural Level 1 through E class evolution“)
- **Spieler:** LLM zai-org/GLM-5.3-Flash (127.0.0.1:5050, Temperatur 0.8), Stil: curious adventurer: follow interesting opportunities without forcing dangerous encounters
- **Züge:** 63 · **Dauer:** 35:49 min · **LLM-Aufrufe der Engine/des Erzählers:** 194
- **Beobachtete Abdeckung:** 9 unterschiedliche gebuchte Reiseziele · 2 Kämpfe · 3 Verkäufe (193 cp Umsatz, ohne Questzahlungen/Geschenke) · 1 Ausrüstungswechsel · 0 Skill-Erwerbe/Evolutionen/Proficiency-Aufstiege. Keine zusätzlichen Erfolgsbedingungen.
- **Auffälligkeiten:** 23
- **Profil unverändert:** ja · **Geheimnis-Scan:** sauber

## Aufbau

| | |
|---|---|
| Build (Erweiterung) | 4.3.0-c.6.6.145 |
| Git | 0a2beca32088 (claude/c-planner-prototype-2026-10-02-gpt-c666) — sauber |
| SillyTavern | 1.19.0 (C:\Users\mmitr\Silly\SillyTavern-Launcher\SillyTavern), isolierte Instanz auf Port 8123, Start 28.2 s |
| Browser | chrome 156.0.8078.49 (headless) |
| Verbindung deines SillyTavern | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: secrets.json api_key_custom |
| Verbindung des Laufs | Quelle "custom" → custom_url http://127.0.0.1:5050/v1 · Modell zai-org/GLM-5.3-Flash · Schlüssel: AVERETH_LIVE_API_KEY — dieselbe |
| Preflight (GET /models) | http://127.0.0.1:5050/v1/models: 6 Modell(e) (Qwen/Qwen3.8-27B, zai-org/GLM-5.3-Flash, zai-org/GLM-5.3, deepseek-ai/DeepSeek-V4.1-Flash, deepseek-ai/DeepSeek-V4-Pro, moonshotai/Kimi-K2.6), Modell enthalten |
| Preset | Avereth Narrator V4 (aus dem Profil), weicht vom Build-Preset ab in: openai_max_tokens, show_thoughts |
| Generierung | Temperatur 0.9, max. Tokens 8192, Kontext 131072, Reasoning low |
| Streaming | aus |
| Spieler-Reasoning (wirksam) | `reasoning_effort`="low", `clear_thinking`=true — as the game's own requests carry them (custom_include_body and the preset's reasoning_effort), same endpoint and model · Probe: angenommen (finish stop, Reasoning 0 Zeichen) · max. 3000 Tokens |
| Karte | Avereth Engine Test v4: Begrüßung aus dem Profil, Beschreibung = Erzählervertrag dieses Builds (im Profil: 4.3.0-c.6.6.49) |
| Lorebook | Avereth World Lore v0.14 aus diesem Build |
| Engine-Einstellungen | {"enabled":true,"budget":1400,"rulesBudget":800,"recentTurns":4,"depth":0,"showDebug":true,"loreSource":"auto","wordSwaps":"ledger=register","hud":"closed","historyTurns":4,"stripTrackers":true,"recoverReports":true,"runtime":"v4","planner":true,"settingsRev":2,"legacyPlanner":true} |
| Kampagne | Chat „Avereth Live 20261101-152757Z-current_test“, Seed 1320776721 |

## Etappen

| Etappe | Pflicht | erreicht | Zug | Nachricht | Budget |
|---|---|---|---:|---:|---:|
| creation_complete | ja | ✔ | 2 | 3 | 8 |
| open_run_level | ja | – |  |  |  |
| class_accepted | ja | – |  |  |  |

## Spielereingaben

| Zug | Eingabe | Antwort | Etappe (Spieler) | Absicht | Ort danach | HP/MP | Zug-Zeit |
|---:|---|---|---|---|---|---|---:|
| 1 | I choose Warrior. | Engine (Menü/Rückfrage) | creation_complete | Select Warrior base class | public roadside verge outside Alderwatch | 90/84 | 2.3 s |
| 2 | I select Cleave and Guard as my two skills. | Engine (Menü/Rückfrage) | creation_complete | Finish character creation with warrior.cleave plus Guard | public roadside verge outside Alderwatch | 95/84 | 2.1 s |
| 3 | I walk along the road toward Alderwatch's gate and enter the city. | Erzähler | open_run_level | Reach town to find Guild work | Alderwatch | 95/84 | 21.6 s |
| 4 | I head to the Guild hall with the crossed swords sign and look for the contract board. | Erzähler | open_run_level | Find a Guild contract | Adventurers' Guild hall, Alderwatch | 95/84 | 52.4 s |
| 5 | I ask the clerk to register me with the Guild, then request the Marsh Lynx contract. | Erzähler | open_run_level | Register and take a novice contract | Adventurers' Guild hall, Alderwatch | 95/84 | 15.5 s |
| 6 | I pay the two silver fee and sign the ledger to register with the Guild. | Erzähler | open_run_level | Register with the Guild | Adventurers' Guild hall, Alderwatch | 95/84 | 15.9 s |
| 7 | I ask the clerk to take the Marsh Lynx contract from the novice board. | Erzähler | open_run_level | Accept Marsh Lynx contract | Adventurers' Guild hall, Alderwatch | 95/84 | 19.2 s |
| 8 | I take the slip and head east through Southgate toward the duck pens along the mill race. | Erzähler | open_run_level | Travel to the Marsh Lynx contract site | the Alderwatch watermeadow duck pens | 95/84 | 27.4 s |
| 9 | I approach the farmer by the fence and tell him I've taken the Guild contract to deal with the lynx, asking where it has been striking and w… | Erzähler | open_run_level | Get information on the lynx from the keeper | the Alderwatch watermeadow duck pens | 95/84 | 29.3 s |
| 10 | I ask the farmer to point me to the feeding platform, then settle in there to wait for the lynx at dusk. | Erzähler | open_run_level | Wait for the lynx at dusk on the feeding platform | the Alderwatch watermeadow duck pens | 95/84 | 26.6 s |
| 11 | I keep waiting on the platform through the afternoon, sword ready, watching the reed line for the lynx at dusk. | Erzähler | open_run_level | Wait for dusk ambush at the feeding platform | the Alderwatch watermeadow duck pens | 95/84 | 33.6 s |
| 12 | I rise and charge the lynx, swinging my longsword at it before it can bolt back into the reeds. | Erzähler | open_run_level | Attack the marsh lynx to complete the contract | the Alderwatch watermeadow duck pens | 91/84 | 16.3 s |
| 13 | I finish it—one more basic attack at the wounded lynx before it can flee. | Erzähler | open_run_level | Kill the marsh lynx to complete the contract | the Alderwatch watermeadow duck pens | 91/84 | 15.9 s |
| 14 | I accept the farmer's offer, following him up to the hut to wash the cuts and let his wife salve them. | Erzähler | open_run_level | Accept recovery help, then plan to turn in the contract at the Guild hall | the farmer's hut | 91/84 | 176.9 s |
| 15 | I eat supper at the hearth, then ask the farmer if I can sleep by the fire until morning before heading back to the Guild. | Erzähler | open_run_level | Rest overnight at the hut, then turn in the contract | the farmer's hut | 95/84 | 19.2 s |
| 16 | I eat the porridge and bread, thank the family, then head back to Valedorn Crown to turn in the lynx contract at the Guild hall. | Erzähler | open_run_level | Turn in the completed lynx contract at the Guild | Adventurers' Guild hall, Alderwatch | 95/84 | 27.7 s |
| 17 | #assign STR 3 VIT 2 | System (Befehl) | open_run_level | Spend free stat points on STR and VIT | Adventurers' Guild hall, Alderwatch | 95/84 | 2.2 s |
| 18 | I look over the fresh postings on the Guild board. | Erzähler | open_run_level | Find a new achievable contract | Adventurers' Guild hall, Alderwatch | 95/84 | 30.8 s |
| 19 | I head to Alderwatch's blacksmith to compare weapon and armour prices against my starter gear. | Erzähler | open_run_level | Check gear upgrades at a smith | Alderwatch smithy | 95/84 | 22.7 s |
| 20 | I thank the smith and step out; with 7 silver 5 copper nothing here beats my gear at a price I can afford, so I head back to the market squa… | Erzähler | open_run_level | Gear unaffordable; seek income until new contracts arrive | Alderwatch market square | 95/84 | 31.6 s |
| 21 | I accept the furrier's seven silver for the pelt, then the old woman's fourteen copper for the two claws and the fang. | Erzähler | open_run_level | Sell lynx parts for 7 silver 14 copper | Alderwatch market square | 95/84 | 35.5 s |
| 22 | I accept the old woman's offer: fourteen copper for the pair of claws and the fang together. | Erzähler | open_run_level | Sell lynx claws and fang for 14 copper | Alderwatch market square | 95/84 | 20.9 s |
| 23 | I turn to the old woman and say plainly: "Merchant, I accept your offer — fourteen copper for the two claws and the fang together." | Erzähler | open_run_level | Sell lynx claws and fang to the merchant | Alderwatch market square | 95/84 | 32.5 s |
| 24 | #bag | System (Befehl) | open_run_level | Verify whether the claw and fang sale and coin actually recorded | Alderwatch market square | 95/84 | 2.2 s |
| 25 | "Merchant, I accept your offer — fourteen copper for the two claws and the fang together," I say again, and wait for the coins. | Erzähler | open_run_level | Complete the claw and fang sale that the bag shows as unrecorded | Alderwatch market square | 95/84 | 13.8 s |
| 26 | I walk over to the guildsman by the timber yard and ask what the wall-hauling work pays and what it involves. | Erzähler | open_run_level | Take the day-work offer for income | Alderwatch market square | 95/84 | 14.6 s |
| 27 | I leave Harl to his tallies and look for a blacksmith's forge in Alderwatch, then enter and ask what weapons and armour he has for sale. | Erzähler | open_run_level | Check a smith for gear upgrades before committing to day work | Alderwatch smithy | 95/84 | 21.1 s |
| 28 | I thank the smith and leave without buying today — 159 copper can't cover the 140-cp fine sword or mail and still keep 20 — and plan to take… | Erzähler | open_run_level | Defer gear purchase until income covers it while keeping 20 cp reserve | Alderwatch smithy | 95/84 | 14.1 s |
| 29 | Merchant, I'll take the fine chain mail for 72 copper — here's the coin. If the sale goes through, I put it on right away. | Erzähler | open_run_level | Buy and equip affordable armour upgrade (fine chain mail, 72 cp of 159), keeping 87 cp | Alderwatch smithy | 95/84 | 15.6 s |
| 30 | I leave the smithy and head to the Adventurers' Guild hall to look at the contract board for a job I can still do today. | Erzähler | open_run_level | Find an achievable Guild contract for the free day | Adventurers' Guild hall, Alderwatch | 95/84 | 36.7 s |
| 31 | I take the Lynx at the Duck Pens slip to the clerk's desk and ask to accept the contract. | Erzähler | open_run_level | Accept an achievable Novice contract for today | Adventurers' Guild hall, Alderwatch | 95/84 | 14.6 s |
| 32 | I head out the south gate and follow the duck-path signs to Warden Malla Ostrow's duck pens, then find her and tell her I'm here about the l… | Erzähler | open_run_level | Travel to the duck pens and report to the warden | the Alderwatch watermeadow duck pens | 95/84 | 26.7 s |
| 33 | I'll wait at the pens with you until dusk, then, and keep an eye on the south fence where the ditch runs close. | Erzähler | open_run_level | Stake out the lynx at dusk with the warden | the Alderwatch watermeadow duck pens | 95/84 | 42.6 s |
| 34 | I draw my longsword and charge the lynx at the fence gap, swinging Cleave into it before it can reach the pens. | Erzähler | open_run_level | Attack the lynx with Cleave to fulfil the contract | the Alderwatch watermeadow duck pens | 95/84 | 25.6 s |
| 35 | I thank Malla, accept the bed and a bite, and sleep until morning. | Erzähler | open_run_level | Recover overnight at the warden's house | the Alderwatch watermeadow duck pens | 115/84 | 22.2 s |
| 36 | I eat the eggs, then tell Malla I'll take the pelt to the tannery in town and set out for the Alderwatch Guild hall to get my contract slip … | Erzähler | open_run_level | Turn in lynx contract at the Guild hall | Adventurers' Guild hall, Alderwatch | 115/84 | 38.7 s |
| 37 | #assign STR 2 VIT 2 AGI 1 | System (Befehl) | open_run_level | Spend level-up points on warrior stats | Adventurers' Guild hall, Alderwatch | 115/84 | 2.2 s |
| 38 | I ask the clerk whether the Guild buys lynx parts like claws and fangs, and what they'd pay for three claws, two fangs and the pelt. | Erzähler | open_run_level | Sell surplus loot at the Guild desk | Adventurers' Guild hall, Alderwatch | 115/84 | 34.0 s |
| 39 | I accept the offer and sell all three claws, two fangs and the pelt at those rates. | Erzähler | open_run_level | Sell surplus lynx parts to the Guild clerk | Adventurers' Guild hall, Alderwatch | 115/84 | 24.4 s |
| 40 | I leave the Guild hall and head to Alderwatch's blacksmith to compare affordable weapon and armour upgrades. | Erzähler | open_run_level | Gear upgrade at smith per gear priority | Alderwatch smithy | 115/84 | 33.1 s |
| 41 | I'll take the superior longsword at eighteen silver. Please pass it over and take the coin. | Erzähler | open_run_level | Buy the superior longsword upgrade | Alderwatch smithy | 115/84 | 29.6 s |
| 42 | I ask the smith to state his final price and terms for the superior longsword, and say I'll buy it at that offer if I can cover it. | Erzähler | open_run_level | Establish a valid canonical offer, then buy the superior longsword | Alderwatch smithy | 115/84 | 44.4 s |
| 43 | The smith has just stated his final offer: the superior longsword for eighteen silver. I accept that offer and buy the superior longsword fr… | Erzähler | open_run_level | Complete the longsword purchase with a canonical offer | Alderwatch smithy | 115/84 | 18.6 s |
| 44 | I buy the superior longsword from the smith at his stated price of eighteen silver — price limit twenty silver — paying on the counter now. | Erzähler | open_run_level | Complete the longsword purchase with an explicit agreed price and limit | Alderwatch smithy | 115/84 | 32.9 s |
| 45 | #equipment | System (Befehl) | open_run_level | Verify whether the longsword purchase and equipping actually booked | Alderwatch smithy | 115/84 | 2.2 s |
| 46 | #audit | System (Befehl) | open_run_level | Check whether the refused longsword purchases silently changed coin or inventory | Alderwatch smithy | 115/84 | 2.2 s |
| 47 | I look around the smithy and call out to the smith: "Are you here? I'm ready to buy that superior longsword at eighteen silver if you can of… | Erzähler | open_run_level | Re-establish the smith's presence, then get a valid offer and buy | Alderwatch smithy | 115/84 | 33.1 s |
| 48 | I buy the superior F-Rank longsword from the smithwoman at the confirmed engine price of 260 copper — total limit 260 cp, paying now. | Erzähler | open_run_level | Complete the longsword purchase at the binding engine price | Alderwatch smithy | 115/84 | 30.2 s |
| 49 | I ask the smithwoman: "Would you buy my starter heavy armor off me? What's your offer?" | Erzähler | open_run_level | Sell surplus gear to raise coin for the longsword | Alderwatch smithy | 115/84 | 15.5 s |
| 50 | "Deal — thirty copper for the starter armor, sold." I hand it over and take the coins, then ask: "And would you take my starter longsword as… | Erzähler | open_run_level | Accept the 30 cp armor sale and raise more coin via longsword trade-in | Alderwatch smithy | 115/84 | 17.5 s |
| 51 | "Twelve for the sword — sold." I hand over the starter longsword and take the coins, then say: "That brings me to the full amount — here is … | Erzähler | open_run_level | Sell starter longsword for 12 cp and buy the superior F-Rank longsword at 260 cp | Alderwatch smithy | 115/84 | 21.2 s |
| 52 | I take the starter heavy armor from my bag and set it on the counter. "This one's a spare from my pack — thirty copper, as you offered. Sold… | Erzähler | open_run_level | Sell the bag-spare starter armor for 30 cp, then buy the superior longsword at 260 cp | Alderwatch smithy | 115/84 | 31.7 s |
| 53 | I head to the outfitter by the market and ask: "Would you buy this spare starter heavy armor off me? What's your offer?" | Erzähler | open_run_level | Sell the spare starter armor at the outfitter to close the 19 cp gap for the longsword | outfitter by the market | 115/84 | 25.4 s |
| 54 | "Twenty-five, sold." I hand over the spare starter heavy armor and take the coins. | Erzähler | open_run_level | Sell the spare armor for 25 cp, keeping coin for the longsword after Harl's day work | outfitter by the market | 115/84 | 21.4 s |
| 55 | "That suits me — twenty-five, sold." I push the armor across the counter and take the coins he counts out. | Erzähler | open_run_level | Complete the 25 cp sale to close the coin gap for the longsword | outfitter by the market | 115/84 | 22.9 s |
| 56 | I push the armor across the counter into his hands. "Kit's yours — deal done at twenty-five." | Erzähler | open_run_level | Complete the 25 cp armor sale | outfitter by the market | 115/84 | 25.8 s |
| 57 | I take the armor back and pocket it. "Keep your coins, then — we're done here." I leave the outfitter and head to find Harl to confirm the w… | Erzähler | open_run_level | Drop the stalled armor sale and line up Harl's day work | timber yard | 115/84 | 36.5 s |
| 58 | "Still wanted. Alaric Red — tell your foreman to count me in at sun-up, east gate, mason's stretch." | Erzähler | open_run_level | Confirm Harl's wall-hauling day work | timber yard | 115/84 | 22.4 s |
| 59 | I leave the timber yard and head to the Guild hall to check the contract board for a morning hunt I can finish before sundown. | Erzähler | open_run_level | Find a short Guild contract to fill the day before the sun-up wall work | Adventurers' Guild hall, Alderwatch | 115/84 | 76.5 s |
| 60 | "Nothing for now — I'll come back when the fresh batch is posted." I leave the Guild hall and look for cheap lodging for the night, so I'm r… | Erzähler | open_run_level | Find lodging and rest before the dawn wall work | the Drowned Gull | 115/84 | 53.4 s |
| 61 | "Two coppers it is — I'll take the loft pallet for the night." I pay the landlady and settle in to rest until morning. | Erzähler | open_run_level | Buy lodging and sleep until dawn for the wall work | the Drowned Gull | 115/84 | 26.8 s |
| 62 | "Agreed plain: loft pallet, two coppers, supper extra if I want it." I pay the innkeeper two coppers and settle in to rest until morning. | Erzähler | open_run_level | Book lodging from the innkeeper and sleep until dawn | the Drowned Gull | 135/84 | 21.5 s |
| 63 | I leave the Drowned Gull and head to the east gate, then walk the mason's stretch to ask for Harl and start the wall-hauling day work. | – | open_run_level | Report for Harl's sun-up wall-hauling work | the Drowned Gull | 135/84 | 7.7 s **interrupted** |

**Beobachtungen des Spielers** (nur aus dem, was er auf dem Bildschirm sah; jeweils zum Ergebnis des Zugs davor):

- zu Zug 7 (notiert vor Zug 8): Contract confirmed active in HUD; coin 3 silver despite earlier showing 30 copper—HUD is authoritative.
- zu Zug 22 (notiert vor Zug 23): Engine requires addressing the counterparty as 'Merchant'; named NPCs map to Merchant A/B/C.
- zu Zug 23 (notiert vor Zug 24): Narration shows the sale completed and coins counted, but the HUD still lists the claws/fang as carried and coin unchanged; no ENGINE RESULT confirmed the trade.
- zu Zug 24 (notiert vor Zug 25): Bag still lists the claws/fang and coin unchanged at 145 copper despite narrated sale — trade again not engine-recorded.
- zu Zug 26 (notiert vor Zug 27): Sale finally engine-recorded at +14 copper (159). Harl's day work starts tomorrow sun-up, so today is free for gear.
- zu Zug 27 (notiert vor Zug 28): Smith's chalk prices (10 cp) conflict with engine-confirmed prices (80 cp common); engine prices are binding, making upgrades unaffordable for now.
- zu Zug 28 (notiert vor Zug 29): HUD shows 1 Gold 5 Silver 9 Copper (=159 cp), more than my earlier 159 note assumed; fine mail at 72 cp is affordable while a 140-cp fine sword is not.
- zu Zug 29 (notiert vor Zug 30): Fine chain mail purchase and equipping engine-confirmed (DEF 9); weapon upgrade still unaffordable at 87 cp.
- zu Zug 31 (notiert vor Zug 32): Contract confirmed ACTIVE (0/1 defeated); mail equipped, DEF 9.
- zu Zug 39 (notiert vor Zug 40): Sold lynx parts for 109 copper; now 241 copper. HUD shows fine F-Rank chain mail already equipped though not shown as purchased earlier.
- zu Zug 41 (notiert vor Zug 42): Engine refused the 18-silver narrator offer as 'no single valid canonical offer'; coin dropped 241→201 copper despite NOT BOUGHT, and HUD still shows Starter Longsword equipped.
- zu Zug 42 (notiert vor Zug 43): Engine refused the purchase as 'no valid canonical offer' while narrator showed coin paid; HUD still shows Starter Longsword and coin 201cp. Retrying with the explicit offer stated.
- zu Zug 43 (notiert vor Zug 44): Engine keeps refusing the 18-silver buy despite narrator showing payment; coin may have silently dropped twice (241→201 cp). Will verify HUD after this attempt.
- zu Zug 44 (notiert vor Zug 45): HUD still shows Starter Longsword equipped and coin 2g4s1cp despite narrator showing payment; engine booked NOT BOUGHT three times. Possible silent coin loss earlier (241→201 cp).
- zu Zug 45 (notiert vor Zug 46): Third refusal of the 18-silver longsword buy; narrator showed payment but engine booked NOT BOUGHT and HUD still shows Starter Longsword and 2g4s1cp.
- zu Zug 46 (notiert vor Zug 47): Audit shows refusals because npc.smith was not present — the smithy is empty; HUD coin unchanged at 2g4s1cp, so no silent loss after all.
- zu Zug 47 (notiert vor Zug 48): Narrator showed an 18-silver sale and coin paid, but HUD still shows Starter Longsword and 2g4s1cp — treating it as not booked; engine price is 260 cp.
- zu Zug 49 (notiert vor Zug 50): Narrator earlier showed an 18-silver buy that the engine never booked; coin unchanged. Selling armor (30 cp) still leaves me 19 cp short of the 260 cp longsword price, so I need one more sale.
- zu Zug 51 (notiert vor Zug 52): Engine refused both the sword sale (equipped) and the coin payment; HUD still shows Starter Heavy Armor carried and 2g4s1cp, so the earlier armor sale also never booked. Selling the carried spare (30 cp) covers the 19 cp gap.
- zu Zug 52 (notiert vor Zug 53): Smith confirmed: won't buy equipped gear or a second identical armor; still 19 cp short of 260 cp longsword.
- zu Zug 53 (notiert vor Zug 54): HUD shows I already wear fine F-Rank chain mail, so armour is upgraded; only the starter longsword remains. Buying the 260 cp sword now would leave only 6 cp, so I'll take Harl's sun-up work first.
- zu Zug 55 (notiert vor Zug 56): Merchant D has now stalled the same sale three times without the engine booking it; if it fails again I'll drop this sale and move on.
- zu Zug 56 (notiert vor Zug 57): Merchant D stalled the same 25 cp sale three turns without the engine booking it; abandoning it per my note. Armor sale unresolved but non-blocking.
- zu Zug 57 (notiert vor Zug 58): Engine says the merchant still holds the armor — sale abandoned, armor stays in pouch. Coin unchanged at 2g4s1cp; longsword upgrade still short by 19 cp, so day work stands as plan.
- zu Zug 58 (notiert vor Zug 59): Engine confirmed the merchant still holds the armor; the sale was never booked, so the starter armor remains in my pouch and coin is unchanged.
- zu Zug 62 (notiert vor Zug 63): Lodging booked and full recovery confirmed (HP 135/135); engine accepted the purchase only after addressing the payment to the innkeeper.

## Kämpfe

| Kampf | Zug | Gegner im Kampf | Gruppe draußen | verborgen | besiegt | Ergebnis |
|---|---:|---:|---|---|---:|---|
| enc.t12 | 12 | 1 | – | nein | 1 | gewonnen, 60 XP |
| enc.t32 | 34 | 1 | – | nein | 1 | gewonnen, 60 XP |

## Quests

- **Catch the Marsh Lynx of the Duck Pens** — active (Zug 7) → completed (Zug 16), READY
  - Aufgabe: Kill 1 marsh lynx at the Alderwatch watermeadow duck pens. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 marsh lynx killed at the Alderwatch watermeadow duck pens.
- **Thin the Bramblewood Boar Sounder** — expired (Zug 30)
  - Aufgabe: Kill 5 adult boars at the Bramblewood orchard edge. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 5 adult boars killed at the Bramblewood orchard edge.
- **Cull the Gallowfen Bog Striders** — expired (Zug 30)
  - Aufgabe: Kill 6 bog striders at the Gallowfen eel-weirs. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 6 bog striders killed at the Gallowfen eel-weirs.
- **Slay the Old Grey of the North Road** — expired (Zug 30)
  - Aufgabe: Kill 1 the Old Grey at the North Road verges north of Alderwatch. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 the Old Grey killed at the North Road verges north of Alderwatch.
- **Clear the Old Crown Catacombs, Level 1** — expired (Zug 30), Dungeon loc.old_crown_catacombs Ebene 1
  - Aufgabe: Clear level 1 of Old Crown Catacombs. Risk: groups and stronger foes; a matching rank does not guarantee a safe solo expedition.
  - Endzustand: Level 1 of Old Crown Catacombs is clear.
- **Lynx at the Duck Pens** — active (Zug 31) → completed (Zug 36)
  - Aufgabe: Kill 1 marsh lynx at the Alderwatch watermeadow duck pens. Only engine-recorded kills of this population count. Return to the Guild to claim payment.
  - Endzustand: 1 marsh lynx killed at the Alderwatch watermeadow duck pens.

## Auffälligkeiten

- Zug 63 (Runner/UI): interrupted
- Zug 11, Nachricht 22 (extraction_repaired): the extractor's first answer needed a repair
- Zug 14, Nachricht 28 (extraction_repaired): the extractor's first answer needed a repair
- Zug 14, Nachricht 28 (extractor_recovery): the extractor required transport recovery (status applied)
- Zug 18, Nachricht 35 (board_failed): the board generator failed
- Zug 21, Nachricht 41 (planner_repaired): the planner's first answer needed a repair
- Zug 33, Nachricht 65 (planner_repaired): the planner's first answer needed a repair
- Zug 36, Nachricht 72 (extraction_repaired): the extractor's first answer needed a repair
- Zug 39, Nachricht 78 (extraction_repaired): the extractor's first answer needed a repair
- Zug 41, Nachricht 81 (planner_repaired): the planner's first answer needed a repair
- Zug 43, Nachricht 85 (planner_repaired): the planner's first answer needed a repair
- Zug 48, Nachricht 95 (planner_repaired): the planner's first answer needed a repair
- Zug 49, Nachricht 98 (extraction_repaired): the extractor's first answer needed a repair
- Zug 50, Nachricht 100 (extraction_repaired): the extractor's first answer needed a repair
- Zug 51, Nachricht 101 (planner_repaired): the planner's first answer needed a repair
- Zug 52, Nachricht 103 (planner_repaired): the planner's first answer needed a repair
- Zug 53, Nachricht 106 (extraction_repaired): the extractor's first answer needed a repair
- Zug 54, Nachricht 107 (planner_repaired): the planner's first answer needed a repair
- Zug 55, Nachricht 109 (planner_repaired): the planner's first answer needed a repair
- Zug 56, Nachricht 111 (planner_repaired): the planner's first answer needed a repair
- Zug 59, Nachricht 117 (board_failed): the board generator failed
- Zug 60, Nachricht 120 (extraction_repaired): the extractor's first answer needed a repair
- Zug 62, Nachricht 123 (planner_repaired): the planner's first answer needed a repair
- Runner-Hinweis (dem Spieler nicht gezeigt): Rename ChatRenaming chat…
- Spieler: 18× keine gültige JSON-Entscheidung (Züge 4, 9, 10, 15, 19, 21, 34, 36, 41, 45, 48, 49, 51, 52, 53, 60, 62, 63)
- Server: Generation failed AbortError: The operation was aborted.
- Server: Generation failed AbortError: The operation was aborted.

System-Panels: CLARIFY 0, NOT TAKEN 0, REFUSED 0, BLOCKED 0, FAILED 0. Zurückgewiesene Deltas: engine_owned_fact 8, ambient 2, world_rule 2, engine_recovery 1, guild_payout 2, npc_presence 1, offer 13, pc_inventory 5, engine_booked 1, coin_already_received 1, no_go 1, scene_context 4, entity_fact 1, sale_evidence 1.
Soft-Extractor-Fehler mit Fortsetzung: 0. Ein Dialogzug kann trotz leerer Planner-Commands neue NPCs, Gaben oder Ereignisse enthalten; der fortgesetzte Test beweist **keine** vollständige Weltübernahme.
Recovery-Beobachtung: Planner leer 0, Transport 0, davon erfolgreich mit 0 Commands 0; Extractor leer 0, Transport 1, davon angewendet mit 0 Deltas 0. Null-Ergebnisse sind Prüfhinweise, keine bewiesenen Spielweltfehler.

Narrator-Recovery: 0 gespeicherte Versuchsmarkierungen (kein Nachweis gestarteter Provideraufrufe); danach 0 mit Erzähltext, 0 leer, 0 ohne Antwort; 0 mit Erzähltext und angewendeter Extraktion.

Spieler-JSON: 18/63 Erstantworten ungültig (28.6 %); 18 Zusatzanfragen; 0 Entscheidungen ohne brauchbare Antwort.

## Performance

| Rolle | Aufrufe | Reparaturen | Median | p90 | Prompt-Tokens (Median) | davon Cache | Antwort-Tokens (Median) | Reasoning (Median) | finish_reason | leer |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| plan | 67 | 11 | 3.0 s | 9.0 s | 12544 | 10476 | 94 | – | stop 67 | 0 |
| narrator | 56 | 0 | 9.6 s | 19.2 s | 11450 | 8877 | 393 | – | stop 55 | 0 |
| extract | 63 | 7 | 5.4 s | 11.3 s | 13618 | 11021 | 287 | – | stop 62 | 0 |
| board | 8 | 4 | 9.2 s | 31.8 s | 3169 | 2539 | 1120 | – | stop 8 | 0 |

## Laufzeit (gemessen)

| | Zeit |
|---|---:|
| Gesamt (Start bis Ende des Spiels) | 35:49 min |
| Einrichtung bis zum ersten Zug (davon SillyTavern-Start 28.2 s) | 0:41 min |
| 63 Züge, Spiel (Senden bis HUD nach der Extraktion) | 28:00 min — Median 22.9 s, p90 38.7 s, max 176.9 s |
| 63 Züge, Spieler-Entscheidung | 6:13 min — Median 4.5 s, 18 unbrauchbare Antworten |
| davon laut Records: Planner / Board / Erzähler / Extraktor / Warten | 4:19 min / 1:57 min / 10:25 min / 8:55 min / 0:00 min |
| Ø je Zug (Spiel + Spieler) | 32.6 s |
| Hochrechnung bei diesem Tempo | 40 Züge ≈ 21:43 min, 80 Züge ≈ 43:26 min (ohne Einrichtung) |

### Auffällige Einzelzeiten

Je Phase/Providerrolle: über 30 Sekunden und über dem Dreifachen ihres Medians; höchstens drei Einträge. Providerzeiten liegen innerhalb der Spielzeiten, sie werden nicht zusätzlich summiert.

| Phase | Zug | API-Aufruf | Zeit | Median |
|---|---:|---:|---:|---:|
| Spiel | 14 | – | 176.9 s | 22.9 s |
| Spiel | 59 | – | 76.5 s | 22.9 s |
| Provider narrator | 14 | 38 | 44.3 s | 9.6 s |
| Provider board | 59 | 179 | 31.8 s | 9.2 s |

## Schutz und Geheimnisse

- Aus dem Profil gelesen (nur lesend): 7 Dateien; danach alle unverändert.
- Profilordner insgesamt (1252 Dateien, Größe und Zeit): unverändert
- `secrets.json` des Profils wurde nicht gelesen; der Schlüssel kam aus der Umgebungsvariable und lag nur in der isolierten Instanz, deren `secrets.json` am Ende gelöscht wurde.
- Geheimnis-Scan des Laufordners (10 Textdateien): kein Schlüssel, kein Bearer-Token, kein api_key-Feld.
- Isolierte Instanz: gelöscht.

## Dateien

- `chat.jsonl` — der vollständige Chat, wie SillyTavern ihn speichert
- `avereth-events.json` — die Ereignisse der Engine (Format des Buttons „Export event log“)
- `server.log` — die Konsole der isolierten SillyTavern-Instanz (alle Requests und Antworten)
- `server.timed.log` — dieselbe Konsole mit Uhrzeit je Zeile
- `chat-completions.jsonl` — jeder Chat-Completion-Request mit seiner Antwort
- `calls.json` — je Aufruf: Rolle, Modell, Zeit, Tokens, finish_reason, Reparatur
- `player.jsonl` — jede Entscheidung des Spielers mit dem Bildschirmtext, den er sah
- `evaluation.json` — die Auswertung (Etappen, Kämpfe, Quests, Auffälligkeiten)
- `run.json` — Ablauf des Laufs: Züge, Zeiten, Hinweise, Seitenfehler, Statuszeile
- `import.json` — was aus dem Profil übernommen wurde (ohne Schlüssel)
- `report.md` — dieser Bericht
- `screens/` — Bildschirmfotos (Ende, Probleme)
