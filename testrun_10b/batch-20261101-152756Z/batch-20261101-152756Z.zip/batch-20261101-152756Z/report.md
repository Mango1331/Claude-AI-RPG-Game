# Avereth – 3 natürliche Testkampagnen

Status: **interrupted**. Serie abgeschlossen bedeutet, dass die Läufe beendet sind; es bedeutet nicht 3 bestandene Level-15-Abnahmen.

| Nr. | Profil | Seed | Eingaben | Level | Ende | Originalbericht |
|---|---|---:|---:|---:|---|---|
| 1 | guild-warrior | 1320776721 | 63 | 3 | process_error | [report.md](001-guild-warrior/20261101-152757Z-current_test/report.md) |
| 2 | guild-mage | 1320776722 | – | – | pending | – |
| 3 | guild-rogue | 1320776723 | – | – | pending | – |

